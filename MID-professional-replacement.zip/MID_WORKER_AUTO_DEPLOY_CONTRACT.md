# MID Worker Auto-Deploy Contract

## Zweck
Der Cloudflare-Worker wird bei fachlichen Worker-Änderungen automatisch aus demselben bereits geprüften MID-Releasecommit veröffentlicht. Browser/PWA und Capacitor-iOS verwenden weiterhin denselben React/Vite-/Worker-Fachkern; es entsteht kein Plattformfork.

## Harte Freigabereihenfolge
1. Professional-ZIP sicher installieren.
2. `npm ci`, Dependency-Audit, TypeScript/Vite-Build, Worker-Syntax und vollständige MID-Regressionen bestehen.
3. Fachliche Worker-Änderung gegen `mid-stable` ermitteln. Eine reine Änderung von `WORKER_VERSION` löst keinen Deploy aus.
4. Aktuelle Cloudflare-Worker-Settings und das aktive Deployment lesen. Bestehende Variablen/Secrets werden nicht exportiert.
5. Nur sicher abbildbare Resource-Bindings in eine temporäre Wrangler-Konfiguration spiegeln. Unbekannte Binding-Typen, fehlende Compatibility-Date oder ein aktives Split-Deployment brechen fail-closed ab.
6. Neue Worker-Version mit exakt gepinntem Wrangler hochladen, noch ohne Produktivtraffic.
7. Vorherige Worker-Version bleibt bei 100 %, neue Version wird mit 0 % in ein Deployment aufgenommen.
8. `?mode=health` wird über `Cloudflare-Workers-Version-Overrides` gezielt gegen die neue 0-%-Version geprüft. Bei aktiver RUC-Pipeline muss zusätzlich `?mode=ruc-health` `configured:true`, `ready:true`, `fresh:true` melden.
9. Erst nach grünem Smoke wird die neue Version auf 100 % promoviert und nochmals ohne Override geprüft.
10. Bei Fehler nach dem 0-%-Staging wird automatisch die vorherige Version wieder zu 100 % aktiviert. Pages und `mid-stable` werden in diesem Lauf nicht weitergeführt.
11. Erst nach grünem Worker-Gate darf das GitHub-Pages-Deployment beginnen; erst danach wird `mid-stable` finalisiert.

## Konfigurationsschutz
- Wrangler v4 wird in CI auf eine konkrete Version festgeschrieben; die GitHub Action selbst ist auf einen vollständigen Commit-SHA gepinnt.
- `--strict`, `--keep-vars`, `--no-bundle`, `--experimental-provision=false` und `--experimental-auto-create=false` sind Pflicht.
- Die aktuelle Remote-`compatibility_date` und vorhandene `compatibility_flags` werden übernommen; kein Datum wird geraten.
- Secrets werden niemals in Repositorydateien, temporäre Config-Dateien oder Logs geschrieben.
- `plain_text`/JSON-Dashboardvariablen werden über `keep_vars` erhalten.
- Aktuell sicher unterstützte Resource-Bindings: KV, R2, D1, Service, Analytics Engine, Vectorize und Hyperdrive. Andere Binding-Typen blockieren den automatischen Deploy, bis ihre verlustfreie Abbildung implementiert und regressionsgeschützt ist.
- Das R2-Binding `MID_DWD_RUC_DATA` darf nur automatisch ergänzt werden, wenn `MID_RUC_R2_BUCKET` gesetzt und `MID_RUC_BINDING_AUTO_APPROVED=true` ausdrücklich freigegeben ist. Wrangler darf dabei keinen Bucket automatisch anlegen.

## Einmalige GitHub-/Cloudflare-Freigaben
Für fachlich geänderte Worker sind erforderlich:
- Secret `CLOUDFLARE_ACCOUNT_ID`
- Secret `CLOUDFLARE_API_TOKEN` (Cloudflare-Token für Worker-CI/CD, auf das MID-Konto begrenzt)
- Variable `MID_CLOUDFLARE_WORKER_NAME`
- Variable `MID_WORKER_HEALTH_URL` oder vorhandene `VITE_METAR_PROXY_URL`
- Variable `MID_WORKER_DEPLOY_ENABLED=true`

Optional für den bereits vorbereiteten privaten RUC-R2-Pfad:
- `MID_RUC_R2_BUCKET`
- `MID_RUC_BINDING_AUTO_APPROVED=true`, sobald der Bucket existiert und die Bindung automatisch ergänzt werden soll
- `MID_RUC_PIPELINE_ENABLED=true` erst nach erfolgreicher RUC-Erstinbetriebnahme; dann wird RUC-Health Teil des Worker-Deploy-Gates.

## Notfallartefakt
`MID-worker.zip` wird weiterhin bei jedem gekoppelten Release erzeugt. Es ist Backup/Notfall-/Audit-Artefakt, nicht mehr der reguläre Veröffentlichungsweg, sobald der Auto-Deploy einmalig aktiviert wurde.

## Ergänzung v0.9.77.18 – KNMI-HARMONIE-EPS-Produktivcache

Der produktive KNMI-HARMONIE-EPS-TAR-Indexcache verwendet das bereits vorhandene KV-Binding `MID_PUSH_SUBSCRIPTIONS` mit dem strikt getrennten Präfix `cache:knmi-eps:tar-index:v1:`. Für diesen Cache darf der Auto-Deploy **kein neues KV-Namespace und keine sonstige Cloudflare-Ressource** provisionieren. Die vorhandene Remote-KV-Bindung wird wie bisher verlustfrei gespiegelt.

Der Push-Scheduler bleibt auf `sub:`-Listenabfragen beschränkt; der KNMI-Cache selbst verwendet kein `KV.list()`. Fachliche Worker-Änderungen am Cache lösen den bestehenden gestagten Worker-Deploy aus. Verbindliche Fachreferenz: `MID_KNMI_HARMONIE_EPS_CACHE_CONTRACT.md`. Required Regression: `scripts/test-knmi-eps-productive-cache-097718.mjs`.

## Getrennte DNS-/Worker-Credentials ab v0.9.85.185

Für das Proxy-Gate des bestehenden `www.midwx.app`-CNAME ist ausschließlich das Repository Secret `CLOUDFLARE_DNS_API_TOKEN` zulässig. Dieser Token ist auf die für den DNS-Record erforderliche Zone-/DNS-Berechtigung für `midwx.app` zu begrenzen.

`CLOUDFLARE_API_TOKEN` bleibt ausschließlich der bestehende Worker-/Route-Credential-Pfad. Der DNS-Schritt darf ihn nicht als Fallback verwenden; umgekehrt darf `CLOUDFLARE_DNS_API_TOKEN` nicht für Worker-Upload, Worker-Promotion oder Workers-Route eingesetzt werden. Ein fehlendes, leeres oder unzureichend berechtigtes DNS-Secret blockiert den Release fail-closed vor Pages und `mid-stable`.

## www.midwx.app Proxy-Gate ab v0.9.85.184

Vor der Same-Origin-Workers-Route muss der bestehende `www.midwx.app`-CNAME über Cloudflare proxied sein. Das Release-Gate darf ausschließlich `proxied=true` für genau diesen bestehenden Record setzen. CNAME-Ziel, Name, Typ, TLS-/SSL-Einstellungen und sämtliche anderen DNS-Records bleiben unverändert. Mehrdeutige oder nicht proxyfähige DNS-Konfigurationen blockieren den Release.

Die hierfür erforderliche CI-Berechtigung ist `Zone:DNS Edit`, auf `midwx.app` begrenzt. Ein fehlendes Recht darf nicht durch einen globalen DNS-Token oder andere Least-Privilege-Abweichungen ersetzt werden.

## Corporate-safe Same-Origin-Gate ab v0.9.85.183

Nach einer erforderlichen Worker-Promotion und auch bei fachlich unverändertem Worker muss vor Pages/Stable die exakte Route `www.midwx.app/api/mid-worker*` auf den konfigurierten MID-Worker bestätigt sein. Die Route wird idempotent angelegt, sofern sie fehlt. Zeigt dasselbe exakte Pattern bereits auf einen anderen Worker, wird es nicht überschrieben; der Release bricht fail-closed ab.

Der Same-Origin-Endpunkt `https://www.midwx.app/api/mid-worker` muss anschließend `mode=health` bestehen. Nach fachlicher Worker-Änderung ist die neue Releaseversion zwingend; bei fachlich unverändertem Worker wird die bereits aktive plausible Worker-Version akzeptiert. Bei aktiver RUC-Pipeline gilt zusätzlich der bestehende RUC-Health-Vertrag. DNS, TLS und fremde Routes sind außerhalb dieses Gates und werden nicht automatisch verändert.

Im produktiven Browser ist dieser Same-Origin-Endpunkt der alleinige Worker-Kandidat. Direkte DWD-/EUMETSAT-/RainViewer-/OpenFreeMap-Abrufe kritischer Kartenpfade werden dort nicht als Netzfilter-Fallback benutzt. Native und lokale Entwicklungsumgebungen behalten ihre explizit konfigurierten Plattformpfade.

