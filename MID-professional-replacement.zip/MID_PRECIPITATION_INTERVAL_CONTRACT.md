# MID · Niederschlags-Intervallvertrag

Stand: v0.9.79.16 · 07.09.2026

## Zweck

Dieser Vertrag trennt appweit **Rohdaten-/Rechenzeit**, **Zeitpunktwerte** und **sichtbare Prognoseintervalle**. Ziel ist zugleich meteorologische Korrektheit und eine für Menschen eindeutige Zeitsemantik: Wenn MID bei **08:00 Uhr** Niederschlag anzeigt, bedeutet dies im Stundenraster **08:00–09:00 Uhr** – nicht 07:00–08:00 Uhr.

Der Vertrag gilt für Niederschlagsmenge, Regen/Schauer/Schnee-Anteile, Niederschlagswahrscheinlichkeit und die daraus abgeleitete Niederschlagsphase bzw. das Niederschlagspiktogramm. Instantane Größen wie Temperatur, Taupunkt, Wind, Luftdruck und Bewölkung bleiben am sichtbaren Zeitpunkt selbst verankert.

## 1. Provider-Semantik bleibt unverändert

Open-Meteo kennzeichnet `precipitation`, `rain`, `showers` und `snowfall` als **Summe der vorangegangenen Stunde**. `precipitation_probability` ist die **Wahrscheinlichkeit der vorangegangenen Stunde**. Der Provider-Zeitstempel `T` bezeichnet für diese Felder also das **Intervallende**.

DWD MOSMIX `RR1c` ist analog der Gesamtniederschlag der **letzten 1 Stunde**. Auch hier bleibt der Roh-/Rechenkern endgestempelt.

Für einen rohen Stundenwert mit Zeitstempel `T` gilt daher:

`Rohintervall = [T − 60 min, T]`

Für einen rohen 15-Minuten-Wert:

`Rohintervall = [T − 15 min, T]`

Die frühere zentrierte Zuordnung `[T − Δt/2, T + Δt/2]` ist für Akkumulations- und Wahrscheinlichkeitsfelder verboten.

## 2. Sichtbare MID-Semantik: Slotbeginn

Eine Endnutzer-Prognose wird **vorwärts** gelesen. Der sichtbare Zeitstempel `S` ist deshalb der **Beginn** des Niederschlagsfensters:

`Sichtbarer Slot = [S, S + Δt]`

Für ein Stundenfeld übernimmt MID dazu die Roh-Niederschlagsfelder des unmittelbar folgenden endgestempelten Wertes:

`Anzeige(S) = Rohwert(S + 60 min)`

Beispiel:

- Provider `09:00 = 0,8 mm` bedeutet roh `08:00–09:00`.
- MID zeigt deshalb **08:00 · 0,8 mm** bzw. **08:00–09:00 · 0,8 mm**.
- Der Nutzer muss keinen Provider-Zeitkonventionswechsel kennen.

Dieses Prinzip entspricht der üblichen Endnutzersemantik von Stundenprognosen: ein mit 08:00 bezeichnetes Stundenwetter beschreibt die ab 08:00 beginnende Stunde.

## 3. Menge, PoP und Niederschlagsart müssen dasselbe Intervall meinen

Für jeden sichtbaren Slot werden gemeinsam verschoben bzw. zusammengefasst:

- `precipitation`
- `rain`
- `showers`
- `snowfall`
- `precipitation_probability`
- die **aus diesen Niederschlagsfeldern** abgeleitete Phase / Niederschlagsdarstellung.

Es ist verboten, beispielsweise die Menge auf `08:00–09:00` zu beziehen, die PoP aber auf `07:00–08:00` oder ein Regenpiktogramm aus einem anderen Intervall zu verwenden.

Instantane Felder bleiben dagegen bei `S`, insbesondere:

- Temperatur / gefühlte Temperatur / Taupunkt
- Wind / Windrichtung
- Luftdruck
- Gesamt-/Schichtbewölkung
- Sicht
- CAPE/LI/CIN und andere Zeitpunktdiagnosen, soweit das Quellprodukt sie instantan liefert.

Der sichtbare Wettercode darf für eine tatsächliche Niederschlagsphase durch die zum Slot gehörenden Niederschlagskomponenten plausibilisiert werden; trockene Slots behalten den instantanen Himmelszustand am Slotbeginn.

## 4. „Ab jetzt“ und 15-Minuten-Übergang

Ein Profil ab `now` darf kein vollständig vergangenes Niederschlagsintervall als Zukunft anzeigen.

- Das erste Intervall beginnt exakt bei `now`.
- Wo finalisierte 15-Minuten-Daten vorhanden sind, werden sie in **lückenlosen, nicht überlappenden** Vorwärtsintervallen verwendet.
- Danach wird bis zur nächsten vollen Stundenkante ein eventuelles Restintervall gebildet.
- Anschließend folgen volle Stundenintervalle.
- Der Übergang 15 min → 1 h darf **keinen Zeitraum doppelt zählen**.

Schneidet `now` einen sichtbaren Stunden-Slot, wird nur der noch zukünftige Anteil dieses Slots bilanziert. Das gilt für Mengen; die PoP bleibt die Eintrittswahrscheinlichkeit des ausgewiesenen Bezugsintervalls und ist **keine Regendauer**.

## 5. Appweite Darstellung

Der Slotbeginn-Vertrag gilt überall dort, wo MID einen Zeitstempel mit einer zukünftigen Niederschlagsangabe verknüpft, insbesondere:

- 90-Minuten-/Kurzfristansicht
- 24-h-Wetterprofil in 1-h- und 3-h-Auflösung
- Tagesdetails der 7-Tage-Ansicht
- 7-Tage-Kurvenübersicht und Skybar
- Tages-/Folgenacht-Piktogramme und Tagescharakter
- 14-Tage-/Ensemble-Best-Match-Fallbacks, soweit sie stündliche Best-Match-Daten verwenden
- Widgets und Exportvorschauen
- Meteogramm / erweiterte Modellansicht
- Wassersport-Stunden-/3-h-Matrix
- Berg-/Wintersport-Stundenfenster und stündliche Niederschlagssignale
- persönliche, zeitfensterbezogene Prognosehinweise.

Tageswerte aus einem echten Daily-Produkt bleiben Tageswerte. Werden Tageswerte aus Stunden abgeleitet, entscheidet der **sichtbare Slotbeginn** über die Tageszuordnung: der Rohwert `00:00` gehört als Intervall `23:00–00:00` zum Vortag; für den neuen Tag ist der Rohwert `01:00` der sichtbare Slot `00:00–01:00`.

## 6. Interne Meteorologie bleibt endgestempelt

Die UI-Normalisierung darf die physikalische Rechenbasis nicht verfälschen. Folgende Pfade arbeiten weiterhin mit den tatsächlichen Rohintervallen `[T−Δt,T]`:

- Radar-/NWP-Mengenblend und Nowcast-Verifikation
- hyperlokale Assimilation beobachteter Akkumulationen
- Rohdaten-/Providerdiagnostik
- Event-Engine, sofern sie die Intervallgrenzen explizit über Überlappung berechnet
- historische Verifikation / Wetterzwilling, sofern ein beobachtetes Referenzintervall verglichen wird.

Die Event-Engine ist deshalb kein Sonderfall gegen die Nutzerlogik: intern überlappt sie korrekt rohe Endintervalle mit dem Eventzeitraum und zeigt anschließend das daraus berechnete **explizite Start–Ende-Intervall** an.

## 7. Radar versus NWP

Im direkten Radarhorizont besitzt die beobachtete/advectierte lokale Niederschlagslage Vorrang vor einer ungestützten deterministischen Modellmenge:

- Standorttreffer: Radar und Modell werden qualitäts-/leadtimeabhängig geblendet.
- Echo nur in unmittelbarer Umgebung, aber **kein Standorttreffer**: die PoP darf erhöht bleiben, die Standortmenge wird bei belastbarer lokaler Trockenstrecke deutlich gedämpft.
- belastbar trockene Radarstrecke: auch große NWP-Mengen >1 mm dürfen den Radar-Abgleich nicht umgehen.
- jenseits des direkten Nowcastfensters läuft das Gewicht weich zurück zum NWP; kein hartes Mengen-Capping.

**Eintrittswahrscheinlichkeit** und **Menge am Standort** bleiben getrennte Größen. MID berechnet insbesondere nicht `PoP × deterministische Menge` als angezeigte Niederschlagsmenge.

## 8. Tagesaggregation

Ab v0.9.85.285 bezeichnet `Day` stets den vollständigen lokalen Kalendertag von 00:00 bis zur nächsten lokalen Mitternacht (einschließlich echter 23-/25-Stunden-Tage). Bei lückenhafter Stundenreihe bleibt das gültige kanonische Tagesprodukt erhalten. Eine Stundenaggregation darf Tagesniederschlag, Wahrscheinlichkeit, Wettercode und Komponenten nur ersetzen, wenn jeder reale sichtbare Stunden-Slot und sein folgendes endgestempeltes Akkumulationssample vorhanden und gültig sind. Leere Strings, Booleans, nicht endliche oder negative Mengen und doppelte Rohendpunkte sind keine vollständige Abdeckung. Missing Data sind niemals eine trockene Stunde.

Eine ausdrücklich als **Resttagesmenge** bezeichnete Zukunftsmetrik darf weiterhin nur die zukünftigen Intervallanteile summieren: Ein von `now` angeschnittenes erstes Stundenintervall zählt dann anteilig. Sie darf den vollständigen Tageswert in Tageskarten, Widgets oder Exporten nicht ersetzen. Rollierende 90-min-/12-h-/24-h-Profile behalten ihre eigenen Zeitgrenzen; Temperatur-Minima/-Maxima bleiben vom Unterschied zwischen Tages- und Resttagesmenge getrennt.

## 9. Fehlende Anschlussstunde

Fehlt für einen sichtbaren Slot der unmittelbar folgende Rohwert oder liegt eine unplausible Zeitlücke vor, darf MID den vorherigen Niederschlag **nicht** einfach als Zukunft umetikettieren. Die Darstellung fällt für diesen Slot niederschlagsseitig sicher auf „kein belastbarer Slotwert“/0 zurück, während die instantanen Zustandsfelder erhalten bleiben. Damit ist ein falscher Zeitpunkt schlechter als ein transparent fehlender Randwert.

## 10. Regressionen

Verbindliche Regressionen:

- `scripts/test-precipitation-trailing-interval-nowcast-097810.mjs` – schützt die rohe endgestempelte Rechenbasis und Radar/NWP-Intervalle.
- `scripts/test-precipitation-forward-slot-presentation-097846.mjs` – schützt die vorwärts gerichtete Nutzersemantik und ihre appweite Verwendung.

## 11. Geometrie der sichtbaren Intervalle

Die fachlich richtige Slotzuordnung muss auch geometrisch sichtbar sein. Ein Niederschlagswert für `19:00–20:00` darf nicht um 19:00 zentriert und dadurch als `18:30–19:30` erscheinen.

Verbindlich gilt daher:

- Skybar-Segmente mit expliziten Zeitpositionen beginnen exakt am sichtbaren Slotstart `T` und enden an `T+Δ`.
- Stündliche Niederschlagsbalken liegen vollständig innerhalb desselben Stundenfensters.
- Niederschlagswahrscheinlichkeit bleibt fachlich eine Intervallgröße. Für die Darstellung darf die Linie ab v0.9.80.6 **monoton geglättet** durch die Mittelpunkte der zugehörigen Vorwärtsslots geführt werden. Die Glättung ist ausschließlich eine visuelle Führung; Prozentwert, Auswahl/Tooltip und Intervallbeschriftung bleiben dem vollständigen Bezugsfenster `[S,S+Δ]` zugeordnet. Ein generischer Spline mit Überschwingen oder eine Umdeutung zu sub-stündlichen Wahrscheinlichkeiten ist unzulässig.
- Die 24-h-Tagesachse reserviert die rechte Kante für 24:00; der 23:00-Punkt liegt am Beginn des letzten Slots 23:00–24:00.
- Instantane Größen bleiben auf ihrer Zeitmarke; Akkumulations-/Wahrscheinlichkeitsfelder verwenden die Vorwärtsintervall-Geometrie.

## v0.9.85.211: Kurzfristtext und Stunden-/Viertelstundenintervall

Die erste im Kurzfristtext genannte Niederschlagsphase leitet sich aus denselben vorwärtsgerichteten Intervallen wie das Wetterprofil ab. Die Zeitangabe bezeichnet precipitationIntervalStartEpoch und niemals die Endezeit der Stundenakkumulation. Innerhalb der ersten betroffenen Profilstunde wird nach Möglichkeit der erste nasse native 15-Minuten-Zeitschritt als genauerer Niederschlagsbeginn verwendet. Eine hohe Niederschlagswahrscheinlichkeit bei gemessenen/modellierten 0 mm genügt nicht als alleinige Grundlage für die Aussage eines tatsächlichen Niederschlagsbeginns. WMO-Phasencodes bleiben unabhängig vom zeitlichen Display-Vertrag eindeutig.
