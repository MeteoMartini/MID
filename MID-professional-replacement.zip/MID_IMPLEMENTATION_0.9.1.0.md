# MID v0.9.1.0 – multiparametrische Frontdiagnostik und korrigierte Windvektoren

## Ausgangsbasis

Verbindliche Basis war `mid-stable` v0.9.0.2. Vor der Änderung wurden `package.json` und `MID_BASELINE.json` geprüft.

## Umsetzung

### Vollständige Frontdiagnostik

Die objektive Frontklassifikation verwendet jetzt gemeinsam und erklärbar neun Diagnosegruppen:

1. Temperaturgradient am Boden und in 850 hPa
2. Taupunkt-/Feuchtegradient am Boden und in 850 hPa
3. Druckrinne im MSLP-Feld
4. Winddrehung über das Frontfenster
5. frontquerende 850-hPa-Strömung
6. Niederschlagsstützung
7. Wolkenband aus Gesamt-, tiefer, mittlerer und hoher Bewölkung
8. Temperaturänderung Vorher–Nachher
9. Böenänderung Vorher–Nachher

Zusätzlich werden verfügbare 700-hPa-Feuchte-/Windfelder, Geopotential und integrierter Wasserdampf als erweitertes Feldpaket angefordert. Nicht unterstützte optionale Felder lösen einen kontrollierten abgestuften Fallback aus.

Ein Frontkandidat wird nur ausgegeben, wenn genügend Signalgruppen und meteorologische Familien gemeinsam tragen. Einzelparameter können keinen Fronttyp mehr allein erzeugen. Der Frontscore wird nicht mehr leicht auf 100 gesättigt und berücksichtigt Feldabdeckung, Kohärenz und Widersprüche.

### Konfliktfeste Multimodellbewertung

DWD ICON-EU, ECMWF IFS und NOAA GFS werden als vollständige Ereignisbündel verglichen. Widersprechen sich ähnlich starke Modellcluster beim Fronttyp, weist MID einen Fronttyp-Konflikt aus. In diesem Fall werden weder ein künstlicher Mehrheitsfronttyp noch ein gemittelter Frontzeitpunkt behauptet. Beobachtungs- und Radarassimilation bleiben bis zur Auflösung des Konflikts deaktiviert.

### Erklärbare Darstellung

Unter der Karte zeigt eine kompakte Evidenzmatrix alle neun Diagnosegruppen mit:

- Mess-/Diagnosewert
- Stützungsgrad
- fehlendem Feld
- widersprechendem Signal
- Modellclusterstatus

Dominante Modellfronten werden kräftig dargestellt; alternative oder isolierte Kandidaten erscheinen reduziert und gestrichelt. Der Kartenstatus benennt kohärenten Cluster, eingeschränkte Lage oder Fronttyp-Konflikt.

### Windvektoren

Der 180°-Fehler der Stationsvektoren wurde behoben. Die meteorologische Herkunftsrichtung wird einmalig in die Strömungsrichtung umgerechnet. Der Stationsvektor besitzt bei 0° nun eine nach Norden gerichtete Grundachse, dreht um den Stationskern und erhält eine eindeutige Pfeilspitze. Tooltip und Phasendarstellung nennen weiterhin getrennt „Wind aus …“ und „Strömung nach …“.

## Responsive Gestaltung

Die Evidenzmatrix verwendet drei Spalten auf breiten Displays, zwei auf Tablets und eine Spalte auf sehr schmalen Geräten. Kartenstatus, Konflikthinweis, Modellspuren und Windvektoren bleiben ohne horizontalen Überlauf lesbar.

## Regression

Neu hinzugefügt: `scripts/test-synoptic-multiparameter-0910.mjs`.

Der Test schützt:

- alle neun Diagnosegruppen
- Druckniveau- und Oberflächenfelder
- konfliktfeste Warm-/Kaltfrontbewertung
- Dominant-/Alternativcluster
- Frontquerung der 850-hPa-Strömung
- korrekte Stationsvektorachse und Pfeilspitze
- responsive Evidenzdarstellung
