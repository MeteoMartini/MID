# MID – bedarfsgerechte Agenten- und Plugin-Nutzung (07.11.2026)

**Verbindlicher ergänzender Arbeitsvertrag zu `AGENTS.md`, nach erfolgter regulärer Stable-Promotion maßgeblich.** Der Stand vom 07.11.2026 ist Entstehungshistorie, keine gegenwärtige SHA-, Versions- oder Aktivitätsbehauptung. Vor jedem Auftrag die aktuellen Refs/Verträge und Berechtigungen neu verifizieren. Dieser Vertrag erweitert keine Rechte und ersetzt weder Nutzerentscheidungen noch strengere MID-Sicherheits- und Release-Gates.

## 1. Grundsatz: ChatGPT wählt die kleinste sichere, belegbar wirksame Unterstützung

**Automatisch nach Bedarf** bedeutet: Innerhalb eines **konkret vom Nutzer autorisierten MID-Auftrags** darf ChatGPT selbstständig geeignete bereits verbundene Plugins/Agenten als Werkzeuge auswählen, lesende Abfragen und freigegebene begrenzte Handoffs initiieren, Ergebnisse selbst in GitHub abholen, unabhängig prüfen und den nächsten sicheren Teilschritt ausführen. Der Nutzer muss weder Prompts noch Patches zwischen GitHub/Copilot/Kilo/ChatGPT kopieren noch reine technische Routineentscheidungen erneut bestätigen.

**Dynamische Vollständigkeitsprüfung, selektive Ausführung:** Vor der Werkzeugwahl alle **aktuell installierten** Plugins einschließlich enthaltener Skills und Apps als potenzielle Kandidaten berücksichtigen – ohne dass der Nutzer `@` angeben muss. Fachlich geeignete Werkzeuge nur nach Prüfung der aktuellen Verbindung, Aktivierung, Berechtigung, Datenfreigabe, Kosten-/Creditlage und vorhandenen parallelen Arbeiten wirklich verwenden. Die untenstehende Zuordnung enthält Beispiele und Rollen-Grenzen, **keine abschließende Allowlist**. Bereits installierte, aber hier nicht namentlich aufgeführte Plugins sind nicht pauschal ausgeschlossen. Unpassende Plugins nicht aufrufen, redundante Abfragen vermeiden, unabhängige sinnvolle Quellen nur bei Mehrwert kombinieren. Nicht installierte oder nicht verbundene Plugins werden nicht als verfügbar behauptet. Tatsächlich benutzte Tools und ausstehende Prüfungen knapp dokumentieren.

Das ist **keine** Ermächtigung zu autonomen neuen Produktentscheidungen, unbestellten Folgeaufträgen, unspezifischem Creditverbrauch, neuen Abonnements/Anbietern/Schlüsseln, Rechteausweitungen, Sicherheits- und Branchschutzänderungen, Releases oder Gateumgehungen. Benutzerpflichtige Anmeldung/OAuth- und privilegierte Zustimmung verbleiben beim Nutzer; vorhandene Runtime-Freigaben sind zu beachten.

### Obligatorisches Preflight je Auftrag

- GitHub `MeteoMartini/MID` ist alleinige Code-Source-of-Truth. `main`/`mid-stable` vollständige SHAs vergleichen; released Version und Spiegel in `package.json`, `MID_BASELINE.json`, `MID_SOURCE_OF_TRUTH.md`, `contracts/index.json` und betroffene Verträge abgleichen.
- `AGENTS.md`, `.github/copilot-instructions.md`, `.kilo/skills/mid-handoff/SKILL.md` (falls Kilo relevant), Rechte/Rulesets, parallele Issues/PRs/Branches/Works und noch nicht veröffentlichte Kandidaten prüfen. Bei Drift, unklarer Provenienz, ungeklärtem Überschneidungs-/Kosten-/Rechterisiko: **fail-closed**.
- Ziel, konkreten Teilauftrag, erlaubte Dateipfade, Ausschlüsse, Fach-/meteorologische Quellen und Akzeptanztests festlegen. Einen verantwortlichen Integrationsträger bestimmen, unnötige parallele Agentenaufträge und doppelte Arbeit vermeiden.
- Vor Verwendung: prüfen, ob benötigtes Plugin **tatsächlich verbunden, verfügbar, berechtigt und für den Daten-/Arbeitsbereich geeignet** ist. Bei fehlendem Werkzeug nichts vortäuschen; auf einen nachweisbar verfügbaren sicheren Weg wechseln oder konkreten Blocker nennen.

## 2. Bedarfsgerechtes Tool-Routing

| Art der Arbeit | Bevorzugter Dienst / Modus | Beschränkung und Abnahme |
|---|---|---|
| Stabile SHAs, Code/Diffs, Issues, PRs, CI/Gates, Releases | **GitHub** direkt durch ChatGPT | Quellwahrheit und Belege aus GitHub; keine manuellen Hauptbranchschreibaktionen |
| Kleine Analyse, Priorisierung, Review, Integrationsentscheidung | **ChatGPT** unmittelbar; GitHub lesen | Externe Agenten nur bei messbarem Mehrwert, nicht reflexartig |
| Eng begrenzte technische Prüfung oder Implementierung | **GitHub Copilot** via ChatGPT→GitHub-Issue→`copilot-swe-agent[bot]` | Nur ausdrücklich beauftragte Aufgaben; GitHub erstellt untrusted `copilot/*` Draft; Rückgabe per GitHub, unabhängige QA, keine Releaseberechtigung; Credits beachten |
| Eng begrenztes **lesendes** Code-/Fachaudit | **Kilo for GitHub** via ChatGPT-Issue und genau einem `@kilocode-bot`-Kommentar | Nur nach verifizierter Kontoverknüpfung und Credit-/Rechteprüfung; Antwort als GitHub-Issue-Kommentar; **keine** Dateien, Branches oder PRs erzeugen |
| **Kilo-Implementierung** auf userbeauftragtem Kilo-Cloud-Arbeitsstand | **Kilo Cloud** und bestehender `scripts/mid-kilo-handoff.mjs` | Ausschließlich SHA-geprüfter lokaler Commit → Dry-run → **einmaliger ref-freier Git-Objekt/Issue-Transport**; unabhängig verifizierter Draft-Intake; nicht via Kilo-GitHub-Fix-PR |
| UI/UX, responsive Quellarbeit | **Replit** nur nach ChatGPT-Auftrag und SHA-/Workspace-/Identitätsprüfung | Nur `replit/*`-Handoff; niemals Worker, Governance, Hauptbranches, Produktion oder eigenständige Produktentscheidungen |
| UX-Flow-Audit, Varianten- und Ergonomiebewertung | **Product Design** bei geeigneter, tatsächlich verfügbarer Fähigkeit | Reale Screenshots/Interaktionen zuerst; Prototyp ≠ implementierter oder real-iOS-abgenommener Code |
| Neue/aktuelle Frameworks, SDKs, Breaking Changes und API-Kompatibilität | **Context7** | Dokumentation/Versionsevidenz, **niemals** Code- oder Release-Source-of-Truth |
| Wetter-/Modell-/Daten-APIs, amtliche Quellen, Lizenz-/Wettbewerbsrecherche | **Firecrawl** und amtliche Primärquellen | Kosten/Credits, Quoten, Quellenrecht, Datenprovenienz; keine Wetterwerte ohne Einheiten/Lauf-/Gültigkeitszeit-/Coverage-Prüfung |
| Nutzungs-, Performance- und Fehlerdaten | **PostHog** nur wenn datenschutzkonform und freigegeben/verbunden | Nur notwendige aggregierte Telemetrie; Einwilligung/Opt-in und Qualität der Instrumentierung prüfen; Rohereignisse ≠ wissenschaftliche Nachweise |
| PR Review, CI-Konflikttriage, Regressionsevidenz | **PR Completion**, sofern verfügbar/autorisiert | Hilfsprüfung; **niemals** dessen generisches Mergeverfahren statt des MID-SHA-Release-Bots |
| Editierbare Designs / Design-System-Layer | **Figma**, wenn angefordert und Zugriffsrechte passen | Nur Designartefakte, keine ungesicherte Code-/Releaseintegration |
| Cloudflare Workers, Pages, R2 und produktive Laufzeitdiagnose | **Cloudflare**, falls verbunden und erforderlich | Nur redigierte, lesende Laufzeitdiagnose mit Least Privilege; **keine** Daten-, Konfigurations-, Cache-, Deployment- oder Secrets-Mutationen. GitHub bleibt Code-/Release-Source-of-Truth |
| Zusätzliche eng begrenzte PR-/QA-Triage | **PR Readiness** oder andere installierte Prüftools, sofern nachweisbar verfügbar | Beratung/Prüfung, niemals Umgehung des MID-Source-/Review-/Release-Gates |
| Sonstige installierte Plugins und neue fachlich passende Werkzeuge | Dynamische Eignungsprüfung statt fester Positivliste | Fachlicher Nutzen, aktuelle Verbindung/Rechte, Datenschutz, Kosten, Nichtüberschneidung und Nutzerauftrag zwingend |

**Weitere Apps:** Nur wenn die konkrete Aufgabe einen fachlichen Mehrwert verspricht und Verfügbarkeit, Rechte, Datenschutz und Kosten geprüft sind. Nicht benötigte Plugins **nicht** nur der Vollständigkeit halber aufrufen; Firecrawl/Context7 nicht für statische Repo-Fakten, PostHog nicht für Bugfix-Tests ohne verwertbare Telemetrie.

## 3. Entscheidungshierarchie: Ergebnisqualität je Aufwand

1. **Direkter Repo-Readback oder vorhandener Test** genügt? Dann keinen externen Agenten beauftragen.
2. **Eine** klar abgegrenzte, delegierbare Aufgabe, deren Ergebnis durch GitHub unabhängig prüfbar ist? Dann geeigneten Copilot- oder ausschließlich lesenden Kilo-GitHub-Agent mit engstem Scope verwenden; bei Benutzerauftrag ist der technische Handoff bereits enthalten, **keine Copy/Paste- oder wiederholte Routinezustimmung** nötig.
3. **Implementierung in einer bestehenden Kilo-Session**? Dort die schon freigegebene ref-freie Transportfunktion verwenden; nicht gleichzeitig Copilot mit denselben Dateien beauftragen. Für neues Kilo-Codearbeitsscope gelten die bereits vorgegebenen Kilo-Regeln, nicht der lesende GitHub-Trigger.
4. **UX-/Produktziel**? Erst gemeinsam mit dem Nutzer festgelegten Scope sichern; Replit/Product Design nur für definierte Design-/Responsive-Teile einsetzen. Ohne Rechte oder geklärte Ausgangs-Shas kein Schreibauftrag.
5. **Mehrere unabhängige, überwiegend lesende Prüfungen** dürfen parallel und kostenbewusst erfolgen; schreibende/überlappende Aufgaben nach Fachabhängigkeit und SHA-Reihenfolge serialisieren. Keine doppelten Tickets, kein automatisches Retry nach unklarer API-Antwort und keine Credit-intensive Auditschleife ohne neue Evidenz.
6. Nach jeder Rückgabe untrusted Artefakte (Issue, Draft, Git Objects, Tests, Screenshots, Rohdaten) gegen Originalquelle, exakte SHAs, Scope, Einheiten/Zeit/Feld-/Coverage-Semantik, WMO/DWD-Verträge und aktuelle Stable-Basis unabhängig kontrollieren. Bei unzureichender Evidenz **NOT VERIFIED**.

## 4. Rechte-, Kosten- und Release-Trennung

- Alle Copilot-/Kilo-/Replit-Kandidaten bleiben **untrusted**. Nur ChatGPT/autorisiertes Integrationswerkzeug kann ausgewählte, unabhängig geprüfte Teile auf `chatgpt/*`/`codex/*` übernehmen.
- Nutzerentscheidungen zu Features, Abo/zusätzlichen Kosten, Rechteausweitungen und privilegierten Freigaben bleiben beim Nutzer. Bereits vorhandene Credits gezielt und nur für klaren Nutzen einsetzen; keinen neuen bezahlten Dienst ohne ausdrückliche Zustimmung einschalten.
- Nie Secrets ausgeben, breit berechtigte PATs erstellen, Authentifizierung umgehen, Regeln lockern, signierte Verträge manipulieren, Tests „grün“ behaupten ohne Lauf, Phantom-Release melden oder Produktionswarnungen aus eigenen Heuristiken erzeugen.
- **Release ausschließlich:** unabhängige vollständige SHA-/Diff-/Test-/Vertragsprüfung → autorisierter Source-PR → Source-PR-Gate → kontrollierter SHA-gebundener Merge → serverseitiges ZIP → `install-mid.yml` → betroffene Worker/Pages/Browser/iOS-Abnahmen → Stable-Promotion. Von Agenten erstellte Drafts dürfen nicht selbst diesen Prozess auslösen.

## 5. Monitoring / Automations – Live-Bestand ist maßgeblich

Monitoring und konkrete Agentenaufträge sind verschiedene Vorgänge. **Keine historische Liste mit einer festen Zahl aktiver Wachen oder früheren Zeitplänen als aktuellen Betriebszustand ausgeben.** Vor einer Aussage über aktive Automationen deren aktuellen Status und Konfiguration im zuständigen Task-System prüfen. Die beim ersten Entwurf vom 07.11.2026 beobachteten Wachen sind eine historische Momentaufnahme; einzelne davon können inzwischen deaktiviert oder ersetzt sein. Alte Beschreibungen oder frühere Erfolge berechtigen weder zur Reaktivierung noch zu einem neuen Monitoringauftrag. Bereits aktive Aufgaben nicht doppeln; bestehende Pausierungen respektieren. Aktive Wachen niemals ohne ausdrückliche Berechtigung und unabhängig nachgewiesenen gleichwertigen Ersatz deaktivieren oder stoppen. Jede Ersetzung erfordert **Ereignis- und Zeitplanabdeckung, tatsächliche Zustellung, Vollständigkeit, Sicherheit und Fehlersignale** mit sicherem, getrenntem Readback; bloß gleiche Cron-Ausdrücke reichen nicht.

## 6. Handoff-Dokumentation / historische Tests

- [Copilot Issue→Draft-Bridge](MID_COPILOT_CLOUD_BRIDGE_2026_11_07.md): erfolgreicher Pilot [#688](https://github.com/MeteoMartini/MID/issues/688) → [#689](https://github.com/MeteoMartini/MID/pull/689), Code-Draft ohne Releaseberechtigung.
- [Kilo read-only Issue→Kommentar-Bridge](MID_KILO_GITHUB_ISSUE_BRIDGE_2026_11_07.md): verifizierter Pilot [#692](https://github.com/MeteoMartini/MID/issues/692) mit `kilo-code-bot[bot]` (GitHub-ID `240665456`) und SHA-gebundener Antwort.
- [Kilo ref-free Coding Handoff](MID_KILO_DEFAULT_HANDOFF_CONTRACT_2026_11_05.md): separater früherer Pilot [#662](https://github.com/MeteoMartini/MID/issues/662) → [Draft #663](https://github.com/MeteoMartini/MID/pull/663).
- Etwaige technische Änderungen an Freigaben, GitHub-Rulesets, CI, OAuth oder Cloud-Abrechnung sind **nicht** Bestandteil dieses Dokuments.

**Status:** Die auf `mid-stable` bereits freigegebene Vertragsfassung bleibt allein verbindlich. **Die Änderungen dieses PR sind ein noch nicht freigegebener Integrationskandidat** und werden erst nach vollständig erfolgreichem Source-/Installer-/Worker-/Pages-/Stable-Releasepfad verbindlich. Historische Pilot-/Commit-Beispiele sind ausdrücklich **keine** aktuellen Release-, Automations- oder Verbindungsnachweise.