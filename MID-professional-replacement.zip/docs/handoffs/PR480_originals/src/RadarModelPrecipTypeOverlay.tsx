import {useEffect,useMemo,useState} from 'react';
import {HtmlMarker} from './MapLibreCore';
import type {OperaRasterFrame} from './CompositeData';
import {loadOperaRasterData,operaRasterPoint,type OperaRaster} from './OperaRasterSource';
import {loadWeatherPhaseGrid,type WeatherPhaseGridData,type WeatherPhaseGridFrame} from './WeatherMapsData';
import type {RadarPhase} from './radarColorTables';
import {precipitationTypeSymbolSvg,type PrecipitationSymbolPhase} from './precipitationTypeSymbols';
import {synopPrecipitationSymbolSvg,synopPrecipitationPhase} from './synopPrecipitationSymbols';

export type RadarModelPhaseStatus='idle'|'loading'|'ready'|'error';
type OverlayPhase=RadarPhase|'hail'|'graupel'|'graupel-hail'|'snow-grains'|'snow-stars'|'ice-crystals'|'ice-pellets';
type PhaseResult={phase:OverlayPhase;label:string;confidence:'hoch'|'mittel'|'eingeschränkt';modelEvidence:boolean};
type EchoSummary={covered:boolean;hits:number;maxDbz:number;meanDbz:number;maxRate:number};
type SymbolPhase=PrecipitationSymbolPhase;
type PhaseSymbol={id:string;lat:number;lon:number;phase:SymbolPhase;label:string;dbz:number;ww?:number};

function finite(value:unknown){if(value==null||typeof value==='boolean'||(typeof value==='string'&&!value.trim()))return NaN;const number=Number(value);return Number.isFinite(number)?number:NaN}
function wetBulbStull(t:number,rh:number){if(!Number.isFinite(t)||!Number.isFinite(rh))return NaN;const humidity=Math.max(1,Math.min(100,rh));return t*Math.atan(.151977*Math.sqrt(humidity+8.313659))+Math.atan(t+humidity)-Math.atan(humidity-1.676331)+.00391838*Math.pow(humidity,1.5)*Math.atan(.023101*humidity)-4.686035}
function coldSupport(temperature:number,wetBulb:number){return(Number.isFinite(wetBulb)&&wetBulb<=.8)||(Number.isFinite(temperature)&&temperature<=1.8)}

function phaseFor(frame:WeatherPhaseGridFrame,index:number):PhaseResult{
 const code=Math.round(finite(frame.weatherCode[index])||0),temperature=finite(frame.temperature2m[index]),humidity=finite(frame.relativeHumidity2m[index]),directWetBulb=finite(frame.wetBulbTemperature2m[index]),wetBulb=Number.isFinite(directWetBulb)?directWetBulb:wetBulbStull(temperature,humidity),precipitation=Math.max(0,finite(frame.precipitation[index])||0),rain=Math.max(0,finite(frame.rain[index])||0),showers=Math.max(0,finite(frame.showers[index])||0),snowfall=Math.max(0,finite(frame.snowfall[index])||0),rucRain=Math.max(0,finite(frame.rucRain?.[index])||0),rucSnow=Math.max(0,finite(frame.rucSnowfallWaterEquivalent?.[index])||0),rucGraupel=Math.max(0,finite(frame.graupelWaterEquivalent?.[index])||0),snowfallHeight=finite(frame.snowfallHeight[index]),freezingLevel=finite(frame.freezingLevelHeight[index]),elevation=finite(frame.elevation[index]),explicitFreezing=[56,57,66,67].includes(code),explicitSnow=[71,73,75,85,86].includes(code),explicitIceCrystals=code===76,explicitSnowGrains=code===77,explicitSnowStars=code===78,explicitIcePellets=code===79,explicitMixed=[68,69,83,84].includes(code),explicitGraupel=[87,88].includes(code),explicitHail=[89,90].includes(code),explicitGraupelHail=[96,99].includes(code),explicitThunderPrecip=[95,97].includes(code),explicitWintryAfterThunder=[93,94].includes(code),explicitRain=[51,53,55,61,63,65,80,81,82,91,92].includes(code),liquid=rain+showers,snowLevelSupports=Number.isFinite(snowfallHeight)&&Number.isFinite(elevation)&&snowfallHeight<=elevation+220,liquidLevelSupports=Number.isFinite(snowfallHeight)&&Number.isFinite(elevation)&&snowfallHeight>=elevation+320,freezeSupports=Number.isFinite(freezingLevel)&&Number.isFinite(elevation)&&freezingLevel<=elevation+280,rucEvidence=rucRain>=.003||rucSnow>=.003||rucGraupel>=.003,coldEnough=coldSupport(temperature,wetBulb),modelEvidence=precipitation>=.003||liquid>=.003||snowfall>=.003||rucEvidence||explicitFreezing||explicitSnow||explicitIceCrystals||explicitSnowGrains||explicitSnowStars||explicitIcePellets||explicitMixed||explicitGraupel||explicitHail||explicitGraupelHail||explicitThunderPrecip||explicitWintryAfterThunder||explicitRain;
 if(explicitGraupelHail)return{phase:'graupel-hail',label:'Graupel oder Hagel',confidence:'hoch',modelEvidence};
 if(explicitHail)return{phase:'hail',label:'Hagel',confidence:'hoch',modelEvidence};
 if(explicitGraupel)return{phase:'graupel',label:'Graupel',confidence:'hoch',modelEvidence};
 if(rucGraupel>=.003&&rucGraupel>=Math.max(rucRain*.65,rucSnow*.8))return{phase:'graupel',label:'Graupel · ICON-D2-RUC',confidence:'hoch',modelEvidence};
 if(rucSnow>=.003&&rucRain>=.003)return{phase:'mixed',label:'Mischphase · ICON-D2-RUC',confidence:'hoch',modelEvidence};
 if(rucSnow>=.003){if(((Number.isFinite(wetBulb)&&wetBulb<=1.2)||snowLevelSupports)&&coldEnough)return{phase:'snow',label:'Schnee · ICON-D2-RUC',confidence:'hoch',modelEvidence};return{phase:'mixed',label:'Mischphase · ICON-D2-RUC',confidence:'mittel',modelEvidence}}
 if(rucRain>=.003){if(coldEnough&&((Number.isFinite(wetBulb)&&wetBulb<=-.25)||(freezeSupports&&Number.isFinite(temperature)&&temperature<=1.2)))return{phase:'freezing',label:'gefrierende Phase möglich · ICON-D2-RUC',confidence:'mittel',modelEvidence};return{phase:'rain',label:'Regen · ICON-D2-RUC',confidence:'hoch',modelEvidence}}
 if(explicitFreezing&&coldEnough)return{phase:'freezing',label:'gefrierender Niederschlag',confidence:Number.isFinite(wetBulb)&&wetBulb<=.8?'hoch':'mittel',modelEvidence};
 if(explicitMixed||(snowfall>=.003&&liquid>=.003))return{phase:'mixed',label:'Schneeregen / Mischphase',confidence:'hoch',modelEvidence};
 if(explicitIceCrystals)return{phase:'ice-crystals',label:'Eisnadeln',confidence:'hoch',modelEvidence};
 if(explicitSnowGrains)return{phase:'snow-grains',label:'Schneegriesel',confidence:'hoch',modelEvidence};
 if(explicitSnowStars)return{phase:'snow-stars',label:'Vereinzelte Schneesterne',confidence:'hoch',modelEvidence};
 if(explicitIcePellets)return{phase:'ice-pellets',label:'Eiskörner',confidence:'hoch',modelEvidence};
 if(explicitSnow||snowfall>=.003){if(coldEnough&&((Number.isFinite(wetBulb)&&wetBulb<=.9)||snowLevelSupports))return{phase:'snow',label:'Schnee',confidence:explicitSnow?'hoch':'mittel',modelEvidence};if(Number.isFinite(wetBulb)&&wetBulb<=1.7)return{phase:'mixed',label:'Mischphase möglich',confidence:'mittel',modelEvidence}}
 if(explicitRain||explicitThunderPrecip||liquid>=.003){if((Number.isFinite(wetBulb)&&wetBulb>=1.3)||liquidLevelSupports)return{phase:'rain',label:'Regen',confidence:explicitRain?'hoch':'mittel',modelEvidence};if(Number.isFinite(wetBulb)&&wetBulb>=.1&&wetBulb<1.3)return{phase:'mixed',label:'Mischphase möglich',confidence:'eingeschränkt',modelEvidence}}
 if(modelEvidence&&Number.isFinite(wetBulb)){
  if(coldEnough&&wetBulb<=.1&&snowLevelSupports&&precipitation>=.05)return{phase:'graupel',label:'Graupel möglich',confidence:'mittel',modelEvidence};
  if(coldEnough&&wetBulb<=.35&&snowLevelSupports)return{phase:'snow',label:'Schneephase wahrscheinlich',confidence:'mittel',modelEvidence};
  if(wetBulb>=1.7&&!freezeSupports)return{phase:'rain',label:'flüssige Phase wahrscheinlich',confidence:'mittel',modelEvidence}
 }
 return{phase:'uncertain',label:'Phase nicht belastbar bestimmbar',confidence:'eingeschränkt',modelEvidence};
}

function cellEchoSummary(raster:OperaRaster,south:number,north:number,west:number,east:number,samplesPerAxis=3):EchoSummary{
 let hits=0,maxDbz=NaN,sumDbz=0,maxRate=0;
 for(let row=0;row<samplesPerAxis;row++)for(let col=0;col<samplesPerAxis;col++){
  const lat=south+((row+.5)/samplesPerAxis)*(north-south),lon=west+((col+.5)/samplesPerAxis)*(east-west),echo=operaRasterPoint(raster,lat,lon);
  if(!echo.covered||!Number.isFinite(echo.dbz))continue;const dbz=Number(echo.dbz),rate=Math.max(0,Number(echo.rate)||0);hits++;sumDbz+=dbz;maxDbz=Number.isFinite(maxDbz)?Math.max(maxDbz,dbz):dbz;maxRate=Math.max(maxRate,rate)
 }
 return{covered:hits>0,hits,maxDbz:Number.isFinite(maxDbz)?maxDbz:NaN,meanDbz:hits?sumDbz/hits:NaN,maxRate};
}

function radarBackedThermalPhase(base:PhaseResult,frame:WeatherPhaseGridFrame,index:number,echo:EchoSummary):PhaseResult{
 if((base.phase!=='uncertain'&&base.confidence!=='eingeschränkt')||!echo.covered||!Number.isFinite(echo.maxDbz)||echo.maxDbz<7)return base;
 const temperature=finite(frame.temperature2m[index]),humidity=finite(frame.relativeHumidity2m[index]),directWetBulb=finite(frame.wetBulbTemperature2m[index]),wetBulb=Number.isFinite(directWetBulb)?directWetBulb:wetBulbStull(temperature,humidity),snowfallHeight=finite(frame.snowfallHeight[index]),elevation=finite(frame.elevation[index]);
 if(Number.isFinite(wetBulb)&&wetBulb>=2)return{phase:'rain',label:'Regen · Radar + thermische Phase',confidence:'mittel',modelEvidence:true};
 if(Number.isFinite(wetBulb)&&wetBulb<=-.7&&echo.maxDbz>=17)return{phase:'graupel',label:'Graupel · Radar + thermische Phase',confidence:'mittel',modelEvidence:true};
 if(Number.isFinite(wetBulb)&&wetBulb<=-.4&&Number.isFinite(snowfallHeight)&&Number.isFinite(elevation)&&snowfallHeight<=elevation+250)return{phase:'snow',label:'Schnee · Radar + thermische Phase',confidence:'mittel',modelEvidence:true};
 return base;
}

function distanceKm(a:PhaseSymbol,b:PhaseSymbol){const latKm=(a.lat-b.lat)*111.2,lonKm=(a.lon-b.lon)*111.2*Math.max(.3,Math.cos((a.lat+b.lat)*Math.PI/360));return Math.hypot(latKm,lonKm)}
function phaseMinimumDbz(phase:SymbolPhase){return phase==='hail'?15:phase==='graupel-hail'?12:phase==='graupel'?9:['snow-grains','snow-stars','ice-crystals','ice-pellets'].includes(phase)?4:(phase==='freezing'?9:phase==='snow'?6:7)}
function asSymbolPhase(phase:OverlayPhase):SymbolPhase|null{return['mixed','snow','snow-grains','snow-stars','ice-crystals','ice-pellets','freezing','hail','graupel','graupel-hail'].includes(phase)?phase as SymbolPhase:null}

function buildPhaseSymbols(data:WeatherPhaseGridData,raster:OperaRaster):PhaseSymbol[]{
 const frame=data.frame,latStep=data.lats.length>1?Math.abs(data.lats[1]-data.lats[0]):.05,lonStep=data.lons.length>1?Math.abs(data.lons[1]-data.lons[0]):.05,candidates:PhaseSymbol[]=[];
 for(let row=0;row<data.lats.length;row++)for(let col=0;col<data.lons.length;col++){
  const index=row*data.lons.length+col,lat=data.lats[row],lon=data.lons[col],echo=cellEchoSummary(raster,lat-latStep/2,lat+latStep/2,lon-lonStep/2,lon+lonStep/2,3);if(!echo.covered||!Number.isFinite(echo.maxDbz))continue;
  const temperature=finite(frame.temperature2m[index]),humidity=finite(frame.relativeHumidity2m[index]),directWetBulb=finite(frame.wetBulbTemperature2m[index]),wetBulb=Number.isFinite(directWetBulb)?directWetBulb:wetBulbStull(temperature,humidity),phase=radarBackedThermalPhase(phaseFor(frame,index),frame,index,echo),typed=asSymbolPhase(phase.phase);if(!typed||phase.confidence==='eingeschränkt')continue;
  if(typed==='freezing'&&(!coldSupport(temperature,wetBulb)||(Number.isFinite(temperature)&&temperature>2.5)||(Number.isFinite(wetBulb)&&wetBulb>.8)))continue;
  if((typed==='snow'||typed==='mixed')&&(Number.isFinite(temperature)&&temperature>4)&&(Number.isFinite(wetBulb)&&wetBulb>1.5))continue;
  if(echo.maxDbz<phaseMinimumDbz(typed))continue;
  const rawWw=finite(frame.weatherCode[index]),ww=Number.isInteger(rawWw)&&synopPrecipitationPhase(rawWw)===typed?rawWw:undefined;
  // Only matching explicit model weather codes carry a real WW number.
  // Thermodynamic/RUC/radar-derived phase estimates retain their inferred label.
  candidates.push({id:`${row}:${col}:${typed}`,lat,lon,phase:typed,label:`${phase.label} · ${Math.round(echo.maxDbz)} dBZ · ${data.modelLabel||'Regionalmodell'}${ww===undefined?'':` · Modell-Wettercode ww ${ww}`}`,dbz:echo.maxDbz,ww});
 }
 const selected:PhaseSymbol[]=[];
 for(const item of candidates.sort((a,b)=>b.dbz-a.dbz)){
  const spacing=item.phase==='hail'?18:item.phase==='graupel'||item.phase==='graupel-hail'?15:14;
  if(selected.some(existing=>distanceKm(existing,item)<spacing))continue;selected.push(item);if(selected.length>=90)break
 }
 return selected;
}

function phaseSummary(symbols:PhaseSymbol[]){
 const counts={mixed:0,snow:0,'snow-grains':0,'snow-stars':0,'ice-crystals':0,'ice-pellets':0,freezing:0,hail:0,graupel:0,'graupel-hail':0} as Record<SymbolPhase,number>;
 for(const item of symbols)counts[item.phase]++;
 const parts=[] as string[];
 if(counts.snow)parts.push(`${counts.snow}× Schnee`);
 if(counts['snow-grains'])parts.push(`${counts['snow-grains']}× Schneegriesel`);
 if(counts['snow-stars'])parts.push(`${counts['snow-stars']}× Schneesterne`);
 if(counts['ice-crystals'])parts.push(`${counts['ice-crystals']}× Eisnadeln`);
 if(counts['ice-pellets'])parts.push(`${counts['ice-pellets']}× Eiskörner`);
 if(counts.graupel)parts.push(`${counts.graupel}× Graupel`);
 if(counts['graupel-hail'])parts.push(`${counts['graupel-hail']}× Graupel/Hagel`);
 if(counts.hail)parts.push(`${counts.hail}× Hagel`);
 if(counts.mixed)parts.push(`${counts.mixed}× Mischphase`);
 if(counts.freezing)parts.push(`${counts.freezing}× gefrierend`);
 return parts.join(' · ');
}

function phaseRateLimit(message:string){return /(?:request|rate|minute|minutes|429).*limit|limit.*(?:request|rate|minute|minutes)|too many requests/i.test(message)}

export default function RadarModelPrecipTypeOverlay({latitude,longitude,targetTime,operaFrame,opacity=.9,onStatus}:{latitude:number;longitude:number;targetTime?:string;operaFrame?:OperaRasterFrame|null;opacity?:number;onStatus?:(status:RadarModelPhaseStatus,message?:string)=>void}){
 const[data,setData]=useState<WeatherPhaseGridData|null>(null),[raster,setRaster]=useState<OperaRaster|null>(null),[retryTick,setRetryTick]=useState(0);
 useEffect(()=>{const controller=new AbortController();let retryTimer:number|undefined;setData(null);setRaster(null);if(!operaFrame?.fileUrl){onStatus?.('error','OPERA-CIRRUS-Echomaske fehlt; die Niederschlagsart bleibt aus.');return()=>controller.abort()}const targetIso=targetTime||operaFrame.time,targetMs=Date.parse(targetIso),operaMs=Date.parse(operaFrame.time);if(!Number.isFinite(targetMs)||!Number.isFinite(operaMs)||Math.abs(targetMs-operaMs)>12*60000){onStatus?.('error','OPERA-CIRRUS liegt zeitlich zu weit vom gewählten Radarstand entfernt.');return()=>controller.abort()}onStatus?.('loading','OPERA-CIRRUS-Echomaske und Rapid-/Regionalmodell werden für die Symbolklassifikation geprüft.');Promise.all([loadWeatherPhaseGrid(latitude,longitude,targetIso,controller.signal),loadOperaRasterData(operaFrame.fileUrl,controller.signal)]).then(([grid,nextRaster])=>{if(controller.signal.aborted)return;if(grid.error)throw new Error(grid.error);const modelMs=Date.parse(grid.frame?.time||''),maxTimeDelta=grid.stale?45*60000:20*60000;if(!Number.isFinite(modelMs)||Math.abs(modelMs-targetMs)>maxTimeDelta)throw new Error('Kein ausreichend zeitnahes Rapid-/Regionalmodell-Phasenfeld.');if(Number.isFinite(Number(grid.modelAgeHours))&&Number(grid.modelAgeHours)>16)throw new Error('Der ausgewählte Modelllauf ist für eine belastbare Radarphase zu alt.');setData(grid);setRaster(nextRaster)}).catch(error=>{if(controller.signal.aborted)return;const message=error instanceof Error?error.message:String(error);if(phaseRateLimit(message)){onStatus?.('error','Rapid-/Regionalmodell-Phasenfeld vorübergehend durch das Open-Meteo-Minutenlimit blockiert. Radar bleibt aktiv; automatischer neuer Versuch in etwa 60 s.');retryTimer=window.setTimeout(()=>setRetryTick(value=>value+1),65000)}else onStatus?.('error',message)});return()=>{controller.abort();if(retryTimer!==undefined)window.clearTimeout(retryTimer)}},[latitude,longitude,targetTime,operaFrame?.fileUrl,operaFrame?.time,onStatus,retryTick]);
 const symbols=useMemo(()=>data&&raster?buildPhaseSymbols(data,raster):[],[data,raster]);
 useEffect(()=>{if(!data||!raster)return;const staleNote=data.stale?' · Ersatzfeld wegen temporärem API-Limit':'';const source=`OPERA + ${data.modelLabel||'Regionalmodell'}${data.rapidUpdate?' · Rapid Update':''}`;if(symbols.length){onStatus?.('ready',`${source} · ${symbols.length} Symbole im aktuellen Ausschnitt · ${phaseSummary(symbols)}${staleNote}`);return}onStatus?.('ready',`${source} · Layer aktiv · aktuell keine festen/gemischten Niederschlagsarten im sichtbaren Ausschnitt${staleNote}`)},[data,raster,symbols,onStatus]);
 if(!symbols.length)return null;const safeOpacity=Math.max(.2,Math.min(1,opacity));return <>{symbols.map(item=><HtmlMarker key={item.id} latitude={item.lat} longitude={item.lon} anchor="center" className={`radar-phase-symbol radar-phase-${item.phase}`} zIndex={450} html={`<span class="radar-phase-symbol-shape" style="opacity:${safeOpacity.toFixed(2)}" title="${item.label.replace(/"/g,'&quot;')}">${item.ww===undefined?precipitationTypeSymbolSvg(item.phase):synopPrecipitationSymbolSvg(item.ww)??precipitationTypeSymbolSvg(item.phase)}</span>`}/>)}</>;
}