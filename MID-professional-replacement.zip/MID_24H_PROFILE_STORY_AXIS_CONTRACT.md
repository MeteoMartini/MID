## MID v0.9.85.417 · klare Wolken-/Sonnen-Klassifikation (03.11.2026)

Diese Präzisierung **ersetzt die ältere direkte Sonnenscheindauer-Priorität im Skybar-Grundband**: Bei bekannter Gesamtbewölkung ist die Dicke immer aus dem **Himmelszustand** abzuleiten. Ab 50 % Gesamtbewölkung Grau in vier Klassen; darunter bei Tageslicht Gelb aus dem unbedeckten Anteil (100 % minus Gesamtbewölkung), ausdrücklich als **Wolkenlücken** beschriftet, nicht als Sonnenscheindauer. Beispielsweise 45 % Bewölkung = 55 % Wolkenlücken = **Stufe 1/4**, auch wenn die separat vorliegende Sonnenscheindauer 100 % beträgt. Nur bei fehlender Bewölkung kann echte direkte Sonnenscheindauer als gekennzeichnetes Ersatzsignal gelten. Beide Werte werden unverändert mit Provenienz und Bezugszeit ausgewiesen. Stufen 50–<62,5 / 62,5–<75 / 75–<87,5 / 87,5–100 % und Dicke 2,4/3,6/4,8/6 bleiben unverändert. Keine Veränderung meteorologischer Rohwerte, Zeitachse, Tageslichtgrenzen, Niederschlagsphase/Intensität, NoData oder amtlicher Warnungen. Der gemeinsame Renderer gilt für 12h, 90min, Heute/24h, 7d/14d, Stundenquadrate und die Web-/Widget-/Exportkonsumenten. Wetterpiktogramme folgen weiterhin dem bereits finalisierten Wettercode und der Bewölkung; trocken/Schnee/Niederschlag nicht durch die Skybar überschreiben.

## MID-C37 · Tageslichtbezug der gelben Dickenstufen (v0.9.85.303)

Bei verifizierten solaren Intervallgrenzen wird für die relative gelbe Bandklassifikation die Sonnenscheindauer auf die innerhalb des ursprünglichen Slots astronomisch mögliche Tageslichtzeit bezogen, nicht auf dessen zusätzliche Nachtminuten. Das ersetzt ausschließlich den bisherigen Vollslot-Nenner im kontinuierlichen solaren Grundband. Roh-Sonnenminuten, ursprüngliche Akkumulationsintervalle, >50-%-Schwelle, vier Klassen, Bewölkungswerte und Niederschlagslagen bleiben unverändert. Die Beschreibung nennt ausdrücklich „% der möglichen Tageslichtzeit“. Überlappende Nachtintervalle werden nur einmal abgezogen; die Bezugszeit bleibt beim Viewport-Clipping diejenige des Originalslots. Ohne verifizierte Sonnenzeiten bleibt die bisherige Intervallklassifikation. Stundenquadrate bleiben diskrete Vollslots mit ihrem bestehenden Bezug und ihrer separat ausgewiesenen Klassenfarbe; sie behaupten keinen minutengenauen solaren Schnitt.

Vier Klassen sind keine Pflichtverteilung der Daten: Grau verwendet 50–<62,5 / 62,5–<75 / 75–<87,5 / 87,5–100 % Gesamtbewölkung. Das gelbe Band verwendet >50–<62,5 / 62,5–<75 / 75–<87,5 / 87,5–100 % der jeweils ausdrücklich genannten Sonnenschein-Bezugszeit bzw. des klar gekennzeichneten Wolkenlückenanteils. Dicken bleiben 2,4 / 3,6 / 4,8 / 6 SVG-Einheiten. Es wird keine Stufe erzwungen, interpoliert oder durch veränderte meteorologische Werte gefüllt. Graue Bewölkung bleibt auch nachts sichtbar; Gelb niemals innerhalb eines verifizierten Nachtintervalls. Der zusätzliche Anbieter-Fixoffset-/DST-Adapterfehler #428 ist damit nicht behoben.

## MID 18.2.35 · Exakte solare Übergänge im kontinuierlichen Skybar-Grundband (v0.9.85.278)

Bekannte Sonnenereignisse aus `solarTimelineWindow` trennen nun innerhalb bestehender Stunden-/Viertelstunden-Slots nur die astronomische Tag-/Nacht-Grundbandfarbe; graue Gesamtbewölkung bleibt grau, gelbe Wolkenlücken sind niemals direkt gemessene Sonnenscheindauer. Die Sonnenzeit modifiziert weder die vom Modell angebotenen Datenpunkte noch meteorologische Werte, Schwellen, akkumulierten Niederschlag, Zeit-/Phasenfarben oder Missing-Flags. Fehlende gültige Epochengrenzen erzwingen die bisherige Slotdarstellung statt Interpolation. Niederschlagsakkumulationen bleiben auf vorwärts normalisierten Intervallen; die momentane Wolkenbewertung liegt am `hour.epoch`. Exakte solare Minutenteilung gilt für kontinuierliche Linien, während optionale Stundenquadrate weiterhin diskrete vollständige Beobachtungs-/Prognoseslots darstellen.

# MID – 24-h-Wetterprofil: Story-Axis-Vertrag

## MID-C33 · kurze Sonnenscheindauer (.268)

Unter 50 % bekannter Gesamtbewölkung darf eine vorhandene Sonnenscheindauer von höchstens 50 % das Tagesgrundband nicht ausblenden. Stattdessen zeigt Gelb ausdrücklich die Wolkenlücken / den unbedeckten Himmelsanteil; die tatsächlich vorhandene Sonnenscheindauer bleibt separat im Titel erhalten. Dies ersetzt die ältere Beschränkung des Wolkenlücken-Fallbacks auf fehlende Sonnenscheindauer. Gerade in Sonnenauf-/Untergangsintervallen können kurze Sonnenscheindauer und weitgehend unbedeckter Himmel gleichzeitig korrekt sein. Ab 50 % bleibt Grau maßgeblich. Klare Nächte und echte Datenlücken bleiben zulässig; keine Sonnenscheindauer wird aus Bewölkung errechnet.

## Kontinuierliche Skybar ab v0.9.85.152

Der kontinuierliche Wetterstreifen nutzt die finalisierte Kurzfristreihe mit ihren tatsächlichen Viertelstundenintervallen und derselben Klassifikation wie die 90-min-Skybar. Danach folgen die verfügbaren Stundenintervalle. Keine vorherige Stundenmittelung der Bewölkung für diesen Streifen: sie kann über eine Farbschwelle hinweg einen abweichenden Himmelszustand erzeugen. Die gemeinsame Zeitabbildung bleibt verbindlich. Kurven, übrige Profilspuren und optionale Stundenquadrate bleiben stündlich. Dieser Abschnitt ersetzt ältere Aussagen einer ausschließlich stündlichen kontinuierlichen Skybar; die Stundenquadrat-Regeln bleiben bestehen.

## Zweck

Das 24-h-Wetterprofil erzählt den gesamten Verlauf auf genau einer gemeinsamen
Zeitachse. Wetterpiktogramme, Tages-/Nachtflächen, Sonnenereignisse,
Stundenraster, Messkurven, Wolkenbänder, Hazards und Auswahlcursor dürfen nicht
gegeneinander verschoben sein.

## Verbindliche Zeitgeometrie

- Das Fenster reicht gleitend von `jetzt` bis `+24 h`.
- `profileXForEpoch(epoch)` ist die einzige Abbildung von Zeit auf die
  horizontale Plotposition.
- Stundenpunkte, Sonnenauf- und -untergang verwenden diese Abbildung direkt.
- Wetterpiktogramme, Kurvenpunkte, Windpfeile und Zeitlabels verwenden die aus
  denselben Stundenpunkten abgeleitete X-Position.
- Das senkrechte Stundenraster und der aktive Auswahlcursor reichen vom oberen
  Wetterband bis einschließlich Hazards.
- Das Profil verwendet durchgehend die kanonische stündliche Darstellung; Zeitfenster und fachliche Werte bleiben unverändert.

## Temperatur und Extrema im 24-h-Fenster

- Die Temperaturkurve verwendet innerhalb des rollenden 24-h-Fensters immer die finale kanonische stündliche Reihe `displayHours`; eine zusätzliche Darstellungsauflösung existiert nicht.
- Derselbe Grundsatz gilt für gefühlte Temperatur, Taupunkt und Luftdruck: Sie bleiben an der kanonischen stündlichen Reihe und damit zeitlich konsistent zur Temperaturkurve. Intervallgrößen wie Niederschlagsakkumulationen bleiben davon unberührt.
- Das sichtbare Maximum und Minimum werden direkt aus genau diesen stündlichen
  Kurvenpunkten im rollenden 24-h-Fenster bestimmt. Damit sind beide Extrema
  unabhängig von Kalendergrenzen immer an einem tatsächlich gezeichneten Punkt
  verankert.
- Direkt an der Kurve steht ausschließlich der gerundete Wert, z. B. `21°` und
  `15°`; die Begriffe Tmax/Tmin werden nicht zusätzlich in die Grafik geschrieben.
- Die fachliche Tageskonsistenz bleibt separat bestehen: `displayDays` wird bei
  vollständiger Stundenabdeckung weiterhin aus den Extrema derselben finalen
  `displayHours` abgeleitet.
- Beide Extremmarken werden aus der vollständigen stündlichen Temperaturkurve bestimmt und bleiben deshalb an tatsächlich gezeichneten Stundenpunkten verankert.

## Wolken

- Die Reihenfolge bleibt von oben nach unten: Gesamt, H, M, L.
- **Gesamtbewölkung wird im 24-h-Profil nicht mehr als viertes graues Zellenband gezeichnet.** An dieser Stelle steht jetzt **ein einzelner, unterschiedlich breiter Wetterstreifen** mit derselben `detailSkyBarSegments`-Grundlogik wie in der Tagesansicht: tagsüber verläuft er je nach Sonne/Wolken gelb bis grau; klare Nacht darf aussetzen, nächtliche Bewölkung erscheint grau. **Sonne und Bewölkung bilden ein farbreines Grundband:** gelb und grau schließen sich gegenseitig aus. Niederschlag verwendet fachlich passende eigene Farben auch für Schnee-, Misch- und Gewitterphasen und wird als separate, zentrierte Lage über das Grundband gezeichnet. Es findet keine Farbmischung mit Gelb/Grau statt; ist der Grundstreifen breiter als die Niederschlagslage, bleibt er seitlich sichtbar. Alle Teilstücke sind gerundet, ohne 3D-Unterlage oder seitliche Überlappung. Die Strichdicke bildet die jeweilige Ausprägung in vier abgestuften Breiten ab.
- Die Gesamt-Leiste verwendet weiterhin exakt dieselbe X-Zeitgeometrie wie alle übrigen Profilparameter; im rollenden Profil werden dafür die bereits über `profileXForEpoch` bestimmten Stundenpositionen an den gemeinsamen Helfer übergeben.
- H, M und L bleiben darunter als schmale, kontinuierliche horizontale Graubänder erhalten. Für diese drei Ebenen steuert 0…100 % ausschließlich die Opazität von weiß/transparent bis grau.
- Nachbarstunden werden in den H/M/L-Verlauf einbezogen, sodass Übergänge weich ein- und ausfaden.
- Im Diagramm gibt es keine rechte 0–100-%-Achse und keine ausgewählten Prozentwerte am rechten Rand.
- Exakte Prozentwerte bleiben in den Einzeldaten und Tooltips erhalten.
- Wertepillen am aktiven Auswahlcursor verwenden einen leicht transparenten Tooltip-Hintergrund, damit Kurven, Bänder und Raster darunter sichtbar bleiben; Textkontrast und Parameterfarben bleiben unverändert.

## Luftdruck

- Luftdruck besitzt eine eigene hPa-Bahn mit dynamischem Wertebereich.
- Die Kurve muss in beiden Themes mit mindestens 1,55 px Strichstärke und nahezu
  voller Deckkraft sichtbar sein.
- Der aktive Wert darf rechts an der Luftdruckbahn stehen; dies ist keine
  Wolkenachse.

## Responsive Darstellung

- Hochformat behält Diagramm und Einzeldaten untereinander bei.
- Kompaktes Querformat stellt Diagramm und Einzeldaten als Master-/Detailansicht
  nebeneinander dar.
- Beide Orientierungen verwenden denselben React/Vite-Fachkern; es gibt keinen
  separaten iOS-Darstellungspfad.

## Tagesansichtsbasierte grafische Hierarchie ab v0.9.76.10

- Das Profil wird in der verfügbaren Breite gezeichnet; auf Mobilgeräten wird kein
  künstlich überbreites SVG mehr auf die Bildschirmbreite herunterskaliert.
- Temperatur, thermisches Empfinden, Niederschlag, Wind/Böen, Luftdruck,
  Wolken und Hazards verwenden dieselben vertikalen Stundenlinien.
- Achsen besitzen eine einheitliche linke Parameter-/Einheitenspalte und sparsame
  Skalenwerte; Wolken bleiben weiterhin ohne Prozentachse.
- Der Windbereich zeigt die kanonischen `DWD_WIND_THRESHOLDS_KMH` aus der
  Tagesansicht als dezente farbige Schwellenbänder und Schwellenlinien. Die
  Skala reicht mindestens bis zur ersten DWD-Böenwarnschwelle.
- Nachtstunden werden über alle grafischen Parameterbahnen hinweg gemeinsam
  abgedunkelt. Die Nachtmarkierung verändert weder Daten noch Zeitgeometrie.
- Sonnenaufgang und Sonnenuntergang werden mit ihren exakten Epochen über
  `profileXForEpoch(event.epoch)` dezent markiert.
- `JETZT` ist die linke Kante des rollenden Fensters; eine dezente vertikale
  Jetzt-Linie und eine zweite, geometrisch identische Zeitreferenz am unteren
  Rand erleichtern das senkrechte Lesen.
- Diese Darstellung gilt unverändert im gemeinsamen Browser/PWA/iOS-React-Kern.

- Die 7-Tage-Kurvenübersicht stellt Nachtstunden wieder als zusammenhängende, themegeeignete Hintergrundbereiche dar und zeigt denselben gerundeten, farbreinen Wetterstreifen auf gemeinsamer Zeitachse. Das zuvor ergänzte P25–P75-Band um die Temperaturkurve ist ersatzlos entfernt.


### Verbindlicher Skybar-Farb-/Dickenvertrag

- Sonnenschein ist gelb, Bewölkung grau. Niederschlag verwendet eine eigene **phasenabhängige, farbreine Overlay-Farbe**: Regen/Sprühregen/Schauer blau, Schnee/Eis hellblau, Misch-/gefrierende Phase violett, Gewitter/Graupel/Hagel purpur. Die Bedeutungen werden nicht über Mischfarben mit dem Grundband codiert.
- **Gesamtbewölkung und Sonnenscheindauer sind getrennte meteorologische Größen.** Ab **50 % Gesamtbewölkung** ist das Grundband grau. Unter 50 % Gesamtbewölkung verwendet das gelbe Grundband tagsüber eine **direkt verfügbare Sonnenscheindauer**. Fehlt die direkte Sonnenscheindauer, darf ersatzweise der unbedeckte Himmelsanteil `1 − Gesamtbewölkung` als **Wolkenlücken / unbedeckter Himmelsanteil** dargestellt werden.
- Gelb und Grau bleiben gegenseitig exklusiv. Der Wolkenlücken-Fallback ist ausdrücklich **keine Sonnenscheindauer**. Die WMO-definierte Sonnenscheindauer bleibt als eigener Strahlungsparameter erhalten und wird nie aus `100 % − Bewölkung` abgeleitet.
- Ist **Gesamtbewölkung unbekannt**, darf eine direkt verfügbare relative Sonnenscheindauer tagsüber ebenfalls das gelbe Grundband bilden. Fehlende Gesamtbewölkung oder Sonnenscheindauer darf nicht als 0 interpretiert werden.
- Das graue Bewölkungsband bildet 50–100 % Gesamtbewölkung in vier Dickenstufen ab. Das gelbe Band bildet direkte Sonnenscheindauer oder – nur bei fehlender Sonnenscheindauer – den ausdrücklich als solchen bezeichneten Wolkenlücken-Fallback in denselben vier Dickenstufen ab. Bewölkung verwendet appweit einen **einheitlichen Grauton**; die Ausprägung wird ausschließlich über die Dicke codiert.
- **Niederschlag ist eine eigenständige Overlay-Lage und darf auch bei Sonne auftreten.** Er wird nach dem Grundband gezeichnet, ist exakt auf derselben Mittellinie zentriert und verwendet die verbindliche Niederschlagsart/-phasenfarbe. Ist das gelbe Grundband breiter als der Niederschlagsstreifen, bleibt Gelb ober- und unterhalb sichtbar; ist der Niederschlagsstreifen gleich dick oder dicker, verdeckt er das gelbe Grundband vollständig. Es gibt keine Farbmischung.
- Die Niederschlagsdicke folgt **der jeweiligen Niederschlagsart** und wird auf das tatsächliche Zeitintervall normalisiert. Kontinuierlicher Regen verwendet die DWD-Klassen **leicht bis 0,5 mm/h**, **mäßig über 0,5 bis 4 mm/h** und **stark über 4 mm/h**; hierfür wird keine erfundene vierte Regenklasse erzeugt. Regenschauer dürfen die vierte Dicke verwenden, weil der DWD hierfür tatsächlich **leicht / mäßig / stark / sehr stark** anhand der 10-Minuten-Menge unterscheidet (`<0,4 / etwa 0,7–2 / 2–8 / >8 mm/10 min`); der kleine numerische Übergangsbereich zwischen 0,4 und 0,7 mm/10 min wird für die kontinuierliche Anzeige der mäßigen Stufe zugeordnet. Schnee und Schneeschauer werden nach Schneezuwachs (`≤0,5 / >0,5–4 / >4 cm/h`) klassifiziert; Sprühregen nutzt bevorzugt den WMO/DWD-Wettercode. Flüssige Spuren unter `0,05 mm` je dargestelltem Intervall beziehungsweise Schneespuren unter `0,05 cm` erzeugen keinen eigenen Streifen.
- Die Dickenstufen bleiben `2.4 / 3.6 / 4.8 / 6.0` SVG-Einheiten. Auch auf dem iPhone wird die Tageskarten-Skybar nicht auf 14 px Höhe verkleinert.
- Klare Nächte unter 50 % Bewölkung dürfen ohne Grundband bleiben. Ist tagsüber Gesamtbewölkung bekannt, entscheidet ab 50 % das graue Wolkenband; darunter hat eine direkt verfügbare Sonnenscheindauer Vorrang. Fehlt sie, darf der unbedeckte Himmelsanteil nur als klar benannter Wolkenlücken-Fallback erscheinen. Eine echte Datenlücke bleibt zulässig, wenn weder Gesamtbewölkung noch direkte Sonnenscheindauer noch Niederschlag verfügbar sind. Gerundete Segmente und fugenlose Verbindung gleichartiger Nachbarsegmente bleiben verbindlich.


## Regression

`scripts/test-weather-profile-story-axis-09750.mjs` schützt die gemeinsame
Zeitabbildung, die durchgehenden Vertikalen, die achsenlose Wolkendarstellung,
die sichtbare Luftdruckspur und die Hoch-/Querformatverträge.

`scripts/test-weather-profile-skybar-pills-097723.mjs` schützt zusätzlich den einzelnen Wetterstreifen für Sonne/Bewölkung/Niederschlag, den Erhalt von H/M/L, vier Dickenstufen, farbreine Grund-/Niederschlagslagen, gerundete Teilstücke, den Verzicht auf 3D-Unterlagen sowie die themegeeigneten Nachtstunden der 7-Tage-Kurvenübersicht und die ersatzlose Entfernung des dortigen P25–P75-Bands.

## Präzisierung v0.9.78.46 · Niederschlags-Slotbeginn

Die gemeinsame Zeitachse unterscheidet ab v0.9.78.46 strikt zwischen instantanen Zustandswerten und akkumulierten Niederschlagsfeldern. Ein sichtbares Stundenlabel `S` steht für den Niederschlag im vorwärts gerichteten Slot `[S,S+1 h]`; Open-Meteo-/DWD-Rohakkumulationen bleiben intern am Intervallende. Temperatur, Wind, Druck und Bewölkung verbleiben punktbezogen an `S`. Niederschlagsmenge, PoP, Phase, Skybar-Overlay und Niederschlagspiktogramm verwenden dagegen gemeinsam die auf den Slotbeginn normalisierte Niederschlagsprobe. Die PoP-Linie darf ab v0.9.80.6 als monoton geglättete PoP-Linie durch die Slotmittelpunkte gezeichnet werden; Säulen, auswählbare Punkte, Werte und Tooltips behalten unverändert ihre expliziten Vorwärtsintervalle. Die Kurve ist eine Darstellungsform und erzeugt keine zusätzlichen Wahrscheinlichkeitswerte. Das erste laufende Intervall wird nur für seinen noch zukünftigen Anteil dargestellt; 15-min-Nowcast und stündlicher Fallback überlappen sich nicht.

## Präzisierung v0.9.84.38 · kontinuierliche Tagesfusion

- Tagesbasierte Modell-/MOSMIX-Konsensanpassungen dürfen die stündliche Temperaturkurve **nicht an 00:00 Uhr sprunghaft** verändern. Tageswerte sind Aggregationen und besitzen keine meteorologische Gültigkeitskante am Kalendertageswechsel.
- Die affine Tageskorrektur der stündlichen Temperatur (Niveau und Tagesamplitude) wird deshalb zwischen den **lokalen Tagesmitten** kontinuierlich interpoliert. Entsprechende Wind-/Böen-Skalierungen folgen demselben zeitlich stetigen Übergang.
- Echte stündliche Änderungen der Leitprognose – beispielsweise Frontpassage, Bewölkungsänderung, Advektion oder nächtliche Durchmischung – bleiben unangetastet. MID glättet keine meteorologisch begründeten Rohsignale weg; beseitigt werden ausschließlich künstliche Gewichtungs-/Tagesgrenzen.
- DWD ICON-D2-RUC läuft vor dem realen +14-h-Horizont mit einer kontinuierlichen Gewichtsfunktion aus. MOSMIX-Stundenbeiträge werden ebenfalls über geglättete Lead-Time-Übergänge ein-/ausgeblendet. Harte Gewichtssprünge dürfen keine Temperatur- oder Druckwende erzeugen.
- Luftdruck bleibt ein punktbezogener stündlicher Zustandswert. Die stündliche Darstellung verwendet keine zeitlichen Blockmittel und versetzt die Druckkurve nicht.

## MID-C24 · kontinuierliches Skybar-Band (.215)
Im Bandmodus werden unmittelbar angrenzende identische Farbe/Dicke/Stufe/Deckkraft/Lage in einer Fläche gezeichnet. Unterschiedliche Prozentwerte oder Tooltiptexte erzeugen keine sichtbaren Stundennähte. Alle Originalintervalle und ihre Beschreibungen bleiben erhalten; echte Lücken, Dicken-/Phasenwechsel und separate Niederschlagslagen werden nicht übermalt. Dies gilt über den gemeinsamen Renderer für 90 min, 12/24 h, Tageskarten, 7/14 Tage sowie Widget-/PNG-/URL-Ausgaben. Der explizite Quadratmodus behält Einzelzellen.

## MID-C32 · gerade Skybar-Balkenenden (.261)
Auf ausdrücklichen Nutzerauftrag ersetzt dieser Vertrag die bisherigen Rundungen im Bandmodus: Alle Grund- und Niederschlagsbalken haben über ihr vollständiges Gültigkeitsintervall konstante Dicke und senkrechte, gerade Enden. Keine Kreiskappen, abgerundeten Ecken oder Verjüngungen an Außenrändern, Datenlücken oder Zeitschritt-/Dicken-/Phasenwechseln. Identische benachbarte Zustände bleiben fugenlos verbunden; Werte, Zeitgrenzen, Missing Data, Tooltips und Overlay-Reihenfolge bleiben unverändert. Der gemeinsame Renderer gilt für sämtliche Ansichten und Widget-/PNG-/URL-Ausgaben. Die expliziten Stundenquadrate sind keine Balken.

## MID-C50 · farbreines kontinuierliches Grundband (.358)

Das kontinuierliche gelbe Sonnen-/Wolkenlückenband verwendet appweit `#ffc229` mit Deckkraft `1`, das graue Bewölkungsband `#aeb3b9` mit Deckkraft `1`. Die vier Ausprägungen werden ausschließlich durch `2.4 / 3.6 / 4.8 / 6.0` SVG-Einheiten vermittelt. Weder direkt gelieferte Sonnenscheindauer gegenüber Wolkenlücken noch Hell-/Dunkel- oder Nachtunterlagen dürfen eine zusätzliche Farbabstufung verursachen. Die Titel behalten den tatsächlichen Parameter und seinen Bezugszeitraum; Wolkenlücken werden niemals zu gemessener Sonnenscheindauer umgedeutet.

Dies gilt für 90 min, Aktuell 12 h, 24-h-Profil, Tagesdetails, 7-/14-Tage-Verbraucher sowie gemeinsam gerenderte Widgets und SVG-/PNG-/URL-Ausgaben. Sonnenränder, Missing, Schwellen, Originalintervalle und phasenabhängige Niederschlagslagen bleiben unverändert. Der optionale Quadratmodus besitzt weiterhin seine expliziten Klassenfarben, weil dort gleich große Zellen die Banddicke nicht abbilden. Die Datenherkunft erzeugt auch dort keine zusätzliche Deckkraftstufe innerhalb derselben Klasse. Dieser Zusatz ersetzt die früheren Grundbanddeckkräfte 0,78 / 0,98 / 0,96.
