# MID – Meteorological Information Dashboard

MID ist eine wissenschaftlich fundierte, hyperlokale Wetter-App, die professionelle meteorologische Datenquellen (DWD, ECMWF, NOAA, ERA5) mit eigener Modellfusion, Ensemble-Analyse und Konfidenzbewertung kombiniert.

**Live-Version:** [Aktueller MID-Versionsstand](https://www.midwx.app/version.json) – wird bei jeder Veröffentlichung aktualisiert.  
**App:** [https://www.midwx.app](https://www.midwx.app)  
**Changelog:** [CHANGELOG.md](CHANGELOG.md) · [Aktuelle Release-Notizen](RELEASE_NOTES.md)

**Hinweis zur GitHub-Releases-Übersicht:** Separate versionierte Tags und Releases sind seit v0.9.85.119 nicht vollständig nachgetragen. Maßgeblich ist der nach erfolgreicher Promotion verifizierte Stand auf `mid-stable`; siehe [Issue #901](https://github.com/MeteoMartini/MID/issues/901). Fehlende GitHub-Release-Metadaten sind kein automatischer Hinweis auf ein fehlgeschlagenes App-Deployment.

## Funktionen

- **Aktuell:** Hyperlokale aktuelle Wetterdaten mit +12-Stunden-Temperaturtrend, Niederschlags-Nowcast, Luftqualität (EU-AQI), UV-Index, Sonne/Mond
- **Heute:** 90-Minuten-Nowcast (15-Minuten-Auflösung) und 24-Stunden-Wetterprofil mit stündlicher Auflösung
- **Vorhersage:** 7- und 14-Tage-Prognose mit Ensemble-basierten Konfidenzindizes, 46-Tage-Witterungstrend und Saisonvorhersagen (ECMWF SEAS5)
- **Karten:** Radar, Satellit und Synoptik mit DWD-Bodenanalyse, NowCastMIX-Blitzdaten und KONRAD3D-Konvektionsobjekten
- **Warnungen:** Amtliche DWD-/MeteoAlarm-Warnungen mit eigener Ereignis-Timeline
- **Klima:** ERA5-Klimanormalen (1991–2020) mit Windrose und Jahresverlauf
- **Planung:** Reiseplaner, Eventplaner und Berg-/Wintersportprofile

## Datenquellen

| Kategorie | Quellen |
|---|---|
| Leitprognose | Open-Meteo Best Match, DWD ICON-D2-RUC, ECMWF IFS |
| Ensembles | DWD ICON-EPS, ECMWF IFS ENS/AIFS ENS, NOAA GEFS |
| Langfrist | ECMWF EC46, NOAA GEFS, ECMWF SEAS5 (51 Member) |
| Beobachtungen | DWD Open Data/CDC/SYNOP, Bright-Sky, GeoSphere Austria |
| Radar & Satellit | RainViewer, OPERA-CIRRUS, DWD NowCastMIX, KONRAD3D |
| Klima | ERA5/ERA5-Land, ERA5-Seamless |
| Warnungen | DWD WFS/CAP, MeteoAlarm, NOAA/NWS |
| Flugmeteorologie | NOAA AviationWeather Center (METAR/SPECI, PIREP/AIREP, SIGMET) |
| Karten | OpenStreetMap, Photon/Overpass, BigDataCloud |

Siehe auch: [Quellen](https://www.midwx.app) (in der App über „Quellen" erreichbar)

## Technologie-Stack

- **Frontend:** React + TypeScript, Vite
- **Mobile:** Capacitor (iOS)
- **Backend:** Cloudflare Workers (Daten-Proxy, METAR-Proxy)
- **Hosting:** Cloudflare Pages
- **Karten:** MapLibre GL, OpenFreeMap

## Entwicklung

### Voraussetzungen

- Node.js (aktuelle LTS-Version)
- npm

### Setup

```bash
npm install
npm run dev
```

### Build

```bash
npm run build
```

### Tests

```bash
npm run verify          # Build + Worker-Check + Regressionen
npm run test:regressions  # Nur Regressionstests
```

### Veröffentlichungsweg

Der reguläre Veröffentlichungspfad ist:

```
Source-PR → Source-PR-Gate → Auto-Merge → Release-ZIP → Installer → Worker/Pages-Prüfung → Stable-Promotion
```

Direkte Änderungen an `main` oder `mid-stable` sind nicht zulässig. Siehe [AGENTS.md](AGENTS.md) für die vollständigen Regeln.

## Repository-Struktur

```
├── src/                    React/TypeScript-Quellcode
├── worker/                 Cloudflare Worker (METAR-Proxy)
├── worker-src/             Worker-Quellmodule
├── scripts/                Build-, Test- und Hilfsskripte
├── ci/github/workflows/    Kanonische GitHub-Actions-Workflows
├── .github/workflows/      Aktive Workflows (aus ci/ gespiegelt)
├── docs/                   Migrierte Dokumentation (seit v0.9.85.117)
│   ├── implementation/     Implementierungs-Logs
│   ├── test-reports/       Testberichte
│   ├── quality/            QS-Dokumentationen
│   ├── audits/             Audit-Berichte
│   ├── design/             Design-Dokumentationen
│   ├── c14/                C14-Kartenprojekt
│   ├── misc/               Handoffs und Verträge
│   └── validation/         Validierungsberichte
├── tools/                  Python-Tools (RUC, KNMI-EPS)
├── tests/                  Smoke-Tests
├── AGENTS.md               Bindende Regeln für KI-Agenten
├── CHANGELOG.md            Benutzerfreundlicher Changelog
├── MID_SOURCE_OF_TRUTH.md  Verbindliche Codebasis-Referenz
├── MID_BASELINE.json       Baseline-Konfiguration
└── package.json            Node.js-Konfiguration
```

## Zusammenarbeit mit GitHub Copilot

GitHub Copilot verwendet die [repositoryweiten MID-Anweisungen](.github/copilot-instructions.md), [fach- und pfadspezifischen Regeln](.github/instructions/), [wiederverwendbare Prüf- und Übergabe-Prompts](.github/prompts/) sowie den [lesenden Audit-Agenten](.github/agents/mid-auditor.agent.md). Die [Copilot-Koordinationsregeln](docs/implementation/MID_COPILOT_COLLABORATION_2026_11_06.md) beschreiben die SHA-Prüfung, den Umgang mit parallelen Arbeiten und die Integration ohne eigene Copilot-Releaseberechtigung.

### Copilot direkt aus ChatGPT beauftragen (ohne Copy/Paste)

Für **ausdrücklich vom Nutzer beauftragte MID-Aufgaben** kann ChatGPT über die bereits verbundene GitHub-App nach Live-Prüfung von `mid-stable`/`main` (volle SHAs), Version, Verträgen, Rechten und parallelen PRs ein GitHub-Issue mit konkretem Scope, Abnahmekriterien und Ausschlüssen erstellen und es **einmalig** `copilot-swe-agent[bot]` zuweisen. GitHub erzeugt daraufhin gegebenenfalls einen **unvertrauenswürdigen Draft-PR** auf einem `copilot/*`-Branch. ChatGPT überprüft GitHub-Issue, Copilot-PR, Basis-/Head-SHA, geänderte Dateien, Tests und Ergebnis direkt über GitHub – **ohne manuelles Kopieren von Prompt, Patch oder Rückmeldung**.

Dieser Transport wurde mit [Pilot-Issue #688](https://github.com/MeteoMartini/MID/issues/688) und dem danach ohne Merge geschlossenen [Copilot-Draft #689](https://github.com/MeteoMartini/MID/pull/689) nachgewiesen. Ein gestarteter Task ist noch **keine Code- oder Releasefreigabe**. Copilot darf keine Aufgaben eigenständig ausweiten, keine neuen Tokens/Abos/Workflows einrichten und weder `main`/`mid-stable` noch `chatgpt/*`/`codex/*` verändern. Die normale unabhängige Review und der vollständige MID-Releasepfad bleiben zwingend. Die Zuweisung kann vorhandene Copilot-AI-Credits verbrauchen; bei unklaren Kosten oder Berechtigungen wird **fail-closed** abgebrochen.

Verbindliche Details: [AGENTS.md](AGENTS.md) · [Copilot-Anweisungen](.github/copilot-instructions.md) · [erprobter Issue-/Draft-Handoff](docs/implementation/MID_COPILOT_CLOUD_BRIDGE_2026_11_07.md).

Copilot-Ergebnisse aus `copilot/*` werden **nicht** direkt veröffentlicht. Unabhängige Integration, vollständige Gates und Stable-Promotion bleiben wie in `AGENTS.md` beschrieben verpflichtend.

## Zusammenarbeit mit Kilo (ohne Copy/Paste)

Für **ausdrücklich beauftragte, rein lesende** Audits kann ChatGPT künftig ein begrenztes GitHub-Issue anlegen und darin `@kilocode-bot` einmalig erwähnen. Kilo soll seine Antwort direkt im Issue dokumentieren, das ChatGPT dann unabhängig ausliest. Der vollständige Ablauf wurde mit [Pilot-Issue #692](https://github.com/MeteoMartini/MID/issues/692) **erfolgreich verifiziert**: Nach deiner GitHub↔Kilo-Kontoverknüpfung hat der authentifizierte Kilo-Bot einen SHA-genauen [Auditbericht](https://github.com/MeteoMartini/MID/issues/692#issuecomment-6711417279) und die [Abschlussmeldung](https://github.com/MeteoMartini/MID/issues/692#issuecomment-6711420333) direkt in GitHub zurückgegeben. ChatGPT hat beide unabhängig ausgelesen. Kein Kopieren, kein neuer PR, kein Merge oder Release. Verknüpfungslinks/-tokens niemals kopieren oder öffentlich weitergeben.

**Codeänderungen laufen weiterhin nicht über GitHub-Bot-Fix-Kommandos.** Die erlaubte Kilo-Codeübergabe bleibt `scripts/mid-kilo-handoff.mjs` mit einmaligem SHA-gesicherten, **ref-freien** Git-Objekt-/Issue-Transport und unabhängiger ChatGPT-Intake-Prüfung (verifizierter Vorversuch [#662](https://github.com/MeteoMartini/MID/issues/662) → [Draft #663](https://github.com/MeteoMartini/MID/pull/663)). Kilo darf keine selbstständigen MID-Branches/PRs, Releases, neuen Secrets oder kostenpflichtigen Dienste anlegen; Kilo-Credits können verbraucht werden. Alle Source-/Installer-/Worker-/Pages-/Stable-Gates bleiben verbindlich.

Vollständige Anleitung: [Kilo-GitHub-Issue-Rückkanal](docs/implementation/MID_KILO_GITHUB_ISSUE_BRIDGE_2026_11_07.md), [Kilo-Handoff-Vertrag](docs/implementation/MID_KILO_DEFAULT_HANDOFF_CONTRACT_2026_11_05.md), [AGENTS.md](AGENTS.md).

## Automatische, bedarfsgerechte Zusammenarbeit

Innerhalb eines **konkreten Nutzerauftrags** übernimmt ChatGPT die Wahl und Koordination geeigneter, bereits verbundener Dienste **ohne unnötiges Kopieren oder wiederholte technische Freigaben**: GitHub als Source of Truth, Copilot für eng beauftragte Coding-/Review-Drafts, Kilo-GitHub-Bot für **lesende** Audits und der bestehende ref-freie Kilo-Handoff für Implementierungen. Je nach nachgewiesenem Nutzen kommen Replit (UI), Product Design (UX), Context7 (API-/SDK-Doku), Firecrawl (Wetter-/Lizenzrecherche), PostHog (datensparsame Qualitätstelemetrie) und PR Completion (CI-/PR-Triage, nicht Merge) dazu. Nur vorhandene Rechte, Einwilligungen und freigegebene Budgets verwenden; keine Doppelaufträge, keine autonomen Folgeaufträge und keine ungeprüfte Agenten- oder Releaseintegration.

**Bestehende fünf MID-Überwachungstasks bleiben aktiv**, da sie unterschiedliche Aufgaben erfüllen (Kilo-Code-Handoff, RUC-Betrieb, Open-Meteo-Änderungen, App-Gesamtaudit und neue Wetterdatenquellen). Einzelne Agentenaufträge ersetzen keine kontinuierliche Wache; Wachen erst nach nachgewiesen gleichwertiger Abdeckung deaktivieren. Vollständige Tool-Zuordnung und verbindliche Schutzregeln: [Agenten-/Plugin-Routing und Taskinventar](docs/implementation/MID_AGENT_PLUGIN_ROUTING_2026_11_07.md) und [AGENTS.md](AGENTS.md).

## Versionsschema

- Funktionsrelease (`0.7.x` oder äquivalent `0.7.x.0`) für neue eigenständige Funktionen.
- Wartungsrelease (`0.7.x.y` mit `y ≥ 1`) für Korrekturen und inkrementelle Weiterentwicklung eines Funktionsstands.

## Lizenz

Keine Lizenz hinterlegt. Die App ist unter [midwx.app](https://www.midwx.app) öffentlich erreichbar.
