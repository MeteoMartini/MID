const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-BnwfmnIU.js","./index-BKGuWBGh.js","./ReactVendor-vKsizCg5.js","./index-DrCUDnSl.css"])))=>i.map(i=>d[i]);
import{b7 as p,_ as r}from"./index-BKGuWBGh.js";import"./ReactVendor-vKsizCg5.js";const i=p("App",{web:()=>r(()=>import("./web-BnwfmnIU.js"),__vite__mapDeps([0,1,2,3]),import.meta.url).then(e=>new e.AppWeb)});export{i as App};
