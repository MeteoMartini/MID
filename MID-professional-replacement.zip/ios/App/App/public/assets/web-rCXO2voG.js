import{bk as n}from"./index-DJ2sY52K.js";import"./ReactVendor-vKsizCg5.js";class i extends n{async show(e){}async hide(e){}}export{i as SplashScreenWeb};
