const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./web-C7rz5Sj2.js","./index-DJ2sY52K.js","./ReactVendor-vKsizCg5.js","./index-DrCUDnSl.css"])))=>i.map(i=>d[i]);
import{b7 as p,_ as r}from"./index-DJ2sY52K.js";import"./ReactVendor-vKsizCg5.js";const i=p("App",{web:()=>r(()=>import("./web-C7rz5Sj2.js"),__vite__mapDeps([0,1,2,3]),import.meta.url).then(e=>new e.AppWeb)});export{i as App};
