# MID Daten-, Warnungs-, Radar-, Bergsport- und Push-Worker v0.7.92

Der Worker v0.7.92 ergänzt die bestehenden MID-Dienste um persönliche Web-Push-Regeln für Niederschlagsbeginn und sich nähernde Gewitterzellen. Er enthält die Routen `push-config`, `push-subscribe` und `push-unsubscribe` sowie einen `scheduled()`-Handler für den fünfminütigen Cron-Lauf.

**Worker-Upload erforderlich: Ja.** Die Datei `worker/metar-proxy.js` muss den bisherigen Cloudflare-Worker vollständig ersetzen. Anschließend sind KV, VAPID-Variablen, das VAPID-Geheimnis und der Cron-Trigger einzurichten.

Cloudflare Worker: `https://mid-data-proxy.martinmolkentin.workers.dev`

Vollständige deutsche Schritt-für-Schritt-Anleitung: `../ANLEITUNG-v0.7.92.md` beziehungsweise `../docs/push-notifications.md`.

# MID Daten-, Warnungs-, Radar- und Bergsportproxy v0.7.91

Funktionale Erweiterung um `mode=mountain-profile` und `mode=snow-observations`. Das Höhenprofil wertet OpenStreetMap-Seilbahnstationen und Liftwege aus und ergänzt fehlende Höhen über Copernicus GLO-90 via Open-Meteo. Für österreichische Bergsportorte ordnet die Schnee-Route aktuelle GeoSphere-TAWES-Schneepegel konservativ den Niveaus Tal, Mitte und Berg zu. Das Frontend besitzt zusätzlich einen direkten CORS-Fallback, sodass die vollständige MID-Ersatz-ZIP auch vor einer optionalen Worker-Aktualisierung funktionsfähig bleibt.

# MID Daten-, Warnungs- und Radarproxy v0.7.88

Funktionale Erweiterung des bestehenden Workers für die Starkregenanalyse der aktuellen Niederschlagswahrscheinlichkeit: RADOLAN-YW-Summen 15/30/60/180/360 Minuten, DWD-RV-Nowcast bis +120 Minuten, KONRAD3D-Zellzug und Starkregenflag, KOSTRA-DWD-2020-Einordnung sowie DWD-Stationsabgleich. Amtliche Warnungen bleiben getrennt. Die Cloudflare-Auslieferung erfolgt weiterhin als einzelner Worker; in `MID-worker.zip` heißt die Einstiegdatei `worker.js`.

# MID Daten-, Warnungs- und Radarproxy v0.7.87.1

Funktionale Erweiterung um DWD-RADOLAN-YW-Metadaten und HDF5-Proxy, DWD-RV-Niederschlagsakkumulation bis +120 Minuten, KOSTRA-DWD-2020-ASC-ZIP-Proxy und DWD-Stationsregenabgleich. Die Starkregenanalyse bleibt von amtlichen Warnungen getrennt.

# MID Daten-, Warnungs-, Radar- und Gewitterproxy v0.7.86.1

Keine funktionale Worker-Änderung. Die Versionsnummer wurde lediglich mit der Korrektur des Frontend-Regressionstests synchronisiert.

# MID Daten-, Warnungs-, Radar- und Gewitterproxy v0.7.86

Funktionale OPERA-Korrektur: `opera-raster-meta` liest die real vorhandenen CIRRUS-DBZH-HDF5-Objekte über S3 ListObjectsV2 ein und erzeugt keine hypothetischen Zeitstände mehr. `opera-raster-file` akzeptiert validierte Objektschlüssel; bei einem S3-Indexausfall steht ein begrenzter Range-Probe-Fallback bereit.

# MID Daten-, Warnungs-, Radar- und Gewitterproxy v0.7.85

Funktionale Erweiterung: DWD-KONRAD3D-Zellnowcast über `mode=thunderstorm-nowcast` einschließlich Schweregrad, Trend, Blitz-, Hagel-, Starkregen- und Böeninformationen.

# MID Daten-, Warnungs- und Radarproxy v0.7.84.1

Keine funktionale Cloudflare-Worker-Änderung in v0.7.84.1; die Versionsnummer wurde ausschließlich mit der TypeScript-Buildkorrektur des OPERA-Rasteroverlays synchronisiert.

# MID Daten-, Warnungs- und Radarproxy v0.7.84

Phase 1 stellt das echte EUMETNET-OPERA-CIRRUS-DBZH-Raster über `opera-raster-meta` und `opera-raster-file` bereit. Die Anwendung wertet dasselbe 1-km-/5-Minuten-Raster für Karte und aktuelle Niederschlagswahrscheinlichkeit aus. Die Reihenfolge lautet DWD → OPERA CIRRUS → RainViewer; die frühere OPERA-Punkt-/Stützstellenlogik ist entfernt.

# MID Daten-, Warnungs- und Radarproxy v0.7.83.3

Keine funktionale Cloudflare-Worker-Änderung in v0.7.83.3; die Versionsnummer wurde ausschließlich mit der Achsenausrichtung des Frontends synchronisiert.

# MID Daten-, Warnungs- und Radarproxy v0.7.83

Keine funktionale Cloudflare-Worker-Änderung in v0.7.83; die Versionsnummer wurde ausschließlich mit dem Frontend-Code-Audit und den Tooltip-/7-Tage-Anpassungen synchronisiert.

# MID Daten-, Warnungs- und Radarproxy v0.7.82.2

Keine funktionale Cloudflare-Worker-Änderung in v0.7.82.2; die Versionsnummer wurde ausschließlich mit den Frontend-Korrekturen für Warnhinweise, Ensemble-Marker und Tooltip-Darstellung synchronisiert.

# MID Daten-, Warnungs- und Radarproxy v0.7.82.1

Keine funktionale Cloudflare-Worker-Änderung in v0.7.82.1; die Versionsnummer wurde ausschließlich mit den Frontend-Wartungskorrekturen synchronisiert.

# MID Daten-, Warnungs- und Radarproxy v0.7.82

Keine funktionale Cloudflare-Worker-Änderung in v0.7.82; die Warntext-, 7-Tage- und Ensemble-Hazarddarstellung betrifft ausschließlich das Frontend.

# MID Daten-, Warnungs- und Radarproxy v0.7.81.1

Keine funktionale Cloudflare-Worker-Änderung in v0.7.81.1; die Ergänzung der DWD-Warnstufe 1 betrifft ausschließlich die Frontend-Auswertung und Darstellung.

# MID Daten-, Warnungs- und Radarproxy v0.7.80

Keine funktionale Cloudflare-Worker-Änderung in v0.7.80; die Versionsnummer wurde zur einheitlichen Auslieferung synchronisiert. Windwarnflächen und die vereinfachte Modulsteuerung betreffen ausschließlich das Frontend.

# MID Daten-, Warnungs- und Radarproxy v0.7.79.3

Keine funktionale Cloudflare-Worker-Änderung in v0.7.79.3; die Versionsnummer wurde zur einheitlichen Auslieferung synchronisiert. Die adaptive Maximierung der Wetterpiktogramme betrifft ausschließlich das Frontend.

# MID Daten-, Warnungs- und Radarproxy v0.7.79.2

Keine funktionale Cloudflare-Worker-Änderung in v0.7.79.2; die Versionsnummer wurde zur einheitlichen Auslieferung synchronisiert. Die neue Reihenfolge der oberen Detaildiagramm-Lanes und die verlängerte Stundenmarkierung betreffen ausschließlich das Frontend.

# MID Daten-, Warnungs- und Radarproxy v0.7.79.1

Keine funktionale Cloudflare-Worker-Änderung in v0.7.79.1; die Versionsnummer wurde zur einheitlichen Auslieferung synchronisiert. Der Tausch von Wetterpiktogrammen und Sonnenschein-/Bewölkungsband betrifft ausschließlich das Frontend.

# MID Daten-, Warnungs- und Radarproxy v0.7.79

Keine funktionale Cloudflare-Worker-Änderung in v0.7.79; die Versionsnummer wurde zur einheitlichen Auslieferung mit dem Hauptprojekt synchronisiert. Ortszeit-, Info-Popover-, Ensemble-Fehlerbalken- und Detaildiagramm-Anpassungen betreffen ausschließlich das Frontend.

# MID Daten-, Warnungs- und Radarproxy v0.7.78.1

Keine funktionale Cloudflare-Worker-Änderung in v0.7.78.1; die Versionsnummer wurde zur einheitlichen Auslieferung mit dem Hauptprojekt synchronisiert. CHMI-Modellkatalog und die erweiterte, adaptive Detailansicht betreffen ausschließlich das Frontend.

Keine funktionale Cloudflare-Worker-Änderung in v0.7.77.1; die Versionsnummer wurde zur einheitlichen Auslieferung mit dem Hauptprojekt synchronisiert. Die Anpassungen an Legendenlesbarkeit und deutscher Wortstellung betreffen ausschließlich das Frontend.

Keine funktionale Cloudflare-Worker-Änderung in v0.7.73; die Versionsnummer wurde zur einheitlichen Auslieferung mit dem Hauptprojekt synchronisiert. Tooltip-, Wolkenhöhen- und mobile Navigationsänderungen betreffen ausschließlich das Frontend.

Keine funktionale Cloudflare-Worker-Änderung in v0.7.72; die Versionsnummer wurde zur einheitlichen Auslieferung mit dem Hauptprojekt synchronisiert. Das zentrale Einstellungsmenü betrifft ausschließlich das Frontend.

Keine funktionale Cloudflare-Worker-Änderung in v0.7.71; die Versionsnummer wurde zur einheitlichen Auslieferung mit dem Hauptprojekt synchronisiert. Die globalen METAR-Korrekturen aus v0.7.70.4 bleiben unverändert enthalten.

Wartungsstand v0.7.70.2 enthält gegenüber v0.7.70.1 keine funktionale Worker-Änderung; die Versionsnummer wurde zur einheitlichen Auslieferung synchronisiert.
In v0.7.70 wurde der METAR-Datenpfad funktional erweitert: Der Worker reicht strukturierte Wolkenlagen, vertikale Sichtweite und die Rohmeldung an die Anwendung weiter. Dadurch kann MID die Hauptwolkenuntergrenze als Ceiling in hft bestimmen und in die hyperlokale Stationsanalyse einbeziehen.

In v0.7.60 wurde der DWD-Radarabgleich funktional korrigiert: Die GetFeatureInfo-Punktabfrage wird auch bei einem scheinbar trockenen GetMap-Pixel ausgeführt, die Analyse ist auf höchstens zwölf Frames begrenzt und liefert Diagnosezähler für Punktwerte und Karten-Fallbacks.

Funktionale Änderung in v0.7.41: `best_match` wird für das vertikale Meteogramm auf eine konsistente ECMWF-IFS-HRES-Druckniveauzeitreihe abgebildet. Dadurch entstehen nach dem Ende eines kurz laufenden Regionalmodells keine leeren Profilfelder. Der Worker liefert weiterhin die tatsächliche Modelllaufzeit über `forecastHours`.

## Druckniveau-Meteogramm v0.7.41

`?mode=meteogram&lat=...&lon=...&elevation=...&model=...` lädt und cached stündliche Open-Meteo-Druckniveauprofile von Stationsniveau bis 300 hPa für maximal 168 Stunden. Zulässig sind Best Match, DWD ICON-D2/EU/Global, Météo-France ARPEGE Europa, ECMWF IFS HRES und NOAA GFS 0,25°.

Der Cloudflare Worker stellt browserkompatibel Stationsdaten, amtliche Warnungen und die standortbezogene Radar-Nowcast-Auswertung bereit. Ein zweiter Worker ist nicht erforderlich.

## Komposit- und Modellrouten v0.7.41

- `rainviewer-meta` stellt die öffentliche RainViewer-Historie CORS-sicher und 120 Sekunden gecacht bereit. Zukunftsframes werden nur weitergereicht, wenn der Anbieter sie tatsächlich meldet.
- `composite-times` liefert bis zu 150 Minuten Satelliten- und 130 Minuten Blitzhistorie sowie einen Publikationspuffer für verspätet eintreffende Satellitenprodukte.
- H-SAF-Niederschlagsprodukte werden in der Reihenfolge MTG H40B (sobald als WMS-Layer vorhanden) und MSG H60B ausgewählt.
- `model-contours` lädt ein großräumiges 17×25-Stützraster in kurzen Zeilenabfragen, erzeugt geglättete dynamische Isobaren und 500-hPa-Isohypsen im Abstand 8 gpdm und erkennt zusätzlich räumlich getrennte H-/T-Druckzentren. Die Antwort wird 15 Minuten gecacht.
- `composite-wms` akzeptiert die neuen freigegebenen H-SAF-Layer und berücksichtigt die längere Veröffentlichungsverzögerung von Satellitenprodukten.

## Hochauflösendes Radar v0.7.41

Der Endpunkt `px250-meta` prüft für deutsche Orte zuerst das nationale DWD-HX-Komposit (`weather/radar/composite/hx`) mit 250-m-Raster. Ein aktuelles PX250-Standortprodukt dient nur noch als Fallback. `px250-file` validiert Produkt, Dateiname und Aktualität erneut.

## Kompatibilität v0.7.41

Der Worker wurde funktional erweitert. Die Route `mode=composite-wms` leitet ausschließlich freigegebene Layer, valide Zeitstempel und notwendige WMS-Kartenparameter an DWD beziehungsweise EUMETSAT weiter, setzt CORS-Header und verwendet beim DWD automatisch den Ausfallserver. `composite-times` liefert Zeitwerte einheitlich als ISO-Zeit, ergänzt den tatsächlich verwendeten DWD-Radar-Layer und die Serverzeit und trennt jede Zeitdimension strikt nach Produkt. DWD-RV stellt für die Oberfläche – soweit vom Dienst angeboten – ein reales relatives Fenster von −1 Stunde bis +2 Stunden bereit; künstliche Zukunftsframes werden nicht erzeugt.

### Zusätzliche Absicherung in v0.7.41

- `px250-meta` akzeptiert nur frische Standortprodukte und prüft mehrere nahe Radarstandorte. `px250-file` validiert den Zeitstempel des Dateinamens erneut, sodass alte Cache-Verweise nicht mehr ausgeliefert werden.
- `composite-wms` weist Zeitpunkte außerhalb des jeweils zulässigen Radar-, Satelliten- oder Blitzfensters zurück.
- Satellitenprodukte ohne vollständige Zeitreihe werden als `latestOnly` gemeldet; sofern die Capabilities einen letzten exakten Zeitpunkt enthalten, wird dieser zusätzlich als `latestTime` fixiert.
- Blitzortung.org ist keine Worker-Quelle. Die Anwendung übernimmt lediglich eine ähnliche alterscodierte Darstellung; Rohdaten werden ausschließlich aus freigegebenen DWD- beziehungsweise autorisierten kommerziellen Quellen bezogen.

Der Worker erweitert die bestehenden Stations-, Warnungs- und Nowcast-Dienste um ein zeitlich validiertes OPERA-CIRRUS-HDF5-Filmfenster und eine ortsabhängige Blitzquellenwahl. Mit autorisierten Xweather-Zugangsdaten werden weltweite Vaisala-/GLD360-Punktdaten genutzt; ohne Zugangsdaten bleiben DWD-Blitzgeometrien in Deutschland und EUMETSAT MTG-LI als freier Satelliten-Fallback erhalten. Die bisherigen Schnittstellen bleiben kompatibel.

## Enthaltene Dienste

- NOAA AviationWeather METAR – weltweit, ohne eigenes Secret
- DWD Open Data über Bright Sky – Deutschland, mehrere deduplizierte Messpunkte ohne eigenes Secret
- GeoSphere Austria/TAWES – Österreich, ohne eigenes Secret
- openSenseMap/senseBox – offene Außenmessungen, ohne Secret und nur als niedrig gewichtete Zusatzquelle
- Weather Underground/The Weather Company PWS – optional
- Netatmo öffentliche Außenmessungen – optional
- Synoptic Data Latest – optional, mit QC
- Xweather Observations/PWS – optional, mit QC-/Vertrauenswerten
- DWD-Warnungen – Deutschland
- MeteoAlarm/CAP – unterstützte europäische Länder
- NOAA/NWS Active Alerts – USA
- Radar-Nowcast: DWD-RV in Deutschland; das Frontend wertet danach das echte OPERA-CIRRUS-Raster aus; RainViewer ist der letzte Fallback
- PX250-Metadaten und HDF5-Dateiproxy für das hochaufgelöste lokale DWD-Radarprodukt
- EUMETNET OPERA CIRRUS DBZH als echtes ODIM-HDF5-Raster mit 1 km Rasterweite und ungefähr 60 Minuten Historie
- Ortsabhängige Blitzquelle: optional weltweite Vaisala-Xweather-/GLD360-Punktdaten, sonst DWD-Blitzgeometrien in Deutschland und MTG-LI-Raster im Satellitenabdeckungsbereich
- Reale, layergebundene WMS-Produktzeitpunkte sowie dynamische Satellitenproduktwahl (`composite-times`)
- CORS-sicherer DWD-/EUMETSAT-Kartenproxy mit DWD-Ausfallserver (`composite-wms`)

## Bereitstellung

1. In Cloudflare einen Worker anlegen oder den vorhandenen MID-Worker öffnen.
2. Den gesamten Inhalt von `worker.js` in den Codeeditor einsetzen.
3. **Deploy** ausführen.
4. Die Worker-Adresse in GitHub als Repository-Variable `VITE_METAR_PROXY_URL` hinterlegen.

Optional kann dieselbe Adresse als `VITE_ALERT_PROXY_URL` und `VITE_RADAR_PROXY_URL` gesetzt werden. Ohne diese Variablen verwendet MID automatisch `VITE_METAR_PROXY_URL` auch für Warnungen und Radar.

## Optionale Secrets

Unter **Worker → Settings → Variables and Secrets** können folgende Secrets gesetzt werden:

```text
WEATHER_COM_API_KEY       # alternativ WU_API_KEY
NETATMO_ACCESS_TOKEN
SYNOPTIC_TOKEN
XWEATHER_CLIENT_ID
XWEATHER_CLIENT_SECRET
XWEATHER_LIGHTNING_ENTERPRISE  # optional: true bei freigeschalteter Lightning-Enterprise-Historie
ENABLE_OPENSENSEMAP        # optional: false deaktiviert die offene Citizen-Science-Quelle
```

Alle Secrets sind optional. Ohne sie bleiben NOAA-METAR, DWD Open Data/Bright Sky, GeoSphere Austria/TAWES, openSenseMap und amtliche Warnungen aktiv. `ENABLE_OPENSENSEMAP=false` ist eine normale Worker-Variable, kein Secret.

- Weather Underground, Netatmo und Xweather werden nur über offizielle, entsprechend berechtigte API-Zugänge verwendet.
- Die Xweather-Zugangsdaten werden zusätzlich für den weltweiten Lightning-Endpunkt genutzt. Der Standardzugang liefert die letzten fünf Minuten; mit `XWEATHER_LIGHTNING_ENTERPRISE=true` fordert MID eine auf 2.500 Treffer begrenzte Historie bis 60 Minuten an. Ohne passenden Tarif bleibt die globale Punktquelle deaktiviert; MID fällt transparent auf die freien regionalen Quellen zurück.
- `SYNOPTIC_TOKEN` ist ein Synoptic-Weather-API-Token.
- Netatmo benötigt einen gültigen OAuth-Access-Token. Ein statisch hinterlegter Access-Token muss nach Ablauf erneuert werden; der Worker führt ohne zusätzliche persistente OAuth-Infrastruktur keine automatische Tokenrotation durch.
- Secrets niemals als öffentliche GitHub-Variable oder `VITE_*`-Variable eintragen.

## Diagnose

Gesundheitstest:

```text
https://DEIN-WORKER.workers.dev/?mode=health
```

Beispielantwort:

```json
{
  "ok": true,
  "version": "0.7.91",
  "services": ["stations", "alerts", "hyperlocal-networks", "model-assisted-local-analysis", "radar-nowcast", "px250-proxy", "opera-cirrus-raster", "rainviewer-metadata", "best-location-lightning", "composite-product-times", "model-contours", "mountain-profile", "snow-observations", "cors-safe-composite-wms"],
  "providers": {
    "NOAA AviationWeather": true,
    "DWD Open Data / Bright Sky": true,
    "GeoSphere Austria": true,
    "openSenseMap / senseBox": true,
    "Weather Underground": false,
    "Netatmo": false,
    "Synoptic Data": false,
    "Xweather": false
  }
}
```

Kompositbild-Diagnose für Niederkassel:

```text
https://DEIN-WORKER.workers.dev/?mode=px250-meta&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=opera-raster-meta&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=lightning-points&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=composite-times&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=rainviewer-meta&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=model-contours&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=radar-nowcast&stage=dwd&country=DE&lat=50.82&lon=7.04
https://DEIN-WORKER.workers.dev/?mode=radar-nowcast&stage=rainviewer&lat=50.82&lon=7.04
```

`stage=dwd` prüft ausschließlich das deutsche DWD-Radar. `stage=rainviewer` ruft ausschließlich den letzten globalen Notfallpfad auf. OPERA wird dazwischen im Frontend aus dem echten CIRRUS-HDF5 ausgewertet, damit Karte und aktuelle Niederschlagswahrscheinlichkeit dasselbe Raster nutzen.

Der von `px250-meta` zurückgegebene `fileUrl` verweist auf denselben Worker und darf direkt vom Frontend geladen werden. PX250, OPERA CIRRUS und die freien DWD-/MTG-LI-Fallbacks benötigen keine zusätzlichen Secrets. Für weltweite Xweather-/GLD360-Blitzpunkte sind `XWEATHER_CLIENT_ID` und `XWEATHER_CLIENT_SECRET` erforderlich.

Stationsabruf für Innsbruck:

```text
https://DEIN-WORKER.workers.dev/?lat=47.26&lon=11.39&radius_km=140
```

Für einen funktionierenden österreichischen Abruf sollte `diagnostics.sourceRows["GeoSphere Austria"]` größer als `0` sein.

Stationsabruf für Cagliari:

```text
https://DEIN-WORKER.workers.dev/?lat=39.2238&lon=9.1217&radius_km=140
```

Die Antwort enthält:

- `data`: verfügbare Einzelstationen
- `providers`: aktivierte optionale Anbieter
- `diagnostics.sourceRows`: Treffer je Quelle
- `diagnostics.errors`: Fehler je Quelle

Die eigentliche Analyse erfolgt anschließend im MID-Frontend. Für Zielort und Stationsstandorte wird derselbe Best-Match-Modellhintergrund auf der jeweiligen Höhe abgefragt. MID interpoliert die Messungs-minus-Modell-Abweichungen statt rohe Stationswerte zu mitteln. Entfernung, Höhe, Aktualität, Netzqualität, Stadt-/Landlage und robuste räumliche Ausreißerprüfungen bestimmen das Gewicht. Citizen-Science-Sensoren besitzen bewusst kurze Reichweiten und deutlich niedrigere Gewichte.

Synoptic-Abfragen verwenden `qc_checks=synopticlabs` und entfernen Werte, die grundlegende oder erweiterte Qualitätsprüfungen nicht bestehen.

## Warnungstests

Deutschland:

```text
https://DEIN-WORKER.workers.dev/?mode=alerts&lat=50.82&lon=7.04&country=DE&name=Niederkassel&region=Nordrhein-Westfalen&language=de
```

Italien:

```text
https://DEIN-WORKER.workers.dev/?mode=alerts&lat=39.2238&lon=9.1217&country=IT&name=Cagliari&region=Sardegna&language=de
```

Eine leere Warnungsliste kann korrekt sein. Ein Feld `error` weist dagegen auf einen Abruf- oder Parserfehler hin.

## Radar-Nowcast testen

Deutschland/DWD:

```text
https://DEIN-WORKER.workers.dev/?mode=radar-nowcast&lat=50.82&lon=7.04&country=DE
```

Europa/OPERA-CIRRUS-Metadaten:

```text
https://DEIN-WORKER.workers.dev/?mode=opera-raster-meta&lat=39.2238&lon=9.1217
```

Die standortbezogene OPERA-Auswertung erfolgt im Frontend aus dem zurückgegebenen HDF5-Raster und wird mit der aktuellen Niederschlagswahrscheinlichkeit kombiniert.

Außerhalb Europas/RainViewer-Fallback:

```text
https://DEIN-WORKER.workers.dev/?mode=radar-nowcast&lat=35.68&lon=139.76&country=JP
```

Die Antwort enthält `source`, `provider`, `quality`, `radarProbability`, `currentRate`, optionale Ankunfts-/Endzeiten und Diagnosewerte. OPERA-Komposite werden unter CC BY 4.0 verarbeitet; die RainViewer-Nutzung ist für persönliche, schulische und kleine Community-Projekte vorgesehen und benötigt eine sichtbare Quellenangabe.

## DWD-Radarrobustheit v0.7.13

- allgemeiner DWD-WMS-Capabilities-Endpunkt statt abgeleiteter, layerspezifischer URL
- gezielte Auswertung der Zeitdimension des tatsächlich verwendeten Layers
- stabiler Alias `dwd:Niederschlagsradar` vor dem konkreten RV-Layer
- kleine transparente `GetMap`-PNG je Zeitschritt als primäre Datenprüfung
- `0 mm/h` aus transparentem Kartenpixel gilt als erfolgreiche DWD-Auswertung
- Mittelpunkt und 2/4/7-km-Umgebung werden aus derselben PNG abgetastet
- `GetFeatureInfo` wird nur zur Verfeinerung sichtbar nasser Pixel verwendet
- auffällige Rasterbandwerte werden gegen die Kartenfarbe plausibilisiert
- Primär- und Backup-Geoserver sowie OPERA-/RainViewer-Fallback bleiben erhalten

## Änderungen in v0.7.13

- DWD-Capabilities berücksichtigen geerbte WMS-Zeitdimensionen.
- Bei laufendem Niederschlag wird das Ende aus dem ersten nachhaltig trockenen Zukunftsfenster berechnet.
- Ein bis zum Ende des Nowcast-Horizonts anhaltendes Echo wird mit `endOpenEnded: true` zurückgegeben.
- `endUncertain: true` kennzeichnet eine Endzeit, die nur auf einem einzelnen trockenen Randframe beruht.
- Die zurückgegebene `timeline` enthält die verfügbare DWD-Zeitachse für die Radarfilm-Steuerung.

## Modelllinien v0.7.41

`mode=model-contours` liefert großräumige, geglättete Konturen. In Europa wird ein einheitlicher ICON-EU-Lauf genutzt, um Modellnähte zu vermeiden. Isobaren werden abhängig vom Druckgradienten mit 1, 2 oder 4 hPa Abstand berechnet; 500-hPa-Isohypsen haben 8 gpdm Abstand.

EuCom ist ein vom DWD für Flugsicherungs-/Flugwetterkunden erzeugtes europäisches Radarkomposit. In den öffentlich auffindbaren DWD-Unterlagen ist kein frei zugänglicher WMS-, Open-Data- oder API-Endpunkt dokumentiert. Der Worker bindet EuCom deshalb nicht ohne kundenspezifische Berechtigung ein.
