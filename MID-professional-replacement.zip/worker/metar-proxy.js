const AWC_API='https://aviationweather.gov/api/data/metar';
const NWS_ALERTS='https://api.weather.gov/alerts/active';
const DWD_WFS_PRIMARY='https://maps.dwd.de/geoserver/dwd/ows';
const DWD_WFS_BACKUP='https://brz-maps.dwd.de/geoserver/dwd/ows';
const DWD_CAP_FEED='https://www.dwd.de/DWD/warnungen/cap-feed/de/atom.xml';
const METEOALARM_FEEDS='https://feeds.meteoalarm.org/feeds/';
const TWC_NEAR='https://api.weather.com/v3/location/near';
const TWC_PWS='https://api.weather.com/v2/pws/observations/current';
const BIGDATA_REVERSE='https://api.bigdatacloud.net/data/reverse-geocode-client';
const NETATMO_PUBLIC='https://api.netatmo.com/api/getpublicdata';
const SYNOPTIC_LATEST='https://api.synopticdata.com/v2/stations/latest';
const XWEATHER_OBS='https://data.api.xweather.com/observations/closest';
const GEOSPHERE_META='https://dataset.api.hub.geosphere.at/v1/station/current/tawes-v1-10min/metadata';
const GEOSPHERE_CURRENT='https://dataset.api.hub.geosphere.at/v1/station/current/tawes-v1-10min';
const BRIGHTSKY_CURRENT='https://api.brightsky.dev/current_weather';
const OPENSENSEMAP_BOXES='https://api.opensensemap.org/boxes';
const DWD_KONRAD3D_INDEX='https://opendata.dwd.de/weather/radar/konrad3d/';
const DWD_RADOLAN_YW_ROOT='https://opendata.dwd.de/weather/radar/radolan/yw/';
const DWD_KOSTRA_ASC_ROOT='https://opendata.dwd.de/climate_environment/CDC/grids_germany/return_periods/precipitation/KOSTRA/KOSTRA_DWD_2020/asc/';
const WORKER_VERSION='0.7.95.27';
const CORS={'content-type':'application/json; charset=utf-8','access-control-allow-origin':'*','access-control-allow-methods':'GET,POST,OPTIONS','access-control-allow-headers':'content-type','cache-control':'public, max-age=180'};
const FEED_SLUGS={
 AD:'andorra',AT:'austria',BE:'belgium',BA:'bosnia-herzegovina',BG:'bulgaria',HR:'croatia',CY:'cyprus',CZ:'czechia',DK:'denmark',EE:'estonia',FI:'finland',FR:'france',DE:'germany',GR:'greece',EL:'greece',HU:'hungary',IS:'iceland',IE:'ireland',IL:'israel',IT:'italy',LV:'latvia',LT:'lithuania',LU:'luxembourg',MT:'malta',MD:'moldova',ME:'montenegro',NL:'netherlands',MK:'republic-of-north-macedonia',NO:'norway',PL:'poland',PT:'portugal',RO:'romania',RS:'serbia',SK:'slovakia',SI:'slovenia',ES:'spain',SE:'sweden',CH:'switzerland',UA:'ukraine',GB:'united-kingdom',UK:'united-kingdom',AM:'armenia'
};
const COUNTRY_ALIASES={
 DE:'DE',GERMANY:'DE',DEUTSCHLAND:'DE',ALLEMAGNE:'DE',GERMANIA:'DE',
 AT:'AT',AUSTRIA:'AT',OESTERREICH:'AT',OSTERREICH:'AT',ÖSTERREICH:'AT',
 IT:'IT',ITALY:'IT',ITALIA:'IT',ITALIEN:'IT',ITALIE:'IT',
 US:'US',USA:'US','UNITED STATES':'US','UNITED STATES OF AMERICA':'US',VEREINIGTESTAATEN:'US',
 GB:'GB',UK:'GB','UNITED KINGDOM':'GB',GROSSBRITANNIEN:'GB',
 CH:'CH',SWITZERLAND:'CH',SCHWEIZ:'CH',SUISSE:'CH',SVIZZERA:'CH',
 FR:'FR',FRANCE:'FR',FRANKREICH:'FR',
 ES:'ES',SPAIN:'ES',SPANIEN:'ES',ESPANA:'ES',ESPAÑA:'ES',
 PT:'PT',PORTUGAL:'PT',NL:'NL',NETHERLANDS:'NL',NIEDERLANDE:'NL',NIEDERLANDE:'NL',
 BE:'BE',BELGIUM:'BE',BELGIEN:'BE',DK:'DK',DENMARK:'DK',DAENEMARK:'DK',DÄNEMARK:'DK',
 NO:'NO',NORWAY:'NO',NORWEGEN:'NO',SE:'SE',SWEDEN:'SE',SCHWEDEN:'SE',FI:'FI',FINLAND:'FI',
 IE:'IE',IRELAND:'IE',IRLAND:'IE',IS:'IS',ICELAND:'IS',ISLAND:'IS',
 PL:'PL',POLAND:'PL',POLEN:'PL',CZ:'CZ',CZECHIA:'CZ','CZECH REPUBLIC':'CZ',TSCHECHIEN:'CZ',
 SK:'SK',SLOVAKIA:'SK',SLOWAKEI:'SK',SI:'SI',SLOVENIA:'SI',SLOWENIEN:'SI',
 HR:'HR',CROATIA:'HR',KROATIEN:'HR',GR:'GR',EL:'GR',GREECE:'GR',GRIECHENLAND:'GR',
 HU:'HU',HUNGARY:'HU',UNGARN:'HU',RO:'RO',ROMANIA:'RO',RUMAENIEN:'RO',RUMÄNIEN:'RO',
 BG:'BG',BULGARIA:'BG',BULGARIEN:'BG',RS:'RS',SERBIA:'RS',SERBIEN:'RS',
 BA:'BA','BOSNIA AND HERZEGOVINA':'BA',BOSNIENHERZEGOWINA:'BA',ME:'ME',MONTENEGRO:'ME',
 MK:'MK','NORTH MACEDONIA':'MK',NORDMAZEDONIEN:'MK',AL:'AL',ALBANIA:'AL',ALBANIEN:'AL',
 EE:'EE',ESTONIA:'EE',ESTLAND:'EE',LV:'LV',LATVIA:'LV',LETTLAND:'LV',LT:'LT',LITHUANIA:'LT',LITAUEN:'LT',
 LU:'LU',LUXEMBOURG:'LU',LUXEMBURG:'LU',MT:'MT',MALTA:'MT',CY:'CY',CYPRUS:'CY',ZYPERN:'CY',
 UA:'UA',UKRAINE:'UA',MD:'MD',MOLDOVA:'MD',MOLDAU:'MD',IL:'IL',ISRAEL:'IL',AD:'AD',ANDORRA:'AD'
};
function number(v){if(v===null||v===undefined||v==='')return undefined;const n=Number(v);return Number.isFinite(n)?n:undefined}
function distance(lat1,lon1,lat2,lon2){const r=6371000,t=x=>x*Math.PI/180,dLat=t(lat2-lat1),dLon=t(lon2-lon1),a=Math.sin(dLat/2)**2+Math.cos(t(lat1))*Math.cos(t(lat2))*Math.sin(dLon/2)**2;return 2*r*Math.asin(Math.sqrt(a))}
function at(v,i){return Array.isArray(v)?v[i]:undefined}
function json(data,status=200,headers={}){return new Response(JSON.stringify(data),{status,headers:{...CORS,...headers}})}
async function fetchWithDeadline(input,init={},timeoutMs=7000){const controller=new AbortController(),timer=setTimeout(()=>controller.abort('timeout'),timeoutMs);try{return await fetch(input,{...init,signal:controller.signal})}finally{clearTimeout(timer)}}
function decodeXml(value=''){return String(value).replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g,'$1').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&apos;/g,"'").replace(/&#39;/g,"'").replace(/&amp;/g,'&')}
function cleanText(value=''){return decodeXml(value).replace(/<br\s*\/?\s*>/gi,'\n').replace(/<[^>]+>/g,' ').replace(/\r/g,'').replace(/[ \t]+/g,' ').replace(/\n\s+/g,'\n').trim()}
function blocks(xml,tag){const re=new RegExp(`<(?:(?:\\w+):)?${tag}\\b[^>]*>([\\s\\S]*?)<\\/(?:(?:\\w+):)?${tag}>`,'gi');return[...String(xml).matchAll(re)].map(m=>m[1])}
function tagValues(xml,tag){const re=new RegExp(`<(?:(?:\\w+):)?${tag}\\b[^>]*>([\\s\\S]*?)<\\/(?:(?:\\w+):)?${tag}>`,'gi');return[...String(xml).matchAll(re)].map(m=>cleanText(m[1])).filter(Boolean)}
function tagValue(xml,tag){return tagValues(xml,tag)[0]||''}
function attrValues(xml,tag,attr){const re=new RegExp(`<(?:(?:\\w+):)?${tag}\\b[^>]*\\b${attr}=["']([^"']+)["'][^>]*>`,'gi');return[...String(xml).matchAll(re)].map(m=>decodeXml(m[1])).filter(Boolean)}
function safeDate(v){if(v===null||v===undefined||v==='')return undefined;let raw=v;if(typeof raw==='string'&&/^\d{10,13}$/.test(raw.trim()))raw=Number(raw);if(typeof raw==='number'&&Number.isFinite(raw))raw=raw<1e12?raw*1000:raw;const d=new Date(raw);return Number.isFinite(d.getTime())?d.toISOString():undefined}
function normalize(value=''){return String(value).normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9]+/g,' ').trim()}
function directCountryCode(value=''){
 const raw=String(value||'').trim();if(!raw)return'';const upper=raw.toUpperCase();if(/^[A-Z]{2}$/.test(upper))return upper==='UK'?'GB':upper;
 const key=normalize(raw).toUpperCase();return COUNTRY_ALIASES[key]||COUNTRY_ALIASES[key.replace(/ /g,'')]||'';
}
function namedCountryHeuristic(name='',region=''){
 const text=normalize(`${name} ${region}`);
 if(/cagliari|sardegna|sardinia|sardinien|italia|italien|italy/.test(text))return'IT';
 return'';
}
function coordinateCountryFallback(lat,lon){
 // Nur konservative Rückfälle: breite Länder-Rechtecke würden Grenzregionen falsch zuordnen.
 if(lat>=38.75&&lat<=41.4&&lon>=8.0&&lon<=9.95)return'IT'; // Sardinien
 if(lat>=24&&lat<=50&&lon>=-125&&lon<=-66)return'US';
 return'';
}
async function resolveCountryCode(value,lat,lon,name='',region=''){
 const direct=directCountryCode(value);if(direct)return direct;
 const named=namedCountryHeuristic(name,region);if(named)return named;
 try{
  const u=new URL(BIGDATA_REVERSE);u.searchParams.set('latitude',String(lat));u.searchParams.set('longitude',String(lon));u.searchParams.set('localityLanguage','en');
  const data=await fetchJson(u.toString());const reverse=directCountryCode(data?.countryCode||data?.countryName);if(reverse)return reverse;
 }catch{}
 return coordinateCountryFallback(lat,lon);
}
const AREA_TERM_GROUPS=[['sardegna','sardinia','sardinien']];
function termsFor(...values){
 const terms=values.flatMap(v=>normalize(v).split(/\s+/)).filter(x=>x.length>=3&&!['stadt','gemeinde','bezirk','landkreis','kreis','region','bundesland'].includes(x));
 const expanded=new Set(terms);for(const group of AREA_TERM_GROUPS)if(group.some(x=>expanded.has(x)))for(const x of group)expanded.add(x);return[...expanded];
}
function pointInRing(lat,lon,ring){let inside=false;for(let i=0,j=ring.length-1;i<ring.length;j=i++){const xi=Number(ring[i]?.[0]),yi=Number(ring[i]?.[1]),xj=Number(ring[j]?.[0]),yj=Number(ring[j]?.[1]);if(![xi,yi,xj,yj].every(Number.isFinite))continue;const hit=((yi>lat)!==(yj>lat))&&(lon<(xj-xi)*(lat-yi)/((yj-yi)||1e-12)+xi);if(hit)inside=!inside}return inside}
function pointInPolygonCoords(lat,lon,rings){if(!Array.isArray(rings)||!rings.length||!pointInRing(lat,lon,rings[0]))return false;return !rings.slice(1).some(r=>pointInRing(lat,lon,r))}
function pointInGeometry(lat,lon,g){if(!g)return false;if(g.type==='Polygon')return pointInPolygonCoords(lat,lon,g.coordinates);if(g.type==='MultiPolygon')return(g.coordinates||[]).some(p=>pointInPolygonCoords(lat,lon,p));if(g.type==='GeometryCollection')return(g.geometries||[]).some(x=>pointInGeometry(lat,lon,x));return false}
function parseCapPolygon(value){return String(value).trim().split(/\s+/).map(pair=>pair.split(',').map(Number)).filter(x=>x.length>=2&&x.every(Number.isFinite)).map(([lat,lon])=>[lon,lat])}
function parseCircle(value){const m=String(value).trim().match(/^(-?\d+(?:\.\d+)?),(-?\d+(?:\.\d+)?)\s+([\d.]+)$/);return m?{lat:Number(m[1]),lon:Number(m[2]),radiusKm:Number(m[3])}:null}
function localMatch(xml,lat,lon,name='',region='',district=''){
 const polygons=tagValues(xml,'polygon').map(parseCapPolygon).filter(x=>x.length>=3);if(polygons.some(p=>pointInRing(lat,lon,p)))return true;
 const circles=tagValues(xml,'circle').map(parseCircle).filter(Boolean);if(circles.some(c=>distance(lat,lon,c.lat,c.lon)<=c.radiusKm*1000))return true;
 if(polygons.length||circles.length)return false;
 const area=normalize(tagValues(xml,'areaDesc').join(' ')),terms=termsFor(name,region,district);return terms.some(t=>area.includes(t));
}
function awarenessLevel(xml,severity,explicit){
 const direct=String(explicit??'').toLowerCase();if(['purple','red','orange','yellow'].includes(direct))return direct;
 const n=Number(explicit);if(Number.isFinite(n)){if(n>=4)return'purple';if(n===3)return'red';if(n===2)return'orange';if(n===1)return'yellow'}
 const params=blocks(xml,'parameter');let raw='';for(const p of params){const key=tagValue(p,'valueName').toLowerCase();if(key.includes('awareness_level')||key==='warnlevel'||key.includes('warning level')){raw=tagValue(p,'value');break}}
 const digit=String(raw).match(/\b([1-4])\b/)?.[1];if(digit==='4')return String(raw).toLowerCase().includes('red')?'red':'purple';if(digit==='3')return String(raw).toLowerCase().includes('orange')?'orange':'red';if(digit==='2')return String(raw).toLowerCase().includes('yellow')?'yellow':'orange';if(digit==='1')return'yellow';
 const s=String(severity||'').toLowerCase();if(s==='extreme')return'purple';if(s==='severe')return'red';if(s==='moderate')return'orange';if(s==='minor')return'yellow';return'unknown';
}
function bestInfo(xml,language='de'){
 const infos=blocks(xml,'info');if(!infos.length)return xml;const lang=String(language||'de').toLowerCase();
 return infos.find(x=>tagValue(x,'language').toLowerCase().startsWith(lang))||infos.find(x=>tagValue(x,'language').toLowerCase().startsWith('de'))||infos.find(x=>tagValue(x,'language').toLowerCase().startsWith('en'))||infos[0];
}
function parseCap(xml,source,url,lat,lon,name,region,district,language='de'){
 const status=tagValue(xml,'status'),msgType=tagValue(xml,'msgType');if(status&&status.toLowerCase()!=='actual')return null;if(msgType&&['cancel','error'].includes(msgType.toLowerCase()))return null;
 const info=bestInfo(xml,language),expires=safeDate(tagValue(info,'expires')||tagValue(xml,'expires'));if(expires&&new Date(expires).getTime()<Date.now())return null;
 const combined=`${xml}\n${info}`;if(!localMatch(combined,lat,lon,name,region,district))return null;
 const headline=tagValue(info,'headline')||tagValue(info,'event')||tagValue(xml,'title');if(!headline)return null;
 const severity=tagValue(info,'severity'),description=tagValue(info,'description')||tagValue(xml,'description')||tagValue(xml,'summary'),instruction=tagValue(info,'instruction');
 return{id:tagValue(xml,'identifier')||tagValue(xml,'guid')||url||headline,headline,description:description||'Für diese amtliche Warnung liegt kein zusätzlicher Meldungstext vor.',instruction:instruction||undefined,level:awarenessLevel(info,severity),severity:severity||undefined,event:tagValue(info,'event')||undefined,source:tagValue(info,'senderName')||source,area:tagValues(info,'areaDesc').join(', ')||undefined,effective:safeDate(tagValue(info,'effective')),onset:safeDate(tagValue(info,'onset')),expires,url:tagValue(info,'web')||url||undefined};
}
function linkObjects(block){const out=[];for(const m of String(block).matchAll(/<(?:(?:\w+):)?link\b([^>]*)\/?\s*>/gi)){const attrs={};for(const a of m[1].matchAll(/([\w:-]+)=["']([^"']*)["']/g))attrs[a[1].toLowerCase()]=decodeXml(a[2]);if(attrs.href)out.push(attrs)}return out}
function capLink(block,base=''){
 const links=linkObjects(block),contentSrc=attrValues(block,'content','src')[0],raw=links.find(x=>String(x.type||'').toLowerCase().includes('cap+xml'))?.href||links.find(x=>/\/api\/v\d+\/warnings\//i.test(x.href||''))?.href||links.find(x=>/cap|\.xml(?:$|\?)/i.test(x.href||''))?.href||contentSrc||links.find(x=>String(x.rel||'').toLowerCase()==='alternate'&&/^https?:/i.test(x.href||''))?.href||links.find(x=>/^https?:/i.test(x.href||''))?.href||tagValues(block,'link').find(x=>/^https?:/i.test(x));
 if(!raw)return'';try{return new URL(raw,base||undefined).toString()}catch{return raw}
}
function embeddedCap(block){
 const decoded=decodeXml(block);const start=decoded.search(/<(?:\w+:)?alert\b/i);if(start<0)return'';return decoded.slice(start);
}
async function fetchText(url,headers={}){const r=await fetch(url,{headers:{'User-Agent':`MID-weather-dashboard/${WORKER_VERSION} (+https://github.com/MeteoMartini/MID)`,...headers},redirect:'follow'});if(!r.ok)throw new Error(`${url} HTTP ${r.status}`);return r.text()}
async function fetchJson(url,headers={}){const r=await fetch(url,{headers:{'User-Agent':`MID-weather-dashboard/${WORKER_VERSION} (+https://github.com/MeteoMartini/MID)`,'Accept':'application/json',...headers},redirect:'follow'});if(!r.ok)throw new Error(`${url} HTTP ${r.status}`);return r.json()}
function dedupeAlerts(alerts){const seen=new Set();return alerts.filter(a=>{const key=a.id||`${a.headline}|${a.expires}`;if(seen.has(key))return false;seen.add(key);return true}).sort((a,b)=>{const order={purple:4,red:3,orange:2,yellow:1,unknown:0};return(order[b.level]??0)-(order[a.level]??0)||String(a.onset||a.effective||'').localeCompare(String(b.onset||b.effective||''))})}
function featureProp(properties,...keys){if(!properties||typeof properties!=='object')return undefined;const map=new Map(Object.entries(properties).map(([k,v])=>[k.toLowerCase(),v]));for(const k of keys){const v=map.get(k.toLowerCase());if(v!==undefined&&v!==null&&v!=='')return v}return undefined}
function dwdColorLevel(value){const rgb=String(value||'').match(/\d+(?:\.\d+)?/g)?.slice(0,3).map(Number);if(!rgb||rgb.length<3)return undefined;const[r,g,b]=rgb;if((b>120&&b>g)||(r>170&&b>130&&g<190))return'purple';if(r>190&&g<110)return'red';if(r>190&&g>=110&&g<220)return'orange';if(r>170&&g>=170)return'yellow';return undefined}
function dwdFeatureAlert(feature){
 const p=feature?.properties??{},expires=safeDate(featureProp(p,'EXPIRES'));if(expires&&new Date(expires).getTime()<Date.now())return null;
 const status=String(featureProp(p,'STATUS')||'Actual').toLowerCase(),msgType=String(featureProp(p,'MSGTYPE')||'Alert').toLowerCase();if(status!=='actual'||['cancel','error'].includes(msgType))return null;
 const headline=String(featureProp(p,'HEADLINE','EVENT')||'Amtliche Wetterwarnung'),severity=String(featureProp(p,'SEVERITY')||'');
 return{id:String(featureProp(p,'IDENTIFIER')||feature?.id||headline),headline,description:cleanText(String(featureProp(p,'DESCRIPTION')||'Für diese amtliche Warnung liegt kein zusätzlicher Meldungstext vor.')),instruction:cleanText(String(featureProp(p,'INSTRUCTION')||''))||undefined,level:awarenessLevel('',severity,dwdColorLevel(featureProp(p,'EC_AREA_COLOR'))||featureProp(p,'WARNLEVEL','WARNING_LEVEL','LEVEL')),severity:severity||undefined,event:String(featureProp(p,'EVENT')||'')||undefined,source:String(featureProp(p,'SENDERNAME','CONTACT')||'Deutscher Wetterdienst (DWD)'),area:String(featureProp(p,'NAME','AREADESC')||'')||undefined,effective:safeDate(featureProp(p,'EFFECTIVE','SENT')),onset:safeDate(featureProp(p,'ONSET')),expires,url:String(featureProp(p,'WEB')||'https://www.dwd.de/warnungen')};
}
async function dwdWfsFrom(base,lat,lon){
 const delta=.025,u=new URL(base);u.searchParams.set('service','WFS');u.searchParams.set('version','2.0.0');u.searchParams.set('request','GetFeature');u.searchParams.set('typeName','dwd:Warnungen_Gemeinden');u.searchParams.set('outputFormat','application/json');u.searchParams.set('CRS','CRS:84');u.searchParams.set('srsName','CRS:84');u.searchParams.set('bbox',`${(lon-delta).toFixed(5)},${(lat-delta).toFixed(5)},${(lon+delta).toFixed(5)},${(lat+delta).toFixed(5)},CRS:84`);
 const data=await fetchJson(u.toString()),features=Array.isArray(data?.features)?data.features:[];
 const exact=features.filter(f=>pointInGeometry(lat,lon,f.geometry));return dedupeAlerts((exact.length?exact:features.filter(f=>{const b=f?.bbox;return Array.isArray(b)&&b.length>=4&&lon>=Number(b[0])&&lon<=Number(b[2])&&lat>=Number(b[1])&&lat<=Number(b[3])})).map(dwdFeatureAlert).filter(Boolean));
}
async function dwdWfsAlerts(lat,lon){let lastError;for(const base of[DWD_WFS_PRIMARY,DWD_WFS_BACKUP]){try{return{alerts:await dwdWfsFrom(base,lat,lon),endpoint:base}}catch(e){lastError=e}}throw lastError||new Error('DWD-WFS nicht erreichbar')}
function entryScore(item,name,region,district){const text=normalize(cleanText(item)),terms=termsFor(name,district,region);let score=0;for(const t of terms){if(text.includes(t))score+=t===normalize(name)?12:5}if(tagValues(item,'polygon').length||tagValues(item,'circle').length)score+=20;const updated=safeDate(tagValue(item,'updated')||tagValue(item,'published')||tagValue(item,'sent'));if(updated)score+=Math.max(0,5-(Date.now()-new Date(updated).getTime())/86400000);return score}
async function capFeedAlerts(feedUrl,source,lat,lon,name,region,district,language='de',maxDocuments=24){
 const xml=await fetchText(feedUrl),rawItems=blocks(xml,'entry').length?blocks(xml,'entry'):blocks(xml,'item'),items=rawItems.map((item,index)=>({item,index,score:entryScore(item,name,region,district),link:capLink(item,feedUrl),embedded:embeddedCap(item)})).sort((a,b)=>b.score-a.score||a.index-b.index),alerts=[],candidates=[];
 for(const x of items){
  const directXml=x.embedded||x.item,direct=parseCap(directXml,source,x.link,lat,lon,name,region,district,language);if(direct){alerts.push(direct);continue}
  if(x.link)candidates.push(x);
 }
 for(let i=0;i<Math.min(candidates.length,maxDocuments);i+=6){const batch=candidates.slice(i,i+6);const results=await Promise.allSettled(batch.map(async x=>{const capXml=await fetchText(x.link,{'Accept':'application/cap+xml, application/xml, text/xml, application/atom+xml;q=0.8, */*;q=0.5'});return parseCap(embeddedCap(capXml)||capXml,source,x.link,lat,lon,name,region,district,language)}));for(const r of results)if(r.status==='fulfilled'&&r.value)alerts.push(r.value)}
 return dedupeAlerts(alerts);
}
async function dwdAlerts(lat,lon,name,region,district,language){
 try{const wfs=await dwdWfsAlerts(lat,lon);return{alerts:wfs.alerts,provider:'Deutscher Wetterdienst (DWD)',coverage:'Deutschland · amtliche DWD-WFS-Warnungen auf Gemeindeebene',sourceStatus:{primary:'DWD WFS',endpoint:wfs.endpoint}}}
 catch(wfsError){const alerts=await capFeedAlerts(DWD_CAP_FEED,'Deutscher Wetterdienst (DWD)',lat,lon,name,region,district,language,16);return{alerts,provider:'Deutscher Wetterdienst (DWD)',coverage:'Deutschland · amtliche DWD-CAP-Warnungen (Fallback)',sourceStatus:{primary:'DWD CAP',fallbackReason:wfsError instanceof Error?wfsError.message:String(wfsError)}}}
}
async function nwsAlerts(lat,lon){
 const u=new URL(NWS_ALERTS);u.searchParams.set('point',`${lat.toFixed(4)},${lon.toFixed(4)}`);u.searchParams.set('status','actual');u.searchParams.set('message_type','alert,update');
 const d=await fetchJson(u.toString(),{'Accept':'application/geo+json'});return(d.features??[]).map(f=>{const p=f.properties??{},severity=String(p.severity||'');return{id:String(p.id||f.id||p.headline),headline:String(p.headline||p.event||'Amtliche Wetterwarnung'),description:String(p.description||'Für diese amtliche Warnung liegt kein zusätzlicher Meldungstext vor.'),instruction:p.instruction||undefined,level:awarenessLevel('',severity),severity,event:p.event||undefined,source:p.senderName||'NOAA / National Weather Service',area:p.areaDesc||undefined,effective:safeDate(p.effective),onset:safeDate(p.onset),expires:safeDate(p.expires),url:p['@id']||f.id||undefined}});
}
async function officialAlerts(lat,lon,country,name,region,district,language){
 const c=await resolveCountryCode(country,lat,lon,name,region);if(c==='DE'){const result=await dwdAlerts(lat,lon,name,region,district,language);return{...result,countryCode:c}}
 if(c==='US'){const alerts=await nwsAlerts(lat,lon);return{alerts:dedupeAlerts(alerts),provider:'NOAA / National Weather Service',coverage:'USA · amtliche CAP-Warnungen',countryCode:c}}
 const slug=FEED_SLUGS[c];if(slug){const url=`${METEOALARM_FEEDS}meteoalarm-legacy-atom-${slug}`,alerts=await capFeedAlerts(url,'MeteoAlarm / nationale Wetterbehörde',lat,lon,name,region,district,language,30);return{alerts,provider:'MeteoAlarm / nationale Wetterbehörde',coverage:`Europa · amtliche CAP-Warnungen · ${c}`,countryCode:c,sourceStatus:{primary:'MeteoAlarm Atom/CAP',endpoint:url}}}
 return{alerts:[],provider:'CAP',coverage:'Das Land konnte nicht sicher bestimmt werden oder besitzt keinen im öffentlichen MID-Proxy hinterlegten amtlichen CAP-Feed.',countryCode:c||undefined};
}


function konradTimestamp(filename=''){
 const match=String(filename).match(/KONRAD3D_(\d{8})T(\d{6})\.xml$/i);if(!match)return undefined;
 const date=match[1],time=match[2],value=Date.UTC(Number(date.slice(0,4)),Number(date.slice(4,6))-1,Number(date.slice(6,8)),Number(time.slice(0,2)),Number(time.slice(2,4)),Number(time.slice(4,6)));return Number.isFinite(value)?value:undefined;
}
function latestKonradFilename(indexHtml){
 const now=Date.now(),names=[...String(indexHtml).matchAll(/KONRAD3D_\d{8}T\d{6}\.xml/gi)].map(match=>match[0]),unique=[...new Set(names)].map(name=>({name,time:konradTimestamp(name)})).filter(item=>Number.isFinite(item.time)&&item.time<=now+10*60000&&item.time>=now-36*3600000).sort((a,b)=>b.time-a.time);return unique[0];
}
function tagNumber(xml,tag){const value=number(tagValue(xml,tag));return value!==undefined&&value>-999000000?value:undefined}
function konradFeatureMatches(xml){return[...String(xml).matchAll(/<(?:(?:\w+):)?feature\b([^>]*)>([\s\S]*?)<\/(?:(?:\w+):)?feature>/gi)]}
function konradAttribute(attrs,name){return decodeXml(String(attrs||'').match(new RegExp(`\\b${name}=["']([^"']+)["']`,'i'))?.[1]||'')}
function konradForecasts(feature,lat,lon,referenceMs){
 const rows=[];for(const match of String(feature).matchAll(/<(?:(?:\w+):)?centroid_forecast\b([^>]*)>([\s\S]*?)<\/(?:(?:\w+):)?centroid_forecast>/gi)){
  const time=safeDate(konradAttribute(match[1],'forecast_time')),timeMs=time?Date.parse(time):NaN,minutes=Number.isFinite(timeMs)?Math.round((timeMs-referenceMs)/60000):NaN,block=match[2],coordinate=blocks(block,'geodetic_coordinate')[0]||block,clat=tagNumber(coordinate,'latitude'),clon=tagNumber(coordinate,'longitude'),ellipse=blocks(block,'uncertainty_ellipse')[0]||'',majorAxis=Math.max(0,tagNumber(ellipse,'major_axis')||0);
  if(clat===undefined||clon===undefined||!Number.isFinite(minutes)||minutes<0||minutes>90)continue;const rawDistanceKm=distance(lat,lon,clat,clon)/1000;rows.push({time,minutes,latitude:clat,longitude:clon,distanceKm:rawDistanceKm,effectiveDistanceKm:Math.max(0,rawDistanceKm-majorAxis),uncertaintyKm:majorAxis});
 }
 return rows.sort((a,b)=>a.minutes-b.minutes);
}
function parseKonradCells(xml,lat,lon,observedAt){
 const referenceMs=Date.parse(observedAt),cells=[];for(const match of konradFeatureMatches(xml)){
  const attrs=match[1],feature=match[2],geometry=blocks(feature,'geometry')[0]||feature,centroid=blocks(geometry,'centroid_3d')[0]||geometry,coordinate=blocks(centroid,'geodetic_coordinate')[0]||centroid,clat=tagNumber(coordinate,'latitude'),clon=tagNumber(coordinate,'longitude');if(clat===undefined||clon===undefined)continue;
  const intensity=blocks(feature,'intensity')[0]||feature,hymec=blocks(feature,'hymec')[0]||'',lightning=blocks(feature,'lightning')[0]||'',tracking=blocks(feature,'tracking')[0]||'',currentDistanceKm=distance(lat,lon,clat,clon)/1000,forecasts=konradForecasts(feature,lat,lon,referenceMs),bestForecast=forecasts.reduce((best,row)=>!best||row.effectiveDistanceKm<best.effectiveDistanceKm?row:best,undefined),relevanceDistanceKm=Math.min(currentDistanceKm,bestForecast?.effectiveDistanceKm??Infinity),arrivalMinutes=currentDistanceKm<=20?0:bestForecast&&bestForecast.effectiveDistanceKm<=30?bestForecast.minutes:undefined;
  const severity=Math.max(0,Math.min(3,Math.round(tagNumber(intensity,'severity')||0))),trend=Math.max(-2,Math.min(2,Math.round(tagNumber(intensity,'severity_trend_category')||0))),hailFlag=Math.max(0,Math.min(3,Math.round(tagNumber(intensity,'hail_flag')||0))),heavyRainFlag=Math.max(0,Math.min(3,Math.round(tagNumber(intensity,'heavy_rain_flag')||0))),gustFlagRaw=tagNumber(intensity,'gust_flag'),gustFlag=gustFlagRaw===undefined?undefined:Math.max(0,Math.min(3,Math.round(gustFlagRaw))),lightningRate=Math.max(0,tagNumber(lightning,'lightning_rate')||0),areaHail=Math.max(0,tagNumber(hymec,'area_hail')||0),areaLargeHail=Math.max(0,tagNumber(hymec,'area_large_hail')||0),speedKmh=Math.max(0,tagNumber(tracking,'cell_speed')||0);
  cells.push({id:konradAttribute(attrs,'identifier')||tagValue(feature,'identifier')||`cell-${cells.length+1}`,latitude:clat,longitude:clon,currentDistanceKm,relevanceDistanceKm,forecastDistanceKm:bestForecast?.distanceKm,forecastEffectiveDistanceKm:bestForecast?.effectiveDistanceKm,forecastTime:bestForecast?.time,arrivalMinutes,isApproaching:Boolean(bestForecast&&bestForecast.effectiveDistanceKm+2<currentDistanceKm),severity,trend,hailFlag,heavyRainFlag,gustFlag,lightningRate,areaHail,areaLargeHail,speedKmh});
 }
 return cells.sort((a,b)=>a.relevanceDistanceKm-b.relevanceDistanceKm);
}
async function dwdKonrad3dNowcast(lat,lon,country=''){
 const countryCode=directCountryCode(country),coverage=countryCode==='DE'||(!countryCode&&inGermanyBounds(lat,lon));if(!coverage)return{available:false,coverage:false,provider:'DWD KONRAD3D',summary:'KONRAD3D ist auf das deutsche Radarverbundgebiet ausgerichtet.',cellsFound:0,nearbyCells:[]};
 const index=await fetchText(DWD_KONRAD3D_INDEX,{'Accept':'text/html,application/xhtml+xml'}),latest=latestKonradFilename(index);if(!latest)throw new Error('Kein aktuelles KONRAD3D-Produkt gefunden.');
 const observedAt=new Date(latest.time).toISOString(),ageMinutes=Math.round((Date.now()-latest.time)/60000);if(ageMinutes>35)return{available:false,coverage:true,temporaryUnavailable:true,provider:'DWD KONRAD3D',observedAt,ageMinutes,summary:'Der letzte KONRAD3D-Datenstand ist veraltet.',cellsFound:0,nearbyCells:[]};
 const xml=await fetchText(new URL(latest.name,DWD_KONRAD3D_INDEX).toString(),{'Accept':'application/xml,text/xml,*/*'}),cells=parseKonradCells(xml,lat,lon,observedAt),nearbyCells=cells.filter(cell=>cell.relevanceDistanceKm<=80).slice(0,8),nearest=nearbyCells[0];
 return{available:true,coverage:true,provider:'DWD KONRAD3D',product:'Objektbasierte Konvektionszellen',observedAt,ageMinutes,cellsFound:cells.length,nearbyCells,nearest,summary:nearest?`Nächste relevante Konvektionszelle in ${Math.round(nearest.relevanceDistanceKm)} km.`:'Keine relevante KONRAD3D-Zelle im 80-km-Umfeld.',temporalResolutionMinutes:5,license:'DWD Open Data',diagnostics:{filename:latest.name,parsedCells:cells.length}};
}

function stationSiteClass(name='',provider=''){
 const text=normalize(`${name} ${provider}`);if(/innenstadt|stadtmitte|city center|urban/.test(text))return'urban';if(/vorstadt|suburban/.test(text))return'suburban';if(/flughafen|airport|flugplatz|feld|warte|berg|gipfel|forst|wald/.test(text))return'rural';return'unknown';
}
function inGermanyBounds(lat,lon){return lat>=47.0&&lat<=55.3&&lon>=5.4&&lon<=15.7}
function radolanYwTimestamp(filename){const match=String(filename).match(/^raa01-yw_10000-(\d{10})-dwd---bin\.hdf5$/i);if(!match)return undefined;const value=match[1],year=2000+Number(value.slice(0,2)),month=Number(value.slice(2,4))-1,day=Number(value.slice(4,6)),hour=Number(value.slice(6,8)),minute=Number(value.slice(8,10)),time=Date.UTC(year,month,day,hour,minute);return Number.isFinite(time)?time:undefined}
function radolanYwProxyUrl(request,filename){const url=new URL(request.url);url.search='';url.searchParams.set('mode','radolan-yw-file');url.searchParams.set('file',filename);return url.toString()}
async function radolanYwMetadata(request,lat,lon){if(!inGermanyBounds(lat,lon))return{coverage:false,provider:'DWD RADOLAN',product:'YW',frames:[],summary:'Außerhalb des deutschen RADOLAN-Rasters.'};const html=await fetchText(DWD_RADOLAN_YW_ROOT,{Accept:'text/html,application/xhtml+xml'}),now=Date.now(),files=[...html.matchAll(/href=["'](raa01-yw_10000-\d{10}-dwd---bin\.hdf5)["']/gi)].map(match=>match[1]).map(name=>({name,time:radolanYwTimestamp(name)})).filter(item=>Number.isFinite(item.time)&&item.time<=now+10*60000&&item.time>=now-8*3600000).sort((a,b)=>a.time-b.time);const frames=files.slice(-76).map(item=>({time:new Date(item.time).toISOString(),fileUrl:radolanYwProxyUrl(request,item.name)}));if(!frames.length)throw new Error('Keine aktuellen RADOLAN-YW-Dateien gefunden.');return{coverage:true,provider:'DWD RADOLAN',product:'YW – quasi-angeeichte 5-Minuten-Niederschlagshöhe',observedAt:frames.at(-1).time,temporalResolutionMinutes:5,nativeResolutionKm:1,license:'DWD Open Data',frames}}
async function radolanYwFileResponse(request){const url=new URL(request.url),filename=String(url.searchParams.get('file')||''),time=radolanYwTimestamp(filename);if(!time||Math.abs(Date.now()-time)>9*3600000)return json({error:'Ungültige oder veraltete RADOLAN-YW-Datei.',version:WORKER_VERSION},400,{'cache-control':'no-store'});const upstream=new URL(filename,DWD_RADOLAN_YW_ROOT).toString(),response=await fetch(upstream,{headers:{Accept:'application/x-hdf5,application/octet-stream,*/*','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`},cf:{cacheTtl:21600,cacheEverything:true}});if(!response.ok)return json({error:`DWD RADOLAN YW HTTP ${response.status}`,version:WORKER_VERSION},response.status,{'cache-control':'no-store'});return new Response(response.body,{status:200,headers:{'content-type':'application/x-hdf5','content-disposition':`inline; filename="${filename}"`,'access-control-allow-origin':'*','cache-control':'public, max-age=21600','x-mid-worker-version':WORKER_VERSION,'x-mid-source':'DWD RADOLAN YW'}})}
function kostraDurationCode(value){const duration=Number(value);return duration===30?'D00030':duration===60?'D00060':duration===360?'D00360':''}
async function kostraFileResponse(request){const url=new URL(request.url),code=kostraDurationCode(url.searchParams.get('duration'));if(!code)return json({error:'KOSTRA-Dauer muss 30, 60 oder 360 Minuten betragen.',version:WORKER_VERSION},400,{'cache-control':'no-store'});const filename=`StatRR_KOSTRA-DWD-2020_${code}_ASC.zip`,upstream=new URL(filename,DWD_KOSTRA_ASC_ROOT).toString(),response=await fetch(upstream,{headers:{Accept:'application/zip,application/octet-stream,*/*','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`},cf:{cacheTtl:604800,cacheEverything:true}});if(!response.ok)return json({error:`DWD KOSTRA HTTP ${response.status}`,version:WORKER_VERSION},response.status,{'cache-control':'no-store'});return new Response(response.body,{status:200,headers:{'content-type':'application/zip','content-disposition':`inline; filename="${filename}"`,'access-control-allow-origin':'*','cache-control':'public, max-age=604800','x-mid-worker-version':WORKER_VERSION,'x-mid-source':'KOSTRA-DWD-2020'}})}
function offsetKm(lat,lon,northKm,eastKm){return{lat:lat+northKm/111,lon:lon+eastKm/(111*Math.max(.25,Math.cos(lat*Math.PI/180)))}}
async function brightSkyRows(lat,lon,radiusKm){
 if(!inGermanyBounds(lat,lon))return[];
 const reach=Math.min(48,Math.max(14,radiusKm*.42)),points=[[0,0],[reach*.33,0],[-reach*.33,0],[0,reach*.33],[0,-reach*.33],[reach*.7,reach*.35],[reach*.7,-reach*.35],[-reach*.7,reach*.35],[-reach*.7,-reach*.35]].map(([n,e])=>offsetKm(lat,lon,n,e));
 const settled=await Promise.allSettled(points.map(async point=>{const u=new URL(BRIGHTSKY_CURRENT);u.searchParams.set('lat',point.lat.toFixed(5));u.searchParams.set('lon',point.lon.toFixed(5));u.searchParams.set('max_dist',String(Math.round(Math.min(90000,radiusKm*1000))));return fetchJson(u.toString())}));
 const rows=[],seen=new Set();for(const result of settled){if(result.status!=='fulfilled')continue;const d=result.value,w=d?.weather,sources=Array.isArray(d?.sources)?d.sources:[];if(!w)continue;const source=sources.find(x=>String(x?.id??x?.source_id)===String(w?.source_id))||sources[0]||{},slat=number(source?.lat??source?.latitude),slon=number(source?.lon??source?.longitude);if(slat===undefined||slon===undefined)continue;const id=String(source?.dwd_station_id??source?.wmo_station_id??source?.id??`${slat.toFixed(4)}:${slon.toFixed(4)}`);if(seen.has(id))continue;seen.add(id);const dist=distance(lat,lon,slat,slon);if(dist>radiusKm*1000)continue;const temp=number(w?.temperature);if(temp===undefined)continue;rows.push({stationId:id,name:source?.station_name??source?.name??`DWD ${id}`,lat:slat,lon:slon,elevation:number(source?.height??source?.elevation),reportTime:safeDate(w?.timestamp??w?.observation_time),temp,dewp:number(w?.dew_point),relativeHumidity:number(w?.relative_humidity),pressureMsl:number(w?.pressure_msl),windDirection:number(w?.wind_direction_10??w?.wind_direction),windSpeed:number(w?.wind_speed_10??w?.wind_speed),windGust:number(w?.wind_gust_speed_10??w?.wind_gust_speed),cloudCover:number(w?.cloud_cover),precipitation:number(w?.precipitation_10??w?.precipitation),provider:'DWD Open Data / Bright Sky',distance:dist,windUnit:'kmh',qcStatus:2,trustFactor:98,networkClass:'official',siteClass:stationSiteClass(source?.station_name??source?.name,source?.observation_type??'DWD')});}
 return rows.sort((a,b)=>a.distance-b.distance).slice(0,18);
}
function senseMetricKey(title='',unit=''){const text=normalize(`${title} ${unit}`);if(/temperatur|temperature|lufttemperatur|air temp/.test(text)&&!/boden|soil|wasser|water/.test(text))return'temp';if(/luftfeuchte|humidity|relative humidity/.test(text))return'relativeHumidity';if(/taupunkt|dew point/.test(text))return'dewp';return''}
async function openSenseMapRows(lat,lon,radiusKm){
 const radius=Math.min(22,Math.max(6,radiusKm*.18)),dLat=radius/111,dLon=radius/(111*Math.max(.25,Math.cos(lat*Math.PI/180))),u=new URL(OPENSENSEMAP_BOXES);u.searchParams.set('bbox',`${(lon-dLon).toFixed(5)},${(lat-dLat).toFixed(5)},${(lon+dLon).toFixed(5)},${(lat+dLat).toFixed(5)}`);u.searchParams.set('exposure','outdoor');u.searchParams.set('minimal','false');
 const raw=await fetchJson(u.toString()),boxes=Array.isArray(raw)?raw:Array.isArray(raw?.data)?raw.data:[],rows=[];
 for(const box of boxes.slice(0,120)){const coords=box?.currentLocation?.coordinates??box?.loc??box?.location?.coordinates,slon=number(coords?.[0]??box?.lon),slat=number(coords?.[1]??box?.lat);if(slat===undefined||slon===undefined)continue;const dist=distance(lat,lon,slat,slon);if(dist>radius*1000)continue;const row={stationId:String(box?._id??box?.id??`${slat}:${slon}`),name:String(box?.name??box?.title??'senseBox'),lat:slat,lon:slon,elevation:number(coords?.[2]??box?.elevation),provider:'openSenseMap / senseBox (ODbL)',distance:dist,windUnit:'kmh',qcStatus:1,trustFactor:42,networkClass:'citizen',siteClass:'unknown'};let newest=0;
  for(const sensor of Array.isArray(box?.sensors)?box.sensors:[]){const measurement=sensor?.lastMeasurement??sensor?.last_measurement??{},value=number(measurement?.value??sensor?.value),timestamp=safeDate(measurement?.createdAt??measurement?.timestamp??sensor?.updatedAt),key=senseMetricKey(sensor?.title??sensor?.phenomenon,sensor?.unit);if(!key||value===undefined||!timestamp)continue;const age=Date.now()-new Date(timestamp).getTime();if(age<0||age>50*60000)continue;if(key==='temp'&&(value<-45||value>55))continue;if(key==='relativeHumidity'&&(value<0||value>100))continue;if(key==='dewp'&&(value<-60||value>40))continue;row[key]=value;newest=Math.max(newest,new Date(timestamp).getTime());}
  if(number(row.temp)===undefined)continue;row.reportTime=new Date(newest).toISOString();rows.push(row);
 }
 return rows.sort((a,b)=>a.distance-b.distance).slice(0,32);
}
function awcMetarBboxes(lat,lon,radiusKm){
 const dLat=radiusKm/111,dLon=radiusKm/(111*Math.max(.25,Math.cos(lat*Math.PI/180))),lat0=Math.max(-89.9,lat-dLat),lat1=Math.min(89.9,lat+dLat),lon0=lon-dLon,lon1=lon+dLon,box=(a,b,c,d)=>[a,b,c,d].map(value=>Number(value).toFixed(3)).join(',');
 if(lon0>=-180&&lon1<=180)return[box(lat0,lon0,lat1,lon1)];
 if(lon0<-180)return[box(lat0,lon0+360,lat1,180),box(lat0,-180,lat1,lon1)];
 return[box(lat0,lon0,lat1,180),box(lat0,-180,lat1,lon1-360)];
}
function metarReportTime(row){const value=safeDate(row?.reportTime??row?.obsTime??row?.observation_time??row?.receiptTime);return value?Date.parse(value):0}
function latestMetarRows(rows){const map=new Map();for(const row of rows){const key=String(row?.icaoId??row?.icao_id??row?.station_id??`${row?.lat??row?.latitude}:${row?.lon??row?.longitude}`);const previous=map.get(key);if(!previous||metarReportTime(row)>=metarReportTime(previous))map.set(key,row)}return[...map.values()]}
async function awcMetarBoxRows(bbox){
 const api=new URL(AWC_API);api.searchParams.set('format','json');api.searchParams.set('hours','3');api.searchParams.set('bbox',bbox);
 const response=await fetch(api,{headers:{'User-Agent':`MID-weather-dashboard/${WORKER_VERSION} (+https://github.com/MeteoMartini/MID)`,'Accept':'application/json'},cf:{cacheTtl:60,cacheEverything:true}});
 if(response.status===204)return[];if(!response.ok)throw new Error(`AviationWeather HTTP ${response.status}`);
 const raw=await response.json();return Array.isArray(raw)?raw:raw?.data??[];
}
async function metarRows(lat,lon,radiusKm){
 const settled=await Promise.allSettled(awcMetarBboxes(lat,lon,radiusKm).map(awcMetarBoxRows)),failures=settled.filter(result=>result.status==='rejected');
 if(failures.length===settled.length)throw failures[0].reason;
 const raw=latestMetarRows(settled.flatMap(result=>result.status==='fulfilled'?result.value:[]));
 return raw.map(r=>{const rlat=number(r.lat??r.latitude),rlon=number(r.lon??r.longitude);if(rlat===undefined||rlon===undefined)return null;const dist=distance(lat,lon,rlat,rlon);if(dist>radiusKm*1000)return null;return{icaoId:r.icaoId??r.icao_id??r.station_id,name:r.name??r.site??r.icaoId??r.station_id,lat:rlat,lon:rlon,elevation:number(r.elev??r.elevation??r.elevation_m),reportTime:safeDate(r.reportTime??r.obsTime??r.observation_time??r.receiptTime),temp:number(r.temp??r.temperature??r.temp_c),dewp:number(r.dewp??r.dewPoint??r.dewpoint_c),relativeHumidity:number(r.relativeHumidity??r.humidity),windDirection:number(r.wdir??r.windDirection??r.wind_dir_degrees),windSpeed:number(r.wspd??r.windSpeed??r.wind_speed_kt),windGust:number(r.wgst??r.windGust??r.wind_gust_kt),pressure:number(r.altim??r.pressureMsl??r.sea_level_pressure_mb),visibility:r.visib??r.visibility??r.visibility_statute_mi,cloudCover:number(r.cloudCover),clouds:Array.isArray(r.clouds)?r.clouds:Array.isArray(r.cloudLayers)?r.cloudLayers:undefined,vertVis:number(r.vertVis??r.verticalVisibility),rawOb:r.rawOb??r.raw_text,provider:'NOAA AviationWeather / METAR-WMO',distance:dist,windUnit:'kt',qcStatus:2,trustFactor:92,networkClass:'professional',siteClass:stationSiteClass(r.name??r.site??r.icaoId??r.station_id,'METAR airport')}}).filter(Boolean);
}

let geoSphereMetadataCache={expires:0,stations:[]};
function geoSphereApplies(lat,lon){return lat>=46.35&&lat<=49.05&&lon>=9.45&&lon<=17.3}
function geoSphereStationArray(data){if(Array.isArray(data?.stations))return data.stations;if(Array.isArray(data?.station_metadata))return data.station_metadata;if(Array.isArray(data?.metadata?.stations))return data.metadata.stations;if(Array.isArray(data?.data?.stations))return data.data.stations;return[]}
async function geoSphereMetadata(){
 if(geoSphereMetadataCache.expires>Date.now()&&geoSphereMetadataCache.stations.length)return geoSphereMetadataCache.stations;
 const raw=await fetchJson(GEOSPHERE_META),stations=geoSphereStationArray(raw).map(st=>({id:String(st?.id??st?.station_id??''),name:String(st?.name??st?.station_name??st?.id??'GeoSphere-Station'),lat:number(st?.lat??st?.latitude),lon:number(st?.lon??st?.longitude),elevation:number(st?.altitude??st?.height??st?.elevation),active:st?.is_active!==false})).filter(st=>st.id&&st.active&&st.lat!==undefined&&st.lon!==undefined);
 geoSphereMetadataCache={expires:Date.now()+6*60*60*1000,stations};return stations;
}
function geoSphereLast(value){const raw=value?.data??value?.values??value?.value??value;if(Array.isArray(raw)){for(let i=raw.length-1;i>=0;i--){const n=number(raw[i]);if(n!==undefined)return n}return undefined}return number(raw)}
function geoSphereParam(feature,name){const props=feature?.properties??feature,parameters=props?.parameters??props?.parameter??props;return geoSphereLast(parameters?.[name]??parameters?.[name.toLowerCase()]??parameters?.[name.toUpperCase()])}
function geoSphereFeatureId(feature){const station=feature?.properties?.station;return String(feature?.properties?.station_id??(station&&typeof station==='object'?station.id:station)??feature?.station_id??feature?.id??'')}
function plausibleQff(value,height,stationPressure){const qff=number(value),elevation=number(height),surface=number(stationPressure);if(qff===undefined||qff<870||qff>1085)return false;if(elevation!==undefined&&elevation>=600&&qff<950)return false;if(elevation!==undefined&&surface!==undefined&&elevation>=150){const expectedLift=Math.min(155,Math.max(12,elevation*.055));if(qff-surface<expectedLift)return false}return true}
async function geoSphereRows(lat,lon,radiusKm){
 if(!geoSphereApplies(lat,lon))return[];
 const meta=await geoSphereMetadata(),nearby=meta.map(st=>({...st,distance:distance(lat,lon,st.lat,st.lon)})).filter(st=>st.distance<=Math.min(120,radiusKm)*1000).sort((a,b)=>a.distance-b.distance).slice(0,14);if(!nearby.length)return[];
 const current=new URL(GEOSPHERE_CURRENT);current.searchParams.set('parameters','TL,TP,RF,PRED,P,FF,DD,FFX,RR');current.searchParams.set('station_ids',nearby.map(st=>st.id).join(','));current.searchParams.set('output_format','geojson');
 let raw;try{raw=await fetchJson(current.toString())}catch{current.searchParams.set('parameters','TL,RR,FF');raw=await fetchJson(current.toString())}
 const features=Array.isArray(raw?.features)?raw.features:Array.isArray(raw?.data)?raw.data:Array.isArray(raw)?raw:[],byId=new Map(nearby.map(st=>[st.id,st])),timestamp=safeDate(Array.isArray(raw?.timestamps)?raw.timestamps.at(-1):raw?.timestamp);
 return features.map(feature=>{const id=geoSphereFeatureId(feature),metaStation=byId.get(id),coordinates=feature?.geometry?.coordinates??[],slon=metaStation?.lon??number(coordinates[0]),slat=metaStation?.lat??number(coordinates[1]);if(!metaStation||slat===undefined||slon===undefined)return null;const temp=geoSphereParam(feature,'TL');if(temp===undefined)return null;const stationPressure=geoSphereParam(feature,'P'),pred=geoSphereParam(feature,'PRED'),pressureMsl=plausibleQff(pred,metaStation.elevation,stationPressure)?pred:undefined;return{stationId:id,name:metaStation.name,lat:slat,lon:slon,elevation:metaStation.elevation,reportTime:timestamp??safeDate(feature?.properties?.timestamp),temp,dewp:geoSphereParam(feature,'TP'),relativeHumidity:geoSphereParam(feature,'RF'),pressureMsl,pressure:stationPressure,windSpeed:(()=>{const v=geoSphereParam(feature,'FF');return v===undefined?undefined:v*3.6})(),windDirection:geoSphereParam(feature,'DD'),windGust:(()=>{const v=geoSphereParam(feature,'FFX');return v===undefined?undefined:v*3.6})(),precipitation:geoSphereParam(feature,'RR'),provider:'GeoSphere Austria / TAWES',distance:metaStation.distance,windUnit:'kmh',qcStatus:1}}).filter(Boolean);
}

async function weatherUndergroundRows(lat,lon,radiusKm,apiKey){
 if(!apiKey)return[];
 const near=new URL(TWC_NEAR);near.searchParams.set('geocode',`${lat.toFixed(5)},${lon.toFixed(5)}`);near.searchParams.set('product','pws');near.searchParams.set('format','json');near.searchParams.set('apiKey',apiKey);
 const nr=await fetch(near);if(!nr.ok)return[];const nd=await nr.json(),loc=nd?.location??nd,ids=loc?.stationId??[],rows=[];
 for(let i=0;i<Math.min(8,Array.isArray(ids)?ids.length:0);i++){
  if(Number(at(loc?.qcStatus,i))===0)continue;
  const stationId=String(ids[i]??'');if(!stationId)continue;
  const stationLat=number(at(loc?.latitude,i)),stationLon=number(at(loc?.longitude,i)),dist=number(at(loc?.distanceKm,i));
  if(dist!==undefined&&dist>radiusKm)continue;
  const current=new URL(TWC_PWS);current.searchParams.set('stationId',stationId);current.searchParams.set('format','json');current.searchParams.set('units','m');current.searchParams.set('numericPrecision','decimal');current.searchParams.set('apiKey',apiKey);
  try{
   const cr=await fetch(current);if(!cr.ok)continue;const cd=await cr.json(),o=(cd?.observations??cd?.observation??[])[0]??cd,metric=o?.metric??{};
   rows.push({stationId,name:at(loc?.stationName,i)||stationId,lat:stationLat??number(o?.lat),lon:stationLon??number(o?.lon),elevation:number(o?.elev??o?.elevation),reportTime:o?.obsTimeUtc??o?.obsTimeLocal??at(loc?.updateTimeUtc,i),temp:number(metric?.temp??o?.temp),dewp:number(metric?.dewpt??o?.dewpt),relativeHumidity:number(o?.humidity),windDirection:number(o?.winddir),windSpeed:number(metric?.windSpeed??o?.windSpeed),windGust:number(metric?.windGust??o?.windGust),pressure:number(metric?.pressure??o?.pressure),precipitation:number(metric?.precipTotal??metric?.precipRate),provider:'Weather Underground PWS (lizenzierter API-Zugang)',distance:dist===undefined&&stationLat!==undefined&&stationLon!==undefined?distance(lat,lon,stationLat,stationLon):dist===undefined?undefined:dist*1000,windUnit:'kmh',qcStatus:Number(at(loc?.qcStatus,i))});
  }catch{}
 }
 return rows;
}
function latestNetatmoMeasure(measures){
 const out={timestamp:0};for(const module of Object.values(measures||{})){const types=Array.isArray(module?.type)?module.type:[],res=module?.res&&typeof module.res==='object'?module.res:{},latest=Object.keys(res).map(Number).filter(Number.isFinite).sort((a,b)=>b-a)[0];if(!latest)continue;const values=res[String(latest)]??res[latest]??[];if(latest<out.timestamp)continue;out.timestamp=latest;types.forEach((type,i)=>{const v=number(values?.[i]);if(v!==undefined)out[String(type).toLowerCase()]=v});for(const key of['rain_60min','rain_24h','rain_live','wind_strength','wind_angle','gust_strength','gust_angle']){const v=number(module?.[key]);if(v!==undefined)out[key]=v}}
 return out;
}
async function netatmoRows(lat,lon,radiusKm,accessToken){
 if(!accessToken)return[];const r=Math.min(45,Math.max(8,radiusKm)),dLat=r/111,dLon=r/(111*Math.max(.25,Math.cos(lat*Math.PI/180))),u=new URL(NETATMO_PUBLIC);u.searchParams.set('lat_ne',String(lat+dLat));u.searchParams.set('lon_ne',String(lon+dLon));u.searchParams.set('lat_sw',String(lat-dLat));u.searchParams.set('lon_sw',String(lon-dLon));u.searchParams.set('filter','true');u.searchParams.set('required_data','temperature');
 const response=await fetch(u,{headers:{Authorization:`Bearer ${accessToken}`,Accept:'application/json'}});if(!response.ok)throw new Error(`Netatmo HTTP ${response.status}`);const raw=await response.json(),stations=raw?.body??raw?.data??[];
 return(Array.isArray(stations)?stations:[]).map(st=>{const location=st?.place?.location??st?.location??[],slon=number(location?.[0]??st?.lon),slat=number(location?.[1]??st?.lat);if(slat===undefined||slon===undefined)return null;const dist=distance(lat,lon,slat,slon);if(dist>r*1000)return null;const m=latestNetatmoMeasure(st?.measures),temp=number(m.temperature);if(temp===undefined||!m.timestamp)return null;return{stationId:st?._id??st?.id,name:st?.place?.city||st?.place?.street||'Netatmo PWS',lat:slat,lon:slon,elevation:number(st?.place?.altitude),reportTime:new Date(m.timestamp*1000).toISOString(),temp,relativeHumidity:number(m.humidity),pressure:number(m.pressure),windSpeed:number(m.wind_strength),windDirection:number(m.wind_angle),windGust:number(m.gust_strength),precipitation:number(m.rain_60min??m.rain_live),provider:'Netatmo Weathermap PWS (autorisierter API-Zugang)',distance:dist,windUnit:'kmh',qcStatus:1}}).filter(Boolean).slice(0,35);
}
function synopticObservation(observations,names){for(const name of names){const key=Object.keys(observations||{}).find(k=>k===name||k.startsWith(`${name}_value`));if(!key)continue;const raw=observations[key],value=number(raw?.value??raw?.[0]?.value??raw),date=raw?.date_time??raw?.[0]?.date_time; if(value!==undefined)return{value,date}}return{};}
async function synopticRows(lat,lon,radiusKm,token){
 if(!token)return[];const miles=Math.min(60,Math.max(8,radiusKm))*0.621371,u=new URL(SYNOPTIC_LATEST);u.searchParams.set('token',token);u.searchParams.set('radius',`${lat.toFixed(5)},${lon.toFixed(5)},${miles.toFixed(1)}`);u.searchParams.set('limit','35');u.searchParams.set('within','120');u.searchParams.set('status','active');u.searchParams.set('vars','air_temp,relative_humidity,dew_point_temperature,sea_level_pressure,pressure,wind_speed,wind_direction,wind_gust,precip_accum_one_hour');u.searchParams.set('units','temp|C,speed|kts,pres|mb,height|m,precip|mm');u.searchParams.set('qc','on');u.searchParams.set('qc_checks','synopticlabs');u.searchParams.set('qc_remove_data','on');u.searchParams.set('output','json');
 const response=await fetch(u,{headers:{Accept:'application/json'}});if(!response.ok)throw new Error(`Synoptic HTTP ${response.status}`);const raw=await response.json();if(Number(raw?.SUMMARY?.RESPONSE_CODE)===200)throw new Error('Synoptic-Token nicht autorisiert');
 return(Array.isArray(raw?.STATION)?raw.STATION:[]).map(st=>{const slat=number(st?.LATITUDE),slon=number(st?.LONGITUDE);if(slat===undefined||slon===undefined)return null;const obs=st?.OBSERVATIONS??{},temp=synopticObservation(obs,['air_temp']),hum=synopticObservation(obs,['relative_humidity']),dew=synopticObservation(obs,['dew_point_temperature']),pressure=synopticObservation(obs,['sea_level_pressure','pressure','altimeter']),wind=synopticObservation(obs,['wind_speed']),direction=synopticObservation(obs,['wind_direction']),gust=synopticObservation(obs,['wind_gust']),precip=synopticObservation(obs,['precip_accum_one_hour']),dist=number(st?.DISTANCE)!==undefined?number(st.DISTANCE)*1609.344:distance(lat,lon,slat,slon);if(temp.value===undefined||dist>Math.min(60,radiusKm)*1000)return null;return{stationId:st?.STID,name:st?.NAME||st?.STID,lat:slat,lon:slon,elevation:number(st?.ELEVATION),reportTime:temp.date||hum.date||wind.date,temp:temp.value,dewp:dew.value,relativeHumidity:hum.value,pressure:pressure.value,windSpeed:wind.value,windDirection:direction.value,windGust:gust.value,precipitation:precip.value,provider:`Synoptic Data / MesoWest-MADIS${st?.MNET_ID?` (${st.MNET_ID})`:''}`,distance:dist,windUnit:'kt',qcStatus:st?.QC_FLAGGED?1:2}}).filter(Boolean);
}
async function xweatherRows(lat,lon,radiusKm,clientId,clientSecret){
 if(!clientId||!clientSecret)return[];const u=new URL(XWEATHER_OBS);u.searchParams.set('p',`${lat.toFixed(5)},${lon.toFixed(5)}`);u.searchParams.set('limit','20');u.searchParams.set('filter','pws');u.searchParams.set('client_id',clientId);u.searchParams.set('client_secret',clientSecret);
 const response=await fetch(u,{headers:{Accept:'application/json'}});if(!response.ok)throw new Error(`Xweather HTTP ${response.status}`);const raw=await response.json();if(raw?.success===false)throw new Error(raw?.error?.description||'Xweather-Abruf fehlgeschlagen');const list=Array.isArray(raw?.response)?raw.response:raw?.response?[raw.response]:[];
 return list.map(st=>{const ob=st?.ob??{},slat=number(st?.loc?.lat),slon=number(st?.loc?.long);if(slat===undefined||slon===undefined)return null;const dist=number(st?.relativeTo?.distanceKM)!==undefined?number(st.relativeTo.distanceKM)*1000:distance(lat,lon,slat,slon),trust=number(ob?.trustFactor),qc=number(ob?.QCcode);if(dist>Math.min(60,radiusKm)*1000||qc===0||(trust!==undefined&&trust<65))return null;return{stationId:st?.id,name:st?.place?.name||st?.id,lat:slat,lon:slon,elevation:number(st?.profile?.elevM),reportTime:ob?.dateTimeISO||st?.obDateTime,temp:number(ob?.tempC),dewp:number(ob?.dewpointC),relativeHumidity:number(ob?.humidity),pressure:number(ob?.pressureMB),windSpeed:number(ob?.windSpeedKTS),windDirection:number(ob?.windDirDEG),windGust:number(ob?.windGustKTS),cloudCover:number(ob?.sky),precipitation:number(ob?.precipMM),provider:`Xweather Observations${st?.dataSource?` / ${st.dataSource}`:''} (lizenzierter API-Zugang)`,distance:dist,windUnit:'kt',qcStatus:qc===undefined?1:qc>0?2:0,trustFactor:trust}}).filter(x=>x&&number(x.temp)!==undefined);
}

// --- Radar-Nowcast v0.7.13 --------------------------------------------------
const DWD_RADAR_WMS_PRIMARY='https://maps.dwd.de/geoserver/wms';
const DWD_RADAR_WMS_WORKSPACE='https://maps.dwd.de/geoserver/dwd/wms';
const DWD_RADAR_WMS_BACKUP='https://brz-maps.dwd.de/geoserver/wms';
const DWD_RADAR_WMS_BACKUP_WORKSPACE='https://brz-maps.dwd.de/geoserver/dwd/wms';
const DWD_RADAR_WMS_BASES=[DWD_RADAR_WMS_PRIMARY,DWD_RADAR_WMS_BACKUP,DWD_RADAR_WMS_WORKSPACE,DWD_RADAR_WMS_BACKUP_WORKSPACE];
// Das explizite RV-Produkt steht zuerst, weil nur seine eigene Zeitdimension
// zuverlässig Beobachtungen und den Nowcast bis +2 Stunden beschreibt.
const DWD_RADAR_LAYERS=['dwd:Radar_rv_product_1x1km_ger','dwd:Niederschlagsradar'];
const RAINVIEWER_META='https://api.rainviewer.com/public/weather-maps.json';
const RADAR_RATE_LIMIT=400;
function clamp(v,min,max){return Math.max(min,Math.min(max,v))}
function dwdWorkspaceEndpoint(base){return /\/geoserver\/dwd\/wms(?:$|\?)/i.test(String(base||''))}
function dwdLayerForEndpoint(layer,base){return dwdWorkspaceEndpoint(base)?String(layer||'').replace(/^dwd:/i,''):String(layer||'')}
function dwdRadarApplies(lat,lon,country=''){return directCountryCode(country)==='DE'}
function operaRadarApplies(lat,lon){return lat>=31.5&&lat<=72.5&&lon>=-30.5&&lon<=50.5}
function isoFloor5(epochMs=Date.now()){return new Date(Math.floor(epochMs/300000)*300000).toISOString().replace('.000Z','Z')}
function mmhFromDbz(dbz){const z=10**(dbz/10);return Math.max(0,(z/200)**(1/1.6))}
function validRadarRate(value){const v=number(value);return v===undefined||v<0||v>RADAR_RATE_LIMIT?undefined:v}
function radarRateLabel(rate){if(rate>=50)return'extremes Radarecho';if(rate>=20)return'sehr stark';if(rate>=8)return'stark';if(rate>=2.5)return'mäßig';if(rate>=.5)return'leicht';if(rate>=.1)return'sehr leicht';return'kein messbarer Niederschlag'}
function normaliseDwdRate(value,key='',mapRate){
 const v=number(value);if(v===undefined||v<0)return undefined;const k=String(key).toLowerCase();
  if(k.includes('dbz'))return validRadarRate(mmhFromDbz(v));
 // GeoServer bezeichnet ein einzelnes Rasterband generisch als GRAY_INDEX.
 // Für RV sind die Nutzwerte mm/h; reservierte/auffällige Bandwerte werden
 // nur akzeptiert, wenn sie zur sichtbaren Kartenfarbe plausibel sind.
 if(/gray_index|grayindex|rain.?rate|precip|rate|^rv$/i.test(k)){
  if(v<=120)return validRadarRate(v);
  if(Number.isFinite(mapRate)&&Number(mapRate)>=20&&v<=RADAR_RATE_LIMIT)return Math.min(80,Number(mapRate));
 }
 return undefined;
}
function dwdRateFromFeatureInfo(data,text='',mapRate){
 const propertySets=[];
 if(Array.isArray(data?.features))for(const feature of data.features)if(feature?.properties&&typeof feature.properties==='object')propertySets.push(feature.properties);
 if(data?.properties&&typeof data.properties==='object')propertySets.push(data.properties);
 if(data&&typeof data==='object'&&!Array.isArray(data))propertySets.push(data);
 for(const properties of propertySets){
  const entries=Object.entries(properties);
  const preferred=entries.find(([key,value])=>/^(GRAY_INDEX|GRAYINDEX|RAIN_RATE|RAINRATE|RATE|PRECIPITATION|RV)$/i.test(key)&&number(value)!==undefined)
   ||entries.find(([key,value])=>/(gray.?index|rain.?rate|precip|(?:^|_)rate(?:$|_)|^rv$)/i.test(key)&&number(value)!==undefined);
  if(preferred){const rate=normaliseDwdRate(preferred[1],preferred[0],mapRate);if(rate!==undefined)return rate}
 }
 const raw=String(text);
 const match=raw.match(/(?:GRAY_INDEX|GRAYINDEX|RAIN_RATE|RAINRATE|PRECIPITATION|RATE|RV)\s*(?:<\/[^>]+>\s*<[^>]+>|["':= ]+)\s*(-?\d+(?:\.\d+)?)/i)
  ||raw.match(/<(?:[^:>]+:)?(?:GRAY_INDEX|GRAYINDEX|RAIN_RATE|RAINRATE|PRECIPITATION|RATE|RV)[^>]*>\s*(-?\d+(?:\.\d+)?)\s*</i);
 return match?normaliseDwdRate(Number(match[1]),match[0],mapRate):undefined;
}
function parseIsoDurationMs(value){const m=String(value||'').match(/^P(?:(\d+)D)?(?:T(?:(\d+)H)?(?:(\d+)M)?(?:(\d+(?:\.\d+)?)S)?)?$/i);if(!m)return 0;return((Number(m[1]||0)*24+Number(m[2]||0))*60+Number(m[3]||0))*60000+Number(m[4]||0)*1000}
function xmlLayerBlock(xml,layer){
 const source=String(xml||''),tokens=/<\/?Layer\b[^>]*>|<Name>\s*([^<]+?)\s*<\/Name>/gi,stack=[];let match;
 while((match=tokens.exec(source))){const token=match[0];if(/^<Layer\b/i.test(token)){stack.push({start:match.index,names:[]})}else if(/^<\/Layer/i.test(token)){const item=stack.pop();if(item&&item.names.includes(layer))return source.slice(item.start,tokens.lastIndex)}else if(match[1]&&stack.length){stack.at(-1).names.push(match[1].trim())}}
 return'';
}
function parseWmsTimeContent(block){const times=[];for(const match of String(block||'').matchAll(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?Z/gi)){const t=Date.parse(match[0]);if(Number.isFinite(t))times.push(t)}for(const part of String(block||'').split(',')){const fields=part.trim().split('/');if(fields.length!==3)continue;const start=Date.parse(fields[0]),end=Date.parse(fields[1]),step=parseIsoDurationMs(fields[2]);if(!Number.isFinite(start)||!Number.isFinite(end)||step<60000||step>6*3600000)continue;for(let t=start;t<=end&&times.length<2500;t+=step)times.push(t)}return[...new Set(times)].sort((a,b)=>a-b)}
function dwdTimesFromCapabilities(xml,layer=''){
 const source=String(xml||'');if(!layer){const blocks=[...source.matchAll(/<(?:\w+:)?(?:Dimension|Extent)\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?(?:Dimension|Extent)>/gi)].filter(match=>/\bname\s*=\s*["']time["']/i.test(match[1]||''));return[...new Set(blocks.flatMap(match=>parseWmsTimeContent(match[2])))].sort((a,b)=>a-b)}
 // WMS-Zeitdimensionen dürfen vererbt werden. Der Parser sammelt deshalb nur
 // die Dimensionen des Ziel-Layers und seiner tatsächlichen Eltern. Ein
 // früherer Rückfall auf die gesamte Capabilities-Datei vermischte Zeitachsen
 // verschiedener Produkte und erzeugte dadurch leere Karten mit falscher Zeit.
 const token=/<(?:\w+:)?Layer\b[^>]*>|<\/(?:\w+:)?Layer>|<(?:\w+:)?Name>\s*([^<]+?)\s*<\/(?:\w+:)?Name>|<(?:\w+:)?(?:Dimension|Extent)\b([^>]*)>([\s\S]*?)<\/(?:\w+:)?(?:Dimension|Extent)>/gi,stack=[];let match;
 while((match=token.exec(source))){const raw=match[0];if(/^<(?:\w+:)?Layer\b/i.test(raw)){stack.push({name:'',times:[]});continue}if(/^<\/(?:\w+:)?Layer/i.test(raw)){const current=stack.at(-1);if(current?.name===layer)return[...new Set(stack.flatMap(item=>item.times))].sort((a,b)=>a-b);stack.pop();continue}if(match[1]&&stack.length){stack.at(-1).name=decodeXml(match[1]).trim();continue}if(match[2]&&stack.length&&/\bname\s*=\s*["']time["']/i.test(match[2]))stack.at(-1).times.push(...parseWmsTimeContent(match[3]))
 }
 return[];
}
function generatedDwdTimes(now=Date.now()){const base=Math.floor(now/300000)*300000,out=[];for(let minute=-60;minute<=120;minute+=5)out.push(base+minute*60000);return out}
function selectDwdTimes(times,now=Date.now()){
 // Gewünschtes Kartenfenster: eine Stunde Beobachtung bis zwei Stunden
 // Nowcast. Vergangenheit bleibt 5-minütig, die Zukunft wird auf etwa
 // 10 Minuten ausgedünnt, damit die Kartenanimation flüssig und vertretbar bleibt.
 const usable=(times.length?times:generatedDwdTimes(now)).filter(t=>t>=now-60*60000&&t<=now+120*60000).sort((a,b)=>a-b),observed=usable.filter(t=>t<=now+90000).slice(-13),allFuture=usable.filter(t=>t>now+90000),future=allFuture.filter((_,i)=>i===0||i%2===1||i===allFuture.length-1);
 return[...new Set([...observed,...future])].sort((a,b)=>a-b);
}
function dwdAnalysisTimes(times,now,validatedTime){const observed=times.filter(t=>t<=now+90000),future=times.filter(t=>t>now+90000),sample=[...observed.filter((_,i)=>i%2===0||i===observed.length-1),...future.filter((_,i)=>i%2===0||i===future.length-1),validatedTime].filter(Number.isFinite).sort((a,b)=>a-b);if(sample.length<=12)return[...new Set(sample)];const step=Math.ceil(sample.length/12),reduced=sample.filter((_,i)=>i%step===0);if(reduced.at(-1)!==sample.at(-1))reduced.push(sample.at(-1));return[...new Set(reduced)].slice(0,12)}
function dwdCapabilitiesUrl(base){const u=new URL(base);u.searchParams.set('service','WMS');u.searchParams.set('version','1.3.0');u.searchParams.set('request','GetCapabilities');return u.toString()}
async function dwdAvailableTimes(base,layer){const response=await fetch(dwdCapabilitiesUrl(base),{headers:{Accept:'application/xml,text/xml,*/*'},cf:{cacheTtl:300,cacheEverything:true}});if(!response.ok)throw new Error(`DWD Capabilities HTTP ${response.status}`);const text=await response.text(),times=dwdTimesFromCapabilities(text,layer);if(!times.length)throw new Error('DWD Capabilities ohne passende Zeitdimension');return times}
function rgbHsl(r,g,b){r/=255;g/=255;b/=255;const max=Math.max(r,g,b),min=Math.min(r,g,b),d=max-min,l=(max+min)/2;let h=0,s=0;if(d){s=d/(1-Math.abs(2*l-1));if(max===r)h=60*((g-b)/d%6);else if(max===g)h=60*((b-r)/d+2);else h=60*((r-g)/d+4);if(h<0)h+=360}return{h,s,l}}
function dwdPixelRate(r,g,b,a){
 if(a<18)return 0;const{h,s,l}=rgbHsl(r,g,b),max=Math.max(r,g,b),min=Math.min(r,g,b);
 // transparente/nahezu graue Hintergrund- und NoData-Pixel
 if(s<.12&&(max-min<28||l<.18||l>.94))return 0;
 // Vereinfachte Dekodierung der DWD-RV-Layerfarben. Sie dient nur als
 // Rückfall, wenn GetFeatureInfo für einen sichtbaren Pixel keinen Nutzwert liefert.
 if(h>=255&&h<340)return 50;
 if(h<18||h>=340)return 25;
 if(h<43)return 12;
 if(h<68)return 6;
 if(h<155)return 2.5;
 if(h<195)return 1.2;
 if(h<255)return l<.42?1:.35;
 return .2;
}
function dwdMapSample(image,lat,latDelta,lonDelta){
 const cx=Math.floor(image.width/2),cy=Math.floor(image.height/2),sample=(x,y)=>{x=clamp(Math.round(x),0,image.width-1);y=clamp(Math.round(y),0,image.height-1);const i=(y*image.width+x)*4;return dwdPixelRate(image.rgba[i],image.rgba[i+1],image.rgba[i+2],image.rgba[i+3])},center=sample(cx,cy),kmPerPixelX=Math.max(.05,2*lonDelta*111*Math.cos(lat*Math.PI/180)/image.width),kmPerPixelY=Math.max(.05,2*latDelta*111/image.height),near=[];
 for(const km of[2,4,7]){const ox=km/kmPerPixelX,oy=km/kmPerPixelY;for(const[x,y]of[[cx+ox,cy],[cx-ox,cy],[cx,cy+oy],[cx,cy-oy],[cx+ox*.7,cy+oy*.7],[cx-ox*.7,cy+oy*.7]])near.push(sample(x,y))}
 return{center,nearby:Math.max(...near,0),visible:center>0||near.some(v=>v>0)};
}
async function dwdMapFrame(base,layer,lat,lon,time){
 const latDelta=.075,lonDelta=.075/Math.max(.35,Math.cos(lat*Math.PI/180)),u=new URL(base);u.searchParams.set('service','WMS');u.searchParams.set('version','1.1.1');u.searchParams.set('request','GetMap');u.searchParams.set('layers',layer);u.searchParams.set('styles','');u.searchParams.set('srs','EPSG:4326');u.searchParams.set('bbox',`${lon-lonDelta},${lat-latDelta},${lon+lonDelta},${lat+latDelta}`);u.searchParams.set('width','129');u.searchParams.set('height','129');u.searchParams.set('format','image/png');u.searchParams.set('transparent','true');u.searchParams.set('exceptions','application/vnd.ogc.se_xml');if(Number.isFinite(time))u.searchParams.set('time',new Date(time).toISOString());
 const response=await fetch(u.toString(),{headers:{Accept:'image/png,*/*'},cf:{cacheTtl:120,cacheEverything:true}});if(!response.ok)throw new Error(`DWD GetMap HTTP ${response.status}`);const type=String(response.headers.get('content-type')||'');const buffer=await response.arrayBuffer();if(!type.includes('image/png')&&new Uint8Array(buffer)[0]!==137)throw new Error('DWD GetMap liefert kein PNG');const sampled=dwdMapSample(await decodePng(buffer),lat,latDelta,lonDelta);return{...sampled,time:Number.isFinite(time)?time:Math.floor(Date.now()/300000)*300000};
}
async function dwdPointRate(base,layer,lat,lon,time,mapRate){
 const delta=.018;
 for(const infoFormat of['application/json','text/plain','text/html']){const u=new URL(base);u.searchParams.set('service','WMS');u.searchParams.set('version','1.1.1');u.searchParams.set('request','GetFeatureInfo');u.searchParams.set('layers',layer);u.searchParams.set('query_layers',layer);u.searchParams.set('styles','');u.searchParams.set('srs','EPSG:4326');u.searchParams.set('bbox',`${lon-delta},${lat-delta},${lon+delta},${lat+delta}`);u.searchParams.set('width','101');u.searchParams.set('height','101');u.searchParams.set('x','50');u.searchParams.set('y','50');u.searchParams.set('format','image/png');u.searchParams.set('info_format',infoFormat);u.searchParams.set('feature_count','1');u.searchParams.set('exceptions','application/vnd.ogc.se_xml');if(Number.isFinite(time))u.searchParams.set('time',new Date(time).toISOString());
  try{const response=await fetch(u.toString(),{headers:{Accept:`${infoFormat},application/json,text/plain,text/html,*/*`},cf:{cacheTtl:60,cacheEverything:true}});if(!response.ok)continue;const text=await response.text();if(/ServiceException|ExceptionReport/i.test(text))continue;let parsed=null;try{parsed=JSON.parse(text)}catch{}const rate=dwdRateFromFeatureInfo(parsed,text,mapRate);if(rate!==undefined)return{rate,source:'feature-info'}}catch{}
 }
 return{rate:validRadarRate(mapRate)??0,source:'map-fallback'};
}
async function findDwdQuery(lat,lon,now=Date.now()){
 const errors=[];
 for(const base of[DWD_RADAR_WMS_PRIMARY,DWD_RADAR_WMS_BACKUP])for(const layer of DWD_RADAR_LAYERS){
  let times=[],fromCapabilities=true;try{times=await dwdAvailableTimes(base,layer)}catch(error){fromCapabilities=false;errors.push(`${new URL(base).hostname}/${layer}: ${error instanceof Error?error.message:String(error)}`)}
  const selected=selectDwdTimes(times,now),observedCandidates=selected.filter(t=>t<=now+90000).slice(-3).reverse();
  for(const time of observedCandidates){try{const sample=await dwdMapFrame(base,layer,lat,lon,time);return{base,layer,times:selected,validatedTime:time,validatedSample:sample,fromCapabilities,errors}}catch(error){errors.push(`${new URL(base).hostname}/${layer}/GetMap: ${error instanceof Error?error.message:String(error)}`)}}
  // Die WMS-Voreinstellung liefert den aktuellsten Frame und ist ein robuster
  // letzter DWD-Test, falls die Zeitdimension verzögert oder anders formatiert ist.
  try{const sample=await dwdMapFrame(base,layer,lat,lon,undefined);return{base,layer,times:[sample.time],validatedTime:sample.time,validatedSample:sample,fromCapabilities:false,errors}}catch(error){errors.push(`${new URL(base).hostname}/${layer}/GetMap-default: ${error instanceof Error?error.message:String(error)}`)}
 }
 throw new Error(`DWD-Radarkarte nicht lesbar${errors.length?`: ${errors.slice(-4).join(' | ')}`:''}`);
}
async function dwdRadarNowcast(lat,lon){
 const now=Date.now(),query=await findDwdQuery(lat,lon,now),frames=[],analysisTimes=dwdAnalysisTimes(query.times,now,query.validatedTime);let featureInfoHits=0,mapFallbacks=0,analysedFrames=0;
 for(const time of analysisTimes){let sample;if(time===query.validatedTime)sample=query.validatedSample;else{try{sample=await dwdMapFrame(query.base,query.layer,lat,lon,time)}catch{continue}}analysedFrames++;let precise;try{precise=await dwdPointRate(query.base,query.layer,lat,lon,time,sample.center)}catch{precise={rate:validRadarRate(sample.center)??0,source:'map-fallback'}}if(precise.source==='feature-info')featureInfoHits++;else mapFallbacks++;frames.push({time,center:precise.rate,nearby:sample.nearby,future:time>now+90000,validPoints:19,rateSource:precise.source})}
 if(!frames.length)throw new Error('DWD-Radar liefert keine verwertbare Kartenzeitreihe.');
 const result=radarResultFromFrames('dwd','DWD-RV −1 h bis +2 h',query.fromCapabilities?'high':'medium',frames,'Daten: Deutscher Wetterdienst; MID-Pixel- und Punkt-Auswertung',{rateApproximate:false});
 const displayTimes=query.fromCapabilities&&query.times.length>1?query.times:frames.map(x=>x.time);return{...result,radarLayer:query.layer,timeline:[...new Set(displayTimes)].sort((a,b)=>a-b).map(x=>new Date(x).toISOString()),diagnostics:{...(result.diagnostics||{}),endpoint:query.base,layer:query.layer,method:'WMS GetMap + GetFeatureInfo je Analyseframe',featureInfoHits,mapFallbacks,analysedFrames,capabilitiesTimeAxis:query.fromCapabilities,displayWindowMinutes:[-60,120],queryErrors:query.errors.slice(-8)}};
}
async function dwdRvAccumulation(lat,lon){if(!inGermanyBounds(lat,lon))return{coverage:false,provider:'DWD RV',product:'Niederschlags-Nowcast',forecast30:0,forecast60:0,forecast120:0,frames:[]};const now=Date.now(),query=await findDwdQuery(lat,lon,now);let available=query.times;try{available=await dwdAvailableTimes(query.base,query.layer)}catch{}const baseTime=available.filter(time=>time<=now).at(-1)??query.validatedTime,future=[...new Set(available.filter(time=>time>baseTime+60000&&time<=baseTime+121*60000))].sort((a,b)=>a-b);if(!future.length)return{coverage:true,provider:'DWD RV',product:'Niederschlags-Nowcast',observedAt:new Date(baseTime).toISOString(),forecast30:0,forecast60:0,forecast120:0,frames:[],approximate:true,license:'DWD Open Data',summary:'Keine zukünftigen RV-Zeitschritte verfügbar.'};const selected=future.filter((time,index)=>index===0||time-future[index-1]>=4*60000),batches=[];for(let index=0;index<selected.length;index+=4)batches.push(selected.slice(index,index+4));const frames=[];for(const batch of batches){const values=await Promise.all(batch.map(async time=>{let precise=await dwdPointRate(query.base,query.layer,lat,lon,time,undefined);if(precise.source!=='feature-info'){try{const map=await dwdMapFrame(query.base,query.layer,lat,lon,time);precise=await dwdPointRate(query.base,query.layer,lat,lon,time,map.center)}catch{}}const leadMinutes=Math.max(0,(time-baseTime)/60000);return{time:new Date(time).toISOString(),leadMinutes,rateMmH:Math.max(0,Number(precise.rate)||0),source:precise.source}}));frames.push(...values)}frames.sort((a,b)=>a.leadMinutes-b.leadMinutes);let previousLead=0;for(const frame of frames){const interval=Math.max(0,Math.min(15,frame.leadMinutes-previousLead||5));frame.amountMm=frame.rateMmH*interval/60;previousLead=frame.leadMinutes}const total=minutes=>frames.filter(frame=>frame.leadMinutes<=minutes+1).reduce((sum,frame)=>sum+frame.amountMm,0);return{coverage:true,provider:'DWD RV',product:'Radar-Nowcast bis +120 Minuten',observedAt:new Date(baseTime).toISOString(),forecast30:total(30),forecast60:total(60),forecast120:total(120),frames,approximate:true,license:'DWD Open Data',diagnostics:{endpoint:query.base,layer:query.layer}}}
async function dwdRainStation(lat,lon){if(!inGermanyBounds(lat,lon))return{available:false,provider:'DWD Open Data / Bright Sky'};const rows=await brightSkyRows(lat,lon,60),now=Date.now(),row=rows.find(item=>{const observed=Date.parse(item.reportTime||'');return Number.isFinite(observed)&&now-observed<=45*60000&&Number.isFinite(Number(item.precipitation))});if(!row)return{available:false,provider:'DWD Open Data / Bright Sky',summary:'Keine aktuelle DWD-Niederschlagsstation im Umfeld.'};return{available:true,name:row.name,stationId:row.stationId,observedAt:row.reportTime,distanceKm:Number(row.distance)/1000,amount10m:Math.max(0,Number(row.precipitation)||0),provider:'DWD Open Data / Bright Sky'}}
function u32(bytes,o){return((bytes[o]<<24)|(bytes[o+1]<<16)|(bytes[o+2]<<8)|bytes[o+3])>>>0}
function paeth(a,b,c){const p=a+b-c,pa=Math.abs(p-a),pb=Math.abs(p-b),pc=Math.abs(p-c);return pa<=pb&&pa<=pc?a:pb<=pc?b:c}
async function decodePng(buffer){
 const bytes=new Uint8Array(buffer);if(bytes.length<24||bytes[0]!==137||bytes[1]!==80)throw new Error('Ungültige PNG-Kachel');let pos=8,width=0,height=0,bitDepth=8,colorType=6,palette=null,transparency=null,idat=[];
 while(pos+12<=bytes.length){const len=u32(bytes,pos),type=String.fromCharCode(...bytes.slice(pos+4,pos+8)),data=bytes.slice(pos+8,pos+8+len);pos+=12+len;if(type==='IHDR'){width=u32(data,0);height=u32(data,4);bitDepth=data[8];colorType=data[9]}else if(type==='PLTE')palette=data;else if(type==='tRNS')transparency=data;else if(type==='IDAT')idat.push(data);else if(type==='IEND')break}
 if(bitDepth!==8||!width||!height)throw new Error('PNG-Format nicht unterstützt');const compressed=new Uint8Array(idat.reduce((n,x)=>n+x.length,0));let off=0;for(const chunk of idat){compressed.set(chunk,off);off+=chunk.length}const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream('deflate')),raw=new Uint8Array(await new Response(stream).arrayBuffer()),bpp=colorType===6?4:colorType===2?3:colorType===4?2:1,stride=width*bpp,out=new Uint8Array(height*stride);let rp=0;
 for(let y=0;y<height;y++){const filter=raw[rp++],row=raw.slice(rp,rp+stride);rp+=stride;for(let x=0;x<stride;x++){const left=x>=bpp?out[y*stride+x-bpp]:0,up=y?out[(y-1)*stride+x]:0,upLeft=y&&x>=bpp?out[(y-1)*stride+x-bpp]:0,v=row[x];out[y*stride+x]=filter===0?v:filter===1?(v+left)&255:filter===2?(v+up)&255:filter===3?(v+Math.floor((left+up)/2))&255:filter===4?(v+paeth(left,up,upLeft))&255:v}}
 const rgba=new Uint8Array(width*height*4);for(let i=0;i<width*height;i++){let r=0,g=0,b=0,a=255;if(colorType===6){r=out[i*4];g=out[i*4+1];b=out[i*4+2];a=out[i*4+3]}else if(colorType===2){r=out[i*3];g=out[i*3+1];b=out[i*3+2]}else if(colorType===3){const idx=out[i];r=palette?.[idx*3]??0;g=palette?.[idx*3+1]??0;b=palette?.[idx*3+2]??0;a=transparency?.[idx]??255}else if(colorType===4){r=g=b=out[i*2];a=out[i*2+1]}else{r=g=b=out[i]}rgba.set([r,g,b,a],i*4)}return{width,height,rgba};
}
// Offizielle Schlüsselstufen der RainViewer-Farbskala 2 (Universal Blue).
// Die öffentliche API liefert nur eingefärbte PNGs; die Rate ist daher eine
// aus der nächstgelegenen Palettenfarbe und Marshall-Palmer abgeleitete Näherung.
const RAINVIEWER_BLUE=[
 [-10,99,97,89,20],[-5,114,110,97,46],[0,130,123,105,73],[5,146,136,113,100],[10,210,196,139,160],[13,216,221,238,255],[16,81,197,232,255],[19,0,163,224,255],[20,0,163,224,255],[25,0,136,191,255],[30,0,85,136,255],[35,255,238,0,255],[40,255,170,0,255],[45,255,102,0,255],[50,193,0,0,255],[52,214,0,13,255],[54,215,0,19,255],[55,255,79,255,255],[57,255,95,255,255],[59,255,111,255,255],[60,255,98,255,255],[63,255,88,255,255],[66,245,231,251,255],[70,255,255,255,255]
];
function rainViewerPixelDbz(r,g,b,a){if(a<10)return undefined;let best=null,bestDistance=Infinity;for(const [dbz,pr,pg,pb,pa]of RAINVIEWER_BLUE){const distance=(r-pr)**2+(g-pg)**2+(b-pb)**2+.18*(a-pa)**2;if(distance<bestDistance){bestDistance=distance;best=dbz}}return bestDistance>30000?undefined:best}
function rainViewerPixelRate(r,g,b,a){const dbz=rainViewerPixelDbz(r,g,b,a);return dbz===undefined||dbz<10?0:validRadarRate(mmhFromDbz(dbz))??0}
function sampleRadarTile(image,lat){const cx=Math.floor(image.width/2),cy=Math.floor(image.height/2),kmPerPixel=156.54303392*Math.cos(lat*Math.PI/180)/(2**7),sample=(x,y)=>{x=clamp(Math.round(x),0,image.width-1);y=clamp(Math.round(y),0,image.height-1);const i=(y*image.width+x)*4;return rainViewerPixelRate(image.rgba[i],image.rgba[i+1],image.rgba[i+2],image.rgba[i+3])},center=sample(cx,cy),offsets=[3,5,8].map(k=>Math.max(1,k/kmPerPixel)),near=[];for(const o of offsets)for(const[a,b]of[[o,0],[-o,0],[0,o],[0,-o],[o*.7,o*.7],[-o*.7,o*.7]])near.push(sample(cx+a,cy+b));return{center,nearby:Math.max(...near,0)}}
async function rainViewerRadarNowcast(lat,lon){
 const meta=await fetchJson(RAINVIEWER_META),past=(meta?.radar?.past??[]).slice(-6),host=meta?.host;if(!host||!past.length)throw new Error('RainViewer ohne aktuelle Frames.');
 const coverageUrl=`${host}/v2/coverage/0/256/7/${lat.toFixed(5)}/${lon.toFixed(5)}/0/0_0.png`,coverageResponse=await fetch(coverageUrl,{cf:{cacheTtl:86400,cacheEverything:true}});if(coverageResponse.ok){try{const coverage=await decodePng(await coverageResponse.arrayBuffer()),i=(Math.floor(coverage.height/2)*coverage.width+Math.floor(coverage.width/2))*4;if(coverage.rgba[i+3]>200&&coverage.rgba[i]<20&&coverage.rgba[i+1]<20&&coverage.rgba[i+2]<20)throw new Error('Keine RainViewer-Radarabdeckung.')}catch(error){if(String(error).includes('Keine RainViewer'))throw error}}
 const frames=[];for(const frame of past){const url=`${host}${frame.path}/256/7/${lat.toFixed(5)}/${lon.toFixed(5)}/2/0_0.png`,response=await fetch(url,{cf:{cacheTtl:600,cacheEverything:true}});if(!response.ok)continue;const sampled=sampleRadarTile(await decodePng(await response.arrayBuffer()),lat);frames.push({time:Number(frame.time)*1000,center:sampled.center,nearby:sampled.nearby,future:false})}
 if(!frames.length)throw new Error('RainViewer-Kacheln nicht auswertbar.');const fresh=Date.now()-frames.at(-1).time<25*60000,quality=fresh&&frames.length>=5?'medium':'low';return radarResultFromFrames('rainviewer','RainViewer-Radarnäherung',quality,frames,'Weather data by RainViewer; MID-Bewegungsnäherung',{rateApproximate:true});
}

async function rainViewerMetadata(){
 const response=await fetch(RAINVIEWER_META,{headers:{Accept:'application/json'},cf:{cacheTtl:120,cacheEverything:true}});if(!response.ok)throw new Error(`RainViewer Metadata HTTP ${response.status}`);const data=await response.json(),host=String(data?.host||''),normalise=rows=>(Array.isArray(rows)?rows:[]).map(row=>({time:Number(row?.time),path:String(row?.path||'')})).filter(row=>Number.isFinite(row.time)&&row.path).sort((a,b)=>a.time-b.time);
 const past=normalise(data?.radar?.past).slice(-12),nowcast=normalise(data?.radar?.nowcast).slice(0,18);if(!host||!past.length)throw new Error('RainViewer liefert aktuell keine nutzbaren Radarframes.');return{host,generated:Number(data?.generated)||undefined,radar:{past,nowcast},coverage:'Weltweite öffentliche RainViewer-Radarkacheln; Zukunft nur wenn vom Anbieter geliefert',historyMinutes:120,forecastMinutes:nowcast.length?120:0};
}

function coherentDisplayRate(frame){const center=validRadarRate(frame?.center)??0,nearby=validRadarRate(frame?.nearby)??0;if(center>=120&&nearby<Math.max(8,center*.12))return{rate:Math.max(nearby,50),raw:center,uncertain:true};return{rate:center,raw:center,uncertain:center>=50}}
function contiguousWetEvent(future,firstIndex,wet){const event=[];let dryCount=0;for(let i=firstIndex;i<future.length;i++){const frame=future[i];if(wet(frame)){event.push(frame);dryCount=0}else if(event.length&&++dryCount>1)break}return event}
function ongoingWetEnd(future,wet,observedTime){if(!future.length)return{};let firstDryTime,consecutiveDry=0,lastWetTime=observedTime;
 for(const frame of future){if(wet(frame)){lastWetTime=frame.time;firstDryTime=undefined;consecutiveDry=0;continue}if(firstDryTime===undefined)firstDryTime=frame.time;consecutiveDry++;if(consecutiveDry>=2)return{endAt:firstDryTime,endMinutes:Math.max(5,Math.round((firstDryTime-observedTime)/60000)),endOpenEnded:false}}
 if(firstDryTime!==undefined)return{endAt:firstDryTime,endMinutes:Math.max(5,Math.round((firstDryTime-observedTime)/60000)),endOpenEnded:false,endUncertain:true};
 const horizon=future.at(-1)?.time;return Number.isFinite(horizon)?{endAt:horizon,endMinutes:Math.max(5,Math.round((horizon-observedTime)/60000)),endOpenEnded:true}:{}
}
function radarResultFromFrames(source,provider,quality,frames,license,options={}){
 frames=frames.filter(x=>Number.isFinite(x.time)).sort((a,b)=>a.time-b.time);const observed=frames.filter(x=>!x.future),latestObserved=observed.at(-1)||frames[0],future=frames.filter(x=>x.future),siteWet=x=>Number(x.center)>=.05,nearbyWet=x=>Number(x.nearby)>=.18;let radarProbability=5,arrivalMinutes,endMinutes,arrivalStartAt,arrivalEndAt,endAt,endOpenEnded=false,endUncertain=false,arrivalKind,peakRate=0,rateUncertain=false,summary='Kein relevantes Radarecho am Standort oder in unmittelbarer Umgebung.';
 const current=coherentDisplayRate(latestObserved);
 if(current.rate>=.05){radarProbability=98;arrivalMinutes=0;arrivalKind='site';peakRate=current.rate;rateUncertain=current.uncertain;const ending=ongoingWetEnd(future,siteWet,latestObserved.time);endAt=ending.endAt?new Date(ending.endAt).toISOString():undefined;endMinutes=ending.endMinutes;endOpenEnded=Boolean(ending.endOpenEnded);endUncertain=Boolean(ending.endUncertain);summary=`Niederschlag am Standort erkannt: ${radarRateLabel(current.rate)}.`}
 else if(future.length){const firstIndex=future.findIndex(siteWet);if(firstIndex>=0){const first=future[firstIndex],event=contiguousWetEvent(future,firstIndex,siteWet),firstRate=coherentDisplayRate(first),eventRates=event.map(coherentDisplayRate),peak=eventRates.reduce((best,item)=>item.rate>best.rate?item:best,firstRate);arrivalMinutes=Math.max(0,Math.round((first.time-latestObserved.time)/60000));arrivalKind='site';const nextTime=future[firstIndex+1]?.time??first.time+5*60000,windowEnd=Math.min(nextTime,frames.at(-1).time);arrivalStartAt=new Date(first.time).toISOString();arrivalEndAt=new Date(Math.max(first.time,windowEnd)).toISOString();radarProbability=clamp(Math.round(96-arrivalMinutes*.28+(first.center>0?5:0)),45,96);const last=event.at(-1);if(last){endAt=new Date(last.time).toISOString();endMinutes=Math.max(arrivalMinutes,Math.round((last.time-latestObserved.time)/60000))}peakRate=peak.rate;rateUncertain=eventRates.some(x=>x.uncertain);summary=`Radarecho erreicht den Standort voraussichtlich in etwa ${arrivalMinutes} Minuten · ${radarRateLabel(peakRate)}.`}else{const nearbyIndex=future.findIndex(nearbyWet);if(nearbyIndex>=0){const first=future[nearbyIndex];arrivalMinutes=Math.max(0,Math.round((first.time-latestObserved.time)/60000));arrivalKind='nearby';arrivalStartAt=new Date(first.time).toISOString();arrivalEndAt=new Date(Math.min(future[nearbyIndex+1]?.time??first.time+10*60000,frames.at(-1).time)).toISOString();peakRate=validRadarRate(first.nearby)??0;rateUncertain=true;radarProbability=clamp(Math.round(32+Math.min(28,peakRate*5)-arrivalMinutes*.12),20,68);summary=`Radarecho erreicht voraussichtlich die Standortumgebung; ein Treffer am Standort ist noch unsicher · ${radarRateLabel(peakRate)}.`}}}
 else if(Number(latestObserved?.nearby)>=.18){const earlier=observed[Math.max(0,observed.length-4)],trend=Number(latestObserved.nearby)-Number(earlier?.nearby||0),strength=Number(latestObserved.nearby);arrivalMinutes=trend>.05?20:35;arrivalKind='approximate';arrivalStartAt=new Date(latestObserved.time+Math.max(0,arrivalMinutes-10)*60000).toISOString();arrivalEndAt=new Date(latestObserved.time+(arrivalMinutes+15)*60000).toISOString();radarProbability=clamp(Math.round(38+Math.min(32,strength*9)+(trend>0?14:-4)),25,82);peakRate=validRadarRate(latestObserved.nearby)??0;rateUncertain=true;summary=`Niederschlagsfeld in Standortnähe; ein Standorttreffer ist nur grob abschätzbar · ${radarRateLabel(peakRate)}.`}
 else if(observed.length>=2&&Number(observed.at(-2).center)>=.05){radarProbability=12;summary='Das Radarecho hat den Standort zuletzt verlassen; kurzfristig nur geringes Wiederholungsrisiko.'}
 return{source,provider,quality,radarProbability,currentRate:current.rate,rawCurrentRate:current.raw,peakRate,rateApproximate:Boolean(options.rateApproximate),rateUncertain,arrivalMinutes,endMinutes,arrivalKind,arrivalStartAt,arrivalEndAt,endAt,endOpenEnded,endUncertain,observedAt:latestObserved?new Date(latestObserved.time).toISOString():undefined,summary,coverage:true,license,diagnostics:{frames:frames.length,observedFrames:observed.length,futureFrames:future.length,latestNearbyRate:Number(latestObserved?.nearby||0),rawCurrentRate:current.raw}};
}
async function radarNowcastForPoint(lat,lon,country='',stage='all'){
 const errors=[],dwdExpected=dwdRadarApplies(lat,lon,country),operaExpected=operaRadarApplies(lat,lon),dwdOnly=stage==='dwd',rainViewerOnly=stage==='rainviewer';
 if(!rainViewerOnly&&dwdExpected){try{return await dwdRadarNowcast(lat,lon)}catch(error){errors.push(`DWD: ${error instanceof Error?error.message:String(error)}`)}}
 // Das echte OPERA-CIRRUS-HDF5 wird im Frontend strikt zwischen der DWD-Stufe
 // und der RainViewer-Stufe dekodiert und für die Niederschlagswahrscheinlichkeit ausgewertet.
 if(!dwdOnly)try{const rainViewer=await rainViewerRadarNowcast(lat,lon);return{...rainViewer,diagnostics:{...(rainViewer.diagnostics||{}),requestedStage:stage,fallbackAfter:dwdExpected?'DWD und OPERA CIRRUS':operaExpected?'OPERA CIRRUS':undefined}}}catch(error){errors.push(`RainViewer: ${error instanceof Error?error.message:String(error)}`)}
 const expectedSource=dwdExpected?'DWD-RV / EUMETNET OPERA CIRRUS':operaExpected?'EUMETNET OPERA CIRRUS':undefined;
 return{source:'model',provider:'Open-Meteo Best Match',quality:'low',radarProbability:0,currentRate:0,summary:expectedSource?'Radarabdeckung ist für den Standort grundsätzlich vorhanden, die externe Radarauswertung war vorübergehend nicht abrufbar.':'Für den Standort ist derzeit keine verwertbare Radarabdeckung verfügbar.',coverage:false,coverageExpected:Boolean(expectedSource),temporaryUnavailable:Boolean(expectedSource),expectedSource,diagnostics:{errors,requestedStage:stage}};
}


// --- Kompositbild-Daten v0.7.30 --------------------------------------------
const DWD_PX250_ROOT='https://opendata.dwd.de/weather/radar/sites/px250';
const DWD_HX_ROOTS=['https://opendata.dwd.de/weather/radar/composite/hx','https://opendatao.dwd.de/weather/radar/composite/hx'];
const DWD_PX250_SITES=[
 {code:'asb',wmo:'10103',name:'Borkum/Emden',lat:53.564011,lon:6.748292},{code:'boo',wmo:'10132',name:'Boostedt',lat:54.004381,lon:10.046899},
 {code:'drs',wmo:'10488',name:'Dresden',lat:51.124639,lon:13.768639},{code:'eis',wmo:'10780',name:'Eisberg',lat:49.540667,lon:12.402788},
 {code:'ess',wmo:'10410',name:'Essen',lat:51.405649,lon:6.967111},{code:'fbg',wmo:'10908',name:'Feldberg',lat:47.873611,lon:8.003611},
 {code:'fld',wmo:'10440',name:'Flechtdorf',lat:51.311197,lon:8.801998},{code:'hnr',wmo:'10339',name:'Hannover',lat:52.460083,lon:9.694533},
 {code:'isn',wmo:'10873',name:'Isen',lat:48.174705,lon:12.101779},{code:'mem',wmo:'10950',name:'Memmingen',lat:48.042145,lon:10.219222},
 {code:'neu',wmo:'10557',name:'Neuhaus',lat:50.500114,lon:11.135034},{code:'nhb',wmo:'10605',name:'Neuheilenbach',lat:50.109656,lon:6.548328},
 {code:'oft',wmo:'10629',name:'Offenthal',lat:49.984745,lon:8.712933},{code:'pro',wmo:'10392',name:'Prötzel',lat:52.648667,lon:13.858212},
 {code:'ros',wmo:'10169',name:'Rostock',lat:54.175660,lon:12.058076},{code:'tur',wmo:'10832',name:'Türkheim',lat:48.585379,lon:9.782675},
 {code:'umd',wmo:'10356',name:'Ummendorf',lat:52.160096,lon:11.176091}
];
function pxTimestamp(raw){const match=String(raw).match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})$/);return match?new Date(Date.UTC(+match[1],+match[2]-1,+match[3],+match[4],+match[5],+match[6])).toISOString():undefined}
function nearestPxSites(lat,lon,rangeKm=150){return DWD_PX250_SITES.map(site=>({...site,distanceKm:distance(lat,lon,site.lat,site.lon)/1000})).filter(site=>site.distanceKm<=rangeKm).sort((a,b)=>a.distanceKm-b.distanceKm)}
async function pxSiteLatest(site){
 const directory=`${DWD_PX250_ROOT}/${site.code}/`,response=await fetch(directory,{headers:{Accept:'text/html,*/*'},cf:{cacheTtl:120,cacheEverything:true}});
 if(!response.ok)throw new Error(`${site.name}: DWD-PX250-Verzeichnis HTTP ${response.status}`);
 const html=await response.text(),pattern=new RegExp(`rab02-tt_${site.wmo}-(\\d{14})-de${site.code}-hd5`,'g'),matches=[...html.matchAll(pattern)].map(match=>({stamp:match[1],file:match[0]})).sort((a,b)=>a.stamp.localeCompare(b.stamp)),latest=matches.at(-1);
 if(!latest)throw new Error(`${site.name}: keine PX250-HDF5-Datei`);
 const observedAt=pxTimestamp(latest.stamp),observedMs=observedAt?Date.parse(observedAt):NaN,ageMinutes=Number.isFinite(observedMs)?Math.round((Date.now()-observedMs)/60000):Infinity;
 return{...site,latest,observedAt,observedMs,ageMinutes};
}
async function hxLatest(){
 const errors=[];
 for(const root of DWD_HX_ROOTS){try{
  const response=await fetch(`${root}/`,{headers:{Accept:'text/html,*/*'},cf:{cacheTtl:90,cacheEverything:true}});if(!response.ok)throw new Error(`HTTP ${response.status}`);
  const html=await response.text(),matches=[...html.matchAll(/composite_hx_(\d{8})_(\d{4})-hd5/g)].map(match=>({stamp:`${match[1]}${match[2]}00`,file:match[0]})).sort((a,b)=>a.stamp.localeCompare(b.stamp)),latest=matches.at(-1);if(!latest)throw new Error('keine HX-HDF5-Datei');
  const observedAt=pxTimestamp(latest.stamp),observedMs=observedAt?Date.parse(observedAt):NaN,ageMinutes=Number.isFinite(observedMs)?Math.round((Date.now()-observedMs)/60000):Infinity;
  return{root,latest,observedAt,observedMs,ageMinutes};
 }catch(error){errors.push(`${root}: ${error instanceof Error?error.message:String(error)}`)}}
 throw new Error(errors.join(' | ')||'DWD-HX-Verzeichnis nicht erreichbar');
}
async function px250Metadata(request,lat,lon){
 // Das nationale HX-Komposit besitzt dieselbe native Rasterweite wie PX250,
 // ist aber für deutsche Orte die robustere und flächendeckende erste Wahl.
 if(inGermanyBounds(lat,lon)){try{const hx=await hxLatest();if(Number.isFinite(hx.observedMs)&&hx.ageMinutes<=30&&hx.ageMinutes>=-10){const fileUrl=new URL(request.url);fileUrl.search='';fileUrl.searchParams.set('mode','px250-file');fileUrl.searchParams.set('product','hx');fileUrl.searchParams.set('file',hx.latest.file);return{available:true,product:'hx',productName:'DWD HX Deutschlandkomposit',site:'hx',siteName:'Deutschlandkomposit HX',coverage:'Deutschland',distanceKm:0,observedAt:hx.observedAt,ageMinutes:hx.ageMinutes,fileUrl:fileUrl.toString(),nativeResolutionM:250,rangeKm:650}}}catch{}}
 const rangeKm=150,candidates=nearestPxSites(lat,lon,rangeKm).slice(0,5);
 if(!candidates.length){const nearest=[...DWD_PX250_SITES].sort((a,b)=>distance(lat,lon,a.lat,a.lon)-distance(lat,lon,b.lat,b.lon))[0],distanceKm=distance(lat,lon,nearest.lat,nearest.lon)/1000;return{available:false,nativeResolutionM:250,rangeKm,site:nearest.code,siteName:nearest.name,distanceKm:Math.round(distanceKm*10)/10,reason:`Kein aktuelles DWD-HX-Komposit und kein DWD-PX250-Radarstandort innerhalb von ${rangeKm} km; nächster Standort ${nearest.name} in ${Math.round(distanceKm)} km.`}}
 const diagnostics=[];
 for(const site of candidates){try{const item=await pxSiteLatest(site);diagnostics.push(`${item.name}: ${Number.isFinite(item.ageMinutes)?item.ageMinutes:'?'} min`);if(!Number.isFinite(item.observedMs)||item.ageMinutes>30||item.ageMinutes<-10)continue;const fileUrl=new URL(request.url);fileUrl.search='';fileUrl.searchParams.set('mode','px250-file');fileUrl.searchParams.set('product','px250');fileUrl.searchParams.set('site',item.code);fileUrl.searchParams.set('file',item.latest.file);return{available:true,product:'px250',productName:'DWD PX250 Standortradar',site:item.code,siteName:item.name,stationId:item.wmo,radarLat:item.lat,radarLon:item.lon,distanceKm:Math.round(item.distanceKm*10)/10,observedAt:item.observedAt,ageMinutes:item.ageMinutes,fileUrl:fileUrl.toString(),nativeResolutionM:250,rangeKm}}catch(error){diagnostics.push(error instanceof Error?error.message:String(error))}}
 const nearest=candidates[0];return{available:false,stale:true,nativeResolutionM:250,rangeKm,site:nearest.code,siteName:nearest.name,distanceKm:Math.round(nearest.distanceKm*10)/10,reason:`DWD HX und die erreichbaren PX250-Standorte liefern derzeit keinen höchstens 30 Minuten alten Stand. ${diagnostics.slice(0,4).join(' · ')}`};
}
async function px250FileResponse(request){
 const url=new URL(request.url),product=String(url.searchParams.get('product')||'px250').toLowerCase(),file=String(url.searchParams.get('file')||'');
 if(product==='hx'){
  const match=file.match(/^composite_hx_(\d{8})_(\d{4})-hd5$/);if(!match)return json({error:'Ungültige DWD-HX-Dateianforderung.',version:WORKER_VERSION},400,{'cache-control':'no-store'});
  const observedAt=pxTimestamp(`${match[1]}${match[2]}00`),ageMinutes=observedAt?(Date.now()-Date.parse(observedAt))/60000:Infinity;if(!Number.isFinite(ageMinutes)||ageMinutes>40||ageMinutes<-10)return json({error:'Der angeforderte DWD-HX-Stand ist nicht aktuell.',version:WORKER_VERSION,observedAt},409,{'cache-control':'no-store'});
  let lastStatus=502;for(const root of DWD_HX_ROOTS){const upstream=await fetch(`${root}/${file}`,{headers:{Accept:'application/octet-stream,*/*'},cf:{cacheTtl:180,cacheEverything:true}});lastStatus=upstream.status;if(!upstream.ok)continue;const headers=new Headers();headers.set('content-type',upstream.headers.get('content-type')||'application/x-hdf5');headers.set('cache-control','public, max-age=180');headers.set('access-control-allow-origin','*');headers.set('access-control-allow-methods','GET,OPTIONS');const length=upstream.headers.get('content-length');if(length)headers.set('content-length',length);return new Response(upstream.body,{status:200,headers})}return json({error:`DWD-HX-Datei HTTP ${lastStatus}`,version:WORKER_VERSION},lastStatus,{'cache-control':'no-store'});
 }
 const siteCode=String(url.searchParams.get('site')||'').toLowerCase(),site=DWD_PX250_SITES.find(item=>item.code===siteCode),stamp=file.match(/-(\d{14})-/)?.[1],observedAt=stamp?pxTimestamp(stamp):undefined,ageMinutes=observedAt?(Date.now()-Date.parse(observedAt))/60000:Infinity;
 if(!site||!new RegExp(`^rab02-tt_${site.wmo}-\\d{14}-de${site.code}-hd5$`).test(file))return json({error:'Ungültige PX250-Dateianforderung.',version:WORKER_VERSION},400,{'cache-control':'no-store'});
 if(!Number.isFinite(ageMinutes)||ageMinutes>40||ageMinutes<-10)return json({error:'Der angeforderte PX250-Stand ist nicht aktuell und wird nicht als Livebild ausgeliefert.',version:WORKER_VERSION,observedAt},409,{'cache-control':'no-store'});
 const upstream=await fetch(`${DWD_PX250_ROOT}/${site.code}/${file}`,{headers:{Accept:'application/octet-stream,*/*'},cf:{cacheTtl:180,cacheEverything:true}});if(!upstream.ok)return json({error:`DWD-PX250-Datei HTTP ${upstream.status}`,version:WORKER_VERSION},upstream.status,{'cache-control':'no-store'});const headers=new Headers();headers.set('content-type',upstream.headers.get('content-type')||'application/x-hdf5');headers.set('cache-control','public, max-age=180');headers.set('access-control-allow-origin','*');headers.set('access-control-allow-methods','GET,OPTIONS');const length=upstream.headers.get('content-length');if(length)headers.set('content-length',length);return new Response(upstream.body,{status:200,headers});
}
const OPERA_S3_ROOT='https://s3.waw3-1.cloudferro.com/openradar-24h';
function operaNominalTime(value=Date.now()){const date=new Date(value);date.setUTCSeconds(0,0);date.setUTCMinutes(Math.floor(date.getUTCMinutes()/5)*5);return date.getTime()}
function operaStamp(value){const date=new Date(value),pad=number=>String(number).padStart(2,'0');return`${date.getUTCFullYear()}${pad(date.getUTCMonth()+1)}${pad(date.getUTCDate())}T${pad(date.getUTCHours())}${pad(date.getUTCMinutes())}`}
function operaObjectKey(value){const date=new Date(value),pad=number=>String(number).padStart(2,'0');return`${date.getUTCFullYear()}/${pad(date.getUTCMonth()+1)}/${pad(date.getUTCDate())}/OPERA/COMP/OPERA@${operaStamp(value)}@0@DBZH.h5`}
function operaS3UrlFromKey(key){return`${OPERA_S3_ROOT}/${key}`}
function operaS3Url(value){return operaS3UrlFromKey(operaObjectKey(value))}
function decodeXmlText(value){return String(value||'').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>').replace(/&quot;/g,'"').replace(/&#39;/g,"'")}
function operaTimeFromKey(key){const match=String(key||'').match(/^(\d{4})\/(\d{2})\/(\d{2})\/OPERA\/COMP\/OPERA@(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})@0@DBZH\.h5$/);if(!match||match[1]!==match[4]||match[2]!==match[5]||match[3]!==match[6])return NaN;const value=Date.UTC(Number(match[4]),Number(match[5])-1,Number(match[6]),Number(match[7]),Number(match[8])),date=new Date(value);return date.getUTCFullYear()===Number(match[4])&&date.getUTCMonth()+1===Number(match[5])&&date.getUTCDate()===Number(match[6])&&date.getUTCHours()===Number(match[7])&&date.getUTCMinutes()===Number(match[8])?value:NaN}
function validOperaKey(key,reference=Date.now()){const time=operaTimeFromKey(key);return Number.isFinite(time)&&time<=reference+10*60000&&time>=reference-30*60*60000}
function operaListPrefix(value){const date=new Date(value),pad=number=>String(number).padStart(2,'0');return`${date.getUTCFullYear()}/${pad(date.getUTCMonth()+1)}/${pad(date.getUTCDate())}/OPERA/COMP/`}
async function operaListDay(value){const url=new URL(OPERA_S3_ROOT);url.searchParams.set('list-type','2');url.searchParams.set('prefix',operaListPrefix(value));url.searchParams.set('max-keys','1000');const response=await fetch(url.toString(),{headers:{Accept:'application/xml,text/xml,*/*'},cf:{cacheTtl:90,cacheEverything:true}});if(!response.ok)throw new Error(`OPERA-S3-Index HTTP ${response.status}`);const xml=await response.text(),keys=[...xml.matchAll(/<Key>([\s\S]*?)<\/Key>/g)].map(match=>decodeXmlText(match[1]).trim()).filter(key=>validOperaKey(key));if(!keys.length)throw new Error('OPERA-S3-Index enthält keine aktuellen DBZH-Objekte.');return keys}
const OPERA_ORD_API='https://api.meteogate.eu/eu-eumetnet-weather-radar/collections/observations/locations/0-20010-0-OPERA';
function operaOrdWindow(reference=Date.now()){const end=operaNominalTime(reference+5*60000),start=end-95*60000;return`${new Date(start).toISOString().replace(/\.000Z$/,'Z')}/${new Date(end).toISOString().replace(/\.000Z$/,'Z')}`}
async function operaOrdFrames(reference=Date.now()){
 const url=new URL(OPERA_ORD_API);url.searchParams.set('datetime',operaOrdWindow(reference));url.searchParams.set('f','CoverageJSON');url.searchParams.set('standard_name','DBZH');url.searchParams.set('format','ODIM');
 const response=await fetch(url.toString(),{headers:{Accept:'application/prs.coverage+json,application/json,*/*'},cf:{cacheTtl:90,cacheEverything:true}});if(response.status===204)throw new Error('OPERA-ORD-API meldet für das aktuelle Zeitfenster keine Daten.');if(!response.ok)throw new Error(`OPERA-ORD-API HTTP ${response.status}`);
 const body=await response.text(),decoded=body.replace(/\u002F/gi,'/').replace(/\\\//g,'/'),urls=[...decoded.matchAll(/https?:[^\s"'<>]+OPERA@\d{8}T\d{4}@0@DBZH\.h5/gi)].map(match=>match[0].replace(/\\u0026/gi,'&')),keys=[];
 for(const value of urls){try{const parsed=new URL(value),marker='/openradar-24h/',index=parsed.pathname.indexOf(marker);if(index>=0)keys.push(decodeURIComponent(parsed.pathname.slice(index+marker.length)))}catch{}}
 const directKeys=[...decoded.matchAll(/(?:^|["'\s])((?:\d{4}\/\d{2}\/\d{2}\/OPERA\/COMP\/)?OPERA@\d{8}T\d{4}@0@DBZH\.h5)/g)].map(match=>match[1]).map(key=>key.includes('/')?key:`${new Date(reference).toISOString().slice(0,10).replace(/-/g,'/')}\/OPERA/COMP/${key}`.replace('\\/','/'));
 const unique=[...new Set([...keys,...directKeys])].filter(key=>validOperaKey(key,reference));if(!unique.length)throw new Error('OPERA-ORD-API enthielt keine direkt nutzbaren DBZH-HDF5-Links.');return unique.map(key=>({key,time:operaTimeFromKey(key)})).filter(frame=>Number.isFinite(frame.time)).sort((a,b)=>a.time-b.time)
}
async function operaListedFrames(reference=Date.now()){const results=await Promise.allSettled([operaOrdFrames(reference),(async()=>{const days=[operaNominalTime(reference),operaNominalTime(reference-24*60*60000)],listed=await Promise.allSettled(days.map(operaListDay)),errors=listed.filter(result=>result.status==='rejected').map(result=>result.reason instanceof Error?result.reason.message:String(result.reason)),keys=[...new Set(listed.flatMap(result=>result.status==='fulfilled'?result.value:[]))];if(!keys.length)throw new Error(errors.join(' | ')||'OPERA-S3-Index lieferte keine verwertbaren Frames.');return keys.map(key=>({key,time:operaTimeFromKey(key)})).filter(frame=>Number.isFinite(frame.time)).sort((a,b)=>a.time-b.time)})()]),errors=results.filter(result=>result.status==='rejected').map(result=>result.reason instanceof Error?result.reason.message:String(result.reason)),frames=[...new Map(results.flatMap(result=>result.status==='fulfilled'?result.value:[]).map(frame=>[frame.key,frame])).values()].sort((a,b)=>a.time-b.time);if(!frames.length)throw new Error(errors.join(' | ')||'OPERA-Datenermittlung lieferte keine verwertbaren Frames.');return frames}
async function operaFrameExists(value){const upstream=operaS3Url(value);try{const probe=await fetch(upstream,{headers:{Accept:'application/octet-stream,*/*','Range':'bytes=0-7'},cf:{cacheTtl:120,cacheEverything:true}}),ok=probe.ok||probe.status===206;try{await probe.body?.cancel()}catch{}return ok}catch{return false}}
async function operaProbedFrames(reference=Date.now()){const start=operaNominalTime(reference),candidates=Array.from({length:19},(_,index)=>start-index*5*60000),frames=[];for(let offset=0;offset<candidates.length;offset+=6){const batch=candidates.slice(offset,offset+6),results=await Promise.all(batch.map(async time=>({time,exists:await operaFrameExists(time)})));for(const result of results)if(result.exists)frames.push({time:result.time,key:operaObjectKey(result.time)})}return frames.sort((a,b)=>a.time-b.time)}
function operaProxyFileUrl(request,frame){const url=new URL(request.url);url.search='';url.searchParams.set('mode','opera-raster-file');url.searchParams.set('key',frame.key);return url.toString()}
async function operaRasterMetadata(request){let frames=[],discovery='ORD API + S3 ListObjectsV2',diagnostics=[];try{frames=await operaListedFrames()}catch(error){diagnostics.push(error instanceof Error?error.message:String(error))}if(!frames.length){discovery='HDF5 Range-Probe';frames=await operaProbedFrames()}if(!frames.length)throw new Error(`EUMETNET OPERA CIRRUS liefert im aktuellen Zeitfenster keine erreichbare HDF5-Datei.${diagnostics.length?` ${diagnostics.join(' | ')}`:''}`);const selected=frames.slice(-13),latest=selected.at(-1).time;return{frames:selected.map(frame=>({time:new Date(frame.time).toISOString(),fileUrl:operaProxyFileUrl(request,frame),product:'DBZH',nativeResolutionKm:1,temporalResolutionMinutes:5})),provider:'EUMETNET OPERA CIRRUS / ORD',product:'DBZH',observedAt:new Date(latest).toISOString(),nativeResolutionKm:1,temporalResolutionMinutes:5,coverage:`Europa · echtes CIRRUS-Maximalreflektivitätskomposit · 1-km-Raster · ${selected.length} reale Produktstände`,license:'CC BY 4.0',discovery,diagnostics}}
async function operaRasterFileResponse(request){const url=new URL(request.url),key=String(url.searchParams.get('key')||''),legacyTime=Date.parse(String(url.searchParams.get('time')||'')),resolvedKey=key||(Number.isFinite(legacyTime)?operaObjectKey(legacyTime):'');if(!resolvedKey||!validOperaKey(resolvedKey))return json({error:'Ungültiger oder veralteter OPERA-Objektschlüssel.',version:WORKER_VERSION},400,{'cache-control':'no-store'});const time=operaTimeFromKey(resolvedKey),upstream=await fetch(operaS3UrlFromKey(resolvedKey),{headers:{Accept:'application/octet-stream,*/*'},cf:{cacheTtl:300,cacheEverything:true}});if(!upstream.ok)return json({error:`OPERA-HDF5 HTTP ${upstream.status}`,version:WORKER_VERSION,requestedTime:new Date(time).toISOString(),key:resolvedKey},upstream.status,{'cache-control':'no-store'});const headers=new Headers();headers.set('content-type',upstream.headers.get('content-type')||'application/x-hdf5');headers.set('cache-control','public, max-age=300, stale-while-revalidate=120');headers.set('access-control-allow-origin','*');headers.set('access-control-allow-methods','GET,OPTIONS');headers.set('x-mid-radar-provider','EUMETNET OPERA CIRRUS');headers.set('x-mid-radar-product','DBZH');headers.set('x-mid-opera-key',resolvedKey);headers.set('x-mid-worker-version',WORKER_VERSION);const length=upstream.headers.get('content-length');if(length)headers.set('content-length',length);return new Response(upstream.body,{status:200,headers})}

function flattenCoordinatePairs(value,out=[]){if(!Array.isArray(value))return out;if(value.length>=2&&Number.isFinite(Number(value[0]))&&Number.isFinite(Number(value[1]))){out.push([Number(value[0]),Number(value[1])]);return out}for(const child of value)flattenCoordinatePairs(child,out);return out}
function geometryCentre(geometry){const pairs=flattenCoordinatePairs(geometry?.coordinates);if(!pairs.length)return null;const valid=pairs.filter(([lon,lat])=>lon>=-180&&lon<=180&&lat>=-90&&lat<=90);if(!valid.length)return null;return{lon:valid.reduce((sum,p)=>sum+p[0],0)/valid.length,lat:valid.reduce((sum,p)=>sum+p[1],0)/valid.length}}
function lightningTimestamp(feature){const props=feature?.properties&&typeof feature.properties==='object'?feature.properties:{},preferred=Object.entries(props).filter(([key])=>/(time|date|valid|reference|start|end|timestamp)/i.test(key));for(const[,value]of preferred){const parsed=safeDate(value);if(parsed)return parsed}for(const value of[feature?.id,...Object.values(props)]){if(typeof value!=='string')continue;const match=value.match(/20\d{2}-?\d{2}-?\d{2}[T_ -]?\d{2}:?\d{2}(?::?\d{2})?/);if(match){const parsed=safeDate(match[0].replace('_','T'));if(parsed)return parsed}}return undefined}
function lightningNumber(properties,pattern){for(const[key,value]of Object.entries(properties||{}))if(pattern.test(key)&&number(value)!==undefined)return number(value);return undefined}
async function dwdLightningPoints(lat,lon){
 const latSpan=2.1,lonSpan=2.1/Math.max(.28,Math.cos(lat*Math.PI/180)),bbox=[lon-lonSpan,lat-latSpan,lon+lonSpan,lat+latSpan].map(value=>value.toFixed(5)).join(','),errors=[];
 for(const base of[DWD_WFS_PRIMARY,DWD_WFS_BACKUP])for(const version of['2.0.0','1.0.0']){try{const url=new URL(base);url.searchParams.set('service','WFS');url.searchParams.set('version',version);url.searchParams.set('request','GetFeature');url.searchParams.set(version==='2.0.0'?'typeNames':'typeName','dwd:Accumulated_Flash_Geometry');url.searchParams.set('outputFormat','application/json');url.searchParams.set('srsName','EPSG:4326');url.searchParams.set(version==='2.0.0'?'count':'maxFeatures','750');url.searchParams.set('bbox',`${bbox},EPSG:4326`);const response=await fetch(url.toString(),{headers:{Accept:'application/geo+json,application/json'},cf:{cacheTtl:120,cacheEverything:true}});if(!response.ok)throw new Error(`HTTP ${response.status}`);const data=await response.json(),features=Array.isArray(data?.features)?data.features:[],points=[];
   for(const feature of features){const centre=geometryCentre(feature.geometry);if(!centre)continue;const properties=feature.properties||{},observedAt=lightningTimestamp(feature),count=lightningNumber(properties,/(count|anzahl|flash|stroke|density|number)/i),intensity=lightningNumber(properties,/(intensity|current|amplitude|strength)/i);points.push({id:String(feature.id||`${centre.lat.toFixed(5)}:${centre.lon.toFixed(5)}:${points.length}`),lat:centre.lat,lon:centre.lon,observedAt,count,intensity})}
   if(points.length)return{points:points.slice(0,750),provider:'DWD NowCastMIX Accumulated Flash Geometry',observedAt:points.map(point=>point.observedAt).filter(Boolean).sort().at(-1),coverage:'Deutschland · DWD-WFS-Blitzgeometrien'};throw new Error('keine Features')
  }catch(error){errors.push(`${new URL(base).hostname}/WFS ${version}: ${error instanceof Error?error.message:String(error)}`)}}
 throw new Error(`DWD-Blitzpunkte nicht verfügbar: ${errors.slice(-3).join(' | ')}`);
}

const XWEATHER_LIGHTNING='https://data.api.xweather.com/lightning/closest';
function mtgLightningApplies(lat,lon){return lat>=-60&&lat<=72&&lon>=-75&&lon<=80}
async function xweatherLightningPoints(lat,lon,clientId,clientSecret,enterprise=false){
 const url=new URL(XWEATHER_LIGHTNING);url.searchParams.set('p',`${lat.toFixed(5)},${lon.toFixed(5)}`);url.searchParams.set('radius','100km');url.searchParams.set('limit',enterprise?'2500':'1000');url.searchParams.set('filter','all');if(enterprise)url.searchParams.set('from','-1hour');url.searchParams.set('format','json');url.searchParams.set('client_id',clientId);url.searchParams.set('client_secret',clientSecret);
 const response=await fetch(url.toString(),{headers:{Accept:'application/json'},cf:{cacheTtl:45,cacheEverything:true}});if(!response.ok)throw new Error(`Xweather Lightning HTTP ${response.status}`);const raw=await response.json();if(raw?.success===false)throw new Error(raw?.error?.description||'Xweather Lightning nicht autorisiert');const rows=Array.isArray(raw?.response)?raw.response:[],points=[];
 for(const row of rows){const plat=number(row?.loc?.lat),plon=number(row?.loc?.long),observedAt=safeDate(row?.ob?.dateTimeISOMS||row?.ob?.dateTimeISO||row?.ob?.timestampMS||Number(row?.ob?.timestamp)*1000);if(plat===undefined||plon===undefined||!observedAt)continue;points.push({id:String(row?.id||`${plat.toFixed(5)}:${plon.toFixed(5)}:${observedAt}`),lat:plat,lon:plon,observedAt,intensity:number(row?.ob?.pulse?.peakamp),pulseType:String(row?.ob?.pulse?.type||''),count:number(row?.ob?.pulse?.numSensors),accuracyKm:1})}
 return{points,provider:'Vaisala Xweather / GLD360',observedAt:points.map(point=>point.observedAt).sort().at(-1),coverage:'Weltweit · lizenzierte Bodenblitzdaten bis 100 km Umkreis',nativeResolutionKm:1,historyMinutes:enterprise?60:5,commercial:true,enterprise};
}
async function bestLightningPoints(lat,lon,env){
 if(env?.XWEATHER_CLIENT_ID&&env?.XWEATHER_CLIENT_SECRET){try{return await xweatherLightningPoints(lat,lon,env.XWEATHER_CLIENT_ID,env.XWEATHER_CLIENT_SECRET,env?.XWEATHER_LIGHTNING_ENTERPRISE==='true')}catch(error){if(!inGermanyBounds(lat,lon)&&!mtgLightningApplies(lat,lon))throw error}}
 if(inGermanyBounds(lat,lon)){try{return{...await dwdLightningPoints(lat,lon),nativeResolutionKm:1,historyMinutes:60,commercial:false}}catch(error){if(!mtgLightningApplies(lat,lon))throw error}}
 if(mtgLightningApplies(lat,lon))return{points:[],provider:'EUMETSAT MTG-LI AFA',coverage:'Europa, Afrika und angrenzende Ozeane · satellitengestütztes 2-km-Raster',fallback:'mtg-li',nativeResolutionKm:2,historyMinutes:60,commercial:false};
 return{points:[],provider:'Keine freie Echtzeit-Blitzquelle',coverage:'Außerhalb der freien DWD- und MTG-LI-Abdeckung',fallback:'none',reason:'Weltweite Punktdaten benötigen lizenzierte Xweather-/GLD360-, nowcast/LINET- oder Earth-Networks-Zugangsdaten.',commercial:false};
}


const EUMETSAT_WMS='https://view.eumetsat.int/geoserver/wms';
const SATELLITE_DAY_CANDIDATES=[
 {provider:'eumetsat',layer:'mtg_fd:vis06_hrfi',label:'MTG FCI VIS 0,6 HRFI',resolutionKm:.5},
 {provider:'eumetsat',layer:'msg_fes:rgb_eview',label:'MSG European HRV RGB',resolutionKm:1},
 {provider:'dwd',layer:'dwd:Satellite_meteosat_1km_euat_rgb_clouds_day_and_night',label:'DWD Meteosat Europa RGB/IR',resolutionKm:1},
 {provider:'dwd',layer:'dwd:SAT_EU_RGB',label:'DWD Meteosat Europa RGB',resolutionKm:1}
];
const SATELLITE_IR_CANDIDATES=[
 {provider:'eumetsat',layer:'mtg_fd:ir105_hrfi',label:'MTG FCI IR 10,5 HRFI',resolutionKm:1},
 {provider:'eumetsat',layer:'msg_fes:ir108',label:'MSG SEVIRI IR 10,8',resolutionKm:3},
 {provider:'dwd',layer:'dwd:Satellite_meteosat_1km_euat_rgb_clouds_day_and_night',label:'DWD Meteosat Europa Tag/Nacht',resolutionKm:1},
 {provider:'dwd',layer:'dwd:SAT_EU_RGB',label:'DWD Meteosat Europa RGB',resolutionKm:1}
];
const SATELLITE_LATEST_DAY={provider:'eumetsat',layer:'mtg_fd:rgb_geocolour',label:'MTG FCI GeoColour · aktueller Dienststand',resolutionKm:1,times:[],latestOnly:true,fallback:true};
const SATELLITE_LATEST_IR={provider:'eumetsat',layer:'mtg_fd:ir105_hrfi',label:'MTG FCI IR 10,5 · aktueller Dienststand',resolutionKm:1,times:[],latestOnly:true,fallback:true};
// H40B ist das operative MTG-FCI-Niederschlagsprodukt. Es wird automatisch
// bevorzugt, sobald EUMETView einen entsprechenden WMS-Layer veröffentlicht.
// Bis dahin ist das öffentlich verfügbare MSG/H SAF H60B der belastbare WMS-Fallback.
const SATELLITE_PRECIP_CANDIDATES=[
 {provider:'eumetsat',layer:'mtg_fd:h40b',label:'H SAF MTG H40B Niederschlagsrate',resolutionKm:2},
 {provider:'eumetsat',layer:'mtg_fd:precipitation_rate',label:'MTG FCI Niederschlagsrate',resolutionKm:2},
 {provider:'eumetsat',layer:'msg_fes:h60b',label:'H SAF Satelliten-Niederschlagsrate',resolutionKm:3}
];
async function wmsCapabilitiesText(base,label){const response=await fetchWithDeadline(dwdCapabilitiesUrl(base),{headers:{Accept:'application/xml,text/xml,*/*','Cache-Control':'no-cache'},cache:'no-store'},6000);if(!response.ok)throw new Error(`${label} Capabilities HTTP ${response.status}`);return response.text()}
async function firstWmsCapabilities(bases,label){const errors=[];for(const base of bases){try{return await wmsCapabilitiesText(base,label)}catch(error){errors.push(error instanceof Error?error.message:String(error))}}throw new Error(errors.join(' | ')||`${label} Capabilities nicht verfügbar`)}
function recentObservedTimes(times,now=Date.now(),historyMinutes=135,maxFrames=28,futureMinutes=10){const unique=[...new Set((times||[]).filter(Number.isFinite).filter(time=>time>=now-historyMinutes*60000&&time<=now+futureMinutes*60000))].sort((a,b)=>a-b);if(unique.length<=maxFrames)return unique;const step=Math.max(1,Math.ceil(unique.length/maxFrames)),selected=unique.filter((_,index)=>index%step===0);if(selected.at(-1)!==unique.at(-1))selected.push(unique.at(-1));return selected.slice(-maxFrames)}
function hasWmsLayer(xml,layer){const target=String(layer).trim().toLowerCase();return tagValues(xml,'Name').some(value=>value.trim().toLowerCase()===target)}
function satelliteProduct(capabilities,candidates,now=Date.now()){
 const products=[],latestOnly=[];
 for(const candidate of candidates){const xml=capabilities[candidate.provider];if(!xml||!hasWmsLayer(xml,candidate.layer))continue;const all=dwdTimesFromCapabilities(xml,candidate.layer),latest=all.at(-1);
  // Satellitenprodukte erscheinen häufig einige Minuten nach ihrem nominellen
  // Aufnahmezeitpunkt. Deshalb gilt ein großzügiger Publikationspuffer.
  if(Number.isFinite(latest)&&latest>=now-190*60000&&latest<=now+15*60000){const times=recentObservedTimes(all,now,150,30,15);if(times.length)products.push({...candidate,times:times.map(time=>new Date(time).toISOString()),latest,fresh:latest>=now-80*60000})}
  else latestOnly.push({...candidate,times:[],latestOnly:true,fresh:false});
 }
 products.sort((a,b)=>Number(b.fresh)-Number(a.fresh)||Number(b.provider==='eumetsat')-Number(a.provider==='eumetsat')||(a.resolutionKm??99)-(b.resolutionKm??99)||b.latest-a.latest);let chosen=products[0];
 if(!chosen){latestOnly.sort((a,b)=>Number(b.provider==='eumetsat')-Number(a.provider==='eumetsat')||(a.resolutionKm??99)-(b.resolutionKm??99));chosen=latestOnly[0]}
 if(!chosen)return undefined;const{latest,...product}=chosen;return{...product,latestTime:Number.isFinite(latest)?new Date(latest).toISOString():undefined,fallback:product.provider!=='eumetsat'||(!product.layer.startsWith('mtg_fd:')&&product.layer!=='msg_fes:h60b')}
}
async function compositeTimes(lat,lon){const serverTime=new Date().toISOString(),result={satelliteDay:[],satelliteIr:[],satellitePrecip:[],mtgLightning:[],dwdLightning:[],dwdRadar:[],dwdRadarLayer:'',dwdRadarLatestOnly:false,mtgLightningLatestOnly:false,checkedAt:serverTime,serverTime,errors:[]};
 if(mtgLightningApplies(lat,lon)){result.satelliteDayProduct={...SATELLITE_LATEST_DAY};result.satelliteIrProduct={...SATELLITE_LATEST_IR};result.mtgLightningLatestOnly=true}
 if(inGermanyBounds(lat,lon)){result.dwdRadarLayer='dwd:Niederschlagsradar';result.dwdRadarLatestOnly=true}
 return result;
}
function diagnosticMapUrl(base,layer,version,bbox){const url=new URL(base),params={service:'WMS',request:'GetMap',version,layers:layer,styles:'',format:'image/png',transparent:'true',bbox,width:'64',height:'64',[version==='1.3.0'?'crs':'srs']:'EPSG:3857'};for(const[key,value]of Object.entries(params))url.searchParams.set(key,value);return url.toString()}
async function compositeProbe(name,url){const started=Date.now();try{const response=await fetchWithDeadline(url,{headers:{Accept:'image/png,image/*,*/*','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`},cache:'no-store'},7000),type=String(response.headers.get('content-type')||'').toLowerCase();return{name,ok:response.ok&&type.startsWith('image/'),status:response.status,contentType:type,durationMs:Date.now()-started,error:response.ok&&type.startsWith('image/')?'':(await response.text()).slice(0,180).replace(/\s+/g,' ')}}catch(error){return{name,ok:false,status:0,contentType:'',durationMs:Date.now()-started,error:error instanceof Error?error.message:String(error)}}}
async function compositeDiagnostics(){const checks=await Promise.all([
 compositeProbe('DWD Niederschlagsradar',diagnosticMapUrl(DWD_RADAR_WMS_PRIMARY,'dwd:Niederschlagsradar','1.1.1','500000,5700000,1700000,7400000')),
 compositeProbe('EUMETSAT GeoColour',diagnosticMapUrl(EUMETSAT_WMS,'mtg_fd:rgb_geocolour','1.3.0','-2000000,3500000,3000000,8500000')),
 compositeProbe('EUMETSAT LI AFA',diagnosticMapUrl(EUMETSAT_WMS,'mtg_fd:li_afa','1.3.0','-2000000,3500000,3000000,8500000'))
 ]);return{ok:checks.every(item=>item.ok),checks,checkedAt:new Date().toISOString(),version:WORKER_VERSION}}

function interpolatePoint(a,b,level){const av=Number(a.value),bv=Number(b.value),den=bv-av,ratio=Math.abs(den)<1e-9?.5:clamp((level-av)/den,0,1);return[a.lat+(b.lat-a.lat)*ratio,a.lon+(b.lon-a.lon)*ratio]}
function distanceKm(a,b){const rad=Math.PI/180,lat1=a[0]*rad,lat2=b[0]*rad,dLat=(b[0]-a[0])*rad,dLon=(b[1]-a[1])*rad,h=Math.sin(dLat/2)**2+Math.cos(lat1)*Math.cos(lat2)*Math.sin(dLon/2)**2;return 12742*Math.asin(Math.min(1,Math.sqrt(h)))}
function median(values){const sorted=values.filter(Number.isFinite).sort((a,b)=>a-b);if(!sorted.length)return NaN;const middle=Math.floor(sorted.length/2);return sorted.length%2?sorted[middle]:(sorted[middle-1]+sorted[middle])/2}
function pressureCenters(values,lats,lons){const rows=values.length,cols=values[0]?.length||0,candidates=[];for(let row=1;row<rows-1;row++)for(let col=1;col<cols-1;col++){const value=values[row][col];if(!Number.isFinite(value))continue;const neighbours=[];for(let dr=-2;dr<=2;dr++)for(let dc=-2;dc<=2;dc++){if(!dr&&!dc)continue;const rr=row+dr,cc=col+dc;if(rr>=0&&rr<rows&&cc>=0&&cc<cols&&Number.isFinite(values[rr][cc]))neighbours.push(values[rr][cc])}if(neighbours.length<8)continue;const max=Math.max(...neighbours),min=Math.min(...neighbours),isHigh=value>=max,isLow=value<=min,prominence=isHigh?value-min:isLow?max-value:0;if((isHigh||isLow)&&prominence>=1.2)candidates.push({type:isHigh?'H':'T',lat:lats[row],lon:lons[col],value:Number(value.toFixed(1)),prominence})}candidates.sort((a,b)=>b.prominence-a.prominence);const selected=[];for(const candidate of candidates){if(selected.some(item=>distanceKm([candidate.lat,candidate.lon],[item.lat,item.lon])<550))continue;selected.push(candidate);if(selected.length>=8)break}return selected.map(({prominence,...item})=>({...item,prominence:Number(prominence.toFixed(1))}))}
function pressureContourStep(values,lats,lons){const gradients=[];for(let row=0;row<values.length;row++)for(let col=0;col<values[row].length;col++){const value=values[row][col];if(!Number.isFinite(value))continue;if(col+1<values[row].length&&Number.isFinite(values[row][col+1])){const km=distanceKm([lats[row],lons[col]],[lats[row],lons[col+1]]);if(km>0)gradients.push(Math.abs(values[row][col+1]-value)/km)}if(row+1<values.length&&Number.isFinite(values[row+1][col])){const km=distanceKm([lats[row],lons[col]],[lats[row+1],lons[col]]);if(km>0)gradients.push(Math.abs(values[row+1][col]-value)/km)}}const changePer100Km=median(gradients)*100;if(!Number.isFinite(changePer100Km))return 4;if(changePer100Km<1.5)return 1;if(changePer100Km<3)return 2;return 4}
function upsampleGrid(values,lats,lons,factor=2){if(factor<=1)return{values,lats,lons};const rows=(values.length-1)*factor+1,cols=(values[0].length-1)*factor+1,out=Array.from({length:rows},()=>Array(cols).fill(NaN)),outLats=Array(rows),outLons=Array(cols);for(let row=0;row<rows;row++){const sourceRow=row/factor,r0=Math.floor(sourceRow),r1=Math.min(values.length-1,r0+1),fy=sourceRow-r0;outLats[row]=lats[r0]+(lats[r1]-lats[r0])*fy;for(let col=0;col<cols;col++){const sourceCol=col/factor,c0=Math.floor(sourceCol),c1=Math.min(values[0].length-1,c0+1),fx=sourceCol-c0;if(row===0)outLons[col]=lons[c0]+(lons[c1]-lons[c0])*fx;const q00=values[r0][c0],q10=values[r0][c1],q01=values[r1][c0],q11=values[r1][c1];if([q00,q10,q01,q11].every(Number.isFinite))out[row][col]=q00*(1-fx)*(1-fy)+q10*fx*(1-fy)+q01*(1-fx)*fy+q11*fx*fy}}return{values:out,lats:outLats,lons:outLons}}
function pointKey(point){return`${point[0].toFixed(5)},${point[1].toFixed(5)}`}
function stitchSegments(segments){if(!segments.length)return[];const endpointMap=new Map();segments.forEach((segment,index)=>segment.forEach(point=>{const key=pointKey(point),items=endpointMap.get(key)||[];items.push(index);endpointMap.set(key,items)}));const used=new Set(),paths=[];for(let seed=0;seed<segments.length;seed++){if(used.has(seed))continue;const segment=segments[seed],aKey=pointKey(segment[0]),bKey=pointKey(segment[1]),start=(endpointMap.get(aKey)?.length||0)===1?segment[0]:(endpointMap.get(bKey)?.length||0)===1?segment[1]:segment[0],path=[start];let current=start;while(true){const candidates=(endpointMap.get(pointKey(current))||[]).filter(index=>!used.has(index));if(!candidates.length)break;const index=candidates[0],nextSegment=segments[index];used.add(index);const next=pointKey(nextSegment[0])===pointKey(current)?nextSegment[1]:nextSegment[0];path.push(next);current=next;if(path.length>segments.length+2)break}if(path.length>1)paths.push(path)}return paths}
function smoothPath(path,iterations=2){if(path.length<3)return path;let result=path.map(point=>[point[0],point[1]]),closed=pointKey(result[0])===pointKey(result[result.length-1]);if(closed)result=result.slice(0,-1);for(let iteration=0;iteration<iterations;iteration++){const next=[];if(!closed)next.push(result[0]);const count=closed?result.length:result.length-1;for(let index=0;index<count;index++){const a=result[index],b=result[(index+1)%result.length];next.push([a[0]*.75+b[0]*.25,a[1]*.75+b[1]*.25],[a[0]*.25+b[0]*.75,a[1]*.25+b[1]*.75])}if(!closed)next.push(result[result.length-1]);result=next}if(closed)result.push(result[0]);return result}
function contourSegments(values,lats,lons,step,maxLevels=90){const interpolated=upsampleGrid(values,lats,lons,2),field=interpolated.values,fieldLats=interpolated.lats,fieldLons=interpolated.lons,finite=field.flat().filter(Number.isFinite);if(!finite.length)return[];const min=Math.min(...finite),max=Math.max(...finite),first=Math.ceil(min/step)*step,levels=[];for(let level=first;level<=max&&levels.length<maxLevels;level+=step){const segments=[];for(let row=0;row<field.length-1;row++)for(let col=0;col<field[row].length-1;col++){const corners=[{lat:fieldLats[row],lon:fieldLons[col],value:field[row][col]},{lat:fieldLats[row],lon:fieldLons[col+1],value:field[row][col+1]},{lat:fieldLats[row+1],lon:fieldLons[col+1],value:field[row+1][col+1]},{lat:fieldLats[row+1],lon:fieldLons[col],value:field[row+1][col]}];if(corners.some(point=>!Number.isFinite(point.value)))continue;const edges=[[0,1],[1,2],[2,3],[3,0]],hits=[];for(const[i,j]of edges){const av=corners[i].value-level,bv=corners[j].value-level;if(av===0&&bv===0)continue;if(av===0||bv===0||av*bv<0)hits.push(interpolatePoint(corners[i],corners[j],level))}if(hits.length===2)segments.push([hits[0],hits[1]]);else if(hits.length>=4){const center=(corners[0].value+corners[1].value+corners[2].value+corners[3].value)/4;if(center>=level){segments.push([hits[0],hits[3]],[hits[1],hits[2]])}else{segments.push([hits[0],hits[1]],[hits[2],hits[3]])}}}const paths=stitchSegments(segments).filter(path=>path.length>2).map(path=>smoothPath(path,2));if(paths.length)levels.push({level:Number(level.toFixed(2)),paths})}return levels}
function openMeteoRows(data){return Array.isArray(data)?data:Array.isArray(data?.results)?data.results:[data]}

const METEOGRAM_LEVELS=[1000,975,950,925,900,850,800,700,600,500,400,300,250,200,150,100];
const METEOGRAM_MODELS=new Map([
 ['best_match',{label:'Best Match',hours:168}],
 ['dwd_icon_d2',{label:'DWD ICON-D2',hours:48}],
 ['dwd_icon_eu',{label:'DWD ICON-EU',hours:120}],
 ['meteofrance_arpege_europe',{label:'Météo-France ARPEGE Europa',hours:114}],
 ['ecmwf_ifs',{label:'ECMWF IFS HRES',hours:168}],
 ['ncep_gfs025',{label:'NOAA GFS 0,25°',hours:168}],
 ['dwd_icon',{label:'DWD ICON Global',hours:180}]
]);
const METEOGRAM_SURFACE=['temperature_2m','relative_humidity_2m','pressure_msl','wind_speed_10m','wind_direction_10m','wind_gusts_10m','precipitation','rain','showers','snowfall','snow_depth','weather_code','freezing_level_height'];
const METEOGRAM_PROFILE=METEOGRAM_LEVELS.flatMap(level=>[`temperature_${level}hPa`,`relative_humidity_${level}hPa`,`cloud_cover_${level}hPa`,`wind_speed_${level}hPa`,`wind_direction_${level}hPa`,`geopotential_height_${level}hPa`]);
async function meteogramData(lat,lon,model,elevation){
 const requested=METEOGRAM_MODELS.has(model)?model:'best_match',effective=requested==='best_match'?'ecmwf_ifs':requested,modelConfig=METEOGRAM_MODELS.get(effective),forecastHours=requested==='best_match'?168:modelConfig?.hours??168,url=new URL('https://api.open-meteo.com/v1/forecast');url.searchParams.set('latitude',String(lat));url.searchParams.set('longitude',String(lon));if(Number.isFinite(elevation))url.searchParams.set('elevation',String(Math.max(-500,Math.min(9000,elevation))));url.searchParams.set('hourly',[...METEOGRAM_SURFACE,...METEOGRAM_PROFILE].join(','));url.searchParams.set('forecast_hours',String(forecastHours));url.searchParams.set('models',effective);url.searchParams.set('timezone','GMT');url.searchParams.set('timeformat','unixtime');url.searchParams.set('wind_speed_unit','kn');url.searchParams.set('precipitation_unit','mm');url.searchParams.set('temperature_unit','celsius');url.searchParams.set('cell_selection','nearest');
 const response=await fetch(url.toString(),{headers:{Accept:'application/json','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`},cf:{cacheTtl:600,cacheEverything:true}}),text=await response.text();let data={};try{data=JSON.parse(text)}catch{}if(!response.ok||data?.error)throw new Error(data?.reason||data?.error||`Open-Meteo Meteogramm HTTP ${response.status}`);
 let meta=null;try{const metaResponse=await fetch(`https://api.open-meteo.com/data/${effective}/static/meta.json`,{headers:{Accept:'application/json','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`},cf:{cacheTtl:600,cacheEverything:true}});if(metaResponse.ok)meta=await metaResponse.json()}catch{}
 const initial=number(meta?.last_run_initialisation_time),available=number(meta?.last_run_availability_time),label=requested==='best_match'?`Best Match · ${modelConfig?.label||effective}`:modelConfig?.label;return{data,requestedModel:requested,effectiveModel:effective,modelLabel:label,forecastHours,runInitialisationTime:Number.isFinite(initial)?new Date(initial*1000).toISOString():undefined,runAvailabilityTime:Number.isFinite(available)?new Date(available*1000).toISOString():undefined,checkedAt:new Date().toISOString()};
}
function modelContourDomain(lat,lon){
 if(lat>=30&&lat<=72&&lon>=-30&&lon<=48)return{scope:'Europa',south:33,north:70,west:-23,east:45,rows:17,cols:25,model:'dwd_icon_eu',modelLabel:'DWD ICON-EU',fallbackModel:'dwd_icon',fallbackLabel:'DWD ICON Global'};
 if(lat>=15&&lat<=72&&lon>=-170&&lon<=-45)return{scope:'Nordamerika',south:20,north:68,west:-145,east:-52,rows:17,cols:25,model:'ncep_gfs025',modelLabel:'NOAA GFS 0,25°'};
 const latSpan=34,cos=Math.max(.35,Math.cos(lat*Math.PI/180)),lonSpan=Math.min(90,52/cos),south=Math.max(-80,lat-latSpan/2),north=Math.min(80,lat+latSpan/2),west=Math.max(-180,lon-lonSpan/2),east=Math.min(180,lon+lonSpan/2);return{scope:'Großregion',south,north,west,east,rows:17,cols:25,model:'dwd_icon',modelLabel:'DWD ICON Global'}
}
async function modelContours(lat,lon){
 const domain=modelContourDomain(lat,lon),{rows,cols,south,north,west,east}=domain,lats=Array.from({length:rows},(_,index)=>north-index*(north-south)/(rows-1)),lons=Array.from({length:cols},(_,index)=>west+index*(east-west)/(cols-1));
 const fetchGrid=async(model,modelLabel)=>{
  const fetchRow=async rowIndex=>{const url=new URL('https://api.open-meteo.com/v1/forecast'),latitudes=Array.from({length:cols},()=>lats[rowIndex].toFixed(4)),longitudes=lons.map(value=>value.toFixed(4));url.searchParams.set('latitude',latitudes.join(','));url.searchParams.set('longitude',longitudes.join(','));url.searchParams.set('hourly','pressure_msl,geopotential_height_500hPa');url.searchParams.set('past_hours','2');url.searchParams.set('forecast_hours','5');url.searchParams.set('models',model);url.searchParams.set('timezone','GMT');url.searchParams.set('cell_selection','nearest');const response=await fetch(url.toString(),{headers:{Accept:'application/json','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`},cf:{cacheTtl:900,cacheEverything:true}}),text=await response.text();let payload={};try{payload=JSON.parse(text)}catch{}if(!response.ok||payload?.error)throw new Error(payload?.reason||payload?.error||`Open-Meteo Modelllinien HTTP ${response.status}`);const points=openMeteoRows(payload);if(points.length!==cols)throw new Error(`Open-Meteo lieferte ${points.length} statt ${cols} Rasterpunkte in Zeile ${rowIndex+1}.`);if(points.some(point=>point?.error||!point?.hourly))throw new Error(`Open-Meteo lieferte unvollständige Modelllinien in Zeile ${rowIndex+1}.`);return points};
  const rowSets=[];for(let start=0;start<rows;start+=4){const batch=await Promise.all(Array.from({length:Math.min(4,rows-start)},(_,offset)=>fetchRow(start+offset)));rowSets.push(...batch)}return{points:rowSets.flat(),model,modelLabel}
 };
 let selected,primaryError='';try{selected=await fetchGrid(domain.model,domain.modelLabel)}catch(error){primaryError=error instanceof Error?error.message:String(error);if(!domain.fallbackModel)throw error;selected=await fetchGrid(domain.fallbackModel,domain.fallbackLabel)}
 const points=selected.points,times=points[0]?.hourly?.time||[],frames=[];
 for(let ti=0;ti<times.length;ti++){const pressure=Array.from({length:rows},()=>Array(cols).fill(NaN)),height=Array.from({length:rows},()=>Array(cols).fill(NaN));for(let pi=0;pi<points.length;pi++){const row=Math.floor(pi/cols),col=pi%cols;pressure[row][col]=number(points[pi]?.hourly?.pressure_msl?.[ti])??NaN;height[row][col]=number(points[pi]?.hourly?.geopotential_height_500hPa?.[ti])??NaN}const stamp=safeDate(times[ti]);if(!stamp)continue;const isobarStep=pressureContourStep(pressure,lats,lons);frames.push({time:stamp,isobarStep,isoheightStepGpdm:8,isobars:contourSegments(pressure,lats,lons,isobarStep),isoheights:contourSegments(height,lats,lons,80,35),centers:pressureCenters(pressure,lats,lons)})}
 if(!frames.length)throw new Error('Open-Meteo lieferte keine auswertbaren Modelllinien.');return{frames,provider:'Open-Meteo',model:selected.modelLabel,resolutionNote:`${domain.scope} · einheitliches ${selected.modelLabel} · ${rows}×${cols} Stützraster, bilinear verdichtet und geglättet`,grid:{rows,cols,latSpan:north-south,lonSpan:east-west,scope:domain.scope,bounds:{south,north,west,east}},contours:{isobars:'dynamisch 1/2/4 hPa nach Druckgradient; Zielabstand ungefähr 100 km',isoheights:'8 gpdm'},fallback:primaryError?{from:domain.modelLabel,to:selected.modelLabel,reason:primaryError}:undefined,checkedAt:new Date().toISOString()};
}
const WMS_ALLOWED_LAYERS={
 dwd:new Set([...DWD_RADAR_LAYERS,'dwd:Blitzdichte',...SATELLITE_DAY_CANDIDATES.filter(item=>item.provider==='dwd').map(item=>item.layer),...SATELLITE_IR_CANDIDATES.filter(item=>item.provider==='dwd').map(item=>item.layer)]),
 eumetsat:new Set(['mtg_fd:vis06_hrfi','mtg_fd:ir105_hrfi','mtg_fd:li_afa','msg_fes:rgb_eview','msg_fes:ir108',...SATELLITE_PRECIP_CANDIDATES.map(item=>item.layer)])
};
async function compositeWmsResponse(request){
 const url=new URL(request.url),provider=String(url.searchParams.get('provider')||'').toLowerCase(),bases=provider==='dwd'?DWD_RADAR_WMS_BASES:provider==='eumetsat'?[EUMETSAT_WMS]:[];
 if(!bases.length)return json({error:'Ungültiger WMS-Provider',version:WORKER_VERSION},400,{'cache-control':'no-store'});
 const layers=String(url.searchParams.get('layers')||'').split(',').map(value=>value.trim()).filter(Boolean),allowedLayers=WMS_ALLOWED_LAYERS[provider];
 if(!layers.length||layers.some(layer=>!allowedLayers?.has(layer)))return json({error:'Nicht freigegebener WMS-Layer',version:WORKER_VERSION},400,{'cache-control':'no-store'});
 const requestedTime=url.searchParams.get('time'),requestedMs=requestedTime?Date.parse(requestedTime):NaN;if(requestedTime&&!Number.isFinite(requestedMs))return json({error:'Ungültiger WMS-Zeitpunkt',version:WORKER_VERSION},400,{'cache-control':'no-store'});
 if(Number.isFinite(requestedMs)){const now=Date.now(),isRadar=layers.some(layer=>DWD_RADAR_LAYERS.includes(layer)),isLightning=layers.some(layer=>layer==='dwd:Blitzdichte'||layer==='mtg_fd:li_afa'),isSatellitePrecip=layers.some(layer=>SATELLITE_PRECIP_CANDIDATES.some(item=>item.layer===layer)),minimum=now-(isRadar?70:isLightning?135:isSatellitePrecip?195:195)*60000,maximum=now+(isRadar?125:15)*60000;if(requestedMs<minimum||requestedMs>maximum)return json({error:'Der angeforderte WMS-Zeitpunkt liegt außerhalb des zulässigen Live-/Nowcast-Fensters.',version:WORKER_VERSION,serverTime:new Date(now).toISOString()},409,{'cache-control':'no-store'})}
 const allowed=new Set(['service','request','version','layers','styles','format','transparent','crs','srs','bbox','width','height','time','exceptions','bgcolor','tiled']);
 const attempt=async base=>{const upstream=new URL(base);for(const[key,value]of url.searchParams){const normalized=key.toLowerCase();if(!allowed.has(normalized))continue;const outgoing=provider==='dwd'&&normalized==='layers'?String(value).split(',').map(layer=>dwdLayerForEndpoint(layer,base)).join(','):value;upstream.searchParams.set(normalized,outgoing)}if(!upstream.searchParams.has('service'))upstream.searchParams.set('service','WMS');if(!upstream.searchParams.has('request'))upstream.searchParams.set('request','GetMap');const response=await fetchWithDeadline(upstream.toString(),{headers:{Accept:'image/png,image/webp,image/jpeg,*/*','User-Agent':`MID-weather-dashboard/${WORKER_VERSION}`,'Cache-Control':'no-cache'},cache:'no-store'},7000),type=String(response.headers.get('content-type')||'').toLowerCase();if(!response.ok)throw new Error(`${new URL(base).hostname}${new URL(base).pathname} HTTP ${response.status}`);if(!type.startsWith('image/')){const text=(await response.text()).slice(0,240).replace(/\s+/g,' ');throw new Error(`${new URL(base).hostname}${new URL(base).pathname} lieferte kein Kartenbild${text?`: ${text}`:''}`)}return{response,type,base}};
 try{const{response,type,base}=await Promise.any(bases.map(attempt));return new Response(response.body,{status:200,headers:{'content-type':type,'access-control-allow-origin':'*','cache-control':'no-store, no-cache, must-revalidate','pragma':'no-cache','expires':'0','x-mid-wms-provider':provider,'x-mid-wms-layer':layers.join(','),'x-mid-wms-endpoint':new URL(base).pathname,'x-mid-worker-version':WORKER_VERSION}})}catch(error){const errors=error instanceof AggregateError?error.errors.map(item=>item instanceof Error?item.message:String(item)):[error instanceof Error?error.message:String(error)];return new Response(errors.join(' | ')||'WMS-Karte nicht verfügbar',{status:502,headers:{'content-type':'text/plain; charset=utf-8','access-control-allow-origin':'*','cache-control':'no-store','x-mid-worker-version':WORKER_VERSION}})};
}


const PUSH_DEFAULT_ORIGIN='https://meteomartini.github.io';
const PUSH_ENCODER=new TextEncoder();
function pushConfigured(env){return Boolean(env?.MID_PUSH_SUBSCRIPTIONS&&env?.VAPID_PUBLIC_KEY&&env?.VAPID_PRIVATE_KEY&&env?.VAPID_SUBJECT)}
function pushOrigins(env){return String(env?.MID_ALLOWED_ORIGINS||env?.MID_ALLOWED_ORIGIN||PUSH_DEFAULT_ORIGIN).split(/[\s,;]+/).map(value=>value.trim()).filter(Boolean)}
function pushOriginAllowed(request,env){const origin=String(request.headers.get('origin')||'');if(!origin)return false;if(/^https?:\/\/(?:localhost|127\.0\.0\.1)(?::\d+)?$/i.test(origin))return true;return pushOrigins(env).includes(origin)}
function pushB64Decode(value=''){const normalized=String(value).replace(/-/g,'+').replace(/_/g,'/'),padded=normalized+'='.repeat((4-normalized.length%4)%4),raw=atob(padded),bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return bytes}
function pushB64Encode(value){const bytes=value instanceof Uint8Array?value:new Uint8Array(value);let raw='';for(let i=0;i<bytes.length;i++)raw+=String.fromCharCode(bytes[i]);return btoa(raw).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'')}
function pushConcat(...parts){const arrays=parts.map(part=>part instanceof Uint8Array?part:new Uint8Array(part)),length=arrays.reduce((sum,item)=>sum+item.length,0),out=new Uint8Array(length);let offset=0;for(const item of arrays){out.set(item,offset);offset+=item.length}return out}
async function pushHmac(key,data){const cryptoKey=await crypto.subtle.importKey('raw',key,{name:'HMAC',hash:'SHA-256'},false,['sign']);return new Uint8Array(await crypto.subtle.sign('HMAC',cryptoKey,data))}
async function pushHkdfExpand(prk,info,length){let result=new Uint8Array(0),previous=new Uint8Array(0),counter=1;while(result.length<length){previous=await pushHmac(prk,pushConcat(previous,info,new Uint8Array([counter++])));result=pushConcat(result,previous)}return result.slice(0,length)}
async function pushHash(value){return pushB64Encode(new Uint8Array(await crypto.subtle.digest('SHA-256',PUSH_ENCODER.encode(String(value)))))}
async function vapidToken(endpoint,env){const publicRaw=pushB64Decode(env.VAPID_PUBLIC_KEY),privateRaw=pushB64Decode(env.VAPID_PRIVATE_KEY);if(publicRaw.length!==65||publicRaw[0]!==4||privateRaw.length!==32)throw new Error('Ungültige VAPID-Schlüssel.');const jwk={kty:'EC',crv:'P-256',x:pushB64Encode(publicRaw.slice(1,33)),y:pushB64Encode(publicRaw.slice(33,65)),d:pushB64Encode(privateRaw),ext:true,key_ops:['sign']},key=await crypto.subtle.importKey('jwk',jwk,{name:'ECDSA',namedCurve:'P-256'},false,['sign']),header=pushB64Encode(PUSH_ENCODER.encode(JSON.stringify({typ:'JWT',alg:'ES256'}))),payload=pushB64Encode(PUSH_ENCODER.encode(JSON.stringify({aud:new URL(endpoint).origin,exp:Math.floor(Date.now()/1000)+12*3600,sub:String(env.VAPID_SUBJECT||'mailto:mid@meteomartini.invalid')}))),unsigned=`${header}.${payload}`,signature=new Uint8Array(await crypto.subtle.sign({name:'ECDSA',hash:'SHA-256'},key,PUSH_ENCODER.encode(unsigned)));return`${unsigned}.${pushB64Encode(signature)}`}
async function encryptPushPayload(subscription,payload){const clientPublic=pushB64Decode(subscription?.keys?.p256dh),authSecret=pushB64Decode(subscription?.keys?.auth);if(clientPublic.length!==65||authSecret.length<16)throw new Error('Ungültige Push-Abonnementschlüssel.');const clientKey=await crypto.subtle.importKey('raw',clientPublic,{name:'ECDH',namedCurve:'P-256'},false,[]),serverKeys=await crypto.subtle.generateKey({name:'ECDH',namedCurve:'P-256'},true,['deriveBits']),shared=new Uint8Array(await crypto.subtle.deriveBits({name:'ECDH',public:clientKey},serverKeys.privateKey,256)),serverPublic=new Uint8Array(await crypto.subtle.exportKey('raw',serverKeys.publicKey)),prkKey=await pushHmac(authSecret,shared),keyInfo=pushConcat(PUSH_ENCODER.encode('WebPush: info\0'),clientPublic,serverPublic),ikm=await pushHkdfExpand(prkKey,keyInfo,32),salt=crypto.getRandomValues(new Uint8Array(16)),prk=await pushHmac(salt,ikm),cek=await pushHkdfExpand(prk,PUSH_ENCODER.encode('Content-Encoding: aes128gcm\0'),16),nonce=await pushHkdfExpand(prk,PUSH_ENCODER.encode('Content-Encoding: nonce\0'),12),aesKey=await crypto.subtle.importKey('raw',cek,'AES-GCM',false,['encrypt']),record=pushConcat(PUSH_ENCODER.encode(JSON.stringify(payload)),new Uint8Array([2])),ciphertext=new Uint8Array(await crypto.subtle.encrypt({name:'AES-GCM',iv:nonce,tagLength:128},aesKey,record)),header=new Uint8Array(21+serverPublic.length),view=new DataView(header.buffer);header.set(salt,0);view.setUint32(16,4096,false);header[20]=serverPublic.length;header.set(serverPublic,21);return pushConcat(header,ciphertext)}
async function sendWebPush(subscription,payload,env){const body=await encryptPushPayload(subscription,payload),jwt=await vapidToken(subscription.endpoint,env),response=await fetch(subscription.endpoint,{method:'POST',headers:{Authorization:`vapid t=${jwt}, k=${env.VAPID_PUBLIC_KEY}`,'Content-Encoding':'aes128gcm','Content-Type':'application/octet-stream',TTL:'300',Urgency:'normal'},body});return{ok:response.ok,status:response.status,expired:response.status===404||response.status===410}}
function validPushFavorites(value){return(Array.isArray(value)?value:[]).slice(0,24).map(item=>({id:String(item?.id||'').slice(0,100),name:String(item?.name||'Favorit').slice(0,100),latitude:number(item?.latitude),longitude:number(item?.longitude),country:String(item?.country||'').slice(0,40),rules:{precipitationStart:Boolean(item?.rules?.precipitationStart),thunderstormApproach:Boolean(item?.rules?.thunderstormApproach),forecastMaterialChange:Boolean(item?.rules?.forecastMaterialChange)}})).filter(item=>item.id&&item.latitude!==undefined&&item.longitude!==undefined&&(item.rules.precipitationStart||item.rules.thunderstormApproach||item.rules.forecastMaterialChange))}
function validPushSubscription(value){const endpoint=String(value?.endpoint||''),p256dh=String(value?.keys?.p256dh||''),auth=String(value?.keys?.auth||'');if(!/^https:\/\//i.test(endpoint)||!p256dh||!auth)return null;return{endpoint,expirationTime:value?.expirationTime??null,keys:{p256dh,auth}}}
async function pushSubscribe(request,env){if(!pushConfigured(env))return json({error:'Push-Dienst ist im Worker noch nicht konfiguriert.',version:WORKER_VERSION},503,{'cache-control':'no-store'});if(!pushOriginAllowed(request,env))return json({error:'Origin für Push-Verwaltung nicht zugelassen.',version:WORKER_VERSION},403,{'cache-control':'no-store'});let body;try{body=await request.json()}catch{return json({error:'Ungültiger JSON-Inhalt.',version:WORKER_VERSION},400,{'cache-control':'no-store'})}const subscription=validPushSubscription(body?.subscription);if(!subscription)return json({error:'Ungültiges Push-Abonnement.',version:WORKER_VERSION},400,{'cache-control':'no-store'});const key=`sub:${await pushHash(subscription.endpoint)}`,existing=await env.MID_PUSH_SUBSCRIPTIONS.get(key,{type:'json'}).catch(()=>null),entry={subscription,favorites:validPushFavorites(body?.favorites),appUrl:String(body?.appUrl||env.MID_APP_URL||'https://meteomartini.github.io/MID/').slice(0,500),userAgent:String(body?.userAgent||'').slice(0,300),state:existing?.state&&typeof existing.state==='object'?existing.state:{},createdAt:existing?.createdAt||new Date().toISOString(),updatedAt:new Date().toISOString()};await env.MID_PUSH_SUBSCRIPTIONS.put(key,JSON.stringify(entry));return json({ok:true,favorites:entry.favorites.length,version:WORKER_VERSION},200,{'cache-control':'no-store'})}
async function pushUnsubscribe(request,env){if(!env?.MID_PUSH_SUBSCRIPTIONS)return json({ok:true,version:WORKER_VERSION},200,{'cache-control':'no-store'});if(!pushOriginAllowed(request,env))return json({error:'Origin für Push-Verwaltung nicht zugelassen.',version:WORKER_VERSION},403,{'cache-control':'no-store'});let body;try{body=await request.json()}catch{body={}}const endpoint=String(body?.endpoint||'');if(endpoint)await env.MID_PUSH_SUBSCRIPTIONS.delete(`sub:${await pushHash(endpoint)}`);return json({ok:true,version:WORKER_VERSION},200,{'cache-control':'no-store'})}
async function pushWeatherState(favorite){const url=new URL('https://api.open-meteo.com/v1/forecast');url.searchParams.set('latitude',String(favorite.latitude));url.searchParams.set('longitude',String(favorite.longitude));url.searchParams.set('timezone','GMT');url.searchParams.set('forecast_minutely_15','8');url.searchParams.set('past_minutely_15','1');url.searchParams.set('current','precipitation,rain,showers,snowfall,weather_code');url.searchParams.set('minutely_15','precipitation,rain,showers,snowfall,weather_code');const data=await fetchJson(url.toString()),current=data?.current??{},amount=Math.max(number(current.precipitation)||0,number(current.rain)||0,number(current.showers)||0,number(current.snowfall)||0),active=amount>=.05,times=data?.minutely_15?.time??[],precip=data?.minutely_15?.precipitation??[],rain=data?.minutely_15?.rain??[],showers=data?.minutely_15?.showers??[],snow=data?.minutely_15?.snowfall??[],now=Date.now();let upcomingMinutes,upcomingKey='',kind=number(current.snowfall)>.02?'Schnee':number(current.showers)>.02?'Schauer':'Regen';if(!active)for(let i=0;i<times.length;i++){const total=Math.max(number(precip[i])||0,number(rain[i])||0,number(showers[i])||0,number(snow[i])||0),time=Date.parse(`${times[i]}Z`),minutes=Math.round((time-now)/60000);if(total>=.05&&minutes>=0&&minutes<=25){upcomingMinutes=minutes;upcomingKey=String(times[i]);kind=(number(snow[i])||0)>.02?'Schnee':(number(showers[i])||0)>.02?'Schauer':'Regen';break}}return{active,upcomingMinutes,upcomingKey,kind}}
function pushThunderState(result){const candidates=Array.isArray(result?.nearbyCells)?result.nearbyCells:[],cell=candidates.filter(item=>Number(item?.currentDistanceKm)<=20||(item?.isApproaching&&Number(item?.relevanceDistanceKm)<=35&&(item?.arrivalMinutes===undefined||Number(item.arrivalMinutes)<=60))).sort((a,b)=>Number(a?.relevanceDistanceKm??a?.currentDistanceKm??999)-Number(b?.relevanceDistanceKm??b?.currentDistanceKm??999))[0];if(!cell)return{active:false};return{active:true,key:String(cell.id||`${Math.round(Number(cell.latitude)||0)}:${Math.round(Number(cell.longitude)||0)}`),distanceKm:Number(cell.relevanceDistanceKm??cell.currentDistanceKm),arrivalMinutes:number(cell.arrivalMinutes)}}
function pushForecastRounded(value,digits=1){const n=Number(value);if(!Number.isFinite(n))return 0;const factor=10**digits;return Math.round(n*factor)/factor}
async function pushForecastState(favorite){const url=new URL('https://api.open-meteo.com/v1/forecast');url.searchParams.set('latitude',String(favorite.latitude));url.searchParams.set('longitude',String(favorite.longitude));url.searchParams.set('timezone','auto');url.searchParams.set('forecast_days','8');url.searchParams.set('wind_speed_unit','kn');url.searchParams.set('models','best_match');url.searchParams.set('daily','temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_gusts_10m_max');url.searchParams.set('hourly','precipitation,precipitation_probability');const data=await fetchJson(url.toString()),daily=data?.daily??{},times=Array.isArray(daily.time)?daily.time:[],rows=times.slice(0,8).map((date,index)=>({date:String(date),max:pushForecastRounded(daily.temperature_2m_max?.[index]),min:pushForecastRounded(daily.temperature_2m_min?.[index]),precipitation:pushForecastRounded(daily.precipitation_sum?.[index]),probability:Math.round(number(daily.precipitation_probability_max?.[index])||0),gust:pushForecastRounded(daily.wind_gusts_10m_max?.[index])})),hourTimes=Array.isArray(data?.hourly?.time)?data.hourly.time:[],hourPrecip=Array.isArray(data?.hourly?.precipitation)?data.hourly.precipitation:[],hourProbability=Array.isArray(data?.hourly?.precipitation_probability)?data.hourly.precipitation_probability:[],offsetSeconds=number(data?.utc_offset_seconds)||0,now=Date.now()-3600000;let onset='';for(let index=0;index<hourTimes.length;index++){const epoch=Date.parse(`${hourTimes[index]}Z`)-offsetSeconds*1000;if(epoch<now)continue;if((number(hourPrecip[index])||0)>=.1||(number(hourProbability[index])||0)>=65){onset=String(hourTimes[index]);break}}const signature=JSON.stringify({rows,onset});return{signature,rows,onset,checkedAt:new Date().toISOString()}}
function pushForecastChangeEvents(previous,current){if(!previous?.rows?.length||!current?.rows?.length)return[];const before=new Map(previous.rows.map(row=>[row.date,row])),events=[];for(const row of current.rows.slice(0,7)){const old=before.get(row.date);if(!old)continue;const add=(metric,delta,threshold,unit,label)=>{if(Math.abs(delta)>=threshold)events.push({metric,date:row.date,delta,label,text:`${label} ${delta>0?'+':''}${Math.round(delta*10)/10} ${unit}`})};add('tmax',row.max-old.max,2.5,'K','Tmax');add('tmin',row.min-old.min,2.5,'K','Tmin');add('probability',row.probability-old.probability,25,'%-Punkte','Regenwahrscheinlichkeit');add('gust',row.gust-old.gust,12,'kt','Böen');const rainDelta=row.precipitation-old.precipitation,rainReference=Math.max(row.precipitation,old.precipitation);if(Math.abs(rainDelta)>=5&&(rainReference>=5||Math.abs(rainDelta)>=10))events.push({metric:'precipitation',date:row.date,delta:rainDelta,label:'Niederschlag',text:`Niederschlag ${rainDelta>0?'+':''}${Math.round(rainDelta*10)/10} mm`})}if(previous.onset&&current.onset){const delta=(Date.parse(current.onset)-Date.parse(previous.onset))/3600000;if(Number.isFinite(delta)&&Math.abs(delta)>=2)events.push({metric:'onset',delta,label:'Regenbeginn',text:`Regenbeginn ${Math.abs(Math.round(delta))} h ${delta>0?'später':'früher'}`})}else if(previous.onset&&!current.onset)events.push({metric:'onset',delta:0,label:'Regenbeginn',text:'Niederschlag aus dem 8-Tage-Fenster verschwunden'});else if(!previous.onset&&current.onset)events.push({metric:'onset',delta:0,label:'Regenbeginn',text:'Niederschlag neu im 8-Tage-Fenster'});return events.slice(0,8)}
function pushForecastEventText(event){const date=event.date?new Intl.DateTimeFormat('de-DE',{weekday:'short',day:'2-digit',month:'2-digit',timeZone:'UTC'}).format(new Date(`${event.date}T12:00:00Z`)):'Nächster Zeitraum';return`${date}: ${event.text}`}
async function pushMapLimited(items,limit,task){let cursor=0;const workers=Array.from({length:Math.min(limit,items.length)},async()=>{while(cursor<items.length){const index=cursor++;await task(items[index],index)}});await Promise.all(workers)}
async function evaluatePushEntry(key,entry,env,weatherCache,thunderCache,forecastCache){const subscription=validPushSubscription(entry?.subscription);if(!subscription){await env.MID_PUSH_SUBSCRIPTIONS.delete(key);return}const favorites=validPushFavorites(entry?.favorites),state=entry?.state&&typeof entry.state==='object'?entry.state:{},appUrl=String(entry?.appUrl||env.MID_APP_URL||'https://meteomartini.github.io/MID/');let expired=false,changed=false;for(const favorite of favorites){const old=state[favorite.id]??{},next={...old};if(favorite.rules.precipitationStart){const cacheKey=`${favorite.latitude.toFixed(4)}:${favorite.longitude.toFixed(4)}`;let weather=weatherCache.get(cacheKey);if(!weather){weather=pushWeatherState(favorite);weatherCache.set(cacheKey,weather)}try{const result=await weather,eventKey=result.upcomingKey||'',triggerActive=result.active&&!old.precipitationActive,triggerUpcoming=!result.active&&result.upcomingMinutes!==undefined&&eventKey!==old.rainEventKey;if(triggerActive||triggerUpcoming){const body=triggerActive?`${result.kind} hat am Favoriten begonnen.`:`${result.kind} beginnt voraussichtlich in ${result.upcomingMinutes} Minuten.`,sent=await sendWebPush(subscription,{title:`MID · ${favorite.name}`,body,tag:`mid-rain-${favorite.id}`,url:appUrl,favoriteId:favorite.id,timestamp:Date.now(),renotify:true},env);if(sent.expired){expired=true;break}if(sent.ok){next.rainEventKey=eventKey||`active-${new Date().toISOString().slice(0,13)}`;next.lastRainNotificationAt=new Date().toISOString()}}next.precipitationActive=result.active;if(!result.active&&result.upcomingMinutes===undefined)next.rainEventKey='';changed=true}catch(error){next.precipitationError=error instanceof Error?error.message:String(error)}}if(favorite.rules.thunderstormApproach&&!expired){const cacheKey=`${favorite.latitude.toFixed(4)}:${favorite.longitude.toFixed(4)}:${favorite.country}`;let thunder=thunderCache.get(cacheKey);if(!thunder){thunder=dwdKonrad3dNowcast(favorite.latitude,favorite.longitude,favorite.country);thunderCache.set(cacheKey,thunder)}try{const result=pushThunderState(await thunder),trigger=result.active&&(!old.thunderActive||result.key!==old.thunderCellKey);if(trigger){const distanceText=Number.isFinite(result.distanceKm)?` · Abstand etwa ${Math.round(result.distanceKm)} km`:'',arrivalText=Number.isFinite(result.arrivalMinutes)?` · mögliche Annäherung in ${Math.round(result.arrivalMinutes)} min`:'',sent=await sendWebPush(subscription,{title:`MID · Gewitter bei ${favorite.name}`,body:`Eine Gewitterzelle nähert sich dem Favoriten${distanceText}${arrivalText}. Keine amtliche Warnung.`,tag:`mid-thunder-${favorite.id}`,url:appUrl,favoriteId:favorite.id,timestamp:Date.now(),renotify:true},env);if(sent.expired){expired=true;break}if(sent.ok)next.lastThunderNotificationAt=new Date().toISOString()}next.thunderActive=result.active;next.thunderCellKey=result.active?result.key:'';changed=true}catch(error){next.thunderError=error instanceof Error?error.message:String(error)}}if(favorite.rules.forecastMaterialChange&&!expired){const cacheKey=`${favorite.latitude.toFixed(4)}:${favorite.longitude.toFixed(4)}`;let forecast=forecastCache.get(cacheKey);if(!forecast){forecast=pushForecastState(favorite);forecastCache.set(cacheKey,forecast)}try{const result=await forecast,reference=old.forecastReferenceSnapshot||old.forecastSnapshot,events=pushForecastChangeEvents(reference,result),newSignature=result.signature!==old.forecastSnapshot?.signature;if(newSignature){if(reference&&events.length&&old.forecastNotifiedSignature!==result.signature){const visibleName=favorite.name.replace(/^Modelllaufänderung\s*·\s*/i,''),extra=events.length>2?` · plus ${events.length-2} weitere`:'',sent=await sendWebPush(subscription,{title:`MID · Prognoseänderung bei ${visibleName}`,body:`${events.slice(0,2).map(pushForecastEventText).join(' · ')}${extra}`,tag:`mid-model-change-${favorite.id}`,url:appUrl,favoriteId:favorite.id,timestamp:Date.now(),renotify:true},env);if(sent.expired){expired=true;break}if(sent.ok){next.forecastNotifiedSignature=result.signature;next.forecastReferenceSnapshot=result;next.lastForecastChangeNotificationAt=new Date().toISOString()}}if(!reference)next.forecastReferenceSnapshot=result;next.forecastSnapshot=result;next.forecastMaterialChanges=events;changed=true}}catch(error){next.forecastChangeError=error instanceof Error?error.message:String(error)}}state[favorite.id]=next}if(expired){await env.MID_PUSH_SUBSCRIPTIONS.delete(key);return}if(changed)await env.MID_PUSH_SUBSCRIPTIONS.put(key,JSON.stringify({...entry,subscription,favorites,state,checkedAt:new Date().toISOString()}))}
async function runPushSchedule(env){if(!pushConfigured(env))return{ok:false,reason:'not-configured'};const listed=await env.MID_PUSH_SUBSCRIPTIONS.list({prefix:'sub:',limit:250}),weatherCache=new Map(),thunderCache=new Map(),forecastCache=new Map();await pushMapLimited(listed.keys??[],4,async item=>{const entry=await env.MID_PUSH_SUBSCRIPTIONS.get(item.name,{type:'json'}).catch(()=>null);if(entry)await evaluatePushEntry(item.name,entry,env,weatherCache,thunderCache,forecastCache)});return{ok:true,subscriptions:listed.keys?.length??0,complete:listed.list_complete!==false}}

export default{async fetch(request,env){
 if(request.method==='OPTIONS')return new Response(null,{status:204,headers:CORS});
 const u=new URL(request.url),mode=u.searchParams.get('mode')||'';
 if(mode==='px250-file')return px250FileResponse(request);
 if(mode==='opera-raster-file')return operaRasterFileResponse(request);
 if(mode==='radolan-yw-file')return radolanYwFileResponse(request);
 if(mode==='kostra-file')return kostraFileResponse(request);
 if(mode==='composite-wms')return compositeWmsResponse(request);
 if(mode==='composite-diagnostics')return json(await compositeDiagnostics(),200,{'cache-control':'no-store'});
 if(mode==='health')return json({ok:true,version:WORKER_VERSION,services:['stations','alerts','hyperlocal-networks','model-assisted-local-analysis','radar-nowcast','px250-proxy','opera-cirrus-raster','dwd-konrad3d-nowcast','radolan-yw-accumulations','dwd-rv-accumulations','kostra-dwd-2020','dwd-rain-station','rainviewer-metadata','best-location-lightning','composite-product-times','model-contours','pressure-level-meteogram','web-push-rules','model-run-change-alerts','cors-safe-composite-wms','composite-diagnostics'],providers:{'NOAA AviationWeather':true,'DWD Open Data / Bright Sky':true,'GeoSphere Austria':true,'openSenseMap / senseBox':env?.ENABLE_OPENSENSEMAP!=='false','Weather Underground':Boolean(env?.WEATHER_COM_API_KEY||env?.WU_API_KEY),Netatmo:Boolean(env?.NETATMO_ACCESS_TOKEN),'Synoptic Data':Boolean(env?.SYNOPTIC_TOKEN),Xweather:Boolean(env?.XWEATHER_CLIENT_ID&&env?.XWEATHER_CLIENT_SECRET),WebPush:pushConfigured(env)},timestamp:new Date().toISOString()});
 if(mode==='push-config')return json({enabled:pushConfigured(env),publicKey:pushConfigured(env)?String(env.VAPID_PUBLIC_KEY):'',requires:['MID_PUSH_SUBSCRIPTIONS','VAPID_PUBLIC_KEY','VAPID_PRIVATE_KEY','VAPID_SUBJECT','Cron */5 * * * *'],version:WORKER_VERSION},200,{'cache-control':'no-store'});
 if(mode==='push-subscribe'){if(request.method!=='POST')return json({error:'POST erforderlich',version:WORKER_VERSION},405,{'cache-control':'no-store'});return pushSubscribe(request,env)}
 if(mode==='push-unsubscribe'){if(request.method!=='POST')return json({error:'POST erforderlich',version:WORKER_VERSION},405,{'cache-control':'no-store'});return pushUnsubscribe(request,env)}
 const lat=Number(u.searchParams.get('lat')),lon=Number(u.searchParams.get('lon'));if(!Number.isFinite(lat)||!Number.isFinite(lon))return json({error:'lat/lon required',version:WORKER_VERSION},400);
 if(mode==='radolan-yw-meta'){
  try{return json({...await radolanYwMetadata(request,lat,lon),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({coverage:inGermanyBounds(lat,lon),provider:'DWD RADOLAN',product:'YW',frames:[],error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='rv-accumulation'){
  try{return json({...await dwdRvAccumulation(lat,lon),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({coverage:inGermanyBounds(lat,lon),provider:'DWD RV',forecast30:0,forecast60:0,forecast120:0,frames:[],error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='dwd-rain-station'){
  try{return json({...await dwdRainStation(lat,lon),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=300'})}
  catch(error){return json({available:false,provider:'DWD Open Data / Bright Sky',error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='rainviewer-meta'){
  try{return json({...await rainViewerMetadata(),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({host:'',radar:{past:[],nowcast:[]},error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='model-contours'){
  try{return json({...await modelContours(lat,lon),version:WORKER_VERSION},200,{'cache-control':'public, max-age=900'})}
  catch(error){return json({frames:[],error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='meteogram'){
  try{return json({...await meteogramData(lat,lon,String(u.searchParams.get('model')||'best_match'),Number(u.searchParams.get('elevation'))),version:WORKER_VERSION},200,{'cache-control':'public, max-age=600'})}
  catch(error){return json({error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='px250-meta'){
  try{return json({...await px250Metadata(request,lat,lon),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({available:false,error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='opera-raster-meta'){
  try{return json({...await operaRasterMetadata(request),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({frames:[],error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='composite-times'){
  try{return json({...await compositeTimes(lat,lon),version:WORKER_VERSION},200,{'cache-control':'public, max-age=60'})}
  catch(error){return json({satelliteDay:[],satelliteIr:[],satellitePrecip:[],mtgLightning:[],dwdLightning:[],dwdRadar:[],dwdRadarLayer:'',serverTime:new Date().toISOString(),error:error instanceof Error?error.message:String(error),version:WORKER_VERSION},502,{'cache-control':'no-store'})}
 }
 if(mode==='lightning-points'){
  try{return json({...await bestLightningPoints(lat,lon,env),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=60'})}
  catch(error){return json({points:[],error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='radar-nowcast'){
  try{const requestedStage=u.searchParams.get('stage')||'all',stage=['dwd','rainviewer'].includes(requestedStage)?requestedStage:'all',result=await radarNowcastForPoint(lat,lon,u.searchParams.get('country')||'',stage);return json({...result,version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='thunderstorm-nowcast'){
  try{return json({...await dwdKonrad3dNowcast(lat,lon,u.searchParams.get('country')||''),version:WORKER_VERSION,checkedAt:new Date().toISOString()},200,{'cache-control':'public, max-age=120'})}
  catch(error){return json({available:false,coverage:true,provider:'DWD KONRAD3D',nearbyCells:[],cellsFound:0,error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 if(mode==='alerts'){
  try{const result=await officialAlerts(lat,lon,u.searchParams.get('country')||'',u.searchParams.get('name')||'',u.searchParams.get('region')||'',u.searchParams.get('district')||'',u.searchParams.get('language')||'de');return json({...result,version:WORKER_VERSION,checkedAt:new Date().toISOString()})}
  catch(error){return json({alerts:[],error:error instanceof Error?error.message:String(error),version:WORKER_VERSION,checkedAt:new Date().toISOString()},502,{'cache-control':'no-store'})}
 }
 const radiusKm=Math.min(250,Math.max(25,Number(u.searchParams.get('radius_km'))||140)),openSenseEnabled=env?.ENABLE_OPENSENSEMAP!=='false',sources=[
  {name:'NOAA AviationWeather',enabled:true,promise:metarRows(lat,lon,radiusKm)},
  {name:'DWD Open Data / Bright Sky',enabled:inGermanyBounds(lat,lon),promise:brightSkyRows(lat,lon,radiusKm)},
  {name:'GeoSphere Austria',enabled:geoSphereApplies(lat,lon),promise:geoSphereApplies(lat,lon)?geoSphereRows(lat,lon,radiusKm):Promise.resolve([])},
  {name:'openSenseMap / senseBox',enabled:openSenseEnabled,promise:openSenseEnabled?openSenseMapRows(lat,lon,radiusKm):Promise.resolve([])},
  {name:'Weather Underground',enabled:Boolean(env?.WEATHER_COM_API_KEY||env?.WU_API_KEY),promise:weatherUndergroundRows(lat,lon,radiusKm,env?.WEATHER_COM_API_KEY||env?.WU_API_KEY)},
  {name:'Netatmo',enabled:Boolean(env?.NETATMO_ACCESS_TOKEN),promise:netatmoRows(lat,lon,radiusKm,env?.NETATMO_ACCESS_TOKEN)},
  {name:'Synoptic Data',enabled:Boolean(env?.SYNOPTIC_TOKEN),promise:synopticRows(lat,lon,radiusKm,env?.SYNOPTIC_TOKEN)},
  {name:'Xweather',enabled:Boolean(env?.XWEATHER_CLIENT_ID&&env?.XWEATHER_CLIENT_SECRET),promise:xweatherRows(lat,lon,radiusKm,env?.XWEATHER_CLIENT_ID,env?.XWEATHER_CLIENT_SECRET)}
 ],settled=await Promise.allSettled(sources.map(x=>x.promise)),rows=settled.flatMap(x=>x.status==='fulfilled'?x.value:[]).sort((a,b)=>(a.distance??999999)-(b.distance??999999)).slice(0,180),errors=settled.map((x,i)=>x.status==='rejected'?`${sources[i].name}: ${x.reason instanceof Error?x.reason.message:String(x.reason)}`:'').filter(Boolean),providers=Object.fromEntries(sources.map(x=>[x.name,x.enabled]));
 return json({data:rows,providers,diagnostics:{radiusKm,rows:rows.length,errors,sourceRows:Object.fromEntries(sources.map((x,i)=>[x.name,settled[i].status==='fulfilled'?settled[i].value.length:0]))},version:WORKER_VERSION});
 },
 async scheduled(_controller,env,ctx){ctx.waitUntil(runPushSchedule(env))}
};
