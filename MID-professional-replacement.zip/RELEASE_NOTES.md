# MID v0.9.85.437 · Ruhige Kartenwechsel und klare Radarphasen

Beim Wechsel des Kartentermins bleibt das bisherige Bild sichtbar, bis der Nachfolger geladen ist. Modell- und Wolkenbilder wechseln mit einer kurzen Überblendung; schnelle Mehrfachwechsel und Ladefehler erhalten den letzten gültigen Stand. Die angezeigte Gültigkeitszeit bleibt dem tatsächlich sichtbaren Feld zugeordnet.

Niederschlagsart-Zeichen erhalten einen deckenden hellen Hintergrund und klare meteorologische Grundformen. Sie kennzeichnen ausschließlich feste, gemischte und gefrierende Niederschläge über dem aktivierten Radar. Reiner Regen und Wolken-/Modellkarten erhalten keine solchen Marker. Die zeitliche und räumliche OPERA-Echoprüfung bleibt erhalten. Modellgestützte Klassifikation ist keine amtliche Stationsmeldung oder Warnung.

# MID v0.9.85.436

- Bottom-Bar auf iOS: feste Bildschirmverankerung statt scrollabhängiger Dokumentposition; Tastatur und Zoom werden getrennt behandelt.
- Einstellungsgruppen besitzen klar getrennte, semantische Überschriften und Beschreibungen.
- Fehlgeschlagene DWD-Bilddarstellung zeigt eine Meldung mit erneutem Ladeversuch.
