
function isFiniteNumber(value:unknown):value is number{return typeof value==='number'&&Number.isFinite(value)}
type Row={climateMin?:number;climateMax?:number;minLow:number;maxHigh:number;bestMin:number;bestMax:number};
declare function format(value:number):string;
function tooltip(row:Row,show:boolean){
 if(show&&isFiniteNumber(row.climateMin)&&isFiniteNumber(row.climateMax))return format(row.climateMin)+format(row.climateMax);
 return '';
}
function scale(data:Row[],show:boolean){
 const values=data.flatMap(row=>[row.minLow,row.maxHigh,row.bestMin,row.bestMax,show?row.climateMin:undefined,show?row.climateMax:undefined]);
 const finite=values.filter(isFiniteNumber);
 return [Math.min(...finite),Math.max(...finite)];
}
void tooltip;void scale;
