# MID v0.9.85.350 · Skybar-Wochengeometrie und Solargrenzen regressionssicher

Die 7-Tage-Skybar erhält einen zusätzlichen Prüfvertrag mit 168 unveränderten Wetterstunden und allen 14 tatsächlichen Sonnenauf- und -untergangsgrenzen. Die Browser-/Widget-kompatible SVG-Darstellung bewahrt jeden Originalwert und jeden interaktiven Zeitabschnitt auch dann, wenn diese Solargrenzen zu 182 Teilstücken führen. Regenintervalle, fehlende Bewölkungswerte, gelbe Tagesabschnitte und der 25-Stunden-Sommerzeitwechsel werden unabhängig geprüft. Unbelegte Zeitgrenzen, Wetterwerte und zusätzliche Son­nen­stunden werden nicht erzeugt.

Die produktive Skybar-Logik, Wettermodelle, Warnungen, CSS, RUC-Kern und veröffentlichte Datenverträge bleiben unverändert. Der neue Test unterstützt die noch offene vollständige Geräte- und Verbraucherabnahme; er ersetzt keine reale iOS-/VoiceOver-Abnahme.

# MID v0.9.85.349 · Verlässlichere Qualitätsprüfungen

Die automatischen Browserprüfungen übergeben dynamische Testwerte sicher getrennt vom Programmcode. Chromium weist seinen Prüfport selbst zu; Startfehler werden genauer protokolliert. CSS-Messungen unterstützen die weitere Performancearbeit und vergleichen Bergwetter erst nach vollständig geladenen Zusatzdaten.

Vorhersagen, Wetterfarben, Warnungen und Datenquellen bleiben unverändert. Die neuen CSS-Messungen aktivieren keine zusätzliche verzögerte CSS-Ladung.

# MID v0.9.85.348 · Sichere Diagnoseberichte

Automatische Prüfungen schreiben ihre Laufzeitberichte in getrennte private Verzeichnisse. Widget-Exporte bewahren bei gleichzeitigen Fehlversuchen eindeutig den zuerst angelegten Fehlerbericht samt zugehörigem Diagnosebild. Browserprofile erhalten zufällige Verzeichnisnamen. Die Prüfung der produktiven Datendienst-Adresse vergleicht die vollständige URL.

Wetterdaten, Vorhersagen, Warnungen und Darstellungen bleiben unverändert.

# MID v0.9.85.347 · Automatische Revision: Chromium und WebKit vollständig vorbereiten

Die automatische und nächtliche MID-Code-Revision installiert die fest vorgegebenen Chromium- und WebKit-Laufzeiten einschließlich benötigter Systembibliotheken jetzt vor der vollständigen Regression in einem separat zeitlich begrenzten Schritt. Dadurch ist die WebKit-Prüfung der 14-Tage-CSS-Parität auch auf frisch gestarteten Runnern ausführbar. Eine gescheiterte Browserbereitstellung bleibt ein harter Fehler und wird in der nächtlichen Revision ausdrücklich gemeldet. Das Zeitbudget berücksichtigt die zusätzliche Vorbereitung; kein Browser, visueller Vergleich oder Regressionstest wird übersprungen.

Wetterwerte, Modelle, RUC, amtliche Warnungen, Karteninhalte und UI bleiben fachlich unverändert.

# MID v0.9.85.346 · Kartenintegrität und Modellstand

Die Modellstandsanzeige zeigt verifizierte Einzelmodelle als Anzahl und unterscheidet Teilverifikation von fehlenden Nachweisen. Best Match wird als Sammelquelle separat erläutert; überfällige Läufe bleiben sichtbar.

Die lokalen ICON-D2-Karten unterscheiden fehlende Werte wieder von trockenem Wetter. Ungültige Wettercodes werden nicht gerundet; echte Nullwerte und gültige Extremwerte bleiben erhalten. Jeder Rasterpunkt wird vor der Darstellung mit der gemeinsamen Gültigkeitszeit abgeglichen. Fehlende oder zeitlich unpassende Zellen bleiben transparent.

# MID v0.9.85.345 · Modellphasen und Tablet-Zeitleiste

Die Modellstandsanzeige berücksichtigt eine verifizierte Bereitstellungszeit und den Quellrhythmus statt ausschließlich das Alter seit Initialisierung. Fehlende oder widersprüchliche Metadaten werden nicht grün.

Tempoauswahl und Zeitschieberegler liegen auf Tablets wieder in getrennten, bedienbaren Zeilen.

Das Radar-Phasenraster erhält fehlende und ungültige Niederschlagsmengen sowie Wettercodes als fehlende Werte. Echte trockene Nullen bleiben erhalten. Nicht angeforderte Schauerwerte werden nicht mehr als gemessene Nullmenge ausgegeben. Radar-Echos, Phasenschwellen, RUC-Horizonte und amtliche Warnungen bleiben unverändert.

# MID v0.9.85.344 · RUC-Aufbereitung und Releasewechsel entkoppeln

RUC-Berechnung und Aufbereitung erhalten getrennte, nachvollziehbare Laufzeiten und einen geprüften Zwischenstand. Eine fehlgeschlagene Aufbereitung kann dadurch ihren vorhandenen Berechnungsstand weiterverwenden. Bereits vollständig geprüfte, aktuelle RUC-Daten können nach einem kompatiblen App-Update erneut zugelassen werden; Herkunft, Datenvertrag, sämtliche Objektbytes und Decoder werden erneut geprüft. Die Veröffentlichung verwendet die aktuelle freigegebene App und verhindert die Rückkehr zu einem älteren RUC-Lauf. Wetterwerte, Ensemble, Extremwerte und Prognosezeiträume bleiben unverändert.

# MID v0.9.85.343 · Browserprüfung und Offline-Entwicklung absichern

Die 14-Tage-Entwicklung bleibt gezielt nachgeladen und steht nach vollständiger Installation der App-Shell auch beim ersten Offline-Aufruf bereit. Die Vorbereitung von Chromium und WebKit erfolgt im Release nun als eigener Schritt mit getrennten Laufzeit- und Abbruchmeldungen. Alle visuellen, funktionalen und meteorologischen Pflichtprüfungen bleiben erhalten.

# MID v0.9.85.342 · 7-Tage-Skybar: Sonnenauf- und -untergänge vollständig

Der Wetterstreifen der 7-Tage-Kurvenübersicht ermittelt die astronomischen Tages- und Nachtgrenzen nun für alle angezeigten lokalen Kalendertage. Auch Freitag, Samstag und Sonntag erhalten damit ihre tatsächlichen Sonnenauf- und -untergänge statt einer künstlich bis zum Wochen-Ende verlängerten Nacht. Die Tageskarten und die Kurvenübersicht verwenden dieselbe astronomische Berechnung; auch 14- und 46-Tage-Zeiträume sowie 23-/25-Stunden-Tage beim Zeitwechsel werden abgesichert. Niederschlagswerte, Wolken, Sonnenscheindauer, RUC-/Modellfusion und amtliche Warnungen bleiben unverändert.

# MID v0.9.85.341 · Browser-Release-Diagnostik absichern

Die RUC-Frischegrenztests und die gezielte 14-Tage-CSS-Auslagerung aus v0.9.85.340 bleiben unverändert erhalten. Die vollständige Chromium-/WebKit- und Responsive-Parität bleibt Pflicht; deren einzelne Fortschritts- und Fehlermeldungen werden im Installer nun während der Ausführung angezeigt statt erst nach Testende. Dies ermöglicht die Behebung des noch offenen Installer-Zeitlimits ohne übersprungene Tests. Wetterberechnung, Warnungen, Modellwerte und Quellenverträge bleiben unverändert.

# MID v0.9.85.340 · RUC-Frischeprüfung und Release-Stabilität

Der bisher nicht veröffentlichte 14-Tage-CSS-Ladeschritt aus .339 bleibt vollständig erhalten. Die RUC-Quellenprüfung unterscheidet auch an der erlaubten Fünf-Minuten-Uhrentoleranz zuverlässig gültige und unzulässige Modellläufe; Wetterwerte und RUC-Gewichtung bleiben unverändert. Die verpflichtende CSS-Browserprüfung für Chromium und WebKit erhält kontrollierte Start-/Zeitdiagnosen, ohne die visuellen, funktionalen oder Zugänglichkeitsprüfungen abzuschwächen. Ein tatsächlicher Release erfolgt erst nach erneutem vollständigem Source-/Installer-/Pages-/Stable-Gate.

# MID v0.9.85.339 · 14-Tage-Entwicklung gezielt nachladen

Die Entwicklungsübersicht der 14-Tage-Prognose wird mit ihren eigenen Styles erst beim Öffnen geladen. Wetterwerte, Ensemble-Spannen, Diagramme und Bedienung bleiben erhalten. Dies ist der erste abgegrenzte Schritt der CSS-Auslagerung.

# MID v0.9.85.338 · Dunkles horizontales MID-Logo

Der Startbildschirm verwendet das bereitgestellte dunkle horizontale MID-Wortbild. Die übrigen Logos und App-Icons bleiben erhalten.

# MID v0.9.85.336 · RUC über 14 Stunden hinaus

- Die gemeinsame Wetterprognose kann DWD ICON-D2-RUC und die stündlichen RUC-EPS-Niederschlagswahrscheinlichkeiten über 14 Stunden hinaus bis zum geprüften nativen Laufende berücksichtigen. Die Obergrenze von +27 Stunden bezieht sich auf die UTC-Modellinitialisierung; die verbleibende Vorhersagezeit ist entsprechend kürzer.
- Der Einfluss nimmt zu späteren Laufstunden ab. Best Match bleibt die Basis, Radar und Beobachtungen ergänzen weiterhin nachgelagert. Fehlende Werte werden nicht als trockenes oder kaltes Wetter ausgegeben.
- Native 5-/15-Minuten-Produkte bis +6 Stunden und der RUC-Beitrag zum Extremwetter-Ausblick bis +14 Stunden behalten ihre bisherigen Zeitgrenzen.

# MID v0.9.85.335 · Modellfusion nach App-Rückkehr zuverlässig laden

Die Modellfusion wird nach Rückkehr in die App und bei wiederhergestellter Netzverbindung erneut geprüft. Fehlgeschlagene Abrufe werden mit begrenzter Wiederholungsrate nachgeholt; ein vorhandener erfolgreicher Prognosestand bleibt erhalten. Ohne bestätigten Fusionsstand weist die Modellliste ausdrücklich darauf hin, dass die Übernahme derzeit nicht verifiziert ist.

Die Stundenmarkierung im Tagesdiagramm verwendet bei Tages- und Auflösungswechseln denselben gültigen Index wie die Detailwerte; dadurch bleibt die Vorhersageansicht auch bei verkürzten Stundenreihen bedienbar.

# MID v0.9.85.333 · Lesbare Karten-Popups in Light und Dark

Leaflet- und MapLibre-Karten-Popups verwenden jetzt die MID-Flächen- und Textfarben ihres aktiven Themes. Dadurch bleiben KONRAD3D-Informationen und weitere Radar-Overlays auch im dunklen Kartenmodus lesbar. Schließen-Schaltflächen erhalten sichtbaren Fokus und auf Touch-Geräten eine 44-px-Zielfläche. Die bewusst helle Extremwetter-Popupgestaltung bleibt unverändert.

## Prüfstand

Der Änderungskandidat basiert auf Stable `3887ebc31dc93fc33b51ad87b55284671e4d4224`. Gemeinsame Leaflet- und MapLibre-Popupverträge sowie deren generierte CSS-Aggregate sind regressionsgeprüft. Der reguläre MID Source-Gate-, Installer-, Pages- und Stable-Pfad ist für diesen Kandidaten noch erforderlich.

- Vite wird von 8.2.4 auf 8.3.5 aktualisiert; @vitejs/plugin-react 6.1.2 bleibt unverändert und ist mit Vite 8 kompatibel.
- React 19.2.8 und MapLibre GL JS 6.7.0 bleiben auf dem bereits qualifizierten Stand.
- Die Kandidaten React 19.3.1 und MapLibre GL JS 6.15.0 überschritten bei gemeinsamer lokaler Regression die bestehenden harten Feature-Chunk-Budgets. Sie sind nicht Bestandteil dieses Releases; die Budgets wurden nicht angehoben.
- Capacitor 8.5.3, PostCSS 8.5.31 und Pako 2.2.0 bleiben unverändert.

# MID v0.9.85.332 · Vite-Wartungsupdate

- Vite wurde von 8.2.4 auf 8.3.5 aktualisiert; @vitejs/plugin-react 6.1.2 blieb unverändert.
- React, React DOM, react-is und die React-Typen blieben auf den qualifizierten 19.2-Versionen. MapLibre GL JS blieb auf 6.7.0.
- React 19.3.1 und MapLibre GL JS 6.15.0 wurden im kombinierten Kandidaten geprüft, überschritten aber die bestehenden harten Feature-Chunk-Budgets und sind nicht Bestandteil des Releases. Die Budgets wurden nicht angehoben.
- Capacitor 8.5.3, PostCSS 8.5.31 und Pako 2.2.0 blieben unverändert.
- Der veröffentlichte Stable-Stand basiert auf `253b365fb916c1e104e04f1c594f5c027dfd9bbf`; Source-Gate, Release-Installer, Worker-Smoke, Pages-Deployment und Stable-Promotion waren erfolgreich.

# MID v0.9.85.331 · Isoliertes Capacitor-Patchupdate

Capacitor Core, CLI und iOS werden gemeinsam von 8.5.2 auf 8.5.3 qualifiziert. Andere Capacitor-Plugins, React, Vite, MapLibre, PostCSS und Pako bleiben unverändert. Keine fachliche Änderung am Web-/PWA-Kern ist beabsichtigt.

Registry-Metadaten und offizielle Capacitor-8-Kompatibilität wurden geprüft. Reproduzierbare Installation, vollständiger Build und Regressionen, iOS-Synchronisierung, Audits und die vollständigen MID-Release-Gates sind erforderlich.

# MID v0.9.85.330 · Isoliertes React-Vite-Plugin-Update

`@vitejs/plugin-react` wird einzeln von 6.1.1 auf 6.1.2 aktualisiert. Das Plugin bleibt an Vite 8 gebunden; die unabhängigen React-, Vite-, Capacitor-, MapLibre- und Pako-Versionen bleiben unverändert. Upstream 6.1.2 behebt HMR für Compound Components. Keine absichtliche Änderung am Produktionsverhalten oder an CSS, Karten, Widgets und Exporten.

Die Registry-Auflösung, Integrität, Peer-Abhängigkeiten und Node-Anforderungen wurden geprüft. Vollständige Types-, Build-, Audit-, Regression-, Browser-/Heavy- und MID-Release-Gates sind erforderlich.

# MID v0.9.85.329 · Isoliertes PostCSS-Wartungsupdate

PostCSS wird separat von 8.5.28 auf 8.5.31 qualifiziert. Das reproduzierbar erneuerte Lockfile zieht nur die dafür erforderliche Nanoid-Patchversion nach; `source-map-js` bleibt auf dem bereits geprüften 1.2.2. React, Vite, Plugin-React, Capacitor, MapLibre und Pako ändern sich nicht. Produktions-CSS, Kaskade, Themen, Widgets, Karten und Exporte bleiben byteidentisch zum freigegebenen .328-Build. Das ist ein Entwicklungsabhängigkeits- und CSS-Parser-Wartungsschritt, kein CSS-Split und kein Laufzeit-/Designwechsel.

Context7/PostCSS-Quelldokumentation und die Registry-Metadaten für 8.5.31 wurden geprüft. Build, vollständige Regression, Dependency-Audit, CSS-Kaskaden-/Budget-Tests und MID-Release-Gates bleiben erforderlich.

# MID v0.9.85.328 · Wiederverwendung unveränderter Berechnungen unter „Aktuell“

Die lokale Stundenfolge wird einmal je Prognose-/Zeitzonen-Eingabe aufgebaut; nur die Auswahl der aktuell gültigen Ortsstunde bleibt an die laufende Uhr gebunden. Temperaturreihe, Achse, vollständige Basis-Skybar und Sonnenfenster verwenden unveränderte Ergebnisse wieder. Niederschlags-Unterstunde, Beobachtungsalter und Sonnenzeit reagieren weiterhin unmittelbar auf jede Uhraktualisierung. 420 Golden-Vergleiche einschließlich Viertelstunden-Zeitzonen und DST sowie ein lokaler React-Profiler bestätigen Verhalten und geringere Renderkosten im synthetischen Fixture. Keine Änderung an Wetterfachwerten oder Darstellungs-CSS.

# MID v0.9.85.327 · Schnellere Stundenfilterung unter „Aktuell“

Die Zeitachse der laufenden 12-Stunden-Übersicht erzeugt ihren Zeitzonen-Formatter nur einmal pro Berechnung statt für jede einzelne Stunde. Dadurch entfällt unnötige Renderarbeit, ohne Prognosewerte, fehlende Daten, die laufende Niederschlagsstunde oder Sommer-/Winterzeitwechsel zu ändern. Der Sonnenzeit-Timer-Fix aus v0.9.85.326 bleibt erhalten.

# MID v0.9.85.326

- **Weniger Hintergrundarbeit:** Die Sonnenuhr unter „Aktuell“ pausiert ihre Zeitsteuerung, sobald der Browser-/PWA-/iOS-Webview-Inhalt verborgen ist. Beim erneuten Anzeigen oder Fokussieren werden die Sonnenzeiten und die Beobachtungsfrische umgehend mit dem echten aktuellen Zeitpunkt neu berechnet.
- Die bisherige maximale Aktualisierungszeit im Vordergrund von 30 Sekunden und der schnelle Wechsel unmittelbar an Sonnenauf-/untergang bleiben erhalten. Der Wetterfachkern und alle Daten-/Warnquellen bleiben unverändert.
- Neuer Regressionstest deckt Hintergrund, Wiederaufnahme, realzeitliche Epoch-Verwendung (auch bei Zeitumstellung), Timer-Cleanup und alle aktiven Event-Listener ab.

# MID v0.9.85.325

- Unter Aktuell bleibt in der 12-Stunden-Ansicht der Niederschlag der vollständigen laufenden Stunde sichtbar, auch wenn ein Teil bereits vergangen ist. Der aktuelle Messanker wird nicht rückwirkend auf diese Stundenanteile projiziert.
- Die nachfolgenden Kurzfristintervalle behalten ihre aktuelle Anpassung.
- Kalender- und Stundenprüfungen sichern Zeitumstellungen im Frühjahr und Herbst auch für weitere Jahre und Zeitzonen ab.

# MID v0.9.85.324

- Die 7-Tage-Ansicht startet auch am Zeitumstellungstag wieder mit heute. Der Abruf enthält die erforderlichen vergangenen Stunden für den vollständigen Ortskalendertag.
- Tagesniederschlag, Sonnenstunden und Temperaturspanne berücksichtigen weiterhin den gesamten Tag; bereits vergangene Stunden werden nicht als Resttag abgeschnitten. Fehlende Daten werden nicht künstlich ergänzt.
- Direkter Wetterabruf und Worker verwenden denselben begrenzten Stundenumfang; alte Kernvorhersage-Caches werden erneuert.

# MID v0.9.85.323

- Karten: Skalare Zusatzisolinien mit feinen, transparenten Strichen und zurückhaltenden Beschriftungen. Geografische Grenzen und Ortsnamen bleiben deutlich sichtbar; physikalische Rasterwerte, Extreme und Druck-Isobaren bleiben unverändert.
- Niederschlagssummen: Schaltbare Isolinien in mm auch für ICON-D2-Akkumulation und DWD-RADOLAN-Beobachtungen; trockene Nullwerte und fehlende Messungen werden getrennt, ebenso im SVG-/PNG-Export.
- Fachprüfung: Der aktuelle ICON-D2-/RUC-Publisher beschränkt mehrere Produkte unabhängig vom Zeitschritt auf den deutschen Zuschnitt. Eine Ausdehnung auf das echte vollständige Modellgebiet ist erst nach Original-GRIB-/NoData-/3-Lauf-/Budget-Gates zugelassen und nicht Teil dieses Builds.

# MID v0.9.85.322

- RUC: Isolierte native DWD-/RADOLAN-/Synoptik-Seitenschritte trennen native Bibliothekslebenszyklen im Pages-Packer; die Crash-Behebung muss im echten Datenlauf bestätigt werden.
- Native Prozessabstürze, fehlgeschlagene Metadaten-/Integritätsprüfungen und Codec-Fehler bleiben fatal. Die vollständige verlustfreie Migration, der gesicherte Raw-Rollback und der 900-MB-Grenzwert bleiben unverändert.
- Die tatsächliche Wiederherstellung erfordert separate RUC-, Pages-, Worker-, Fusion- und Stable-Live-Nachweise; ein grünes Source-Gate allein genügt nicht.

# MID v0.9.85.321

- RADOLAN: Die HDF5- und Projektionsbibliotheken werden auch im schlanken Pages-/Installer-Pfad installiert. Dies behebt den belegten Importabbruch vor der Summenveröffentlichung.
- Karten: Der Hilfetext beschreibt die je Zoomstufe einheitlichen Druckkonturintervalle korrekt.

# MID v0.9.85.320

- Karten: Isobaren verwenden je Zoomstufe ein einheitliches Werteintervall ohne lokale Auslassung einzelner Linien.
- Flächige numerische Modellkarten zeigen zusätzlich beschriftete Hilfskonturen, auch für Wind und Böen. Export und Karte verwenden denselben Konturpfad.

# MID v0.9.85.319

- Aktuell – Radar-Nowcast: Niederschlagsbalken zeigen leichte, mäßige und starke Regenintensität anhand der Radar-Rate farblich abgestuft. Schraffur und Deckkraft unterscheiden die unkalibrierte Szenariounterstützung; fehlende Werte bleiben ausdrücklich unbekannt.
- Karten – RADOLAN-Niederschlagssummen: DWD-Import an aktuelle ODIM-H5-RW-Dateien und deren eigenständige 1-km-Rastergeometrie angepasst. Nur zeitlich vollständige, qualitätsgeprüfte 1-/6-/12-/24-/48-Stunden-Summen werden angeboten; fehlende Beobachtungen sind keine Nullwerte.
- Technisch: HDF5-Projektions-/Zeit-/NoData-Regressionen und einheitliche Radar-Farb-/Wahrscheinlichkeitsprüfungen ergänzt, ohne RUC- oder Warnlogik umzudeuten.

# MID v0.9.85.318

- Zeitumstellung: Stunden- und Viertelstundenprognosen behalten ihre richtigen absoluten Zeitpunkte. Die doppelte Herbststunde bleibt eindeutig; im Frühjahr wird keine zusätzliche Stunde erzeugt.
- Tageswerte: Unterschiedliche Anbieter- und Ortszeitgrenzen werden erkannt. Vollständig abgedeckte lokale 23-/25-Stunden-Tage werden aus den Stunden berechnet; unvollständige Zeiträume erhalten keine falsche 24-Stunden-Summe.
- Ensemble- und Eventauswertungen verwenden dieselben Zeitgrenzen. Alte abgeleitete Ensemble-Zwischenspeicher werden erneuert; Rohdaten mit verlässlichem UTC-Offset bleiben verwendbar.

# MID v0.9.85.317

- Modellkarten: dezente weiße Extremwertzahlen ausschließlich aus gültigen Rasterzellen des sichtbaren Kartenausschnitts; Aktualisierung bei Verschieben, Zoom und Größenwechsel.
- Einheitliche Darstellung für vorhandene numerische ICON-D2-/RUC-Modellfelder ohne sichtbare „Min.“-/„Max.“-Zusätze, mit barrierearmer Erläuterung beim Fokussieren/Antippen.
- PNG-/SVG-Kartenexporte zeigen Extremwerte passend zum eigenen vollständigen Exportbild; Missing Data und Originalmodellwerte bleiben unverändert.

# MID v0.9.85.316

- Native Modellkarten zeigen auf Wunsch beschriftete Isothermen, Wind-/Böen-, Bewölkungs- und Niederschlagslinien aus dem gewählten Raster.
- Min-/Max-Markierungen und Zahlenübersicht zeigen die tatsächlichen Extremwerte des verfügbaren Rasters einschließlich Randzellen. Fehlende Daten bleiben ausgespart.
- Die 24-h-Übersicht erhält runde Windteilstriche in der gewählten Einheit. Karte und PNG-/SVG-Export übernehmen dieselben Linien und Extremwerte.

# MID v0.9.85.314

- Druckkarten: Kleine Druckextrema bleiben bei der Konturberechnung erhalten; Karten und SVG-/PNG-Exporte verwenden dieselben vollständigen Linienzüge, auch bei Wolken-/Wetterkarten.
- Datenprüfung: Der Vollgebiets-Auditor prüft zusätzlich vollständige Vorhersagestunden, Quellprüfsummen, Einheiten und Intervalle. Fehlende Daten bleiben von tatsächlichen Nullwerten getrennt.
- Die vollständige Erweiterung auf das gesamte ICON-D2/RUC-Modellgebiet ist weiterhin in Arbeit; dieser Stand aktiviert keine neue Datenquelle oder größere Gebietsabdeckung.

# MID v0.9.85.311

- Prognosegüte: MID und Best Match werden anhand identischer gespeicherter Fälle und gemeinsam verfügbarer Parameter verglichen. Fehlende Werte können keinen künstlichen Vorteil mehr erzeugen.
- Der Kontrollvergleich nennt die Zahl der tatsächlich auswertbaren Tage und Fälle.

# MID v0.9.85.309

- Extremwetter-Ausblick: Verschachtelte Gefahrenflächen mit Löchern und Inseln erscheinen nicht mehr mehrfach übereinander; ihre modellierten Werte bleiben unverändert.

- Extremwetter-Ausblick: Bei einer nicht geladenen oder leer gerenderten nativen Gefahrenebene kann eine georeferenzierte Ersatzdarstellung aus denselben modellierten Wahrscheinlichkeitskonturen einspringen.
- Ein klarer Hinweis kennzeichnet diesen Ersatzmodus; Gefahrenstufen, Eintrittswahrscheinlichkeiten, Schraffuren und amtliche Warnungen bleiben fachlich unverändert.
- Der native Kartenlayer bleibt der bevorzugte Normalfall und wird nach erfolgreicher Wiederherstellung erneut verwendet.

- Extremwetter-Kartenfallback erkennt zusätzlich explizit ausgeblendete bzw. vollständig transparente native Fill-Layer, auch wenn die Featureabfrage Geometrie zurückliefert. Keine Änderung meteorologischer Felder.

# MID v0.9.85.311

- Prognosegüte: MID und Best Match werden anhand identischer gespeicherter Fälle und gemeinsam verfügbarer Parameter verglichen. Fehlende Werte können keinen künstlichen Vorteil mehr erzeugen.
- Der Kontrollvergleich nennt die Zahl der tatsächlich auswertbaren Tage und Fälle.

# MID v0.9.85.309

- Extremwetter-Ausblick: Verschachtelte Gefahrenflächen mit Löchern und Inseln erscheinen nicht mehr mehrfach übereinander; ihre modellierten Werte bleiben unverändert.

- Extremwetter-Ausblick: Bei einer nicht geladenen oder leer gerenderten nativen Gefahrenebene kann eine georeferenzierte Ersatzdarstellung aus denselben modellierten Wahrscheinlichkeitskonturen einspringen.
- Ein klarer Hinweis kennzeichnet diesen Ersatzmodus; Gefahrenstufen, Eintrittswahrscheinlichkeiten, Schraffuren und amtliche Warnungen bleiben fachlich unverändert.
- Der native Kartenlayer bleibt der bevorzugte Normalfall und wird nach erfolgreicher Wiederherstellung erneut verwendet.

- Extremwetter-Kartenfallback erkennt zusätzlich explizit ausgeblendete bzw. vollständig transparente native Fill-Layer, auch wenn die Featureabfrage Geometrie zurückliefert. Keine Änderung meteorologischer Felder.

# MID v0.9.85.309

- GeoJSON-Konturen: tiefe Loch-/Inselverschachtelungen werden duplikatfrei erzeugt; keine veränderten Gefahrenschwellen.

- Extremwetter-Ausblick: Bei einer nicht geladenen oder leer gerenderten nativen Gefahrenebene kann eine georeferenzierte Ersatzdarstellung aus denselben modellierten Wahrscheinlichkeitskonturen einspringen.
- Ein klarer Hinweis kennzeichnet diesen Ersatzmodus; Gefahrenstufen, Eintrittswahrscheinlichkeiten, Schraffuren und amtliche Warnungen bleiben fachlich unverändert.
- Der native Kartenlayer bleibt der bevorzugte Normalfall und wird nach erfolgreicher Wiederherstellung erneut verwendet.

# MID v0.9.85.308

- RUC im Modellmarkt: vollständiges Synoptik-Komposit mit Theta-E 850 hPa, Höhe 500 hPa, Bodendruck, Feuchte 700 hPa und Strömung 300 hPa aus demselben nativen Lauf.
- RUC-Wolken und signifikantes Wetter: direkte WMO-Wettercodes und Gesamtbewölkung, wahlweise als schematisches Modell-Wolkenbild; Isobaren und Isohypsen aus demselben Termin.
- Karten zeigen die sichtbare Vorhersagestunde (z. B. +3 h), den tatsächlich verfügbaren Bereich und die Anzahl/Schrittweite der Termine. Zeitachse und Bildexporte nennen die Vorhersagestunde ebenfalls.
- RUC-Zusatzkarten werden ausschließlich mit vollständiger stündlicher Achse bis +27 h veröffentlicht. Bei unvollständigen Quellen bleibt der geprüfte RUC-Kern erhalten; EPS und Prognosefusion behalten ihren bisherigen Horizont.

# MID v0.9.85.307

- Ensemble-Szenariocluster bewahren seltene vollständige Starkregenverläufe und kleine Cluster. Modellanteile sind keine amtlichen oder kalibrierten Eintrittswahrscheinlichkeiten.
- RADOLAN: Gültige Niederschlagswerte werden nicht länger unbegründet bei 250 mm begrenzt. Fehlende Daten und trockene Null bleiben unterscheidbar.
- Wetterzwilling: Prognosegüte, Bias und Kalibrierung verwenden ausschließlich genügend vollständige unabhängige Messreferenzen. Frühere Modell- und Reanalyserückblicke bleiben archiviert, sind jedoch keine Messwahrheit.
- Best Match wird präziser als automatisch ausgewählte operative Modellprognose erklärt.

# MID v0.9.85.306

- Wartung: Die bestehenden Revisions-, Sicherheits- und Veröffentlichungsprüfungen verwenden jetzt einheitlich die erforderliche RUC-Testumgebung.
- Sicherheit: Vite erhält den kompatiblen Sicherheits-Patch 8.2.4; die bestehenden Karten-, Export- und iOS-Verträge bleiben erhalten.
- RUC-Karten aus .305 bleiben verfügbar: sechs Parameter und getrennt geprüfte Kartenstunden bis +27 h; EPS und Prognosefusion behalten ihren bisherigen Stundenvertrag.

# MID v0.9.85.305

- Karten: DWD ICON-D2-RUC ergänzt Temperatur, Bodendruck, Wind, Böen, Bewölkung und stündlichen Niederschlag mit eigenem Modelllauf. Vollständig geprüfte Stundenfelder reichen bis +27 Stunden.
- Modellauswahl bleibt gespeichert. Karten, Ortswerte und Bildexporte verwenden dieselben Rasterwerte und Einheiten. Datenlücken bleiben transparent.
- Kartenstunden werden getrennt geprüft: RUC-EPS und Prognosefusion behalten ihren bisherigen Stundenvertrag.

# MID v0.9.85.304

- Der 7-Tage-Kurztext liest sich flüssiger: vollständige Sätze, ein natürlicher Anschluss an die kommende Nacht und klar datierte weitere Wetterphasen. Niederschlagsart, Unsicherheit und markante Hinweise bleiben erhalten.
- Sonnenscheindauer: Die stündliche Zusammenfassung aus Viertelstunden verwendet jetzt genau die vier vorangegangenen Intervalle bis zum Stundenende. Spätere Viertelstunden fließen nicht mehr versehentlich ein. Dies verbessert auch die davon abhängige Skybar.
- Bei Lücken, doppelten oder unpassenden Zeitpunkten bleibt der verfügbare Stundenwert erhalten. Fehlende Werte bleiben fehlend. Die weitergehende Anbieter-Zeitumstellungs-Migration bleibt offen.

# MID v0.9.85.303

- Skybar: An Sonnenauf- und -untergang richtet sich die gelbe Balkendicke jetzt nach dem tatsächlich möglichen Tageslichtanteil des Intervalls. Nachtminuten schwächen das sichtbare Tagesstück nicht mehr künstlich ab. Die Bezugszeit wird im Tooltip genannt; Sonnenminuten bleiben unverändert.
- Alle vier gelben und grauen Dickenstufen werden separat geprüft. Nicht jede Wetterlage enthält jede Stufe; Bewölkungswerte und Niederschlag werden nicht verändert oder künstlich auf Klassen verteilt. Die größere Open-Meteo-Zeitumstellungs-Migration bleibt separat offen.

# MID v0.9.85.302

- Zeitangaben mit ausdrücklich angegebener UTC-Zeit oder Zeitzonenverschiebung werden nicht mehr erneut als Ortszeit interpretiert. Die beiden gleichen Ortszeiten bei der Herbst-Zeitumstellung bleiben dadurch unterschiedliche Zeitpunkte.
- Zeiten ohne ausdrücklich angegebene Verschiebung behalten ihre bisherige Ortszeitbehandlung. Die weitergehende Umstellung der Open-Meteo-Zeitreihen und Tagesgrenzen ist damit noch nicht abgeschlossen.

# MID v0.9.85.301

- Extremwetterhinweise: Nach dem Abbruch eines direkten Abrufs werden keine unnötigen Folgeabfragen mehr gestartet. Parallel laufende, nicht abgebrochene Abrufe bleiben unabhängig.
- Fachliche Berechnung, vorhandene Niederschlags-/Warnlogik und Modellwerte bleiben unverändert. Fehlerfälle und bereits abgebrochene Abrufe werden separat getestet.

# MID v0.9.85.300

- Die Niederschlags-Skybar unterscheidet bei vorhandenen WMO-Wettercodes nun fehlende Mengen von tatsächlich gemessenen 0 mm. Statt fälschlicher Nullmengen werden „Gesamtmenge nicht verfügbar“ und der ursprüngliche WMO-Code angezeigt.
- Vorhandene Niederschlagsphasen, Wettercodes, echte Nullwerte, extreme codierte Schauerstufen und verfügbare Schnee-Teilwerte bleiben erhalten. Die meteorologischen Modellwerte und amtlichen Warnungen werden nicht geändert.
- Neue Regression für fehlende und ungültige Mengen, 15-Minuten-Intervalle, WMO-Codes, Teilfelder und echte Nullwerte. CSS/Responsive-Verhalten bleibt unverändert.

# MID v0.9.85.299

- Die Buildprüfung erkennt jetzt fehlende Haupt-CSS- oder JavaScript-Dateien in einem bereits angelegten Produktions-Build zuverlässig als Fehler. Ein unvollständiges Bundle wird nicht mehr als erfolgreiche Null-Byte-Messung ausgegeben.
- Bestehende Größenbudgets, CSS-Kaskade, Layout und Wetterberechnungen bleiben unverändert; die gezielte CSS-Verkleinerung erfordert weiterhin separate Browser-Paritätsmessungen.

# MID v0.9.85.298

- Der RUC-Aktualitätsprüfer kontrolliert bei vollständig komprimierten Daten zusätzlich sichere Objektpfade, SHA-256-Deklarationen, ununterbrochene Datensatzketten und eine korrekte Bytebilanz.
- Bei unvollständigen RUC-Metadaten wird der Neuaufbau nicht fälschlich übersprungen. Die bestehenden Modellwerte, der verlustfreie Codec und die amtlichen Datenquellen bleiben unverändert.

# MID v0.9.85.297

- Die klassische Tagesdetailansicht und die Stundenansicht verwenden für Wetterstreifen, Nachtflächen, Sonnenmarker und aktuelle Zeit dieselbe reale Zeitachse.
- Tage mit Zeitumstellung behalten alle 23 oder 25 Stunden. Dreistündliche Niederschlagsbalken zeigen ihre tatsächliche Zeitspanne; Datenlücken bleiben offen.
- Sonnenübergänge im Wetterstreifen bleiben auch in der 3-Stundenansicht minutengenau. Sonnenscheindauer und Wolkenlücken bleiben getrennte Größen.

# MID v0.9.85.296

- Der regionale Extremwetter-Ausblick für Tag 3–7 lädt vollständige Modellfelder nun direkt über den MID-Worker, ohne zuvor ein zusätzliches JavaScript-Modul abrufen zu müssen.
- Bei vorübergehenden Daten- oder Modulfehlern bleiben ein geprüfter lokaler Ausblick und die Kennzeichnung veralteter Daten als Ausfallsicherung verfügbar; fehlende Prognosen werden nicht als Entwarnung angezeigt.
- Kann eine App-Ressource nicht geladen werden, bietet die Ansicht eine explizite Aktion zum Neuladen statt wiederholter erfolgloser Modulimporte.

# MID v0.9.85.295

- Die 7-Tage-Kurzinterpretation zeigt vor allem markante Wetterentwicklungen und relevante Risiken.
- Höchstens drei kurze Aussagen erscheinen in zeitlich richtiger Reihenfolge, auch bei Wetterereignissen in der Nacht.
- Unvollständige Prognosedaten werden nicht als trockene Wetterlage dargestellt.

# MID v0.9.85.294

- Der Wetterstreifen unter Aktuell berücksichtigt Sonnenauf- und -untergang nun minutengenau innerhalb der Stundenabschnitte.
- Kurzfristiger Niederschlag und die optionalen Stundenquadrate bleiben unabhängig erhalten.

# MID v0.9.85.293

- Die Ortssuche erhält freie Fläche: Standortleiste und schwebende Hauptnavigation werden während der geöffneten Suche ausgeblendet und beim Schließen wiederhergestellt.
- Verspätete Suchergebnisse oder Fehler öffnen eine bereits geschlossene Suche nicht erneut.
- Fokus ohne verzögertes Wegspringen, Escape, Ortsauswahl und Tastaturgrößenwechsel werden gemeinsam abgesichert.

# MID v0.9.85.292

- Amtliche Europa-Warngebiete werden zusätzlich anhand ihrer Kartenpolygone geprüft. Ähnliche Gebiets- und Küstennamen ziehen keine entfernten Warnungen mehr nach.
- CAP-Aktualisierungen und Stornos werden über ihre Meldungsketten verarbeitet. Unterschiedliche Warnstufen, Gültigkeitsfenster und amtliche Sprachfassungen bleiben erhalten.
- Der bisherige Barcelona-Sonderhinweis wird durch die allgemeine Gebietsprüfung ersetzt.

# MID v0.9.85.291

- API-Qualitätsprüfung erkennt fehlende Wetterwerte zuverlässiger; echte Nullwerte bleiben gültig.
- Bestehende Modelle, Wetterdaten und Warnungen bleiben erhalten.

# MID v0.9.85.289

- **Heute/Kurzfrist: gleiche Uhrzeit wie im Diagramm.** Niederschlagsbeginn und -ende orientieren sich an denselben korrigierten Zeitabschnitten wie die 24-Stunden-Kurve; abweichende versteckte Viertelstundenwerte bestimmen den Text nicht mehr.
- **Weniger, dafür wichtigere Wetterhinweise.** Unbedeutende Böen werden nicht länger automatisch erwähnt. Hinweise konzentrieren sich auf belastbaren Niederschlag und markante Böen; fehlende Wetterdaten bleiben als solche erkennbar.
- **Mehr nutzbare Kartenfläche auf dem Smartphone.** Modell- und Quellenkennzeichnung sowie die einklappbare Kartenlegende belegen weniger Platz. Produktzeiten, Karteneinstellungen, Legende und verpflichtende Quellenangaben bleiben erreichbar.
- **Unverändert:** amtliche Warnungen, Modellmeteorologie und RUC-Daten bleiben unberührt.

# MID v0.9.85.288

- **Sichtweiten- und Nebelanzeige:** Nicht verfügbare Sichtweiten oder Luftfeuchtewerte werden nicht mehr als tatsächlich gemessene Null behandelt. Unbelegte Nebel- und Dunstsignale aus fehlenden Daten werden vermieden.
- **Echte Extremwerte bleiben erhalten:** Eine valide Sichtweite von 0 m wird weiterhin als außergewöhnlich schlechte Sicht behandelt. Vorhandene Wettercodes und vertrauenswürdige Wetterbeobachtungen behalten ihre eigene Aussagekraft.
- **Mehr Datensicherheit:** Fehlende oder beschädigte Werte und aus Caches zurückgelesene Lücken werden in der gemeinsamen Sichtweitenklassifikation konsistent behandelt. Amtliche Warnungen, Datenquellen und Modellberechnungen sind unverändert.

# MID v0.9.85.287

- **Tagesniederschlag mit verlässlichem Datenstatus:** Fehlt eine Tagesmenge beim Wetterdatenanbieter, erscheint sie als nicht verfügbar statt fälschlich als 0 mm. Eine wirklich gemessene oder vorhergesagte Null bleibt 0 mm.
- **Tagesprognosen und Widgets:** Niederschlagsmenge und -wahrscheinlichkeit werden unabhängig voneinander als verfügbar oder fehlend gekennzeichnet. Auch 7-/14-Tage-Ansichten und Widget-Darstellungen übernehmen diese Unterscheidung.
- **Wetterlage bleibt erkennbar:** Vorhandene Regen- und Schneesignale werden nicht durch eine fehlende Tagessumme zu trockenem Wetter umgedeutet. Vollständige Stundenfolgen können eine fehlende Tagessumme weiterhin nach dem bestehenden Kalendertagsvertrag ersetzen.
- **Keine Änderung** an amtlichen Warnungen, RUC-Kompression, numerischen Wettermodellen oder Wettervorhersageschwellen.

# MID v0.9.85.286

- Push-Einstellungen: schnelle Änderungen der relativen/absoluten Zeitanzeige werden in Reihenfolge übertragen; ältere Antworten überschreiben die aktuelle Auswahl nicht.
- Die Oberfläche unterscheidet lokales Speichern, ausstehende Übertragung und die Bestätigung der konkreten Auswahl durch den Server. Fehlendes Geräteabo und Speicherfehler werden ausdrücklich angezeigt.
- Laufende Push-Auswertungen prüfen die neueste lesbare Registrierung vor dem Versand und bewahren neuere Einstellungen bei Status-Rückschreibungen. Keine globale Atomaritätsgarantie für Cloudflare KV; keine Änderung amtlicher Warnungen oder meteorologischer Schwellen.

# MID v0.9.85.285

- **Tageswerte ganzer Kalendertage:** Die heutige Niederschlagssumme wird nicht länger durch die nur noch verbleibenden Stunden ersetzt. Bei unvollständigen Stunden bleibt der Tageswert der gültigen Tagesquelle erhalten.
- **23-/24-/25-Stunden-Tage:** Nur eine lückenlose echte Stundenfolge inklusive nachfolgendem Akkumulationsende darf die Tageswerte aus Stunden rekonstruieren. Fehlende Modellstunden oder Tageslücken dürfen nicht als null Millimeter gelten.
- **Skybar „Aktuell“:** Bewölkung und Sonnenschein der laufenden vollen Modellstunde bilden den Hintergrund; 15-Minuten-Nowcast-Niederschläge bleiben als unabhängige Ebene mit den unveränderten Intervallzeiten erhalten.
- **Fachliche Abgrenzung:** Keine Änderung amtlicher Warnungen, RUC-Kompression, numerischer Wetterwerte oder Modellkarten. Vollständig fehlende providerseitige Tagessummen werden weiterhin im eigenen Data-QA-Arbeitspaket #397 untersucht.

# MID v0.9.85.284

- Karten: Kompakte Schalter „Isobaren“ und „Isohypsen“ ohne angehängte hPa-/gpdm-Kürzel; fachliche Einheiten an tatsächlichen Datenwerten und Druckniveaus bleiben erhalten.
- Weniger verdeckte Karte: Auf Smartphones sind Radar-/Satelliten- und Modelllayer einklappbar und Linienfarben nur nach bewusstem Öffnen sichtbar. Die direkte Terminwahl, Zeitleiste und Navigation bleiben erhalten.
- Modellkarten: Parameter und Modell als kompakte Hauptauswahl; Kartenbasis unter „Darstellung & Ebenen“. Modell- und Zeitstatus liegen auf kleinen Displays außerhalb der Kartenfläche.
- Mehr Kartenausschnitt in Portrait und Landscape; Touch-/Tastaturzugang sowie Light/Dark bleiben Bestandteil der Abnahme.
- Keine Änderungen an amtlichen Warnungen, DWD-/WMO-Daten, Konturen, RUC-Kompression, Modellläufen oder Missing-Data-Regeln.

# MID v0.9.85.283 · Schnellere Ortswechsel und stabile Bergwetter-Höhenprognose

- Beim Wechsel zu einem bereits geladenen Favoriten zeigt MID einen überprüften gespeicherten Best-Match-Stand sofort an, sofern Standort, Höhenangabe und Zeitzone exakt passen und der Stand höchstens 45 Minuten alt ist. Alter und laufende Aktualisierung werden sichtbar ausgewiesen. Andere Ortsdaten werden nicht übertragen.
- Die Berg-/Wintersportansicht zeigt die vollständige Best-Match-Höhenprognose, ohne auf zusätzliche regionale Modelle zu warten. Diese ergänzen die vorhandene Prognose nach erfolgreicher Prüfung im Hintergrund.
- Bricht die gemeinsame Höhen-Netzanfrage unerwartet ab, versucht MID einmal einen kontrollierten Abruf derselben vollständigen Felder für die einzelnen Höhenstufen. Unvollständige oder zeitlich widersprüchliche Antworten werden verworfen, nicht als Nullwerte ergänzt.
- Fehlgeschlagene Höhenprognosen erhalten eine verständliche deutsche Meldung und eine Schaltfläche zum erneuten Laden. Ausgeblendete oder gewechselte Orte übernehmen keine verspäteten Antworten.
- Bestehende Wetterfarben, amtliche Warnungen, Prognosewerte, Quellenkennzeichnungen, RUC und Release-Schutzmechanismen bleiben erhalten. Nicht verfügbare Werte werden nicht als gemessene Nullen dargestellt. Der iOS-Code wird gebaut/synchronisiert; eine physische iOS-/VoiceOver-Abnahme ist damit nicht verbunden.

# MID v0.9.85.282 · Vollständige Tages-Skybar und Tageswerte

- Tagesansichten berücksichtigen jetzt den **ganzen lokalen Kalendertag**, auch wenn die aktuelle Uhrzeit bereits fortgeschritten ist. Fehlende Stunden werden in der Skybar ausdrücklich als nicht verfügbare Daten angezeigt, statt verbleibende Stunden zu strecken oder vorausgegangene Stunden als klar/trocken auszugeben.
- Wetterstreifen, Stundenquadrate und Nachtzeiten verwenden dieselben tatsächlichen Stundenintervalle; auch die Zeitumstellungen mit 23 bzw. 25 Stunden bleiben korrekt. Tages-/Kurvenansicht und Widget-Export nutzen die entsprechende Zeitachse.
- Tagesniederschlagsmenge und Sonnenscheindauer beruhen weiterhin auf den kanonischen **Volltageswerten**, soweit diese verfügbar und gültig sind. Die qualitative 7-Tage-Interpretation schneidet für „Heute“ nicht pauschal die vergangenen Tagesstunden ab.
- Die bewusst **rollierenden** 90-Minuten-, 12-/24-Stunden- und Nowcast-Prognosen bleiben ab der aktuellen Zeit in die Zukunft ausgerichtet. WMO-Wetterfarben, amtliche Warnungen, RUC, Modellwerte, Tagesakkumulationsgrenzen und Quellen bleiben unverändert.
- Fehlen vergangene Stunden oder ist ein Tageswert nicht verfügbar, werden keine Werte erfunden, nicht als 0 behandelt und keine historischen Beobachtungen simuliert.
# MID v0.9.85.281 · Natürlichere Land- und Wasserfarben im Modell-Wolkenbild

- Das **schematische Modell-Wolkenbild** erhält einen ruhigeren, geografisch unterscheidbaren Untergrund: Landflächen in natürlichem Sandgrau und Meere/Seen in zurückhaltendem Blaugrau. Das hilft insbesondere in Küstengebieten, bei wenig Bewölkung und unter transparenten Wolken.
- Die einheitliche Darstellung erreicht die gemeinsame Kartenansicht, die separate ICON-D2-Modellkarte und die PNG-/SVG-Exporte. Verifizierte Vektor-Wasserflächen und die vorhandenen Natural-Earth-Landgeometrien einschließlich der Bundesländer bilden die Grenzen; Wolken und Wetterraster liegen sichtbar darüber.
- Die Normal-/Satelliten-/Radaransichten, helle und dunkle Standardkarten, Wetterphasenfarben, Modellwerte, Isobaren, Uhrzeiten, RUC-Verarbeitung und amtliche Warnungen bleiben unverändert. Das Wolkenbild ist ausdrücklich **kein echtes Satellitenbild**; die Farben kennzeichnen die Kartengrundlage, nicht meteorologische Messwerte.
- Land-/Wassergeometrien in Offline-Exporten und Online-Vektorkacheln besitzen unterschiedliche Detailgrade; kleinste Binnengewässer können abweichen. Die kartografische Genauigkeit wird nicht über den Datenstand der vorhandenen Quellen hinaus behauptet.
# MID v0.9.85.280

- **Regen- und Schneebeginn einfacher lesbar:** Relative Vorlaufzeiten werden auf ganze 5-/10-Minutenstufen gerundet; Dauerangaben verwenden Stunden und Minuten statt Dezimalstunden. Die tatsächlichen Ereigniszeiten und meteorologischen Auslöseschwellen bleiben unverändert.
- **Benachrichtigungseinstellung:** Niederschlagshinweise lassen sich zwischen gerundeter relativer Zeit und ungefährer absoluter Uhrzeit umschalten. UTC-Ereigniszeit, gültige Orts-/Gerätezeitzone, Tageswechsel und Sommer-/Winterzeit werden berücksichtigt. Alte Registrierungen bleiben relativ; fehlende Angaben werden nicht als genaue Ortszeit ausgegeben.
- **Weitere modellgebundene Isobaren:** In der Synoptik sind MSLP-Isobaren jetzt für die vorhandenen GFS-/IFS- sowie ICON-Katalogmodelle explizit umschaltbar. Nur geprüfte Druckkonturen des angezeigten Modells, Modelllaufs und Gültigkeitstermins werden verwendet; keine Ersatzlinien von ICON auf anderen Modellen.
- RUC, amtliche Warnungen, Push-Cooldown, Ereignisdeduplikation und Prognosewerte bleiben unverändert. Ein neuer Regressionstest prüft Formate, DST, Altkunden und Modellzuordnung.

# MID v0.9.85.279 · Wetterabruf-Retry und Pseudo-Sat-Kartenverbesserung

- Ein sporadisch verzögerter Wetterabruf nach einem Ortswechsel erhält einmalig einen kontrollierten automatischen Wiederholungsversuch. Bei anhaltendem Fehler lässt sich der Wetterabruf manuell neu starten. Ergebnisse veralteter Ortsanfragen bleiben ausgeschlossen.
- Das schematische Modell-Wolkenbild mit Wettererscheinungen behält die bisherige gespeicherte Darstellung. Bei diesem Produkt wird im hellen Design ausschließlich während bestätigter Modelltermine eine ruhigere, kontrastreichere Kartenbasis verwendet.
- Zusätzlich zu den optionalen Bodendruck-Isobaren lassen sich verifizierte 500-hPa-Isohypsen (gpdm) unabhängig zuschalten und speichern. Beide Konturentypen dürfen nur zum identischen Modell, Lauf und Gültigkeitstermin erscheinen und werden entsprechend in PNG/SVG übernommen.
- Niederschlagsmengen, WMO-Wetterphasen, Datenlücken, amtliche Warnungen, RUC-Kompression und vorhandene Kartenprodukte bleiben unverändert. Modell-Wolkenbilder sind keine Satellitenmessungen.

# MID v0.9.85.278 · Skybar an tatsächlichen Sonnenzeiten ausrichten

- Die durchgehende Skybar unterscheidet jetzt auch innerhalb eines Stunden- oder Viertelstundenabschnitts präzise zwischen Nacht und Tageslicht. So verschwinden scheinbare Lücken unmittelbar nach Sonnenaufgang und gelbe Wolkenlücken enden rechtzeitig bei Sonnenuntergang.
- Die exakten Sonnenzeiten werden aus dem vorhandenen astronomischen Orts-/Zeitzonenmodell übernommen. Bewölkung bleibt eine eigene Modellgröße; ein gelbes Wolkenlückenband wird nicht als gemessene Sonnenscheindauer ausgegeben.
- Niederschlag bleibt mit unveränderter Menge, Phase, Farbgebung und Gültigkeitszeit auf seiner ursprünglichen Zeitachse. Auch klare Nächte und echte Datenlücken behalten ihre bisherige Bedeutung.
- Skybar-Kurven der Kurzfristansicht, des 24-Stunden-Profils, der Tageskarten und der 7-Tage-Kurvenübersicht verwenden denselben geprüften Intervallhelfer. Stundenquadrate bleiben diskrete Stunden-/Viertelstundensymbole; eine visuelle Minutenteilung findet nur im durchgehenden Band statt.

# MID v0.9.85.277 · Satellit→Modell-Zeitachse und optionale Isobaren

- Das neue „Modell-Wolkenbild“ in der gemeinsamen Kartenzeitachse erscheint nur an bestätigten Modellterminen. Während tatsächlicher Satelliten-/Radarbeobachtungen oder Nowcast bleibt das Modell-Wolkenoverlay ausgeblendet. Nutzer können die vorhandene Satellitenebene zur Betrachtung des Beobachtungs→Modell-Übergangs zuschalten; es werden keine Zwischenbilder erfunden.
- Für „Wolken und signifikantes Wetter“ lassen sich zusätzlich **Isobaren (hPa)** einschalten. Die erste Ausbaustufe verwendet ausschließlich geprüfte DWD ICON-D2-Druckkonturen desselben Modelllaufs und Gültigkeitszeitpunkts. Die Auswahl bleibt gespeichert und wird in SVG-/PNG-Exporten berücksichtigt. Bei Modellen ohne passende verifizierte Konturen (derzeit insbesondere GDPS) werden keine Isobaren vorgetäuscht.

# MID v0.9.85.276 · Modell-Wolkenbild als alternative Kartenansicht

- In „Wolken und signifikantes Wetter“ lässt sich bei DWD ICON-D2, ICON-EU und ICON nun zwischen „Standard“ und dem neuen, helleren „Modell-Wolkenbild“ wechseln. Dieses zeigt modellierte Wolken mit farbig darüber dargestellten Wettererscheinungen wie Nebel, Regen, Schnee und gefrierendem Niederschlag. Die Wahl bleibt gespeichert und wird auch in Kartenexporten übernommen.
- Das Modell-Wolkenbild ist eine schematische Modellvisualisierung, kein echtes Satellitenbild. Fehlende Felder werden nicht als wolkenfrei ausgegeben; Modellläufe, echte Wetterkategorien und die bestehenden Funktionen bleiben erhalten. Ein durchgängiger Übergang von Satellitenbeobachtungen zu Modellen ist ein separates Folgepaket.

# MID v0.9.85.275 · Parallele Extremwetter-Direktabrufe zuverlässig abbrechen

- Überlappen zwei Auswertungen des Extremwetter-Ausblicks, sind ihre Abbruchsignale jetzt voneinander isoliert. Ein Standort- oder Ansichtswechsel beendet nur den zugehörigen Direktabruf und bricht keine unabhängigen Auswertungen versehentlich ab.
- Die Optimierung betrifft ausschließlich den Browser-Direktfallback, wenn der bevorzugte MID-Worker nicht verfügbar ist. Erfolgreich zwischengespeicherte Daten, meteorologische Schwellenwerte, Farben, Warnungsabgrenzung und Datenverarbeitung bleiben erhalten.
- Ein zusätzlicher deterministischer Parallelitätsnachweis schützt das Verhalten bei verzögerten Folgeabrufen und stellt sicher, dass ein abgebrochener Abruf nach der Verarbeitung nicht als neuer vollständiger Live-Stand angezeigt wird.

# MID v0.9.85.274 · Modellstand: Einzelne ältere Läufe nicht pauschal rot

- Die Modellstand-Pillen der Kurzfrist-, 7-Tage- und 14-Tage-Prognosen bewerten nun den tatsächlich berücksichtigten Modellverbund statt automatisch das älteste Einzelmodell. Ein einzelner überfälliger Lauf unter sonst aktuellen Modellen wird gelb gemeldet und im Detail ausdrücklich als überfällig aufgeführt.
- Rot wird weiterhin angezeigt, wenn mindestens zwei Drittel der berücksichtigten Modellläufe überfällig sind oder der einzige verwendete Modelllauf überfällig ist. Grau kennzeichnet unverändert fehlende belastbare Modellmetadaten; vollständig aktuelle, verifizierte Läufe bleiben grün.
- Ausdrücklich nicht verwendete, lediglich geladene Kandidaten beeinflussen die Pille nicht mehr. Ein tatsächlich eingesetzter Ensemble-Fallback wird dagegen berücksichtigt. Grenzwerte der einzelnen RUC-, MOSMIX- und übrigen Modelle, Wetterwerte, amtliche Warnungen und die RUC-Kompression bleiben unverändert.

# MID v0.9.85.273 · Modellstand-Aktualität auf einen Blick

- Die Modellstand-Pillen der Kurzfrist-, 7-Tage- und 14-Tage-Prognosen zeigen die zeitliche Aktualität der berücksichtigten Modellläufe direkt: grün für aktuell, gelb für verzögert, rot für überfällig, grau gestrichelt bei unzureichenden Metadaten.
- Ein zusätzlicher Statuspunkt, eine aussagekräftige Schaltflächenbeschriftung für Screenreader und eine verständliche Detailerklärung machen den Zustand auch ohne Farberkennung zugänglich. Bei geöffneter App aktualisiert sich der Status einmal pro Minute.
- Die Kennzeichnung bewertet nur das Laufalter gegenüber der dokumentierten Aktualisierungsfrequenz. Sie ist keine Aussage über Prognosegüte und keine amtliche Wetterwarnung. Unvollständige Modellmetadaten gelten niemals als aktuell; Wetterwerte, RUC-Berechnung, Warnungen und bisherige Funktionen bleiben unverändert.

# MID v0.9.85.272 · Zusätzliche ICON-D2-Wetterkartentermine zuverlässig laden

- Die verlustfrei komprimiert veröffentlichten zusätzlichen ICON-D2-Karten für +13, +14, +16 und +17 Stunden erhalten jetzt denselben unveränderlichen SHA-Adressvertrag wie der bestehende Synoptik- und Kartenkatalog. Dadurch können Browser und Modellcache die nach erfolgreicher Prüfung veröffentlichten Karten wieder laden.
- Browser und DWD-Modellcache akzeptieren außerdem bereits mit v0.9.85.271 veröffentlichte Zusatzindizes unter ihrem früheren, ausdrücklich SHA-validierten Pfad. Alle neuen Indizes verwenden ausschließlich das kanonische Format. Ein Ende-zu-Ende-Test prüft beide erlaubten Varianten und weist unbekannte Pfade sowie ungültige Checksummen zurück.
- WMO-Wettercodes, echte Modelllauf- und Gültigkeitszeiten, Gitterkoordinaten, Kompressionswerte, Missing-Masken, unveränderter Rohdaten-Rollback und alle bestehenden Speicher-/Worker-/Pages-Gates bleiben erhalten. Die tatsächliche Verfügbarkeit zusätzlicher Termine ist von den verfügbaren DWD-Quelldaten abhängig.

# MID v0.9.85.271 · Nativen DWD-Kartengittervertrag reparieren

- Die geprüfte ICON-D2-Ergänzung für echte +13, +14, +16 und +17 Stunden verarbeitet nun die vom DWD-Decoder gelieferten separaten eindimensionalen Breiten-/Längenachsen korrekt. Bisherige, ausdrücklich rechteckige zweidimensionale Rasterdarstellungen bleiben weiterhin unterstützt.
- Koordinaten-, Feldlängen-, Monotonie-, Gültigkeitszeit-, WMO-Wettercode-, Missing- und SHA-Kontrollen bleiben streng. Ungültige Zusatzkarten werden nie als gültige Wetterwerte veröffentlicht.
- Der bereits gesicherte unveränderte RUC-Rohsnapshot, die vollständige verlustfreie Kompression, 900-MB- und Pages-Budgetgrenzen, Worker-/Pages-Gates und Skybar-Reparatur bleiben erhalten.
- Die zeitliche Ausweitung weiterer Modellkarten und der mögliche Einsatz nativer RUC-Karten sind fachlich in einer separaten Bestands- und Prioritätenprüfung dokumentiert. Weitere Zeitschritte werden erst nach tatsächlicher Quellfeld-, Speicher- und Performancevalidierung freigegeben.

# MID v0.9.85.270 · Zusätzliche ICON-D2-Wetterkartentermine nach RUC-Kompression

- Der bereits produktiv freigegebene verlustfrei komprimierte RUC-Snapshot kann zusätzlich tatsächlich vorhandene ICON-D2-Karten für Wolken und signifikantes Wetter (+13, +14, +16 und +17 Stunden) aufnehmen. Die Dateien werden nur bei passendem DWD-Modelllauf, exakter Gültigkeitszeit, Raster-/WMO-/Einheitenkontrolle und vollständigem SHA-Nachweis übernommen; fehlende Karten werden nicht künstlich erzeugt.
- Die Erweiterung erfolgt ausschließlich nach bestandenem RUC-Bytegleichheitsnachweis in einem eigenen unveränderlichen Kartennamespace. Originaldaten, veröffentlichte Kartentermine und die gesicherte unkomprimierte Rückfallkopie bleiben bestehen.
- Das 900-MB-RUC-Budget, die bisherige 950-MB-Pages-Grenze und sämtliche Worker-/Pages-/Freshness-/Rollback-Gates bleiben aktiv. Ist kein zusätzlicher gültiger Termin verfügbar, bleibt das bewährte Kartenangebot unverändert.
- Skybar-Fix und RUC-Snapshot-Schutz aus v0.9.85.268/.269 bleiben unverändert erhalten. Neue RUC-Parameter, native RUC-Karten und eine physische iOS-/VoiceOver-Abnahme werden mit dieser Änderung nicht behauptet.

# MID v0.9.85.269 · RUC-Snapshotprüfung für komprimierte Daten vervollständigen

- Der Installer erkennt jetzt auch das streng validierte aktive RUC-Kompressionsprofil. Eine übersehene Rohformat-Beschränkung hatte die Veröffentlichung der bereits geprüften Skybar-Korrektur sicher angehalten.
- Kandidaten und widersprüchliche Metadaten bleiben gesperrt; die exakte Modelllaufbindung sowie alle Release-Gates bleiben erhalten. Die Skybar-Korrektur aus .268 ist enthalten.

# MID v0.9.85.268 · Skybar bei kurzer Sonnenscheindauer konsistent

- Bekannte geringe Tagesbewölkung verschwindet nicht mehr aus der Skybar, wenn die Sonnenscheindauer innerhalb eines Intervalls kurz ist, etwa bei Sonnenauf- oder -untergang. Das gelbe Band bezeichnet dann ausdrücklich Wolkenlücken, nicht gemessene Sonnenscheindauer.
- Die gemeinsame Korrektur erreicht auch Tagesansichten, Widgets und Exporte. Graue Bewölkung, klare Nächte, Niederschlag und echte Datenlücken bleiben erhalten.
- Die inzwischen veröffentlichte vollständige RUC-Kompression bleibt unverändert; zusätzliche Wetterfelder oder Termine werden mit diesem Update nicht aktiviert.

# MID v0.9.85.267 · RUC-Daten verlustfrei komprimiert veröffentlichen

- Der RUC-Hintergrunddienst erhält ein vollständiges verlustfrei komprimiertes Datenprofil: Wetterwerte, Missing-Daten, Modellläufe und Zeitintervalle bleiben bitidentisch. Das veröffentlichte Datenpaket wird erst nach vollständig unabhängigen Python-/JavaScript- und Originaldatenprüfungen freigegeben.
- Für jeden komprimierten RUC-Lauf wird ein unveränderlicher Rohsnapshot zur Rücknahme gesichert. Bei fehlerhaftem produktivem Worker-Healthcheck versucht der etablierte GitHub-Pages-Weg automatisch die geprüften Originaldaten desselben Laufs wiederherzustellen.
- Aktualitätsprüfung, Installer-Restore und öffentliche Worker-/Pages-Healthchecks berücksichtigen das neue Format und unterscheiden es strikt vom bisherigen Rohprofil und von inaktiven Kompressionskandidaten.
- Das unveränderte 900-MB-Speicherlimit, amtliche Modellherkunft und Warntrennung sowie sämtliche bestehenden Parameter bleiben geschützt. Die tatsächliche Datenspeicherumstellung erfolgt erst mit dem nächsten vollständig geprüften RUC-Publish nach Stable-Promotion; bis dahin können einzelne Läufe kontrolliert ausfallen.
- Zusätzliche Parameter und Modellzeiten werden erst nach nachgewiesener produktiver Speicherreserve, gültigen DWD-Quellterminen und Leistungsprüfung zugeschaltet.

# MID v0.9.85.268 · Skybar bei kurzer Sonnenscheindauer konsistent

- Bekannte geringe Tagesbewölkung verschwindet nicht mehr aus der Skybar, wenn die Sonnenscheindauer innerhalb eines Intervalls kurz ist, etwa bei Sonnenauf- oder -untergang. Das gelbe Band bezeichnet dann ausdrücklich Wolkenlücken, nicht gemessene Sonnenscheindauer.
- Die gemeinsame Korrektur erreicht auch Tagesansichten, Widgets und Exporte. Graue Bewölkung, klare Nächte, Niederschlag und echte Datenlücken bleiben erhalten.
- Die inzwischen veröffentlichte vollständige RUC-Kompression bleibt unverändert; zusätzliche Wetterfelder oder Termine werden mit diesem Update nicht aktiviert.

# MID v0.9.85.267 · RUC-Daten verlustfrei komprimiert veröffentlichen

- Der RUC-Hintergrunddienst erhält ein vollständiges verlustfrei komprimiertes Datenprofil: Wetterwerte, Missing-Daten, Modellläufe und Zeitintervalle bleiben bitidentisch. Das veröffentlichte Datenpaket wird erst nach vollständig unabhängigen Python-/JavaScript- und Originaldatenprüfungen freigegeben.
- Für jeden komprimierten RUC-Lauf wird ein unveränderlicher Rohsnapshot zur Rücknahme gesichert. Bei fehlerhaftem produktivem Worker-Healthcheck versucht der etablierte GitHub-Pages-Weg automatisch die geprüften Originaldaten desselben Laufs wiederherzustellen.
- Aktualitätsprüfung, Installer-Restore und öffentliche Worker-/Pages-Healthchecks berücksichtigen das neue Format und unterscheiden es strikt vom bisherigen Rohprofil und von inaktiven Kompressionskandidaten.
- Das unveränderte 900-MB-Speicherlimit, amtliche Modellherkunft und Warntrennung sowie sämtliche bestehenden Parameter bleiben geschützt. Die tatsächliche Datenspeicherumstellung erfolgt erst mit dem nächsten vollständig geprüften RUC-Publish nach Stable-Promotion; bis dahin können einzelne Läufe kontrolliert ausfallen.
- Zusätzliche Parameter und Modellzeiten werden erst nach nachgewiesener produktiver Speicherreserve, gültigen DWD-Quellterminen und Leistungsprüfung zugeschaltet.

# MID v0.9.85.267 · RUC-Daten verlustfrei komprimiert veröffentlichen

- Der RUC-Hintergrunddienst erhält ein vollständiges verlustfrei komprimiertes Datenprofil: Wetterwerte, Missing-Daten, Modellläufe und Zeitintervalle bleiben bitidentisch. Das veröffentlichte Datenpaket wird erst nach vollständig unabhängigen Python-/JavaScript- und Originaldatenprüfungen freigegeben.
- Für jeden komprimierten RUC-Lauf wird ein unveränderlicher Rohsnapshot zur Rücknahme gesichert. Bei fehlerhaftem produktivem Worker-Healthcheck versucht der etablierte GitHub-Pages-Weg automatisch die geprüften Originaldaten desselben Laufs wiederherzustellen.
- Aktualitätsprüfung, Installer-Restore und öffentliche Worker-/Pages-Healthchecks berücksichtigen das neue Format und unterscheiden es strikt vom bisherigen Rohprofil und von inaktiven Kompressionskandidaten.
- Das unveränderte 900-MB-Speicherlimit, amtliche Modellherkunft und Warntrennung sowie sämtliche bestehenden Parameter bleiben geschützt. Die tatsächliche Datenspeicherumstellung erfolgt erst mit dem nächsten vollständig geprüften RUC-Publish nach Stable-Promotion; bis dahin können einzelne Läufe kontrolliert ausfallen.
- Zusätzliche Parameter und Modellzeiten werden erst nach nachgewiesener produktiver Speicherreserve, gültigen DWD-Quellterminen und Leistungsprüfung zugeschaltet.

# MID v0.9.85.266 · RUC-Vollkompression im Worker sicher vorbereiten

- Der MID-Datenworker kann künftig einzelne Datensätze aus einem vollständig verlustfrei komprimierten RUC-Paket lesen. Größen, SHA-256-Prüfsummen und unveränderte Wetterwerte einschließlich fehlender Werte bleiben geschützt.
- Das neue Ersatzformat wird nur akzeptiert, wenn das Manifest ausdrücklich als produktives, versioniertes Format gekennzeichnet ist. Ein vorbereiteter Kandidat wird weiterhin abgewiesen.
- Der bisherige Rohdatenpfad und der bereits geprüfte Kompressionspilot bleiben erhalten. Die laufenden RUC-Modellläufe und Modellkarten werden durch dieses Update noch nicht umgestellt.
- Vor der endgültigen Speicherfreigabe folgen eigenständige Worker-/Browser-/Altclient-, Frische-, Budget- und Rollbackprüfungen. Die Speichergrenze bleibt unverändert.

# MID v0.9.85.265 · Vollständige RUC-Kompression als geprüften Kandidaten vorbereiten

- Ein separates Werkzeug erstellt jetzt ein vollständiges verlustfrei komprimiertes RUC-Ersatzpaket mit eigenem Profil, geprüften Datensatzbereichen und exakter Bytebilanz einschließlich des endgültigen Manifests. Der Originalbestand bleibt als Rückfallreferenz unverändert.
- Ein vorbereiteter JavaScript-Reader liest die benötigten Datensätze mit begrenzter Parallelität, Warteschlange, Deadline und geprüften SHA-Werten. Er ist standardmäßig deaktiviert und wird noch nicht vom produktiven Worker geladen.
- Ein unabhängiger Nachweis prüft alle Kandidatendateien und jeden dekodierten Teil gegen die Originalbytes. Zusätzliche Vergleiche nutzen den tatsächlichen meteorologischen Record-Decoder für deterministische, EPS- und Rapid-Produkte.
- Die laufende RUC-Veröffentlichung bleibt beim bisherigen Profil mit Pilot. Die Aktivierung des vollständigen Ersatzformats erfordert noch die produktive Reader-Integration, Betriebsnachweise und einen gemeinsam geprüften Daten-/Worker-Rückfall.

# MID v0.9.85.264 · Vollständige RUC-Inventur und begrenzter Kompressionsnachweis

- Die vollständige Speicherprüfung verifiziert jetzt auch JSON-Dateien, bereits komprimierte Karten und Dateien außerhalb der Codec-Grenze gegen Größe und SHA-256. Beschädigte Bestände gelten nicht als erfolgreich geprüfte Inventur.
- Ein neuer separater Offline-Prüfer untersucht den gesamten materialisierten RUC-Bestand. Er zerlegt deklarierte 16-Bit-Datensätze verlustfrei an Datensatzgrenzen in höchstens 512 KiB große Teile und prüft die Rückwandlung unabhängig in Python und JavaScript.
- Der Nachweis bilanziert Originale, deduplizierte Codec-Dateien und Deskriptoren getrennt. Er zeigt sowohl einen hypothetischen Ersatzbestand als auch den zusätzlichen Platzbedarf bei erhaltenen Rohkopien. Die Quelldateien bleiben unverändert.
- Die vollständige Rohdatenablösung ist damit noch nicht aktiviert: Der Offline-Nachweis ersetzt weder ein produktives Migrationsformat noch den rückfallfähigen Rollout oder CPU-/RAM-Nachweise. Der aktive Pilot und das Speicherbudget bleiben erhalten.

# MID v0.9.85.263 · Begrenzte parallele RUC-Dekodierung und Offline-Nachweis

- Gleichzeitige Abrufe desselben komprimierten RUC-Chunks teilen jetzt einen einzigen geprüften Ladevorgang. Höchstens zwei unterschiedliche Codec-Vorgänge laufen gleichzeitig; weitere Abrufe nutzen den verifizierten Rohfallback.
- Zusätzliche Prüfungen decken parallele Abrufe, Fehler und Wiederanlauf sowie den Original-Service-Worker von .257 und den aktuellen Service-Worker im Browser ab. Offline dürfen keine alten oder beschädigten Cacheeinträge als aktuelle Wetterwerte erscheinen.
- Der bestehende verlustfreie Pilot und die Rohkopien bleiben erhalten. Dieser Schritt begrenzt Decoderarbeit und verbessert die geprüfte Kompatibilität; eine vollständige Rohdatenablösung oder Netto-Speicherreduktion wird damit nicht freigegeben.

# MID v0.9.85.262 · Kompakte Tageswerte in der Widget-Kurvenübersicht

- Bei aktivierter Niederschlagsoption zeigt die Kurvenübersicht direkt unter Tmin eine kompakte Tageszeile mit Menge und Wahrscheinlichkeit. Stundenmaxima bleiben als „max“ erkennbar; fehlende Werte werden nicht als trocken dargestellt.
- Sonnenstunden erhalten bei aktivierter Option eine eigene kompakte Zeile oberhalb des Diagramms.
- Ein eigenes Kästchen „Skybar“ zeigt oder verbirgt den vollständigen Wetterstreifen. Die Optionen für Niederschlags- und Sonnenwerte verändern seine Wetterlagen nicht mehr. Nachtbereiche im Diagramm bleiben erhalten.
- Die Auswahl wird gespeichert und gilt ebenso für Vorschau, PNG und direkte Widget-URLs. Bestehende Einstellungen behalten zunächst die sichtbare Skybar. Die Kästchen stehen auch auf breiten Displays übersichtlich in zwei Spalten.

# MID v0.9.85.261 · Gerade Skybar-Balken und RUC-Prüfwerkzeug

- Skybar-Balken besitzen in allen gemeinsamen Ansichten, Widgets und Exporten gerade Enden. Auch kurze Intervalle, Datenlücken und Dicken-/Phasenwechsel werden ohne abgerundete oder spitz zulaufende Kappen dargestellt. Zeitgrenzen, Wetterwerte, Dickenstufen und Niederschlagslagen bleiben erhalten.
- Ein lesendes Prüfwerkzeug vergleicht echte materialisierte RUC-Pilotdateien bytegenau mit den unveränderten Rohdaten und prüft Offline-Cache, Rohfallback und Abschaltung. Lokale Laufzeit-/Speichermessungen sind ausdrücklich keine Cloudflare- oder Geräteabnahme.
- Der begrenzte verlustfreie RUC-Pilot bleibt aktiv; die Rohdaten bleiben erhalten. Eine vollständige Rohdatenablösung wird damit nicht freigegeben.

# MID v0.9.85.260 · RUC-Betriebsnachweis und Open-Meteo-Prüfstand

- Die laufgebundene RUC-Betriebsprüfung protokolliert jetzt ausdrücklich, ob der begrenzte verlustfreie Pilot vom Worker verifiziert gelesen wurde. Ein erfolgreicher Rohdatenabruf wird dabei nicht als Codec-Erfolg ausgegeben; Abschaltung und Rohfallback bleiben möglich.
- Die bisherigen Open-Meteo-Prüfungen sind mit verifizierten Originalquellen konsolidiert: Tagesaggregate, GEM-Strahlung, HRRR/NAM-Windrichtung, ICON-Umstellung und weiterhin offene Böen-/RUC-Themen. Es erfolgen keine spekulativen Datenkorrekturen oder Modellwechsel.
- Die automatisierten Kartenprüfungen berücksichtigen jetzt den kürzeren ICON-Horizont der 06-/18-UTC-Läufe in ihren Testdaten. Die tatsächliche Isobarendarstellung bleibt verpflichtend geprüft.
- Alle RUC-Rohdaten bleiben erhalten. Der Pilot bedeutet weiterhin keine vollständige Speicherkompression oder Freigabe einer Rohdatenablösung.

# MID v0.9.85.259 · RUC-Pilot ohne zusätzliche Python-Laufzeitabhängigkeit

- Der begrenzte verlustfreie RUC-Pilot benötigt für Byteplane-gzip ausschließlich die Python-Standardbibliothek. Ein unnötiger Import diagnostischer NumPy-Helfer blockierte zuvor die unabhängige Installer-Prüfung von .258.
- Der End-to-End-Test läuft jetzt ausdrücklich ohne Python-Site-Packages. Rohdaten, Prüfsummen, Speicherbudget, Abschaltung und Rückfall bleiben unverändert.
- .258 wurde durch das fehlgeschlagene Installer-Gate nicht veröffentlicht. Dieses Release enthält den vollständigen geprüften Pilot einschließlich Body-Deadlinekorrektur; produktive Aktivierung ist weiterhin separat an einem echten RUC-Lauf nachzuweisen.

# MID v0.9.85.258 · Begrenzter RUC-Dual-Read-Pilot mit Rohdaten-Rückfall

- Die RUC-Aufbereitung kann erstmals eine kleine verlustfrei komprimierte Kopie eines tatsächlichen Chunks ergänzen. Alle Rohdateien bleiben erhalten; die Kopie wird nur bei ausreichendem freiem Speicher veröffentlicht.
- Der neue Worker kann sie im deterministischen Punktadapter lesen. Schlüssel, Chunk-Geometrie, Größen und Prüfsummen müssen stimmen. Andere Produkte und alte Worker behalten ihren bisherigen Datenweg.
- Eine defekte Kopie führt zum diagnostizierten Rohdaten-Rückfall. Der Datenweg kann auf Rohdaten zurückgestellt werden; Wetterwerte, Missing und Zeitauflösung bleiben gleich.
- Noch keine vollständige Speicherumstellung: keine Rohdatenentfernung, keine App-Cache-Löschung und keine Erhöhung des 900-MB-RUC-Budgets.

# MID v0.9.85.257 · RUC-Kompression mit isolierter Transportprüfung

- Ein getrenntes Diagnoseprodukt prüft die verlustfreie RUC-Kompression über die tatsächlich verwendete Dateiauslieferung. Rohdaten und drei Codecvarianten müssen alle 65.536 möglichen 16-Bit-Muster exakt erhalten.
- Browser und Worker verwenden dafür denselben geprüften Decoder. Dateigröße, Prüfsummen, HTTP-Auslieferung und ein getrennter Browser-Cache werden kontrolliert; beschädigte Antworten werden zurückgewiesen.
- Die Tests unterscheiden automatische HTTP-Entpackung von einer komprimierten Codec-Datei. Das verhindert eine falsche Bestätigung ungeeigneter Transportformate.
- Die Diagnose arbeitet ausschließlich mit synthetischen Testdateien. Die produktiven RUC-Daten, ihre Genauigkeit, Zeitschritte, Speichergrenze und bestehenden App-Caches bleiben bis zur gesonderten Migrationsabnahme unverändert.

# MID v0.9.85.256 · RUC-Kompression sicher für Browser und Worker vorbereiten

- Der neue Prüfschritt kann künftig verlustfrei komprimierte RUC-Wetterdaten in JavaScript wieder exakt in ihre ursprünglichen Werte umwandeln. Dabei werden auch fehlende Werte korrekt erhalten.
- Ein zusätzlicher automatisierter Test prüft alle 65.536 möglichen 16-Bit-Muster und echte Python-Kompressionsdateien. Beschädigte, verkürzte oder unerwartete Daten werden zurückgewiesen.
- Die Messung eines vollständigen RUC-Laufs zeigt für Byteplane-gzip rund 70,8 Prozent theoretisches Einsparpotenzial beim bisher veröffentlichten Datenbestand. Das ist eine Messung, noch keine aktivierte Speicherreduktion.
- Die bisherige RUC-Veröffentlichung, Wetterberechnungen, Karten und das bestehende Datenformat bleiben unverändert, bis Web-/Worker-Dual-Read, echte Leistungsprüfungen und die alten App-Caches sicher getestet sind.

# MID v0.9.85.255 · Kartenprüfung bei hoher Browserlast zuverlässiger

- Die regelmäßige Qualitätsprüfung der Wetterkarten verteilt gleichzeitig geöffnete Kartenfenster schonender. Dadurch wird die Software-Grafikdarstellung weniger stark überlastet.
- Alle 24 Bildschirmgrößen-, Design- und Hell-/Dunkel-Prüffälle bleiben erhalten. Die Anzeige der ICON-EU-Isobaren muss weiterhin tatsächlich funktionieren; eine fehlende Karte bleibt ein Fehler.
- Sollte die Prüfung scheitern, zeigt der Bericht jetzt deutlicher, welche Displayvariante, Modellkarte und Kartenlayer betroffen waren.
- An Wetterberechnungen, Modelllaufzeiten, Farben, Karteninhalten und der Bedienung ändert sich nichts. RUC-Datenformate und Speichergrenzen bleiben unverändert.

# MID v0.9.85.254 · Veröffentlichte Modellkarten wieder vollständig erreichbar

- Ein Fehler im Kartenkatalog wurde behoben: Gültige zusätzliche ICON-D2-Wolken-/Wettertermine bei +13, +14, +16 und +17 Stunden führten bisher dazu, dass die App den gesamten Synoptik-Katalog ablehnte. Die bereits veröffentlichten Karten von ICON-D2, ICON-EU, ICON, GFS und IFS sind dadurch wieder auswählbar.
- Die Prüfung bleibt streng: Zusatzstunden gelten ausschließlich für ICON-D2. Lauf, Gültigkeitszeit, Modellhorizont, Größe, Datenformat und Prüfsummen müssen weiterhin stimmen. Fehlende Karten werden nicht geschätzt oder künstlich ergänzt.
- Automatische Kartenprüfungen verwenden auch beim vollständigen Revisionslauf die bestehenden vollständigen Teilgruppen. Alle 24 Größen-/Theme-/Designfälle bleiben erhalten; die Zeitgrenze pro Teilgruppe wird nicht erhöht.
- Neue Regressionen prüfen den tatsächlich veröffentlichten Katalog und zusätzliche Kartenstunden. Wetterberechnungen, Darstellung, Speicherbudget und das RUC-Datenformat bleiben unverändert.

# MID v0.9.85.253 · Sicherheitsprüfungen mit eindeutigem Datenstatus

- Eine hohe Sicherheitslücke im Build-Werkzeugpfad wurde durch den kompatiblen Patch von `source-map-js` auf 1.2.2 behoben.
- Die Prüfung der Produktionsabhängigkeiten unterscheidet jetzt ein geprüftes Ergebnis von einem unbekannten Zustand bei ausgefallenen Prüfdiensten. Ein unbekannter Zustand wird nicht mehr als „keine hohen Sicherheitsbefunde“ bezeichnet.
- Prüfzeit, geprüfter Paketstand und verwendete Quelle werden nachvollziehbar dokumentiert. Bei Dienstausfällen wird eine notwendige Nachprüfung ausgewiesen.
- Unvollständige oder ungültige Antworten gelten nicht als erfolgreiche Prüfung. Bestätigte hohe und kritische Befunde blockieren weiterhin die Freigabe.
- Wetterdaten, Modellkarten und Darstellung bleiben unverändert. Die bestehende Regel für reine externe Dienstausfälle und die unabhängigen Release-Prüfungen bleiben erhalten.

# MID v0.9.85.252 · Modellkarten bei echten Datenlücken besser erreichbar

- Bei geöffneten Modellkarten wählt die gemeinsame Zeitleiste zum Einstieg einen tatsächlich vorhandenen Modelltermin statt eines reinen Radar-/Beobachtungszeitpunkts. Das reduziert leere Synoptik-Komposite bei ungleichmäßig verfügbaren Modellzeiten.
- Bei „Wolken und signifikantes Wetter“ kann ICON-D2 für einzelne fehlende Termine ein schon vorhandenes, zeitgleiches natives Wolken-/Wetterfeldpaar nutzen. Fehlende oder unpassende Felder werden weiterhin nicht ergänzt oder geschätzt.
- Zusätzliche Regressionen prüfen die Terminwahl und stellen sicher, dass nur gemeinsam verfügbare Modellfelder verwendet werden.
- Modellberechnungen, Warnschwellen, RUC-Datenformat, Speicherschutz und die Bedienung anderer Wetterkarten bleiben unverändert.

# MID v0.9.85.251 · Zuverlässigere RUC-Veröffentlichungsprüfung

- MID prüft nach dem Hochladen neuer RUC-Wetterdaten etwas länger, ob der neue Modelllauf tatsächlich an der öffentlichen Adresse angekommen ist. Dadurch führen verzögerte Pages-Aktualisierungen seltener zu unnötigen Fehlalarmen.
- Die Überprüfung bleibt streng: Ein älterer oder ungültiger Modelllauf wird weiterhin nicht als erfolgreich bestätigt. Auch der Worker muss den richtigen Lauf und vollständige Daten melden.
- Zusätzliche automatisierte Tests simulieren sowohl eine verspätete Aktualisierung als auch dauerhaft veraltete oder ungültige Daten. Der Kontrolllauf dokumentiert jetzt die einzelnen Wiederholungsversuche verständlicher.
- Das Wettermodellangebot, die Berechnungen, das Datenspeicherbudget und die App-Oberfläche bleiben unverändert.

# MID v0.9.85.250 · RUC-Datenaktualisierung wieder absichern

- Ein Fehler im neuen internen RUC-Kompressions-Prüfmodul wurde korrigiert. Er hatte zuletzt die Veröffentlichung neuer RUC-Wetterdaten verhindert, obwohl die eigentliche Datenaufbereitung bereits erfolgreich war.
- Vor dem zeitaufwendigen Laden der DWD-Modellfelder kontrolliert MID jetzt alle Python-Programme der RUC-Pipeline auf Syntaxfehler. Zusätzlich ist diese Prüfung im Entwicklungs- und Freigabetest verankert.
- Die eigentlichen RUC-Modellwerte, das Speicherbudget, die Modellkarten und das bisherige Datenformat bleiben unverändert; eine produktive verlustfreie Kompression folgt erst nach eigenen Decoder- und Leistungstests.
- Die App-Oberfläche und ihre Bedienung ändern sich durch diese Fehlerbehebung nicht.

# MID v0.9.85.249 · RUC-Speicheroptimierung sicher vorbereiten und CSS-Startlast messen

- MID prüft neue verlustfreie RUC-Kompressionsverfahren jetzt mit einem zusätzlichen Sicherheitscheck. Dabei bleiben sämtliche 16-Bit-Werte einschließlich fehlender Wetterdaten unverändert; beschädigte und zu große Datenpakete werden im Test erkannt.
- Der Qualitätscheck misst nun die beim App-Start direkt eingebundenen CSS-Dateien auch in gzip- und Brotli-Größe. Das schafft eine Grundlage für gezielte Ladezeitverbesserungen ohne Layoutverlust.
- Noch keine Änderung der tatsächlich ausgelieferten RUC-Datenformate oder des Wetterkartenangebots: Eine produktive Kompressionsumstellung erfolgt erst nach Web-, Worker-, iOS- und Frischeprüfung.
- Prognosen, Warnungen und das gewohnte App-Design bleiben unverändert.

# MID v0.9.85.248 · Zusätzliche ICON-D2-Karten nur bei freiem Speicherbudget

- Für „Wolken und signifikantes Wetter“ versucht MID vier zusätzliche stündliche ICON-D2-Termine (+13, +14, +16 und +17 Stunden), sofern passende Originalfelder tatsächlich vorliegen.
- Die neuen Zeiten werden nur dann veröffentlicht, wenn nach allen bisherigen Karten und RUC-Prognoseprodukten genügend Platz verbleibt. Bestehende Kartentermine werden dafür nicht entfernt, und eine Sicherheitsreserve bleibt bestehen.
- Die CSS-Aufteilung wurde hinsichtlich tatsächlicher Ladewege und späterer Überschreibungen weiter untersucht. Die globale Darstellung bleibt bewusst unverändert, bis die ausgelagerten Styles in allen Größen und Darstellungsmodi nachweislich gleich aussehen.

# MID v0.9.85.247 · Prognose-Radar und klarere Modellkarten

- Das Prognose-Radar prüft auch Favoriten, die nicht geöffnet wurden. Fehlgeschlagene Prüfungen werden bei sichtbarer, verbundener App früher erneut versucht; die regelmäßige Kontrolle erfolgreicher Favoriten bleibt erhalten.
- Im Radar werden Fehler beim Wetterabruf und beim Speichern im Gerät jetzt getrennt angezeigt. So ist besser nachvollziehbar, warum noch keine Prognosebasis vorhanden ist.
- Modellwetterkarten zeichnen Länder- und Verwaltungsgrenzen als eigene Kartenlinien über den Wetterflächen. Ortsnamen bleiben ebenfalls sichtbar; die bereits funktionierenden Kompositkarten sind unverändert.
- Zusätzliche ICON-D2-Stunden werden aus Sicherheitsgründen noch nicht aktiviert: Die RUC-Datenveröffentlichung nutzt bereits nahezu das gesamte 900-MB-Speicherbudget. Vor einer Ausweitung müssen Speicherbedarf und Frische nachweislich abgesichert werden.

# MID v0.9.85.246 · Startlast der Darstellung messbar

- MID erfasst beim Qualitätscheck jetzt getrennt, wie groß die unmittelbar beim App-Start benötigten Gestaltungspakete sind. Damit lassen sich kommende Geschwindigkeitsverbesserungen zuverlässig überprüfen.
- Die Größen für komprimiertes CSS werden mitgemessen, ohne später geladene Ansichten fälschlich zum Startpaket zu zählen.
- Wetterdaten, Piktogramme und das gewohnte Layout bleiben unverändert. Die eigentliche Verkleinerung des Haupt-CSS folgt nach belastbaren Vergleichsmessungen.

# MID v0.9.85.245 · Robuste Wetterdatenabfragen

- Geschlossene Karten-Info-Dialoge geben den Tastaturfokus nur zurück, wenn inzwischen kein anderes Bedienelement ausgewählt wurde. Dadurch bleiben Deckkraftregler und Kartentermin unabhängig bedienbar.
- Identische gleichzeitige Wetterdatenabfragen werden weiter gemeinsam ausgeführt, ohne dass der Abbruch einer Ansicht andere aktive Ansichten beeinträchtigt.
- Bei Orts- und Ansichtswechsel werden nicht mehr benötigte Abfragen beendet, weiterhin benötigte Daten jedoch zuverlässig geladen.
- Explizite längere Wartezeiten von Open-Meteo werden eingehalten; unnötige erneute Versuche bei einer längeren Sperre werden vermieden.
- Zusätzliche automatische Tests sichern gemeinsame Abfragen, unabhängige Abbrüche und die Behandlung von Rate-Limits ab. Wettermodelle und Vorhersageberechnung bleiben unverändert.

# MID v0.9.85.244 · Temperaturspanne und verlässliche Radar-Basis

- Aktuelles zeigt Minimum und Maximum aller angezeigten 12-h-Stundenwerte statt einer Differenz zwischen Anfang und Ende. Fehlende Werte werden ausgewiesen.
- Prognose-Radar speichert Best-Match-Eingänge unabhängig vom Aufklappen. Favoriten werden bei sichtbarer, verbundener App alle 30 Minuten mit höchstens zwei parallelen Abrufen geprüft. Keine Hintergrund-Aufzeichnung bei geschlossener App.
- Anzahl gespeicherter Stände, letzter Stand und letzte Prüfung machen unveränderte Eingänge, Datenlücken und Fehler sichtbar. Fehlende Ensemble-Werte werden nicht als Nullen verglichen.
- Doppelte Kartenbeschreibungen konsolidiert hinter zugänglichem Info-Button; Legende, Quellen, Lauf, Termin und Fehlermeldungen bleiben erreichbar bzw. sichtbar. Auch Ortsvergleich, Radar-Methode und Prognosehinweis verwenden das gemeinsame Info-Popover.

# MID v0.9.85.243 · Orte sortieren und verständliche Wetterwerte

- Prognose-Radar unter Vorhersage eindeutig benannt. Die erweiterte Ensembleanalyse im Prognose-Cockpit zeigt dieselbe Auswertung nicht doppelt; eigenständige Ensembleansichten und Änderungsbenachrichtigungen bleiben erhalten.
- Die Mehrort-Übersicht folgt standardmäßig deiner Favoritenreihenfolge in den Einstellungen. Sortiere alternativ nach Ortsname, Warnlage, Temperatur, Niederschlagsmenge, Böen oder Entfernung. Deine Wahl bleibt gespeichert.
- Übersicht und „Wetterfenster vergleichen“ haben klar unterschiedliche Aufgaben: kompakte Wetterkarten gegenüber einer Rangliste mit hervorgehobenen passenden Stunden und konkreten Trockenphasen.
- Ganzzahlige Temperaturen in der Ortsübersicht; gleiche gerundete Minima und Maxima werden nur einmal angezeigt.
- Einheitliche parameterabhängige Anzeigepräzision: keine Hundertstel bei Niederschlagswerten, ganzzahlige Windwerte auch in m/s, Sichtweiten in fachlich passenden Stufen. Kleine positive Niederschläge bleiben als „<0,1 mm“ sichtbar.
- Neuer verbindlicher Präzisionsvertrag unterscheidet SYNOP-Berichtsregeln von MID-Prognosedarstellung. Die unveränderten Originalwerte bleiben Grundlage für Berechnungen und Vergleiche.

# MID v0.9.85.242 · Meine Orte und korrektes Desktop-Wetterprofil

- Eigene Favoritenseite „Meine Orte“ über die Ortsleiste und Mehr: Mehrort-Übersicht, fairer Ortsvergleich und vorhandene Favoritenverwaltung. Die Seite lädt unabhängig von der Prognose des gerade ausgewählten Orts; Zeitraum, Profil und Umkreis bleiben gespeichert.
- MID Prognose-Radar ist direkt bei der Vorhersage als „Prognoseänderungen“ erreichbar. Die Ansicht lädt beim Öffnen und merkt ihren geöffneten Zustand; bestehende Modellhistorie und gemeinsame Gültigkeitstage bleiben maßgeblich.
- Behebt das im Screenshot sichtbare Desktop-Raster des 24-h-Wetterprofils: Überschrift über beide Spalten, breite Grafik links, kompakte Einzeldaten rechts. Der gemeinsame Profilrenderer gilt auch für Widgets und Exporte.
- Update-Meldung mit lesbarer Textbreite, korrekt markierter Aktuell-Navigation und direkt geöffneten Planermodulen. Neue Eventtermine berücksichtigen die Zeitzone des Zielorts.
- Fehlende WebGL2-Unterstützung zeigt eine wiederholbare Kartenmeldung, statt die ganze App abzubrechen. Gleiche Temperatur-Minima/Maxima erzeugen keine doppelten Diagrammmarkierungen.
- Responsive Browserprüfungen umfassen breite Desktopansichten, Favoritenseiten-Navigation, Zustandswiederherstellung und Grafikfehler. Physische iOS-Geräte und deren Grafiktreiber sind damit nicht geprüft.

# MID v0.9.85.241 · Sicherer Profilstart am Tag-/Nachtübergang

- Behebt den im veröffentlichten Browser reproduzierten Startabbruch bei einer Kurzfrist-Stundengruppe, die den Sonnenaufgang überschreitet.
- Das zusammengefasste Wetterpiktogramm verwendet denselben Tag-/Nachtstatus wie der sichtbare Intervallbeginn. Fehlende zivile Zeitfelder lösen keinen Startabbruch aus.
- Sonnenaufgang, Sonnenuntergang, fehlende Zeitfelder und unveränderte Niederschlagsintervalle werden mit dem echten Profilrenderer geprüft.

# MID v0.9.85.240 · Orte vergleichen und Prognoseänderungen verstehen

- Neuer gemeinsamer Bereich „Orte & Prognose“ unter Aktuell: Mehrort-Übersicht, Ortsvergleich 2.0 und MID Prognose-Radar.
- Alle Favoriten im gleichen kommenden 6-/12-/24-Stunden-Fenster, Trockenfenster, Regenrisiko, Temperatur und Böen; Profile und 30-/100-km-Filter werden gespeichert. Fehlende oder veraltete Daten erhalten keinen Spitzenplatz.
- Mehrort-Übersicht priorisiert amtliche Warnungen, Datenlücken und relevante Wetterlagen. Ensemble-P25/P75-Spannen werden gezielt ergänzt und nur für vollständig abgedeckte Stunden ausgewiesen.
- Prognose-Radar nutzt den vorhandenen Drei-Tage-Modellvergleich: Bisher/Jetzt, Relevanzfilter, Datenkontext und bis zu sechs Prognosestände für denselben Gültigkeitstag. Derselbe Renderer wird im Ensemblebereich verwendet.
- Regenbeginn wird mit absoluten Zeitstempeln abgesichert; abgelaufene Ereignisse und neu ins rollende Fenster kommende Termine werden nicht als Prognoseänderung ausgegeben. Ursachen ohne archivierte Eingangsevidenz bleiben ausdrücklich unbestimmt.
- Daten laden erst beim Öffnen, mit begrenzter Parallelität und Abbruch bei Orts-/Ansichtswechsel. Keine zusätzlichen kostenpflichtigen Quellen.

# MID v0.9.85.239 · Beobachtungen merken und kompakte Wetterphasen

- Beobachtungen lassen sich gemeinsam aus-/einschalten; die gewählten Einzellayer bleiben gespeichert. Direkte Bedienaktionen speichern sofort, unveränderte alte Karteninstanzen überschreiben keine neuere Auswahl.
- Höhenkonturen: 8/4 gpdm. Druckkonturen: 5/2/1 hPa nach Zoom und numerischem Gradienten; neue 1-hPa-Geometrie wird aus dem Modellfeld erzeugt. Ältere unveränderliche Dateien behalten ihre vorhandenen Linien bis zum nächsten passenden Datenlauf.
- Feinere ICON-D2-Isobaren werden einmal im Bodendruckfeld gespeichert; andere native Karten und Exporte nutzen die exakt lauf-/terminpassende Druckgeometrie. T/H bleiben ausschließlich in reinen Bodendruckkarten.
- Der Wetterphasenbereich wird im aktiven Stylesheet kompakt dargestellt: drei kurze Zeilen auf Smartphones, drei Spalten auf größeren Bildschirmen. Werte, Ensemble-Spannen und Quellen bleiben unverändert.

# MID v0.9.85.238 · Adaptive Konturen und klare Ortsanzeige

- Numerische Isobaren/Isohypsen werden beim Zoomen mit 16/8/4 hPa bzw. dam sichtbar; veröffentlichte Daten bleiben unverändert. Isobaren unter 1013 hPa sind gestrichelt, auch im ICON-D2-Export.
- T/H erscheinen ausschließlich in reinen Bodendruckkarten, nicht im Synoptik-Komposit.
- Die Ortszeile erhält eine deckende, isolierte und untransformierte Darstellung; responsive Browserprüfungen berücksichtigen Bottom-Tabs und Nachkomma-Scrollpositionen.
- RUC-Speicheraudit ergänzt einen verlustfreien Delta-/Byteplane-Kandidaten mit vollständiger Byte-Rückprüfung. Keine produktive Codec-Aktivierung, Genauigkeitsreduktion oder Budgetänderung.

Details: docs/implementation/MID_C28_ADAPTIVE_CONTOURS_0.9.85.238.md. Echte iOS-/WKWebView-Abnahme bleibt offen.


# MID v0.9.85.237 · Karten merken sich die Auswahl, mehr ICON-D2-Stunden und Druckzentren

- Die gespeicherte Modellwahl bleibt auch erhalten, wenn ein Modell vorübergehend nicht im Katalog verfügbar ist. Radar-/Satelliten-Layer werden beim erneuten Öffnen wiederhergestellt; die gemeinsame Karte überschreibt keine alte Synoptik-Auswahl.
- Native ICON-D2-Karten erhalten echte Termine für jede Stunde von +1 bis +6. Zusätzliche Synoptik-Termine werden aus demselben Lauf geprüft und im Speicherbudget vor verzichtbarer späterer Dichte erhalten.
- Bodendruckkarten und Synoptik-Komposit zeigen modellgestützte Hoch-/Tiefzentren mit H/T und Druckwert. Markierungen werden nur aus passenden numerischen Druckdaten desselben Laufs und Termins erzeugt. ICON-D2-Exporte enthalten dieselben Zentren.
- Speichergrenzen, Prüfsummen, Mess-/Prognoseunterscheidung und fehlende Daten bleiben verbindlich. Tatsächlich verfügbare Termine richten sich nach Quelle und erfolgreicher RUC-Veröffentlichung.

# MID v0.9.85.236 · Ortsanzeige und verlustfreie RUC-Deduplizierung

- Die ausgewählte Ortsleiste bleibt beim Scrollen über dem Suchkopf scharf lesbar. Der überlagernde Kopf-Blur wird bei sichtbarer Ortsleiste abgeschaltet; Karten-/Einstellungsgrenzen und Dialoge bleiben erhalten.
- Bytegleiche RUC-Chunks werden nach Hash, Größe und vollständigem Bytevergleich einmal gespeichert. Der Worker unterstützt geprüfte Chunk-Aliase sowie unverändert ältere Snapshots. Missing, trockene Nullen, Zeitachsen und Datengenauigkeit bleiben bitidentisch.
- Gemessener Lauf2026-10-11T05:00:899950367 Objektbytes,20103168 Duplikatbytes. Der tatsächliche Gewinn jedes neuen Laufs fließt vor der Synoptik-Budgetierung ein und erhält damit mehr validierte Modelltermine, sofern verfügbar.1MB Reserve plus exakte Manifestprüfung schützen das unveränderte900MB-Budget.
- Gzip/Byteplane-Kompression bleibt Messkandidat bis vollständige Lauf-/Decoder-/Performance-Evidenz vorliegt. Keine zusätzlichen Felder oder Modelle werden zur Einsparung gestrichen, kein kostenpflichtiger Speicher aktiviert.

# MID v0.9.85.235

- Legende und Info dezent im gemeinsamen 24-h-Profilkopf mit unveränderten Funktionen und gut erreichbaren Touchflächen.
- Der ausgewählte Ort bleibt außerhalb von Karten und Einstellungen kompakt am oberen Rand sichtbar, einschließlich Favoritenalias.
- Der verlustfreie RUC-Speichervergleich misst zusätzlich reversible Byteplanes plus gzip. Produktionsdaten, Auflösung und Speichergrenzen bleiben unverändert.

# MID v0.9.85.235

- Legende und Info dezent im gemeinsamen 24-h-Profilkopf mit unveränderten Funktionen und gut erreichbaren Touchflächen.
- Der ausgewählte Ort bleibt außerhalb von Karten und Einstellungen kompakt am oberen Rand sichtbar, einschließlich Favoritenalias.
- Der verlustfreie RUC-Speichervergleich misst zusätzlich reversible Byteplanes plus gzip. Produktionsdaten, Auflösung und Speichergrenzen bleiben unverändert.

# MID v0.9.85.234

- GDPS-Wolken und Niederschlagsart erhalten das von GeoMet verlangte UTC-Zeitformat ohne Millisekunden. Lauf und gültiger Termin bleiben exakt erhalten; echte Sekundenbruchteile werden abgewiesen.
- Jede RUC-Aufbereitung protokolliert jetzt Speicheranteile, Restbudget, mögliche identische Objekte und begrenzte verlustfreie gzip-Stichproben. Zusätzlich werden die tatsächlich veröffentlichten Wolken-/Wetterstunden ausgewiesen.
- Das 900-MB-Budget, die Datenauflösung und sämtliche veröffentlichten Wetterwerte bleiben unverändert. Kompression und Deduplizierung werden zunächst gemessen, bevor ein neuer Datenvertrag eingeführt wird.

# MID v0.9.85.233

Die Wolken-/Wetterkarte behält bei knappem Speicher bevorzugt die stündlichen ICON-Termine bis +12 h. Zusätzliche Synoptiktermine werden vor diesen Stunden entfernt; die vollständigen Pflichttermine und RUC-Kerndaten bleiben erhalten. Der Katalog dokumentiert die tatsächlich gekürzten Termine. Das Speicherlimit bleibt bei 900 MB.

„Wolken und Wetter erneut laden“ erstellt nach einem GDPS-Ladefehler neue Kartenquellen, statt die fehlgeschlagene Kombination unverändert weiterzuverwenden. Beide Ebenen müssen erneut vollständig laden.

Die Karten-Liveprüfung und der Intensivaudit laufen weiter. Echte iOS-/WKWebView-/VoiceOver-Abnahme und langfristige SLO-/Alarmierungsnachweise sind weiterhin offen.

# MID v0.9.85.232

„Wolken und signifikantes Wetter“ erhält eigenständige Modelltermine: ICON-D2, ICON-EU und ICON Global stündlich von +0 bis +12 h, danach größere Abstände innerhalb des Modellhorizonts. Angezeigt werden ausschließlich tatsächlich aufbereitete und geprüfte Wolken-/Wetterpaare. Fehlende Termine werden nicht interpoliert.

Die Veröffentlichung transportiert die zusätzlichen Raster einschließlich Prüfsummen; Wiederverwendung und Speicherbudget berücksichtigen sie. Die gröbere Synoptik-Zeitfolge begrenzt diese Karte nicht mehr. Quellen erscheinen, sobald entsprechende Daten veröffentlicht sind.

GDPS behält auswählbare gemeinsame Termine unabhängig von einer unpassenden bisherigen Kartenzeit. Unvollständig geladene Kombinationen erhalten eine Fehlermeldung und einen erneuten Ladeversuch. GDPS liefert die Kombination in dreistündlichen, später gröberen Abständen; stündliche Wolken allein werden nicht als stündliches kombiniertes Wetter ausgegeben.

Wissenschaftlicher Audit: Lauf-, Termin-, Raster-, Missing- und Publikationsverträge werden weiter geprüft. Offene Einheitenfragen und die vollständige externe Referenz-/Geräteabnahme bleiben offen.

# MID v0.9.85.231

Unter Karten ersetzt „Wolken und signifikantes Wetter“ das Einzelprodukt. Graue Bewölkung plus farbige direkte Wettererscheinungen desselben Modelllaufs: ICON-D2, ICON-EU/Global bei bestätigten Daten; GDPS global mit Wolken und momentaner Niederschlagsart, ausdrücklich ohne vollständige Nebel-/Gewitterdiagnostik. Gemeinsame native Ortswerte und PNG-/SVG-Exporte; Kategorien bleiben ohne Interpolation, Missing bleibt unbekannt.

Fehlende optionale RUC-Graupeldaten bleiben beim Erzeugen, Speichern und Lesen der Niederschlagsphasen als „nicht verfügbar“ erhalten. Sie werden nicht mehr als trockene Nullwerte ausgegeben. Vorhandene Regen-/Schneewerte und echte trockene Graupelwerte bleiben nutzbar; vollständig fehlende Phasenzellen bestehen die Verfügbarkeitsprüfung nicht.

Das Radar-Phasenoverlay behandelt fehlende Temperatur-/Feuchtewerte ebenfalls als fehlend. Aus null oder leeren Werten entstehen keine künstlichen 0 °C und kein thermischer Beleg für Schnee oder gefrierenden Niederschlag.

Wissenschaftlicher Audit: Regressionen prüfen Missing-Sentinels, partielle Datenlücken, echte trockene Nullwerte, Extremwetter-Ausgabe und den Worker-Leseweg. Weitere Parameter-/Einheitenverträge, der vollständige wissenschaftliche Referenzlauf und externe Geräte-/SLO-Abnahmen bleiben offen.

# MID v0.9.85.230

Die Skybar unter „Aktuelles“ verwendet jetzt dieselbe kanonische Kurzfristreihe und Stundenaufbereitung wie das Wetterprofil unter „Heute“. Auch leichte, kurze Regenphasen unter 0,1 mm bleiben als Niederschlagsband sichtbar. Beginn und Ende werden auf der gemeinsamen Zwölf-Stunden-Zeitachse verortet; Stundenquadrate erhalten dieselben Niederschlags- und Bewölkungswerte wie „Heute“.

Explizite Niederschlagsintervalle werden im gemeinsamen Skybar-Renderer nach ihren echten Grenzen gezeichnet. Datenlücken bleiben Lücken; am Rand abgeschnittene Intervalle erhalten keine künstlich erhöhte Intensität. Der wissenschaftliche Gesamtaudit und die dort dokumentierten weiteren Abnahmen bleiben offen.

Unter „Karten“ erscheinen Modelle alphabetisch nach ihrem Namen und Parameter alphabetisch innerhalb der bisherigen Unterkategorien. Gespeicherte Auswahlen, verfügbare Produkte und fachliche Quellenprioritäten bleiben erhalten.

Wissenschaftlicher Audit: Die optionalen Energiefelder CAPE_MU/CIN_MU erhalten feste, gegen echte DWD-Header geprüfte Einheiten-, Produkt-, MU-Schicht- und Zeitverträge. Falsche Einheiten oder eine Verwechslung mit der ML-Schicht werden vor Verarbeitung abgewiesen. Weitere optionale Produkte und der vollständige wissenschaftliche Referenzlauf bleiben offen.

# MID v0.9.85.229

UTCI erscheint unter „Aktuell“ als eigene hervorgehobene Wertgruppe mit °C und thermischer Einordnung. Die 14-Tage-Entwicklung bündelt drei Wetterphasen und kompakte, verbundene Tmax-/Tmin-Verläufe; echte Ensemble-Spannen und Datenlücken bleiben erkennbar.

Wissenschaftlicher Audit: Reale DWD-Werte aus 66 Dateien wurden für +0/+1 Stunde auf dem vollständigen nativen Gitter und mit allen 20 EPS-Mitgliedern geprüft. Eine eingefrorene Auswahl dekodierter Zellen erlaubt reproduzierbare Einheiten-, QC-, Missing- und Packing-Vergleiche. Der vollständige 14-Stunden-/Rapid-/E2E-Referenzlauf und weitere Auditpunkte bleiben offen.

# MID v0.9.85.228

Wissenschaftlicher Audit: Die zwölf RUC-Kernparameter, CLAT/CLON und EPS-Niederschlag werden gegen feste, anhand echter DWD-Header kalibrierte Parameter-, Schicht-, Zeitfenster- und Gitterverträge geprüft. Gleiche Zellzahl allein reicht nicht mehr: Gitter-UUID und Referenzkennungen müssen stimmen. Niederschlag muss seit Modellstart akkumuliert sein, Böen das vorangegangene native Stundenfenster abdecken; Gültigkeit und Vorlauf müssen zur UTC-Initialisierung passen. Viertelstunden-/Sekundenangaben werden mit expliziter Einheit dekodiert. Neue Metadaten unterscheiden Quell-Akkumulation von gepackten Intervallmengen. Optionale Levelkalibrierung, vollständige Werte-/E2E-Referenzabnahme und reale Geräteprüfungen bleiben offen.

# MID v0.9.85.227

Wissenschaftlicher Audit, nächstes Einheitenpaket: Native RUC-Gitterkoordinaten werden nach deklarierter Grad-/Radiant-Einheit umgerechnet, nicht nach ihrer Größenordnung. Falsch gerichtete oder unbekannte Koordinateneinheiten werden abgewiesen. Windkomponenten/Böen, CAPE/CIN und Niederschlagsakkumulation erhalten explizite Einheitenprüfungen vor Aggregation und Packing. Trockene Nullwerte, fehlende Werte und Eingabearrays bleiben erhalten. Archivierte DWD-Header belegen die verwendeten Produkteinheiten. Vollständige Parameter-/Level-/Zeitfenster-/Gitteridentitäts- und reale Geräteabnahmen bleiben offen.

# MID v0.9.85.226

Wissenschaftlicher Audit, erstes Umsetzungspaket: Fehlende RUC-Niederschlagswerte werden in Extremwetter-Summen und Ensemble-Auswertungen nicht mehr als trockene Null gewertet. Unvollständige Mitgliedsperioden werden aus Wahrscheinlichkeiten und Quantilen ausgeschlossen; tatsächlich trockene Werte bleiben Null. Fehlende Niederschlagsphasen bleiben erkennbar fehlend. Ein reproduzierbares wissenschaftliches Inventar und eine geprüfte Referenzbaseline ergänzen die Entwicklungsprüfung. Die Browserprüfung der Update-Bedienung misst Touch-Ziele nach Ende der Einblendanimation. Weitere fachliche Audit- und reale Geräteabnahmen bleiben offen.

# MID v0.9.85.225

MID-C26: RUC-Einheiten werden aus GRIB-Metadaten umgerechnet. Native geringe Prozentwerte werden nicht mehr als Bruchteile vervielfacht; Temperatur und Luftdruck wechseln die Einheit nicht anhand der Wetterwerte. Unbekannte Einheiten dieser Felder werden vor Publikation abgewiesen. Reale DWD-Header mit URL/Hash archiviert, numerische Einheitennaht- und Missing-Data-Regressionsfälle ergänzt. Hardware-/VoiceOver-/WKWebView-Abnahme und langfristige SLO-Kalibrierung bleiben offen.

# MID v0.9.85.224

MID-C26: Vollständiger RUC-Kernparametervertrag. Fehlender Luftdruck oder CIN wird vor Packing/Publikation abgewiesen; normalisierter Luftdruck muss positiv, CIN als Betrag nicht negativ sein. EPS-Kennungen müssen eindeutig sein. Native Missing-Zellen und bestehende Quoten bleiben erhalten. Keine vollständige numerische, Geräte- oder SLO-Abnahme behauptet.

# MID v0.9.85.223

- Updatehinweise unterscheiden verfügbare, noch vorbereitete und aktivierte Versionen. „Update laden und aktivieren“ benennt die tatsächliche Wirkung; „Für diese Sitzung ausblenden“ unterdrückt weitere Versuche dieser Version in der laufenden Seite.
- Automatische Aktivierung beachtet die gespeicherte Auswahl. Einschalten startet den aktuellen Versuch; nach Wiederverbindung kann MID erneut prüfen. Gleichzeitige Versuche werden zusammengeführt und das Ende eines Retry-Budgets ausdrücklich angezeigt.
- Eine bereits geladene neue Version lässt sich aus dem Rückfallcache gezielt neu starten. Auch ein verpasster Neustart unter einem bereits neuen Controller wird erkannt.
- Der Rückfallknopf wird bei fehlender oder verspäteter Antwort spätestens nach zehn Sekunden wieder bedienbar. Fehlermeldungen und Zielversion sind sichtbar; späte Antworten nach Timeout lösen keinen überraschenden Neustart aus.
- HTML, Versionsdatei und Service Worker müssen beim Vorbereiten denselben Release tragen. Unvollständige Caches und Aktivierungsanfragen für einen anderen Release werden abgewiesen.
- Updateknöpfe und Automatik-Auswahl erhalten größere Touchflächen, umbrechende Bezeichnungen und zugängliche Statusbeschreibungen. Eine neue Browsermatrix prüft sieben Bildschirmgrößen in hellem und dunklem Design; echte VoiceOver-/WKWebView-Abnahme bleibt separat erforderlich.

# MID v0.9.85.222

- RUC-Datenprüfungen protokollieren fehlende Rasterzellen getrennt nach Parameter, Vorhersagezeit und Ensemble-Mitglied.
- Dauerhaft fehlende Zellen und zusätzliche zeitweise Ausfälle werden getrennt sichtbar; gültige trockene Nullwerte bleiben erhalten.
- Eine leere Ensemble-Zeitachse wird vor der Verarbeitung abgewiesen.

# MID v0.9.85.221

- RUC-Aktualität wird getrennt als Laufalter und Rückstand zum gemeinsam angekündigten DWD-Lauf protokolliert.
- Unbekannte Angaben bleiben ausdrücklich unbekannt; auffällige Zeitstempel werden nicht zu Null geschönt.
- Der erfolgreiche Cloudflare-Watchdog-Dispatch ist mit zwei echten GitHub-Laufnachweisen dokumentiert.

# MID v0.9.85.220

- Abgebrochene RUC-Snapshot-Downloads werden direkt mit begrenztem Backoff wiederholt.
- Nur vollständig geladene und per Größe/SHA geprüfte Dateien werden übernommen.
- Bei dauerhaftem Fehler bleibt der vorhandene Snapshot erhalten; Teilbytes werden nicht veröffentlicht.

# MID v0.9.85.219

- RUC-EPS-Mitglieder müssen an allen benötigten Vorhersageterminen vorhanden sein.
- Vollständig leere Termine einzelner Mitglieder stoppen den Lauf vor der Aggregation.
- Maskierte Randzellen, trockene Nullwerte und die bisherigen Ensemble-Schwellen bleiben erhalten.

# MID v0.9.85.218

- RUC-Daten werden vor Veröffentlichung zusätzlich auf vollständig leere Vorhersagetermine geprüft.
- Alle stündlichen Kernfelder müssen dieselben Zeit- und Gitterdimensionen besitzen.
- Gültige maskierte Randzellen und trockene Nullwerte bleiben erhalten; fehlerhafte Läufe werden nicht veröffentlicht.

# MID v0.9.85.217

- Kartenwerte bleiben zum Lesen geöffnet, bis sie bewusst geschlossen werden oder sich der Kartenkontext ändert.
- Die gemeinsame Wertanzeige erhält Dialogsemantik und Tastaturführung mit Escape und Rückkehr zum Auslöser.
- Wetterwerte, Einheiten, Quellen und Kartenfarben bleiben unverändert.

# MID v0.9.85.216

- Widget-Exporte warten auf tatsächlich geladene Schriften, Bilder und sichtbares Layout.
- Automatische Renderläufe bewahren den ersten Fehler mit Screenshot, Build-Bezug und begrenzter Netzwerkdiagnostik auch bei erfolgreichem Retry.
- Fehlerartefakte bleiben getrennt vom öffentlichen Widget-Paket; bestehende Daten- und Release-Gates bleiben erhalten.

# MID v0.9.85.215

- Gleiche Skybar-Zustände erscheinen als durchgehendes Band, auch in der kompakten 7-Tage-Ansicht. Die künstlichen Stundennähte entfallen.
- Die gemeinsame Darstellung gilt auch für Kurzfristansichten, Tageskarten und Widgets. Unterschiedliche Wetterzustände und einzelne Stundeninformationen bleiben erkennbar.

# MID v0.9.85.214

Die Wetterkarte erhält zusätzliche automatische Langzeitprüfungen: wiederholte Modellwechsel werden auf stabile Kartendarstellung und Speicherentwicklung untersucht. Das erleichtert gezielte Verbesserungen bei Geschwindigkeit und Zuverlässigkeit. Alle bisherigen Wetterfunktionen und die Korrektur fehlender RUC-Gitterwerte bleiben erhalten.

# MID v0.9.85.213

Die DWD-RUC-Kurzfristdaten werden bei der Aufbereitung jetzt zuverlässiger behandelt. Bereiche ohne gültige Modellwerte sind klar als fehlende Daten gekennzeichnet; falsche Extremtemperaturen entstehen dadurch nicht mehr. Die strengen Prüfungen meteorologischer Werte bleiben bestehen. Verfügbare Radar-, Kurzfrist- und Ensemblefunktionen sowie die Bedienoberfläche werden nicht verändert.

# MID v0.9.85.212

**Karten im Dark Mode:** Die Terminwahl für Radar und Karten passt ihre Schaltflächen und das Auswahlmenü jetzt korrekt an helle und dunkle Designs an. Auch auf schmalen Smartphones bleiben die Bedienelemente besser lesbar und erreichbar. Tastaturfokus und deaktivierte Zustände sind klarer erkennbar.

**Datenqualität:** Im Hintergrund werden unerwartete DWD-RUC-Temperaturwerte präziser diagnostiziert. Ungültige Wetterdaten werden weiterhin nicht veröffentlicht.

# MID v0.9.85.211

Niederschlagsarten sind eindeutiger: Gefrierender Regen und Schneeregen haben jetzt unterscheidbare Symbole. Bei nicht durch kalte Oberflächen bestätigtem gefrierendem Regen wird ein Modellhinweis vorsichtiger formuliert, während bestätigtes Glätterisiko sichtbar bleibt. Der Kurzfristtext orientiert den Niederschlagsbeginn an der dargestellten Stunden-/15-Minuten-Zeitachse. Die 90-Minuten-Kacheln zeigen keine redundanten Wolkenprozente mehr; die Skybar bleibt unverändert.

# MID v0.9.85.210

MID misst jetzt bei automatisierten Karten-Browsertests zusätzlich die tatsächliche Ladebereitschaft, den Bildaufbau und längere Berechnungsphasen. Die Messwerte werden für verschiedene Displaygrößen, helle und dunkle Ansichten sowie die beiden Designs dokumentiert. Sie dienen zunächst als Vergleichsbasis; Wetterprognosen, Kartenfunktionen und die Bedienoberfläche ändern sich nicht.

# MID v0.9.85.209

Die Prüfung der DWD-RUC-Wetterdaten wurde weiter verschärft: MID kontrolliert jetzt auch, ob GRIB2-Felder tatsächlich vom erwarteten DWD-Erzeugungszentrum stammen und die richtige Modellinitialisierung besitzen. Verwechslungen verschiedener Wetterparameter, Höhenniveaus oder Gitter innerhalb eines Modelllaufs sowie doppelte Prognosewerte werden vor der Veröffentlichung erkannt. Vorhandene Wetterfunktionen und die Bedienoberfläche bleiben unverändert.

# MID v0.9.85.208

Die Verarbeitung der DWD-RUC-Wetterdaten erhält zusätzliche fachliche Sicherheitsprüfungen: Unpassende Modellläufe, doppelte Zeitstempel, deutlich zurückspringende Niederschlagsakkumulationen und physikalisch widersprüchliche Feuchte-, Wolken- oder Taupunktwerte werden vor der Datenveröffentlichung erkannt. Kleine Rundungsabweichungen bleiben zulässig. Die Wetteransichten und die Bedienung ändern sich nicht.

# MID v0.9.85.207

Der technische Prüfpfad wurde erweitert: MID kann nun für jeden neu erzeugten Web-Build seine Versionsnummer und einen Fingerabdruck der tatsächlich ausgelieferten Dateien nachvollziehen. Die Wetterfunktionen, Karten, Prognosen und Bedienoberfläche bleiben unverändert.

# MID v0.9.85.206

Die 90-Minuten-Kacheln zeigen zusätzlich den Bewölkungswert ihres jeweiligen Zeitschritts. Die Skybar erklärt ihre Schwellen und die breite Nacht-Hinterlegung. Vorhandene Werte unter den Bandschwellen bleiben als solche erkennbar und werden nicht als fehlende Daten bezeichnet.

Fehlende Bewölkungswerte werden in gemeinsamen Wetterzeichen, Periodenmitteln, Wolkenschichten und Kurzfrist-Fallbacks nicht mehr als 0 % ausgewertet. In den 3-Stunden-Details folgen trockene Wetterbeschreibung und Wetterzeichen nun demselben Bewölkungsmittelwert. Das 24-h-Profil besitzt einen korrigierten Erklärungstext und kompakter angeordnete Hinweise auf breiten Bildschirmen. Echte Nullwerte, Bandfarben und meteorologische Schwellen bleiben erhalten.

# MID v0.9.85.205

Die Kartennavigation reicht jetzt bis zum letzten tatsächlich veröffentlichten Modelltermin. Eine bisherige feste 204-Stunden-Grenze konnte die neuen IFS- und GFS-Endpunkte im Dropdown abschneiden. Ausschließlich verifizierte vorhandene Termine werden angeboten; Beobachtungs- und Nowcastregeln bleiben erhalten.

# MID v0.9.85.204 · Bewölkung und längere Synoptik

Das 24-Stunden-Profil verwendet für Bewölkungswerte, Wetterzeichen und Skybar denselben Stundenstand. Die 90-Minuten-Ansicht behält ihre feinere Auflösung. Nachtfelder nennen den tatsächlichen Bewölkungswert und werden bei unbekannten Daten nicht als klare Nacht ausgegeben.

Die Synoptik prüft zusätzlich ICON Global sowie modellabhängige längere Horizonte: ICON-EU bis +120 h, ICON Global laufabhängig bis +120/+180 h, IFS bis +360 h und GFS bis +384 h. Angeboten werden ausschließlich vollständige Termine desselben Laufs, soweit Daten und das unveränderte Speicherbudget verfügbar sind. Spätere Termine nutzen ein gröberes, gekennzeichnetes Übersichtsraster. Navigation und Terminauswahl zeigen den zweibuchstabigen Wochentag.

# MID v0.9.85.203 · Synoptik-Katalog ohne Terminverlust aktualisieren

Beim Neuladen bleibt der letzte geprüfte und noch gültige Synoptikkatalog sichtbar. Modellwahl, Kartenzeitachse und manuell gewählte Gültigkeitszeit bleiben während einer verzögerten Antwort erhalten. Das angebotene Zeitfenster hängt vom bestätigten Modellkatalog ab, auch wenn der bisherige Termin außerhalb eines neu gewählten Modells liegt.

Die Kartenprüfung kontrolliert feste Gültigkeitszeiten statt veränderlicher Listenpositionen und hält die Katalogantwort gezielt zurück. Die Synoptikdarstellung, erweiterten Modelltermine und RUC-Recovery aus .202 bleiben erhalten.

# MID v0.9.85.202 · Synoptik-Komposit und Kartenzeitsteuerung

Theta-E 850 hPa erhält dezente graue Konturen; die Linienbeschriftung erscheint nur bei Vielfachen von 12 °C. Die blauen Feuchtelinien in 700 hPa bleiben ohne Linienbeschriftung.

Die fokussierte Wetterkarte wechselt mit den Pfeiltasten links/rechts zum vorherigen/nächsten bestätigten Termin. Eingabefelder und Regler behalten ihre eigene Bedienung.

Für ICON-EU, GFS und IFS werden zusätzlich +60 und +72 Stunden angeboten, soweit vollständige Felder aus demselben Lauf verfügbar sind und das bestehende Datenbudget ausreicht. ICON-D2 bleibt auf seinen regionalen Ausschnitt und 48 Stunden begrenzt. Der große Europa-Ausschnitt und die 6-Grad-Farbstufen aus .200 bleiben erhalten.

# MID v0.9.85.201

RUC-Kurzfristdaten werden nach erfolgreichen MID-Veröffentlichungen automatisch auf Aktualität geprüft und bei Bedarf nachgeholt. Ein erfolgreicher Verarbeitungslauf ohne tatsächlich veröffentlichte Daten unterdrückt die Wiederaufnahme nicht mehr.

RUC-Übergabeartefakte erhalten pro Ausführungsversuch eindeutige Namen. Der bestehende Vier-Stunden-Frischevertrag, Datenbudgets sowie Release- und Sicherheitsprüfungen bleiben erhalten.

Basis: main = mid-stable c3f3abebfd5e3da86013063d7b051b05399e3876 (v0.9.85.200). Details: docs/implementation/MID_C22_RUC_RECOVERY_0.9.85.201.md.

# MID v0.9.85.200

- Synoptik/Theta-E: Europaausschnitt bis zur ICON-EU-Abdeckung (29,5–70,5° N, 23,5° W–62,5° O); ICON-EU als klar benannte 0,125°-Übersicht. ICON-D2 bleibt auf seinem tatsächlichen Regionalgebiet.
- Wind 300 hPa ab 60 kt, Stärke über Pfeillänge und -dicke; räumlich lesbare Pfeildichte.
- Theta-E mit 6-Grad-Farbstufen und dezenten Konturen, Beschriftung alle 12 °C. Feuchte 700 hPa: 60 % blau gestrichelt, 80 % blau durchgezogen.
- Bis zu 13 statt neun vollständige Synoptik-Termine bis +48 h. Zusätzliche Termine bleiben vom unveränderten freien Datenbudget abhängig.
- Bildwechsel: vorheriges Bild bis zum geladenen Nachfolger erhalten und 350 ms überblenden. Gemeinsamer Bild-/Canvas-Renderer, native Modelle, WMS, OPERA und 250-m-Radar; gültige Zeit bleibt während des Abrufs erkennbar.
- Prüfungen: echte GRIB-Dekodierung, meteorologische Referenzen, Budgetgrenzen und langsame/fehlerhafte Bildwechsel in der vollständigen Karten-Browsermatrix.

# MID v0.9.85.199

Die 7-Tage-Kurven-Widgets verzichten auf die beiden bisherigen Unterüberschriften „7-Tage-Kurvenübersicht“ und „Wetterstreifen, Temperaturtrend & Niederschlag“. So beginnt die Grafik ohne unnötigen Zwischenraum direkt unter den Ortsangaben.

Die normale 7-Tage-Prognose, die Wetterwerte, Kurven, Piktogramme und der Wetterstreifen bleiben unverändert.

Basis: main = mid-stable 36110a193328b0e4a5978e742e3768a8fcd9664f (v0.9.85.198). Details: docs/implementation/MID_C21_CURVE_WIDGET_COMPACT_0.9.85.199.md.

# MID v0.9.85.198

MID-C21: sichtbare Küsten und Ländergrenzen über den Wetterflächen; direkte Kartenzeitwahl mit Vor/Zurück, Terminliste und Aktuell. Synoptik zeigt fehlende Kataloge und Ladefehler mit erneutem Abruf.

RUC-Veröffentlichung bindet den vorbereiteten Snapshot an seine Artefakt-ID. Pages-Artefakte sind je Ausführungsversuch eindeutig. Alte Scheduler-Einträge ohne Jobs blockieren die Wiederaufnahme erst nach überprüfter Jobs-Abfrage nicht mehr; laufende Jobs und Schutzgates bleiben erhalten.

Basis: verifiziertes main = mid-stable b27bd472e228c59a9cc36e7305307b775623288a (.197). Details: docs/implementation/MID_C21_MAP_RUC_0.9.85.198.md.

# MID v0.9.85.197

- Aktuelles Wetter: vier einheitliche Parameterfelder mit passenden Symbolen und lesbarer Typografie. Die Skybar liegt oberhalb des 12-Stunden-Temperaturgraphen mit gemeinsamer Zeitachse.
- Kartendetails lassen sich einzeln auswählen: Ländergrenzen, Regionen, Städte, Flüsse und Straßen. Eine gemeinsame OSM-Geometrie ersetzt doppelte und schematische Grenzen.
- Höhenlinien 500 hPa werden aus dem vollständigen Modellraster als zusammenhängende Konturen berechnet. Die alte gestufte Darstellung entfällt.
- Das Synoptik-Komposit kombiniert Theta-E 850 hPa, Höhenlinien 500 hPa, Bodendruck, Feuchte 700 hPa und Wind 300 hPa aus demselben Modelllauf und Termin. ICON-D2, ICON-EU, GFS und IFS werden nur mit vollständigen, geprüften Rohdaten angeboten.
- Bei App-Rückkehr bleibt die gewählte Inhaltsansicht erhalten. Das temporäre Mehr-Menü startet geschlossen und schließt beim Wechsel in den Hintergrund.

# MID v0.9.85.196

- Die vollständige Replit-Übergabeprüfung erhält ausreichend Zeit für alle bestehenden Browser- und Regressionstests.
- Die geplante MID-C21-Wetterkartenanpassung wird erst nach erneut erfolgreicher Übergabeprüfung freigegeben.

# MID v0.9.85.195

- Karten: dezente Verwaltungsgrenzen statt heller Doppelkonturen; Parameter in sechs fachlichen Kategorien.
- Neues Synoptik-Komposit: Temperatur 850 hPa, Höhenlinien 500 hPa und MSL-Isobaren ausschließlich aus demselben ICON-Lauf und Termin.
- ECCC GDPS Global ergänzt Gesamtbewölkung über freie GeoMet-Karten mit eigenem Lauf und Termin, glatter Originaldarstellung und erhaltener Herkunft.
- ICON-EU ergänzt die 2-m-Temperatur; verifizierte 12-h-Niederschlagskarten aus ICON-EU und ICON Global. Druckflächenabhängige Farbskalen werden passend gewählt.

- Warnungs-Timeline: vollbreite Ereigniskarten und ein gemeinsamer Tageszeitstrahl mit Wochentag, Datum und Ereigniszahl in allen Ansichten und beiden Designs.
- Die Jetzt-Markierung zeigt Datum und Uhrzeit in Ortszeit. Tagesgruppierung berücksichtigt Zeitzonen; Ereignisse über Mitternacht behalten ihren vollständigen Zeitraum.
- Die horizontale Layout-Kollision und der große Leerraum links entfallen. Amtliche Warnstufen und MID-Quellen bleiben unverändert getrennt.

# MID v0.9.85.194

- Inhaltlich gleiche, überlappende MID-Windhinweise werden nach der probabilistischen Fensterbildung als ein zusammenhängendes Ereignis dargestellt. Unsicherheit und längerer Prognosehorizont bleiben kenntlich.
- Unterschiedliche Warnstufen, Windrichtungen, konvektive Risiken und getrennte Ereignisse bleiben erhalten. Amtliche Warnungen und Niederschlagssummen werden nicht zusammengeführt.

# MID v0.9.85.193

- Der Installer prüft Core und Heavy-Regressionen parallel auf getrennten Runnern, ohne Tests auszulassen.
- Alle 24 Karten-Browserfälle werden verlustfrei auf drei isolierte Gruppen verteilt.
- Event-SHA, Manifest-, Archiv- und Datei-Hashes binden sämtliche Jobs an dasselbe validierte Release-Paket. Commit und Deployment bleiben bis zum Erfolg aller Prüfungen gesperrt.
- Laufzeitberichte je Test und Kartenfall machen Verzögerungen messbar. Keine Testergebnisse werden zwischen Releases wiederverwendet; sämtliche bestehenden Deployment-/Stable-Gates bleiben erhalten.

# MID v0.9.85.194

- Inhaltlich gleiche, überlappende MID-Windhinweise werden nach der probabilistischen Fensterbildung als ein zusammenhängendes Ereignis dargestellt. Unsicherheit und längerer Prognosehorizont bleiben kenntlich.
- Unterschiedliche Warnstufen, Windrichtungen, konvektive Risiken und getrennte Ereignisse bleiben erhalten. Amtliche Warnungen und Niederschlagssummen werden nicht zusammengeführt.

# MID v0.9.85.193

- Der Installer prüft Core und Heavy-Regressionen parallel auf getrennten Runnern, ohne Tests auszulassen.
- Alle 24 Karten-Browserfälle werden verlustfrei auf drei isolierte Gruppen verteilt.
- Event-SHA, Manifest-, Archiv- und Datei-Hashes binden sämtliche Jobs an dasselbe validierte Release-Paket. Commit und Deployment bleiben bis zum Erfolg aller Prüfungen gesperrt.
- Laufzeitberichte je Test und Kartenfall machen Verzögerungen messbar. Keine Testergebnisse werden zwischen Releases wiederverwendet; sämtliche bestehenden Deployment-/Stable-Gates bleiben erhalten.

# MID v0.9.85.193

- Der Installer prüft Core und Heavy-Regressionen parallel auf getrennten Runnern, ohne Tests auszulassen.
- Alle 24 Karten-Browserfälle werden verlustfrei auf drei isolierte Gruppen verteilt.
- Event-SHA, Manifest-, Archiv- und Datei-Hashes binden sämtliche Jobs an dasselbe validierte Release-Paket. Commit und Deployment bleiben bis zum Erfolg aller Prüfungen gesperrt.
- Laufzeitberichte je Test und Kartenfall machen Verzögerungen messbar. Keine Testergebnisse werden zwischen Releases wiederverwendet; sämtliche bestehenden Deployment-/Stable-Gates bleiben erhalten.

# MID v0.9.85.192

- Kurven-Widgets zeigen denselben Ortskopf wie Tageskarten: Ortsname, Koordinaten, Höhe und Ortszeit.
- Ein gemeinsamer Kopf innerhalb der Exportfläche hält Vorschau, URL-Widget, PNG und Zwischenablage konsistent; Ensemble bleibt unverändert.
- Zusätzliche Render- und Browserprüfungen sichern beide Profile, alle drei festen Orte und beide Themes. Release- und Sicherheitsgates bleiben unverändert.

# MID v0.9.85.191

- Warnungscenter: Amtliche Warntexte und MID-Hinweise sind beim Öffnen sofort sichtbar und bleiben einzeln einklappbar. Beim erneuten Öffnen werden beide Gruppen wieder aufgeklappt.
- Der Hinweisstatus unterscheidet aktuelle und anstehende Prognosehinweise; die Zahl anstehender Hinweise bleibt auch mobil im Status sichtbar.
- Auf Smartphones bleiben Timeline-Karten über die volle Breite lesbar. Die Ereignis-Timeline benennt amtliche Warnungen und MID-Hinweise gemeinsam, ohne ihre Herkunft oder Warnstufen zu vermischen.
- Die Bundle-Prüfung vermeidet unnötige Kompressionsberechnungen. Alle Regressions-, Budget-, Sicherheits- und Releaseprüfungen bleiben vollständig erhalten.

- Kurvenwidget: Der Erklärungstext oben rechts entfällt. Wind und Böen stehen mit klar getrennten Textzeilen ohne Überdeckung.

# MID v0.9.85.190

- Die Veröffentlichung erhält ausreichend Zeit für die vollständige Prüfung. Ein Zeitabbruch nach bereits bestandenen Tests blockiert dadurch nicht mehr die Freigabe und nachfolgende RUC-Aktualisierungen.
- Enthält die jüngsten Favoritenkorrekturen, Tmin und beide Unsicherheitsbereiche im 14-Tage-Diagramm sowie kompaktere Phasenfelder.
- Die Saisonvorhersage öffnet und lädt ausschließlich nach ausdrücklicher Auswahl, unabhängig von der 46-Tage-Ansicht.
- Alle Sicherheits-, Wetterdaten- und Veröffentlichungsgates bleiben verbindlich.

# MID v0.9.85.189

- 14 Tage: Tmax und Tmin mit echten P10–P90- und P25–P75-Ensembleintervallen, kompakter Phasenübersicht und vollständigen Intervall-Details.
- 46 Tage und Saison öffnen und laden unabhängig. Saisonmodelle werden erst bei ausdrücklicher Auswahl abgerufen; beim Wechsel zurück werden laufende Abrufe abgebrochen.
- Ortswechsel bleiben auch bei einem vollen oder gesperrten Browserspeicher bedienbar. Der vorhandene dauerhafte Speicher-Fallback wird direkt genutzt.
- Die Favoritenleiste unterdrückt nur das doppelte Folgeereignis desselben Touch-Taps; neue Maus-/Touch-Gesten und Tastaturaktivierungen bleiben erreichbar.
- Horizontales Wischen löst keinen Ortswechsel aus. Ein Fehler kann keine dauerhafte Klicksperre mehr hinterlassen.

# MID v0.9.85.188

- Die serverseitigen MID-Widgetbilder werden automatisch nur noch viermal täglich aktualisiert statt stündlich und zusätzlich nach Releases.
- Die vier automatischen Läufe liegen gleichmäßig sechs Stunden auseinander; die geprüften Widgetprofile und das rollierende Downloadpaket bleiben unverändert.
- Ein manueller Start bleibt für Diagnose- oder Notfallzwecke verfügbar.
- Wetterdaten, Prognoselogik und Darstellung in der MID-App bleiben unverändert.

# MID v0.9.85.187

- Karten: kompakte Ortswert-Tabelle auch für DWD-WMS-Layer, gebunden an ausgewählten Lauf, Termin, Parameter und Höhe.
- Layer-Schalter, Icons und Ortsbuttons verwenden in allen Designs konsistente Light-/Dark-Farben und umbrechende Rasterlayouts.
- Gefrierender Regen und Schneeregen bleiben getrennte WMO-Phasen. Warme, feuchte Fehlprognosen werden geprüft; kalte Oberflächen, native Feuchttemperatur und Beobachtungen bleiben geschützt.
- Extremwetter leitet Eisregen nicht mehr aus Gesamtniederschlag und Kälte allein ab. Explizite gefrierende Phase erforderlich; Schneewasser wird ausgeschlossen. Routen unterscheiden Schneeregen von gefrierendem Regen.

# MID v0.9.85.186 · 06.10.2026 · Karten-Layer

- Radar und Satellit bevorzugen Modelllinien; Flächen bleiben ausdrücklich optional auswählbar.
- Isobaren werden unabhängig von einem Flächenraster gezeichnet. DWD-Linien und Windfiedern verwenden die tatsächlich angebotenen Katalogstile.
- Kartenebenen mit klareren aktiven Zuständen, gut erreichbaren Schaltern und vollständigen Quell- und Terminangaben.
- Mobile Layer-Auswahl ohne Überlappung, Radar und Satellit komplett abwählbar; einzelne Ortsbeschriftung und kompakte Favoriten bei reiner Ortsauswahl.

# MID v0.9.85.185

- Das Same-Origin-DNS-Gate verwendet jetzt ausschließlich das separate Repository Secret `CLOUDFLARE_DNS_API_TOKEN` für den bestehenden `www.midwx.app`-CNAME.
- Worker-Upload, Worker-Promotion und die Same-Origin-Workers-Route verwenden weiterhin den bestehenden `CLOUDFLARE_API_TOKEN`; DNS- und Worker-Rechte bleiben damit strikt getrennt.
- Fehlt der separate DNS-Token oder besitzt er nicht die erforderliche zonenbegrenzte Berechtigung, stoppt der Release weiterhin vor Pages und Stable-Promotion. Es gibt keinen breiter berechtigten Fallback.
- Meteorologische Datenlogik und Darstellung bleiben unverändert.

# MID v0.9.85.184

- Der bestehende Webhost `www.midwx.app` wird im Release-Gate jetzt kontrolliert über Cloudflare proxied, damit der Same-Origin-Datenpfad `/api/mid-worker` tatsächlich erreichbar ist.
- Dabei bleibt der vorhandene DNS-Zielwert unverändert; MID legt keinen neuen DNS-Record an und verändert weder TLS noch andere DNS-Einträge oder Worker-Routen.
- Warnungen, ICON-D2-RUC, Radar, Satellit und die moderne Kartenbasis können damit auch in restriktiven Unternehmensnetzen über dieselbe bereits erreichbare MID-Domain geladen werden.
- Fehlen die eng begrenzten Cloudflare-DNS-Rechte oder ist der bestehende `www`-Record nicht eindeutig, stoppt die Veröffentlichung weiterhin fail-closed.

# MID v0.9.85.183

- Warnungen, ICON-D2-RUC sowie Radar- und Satellitendaten laufen im produktiven Web jetzt über denselben MID-Host statt über vom Browser direkt angesprochene Wetterdaten-Domains.
- Die moderne Kartenbasis wird in restriktiven Netzen ebenfalls über MID bereitgestellt; externe Direktpfade bleiben nur außerhalb des produktiven Webs als Plattform-/Entwicklungsfallback erhalten.
- Unter „Daten & Qualität“ zeigt eine neue Verbindungsdiagnose getrennt, ob Datendienst, Warnungen, RUC und Kartenquellen erreichbar sind.
- Die Veröffentlichung stoppt automatisch, wenn die geschützte Same-Origin-Route nicht eindeutig auf den geprüften MID-Worker zeigt oder der Health-Check dort fehlschlägt.


# MID v0.9.85.182

- Die automatische Widget-Erzeugung wiederholt einzelne fehlgeschlagene Renderings jetzt kontrolliert, statt den gesamten 12er-Satz wegen eines einmaligen Daten-Timeouts sofort abzubrechen.
- Pro Widget sind höchstens drei Render-Versuche mit erweitertem Daten-/Render-Zeitfenster zulässig; nach dem dritten Fehlschlag bleibt der Export weiterhin fail-closed.
- Widget-Inhalte, Standorte, Profile und die SharePoint-Übergabe bleiben unverändert.

# MID v0.9.85.181

- Die automatische Erzeugung der zwölf festen MID-Widget-PNGs läuft jetzt plattformübergreifend auch auf den Linux-GitHub-Runnern.
- Der Export prüft vor dem Rendern explizit auf Chrome/Chromium und bricht bei fehlendem Browser sofort mit einer klaren Fehlermeldung ab.
- Windows-/macOS-Fallbacks für Edge, Chrome und Chromium bleiben erhalten; die Widgetinhalte selbst wurden nicht verändert.

# MID v0.9.85.180

- Profilkopf kompakt: redundante Drucktrend-Karte entfernt, relevante Hinweise vollbreit und umbrechend. RUC zeigt Kandidat und tatsächlich aufbereiteten Lauf mit Datum/HHMMZ im Log und der Ergebnisübersicht.

- Stark-/Dauerregenhinweise markieren die tatsächlich nasse Phase statt trockener Vor- und Nachlaufstunden rollierender Summenfenster.
- Regenhinweise nennen die Standort-Modellsumme und DWD-Schwellen; unbelegte Ensemble-Bestätigung und erfundene Wahrscheinlichkeitsbereiche entfallen.
- Zeitlücken und Mehrstundenwerte dürfen keine Stunden-Warnschwellen vortäuschen. Amtliche Warnungen und Extremwettervorschau behalten ihre eigenen Quellen und Kriterien.

# MID v0.9.85.179

- Der automatische Widget-Export startet jetzt zusätzlich direkt bei jeder erfolgreichen Promotion auf `mid-stable`.
- Dadurch werden die zwölf festen PNGs unmittelbar nach einem neuen Stable-Build neu erzeugt; Stundenplan, Release-Folge und manueller Start bleiben als Redundanz erhalten.
- Keine meteorologische Fachlogik und keine Widgetdarstellung wurden verändert.

# MID v0.9.85.178

- MID erzeugt die zwölf festen Widgets für Malatya, Kürecik und Ämari jetzt automatisch serverseitig.
- Die Widget-PNGs werden nach erfolgreichen MID-Releases und zusätzlich stündlich aus dem verifizierten Stable-Stand neu gerendert.
- Ein festes, rollierendes ZIP stellt immer den zuletzt vollständig geprüften Bildsatz mit Manifest und SHA-256-Prüfsummen bereit.
- Für Windows steht ein Downloader ohne Administratorrechte, OneDrive oder lokale Node-Installation bereit.

# MID v0.9.85.177

- Bergwetter: Die Höhenwahl allein verändert keine geografische Modellzelle mehr; Nullgrad- und Schneefallgrenzen bleiben für dieselbe atmosphärische Säule konsistent.
- Wolkenuntergrenze und lokale Kondensationshöhe werden fachlich getrennt; tiefer liegende Wolkenschichten bleiben auch bei gewählter Bergstation erhalten.
- Räumliche Unterschiede und mehrere Wolkenschichten bleiben erhalten. Fehlende Grenzhöhen und Koordinaten werden nicht zu künstlichen Nullwerten.

# MID v0.9.85.176

- Bergwetter: getrennte Tagesmaxima für Wind und Böen; fehlende Werte bleiben unbekannt.
- Dezente Wind- und Neuschneefarben in Tages-, Stunden- und Periodenansichten.
- Gleichmäßige Tablet-Spalten für Sonnenstunden; vollständige Wettertexte.
- Gemeinsame Prüfung klar warmer Gefrierregen-Prognosen mit Feuchte; kalte Böden, Beobachtungen und Grenzlagen bleiben geschützt.
- Neuschnee-Methodik transparent: Modell-Schneewasser und feste Anbieterumrechnung, getrennt von der Schneedecke.

# MID v0.9.85.175

Die festen MID-Widget-Exporte sind auf Malatya, Kürecik und Ämari (59,26°N, 24,20°E) ausgerichtet. Pro Ort werden 7 Tage Kurve mit Wind, Niederschlag, Sonne und ECMWF-Temperaturfarben sowie 5 Tage Kompakt mit Wind und ECMWF-Temperaturfarben erzeugt – jeweils in Hell und Dunkel. Die Exportautomatik erzeugt damit exakt zwölf aktuelle PNGs.

# MID v0.9.85.174

Nebel-/Dunsttexte bleiben mit den Wetterpiktogrammen konsistent. Bergwetter verwendet vorhandene Modell-Schneefallgrenzen vor der vereinfachten Höhenableitung. Temperatur und Taupunkt erreichen die bestehende Kurzfrist-Phasenprüfung.

# MID v0.9.85.173

- Wetterdaten-Veröffentlichung und Worker-Übernahme werden getrennt geprüft.
- App-Updates schützen vor einem zwischenzeitlich veralteten RUC-Datenstand.
- Automatische Wetterdatenläufe zeigen eindeutiger an, ob Daten aktuell, aufbereitet oder veröffentlicht wurden.

# MID v0.9.85.172

- Die Wetterdaten-Aufbereitung wiederholt vorübergehende DWD-Verbindungsfehler gezielt und verwirft unvollständige Modellläufe früher.
- Unterbrochene Downloads können keine unvollständigen Dateien als fertige Daten hinterlassen.
- Die bereits eingeführten Verbesserungen für Bergwetter, Widgets, Karten und schnellere Freigabeprüfungen bleiben erhalten.

# MID v0.9.85.171

- Veröffentlichungen werden weiter beschleunigt, ohne Regressionen wegzulassen: besonders zeitintensive Karten- und Bergdarstellungsprüfungen laufen im Quell-Gate nun voneinander isoliert parallel.
- Die vollständige Testabdeckung bleibt verbindlich. Der Freigabecheck wird nur grün, wenn der Kern und alle drei schweren Prüfläufe erfolgreich abgeschlossen sind.
- Produktfunktionen, Wetterlogik und Darstellung wurden mit diesem Build nicht verändert.

# MID v0.9.85.170

- Bergwetter und Widget-/PNG-Generator laden erst beim Öffnen der jeweiligen Ansicht.
- Gemeinsame Wetterdarstellung, Einstellungen und PNG-Ausgabe bleiben über alle Ansichten hinweg erhalten.
- Globale Styles werden aus einer geordneten Quelle konsolidiert geladen; redundante Deklarationen entfallen aus der Laufzeitausgabe.
- Startpaket und Stylesheet verkleinert, ohne Wetterparameter oder Bedienfunktionen zu entfernen.

# MID v0.9.85.169

- Häufige Kopfzeilen- und Favoritenaktionen auf kleinen Displays sind leichter zu treffen.
- Optionale Ansichtseinstellungen und Apple-Widget-Einstellungen laden erst beim Öffnen.
- Redundante Stilblöcke und eine ungenutzte temporäre iOS-Datei entfernt.
- Kompatible kleinere Updates für die iOS-Anbindung und den HDF5-Datenleser.

# MID v0.9.85.168

- Veröffentlichungen werden schneller, ohne Prüfungen auszulassen: sicher als read-only erkannte Regressionen können parallel laufen, risikobehaftete Prüfungen bleiben seriell.
- Unnötige vollständige Git-Historien werden im normalen Releasepfad vermieden; bei einem parallelen main-Update wird weiterhin automatisch auf die vollständige Race-Prüfung eskaliert.
- Das Pages-Paket wird bereits während der Worker-Prüfung vorbereitet, aber weiterhin erst nach erfolgreichem Worker-Gate veröffentlicht.
- Die Stable-Freigabe bleibt ein verifizierter Fast-Forward ohne Force-Update und prüft den finalen SHA weiterhin ausdrücklich.

# MID v0.9.85.167

- Eine gemeinsame Wetterkarte statt getrennter Radar-, Satelliten-, Synoptik- und Modellansichten.
- Ruhige Vektorkartenbasis mit Grenzen und Ortsnamen über den Wetterflächen; Radar, hochauflösender Satellit und Modellfelder unabhängig schaltbar.
- Direkte ICON-D2- und RADOLAN-Raster aus der Publikationsstrecke der Niederschlagssummen; weitere Modelle als bestätigte DWD-Feldkacheln statt statischer Übersichtsbilder.
- Parameter und Modelle filtern sich gegenseitig. Druckflächen, Niederschlagsfenster und Ensemble-Wahrscheinlichkeiten bleiben fachlich getrennt.
- Gemeinsame Produktzeitleiste, transparente Datenstände, lokale Rasterabfrage, Favoriten und PNG-/SVG-Rasterexport bleiben verfügbar.
- Abbrechbare Abrufe, begrenzter Feldcache und Vorladen des nächsten Termins; große Summenraster werden erst bei Bedarf geladen.
- Die neue Layerauswahl wird unmittelbar gespeichert. Die ECMWF-Farbwahlkorrektur der 7d-Vorhersage bleibt erhalten.

# MID v0.9.85.166

- Die ECMWF-Farbwahl der 7-Tage-Vorhersage wird unmittelbar gespeichert und bei Neustarts zuverlässig wiederhergestellt.
- Ältere Speicher- und Gerätestände überschreiben eine neuere Farbwahl nicht mehr.
- Die kompakten 14-/46-Tage- und Saisonansichten aus dem vorherigen Update bleiben unverändert erhalten.

# MID v0.9.85.165

## MID-C16 · kompakte Prognoseansichten
- 14-Tage-Entwicklung mit drei kurzen Phasen; fachliche Einordnung bleibt im Infohinweis verfügbar.
- Wochenvergleich für Tag 15–46 startet eingeklappt. Methodik, Modellläufe, Mitgliederzahlen und Quellen bleiben erreichbar.
- Alle Saisonmonate gleichzeitig sichtbar, ohne horizontales Scrollen; auf schmalen Displays zweizeilige Monats-/Jahreslabels.
- Witterungstrend mit konkreten Kalenderdaten an Achsen, Kopfzeile und Modellvergleich.
- Einheitliche Überschriften, Zusatztexte und Abstände für 14d, 46d und Saison; Mitgliedsanomalien bleiben in K/%.
- Responsive Gestaltung der Detailansichten in der gepflegten CSS-Quelle; keine Änderung der Prognosedaten oder Ensemblegewichtung.

# MID v0.9.85.164

- Die Skybar bleibt nach nachgeladenen RUC-/Modellkorrekturen mit der Viertelstundenprognose konsistent.
- Saison-Niederschlagsabweichungen erscheinen in Prozent zum zugehörigen Monatsmittel; Temperatur-Mitgliedskurven zeigen Abweichungen in K.
- Alle Monate bleiben auf den Zeitachsen sichtbar; kurze Monatslabels und bei Bedarf horizontales Scrollen erhalten die Lesbarkeit.
- Saisoninstrumente verwenden lesbare Monatslabels und passende Einheiten; Modellvergleiche behalten auch Quellen ohne Prozentreferenz.
- Die gespeicherte ECMWF-Farbwahl bleibt bei einem Neustart erhalten.

# MID v0.9.85.163

- Skybar und Wetter übernehmen lokale Bewölkungskorrekturen auch in der Viertelstundenreihe. Alte Modell-Sonnenscheinwerte werden bei deutlich geändertem Himmel verworfen.
- 14d-, 46d- und Saisoninstrumente mit einheitlicher Gestaltung und runden Achsenwerten.
- Saisonmonate bleiben auf kleinen Displays lesbar; beide Rauchfahnen messen ihre eigene Diagrammbreite.

# MID v0.9.85.162

MID-C15: Eigenständige Horizonte. 14 Tage mit Entwicklungsabschnitten und Tages-Temperaturbandbreite statt wiederholtem 7d-Kalender; Entwicklung, Konfidenz und Ensemble-Grafiken bleiben erhalten, Tagesdetails aufklappbar. 46d standardmäßig mit Wochenabweichungen und Unsicherheit um Null; absolute Wochenwerte bleiben umschaltbar.

Saison: zusätzliche echte SEAS5-Einzelmitgliedskurven für vollständige Kalendermonate, reale P10–P90/P25–P75-Bänder. Alle numerisch geladenen unabhängigen Saisonmodelle zusätzlich als Linien in den Haupt-Anomaliegrafiken. Keine Rauchfahnenbehauptung aus bloßen Mittelwerten. Monatsniederschlag korrekt nach tatsächlicher Monatslänge in mm/Tag normalisiert; Cache aktualisiert. Modellstreuung, Roh-Mitglieder und Klimareferenz bleiben fachlich getrennt.

# MID v0.9.85.161

MID-C15: Nachtstunden der 7d-Kurve sind wieder deutlich sichtbar, auch im Widget und PNG. Gemeinsame opake Nachtfarbe mit einmaliger Deckkraft statt unbeabsichtigter doppelter Transparenz; astronomische Grenzen und sanfte Übergänge bleiben erhalten. Dieselbe Korrektur erreicht die übrigen SVG-Nachtflächen.

Der Wetterstreifen im 12h-Diagramm unter Aktuell verwendet die volle SVG-Höhe von 16 px, wie die 90-Minuten-Ansicht. Die vier Bedeckungsstufen werden nicht mehr vertikal gestaucht; gemeinsame Zeitachse, Niederschlagszustände und Quadrateinstellung bleiben erhalten.

# MID v0.9.85.160

MID-C15: ECMWF-Temperaturfarben sind in Einstellungen wieder optional für 7d-Tageswerte und die stündliche 7d-Kurve verfügbar; Standard bleibt die 24h-Parameterpalette. Widget und PNG verwenden denselben Renderer mit ihrem vorhandenen Farbschalter. Eindeutige Gradienten-IDs verhindern Wechselwirkungen zwischen gleichzeitig sichtbaren Diagrammen.

24h-Profil und aufgeklapptes 7d-Tagesdetail verwenden einen gemeinsamen Linienvertrag für Farbe, Stärke, Strichmuster, Deckkraft und Rundung aller sieben Parameter. Der ursprüngliche 24h-Goldton für UTCI ist auch im Tagesdetail wiederhergestellt. Coverage-Pilot installiert Vite, Vitest und Coverage gemeinsam in einem isolierten Verzeichnis, ohne MID-Lockfile oder Release-Gates zu verändern.

# MID v0.9.85.159

MID-C15: Widget-Kurvenübersicht mit echtem stündlichem Temperaturensemble P25–P75 wie in der App. Gemeinsame astronomische Nachtflächen einschließlich Skybar, gemeinsame Skybar-Einstellung auch im Widget und URL-Export. Abruf beim Öffnen der Kurvenansicht; URL-Export wartet auf den Ensembleabruf. Fehlende Mitglieder erzeugen kein künstliches Band.

90-Minuten-Skybar: dieselbe gerenderte Dicke der vier Bedeckungsstufen wie im 24h-Profil; Schwellen und Viertelstunden bleiben unverändert. Vitest-/Coverage-Pilot unter Node 22/npm 10 mit explizit gepinntem Vite-Peer reproduzierbar ausführbar.

# MID v0.9.85.158

MID-C15: 7d-Temperaturkurve, Tageswerte und Legende verwenden nun die sichtbaren Parameterfarben des 24h-Diagramms. Tmin blau, Tmax rot; keine abweichende wertabhängige Palette in der Tagesübersicht. Wind grün, Böen ohne Warnstufe oliv, Niederschlagssymbol und Wahrscheinlichkeit blau. Bestehende Warnfarben bleiben erhalten.

# MID v0.9.85.157

- Die aufgeklappte 7-Tage-Tagesansicht verwendet nun für UTCI dieselbe Parameterfarbe wie das 24-Stunden-Profil; Linie, Auswahlpunkt und Legende bleiben einheitlich in Hell, Dunkel und Kontrast.
- Der Coverage-Workflow führt die Unit-Tests nur noch einmal mit Coverage aus. Alle Release-Sicherungen und vorhandenen Regressionen bleiben erhalten.
- Code-, Workflow- und Regressionsaudit mit dokumentierten Folgearbeiten.

# MID v0.9.85.161

MID-C15: Nachtstunden der 7d-Kurve sind wieder deutlich sichtbar, auch im Widget und PNG. Gemeinsame opake Nachtfarbe mit einmaliger Deckkraft statt unbeabsichtigter doppelter Transparenz; astronomische Grenzen und sanfte Übergänge bleiben erhalten. Dieselbe Korrektur erreicht die übrigen SVG-Nachtflächen.

Der Wetterstreifen im 12h-Diagramm unter Aktuell verwendet die volle SVG-Höhe von 16 px, wie die 90-Minuten-Ansicht. Die vier Bedeckungsstufen werden nicht mehr vertikal gestaucht; gemeinsame Zeitachse, Niederschlagszustände und Quadrateinstellung bleiben erhalten.

# MID v0.9.85.160

MID-C15: ECMWF-Temperaturfarben sind in Einstellungen wieder optional für 7d-Tageswerte und die stündliche 7d-Kurve verfügbar; Standard bleibt die 24h-Parameterpalette. Widget und PNG verwenden denselben Renderer mit ihrem vorhandenen Farbschalter. Eindeutige Gradienten-IDs verhindern Wechselwirkungen zwischen gleichzeitig sichtbaren Diagrammen.

24h-Profil und aufgeklapptes 7d-Tagesdetail verwenden einen gemeinsamen Linienvertrag für Farbe, Stärke, Strichmuster, Deckkraft und Rundung aller sieben Parameter. Der ursprüngliche 24h-Goldton für UTCI ist auch im Tagesdetail wiederhergestellt. Coverage-Pilot installiert Vite, Vitest und Coverage gemeinsam in einem isolierten Verzeichnis, ohne MID-Lockfile oder Release-Gates zu verändern.

# MID v0.9.85.159

MID-C15: Widget-Kurvenübersicht mit echtem stündlichem Temperaturensemble P25–P75 wie in der App. Gemeinsame astronomische Nachtflächen einschließlich Skybar, gemeinsame Skybar-Einstellung auch im Widget und URL-Export. Abruf beim Öffnen der Kurvenansicht; URL-Export wartet auf den Ensembleabruf. Fehlende Mitglieder erzeugen kein künstliches Band.

90-Minuten-Skybar: dieselbe gerenderte Dicke der vier Bedeckungsstufen wie im 24h-Profil; Schwellen und Viertelstunden bleiben unverändert. Vitest-/Coverage-Pilot unter Node 22/npm 10 mit explizit gepinntem Vite-Peer reproduzierbar ausführbar.

# MID v0.9.85.158

MID-C15: 7d-Temperaturkurve, Tageswerte und Legende verwenden nun die sichtbaren Parameterfarben des 24h-Diagramms. Tmin blau, Tmax rot; keine abweichende wertabhängige Palette in der Tagesübersicht. Wind grün, Böen ohne Warnstufe oliv, Niederschlagssymbol und Wahrscheinlichkeit blau. Bestehende Warnfarben bleiben erhalten.

# MID v0.9.85.157

- Die aufgeklappte 7-Tage-Tagesansicht verwendet nun für UTCI dieselbe Parameterfarbe wie das 24-Stunden-Profil; Linie, Auswahlpunkt und Legende bleiben einheitlich in Hell, Dunkel und Kontrast.
- Der Coverage-Workflow führt die Unit-Tests nur noch einmal mit Coverage aus. Alle Release-Sicherungen und vorhandenen Regressionen bleiben erhalten.
- Code-, Workflow- und Regressionsaudit mit dokumentierten Folgearbeiten.

# MID v0.9.85.160

MID-C15: ECMWF-Temperaturfarben sind in Einstellungen wieder optional für 7d-Tageswerte und die stündliche 7d-Kurve verfügbar; Standard bleibt die 24h-Parameterpalette. Widget und PNG verwenden denselben Renderer mit ihrem vorhandenen Farbschalter. Eindeutige Gradienten-IDs verhindern Wechselwirkungen zwischen gleichzeitig sichtbaren Diagrammen.

24h-Profil und aufgeklapptes 7d-Tagesdetail verwenden einen gemeinsamen Linienvertrag für Farbe, Stärke, Strichmuster, Deckkraft und Rundung aller sieben Parameter. Coverage-Pilot installiert Vite, Vitest und Coverage gemeinsam in einem isolierten Verzeichnis, ohne MID-Lockfile oder Release-Gates zu verändern.

# MID v0.9.85.159

MID-C15: Widget-Kurvenübersicht mit echtem stündlichem Temperaturensemble P25–P75 wie in der App. Gemeinsame astronomische Nachtflächen einschließlich Skybar, gemeinsame Skybar-Einstellung auch im Widget und URL-Export. Abruf beim Öffnen der Kurvenansicht; URL-Export wartet auf den Ensembleabruf. Fehlende Mitglieder erzeugen kein künstliches Band.

90-Minuten-Skybar: dieselbe gerenderte Dicke der vier Bedeckungsstufen wie im 24h-Profil; Schwellen und Viertelstunden bleiben unverändert. Vitest-/Coverage-Pilot unter Node 22/npm 10 mit explizit gepinntem Vite-Peer reproduzierbar ausführbar.

# MID v0.9.85.158

MID-C15: 7d-Temperaturkurve, Tageswerte und Legende verwenden nun die sichtbaren Parameterfarben des 24h-Diagramms. Tmin blau, Tmax rot; keine abweichende wertabhängige Palette in der Tagesübersicht. Wind grün, Böen ohne Warnstufe oliv, Niederschlagssymbol und Wahrscheinlichkeit blau. Bestehende Warnfarben bleiben erhalten.

# MID v0.9.85.157

- Die aufgeklappte 7-Tage-Tagesansicht verwendet nun für UTCI dieselbe Parameterfarbe wie das 24-Stunden-Profil; Linie, Auswahlpunkt und Legende bleiben einheitlich in Hell, Dunkel und Kontrast.
- Der Coverage-Workflow führt die Unit-Tests nur noch einmal mit Coverage aus. Alle Release-Sicherungen und vorhandenen Regressionen bleiben erhalten.
- Code-, Workflow- und Regressionsaudit mit dokumentierten Folgearbeiten.

# MID v0.9.85.159

MID-C15: Widget-Kurvenübersicht mit echtem stündlichem Temperaturensemble P25–P75 wie in der App. Gemeinsame astronomische Nachtflächen einschließlich Skybar, gemeinsame Skybar-Einstellung auch im Widget und URL-Export. Abruf beim Öffnen der Kurvenansicht; URL-Export wartet auf den Ensembleabruf. Fehlende Mitglieder erzeugen kein künstliches Band.

90-Minuten-Skybar: dieselbe gerenderte Dicke der vier Bedeckungsstufen wie im 24h-Profil; Schwellen und Viertelstunden bleiben unverändert. Vitest-/Coverage-Pilot unter Node 22/npm 10 mit explizit gepinntem Vite-Peer reproduzierbar ausführbar.

# MID v0.9.85.158

MID-C15: 7d-Temperaturkurve, Tageswerte und Legende verwenden nun die sichtbaren Parameterfarben des 24h-Diagramms. Tmin blau, Tmax rot; keine abweichende wertabhängige Palette in der Tagesübersicht. Wind grün, Böen ohne Warnstufe oliv, Niederschlagssymbol und Wahrscheinlichkeit blau. Bestehende Warnfarben bleiben erhalten.

# MID v0.9.85.157

- Die aufgeklappte 7-Tage-Tagesansicht verwendet nun für UTCI dieselbe Parameterfarbe wie das 24-Stunden-Profil; Linie, Auswahlpunkt und Legende bleiben einheitlich in Hell, Dunkel und Kontrast.
- Der Coverage-Workflow führt die Unit-Tests nur noch einmal mit Coverage aus. Alle Release-Sicherungen und vorhandenen Regressionen bleiben erhalten.
- Code-, Workflow- und Regressionsaudit mit dokumentierten Folgearbeiten.

# MID v0.9.85.158

MID-C15: 7d-Temperaturkurve, Tageswerte und Legende verwenden nun die sichtbaren Parameterfarben des 24h-Diagramms. Tmin blau, Tmax rot; keine abweichende wertabhängige Palette in der Tagesübersicht.

# MID v0.9.85.157

- Die aufgeklappte 7-Tage-Tagesansicht verwendet nun für UTCI dieselbe Parameterfarbe wie das 24-Stunden-Profil; Linie, Auswahlpunkt und Legende bleiben einheitlich in Hell, Dunkel und Kontrast.
- Der Coverage-Workflow führt die Unit-Tests nur noch einmal mit Coverage aus. Alle Release-Sicherungen und vorhandenen Regressionen bleiben erhalten.
- Code-, Workflow- und Regressionsaudit mit dokumentierten Folgearbeiten.

# MID v0.9.85.157

- Die aufgeklappte 7-Tage-Tagesansicht verwendet nun für UTCI dieselbe Parameterfarbe wie das 24-Stunden-Profil; Linie, Auswahlpunkt und Legende bleiben einheitlich in Hell, Dunkel und Kontrast.
- Der Coverage-Workflow führt die Unit-Tests nur noch einmal mit Coverage aus. Alle Release-Sicherungen und vorhandenen Regressionen bleiben erhalten.
- Code-, Workflow- und Regressionsaudit mit dokumentierten Folgearbeiten.

# MID v0.9.85.156

- Vorhinweise bleiben auf Tag 3–7 begrenzt. Böen erhalten hinter dem kürzeren ICON-Horizont eine getrennte ECMWF-Ensembleergänzung, sofern ein vollständiges Tagesfenster verfügbar ist.
- Fertig berechnete regionale Ausblicke werden auch nach einem Neustart des Datendienstes wiederverwendet. Bei einem Ausfall bleibt ein höchstens 24 Stunden alter Stand ausdrücklich als veraltet gekennzeichnet.
- Die Fehlermeldung unterscheidet ein ausgeschöpftes Tageskontingent von einem nicht verfügbaren Ersatzabruf.
- Die 7-Tage-Diagramme übernehmen das Farbkonzept der 24-Stunden-Ansicht.

# MID v0.9.85.155

- Der Extremwetter-Ausblick „Vorhinweise · Tag 3–7“ wertet jetzt die tatsächlich verfügbaren ICON-EPS-Ensemblemitglieder aus. Leere Streuungsfelder blockieren den gesamten Ausblick nicht mehr.
- Regen und Schnee bleiben über vollständige Tagesfenster auswertbar. Böen werden ausschließlich für Zeiträume mit vollständigen Modelldaten bewertet; fehlende Böenwerte erscheinen ausdrücklich als Datenlücke.
- Die Änderungen aus den parallel veröffentlichten Versionen .153 und .154 bleiben erhalten.

# MID v0.9.85.154

- Der Extremwetter-Ausblick „Vorhinweise · Tag 3–7“ bleibt auch dann nutzbar, wenn der zentrale Wetterdatenweg vorübergehend sein Tageslimit erreicht: MID wechselt kontrolliert auf die gleiche ICON-EPS-Berechnung direkt im Browser.
- Der letzte vollständige Langfristausblick kann bei einer vorübergehenden Störung weiter angezeigt werden, statt eine Datenlücke wie Entwarnung wirken zu lassen.
- Die Langfristdaten werden deutlich länger zwischengespeichert. Das reduziert unnötige externe Abrufe, ohne Warnschwellen oder die meteorologische Bewertungslogik zu verändern.

# MID v0.9.85.153

- Der zusätzliche lange Erklärungstext auf der Warnungsseite wurde wieder entfernt; Warnstatus, amtliche Warnungen, MID-Hinweise und Ereignis-Timeline bleiben die primären Informationsebenen.
- Der neue Extremwetterbereich „Vorhinweise · Tag 3–7“ verwendet den Bereichsparameter wieder korrekt und bricht nicht mehr wegen eines undefinierten URL-Bezeichners ab.
- Technische JavaScript-/Worker-Fehler werden im Extremwetter-Ausblick nicht mehr als Rohtext angezeigt; bei einer echten Quellenstörung erscheint eine verständliche, neutrale Fehlermeldung mit erneutem Ladeversuch.

# MID v0.9.85.152

- Der Wetterstreifen im 24-h-Profil behält die Viertelstunden der Kurzfrist bei, damit wechselnde Bewölkung und Sonne zur 90-min-Ansicht passen.
- Fehlende Kurzfristwerte fallen auf die Stundenprognose zurück und werden nicht mehr als Nullwerte behandelt.
- Die optionalen Stundenquadrate behalten ihre stündliche Auflösung.

# MID v0.9.85.151

- MID-Prognosehinweise im Warnzentrum bis sieben Tage; ab 48 Stunden Vorhinweise, ab Tag 6 Gefahrenausblick.
- Extremwetter: zusätzliche Auswahl Tag 3–7 mit regionalem ICON-EPS-Potenzial für Regen, Sturm und Schnee.
- Amtliche Vorabinformationen bleiben kenntlich; fehlende Langfristdaten werden nicht als Entwarnung dargestellt.

# MID v0.9.85.150

- Die mobile Hauptnavigation erhält auf iPhone/iPad eine gesonderte Verankerung am sichtbaren unteren Bildschirmrand, damit sie nach Scroll- und Tastaturänderungen nicht in die Seitenmitte wandert.
- Safe-Area-Abstand, fünf Navigationstasten und die bisherige Tablet-/Desktop-Navigation bleiben erhalten.
- Browserprüfungen kontrollieren zusätzlich den tatsächlichen unteren Rand, Scroll-Rückkehr, Größenänderungen und veraltete iOS-Viewport-Offsets.

# MID v0.9.85.149

- Beide Karten-Farbskalen verwenden gut lesbare, nach außen gerundete Grenzen in der ausgewählten Einheit; Raster, Legende und Export bleiben deckungsgleich.
- Antippen einer direkten Modell- oder Niederschlagskarte zeigt den geprüften Rasterwert kurzzeitig an. Die Anzeige schließt automatisch, beim Bewegen der Karte, per Außenklick, Escape oder Schließen.
- Unterstützte DWD-WMS-Karten liefern geprüfte Ortswerte für den gewählten Termin, Modelllauf und die gewählte Höhe; nicht verfügbare Werte werden nicht geschätzt.
- Eine zusätzliche Mittelpunkt-Abfrage ermöglicht die Bedienung per Tastatur; Datenlücken bleiben ausdrücklich ohne Wert.
- Favoriten-Auswahl und Export-Rückmeldung sind in den Kartenansichten vereinheitlicht.

# MID v0.9.85.148

- Modellkarten verwenden die gewählte Windeinheit konsistent in Ortswerten, Farblegenden und PNG-/SVG-Exporten.
- Direkte DWD-Karten und Niederschlagssummen erhalten kontinuierliche Farbverläufe und eine an den tatsächlichen Wertebereich angepasste Kontrastdarstellung.
- Eine feste Vergleichsskala bleibt auswählbar und wird für Animationen verwendet; Wettercodes sowie fehlende und trockene Rasterpunkte behalten ihre eigene Bedeutung.
- Die parallel vorbereitete Navigation bleibt auch innerhalb transformierter Dashboard-Flächen fest am Viewport; Smartphone-, Tablet- und Desktop-Stile bleiben erhalten.

# MID v0.9.85.147

- Die mobile Bottom-Bar bleibt beim Scrollen stabil an ihrer Position und wechselt nicht mehr in einen scrollabhängigen Verschiebezustand.
- Die Modellkarten zeigen Modell, Produktfamilie, Quelle und Analyse-/Vorhersagestatus in einer klareren Kopfzeile.
- Ältere DWD-WMS-/Rasterkarten erhalten dieselbe ruhige, responsive Bedienhierarchie wie die neueren Niederschlags- und Direktkarten.

# MID v0.9.85.146

- „Untergang“ bleibt in der Sonne-/Mond-Kachel auch auf schmalen Displays vollständig in einer Zeile.
- Die Bergwetter-Stundentabelle passt ihre Breite an die tatsächlich verfügbaren Uhrzeitspalten an; große Leerflächen zwischen Feldnamen und erster Uhrzeit entfallen.
- Das Stundenraster bleibt bei tatsächlichem Überlauf horizontal scrollbar; ohne Überlauf wird kein künstlicher Leerraum erzeugt.

# MID v0.9.85.145

- Kleine Niederschlagsmengen wie <0,1 mm bleiben in den 7-/14-Tage-Ansichten vollständig lesbar.
- Dezente Spannengrenzen erscheinen ohne P25/P75-Kürzel vor den Zahlen; Einheiten und echte Ensemble-Mediane bleiben erhalten.
- 7 Tage verbindet Tmin/Tmax in einer kompakten gemeinsamen Temperaturdarstellung; 14 Tage betont langfristige Ensemble-Spannen und Trends.

# MID v0.9.85.144

- Die 7-Tage-Temperaturgrafik zeigt den P25–P75-Bereich auch über die ganze Woche, sobald tatsächliche stündliche Mitgliederdaten vorliegen. Datenlücken bleiben erkennbar.
- Der 7-Tage-Trend berücksichtigt den Regenbeginn am Tag auch bei anschließender nasser Nacht.
- Dezente Zahlen ordnen die Unsicherheitsbalken für Temperatur, Niederschlag und Böen ein.
- Die direkte DWD-Kartenaufbereitung behandelt relative Feuchte oberhalb der Sättigung korrekt, sodass die bisherigen ICON-D2-Karten wieder gemeinsam mit den Summenkarten bereitgestellt werden können.

# MID v0.9.85.143

- Kurzfrist-Hinweis entfernt; Unsicherheitsbänder deutlich kompakter.
- Echte Ensemble-Mediane statt gemischter Einzelwert-/Mittelwertmarker; Böen statt Mittelwind, Tmax/Tmin getrennt gefärbt.
- Stündliches Temperatur-P25–P75-Band nur mit verfügbaren echten Quantilen; künstlicher Halo entfällt. Niederschlagsnullwert als 0.

# MID v0.9.85.142

- Vollständige neue ICON-D2-Kartenraster verlustfrei verdichtet: deutlich weniger Speicher und Downloadvolumen bei unveränderten Werten und unveränderter Auflösung.
- Das kostenlose 900-MB-Datenbudget bleibt verbindlich. Größen- und SHA256-Prüfung erfolgen auch für komprimierte Felder; ältere Safari/WebViews erhalten einen kompatiblen Decoder.
- Enthält die Wetterkarten-, Messsummen- und parameterbezogenen Prognosespannen aus .141.

# MID v0.9.85.141

- Wetterkarten: gefallener Niederschlag aus DWD RADOLAN RW für vollständige 1-/6-/12-/24-/48-h-Fenster; fehlende Messzellen bleiben grau und unbekannt.
- Direkte ICON-D2-Raster für Temperatur, Wind, Böen, Bewölkung, Druck, ThetaE, Wettercode und einstündlichen Niederschlag: bestätigte Modelltermine, Favoritenwerte, PNG-/SVG-Export.
- Parameterweise P10–P90-/P25–P75-Bänder in 7-/14-Tage-Prognosen, mit vergleichbaren Skalen und ausgewählter Windeinheit. Keine erfundenen Stunden- oder Parameterintervalle.
- Niederschlagsnull kompakt als 0; kleine positive Mengen bleiben als Spurenwerte erkennbar.
- Drei nicht mehr im DWD-WMS-Katalog verfügbare Wettercodekarten werden nicht mehr angeboten. Andere regionale/globale WMS-Karten bleiben erhalten.

# MID v0.9.85.140

- Niederschlagsphasen kompakt mit Zeitspannen, Radar und Modellfortsetzung klar gekennzeichnet.
- Radar-Nowcast: kompakte Summe, getrennte Hinweise und Achsen; gegen geerbte Pillenregeln abgesichert.
- Bright-Sky-RV-Import korrigiert: aktuelle Quellkennung wird erkannt statt verworfen.
- Vollständige native DWD-RV-Fünfminutenreihen über Bright Sky bleiben unabhängig vom WMS-Diagnoseweg erhalten. Zusätzliche Beobachtungen dienen bei diesen Reihen als Kontrollabgleich.

# MID v0.9.85.142

- Vollständige neue ICON-D2-Kartenraster verlustfrei verdichtet: deutlich weniger Speicher und Downloadvolumen bei unveränderten Werten und unveränderter Auflösung.
- Das kostenlose 900-MB-Datenbudget bleibt verbindlich. Größen- und SHA256-Prüfung erfolgen auch für komprimierte Felder; ältere Safari/WebViews erhalten einen kompatiblen Decoder.
- Enthält die Wetterkarten-, Messsummen- und parameterbezogenen Prognosespannen aus .141.

# MID v0.9.85.141

- Wetterkarten: gefallener Niederschlag aus DWD RADOLAN RW für vollständige 1-/6-/12-/24-/48-h-Fenster; fehlende Messzellen bleiben grau und unbekannt.
- Direkte ICON-D2-Raster für Temperatur, Wind, Böen, Bewölkung, Druck, ThetaE, Wettercode und einstündlichen Niederschlag: bestätigte Modelltermine, Favoritenwerte, PNG-/SVG-Export.
- Parameterweise P10–P90-/P25–P75-Bänder in 7-/14-Tage-Prognosen, mit vergleichbaren Skalen und ausgewählter Windeinheit. Keine erfundenen Stunden- oder Parameterintervalle.
- Niederschlagsnull kompakt als 0; kleine positive Mengen bleiben als Spurenwerte erkennbar.
- Drei nicht mehr im DWD-WMS-Katalog verfügbare Wettercodekarten werden nicht mehr angeboten. Andere regionale/globale WMS-Karten bleiben erhalten.

# MID v0.9.85.140

- Niederschlagsphasen kompakt mit Zeitspannen, Radar und Modellfortsetzung klar gekennzeichnet.
- Radar-Nowcast: kompakte Summe, getrennte Hinweise und Achsen; gegen geerbte Pillenregeln abgesichert.
- Bright-Sky-RV-Import korrigiert: aktuelle Quellkennung wird erkannt statt verworfen.
- Vollständige native DWD-RV-Fünfminutenreihen über Bright Sky bleiben unabhängig vom WMS-Diagnoseweg erhalten. Zusätzliche Beobachtungen dienen bei diesen Reihen als Kontrollabgleich.

# MID v0.9.85.140

- Niederschlagsphasen kompakt mit Zeitspannen, Radar und Modellfortsetzung klar gekennzeichnet.
- Radar-Nowcast: kompakte Summe, getrennte Hinweise und Achsen; gegen geerbte Pillenregeln abgesichert.
- Vollständige native DWD-RV-Fünfminutenreihen über Bright Sky bleiben unabhängig vom WMS-Diagnoseweg erhalten. Zusätzliche Beobachtungen dienen bei diesen Reihen als Kontrollabgleich.

# MID v0.9.85.139

## Radar-Nowcast und sichtbare Vorhersagespannen

- Radar-Balken und der unsichtbare Auswahlanker sind Grafikmarkierungen statt Buttons. Globale Touch-Mindesthöhen können Mengenunterschiede nicht mehr verdecken. Die gesamte Zeitachse bleibt per Berührung und Tastatur bedienbar.
- Ein kompakter nativer DWD-RV-Abruf über Bright Sky liefert Fünfminutenwerte ohne Ausdünnung. Einheiten, Referenzlauf, Aktualität und fehlende Werte werden geprüft; der direkte DWD-Pfad bleibt als Reserve erhalten. Fehlende Daten werden nicht interpoliert oder als trocken bilanziert.
- Summen, Hinweise, Achsen und Jetzt-Markierung erhalten ein abschließendes, eng begrenztes Layout. Auswahlanker werden auf einen unsichtbaren Pixel begrenzt.
- 7- und 14-Tage-Übersichten zeigen verfügbare P10–P90-Modellspannen für Tageshöchsttemperatur und Niederschlag. Das Temperaturband markiert zusätzlich P25–P75 und den angezeigten Wert auf einer gemeinsamen Skala. Fehlende Ensemblewerte erzeugen keine erfundenen Spannen.
- Eine aufklappbare Erklärung trennt Modellübereinstimmung von Trefferwahrscheinlichkeit und erläutert den zunehmenden Stellenwert von Tendenzen.

## Prüfung

- Basis: `main == mid-stable == 72c19e18f48cc9997d3ad65c69e3b00d8d723bf4` (v0.9.85.138).
- Neue Pflichtregression prüft native Einheiten, 24 Prognoseintervalle, Summen, Referenzläufe, fehlende/veraltete Werte und echte Mengenunterschiede.
- Im CI werden zusätzlich echte Browserprüfungen mit vollständiger CSS-Kaskade auf sechs Displaygrößen in Hell und Dunkel ausgeführt.
- UTCI-, Quellen-, Niederschlagsintervall- und gemeinsame Modellkartenänderungen aus .138 bleiben erhalten.

Native Quelle: https://github.com/jdemaeyer/brightsky/issues/144 und https://github.com/jdemaeyer/brightsky/blob/master/brightsky/query.py. Pixelwerte sind 0,01 mm/5 min; Prognosen werden nur aus dem neuesten frischen RV-Referenzlauf übernommen. Die verwendete öffentliche API benötigt keinen kostenpflichtigen Schlüssel. DWD-Daten und Bright-Sky-Bereitstellung werden in der Herkunft getrennt angegeben.

# MID v0.9.85.138

## Radarintensität, konsistente Niederschlagsstufen und UTCI appweit

- Die 5-Minuten-Balken des Radar-Nowcasts folgen jetzt der tatsächlichen DWD-RV-Intensität des jeweiligen Zeitschritts. Unterschiedlich starker Niederschlag wird deshalb wieder durch unterschiedlich hohe Balken sichtbar; Datenlücken bleiben ausdrücklich schraffiert und werden nicht als trocken interpretiert.
- Die Radar-y-Achse zeigt Maximum, halbe Skala und Null gleichmäßig am selben Raster wie die Balken. Die Einheit bleibt fachlich eindeutig mm/5 min.
- Niederschlagsangaben verwenden appweit dieselbe zentrale WMO-/DWD-basierte Intensitätsklassifikation. Angezeigte Rate und Textstufe stammen aus demselben Intervall; 1,9 mm/h Dauerregen wird beispielsweise als „mäßig“ eingeordnet.
- UTCI (Universal Thermal Climate Index) ist nun der kanonische Index für die gefühlte Außentemperatur in Aktuell, Kurzfrist, 24-h-Profil/Cockpit, Event- und Wassersportansichten sowie Bergwetter. Temperatur, Feuchte, Wind und Strahlungseinfluss werden gemeinsam berücksichtigt; die sichtbaren Belastungsstufen folgen den Standard-UTCI-Klassen.
- Wo keine direkte mittlere Strahlungstemperatur verfügbar ist, schätzt MID sie transparent aus Tageszeit, Bewölkung, UVI und Höhe. Unbrauchbare Eingangsdaten erzeugen keinen erfundenen UTCI-Wert.

# MID v0.9.85.137

## DWD-Radar im Fünfminutentakt und gemeinsame Modellkarten

- DWD GetFeatureInfo wertet RV_ANALYSIS, RV_FORECAST und RV_PREDICTION als native mm/5 min aus und normalisiert korrekt nach mm/h. Die bisher nicht erkannten numerischen Bandwerte verursachten Lücken zwischen den ausgedünnten Kartenbildern. Der bestehende kostenlose DWD-Pfad bleibt erhalten.
- Native Fünfminutenintervalle erhalten explizite Start-/Endzeiten. Die Forecast-Fusion zählt bei 15 Minuten genau drei native Intervalle. Lücken werden weder verbreitert noch als trocken interpretiert oder über RS-Mengenanker aufgefüllt.
- Die sichtbare Summe verwendet die tatsächlich verfügbaren zentralen, final kalibrierten Mengen eines ausdrücklich angegebenen 120-Minuten-Fensters. Nur 24 gültige Schritte ergeben eine vollständige Zweistundensumme und Ensemble-Spanne; ansonsten stehen Teilsumme, auswertbare Minuten und Datenlückenhinweis im Vordergrund. Frühere Summen bei Lücken sind nicht als vollständige Zweistundensummen belastbar.
- Unter Karte bleiben zwei Einstiege: Radar/Satellit/Blitz und Modellkarten. Niederschlagssummen sind ein ICON-D2-Kartenprodukt innerhalb der gemeinsamen, nach Wetterparameter gruppierten Auswahl. Alte Summen-Einstiege und gespeicherte Auswahl werden migriert; Favoriten, Zeitfenster und PNG-/SVG-Downloads bleiben erhalten.
- Kostenlose Natural-Earth-Grenzen (Public Domain) liegen über sämtlichen Modellfeldern. Ländergrenzen immer, Bundesländer ab Zoom 4,8 und kollisionsgeprüfte Ortsnamen ab Zoom 5,7. Bundeslandgrenzen sind auch im PNG-/SVG-Export sichtbar. Auf Smartphones sind die Auswahlfelder mindestens 44 px hoch.
- Neue funktionale Regression prüft Datenfeld/Einheit, 37 Fünfminutenabfragen, Intervallgrenzen, vollständige/partielle Mengen, RS-Lückenschutz, Intervallfusion, Navigationmigration und Zoomstufen. Betroffene historische Oberflächentests werden wegen der ausdrücklich gewünschten Zusammenführung und korrigierten Summenbasis angepasst; alle übrigen Assertions bleiben erhalten.

# MID v0.9.85.136

## ICON-D2-Abgrenzung und konsolidierte Regressionen

- Extremwetter-Ausblick: Außenbereich der gekrümmten ICON-D2-Modellabdeckung dunkel eingefärbt; Grenzpolygon entspricht exakt der bestehenden Analyse. Dunkler Bereich in der Kartenlegende erklärt, unabhängig von Hazard-Auswahl, Zeitraum und temporären Datenlücken.
- Alle 894 Regressionen bleiben unverändert wirksam. Automatische Dateierkennung und beide Baseline-Pflichtlisten werden jetzt als vollständige identische Inventare geprüft; fehlende, veraltete und doppelte Registrierungen brechen die Suite ab.
- Ein gemeinsamer Runner meldet Fortschritt, Gesamtdauer und langsamste Prüfungen; Fehler enthalten weiter die vollständige Ausgabe. MID_REGRESSION_VERBOSE=1 zeigt auch erfolgreiche Einzelausgaben. Ausführung bleibt isoliert und seriell, damit gemeinsam verwendete Artefakte keine Rennen verursachen.
- Neue Regression schützt die identische Modellgeometrie sowie positive und negative Fälle der Testregistrierung. Keine bestehenden Assertions entfernt, keine zusätzlichen Kosten oder Datenquellen.

# MID v0.9.85.135

## Unveränderliche DWD-Karten-Snapshots

- Niederschlagssummen aus ICON-D2 erhalten eine eigene, vom tatsächlichen Datei-Hash abgeleitete Objektadresse innerhalb des bestehenden RUC-/Pages-Manifests.
- Ein neuer ICON-D2-Lauf oder eine Wiederholung der Aufbereitung kann dadurch keine bereits gecachte Raster-URL überschreiben, auch wenn der RUC-Lauf unverändert bleibt.
- Die Auswahl des aktuellen Kartenobjekts lädt das DWD-Manifest mit einer frischen Anfrage, damit ein Browser-/CDN-Cache keinen alten Lauf festhält.
- Snapshot-Erhalt, Kartenansicht, Favoriten, PNG-/SVG-Downloads und alle Änderungen aus v0.9.85.134 bleiben erhalten. Kein zusätzlicher Anbieter oder Workflow; bestehende kostenlose DWD-Pipeline.
- Regression prüft zwei unterschiedliche ICON-D2-Läufe bei identischem RUC-Lauf und verschiedene unveränderliche Objektadressen.

# MID v0.9.85.134

## Gemeinsamer Kartenbereich und echte DWD-Niederschlagssummen

- „Karte“ bündelt Radar/Satellit/Blitz, Modellkarten und Niederschlagssummen. Bestehende Wetterkarten-Einstiege öffnen weiterhin die Modellkarten; Radartimeline und Echo-/ETA-Markierungen bleiben erhalten.
- Direkte kostenfreie DWD-ICON-D2-TOT_PREC-Raster für 6/12/24/48 Stunden ab Laufstart, geprüft auf denselben Lauf, Einheiten, Rasterabdeckung und akkumulierte Endfelder. Keine Verlängerung der 14-Stunden-RUC-Daten.
- Deutschlandausschnitt, einheitliche mm-Farbskala, Favoritenwerte am nächsten DWD-Rasterpunkt, Kartenmaximum und tatsächlicher Gültigkeitszeitraum. PNG-/SVG-Download mit Legende, Favoriten, Quellen- und Lizenzangaben; auf unterstützten Mobilgeräten als Datei teilbar.
- Der vorhandene kostenlose DWD-/Pages-Prozess veröffentlicht die zusätzlichen Raster als geprüfte unveränderliche Objekte; App-Releases erhalten sie über den bestehenden Snapshot-Restore.
- Veraltete, unvollständige oder fehlende Raster werden nicht angezeigt oder exportiert. Die zusätzliche Karte wird erst nach erfolgreicher DWD-Aufbereitung freigegeben.
- Redundante Standort-Kartenbox entfernt. Die Änderungen und Zeitsteuerungen der veröffentlichten v0.9.85.131–.133 bleiben erhalten.

## Quellen und Kosten

DWD Open Data (CC BY 4.0), OpenStreetMap (ODbL 1.0), Natural Earth (Public Domain). Kein kostenpflichtiger Kartenanbieter, kein zusätzlicher API-Key und keine Bright-Sky-Abhängigkeit. Bright Sky ist eine kostenlose DWD-API, ersetzt jedoch keine vollständige ICON-D2-GRIB-Rasterschnittstelle; unbegrenzte Verfügbarkeit wird nicht zugesichert.

# MID v0.9.85.133

## Niederschlag und Kurzfrist
- Radar-Zeitschritte, die technisch nicht ausgewertet werden konnten, werden nicht mehr als trockene 5-Minuten-Phasen dargestellt.
- Die Niederschlagsaussage oberhalb des Radar-Nowcasts berücksichtigt nun den gesamten 24-h-Prognoseverlauf und mehrere Niederschlagsphasen statt nur des ersten zusammenhängenden Abschnitts.
- Niederschlagsart und -intensität werden intervallgerecht bewertet: 15-Minuten-Mengen werden auf ihre tatsächliche Dauer bezogen. Ein hoher 15-Minuten-Wert kann deshalb nicht mehr als „leichter Sprühregen“ erscheinen.
- Frische lokale Niederschlagsbeobachtungen können die Niederschlagsart in der unmittelbaren Kurzfrist stützen, damit beobachtete Schauer nicht sofort durch einen widersprüchlichen Modellcode verdrängt werden.

## Pollenflug
- „Heute“ wird jetzt über das tatsächliche lokale Datum bestimmt; gestrige DWD-Zeilen können nicht mehr als heutige Prognose erscheinen.
- Angezeigt wird nach Möglichkeit der fachliche DWD-Produktstand statt lediglich der technischen Abrufzeit.
- Der Pollenabruf wird rund um Produktaktualisierungen schneller erneuert und bei längeren PWA-Sitzungen bzw. nach Rückkehr in die App automatisch aktualisiert; ein kurzfristiger Aktualisierungsfehler entfernt einen bereits geladenen verwertbaren Stand nicht.

## Navigation
- Beim Neustart ist der zuletzt gewählte Hauptbereich maßgeblich. Ein veralteter Unterbereich darf ihn nicht mehr auf „Vorhersage“ zurücksetzen.
- Forecast-Horizon-Ereignisse dürfen nur innerhalb des tatsächlich aktiven Prognosebereichs persistieren.

# MID v0.9.85.132

## Niederschlag · einheitliche Zeitangaben
- Aussagen wie „Niederschlag voraussichtlich bis …“ verwenden jetzt dieselbe Intervallzeit wie die sichtbaren Niederschlagsdiagramme.
- Die bisher mögliche stündliche Verschiebung der Endzeit um eine zusätzliche Stunde wurde entfernt.
- Innerhalb der Kurzfrist wird die finalisierte 15-Minuten-Reihe bevorzugt; sie enthält bereits die operative RUC-/Radar-/Modellfusion. Nur bei fehlender vollständiger 15-Minuten-Abdeckung wird auf die intervallkorrigierte Stundenreihe zurückgefallen.
- Reine Niederschlagswahrscheinlichkeit ohne dargestellte messbare Niederschlagsmenge verlängert keine vermeintliche Niederschlagsdauer mehr.
- Niederschlagsphasen hinter dem +2-Stunden-Radarfenster werden aus derselben kanonischen Zeitreihe abgeleitet wie Kurzfrist, 24-h-Profil und weitere Prognosedarstellungen.

## Konsistenz
- Open-Meteo-Akkumulationen am Intervallende werden vor sichtbaren Zeitaussagen auf den zugehörigen Vorwärtsslot normalisiert.
- Die Endzeit eines letzten nassen Stundenintervalls wird dadurch nicht mehr pauschal um eine weitere Stunde verlängert.

# MID v0.9.85.131

## Aktuell · Radar-Nowcast
- Die Radar-Nowcast-Auswertung startet früher und verwendet für die erste Echoentscheidung einen schlanken DWD-Rasterpfad; die vollständige 5-Minuten-Punktserie wird unmittelbar danach nachgeladen.
- Die Grafik erscheint weiterhin nur, wenn am Standort oder im relevanten Umfeld ein Niederschlagsecho erkannt wird.
- Regelmäßige scheinbare „Trockenphasen“ aus der ausgedünnten Schnellserie werden nicht mehr als 0-Niederschlag dargestellt. Eine unvollständige Schnellserie wird transparent als noch zu vervollständigende 5-Minuten-Auswertung behandelt.
- Echte trockene 5-Minuten-Abschnitte bleiben sichtbar, wenn der vollständige DWD-Punktpfad für den jeweiligen Zeitschritt tatsächlich kein relevantes Echo liefert.

## Wetterkarten
- Der MID-C11-Handoff vereinheitlicht und verdichtet die Zeitsteuerung in den Kartenansichten.
- Ausgewählte Zeitpunkte und Navigationskontrollen bleiben auf Smartphone, Tablet und Desktop klarer lesbar und beanspruchen weniger Kartenfläche.

## Fachlichkeit und Leistung
- DWD-Radarquelle, saisonale Echoprofile und bestehende Niederschlagsschwellen bleiben unverändert.
- Kurzer Radar-Kurzcache, früherer Preload und größere parallele Pakete für die exakten 5-Minuten-Punktwerte reduzieren unnötige Wiederholungs- und Wartezeiten.

# MID v0.9.85.130

## Einstellungen
- Unter „Inhalte & Navigation“ ist **Gesundheitswetter** jetzt tatsächlich sichtbar und steht vor den übrigen optionalen Inhaltsmodulen.
- **Pollenflug** kann dort separat ein- oder ausgeschaltet werden. Die Auswahl bleibt gerätelokal gespeichert.
- Die Modulreihenfolge bleibt darunter separat konfigurierbar.

## Navigation
- MID merkt sich wieder den zuletzt verwendeten Hauptbereich: **Aktuell**, **Heute**, **Vorhersage**, **Karten** oder **Mehr**.
- „Mehr“ wird nach einem erneuten App-Aufruf wieder geöffnet, wenn die App dort beendet wurde.
- Wird „Mehr“ bewusst geschlossen, gilt wieder der darunter aktive Hauptbereich.
- Explizite MID-Deep-Links haben beim Start weiterhin Vorrang vor dem gespeicherten Bereich.

## Fachlichkeit
- DWD-Pollendaten, Belastungsstufen, Regionen und Vorhersagewerte bleiben unverändert.

# MID v0.9.85.129

## Gesundheitswetter kompakter
- Pollenflug erscheint im Standardzustand jetzt als sehr kompakter Gesundheitswetter-Block mit heutiger Belastung, Region und DWD-Stand.
- Direkt sichtbar sind nur Pollenarten mit tatsächlicher heutiger Belastung. Die erste geöffnete Detailstufe zeigt höchstens vier Pollenarten mit der höchsten relevanten 3‑Tage-Belastung.
- Die vollständige Übersicht aller acht DWD-Pollenarten wird erst nach „Alle 8 Pollenarten anzeigen“ eingeblendet.
- Die mobile 3-Tage-Ansicht passt ohne abgeschnittene dritte Spalte oder erzwungene horizontale Mindestbreite in die Karte.

## Fachliche Korrektur
- DWD-Zwischenstufen wie „keine bis gering“, „gering bis mittel“ und „mittel bis hoch“ werden nicht mehr fälschlich als „keine Belastung“ behandelt.
- Grundlage bleiben die sieben Belastungsstufen des amtlichen DWD-Pollenflug-Gefahrenindex; DWD-Datenquelle, Regionen und Vorhersagewerte bleiben unverändert.

## Bedienung
- Der Hauptschalter bleibt mindestens 44 px hoch, tastaturbedienbar und mit aria-expanded/aria-controls versehen.
- Region und Aktualitätsstand werden platzsparend dargestellt; geöffnete Details erhalten sicheren Abstand zur festen Bottom-Bar.

# MID v0.9.85.128

## Sichtbar
- „Pollenflug“ steht unter „Inhalte & Navigation“ jetzt in einer eigenen Sektion „Gesundheitswetter“ und bleibt vollständig optional.
- Die kompakte Pollenvorhersage priorisiert heute tatsächlich belastende Pollenarten; bei keiner Belastung erscheint eine ruhige Zusammenfassung. Die Drei-Tage-Details bleiben aufklappbar und sind besser per Touch und Tastatur bedienbar.
- DWD-Quelle, Aktualitätsstand und die bestehenden Belastungsbegriffe bleiben sichtbar und unverändert.

## Technisch
- CodeQL-Eingabepfade für amtliche Warnwahrscheinlichkeiten und den Bergwetter-Browsertest wurden gehärtet.
- Der aktuelle High-Severity-`brace-expansion`-Befund wird innerhalb des kompatiblen 5.x-Pfads geschlossen; der bekannte `uuid`-Dev-/iOS-Werkzeugpfad wird nicht mit einem inkompatiblen Force-Upgrade umgangen.
- `actions/download-artifact` ist im RUC-Publishpfad auf v8.0.1 und einen vollständigen Commit-SHA aktualisiert.
- Meteorologische Prognose-, Warn-, DWD-Pollen- und Worker-Datenlogik bleiben unverändert.

# MID v0.9.85.127

## Sichtbar
- Pollenflug-Einstellung und Aktuell-Ansicht stabilisiert.
- Dezente Datenqualitätsindikatoren direkt an zentralen Wetterparametern.
- Versionsanzeige und ausgelieferter Funktionsstand wieder synchron.

## Technisch
- Referenzbewusste Root-Dokumentmigration, sicherer Branch-Cleanup und Vertragsregistry.
- KNMI-Diagnoseworkflows bereinigt; Vitest/V8-Coverage ergänzend eingeführt.
- Keine meteorologische Fachlogik geändert.

## v0.9.85.127 · 2026-09-30

- Die Pollenflug-Einstellung und die aktuelle Wetteransicht bleiben nach den jüngsten Korrekturen stabil; die Qualitätsanzeige sitzt dezent direkt an den wichtigsten Wetterparametern.
- Die Versionsanzeige ist wieder mit dem tatsächlich ausgelieferten Funktionsstand synchron.
- Technische Repository-, Vertrags- und CI-Bereinigungen verändern keine meteorologischen Schwellen, Warnlogik oder Prognosewerte.

# MID v0.9.85.126

- Behoben: „Aktuell"-Ansicht sprang nach Wetterdaten-Laden automatisch auf „Vorhersage" zurück, wenn die zuletzt gespeicherte Ansicht „Vorhersage" war und der Nutzer zuvor auf „Aktuell" getippt hatte.
- Ursache: Der Startup-Restore-Effekt lief nach dem Laden der Wetterdaten und überschrieb die explizite Nutzer-Navigation mit der gespeicherten Sektion.
- Fix: Ein `userNavigatedRef` verfolgt, ob der Nutzer bereits aktiv navigiert hat. Der Startup-Restore wird übersprungen, wenn der Nutzer vorher eine andere Ansicht gewählt hat.

# MID v0.9.85.125

- App-Absturz beim Start behoben: PollenForecast-Komponente führte Datenabruf während der Render-Phase durch (React-Side-Effect) statt in useEffect. Dies konnte zu Endlos-Schleifen und Abstürzen führen.
- UTCI-Windgeschwindigkeits-Übergabe abgesichert: Math.max(0.5, NaN) gab NaN zurück statt 0.5. Jetzt mit Number.isFinite-Prüfung.

# MID v0.9.85.124

- UTCI (Universal Thermal Climate Index) ersetzt die gefühlte Temperatur in der Aktuell-Ansicht. Korrekte Polynom-Koeffizienten nach Brode et al. (2012). Keine separate Sektion mehr — UTCI-Wert und Belastungskategorie direkt in der aktuellen Wetteranzeige.
- Pollenflug-Vorhersage kompakter: Chip-basierte Anzeige statt großer Tabelle. Details aufklappbar.

# MID v0.9.85.123

- UTCI (Universal Thermal Climate Index) als gefühlte Temperatur in der Aktuell-Ansicht: wissenschaftlich fundiertes thermisches Komfortmodell nach WMO/ISB mit 10 Belastungskategorien.
- Pollenflug-Einstellung und weitere Inhaltsmodule unter "Inhalte & Navigation" umgruppiert (zuvor in allen Einstellungsbereichen sichtbar).
- Pollenflug-Einstellung dauerhaft gespeichert (gerätelokal, nicht von Gerätesynchronisation überschrieben).

# MID v0.9.85.122

- Fehler behoben: Pollenflug-Einstellung wurde beim App-Neustart nicht dauerhaft gespeichert (Gerätesynchronisation hat Schlüssel entfernt).
- Fehler behoben: Zuletzt angezeigte Ansicht wurde beim Wiederaufrufen der App nicht wiederhergestellt (IntersectionObserver und Forecast-Horizon-Event haben gespeicherte Ansicht beim Start überschrieben).

# MID v0.9.85.121

- Pro-Parameter Datenqualitätsindikator in der Aktuell-Ansicht: kompakte Qualitäts-Badges für Temperatur, Wind, Niederschlag, Feuchte und Luftdruck mit Quellen- und Altersangabe.
- Erweiterte Ansicht zeigt aktive Modellläufe mit Initialisierungszeit, Auflösung und Vorhersagehorizont.

# MID v0.9.85.120

- Pollenflug-Vorhersage kann in den Einstellungen ein- und ausgeschaltet werden.
- Pollenflug-Komponente an das MID-Designsystem angeglichen (forecast-entry-head, Card-Oberfläche, Parameter-Farben).

# MID v0.9.85.119

- Pollenflug-Vorhersage für Deutschland: DWD-Pollendaten (8 Allergene, 27 Regionen, 3 Tage) in der Aktuell-Ansicht.
- Hoher-Kontrast-Modus (WCAG 2.1 AA) als vierte Theme-Option in den Einstellungen.
- Fehler behoben: Changelog-Link aus der App startete die App neu statt den Changelog zu öffnen.

# MID v0.9.85.116

- Nachtstunden sind im Dark-Design in Skybar und Temperaturverlauf deutlicher erkennbar.
- Die Nachtflächen bleiben weich an Sonnenuntergang und Sonnenaufgang ausgeblendet und überdecken Temperaturkurve oder Wetterfarben nicht.
- Das Light-Design bleibt unverändert; meteorologische Logik, Solarberechnung, Wetterfarben und Datenquellen bleiben unangetastet.

# MID v0.9.85.115

- Der kurzfristige Temperaturverlauf übernimmt lokale Messkorrekturen jetzt zeitgenau und ohne künstliche Gegenbewegung durch ein zu schnelles Ausblenden des Temperatur-Bias.
- Dadurch wird insbesondere ein unplausibler Stundenanstieg vermieden, der allein aus der Rückführung einer starken hyperlokalen Temperaturkorrektur entstehen konnte.
- Die +12-h-Temperaturkurve bleibt an dieselbe kanonische, hyperlokal finalisierte Stundenreihe gebunden; es gibt keine separate grafische Glättung.
- Im Berg-/Wintersportbereich zeigt die horizontale Stundenprognose jetzt die nächsten 12 statt 24 Stunden. Die 7-Tage-Ansicht und eigenständige 24-h-Schneeangaben bleiben erhalten.

# MID v0.9.85.114

- Der Trendtext der mobilen 7-Tage-Ansicht kann vollständig umbrechen; Modellstand und Legende erhalten eine eigene Zeile.
- Die Kopfzeilen von Komposit- und Wetterkarten ordnen Titel und Status auf schmalen Ansichten untereinander an.
- Bei ausgewähltem Standort erscheint kein fester PWA-Installationshinweis mehr über dem Wetterinhalt. Die Installation bleibt über die Kopfzeile erreichbar.
- Die Korrekturen betreffen ausschließlich Darstellung und Bedienung; Wetter- und Warnlogik bleiben unverändert.

# MID v0.9.85.113

- In der Kurzfristvorhersage ist das Detail nach Auswahl eines Zeitpunkts wieder sichtbar.
- Wetterkarten-Playback, „Jetzt“ und „Neu laden“ besitzen auf Touch-Ansichten mindestens 44 × 44 px große Ziele. Standort-Popups öffnen auch durch Tippen; der gewählte Standort ist zusätzlich per Tastatur aufrufbar.
- Die Szenarioübersicht der 14-Tage-Ansicht zeigt ihre Kurzlabels lesbar und ohne Abschneiden auf schmalen Displays.
- Die untere Hauptnavigation ist für Screenreader als Navigation ausgezeichnet.
- Meteorologische Berechnungen, Datenquellen und Warnstufen bleiben unverändert.

# MID v0.9.85.112

- Die Kartensteuerung ist auf Smartphone und Touch-Geräten ruhiger und einheitlicher angeordnet: Zoom, Positionszentrierung und Layersteuerung besitzen konsistente Größen, Abstände und eine gemeinsame rechte Ausrichtung.
- Die Bedienelemente berücksichtigen weiterhin Safe Areas und ausreichend große Touch-Ziele.
- In der 7-Tage-Kurvenübersicht sind die sieben Tagesbereiche auf Desktop wieder vollständig sichtbar und sauber an der gemeinsamen Zeitachse ausgerichtet.
- Meteorologische Berechnungen, Datenquellen und Warnlogik bleiben unverändert.

# MID v0.9.85.111

- Die automatische MID-Revision behandelt kurzzeitige Netzwerk- und Providerfehler robuster, ohne den fachlichen Fail-Closed-Schutz zu lockern.
- Kritische API-Verträge erhalten höchstens drei begrenzte Abrufversuche bei Transportfehlern, HTTP 408/425/429 oder 5xx.
- Inhaltlich ungültige Antworten und nicht-transiente 4xx bleiben sofort echte Vertragsfehler; nach dem letzten erfolglosen Versuch bleibt die Revision rot.
- Die Änderung betrifft ausschließlich die Prüfautomatik. Wetterlogik, Berg-/Wintersportdaten, Worker-Fachlogik und sichtbare App-Funktionen bleiben unverändert.

# MID v0.9.85.110

- Berg-/Wintersport nutzt im Kurzfristbereich nach Möglichkeit ein einheitliches hochaufgelöstes Regionalmodell für alle Höhenstufen; Best Match bleibt die vollständige 7-Tage-Basis und der robuste Fallback.
- Die tatsächlich verwendete Höhenprognosequelle wird sichtbar benannt. DWD ICON-D2-RUC wird als ergänzendes standortbezogenes 15-Minuten-Signal klar von getrennten Tal-/Mitte-/Berg-Reihen abgegrenzt.
- Tagespiktogramme der Höhenprognose verwenden keine Mond-Darstellung mehr; geöffnete Stunden- und 3-Stunden-Werte behalten weiterhin die astronomisch korrekte Tag-/Nacht-Darstellung.
- Neuschnee wird im Tagesüberblick ausdrücklich als „Neuschnee“ bezeichnet. In der Sommerdarstellung entfällt ein redundantes „0 cm“, positive Mengen bleiben sichtbar; im Winter bleibt ein echter Nullwert erhalten.
- Räumlich versetzte Höhenpunkte werden transparent gekennzeichnet: Niederschlagsunterschiede können neben der Höhe durch Exposition und Luv-/Lee-Effekte entstehen. Eine künstliche monotone Niederschlagskorrektur nach Höhe findet nicht statt.
- Die Höhenzonenanalyse wird typografisch und farblich an die übrige Berg-/Wintersportsektion angeglichen.

# MID v0.9.85.109

- Aktuelles Wetter, Wetterpiktogramm und Bewölkungskarte verwenden jetzt denselben kanonischen Bewölkungszustand; widersprüchliche Kombinationen wie „Bedeckt“ bei 6/8 werden vermieden.
- Die sichtbaren Bewölkungsbezeichnungen folgen app-weit der DWD-Oktas-Systematik: 0/8 wolkenlos, 1–3/8 leicht bewölkt, 4–6/8 wolkig, 7/8 stark bewölkt und 8/8 bedeckt.
- Auch ohne frische lokale Wolkenmessung wird ein trockener Best-Match-Wettercode mit der tatsächlich dargestellten Gesamtbewölkung abgeglichen.
- Kurzfrist-, Piktogramm-, Bergwetter- und Forecast-Fusion-Fallbacks verwenden dieselben aus Oktas abgeleiteten Bewölkungsgrenzen.
- Event-, Routen-, Wasser- und Periodenansichten verwenden bei trockenem Wetter dieselben kanonischen Bewölkungsbezeichnungen.
- Die Kurzbezeichnung des UV-Index ist in den sichtbaren Wetteransichten einheitlich „UVI“, unter anderem in 7-/14-Tage-, Bergwetter- und Eventdarstellungen.

# MID v0.9.85.108

- Berg-/Wintersport zeigt für die gewählte Höhenstufe jetzt eine stündliche Prognose statt der bisherigen Kennwert-Kacheln.
- Die 7-Tage-Höhenprognose ist deutlich kompakter; ein Tag lässt sich weiterhin für die Stundenwerte öffnen.
- Beim Laden erscheint sofort eine strukturierte Vorschau, während Zusatzdaten im Hintergrund ergänzt werden.
- Der bisherige separate „Höhenvergleich“ entfällt. Weitere Kennwerte, Schnee-/Eishinweise, Schneefallgrenzen, Lawinenquelle und Methodik sind ruhiger in das MID-Design eingeordnet.
- Aktuelle hyperlokal analysierte Bewölkung wird knapp unter vollständiger Bedeckung nicht mehr allein durch Rundung als „Bedeckt“ ausgegeben.
- Open-Meteo liefert für Sonne/Mond zusätzlich Mondaufgang, Monduntergang und Mondphase; MID nutzt diese Tageswerte vorrangig und behält die lokale Astronomieberechnung als robusten Fallback.

# MID v0.9.85.107

- Die 7- und 14-Tage-Übersichten sind kompakter aufgebaut; Sonnenstunden und UVI bleiben auch auf kleinen Displays gut lesbar.
- Nachtpiktogramme erhalten ausreichend Platz und werden in den kompakten Tageszeilen nicht abgeschnitten.
- Das Berg-/Wintersportprofil ist dichter und tabellarischer aufgebaut. Schnee und Flüssigniederschlag werden getrennt dargestellt; die Schneeflächen skalieren ausschließlich die dargestellte Schneemenge und sind keine amtlichen Warnstufen.
- Schnee-/Eiswarnungen, amtliche Lawinenquelle und Methodik sind kompakter strukturiert. Lange Warntexte bleiben über Details zugänglich.
- Der ChatGPT/GitHub-Vertrag entspricht jetzt dem geschützten Source-first-Veröffentlichungsweg.

# MID v0.9.85.106

- Replit bleibt die gezielte MID-Werkbank für Design- und UI-Anpassungen; konkrete MID-Arbeitsaufträge an Replit werden ausschließlich von ChatGPT erteilt.
- Replit übergibt Änderungen nur über geprüfte `replit/*`-Handoffs. Prüfung, Integration und Veröffentlichung bleiben bei ChatGPT und dem geschützten GitHub-Releasepfad.
- Ein fehlender lokaler SSH-Deploy-Key wird nicht durch einen neuen Schreibschlüssel oder gelockerte Hostprüfung ersetzt; der vorhandene GitHub-Integrationsweg nutzt SHA-Verifikation vor und nach dem Handoff.
- Persistente Replit-Regeln und ein projektgebundener MID-Handoff-Skill machen den Ablauf auch nach neuen Replit-/ChatGPT-Sitzungen reproduzierbar.
- Das Replit-Handoff-Gate schützt zusätzlich Governance-, Agent-, CI-/Release-, Worker-, iOS-, Versions- und zentrale Build-/Deploy-Dateien vor direkten Replit-Änderungen.

# MID v0.9.85.105

- Zusatzdaten der Bergprognose bleiben nach einem Diagnosefehler korrekt als „Nicht verfügbar“ markiert, auch wenn der 3-Minuten-Cache erneut geöffnet wird.
- Die geöffnete Quellenübersicht zeigt Diagnostik, Messungen, Ensemble und Cachehinweise in einer kompakten Statusliste; die Kernprognose bleibt unabhängig davon sichtbar.
- Die bestehenden kompakten 7-/14-Tage-Sonnen- und UVI-Werte verwenden weiterhin die vorhandenen Tagesdaten und fehlende Werte als „–“.

# MID v0.9.85.104

- Berg-/Wintersportwetter ist auf schmalen Smartphones kompakter und besser lesbar.
- Wochentage bleiben vollständig sichtbar; Schnee-, Sonnen- und Windwerte überlagern sich nicht mehr.
- Schneemengen werden einheitlich als „0 cm“, „<1 cm“ oder „–“ dargestellt.
- Aktuelle Bergwerte erscheinen als kompakte horizontale Instrumentleiste; die 7-Tage-Zeilen bleiben ohne horizontales Scrollen bedienbar.
- Die 3-Stunden-Detailansicht ist für kleine Displays neu ausbalanciert.

# MID v0.9.85.103

- Berg-/Wintersportwetter zeigt Tal-, Mittel- und Bergstation als klare Höhenwahl mit jeweils eigenen aktuellen Bedingungen.
- Die 7-Tage-Übersicht ist kompakt, standardmäßig geschlossen und pro Tag einzeln aufklappbar.
- Geöffnete Tage zeigen 3-stündliche Tag-/Nachtwerte mit MID-Piktogrammen, Wind/Böen sowie Niederschlags- und Schneemengen.
- Die Höhenprognose umfasst sieben Tage; fehlende Schneefalldaten werden nicht als 0 cm ausgegeben.

# MID v0.9.85.102

- „Heute“ bleibt nach dem Antippen zuverlässig im Kurzfristbereich und springt nicht mehr auf „Vorhersage“ zurück.
- Die Bottom-Bar bleibt auf Smartphone und Querformat mit den bestehenden Safe-Area- und Touchzielregeln responsiv.

# MID v0.9.85.101

- Aktuelles Wetter verwendet für Himmelszustand und großes Wettersymbol konsequent dieselbe aktuelle Bewölkungsquelle.
- Nachtstunden werden auch in den Skybars der 7- und 14-Tage-Tageszeilen dezent astronomisch markiert.
- Im Kartenbereich verdeckt der automatische App-Installationshinweis keine Karte oder Kartenbedienelemente mehr.

# MID v0.9.85.100

- Der aktive Bereich der mobilen Einstellungen bleibt auf kleinen Smartphones vollständig sichtbar.
- Die einzeilige Tab-Leiste führt den gewählten Bereich automatisch ins Sichtfeld und zeigt dezent weitere Inhalte links oder rechts an.
- Touchziele, Safe Areas und Light-/Dark-Darstellung wurden für 360×800 und 390×844 geprüft; Wetter- und Prognoselogik bleiben unverändert.

# MID v0.9.85.99

- Die Prognose-Zeithorizonte bleiben auf kleinen Smartphones und im schmalen Querformat nach dem Navigationssprung vollständig sichtbar.
- Die Horizontleiste überdeckt weder Prognosekopf noch erste Tageszeile und berücksichtigt die obere Safe Area.
- Wetterdaten, Modellfusion, Schwellen, Parameterfarben sowie die 7-/14-Tage-Fachlogik bleiben unverändert.

# MID v0.9.85.98

- Die 90‑Minuten‑Skybar unter „Heute / Ab jetzt“ kennzeichnet Nachtstunden jetzt genauso dezent wie die Skybar unter „Aktuell“.
- Die Nachtfläche wird minutengenau aus der gemeinsamen Sonnenauf‑/untergangslogik abgeleitet und liegt hinter den Wettersegmenten, sodass Niederschlags-, Bewölkungs- und Sonnenfarben unverändert lesbar bleiben.
- Übergänge an Sonnenaufgang und Sonnenuntergang blenden weich ein bzw. aus; vollständig nächtliche und teilweise nächtliche 90‑Minuten‑Fenster werden korrekt dargestellt.

# MID v0.9.85.97

- Forecasts für denselben Ort unterscheiden Cache-Stände jetzt zuverlässig nach Höhe und Ortszeitzone. Ein Wechsel zwischen Tal und Gipfel oder zwischen Zeitzonen kann deshalb keinen unpassenden alten Kernforecast mehr übernehmen.
- Direkte und Worker-basierte Kernprognosen verwenden dieselbe angeforderte Höhe und Zeitzone.
- Dialoge, Popover und Sheets besitzen eine gemeinsame Tastatur-Fokusführung: Tab bleibt in der geöffneten Ebene, Escape schließt nur die oberste Ebene und der Fokus kehrt anschließend zum auslösenden Bedienelement zurück.
- Tages- und Folgenachtlogik orientiert sich an lokalen Kalendertagen und realen Prognose-Epochen statt an einem festen UTC-Mittag; dies schützt insbesondere Mitternacht, Sommerzeitwechsel und weit von UTC entfernte Zeitzonen.

# MID v0.9.85.96

- Aktuelle METAR-Beobachtungen werden strikt vom nachfolgenden Trendteil getrennt. TEMPO-/BECMG-/FM-Angaben können dadurch kein aktuelles Wetterphänomen oder aktuelle Bewölkung mehr vortäuschen.
- Ein trockener METAR mit nachfolgendem `TEMPO SHRA` führt nicht mehr zu einem aktuellen Regenschauer in MID.
- Die 14-Tage-Ansicht ist auf Smartphones deutlich kompakter: pro Tag eine Tageszeile mit Datum, Wetter, Tmin/Tmax, genau einer Skybar, Niederschlag, Wind/Böen und Konfidenz.
- Sonnenscheindauer, Temperaturabweichung und erweiterte Konfidenz erscheinen nur noch nach Antippen des jeweiligen Tages; eine zweite Skybar entfällt.

# MID v0.9.85.95

- Gewitterhinweise zeigen diagnostische Modellwerte durchgehend als Signalstärke und nicht mehr als scheinbar kalibrierte Prozentwahrscheinlichkeit.
- Die Kurzfristdiagnose respektiert die native zeitliche Auflösung der DWD-RUC-Parameter: 15-minütige ML-CAPE/CIN-Werte und stündliche MU-CAPE/CIN-Werte werden nur zeitlich passend kombiniert.
- Die Skybar trennt Sonnenscheindauer und Gesamtbewölkung fachlich sauber. Wolkenlücken werden nicht mehr als Sonnenscheindauer ausgegeben.
- Ensembleinformationen berücksichtigen die native Zeitauflösung der Modelle. WeatherNext 2 bleibt für Tages- und Szenarioaussagen erhalten, wird aber nicht für überpräzise stündliche Warn-/Ereignisaussagen verwendet.
- Zusätzliche Performance-Grenzen schützen große Karten-, Radar-, Ensemble- und Vendor-Module vor schleichendem Wachstum.

# MID v0.9.85.94

- MID behandelt die native Zeitauflösung von ICON-D2-RUC jetzt eindeutig und nachvollziehbar: 5-Minuten-Niederschlag, 15-Minuten-Felder nur dort, wo der DWD sie tatsächlich so liefert, und stündliche Felder bleiben stündlich.
- CAPE_MU und CIN_MU werden nicht mehr fälschlich als 15-Minuten-Rapidfelder angefordert. Dadurch sinkt unnötiger RUC-Aufwand und die Datenherkunft bleibt fachlich korrekt.
- Gewitter-Mehrparameterdiagnosen werden nicht mehr wie kalibrierte Prozentwahrscheinlichkeiten dargestellt. Sichtbar ist jetzt eine klar bezeichnete Signalstärke; amtliche und echte probabilistische Angaben bleiben davon getrennt.
- Trockene Wetterpiktogramme werden zusätzlich gegen die finalisierte Gesamtbewölkung plausibilisiert, damit „stark bewölkt“, „bedeckt“, Skybar und Symbolik nicht durch einen zu groben Wettercode auseinanderlaufen.
- Radar-, Gewitter- und Starkregen-Aktualisierungen teilen sich einen gemeinsamen Vordergrund-Refresh-Broker. Fokus-, Sichtbarkeits- und Online-Wechsel lösen dadurch weniger doppelte Arbeit aus.
- Identische gleichzeitige Worker-Abfragen ohne eigenen Abbruchkontext werden zusammengeführt, bevor der gemeinsame Cache greift.
- Ein automatisches Bundle-Budget schützt den bereits großen Haupt-JavaScript- und Haupt-CSS-Pfad vor weiterem unbeabsichtigtem Wachstum. Eine tiefere CSS-Konsolidierung bleibt dadurch messbar und regressionsgeschützt.

# MID v0.9.85.93

- Die 14-Tage-Ansicht bleibt eine vertikale Liste aus 14 Tageskarten; der bisherige horizontale Karten-Scroll auf Smartphone und Tablet entfällt.
- Innerhalb jeder Tageskarte passt sich die Informationsanordnung nun fluid an: eine Spalte auf Smartphones, zwei auf Tablets und vier auf Desktop.
- Wochentag, Datum und Wetterbeschreibung werden nicht mehr zeichenweise gequetscht; Temperaturfaden, Skybar, Niederschlag, Wind/Böen und Sonnenscheindauer nutzen die verfügbare Breite.
- Jede Tageskarte behält eine sichtbare Details-Steuerung.
- Geöffnete Tagesdetails enthalten zusätzlich eine interaktive „Skybar · 24 Einzelstunden“ mit 00–23 Lokalzeit, auswählbaren Stunden und Wetterinformation zur gewählten Stunde.
- 7-/14-Tage-Datenlogik, Ensemble-/Konfidenzberechnung, Warnlogik und meteorologische Schwellen bleiben unverändert.
- Der Replit-Stand wurde dort bereits für Mobil, Tablet und Desktop sowie Light/Dark, Overflow, Tagesdetails und Bottom-Bar-Abstand geprüft; eine zusätzliche MID-Regression schützt den übernommenen Vertrag.

# MID v0.9.85.92

- Nebel wird in der Vorhersage und im aktuellen Wetter grundsätzlich nur noch bei einer Sichtweite unter 1.000 m angezeigt.
- Sichtweiten von 1 bis 8 km werden bei feuchter Luft als feuchter Dunst, Sichtweiten von 1 bis 5 km bei trockener Luft als trockener Dunst unterschieden.
- Bodennebel, Nebelbänke, partieller Nebel und Nebel in der Umgebung werden nur übernommen, wenn eine geeignete vertrauenswürdige lokale Wetterbeobachtung dies ausdrücklich meldet.
- Ein Modell-Nebelcode kann eine belastbare Sichtweite über 1.000 m nicht mehr überstimmen.
- Temperaturen unter 0 °C machen aus normalem Nebel nicht automatisch Reif- oder gefrierenden Nebel.
- Aktuelles Wetter, Kurzfrist, 24-Stunden-Profil und die daraus abgeleiteten Tagesansichten verwenden denselben Sicht- und Nebelvertrag.
- Der Hinweisbereich heißt nun neutral „Sichttrübung“ und unterscheidet vorhandenen Dunst/Nebel von einem erst prognostizierten Nebelrisiko.

# MID v0.9.85.91

- Die 14-Tage-Ansicht bleibt auf Smartphones lesbar: Tageskarten haben wieder eine stabile Breite und lassen sich horizontal durchblättern.
- „Klima“ hat in Menüs und Navigation wieder ein eindeutiges, einheitliches Symbol.
- Die amtliche DWD-Bodenanalyse ist im Kartenbereich unter „Synoptik · DWD-Bodenanalyse“ direkt auffindbar und klar von Modellkarten getrennt.
- Für Favoriten mit aktiviertem Berg- oder Wasserprofil erscheinen dezente Direktzugänge am Ortsbereich.
- Die mobile Einstellungsnavigation ist kompakter. Helles und dunkles MID-Logo werden in passenden Vorschauflächen sichtbar unterschieden.
- Darstellung, Wetterdarstellung, Inhalte & Navigation sowie Einheiten & Zeit zeigen wieder jeweils die zugehörigen Einstellungen.
- Die wirkungslosen Auswahlmöglichkeiten „Klassisch“, „Cockpit · Register“ und „Cockpit · Ribbons“ wurden entfernt; die aktuelle Vorhersageansicht bleibt eindeutig.

# MID v0.9.85.90

- Das Menü „Mehr“ ist jetzt nach Aufgaben geordnet und zeigt keine doppelten oder missverständlich mehrfach einsortierten Bereiche mehr.
- 14-Tage-Prognose und Ensemble bleiben gemeinsam im Vorhersagebereich; Wetter- und Modellkarten sind im Kartenbereich gebündelt.
- Die Einstellungen sind klarer nach Darstellung, Wetterdarstellung, Navigation, Einheiten, Orten, Benachrichtigungen, Datenqualität, Synchronisation und System gegliedert.
- Zentrale Wetter- und Warnbereiche bleiben zuverlässig erreichbar und können nicht versehentlich aus der Kernnavigation entfernt werden.
- Warnlage und Benachrichtigungen, Prognosekonfidenz und Gefahr sowie lokale Korrektur und Datenquelle sind klarer voneinander getrennt. Die missverständliche Rot-/Gelb-/Grün-Auswahl für Prognosekonfidenz entfällt.
- „Mehr“ und Einstellungen wurden für Smartphone, Tablet im Hoch- und Querformat sowie Desktop mit sicheren Abständen, kontrolliertem Scrollen und stabilen Bedienelementen abgesichert.

# MID v0.9.85.89

- Die 7-Tage-Prognose ist auf Desktop wieder als kompakte, untereinander angeordnete Tagesliste aufgebaut; der große ungenutzte Leerbereich entfällt.
- Die ausgewählte Tagesansicht erscheint nach allen sieben Tageszeilen als gemeinsame Detailfläche und verdrängt die übrigen Tage nicht mehr.
- Meteogramm-, Wasser- und Gezeitenflächen bleiben auf Smartphone, Tablet und Desktop innerhalb des Viewports; notwendige Tabellen-/Zeitachsenbereiche scrollen nur lokal.
- Touchziele, Umbrüche und Querformatdarstellung wurden für die H-Responsive-Abnahme zusätzlich abgesichert.

# MID v0.9.85.88

- Ensemble-Ansichten sind ruhiger aufgebaut; Legenden und Tooltips bleiben auch auf kleinen Displays vollständig lesbar.
- Die 14 Ensemble-Tage besitzen weiterhin individuelle Tagesinformationen zu Temperatur, Niederschlag sowie Wind/Böen; die Darstellung wurde responsiv abgesichert.
- Die Klimaansicht ordnet ihre Kennwerte auf Smartphone, Tablet und Desktop klarer und ohne unnötiges horizontales Scrollen.
- Widget-Einstellungen und Exportflächen sind kompakter, besser lesbar und behalten die bestehenden Light-/Dark- und Exportvarianten.

# MID v0.9.85.87

- Die 14-Tage-Prognose ist auf Smartphones luftiger aufgebaut: Tag, Datum und Wetterzustand erhalten mehr Platz und werden nicht mehr durch die Konfidenzanzeige zusammengedrückt.
- Die Konfidenzpille bleibt vollständig lesbar und klar als sekundäre Information getrennt.
- Wesentliche Wettertexte dürfen umbrechen statt abgeschnitten zu werden; horizontales Scrollen der Tageszeilen bleibt ausgeschlossen.
- Ensemble-, Konfidenz-, Wetter-, Skybar- und Tagesdatenlogik bleiben unverändert.

# MID v0.9.85.86

- Die Heute-Ansicht erzeugt auf Smartphones keinen zusätzlichen horizontalen Außen-Scrollbereich mehr.
- Das 24-h-Wetterprofil passt im Hochformat vollständig in die verfügbare Breite und muss nicht mehr horizontal verschoben werden.
- Die untere Zeitachse mit ihren Beschriftungen bleibt im Hoch- und Querformat vollständig sichtbar.
- Bottom Bar und Safe Areas überdecken das Wetterprofil nicht.

# MID v0.9.85.85

- Unter „Aktuell“ zeigt Wind/Böen nun denselben klaren Windrichtungspfeil wie die Detailansicht unter „Mehr“.
- Die +12-h-Temperaturdifferenz ist auf Desktop, Tablet und Smartphone räumlich klar vom Titel getrennt und bleibt in Hoch-/Querformat sowie Light/Dark gut lesbar.
- Das 24-h-Wetterprofil verwendet nur noch die stündliche Darstellung; die separate 3-h-Ansicht wurde entfernt. Auf schmalen Smartphones bleibt das Diagramm durch eine ausreichend breite, horizontal bedienbare Profilfläche lesbar.
- Die aktiven Prognosezeiträume „7 T“ und „14 T“ bleiben auf Desktop sichtbar. Die 7-Tage-Zeilen wurden gegen Überlagerungen und ineinander verschobene Inhalte stabilisiert.
- In der 14-Tage-Ansicht entfällt die gedoppelte zweite „24-Stunden-Wetter“-Zeile; die vorhandene Skybar bleibt die einzige Stundenübersicht.
- Konfidenz-Pillen erhalten mehr Mindestbreite und Innenabstand. Der Hauptwert der Sonnenscheindauer wird ganzzahlig angezeigt; P10/P90- und weitere Spannendarstellungen behalten ihre nötige Dezimalgenauigkeit.
- Meteorologische Datenquellen, Warn-/Hazard-Logik, Skybar-Fachlogik, Temperaturfarben und die hyperlokal korrigierte +12-h-Temperaturreihe bleiben fachlich unverändert.

# MID v0.9.85.84

- **Arbeitspaket F:** Radar, Satellit, Komposit, Modellkarten und Synoptik arbeiten jetzt konsequenter map-first: Die Wetterkarte erhält deutlich mehr Raum, die Bedienung tritt optisch zurück.
- Radar, Satellit und Komposit verwenden eine einheitlichere Zeit- und Playback-Sprache. Bestätigte Zeitstände sowie die Trennung von Beobachtung, Nowcast und Modell bleiben unverändert.
- Deckkraftregler sind visuell vereinheitlicht; die vorhandenen Werte bleiben weiterhin getrennt je Layer beziehungsweise Kartenprodukt gespeichert.
- Die interaktive MID-Synoptik steht nun vor der amtlichen DWD-Referenzkarte. Das DWD-Original bleibt unverändert als klar gekennzeichnete Referenz erhalten.
- Smartphone, Tablet hoch/quer und Desktop wurden für Light/Dark, Safe Areas, Bottom Bar und Overlay-Grenzen optimiert.
- Meteorologische Datenquellen, Zeitauflösungen, Farbskalen, Isobaren/Isohypsen, Fronten, Warn-/Hazard-Logik sowie die unabhängige Skybar-/Stundenquadrat-Auswahl bleiben fachlich unverändert.

# MID v0.9.85.83

- **Arbeitspaket E:** Die 7- und 14-Tage-Prognose verwenden nun dieselbe ruhige Tageszeilen-Darstellung statt unterschiedlich aufgebauter Kartenbereiche.
- Pro Tag bleiben Wochentag/Datum, Wetterzeichen, Tmin/Tmax mit ECMWF-Farben, Wetterstreifen, Niederschlag sowie Wind/Böen direkt erfassbar.
- Nur der ausgewählte Tag öffnet sich unmittelbar unter seiner Zeile; alle übrigen Tage bleiben kompakt.
- Die 7-Tage-Stundenansicht besitzt keinen zusätzlichen unabhängigen Öffnungszustand mehr. In 14 Tagen ist die bisher getrennte Detailkarte der ausgewählten Tageszeile zugeordnet.
- Die bestehende Wetter-, Warn-, Ensemble-, Niederschlags-, Wind- und Skybar-Fachlogik sowie die Datenquellen bleiben unverändert.
- Smartphone, Tablet hoch/quer und Desktop verwenden dieselbe Informationsstruktur mit angepasster Anordnung; horizontales Seitenoverflow wird vermieden.

# MID v0.9.85.82

- **D.2-Korrektur:** Die sichtbare Temperaturdifferenz vergleicht wieder ausschließlich die hyperlokal korrigierte Temperatur der aktuellen **vollen Stunde** mit dem ebenfalls hyperlokal korrigierten Wert exakt **+12 volle Stunden** später.
- Minutengenaue Startpunkte und mehrphasige Trendtexte sind entfernt; angezeigt wird nur noch eine auf ganze Kelvin gerundete Differenz T(+12 h) − T(0 h).
- Die 12-h-Zeitachse startet mit der tatsächlichen vollen Uhrzeit statt mit einem missverständlichen „Jetzt“.
- Nachtstunden sind hinter Temperaturkurve, Skybar/Stundenquadraten und im 24-h-Profil etwas deutlicher markiert, bleiben aber transparent, theme-adaptiv und untergeordnet gegenüber den meteorologischen Farben.
- Stündliche Skybar-Auflösung, Niederschlags-/Bewölkungs-/Sonnenlogik und die gemeinsame Sonnengeometrie bleiben unverändert.
- Replit hat die Korrektur einschließlich Regressionen, Typecheck, Produktionsbuild sowie Light/Dark auf 360×800, 390×844, 430×932, 768×1024, 1024×768 und 1440×900 geprüft.

# MID v0.9.85.81

- **D.2:** Der 12-h-Temperaturtrend verwendet jetzt ausschließlich die bereits kanonisch lokal beziehungsweise hyperlokal angepasste Stundenreihe. Ein isolierter Messwert wird nicht mehr als Startwert in eine anders korrigierte Kurve gemischt.
- **D.2:** Wenn die Temperatur innerhalb des 12-h-Fensters ihre Richtung deutlich ändert, zeigt MID die Entwicklung in zwei Phasen, etwa zuerst Abkühlung und danach Erholung, statt nur Endwert minus Startwert.
- **D.2:** Nachtstunden werden in der Temperaturkurve und in der Skybar beziehungsweise den Stundenquadraten dezent über dieselbe minutengenaue Sonnengeometrie hinterlegt.
- Die Nachtkennzeichnung blendet an Sonnenuntergang und Sonnenaufgang weich ein beziehungsweise aus und bleibt in Light/Dark zurückhaltend.
- Stündliche Skybar-Auflösung, Wetterfarben, Niederschlagsphase/-intensität und die zentrale Sonne-/Bewölkung-/Niederschlagslogik bleiben unverändert.
- Replit hat D.2 einschließlich Light/Dark auf 360×800, 390×844, 430×932, 768×1024, 1024×768 und 1440×900 geprüft. Veröffentlichung und Stable-Promotion erfolgen ausschließlich durch ChatGPT.

# MID v0.9.85.80

- Das 24-h-Wetterprofil verwendet eine gemeinsame Zeitbasis für Temperatur, Skybar beziehungsweise Stundenquadrate, Niederschlag, Wind/Böen, Luftdruck, Wolken und Hazards.
- Senkrechte Hilfslinien bleiben stündlich; sichtbare Zeitangaben folgen einem ruhigen Drei-Stunden-Raster.
- Die wählbaren 24-Stundenquadrate liegen jetzt auf denselben realen Zeitpositionen wie die übrigen Profilspuren; Skybar und Quadrate verwenden weiterhin dieselbe fachliche Wetterlogik ohne Normalisierung.
- Die ausgewählte Stunde wird über alle Spuren synchron markiert. Der Niederschlag wird in den Einzeldaten zusätzlich als intervallbezogene Rate in mm/h angegeben.
- Fehlende Wolkenschichtwerte werden nicht mehr als 0 % beschrieben, sondern ausdrücklich als nicht verfügbar gekennzeichnet.
- Auf schmalen Smartphones scrollt nur die Diagrammfläche intern horizontal; die Seite selbst bleibt viewportfest. Tablet und Desktop nutzen weiterhin die verfügbare Breite.
- Wetterfachlogik, Datenquellen, Warnungen, Favoriten, RUC/Nowcast, Radar/Satellit/Komposit, Ensemble, Klima und Prognoseberechnung bleiben unverändert.
- Replit hat Arbeitspaket D umgesetzt und geprüft; Veröffentlichung und Stable-Promotion erfolgen ausschließlich durch ChatGPT.

# MID v0.9.85.79

- Der überflüssig gewordene Einstellungspunkt für die dauerhaft sichtbare Bottom-Bar wurde entfernt. Die fünf Hauptziele bleiben verbindlicher Bestandteil des neuen MID-Designs.
- Die Favoriten-Schnellleiste dient nur noch zur Ortsauswahl. Ihre Reihenfolge lässt sich ausschließlich im Einstellungsmenü „Favoriten verwalten“ ändern.
- Drag-Griffe und Reorder-Logik entfallen aus der Schnellleiste; dadurch werden Favoriten kompakter, bleiben einzeilig und scrollen auf schmalen Geräten intern horizontal.
- „Aktuelles Wetter“ wurde als zusammenhängende Atmosphärenkarte weiter verdichtet: Temperatur und Wetterzustand bilden die klare Hauptaussage, Kernparameter sind als ruhige Instrumentfläche angeordnet.
- Taupunkt ist in der Feuchtehierarchie primär; relative Feuchte bleibt sekundärer Kontext.
- Der Bereich „mehr“ ist als gemeinsame Informationsfläche mit feinen Trennlinien statt vieler gleichgewichtiger Einzelkacheln aufgebaut. Dadurch sinken Fragmentierung und mobiler Platzverbrauch.
- Wetterfachlogik, Datenquellen, Warnungen, RUC/Nowcast, Skybar/24-Stundenquadrate, Radar/Karten und Prognoseberechnung bleiben unverändert.
- Replit implementiert und prüft; Veröffentlichung und Stable-Promotion erfolgen ausschließlich durch ChatGPT.

# MID v0.9.85.78

- Die fünf mobilen Hauptziele **Aktuell, Heute, Vorhersage, Karten und Mehr** bleiben dauerhaft sichtbar; das frühere Scroll-Auto-Hide der Bottom-Bar entfällt.
- Navigation über die Bottom-Bar springt ohne verzögerten Smooth-Scroll direkt in den gewählten Arbeitsbereich.
- Bottom-Bar und Favoritenleiste verwenden nun dieselbe ruhige, schwebende MID-Materialität.
- Die Favoritenleiste bleibt einzeilig. Auf schmalen Geräten scrollt sie intern horizontal, statt Ortsnamen umzubrechen oder die Seite zu verbreitern.
- Der aktive Favorit wird dezent über Rand, Hintergrundton und Signaturkante markiert, nicht mehr über eine überstarke Vollfläche.
- Die mobile Safe-Area-Reserve wurde vereinheitlicht, damit Home-Indikator, Footer und Inhalte nicht doppelt Abstand reservieren oder sich überlagern.
- Die Umsetzung wurde in Replit vorbereitet und geprüft; Veröffentlichung, Deployment und Stable-Promotion erfolgen ausschließlich durch ChatGPT über den kanonischen Releasepfad.
- Wetter-, Warn-, RUC-/Nowcast-, Skybar-/24-Stundenquadrate-, Prognose- und Kartenfachlogik bleiben unverändert.

# MID v0.9.85.77

- Warnungen sind jetzt als ruhige, zeitlich sortierte Ereignis-Timeline aufgebaut: Eine „Jetzt“-Marke trennt den aktuellen Zeitpunkt klar von laufenden und kommenden Ereignissen.
- Amtliche Warnungen bleiben fachlich führend und vollständig abrufbar; MID-Prognosehinweise sind optisch und inhaltlich klar als Ergänzung gekennzeichnet.
- Abgelaufene Warnungen erscheinen nicht mehr als aktive Ereignisse. Aktive und kommende Meldungen werden nach ihrem Beginn sortiert.
- Die Warnstufe wird ausschließlich über den farbigen Warnmarker codiert; bloße Hinweise erhalten keine amtliche Warnfarbe.
- Eine Störung der amtlichen Quelle wird ausdrücklich als „Warnstatus nicht bestimmbar“ angezeigt und niemals als Entwarnung dargestellt.
- Soweit die amtliche Meldung eine Eintrittswahrscheinlichkeit liefert, wird sie direkt am Ereignis angezeigt.
- Warnungen sind aus dem Ortskopf direkt erreichbar; „Extremwetter“ besitzt im Warnbereich einen eigenen Einstieg.
- Die neue Warnansicht wurde für schmale und breite Smartphones, Tablet Hoch-/Querformat sowie Desktop in Hell und Dunkel geprüft.

# MID v0.9.85.76

- Ein reproduzierter Veröffentlichungs-Race ist behoben: Ein bereits laufender RUC-Pages-Lauf konnte nach einem neuen App-Deploy noch den älteren `mid-stable`-App-Shell zurück auf Pages schreiben.
- RUC prüft jetzt zusätzlich, ob `main` bereits eine neuere MID-Version als `mid-stable` trägt. In diesem Releasefenster wird der RUC-Publish sicher übersprungen und erst nach Stable-Promotion mit der neuen App-Version fortgesetzt.
- Die Prüfung erfolgt zweimal: beim Eintritt in den kurzen Pages-Publish-Lock und unmittelbar vor dem Upload. Dadurch kann auch ein während der RUC-Aufbereitung gestarteter MID-Release nicht mehr durch einen älteren App-Shell-Publish überschrieben werden.
- Auch der manuelle Stable-Pages-Deploy wird blockiert, solange `main` und `mid-stable` unterschiedliche MID-Versionen tragen.
- Die RUC-Datenlogik und Parameterpriorisierung bleiben unverändert.

# MID v0.9.85.75

- Das neue MID-Redesign ist jetzt die einzige produktive Gesamtoberfläche; die bisherige Auswahl zwischen „Design 2.0.1“ und „Klassisch“ wurde aus den Einstellungen entfernt.
- Alte lokal gespeicherte Designauswahlen werden beim Start bereinigt und können die App nicht mehr auf die frühere Gesamtansicht zurückschalten.
- Bottom-Navigation und moderner Forecast-Arbeitsraum sind damit appweit verbindlich.
- **Unverändert erhalten bleibt die fachliche Auswahl „Skybar ↔ 24 Stundenquadrate“.** Beide Varianten nutzen weiterhin dieselben Einzelstunden und dieselbe meteorologische Logik.
- Standard/Erweitert, Informationsdichte, Light/Dark und die übrigen fachlichen Anzeigeoptionen bleiben unabhängig davon erhalten.

# MID v0.9.85.74

- Der RUC-Pages-Fehler oberhalb der 950-MB-Sicherheitsgrenze ist behoben: Das kostenlose RUC-Profil erhält zusätzlich ein eigenes 900-MB-Datenbudget und stoppt Übergrößen künftig bereits vor Artefakt-Upload und Pages-Publish.
- Native 15-Minuten-Zustandsdaten werden auf **Sicht und Ceiling** konzentriert. Beide können sich bei Nebel/Stratus rasch ändern und profitieren meteorologisch von der höheren Kadenz.
- Nullgrad- und Schneefallgrenze bleiben stündlich; die eigentliche Niederschlagsphase (Regen/Schnee/Graupel) bleibt separat nativ 15-minütig. Dadurch geht keine relevante kurzfristige Phaseninformation verloren.
- Die drei 15-Minuten-Solarvollfelder werden im kostenlosen Produktionspfad nicht mehr geladen bzw. auf Pages publiziert, weil der sichtbare MID-Kurzfristpfad sie derzeit nicht konsumiert.
- Der reale DWD-RUC-Lauf zeigte Gesamt-/Schichtbewölkung, Temperatur, Druck und Wind für 0…+6 h weiterhin stündlich. MID behauptet dafür deshalb keine native 15-Minuten-Auflösung; die 15-Minuten-Anzeige interpoliert diese Zustände weiterhin transparent.
- Erwartete RUC-Pages-Größe sinkt anhand des fehlerhaften Laufs von rund 1.020 MB auf rund **884 MB**; zusammen mit dem aktuellen App-Build auf rund **897 MB**.
- Der CodeQL-Hinweis „Incomplete URL substring sanitization“ in einem reinen Dependency-Audit-Test wurde als Testmuster bereinigt; Produktions-URL-Validierung war davon nicht betroffen.

# MID v0.9.85.73

- Die operative RUC-Kurzfrist verwendet nun parameter-native Zeitauflösungen statt einer pauschalen Stundenauflösung.
- Niederschlag bleibt im RUC-Pfad 5-minütig. Für 0…+6 Stunden werden Temperatur, Taupunkt/Feuchte, Druck, Wind/Böen, Gesamt-/Schichtbewölkung, Sicht, Ceiling sowie weitere kurzfristig relevante Zustandsgrößen automatisch in nativer 15-Minuten-Auflösung übernommen, **wenn der jeweilige DWD-Lauf diese Folge vollständig bereitstellt**.
- Fehlt für einen Parameter eine vollständige native 15-Minuten-Folge, bleibt dessen bisheriger stündlicher Pfad aktiv. MID kennzeichnet stündliche Werte nicht künstlich als 15-Minuten-Daten.
- 90-Minuten-Karten, Wettertext, Piktogramme und Skybar greifen gemeinsam auf den finalisierten 15-Minuten-Zustand zurück. Damit kann insbesondere native RUC-Gesamtbewölkung direkt in die Skybar einfließen, sobald sie für den Lauf in 15-Minuten-Kadenz verfügbar ist.
- Radar/Nowcast und belastbare lokale Beobachtungen behalten in ihrem verlässlichen Zeitraum Vorrang; die RUC-Zustandsfelder ergänzen die kohärente Leitprognose mit abnehmendem Gewicht bis +6 h.
- Der stündliche RUC-Zustandsvektor bleibt als robuster Fallback und für den längeren Kurzfristbereich erhalten.

# MID v0.9.85.72

- Die 15-Minuten-Kurzfrist verwendet für trockene Wettertexte und Piktogramme jetzt dieselbe Gesamtbewölkung wie die Skybar. Eine dünne/mittlere graue Wolkenstufe kann dadurch nicht mehr gleichzeitig als „Bedeckt“ beschriftet werden.
- Gesamtbewölkung ist für die Himmelsklassifikation primär; tiefe Bewölkung dient nur als Fallback, wenn Gesamtbewölkung fehlt. „Bedeckt“ setzt bei trockener Lage mindestens 87,5 % Gesamtbewölkung voraus.
- Nebel- sowie Niederschlags-/Gewittercodes bleiben von der reinen Wolkenkorrektur fachlich getrennt.
- ICON-D2-RUC CLCT/CLCL fließen weiterhin in den kanonischen stündlichen Forecastkern ein. Die 15-Minuten-Skybar interpoliert diese Zustandsfelder; sie wird nicht fälschlich als native 15-Minuten-CLCT-Ausgabe bezeichnet.
- Ein eigener Regressionstest schützt die Kohärenz zwischen Skybar, Wettertext und Piktogramm.

# MID v0.9.85.71

- Lange Ortsnamen bleiben im modernen Kopf vollständig lesbar und werden nicht mehr mit einer Ellipse abgeschnitten.
- Ein erneutes Öffnen von „Heute“ über die Bottom-Bar startet zuverlässig am Kopf der Kurzfristansicht; frühere interne Scrollpositionen werden bei dieser expliziten Navigation nicht wiederhergestellt.
- Der moderne Radar-/Satellit-Arbeitsraum wurde weiter verdichtet: weniger Rahmenabstand, kompaktere Moduswahl und Timeline, mehr visuelles Gewicht für die eigentliche Karte.
- Die produktive Radar-, Satelliten-, Nowcast-, DWD- und Synoptiklogik bleibt unverändert. Die bereits vorhandene amtliche DWD-Bodenanalyse und die getrennte MID-Modellanalyse werden ausdrücklich nicht durch Replit-Demodaten ersetzt.
- Die Änderungen sind durch einen eigenen MID-18.2.1-Regressionstest geschützt und werden über den üblichen Source-PR-/Release-Gate-Pfad ausgeliefert.

# MID v0.9.85.70

- Die 14-Tage-Ensemble-Auswahl auf Smartphones wurde verdichtet: Temperatur, Niederschlag und Wind/Böen bleiben einzeilig, die Mini-Grafiken sind deutlich größer und der vertikale Leerraum wurde reduziert.
- Der Temperatur-Mini-Plot nutzt eine stärkere, weiterhin rein visuelle Skalierung der Abweichung zum Klimamittel; die Ensemble-Daten selbst bleiben unverändert.
- Das mobile Ensemble-Detailoverlay ordnet Sekundärangaben zweispaltig statt über eine extrem schmale Labelspalte an. Begriffe wie „Sonnenscheindauer“ und „Niederschlag“ werden nicht mehr unleserlich zerbrochen; das Overlay bleibt oberhalb der Bottom-Bar und kann bei Bedarf intern scrollen.
- Die Synoptik startet als Bodenanalyse nun mit Isobaren als Standard-Modelllinien. 500-hPa-Isohypsen bleiben optional zuschaltbar.
- Kaltfronten werden blau mit Dreiecken, Warmfronten rot mit Halbkreisen und Okklusionen violett mit alternierenden Symbolen auf derselben Seite dargestellt. Symbolabstände orientieren sich an der tatsächlichen Frontlänge statt an Rasterpunkten.
- Typisierte Fronten erhalten eine stärkere, aber halo-gestützte Linienführung; neutrale θe-850-Frontalzonen bleiben visuell nachgeordnet.
- Die bestehende Frontdiagnose, θe-850-Erkennung, Isobarenberechnung, Wetterdaten und Warnlogik wurden fachlich nicht verändert.
- Replit-Redesign wurde parallel für dieselben Ensemble-/Synoptik-Probleme und die vollständige Viewport-/Light-/Dark-Abnahme fortgesetzt.

# MID v0.9.85.69

- Der 14-Tage-/Ensemble-Block wurde nach dem mobilen Screenshot-Audit weiter poliert: Die Mini-Grafiken der Umschalter „Temperatur“, „Niederschlag“ und „Wind/Böen“ liegen auf Tablet/Smartphone jetzt in einer eigenen Zeile unter dem Text und können die Bezeichnungen nicht mehr überdecken.
- Ensemble-Legenden umbrechen innerhalb ihrer Fläche, statt rechts abgeschnitten oder in den Plot gedrückt zu werden.
- Beim Schließen eines Temperatur-, Niederschlags- oder Wind/Böen-Tooltips werden aktive Recharts-Interaktionsmarker ausdrücklich unterdrückt. Beim nächsten Tippen werden sie regulär neu aktiviert; es bleiben keine Auswahlpunkte aus dem vorherigen Overlay stehen.
- Nebenlinien wie ENS-Mittel und Klimamittel erzeugen keine zusätzlichen aktiven Punkte.
- Die fachliche Ensembleberechnung, P10–P90/P25–P75-Spannen, Best-Match-Werte, Sonnenscheinband und zeitliche Auflösung bleiben unverändert.
- Responsive Ziel: keine äußere horizontale Überbreite; dichte Metrikumschalter dürfen auf sehr schmalen Geräten ausschließlich innerhalb ihrer eigenen Leiste horizontal verschoben werden.

# MID v0.9.85.68

- Der MID-18.2-Abschluss für „Ab jetzt“, 90-Minuten-Vorhersage und 24-h-Wetterprofil wurde auf die gemeinsame professionelle MID-Flächenhierarchie gebracht.
- Status, 90-Minuten-Instrument, 24-h-Profil und kompakte 24-Stunden-Leiste bleiben vollständig erhalten, sind aber klarer voneinander gegliedert und können die Seite auf kleinen Displays nicht mehr horizontal verbreitern.
- Das 24-h-Profil hält Toolbar, Legende, Diagramm, Auswahlzustand und Einzeldaten auch auf schmalen Geräten innerhalb ihrer Instrumentfläche; lange Labels und Detailtexte dürfen umbrechen statt abgeschnitten zu werden.
- Mobile Safe-Area und Bottom-Bar-Abstand werden für die Kurzfrist- und Profilflächen verbindlich berücksichtigt.
- Sichtbare Preview-/Demo-/Mockup-Entwicklungsmarker sind im produktiven Wetter-/Forecastpfad nicht vorhanden.
- Replit-Abnahme: Wetter/Aktuell, Heute/24-h-Profil, Forecast, Radar/Karten, Warnungen, Wasser/Tide und Mehr auf 390×844, 430×932, 834×1112, 1112×834 und 1440×900 jeweils Light/Dark bestanden; Typecheck, Produktionsbuild und Diff-Prüfung grün.
- Keine Änderung an Wetterdaten-, RUC-, Warn-, Radar-, Nowcast-, Tide- oder Forecast-Fachlogik.

# MID v0.9.85.67

- Der in Replit vollständig abgenommene MID-18.2-Finish für Meteogramm, Warnungen, Wasser/Tide und „Mehr“ wurde in den kanonischen MID-Build übernommen.
- Meteogramm: Diagramme bleiben die dominante Instrumentfläche; dichte Zeitreihen scrollen ausschließlich innerhalb des Diagramms, Quellen- und Steuerbereiche bleiben vollständig lesbar.
- Warnungen: amtlicher Warnstatus bleibt visuell priorisiert; Ereignisspur, ergänzende MID-Hinweise, Herkunft und lange Texte können auf mobilen Geräten nicht mehr abgeschnitten oder in Ellipsen gedrückt werden.
- Wasser/Tide: Bewertung, Tide/Pegel, Wellen, Strömung und Wetterwerte bilden eine zusammenhängende responsive Instrumentfläche; dichte Matrizen scrollen nur intern.
- „Mehr“: Schnellzugriffe und Themenmodule sind als ruhige progressive Gruppen strukturiert; auf sehr schmalen Geräten wechselt die Schnellzugriffsebene in eine einspaltige Darstellung.
- Bottom-Bar-Safe-Area sowie Light/Dark bleiben geschützt.
- Replit-Abnahme: 390×844, 430×932, 834×1112, 1112×834 und 1440×900 jeweils in Light/Dark; Typecheck und Produktionsbuild erfolgreich.
- Keine Änderung an Warnlogik, Wetterdaten, Tide-/Wasserfachlogik, Forecast, Radar oder Nowcast.

# MID v0.9.85.66

- Der in Replit vollständig geprüfte MID-18.2-Redesign-Block für Vorhersage und Karten/Radar wurde in den kanonischen MID-Build übernommen.
- Die gemeinsame Desktop-Shell verwendet nun appweit eine maximale Breite von 1580 px; Prognose- und Kartenarbeitsräume folgen derselben Breiten- und Oberflächenlogik.
- Dichte 7-/14-Tage- und Kurzfrist-Zeitreihen bleiben vollständig erhalten und scrollen ausschließlich innerhalb ihrer Instrumentflächen, statt die gesamte Seite horizontal zu verbreitern.
- Karten/Radar erhalten denselben begrenzten Arbeitsraum; Layer-, Zeit-, Status- und Quellenbereiche bleiben funktional unverändert und können auf schmalen Displays nicht mehr die Seitenbreite sprengen.
- Bottom-Bar-Safe-Area und responsive Innenränder bleiben erhalten.
- Replit-Abnahme: 390×844, 430×932, 834×1112, 1112×834 und 1440×900 jeweils in Light/Dark; Typecheck und Produktionsbuild erfolgreich.
- Keine Änderung an Forecast-, Radar-, Nowcast-, Layer-, Warnungs- oder Wetterdatenlogik.

# MID v0.9.85.65

- Der mobile Bereich „Weitere aktuelle Werte“ wurde nach dem Screenshot-Audit neu verriegelt: Überschrift/Info-Schalter, Primärwert und Detailtext liegen nun in eindeutig getrennten Zeilen und können sich auf schmalen Smartphones nicht mehr überlagern.
- UVI und EU-AQI nutzen eine eigene vierzeilige Hierarchie aus Kopf, Bewertung, Skala und Detailwert; Sonnenschein sowie Sonne/Mond folgen derselben konsistenten Ordnung.
- Auf 391–620 px bleiben die kompakten Werte zweispaltig; bis 390 px wechselt der Bereich automatisch in eine einspaltige Darstellung, statt Inhalte zu quetschen.
- Sonne/Mond erhält größere, sauber ausgerichtete Auf-/Untergangswerte und eine lesbare Mondphasenzeile.
- Die Änderung ist auf den MID-Next-„Aktuell“-Mehrbereich begrenzt; Wetterlogik, RUC/Nowcast, Warnungen und Prognosedaten bleiben unverändert.
- Parallel wurde das professionelle Redesign im Replit-Projekt „MID Weather Intelligence“ mit Fokus auf dieselbe responsive Kartenhierarchie fortgesetzt.

# MID v0.9.85.64

- Die mobile Bottom-Bar startet ohne ausdrücklich gewählten Auto-Modus fixiert sichtbar. Im Auto-Modus blendet sie erst nach einer längeren Abwärtsbewegung aus und reagiert bereits auf einen kurzen Aufwärtsscroll wieder sichtbar.
- Taps auf die fünf Hauptziele wechseln den Arbeitsbereich unmittelbar statt mit verzögertem Smooth-Scroll.
- „Weitere aktuelle Werte“ ordnet auf Smartphonebreiten Beschriftung/Info-Schalter und Messwert in getrennten Zeilen an. Lange Werte wie Wind/Böen oder Luftdruck können dadurch keine Beschriftungen mehr überdecken.
- Der 12-h-Temperaturtrend besitzt eine besser erkennbare ECMWF-farbige Linie, ein dezentes farbiges Flächenband und ein klareres Hilfsraster – ohne zeitliche Glättung oder Resampling.
- Tmin und Tmax im Aktuell-Kopf verwenden jetzt jeweils die wertbasierte ECMWF-Temperaturfarbe des tatsächlichen Werts.
- Der ICON-D2-RUC-Kurzfristaudit bestätigt: CLCT/CLCL sowie verfügbare CLCM/CLCH/VIS/CEILING laufen bereits über die kanonische Forecast-Fusion in die Kurzfrist. Eine zweite RUC-Bewölkungsmischung wird deshalb bewusst vermieden; nativer 15-min-CEILING bleibt als gezielter +0…6-h-Ausbaukandidat dokumentiert.
- Wetterdaten-, Warnungs-, Niederschlags-, Skybar-, Nowcast- und 90-Minuten-Fachverträge bleiben unverändert.

# MID v0.9.85.63

- Warnungen, Extremwetter-Ausblick und Lüftungsassistent bleiben beim Öffnen im primären Bottom-Bar-Kontext „Aktuell“; „Mehr“ wird nicht mehr irreführend als aktives Hauptziel markiert.
- Die Warnlage bleibt direkt über den Ortskopf erreichbar und zusätzlich im „Mehr“-Bereich auffindbar.
- Der kanonische Navigationsvertrag benennt nun durchgängig exakt fünf Hauptziele; die widersprüchliche Formulierung „sechs Ziele“ ist korrigiert.
- Release-, PWA-, Worker- und iOS-Versionsmarker sind auf v0.9.85.63 synchronisiert. Wetterdaten, Skybar-, Niederschlags-, Warnfach-, Nowcast- und 90-Minuten-Logik bleiben unverändert.

# MID v0.9.85.62

- Der 12-h-Temperaturtrend und die darunterliegende Skybar/Stundenquadrate verwenden jetzt exakt dieselbe horizontale Zeitbasis und dieselben Plotränder.
- Die Temperaturkurve nutzt die bereits vorhandene ECMWF-inspirierte 2-m-Temperaturpalette: kühlere Werte erscheinen blau/türkis, milde gelblich und wärmere orange/rot – ohne eine zweite Farbskala einzuführen.
- Die bisher oval verzerrt wirkenden Start-/Endmarker („Linsen“) wurden im Aktuell-Trend entfernt. Sie hatten keine zusätzliche meteorologische Bedeutung.
- Die stündlichen Hilfslinien sowie die mindestens 3-stündlichen Zeitmarken bleiben erhalten und sind nun exakt zur Skybar ausgerichtet.
- Der in v0.9.85.61 korrigierte Footer-/Bottom-Bar-Abstand bleibt unverändert: Bottom-Bar-Clearance wird nur einmal reserviert.
- Skybar-/Stundenquadrate-, Niederschlags-, Warnungs- und 90-Minuten-Fachlogik bleiben unverändert.

# MID v0.9.85.61

- Der große Leerraum zwischen dem letzten Wetterinhalt und dem App-Footer auf Smartphones wurde entfernt. Die Bottom-Bar-/Safe-Area-Reserve wird nicht mehr gleichzeitig in mehreren Layout-Ebenen sichtbar addiert.
- Der letzte Inhaltsblock folgt dem Footer wieder mit normalem MID-Seitenabstand; der notwendige Sicherheitsraum für die feste Bottom-Bar liegt ausschließlich hinter dem Footer beziehungsweise als Scroll-Padding für Fokus- und Sprungziele.
- Quellen- und Aktualitätsangaben im Prognose-Footer können auf kleinen Bildschirmen vollständig umbrechen und werden nicht mehr als abgeschnittener Einzeiler dargestellt.
- Der globale Footer reagiert auf schmale Gerätebreiten mit einer ruhigeren mehrzeiligen Anordnung für Version, Impressum und Quellen.
- Wetterdaten, Warnlogik, Skybar/Stundenquadrate und die 90-Minuten-Regel bleiben fachlich unverändert.

# MID v0.9.85.60

- Der 12-h-Temperaturtrend unter „Aktuell“ besitzt jetzt stündliche vertikale Hilfslinien und beschriftete Hauptzeitpunkte mindestens alle drei Stunden. Sichtbare Temperatur- und Trendwerte werden ganzzahlig dargestellt.
- Der aufgeklappte „Mehr“-Bereich unter „Aktuell“ ist als kompakter, klar gegliederter Informationsbereich für Atmosphäre, Umwelt und Astronomie gestaltet. Einzelwerte, UVI, Luftqualität, Sonnenschein und Sonne/Mond erhalten konsistente Flächen, Abstände und Typografie statt einer großen grauen Restfläche.
- Der erste Prognose-Untertab heißt jetzt „Ab jetzt“ statt „Kurzfrist“. Damit bleibt die Bottom-Bar „Heute“ das übergeordnete Ziel, während „Ab jetzt“ eindeutig die 90-Minuten-/24-h-Linse bezeichnet.
- Skybar-/Stundenquadrate-, Niederschlags- und 90-Minuten-Verträge bleiben fachlich unverändert.

# MID v0.9.85.59

- Favoriten reagieren auf Smartphones jetzt zuverlässig mit einem einzelnen Tap. Horizontales Wischen zum Scrollen und Ziehen am separaten Griff bleiben davon getrennt; die gesamte Favoritenkarte ist ein ausreichend großes Touchziel.
- Das MID-Logo wird im App-Kopf ohne zusätzliche Hintergrundkachel oder Schatten transparent eingebettet. Auf schmalen Geräten erscheint nur das kompakte Logo, auf breiteren Flächen weiterhin die horizontale Logo-Variante aus dem LogoSet.
- Wetterquadrate sind in den kompakten 12-h- und 90-min-Bereichen deutlich größer und klarer erkennbar.
- Sonne und Bewölkung nutzen nun innerhalb der bestehenden Skybar-Stufen deutlich unterscheidbare Gelb-/Grautöne; Niederschlagsart und -intensität bleiben an die bestehende MID-/DWD-Skybar-Logik gekoppelt.
- Der bisherige kleine Punkt für klare Nacht wurde entfernt. Klare Nacht wird nun als ruhige Flächenzelle dargestellt, damit keine zusätzliche, unklare Punktkodierung entsteht.
- Die bestehenden Verträge zu Skybar/Stundenquadraten, Niederschlagsphasen und exakt sechs vollständigen 15-Minuten-Intervallen der 90-Minuten-Kurzfrist bleiben unverändert.

# MID v0.9.85.58

- Der 12-h-Temperaturtrend unter „Aktuell“ besitzt jetzt eine klar erkennbare Zeitachse mit einfachen Hilfslinien; der Wetterstreifen ist bewusst flacher und ordnet sich der Temperaturkurve unter.
- In der 90-Minuten-Kurzfrist teilen Wetterstreifen, 15-Minuten-Zeitachse und die sechs Zeitschritt-Felder denselben horizontalen Raster- und Scrollraum. Damit bleiben Zeitpositionen auch auf schmalen Smartphones exakt synchron.
- Die sieben Tagesfelder der 7-Tage-Prognose werden im Hochformat nicht mehr in sieben Mini-Spalten gequetscht, sondern als vollständige, lesbare Tageszeilen dargestellt.
- Die bestehende stündliche Skybar-/Stundenquadrate-Logik sowie die exakt sechs vollständigen 15-Minuten-Intervalle der Kurzfrist bleiben fachlich unverändert.

# MID v0.9.85.57

- Die 90-Minuten-Kurzfrist beginnt jetzt am nächsten runden 15-Minuten-Zeitpunkt und umfasst exakt sechs vollständige 15-Minuten-Intervalle. Ein zusätzlicher Endpunkt dient nur der zeitlichen Orientierung und fließt nicht als siebtes Intervall in die 90-Minuten-Bilanz ein.
- Die gewählte Stundenanzeige „Skybar“ oder „Stundenquadrate“ gilt nun auch im 12-h-Trend unter „Aktuell“, im 24-h-Wetterprofil, in der 7-Tage-Kurvenübersicht und in den einzelnen Tageskarten.
- In der 90-Minuten-Ansicht zeigt MID die Wetterzustandsentwicklung passend zur Auswahl als 15-Minuten-Wetterstreifen oder als sechs 15-Minuten-Quadrate. Sonne, Bewölkung sowie Niederschlagsart und -intensität stammen aus derselben MID-/DWD-Logik; eine zeitliche Normalisierung findet nicht statt.
- Ortszeit und Zeitzone bleiben auf schmalen Smartphone-Breiten zusammen, sodass z. B. „GMT+2“ nicht mehr isoliert in eine neue Zeile fällt.
- Stundenquadrate skalieren in längeren Mehrtagesansichten so, dass einzelne Zellen nicht überlappen; die reduzierte Wetterzustandsleiste bleibt auch auf schmalen Geräten kompakt.

# MID v0.9.85.56

- Der mobile Radar-Nowcast in „Aktuell“ wurde neu ausbalanciert: Beschreibungstexte werden nicht mehr abgeschnitten, die 5-Minuten-Grafik erhält deutlich mehr Höhe und Achsen-, Uhrzeit- sowie Quantilangaben kollidieren nicht mehr mit den Niederschlagsbalken.
- Das technische Nowcast-Detailfenster nutzt auf Smartphones die verfügbare Breite besser. Begriffe und Werte wie „Standorttreffer“, „Wachstum/Zerfall“ oder die Mengenbasis brechen nicht mehr mitten im Wort um.
- Schriftgrößen und Zeilenhöhen im Niederschlags-/Nowcast-Bereich wurden angehoben, ohne die Karte unnötig zu vergrößern.
- Unter Einstellungen gibt es neu „Stundenanzeige“ mit den Optionen „Skybar“ und „24 Stundenquadrate“. Die bisherige Skybar bleibt Standard.
- Die Stundenquadrate verwenden exakt dieselbe MID-/DWD-Logik für Sonne, Bewölkung, Niederschlagsphase und Intensität wie die Skybar. Jede verfügbare Einzelstunde bleibt eine eigene Zelle; es gibt keine Normalisierung oder Mehrstunden-Zusammenfassung.
- Die ausgewählte Stunde wird in der Quadratansicht klar markiert; Light und Dark verwenden kontrastangepasste Zellränder.
- Alle Schutzregeln aus v0.9.85.50–55 bleiben bestehen, insbesondere Taupunkt primär, Bottom-Bar/Safe-Area, Favoriten, kein horizontaler Overflow und die vollständige stündliche Wetterauflösung.
- Keine meteorologische Datenlogik, Warnsemantik oder Niederschlagsklassifikation wurde verändert.

# MID v0.9.85.55

- Die mobile Bottom-Bar erhält eine ruhigere optische Abschlusszone und mehr Scroll-/Inhaltsreserve, ohne ihre Position oder Funktion zu verändern.
- Auf schmalen Smartphones wirken lange Inhalte dadurch weniger so, als würden sie direkt unter der Navigation weiterlaufen.
- Gezeitenereignisse werden auf kleinen Phones als horizontale Snap-Reihe dargestellt statt als gedrängtes 2×2-Raster; Werte und Zeiten bleiben vollständig lesbar.
- Header und Favoritenleiste sind flacher und ruhiger gestaltet: weniger Schatten, keine starke äußere Karten-/Pillenfassung, dafür feine Trennlinien und eine dezente aktive Markierung.
- Ortsname, Suche, Favoriten-Vollständigkeit, Favoritenverwaltung und Bottom-Bar-Signatur bleiben unverändert funktionsfähig.
- Die Schutzregeln aus v0.9.85.50–54 bleiben bestehen: Niederschlagslesbarkeit, ruhiger mobiler Kartenhintergrund, Taupunkt primär, C9-Forecast-Scroll, kein horizontaler Overflow und 24-stündige nicht normalisierte Skybar.
- Keine meteorologische Datenlogik, Tide-Zeitskala oder Warnsemantik wurde verändert.

# MID v0.9.85.54

- Aktuell, Vorhersage und Tide/Wasser wurden optisch weiter an die ruhigere Hierarchie von Meteogramm, Radar und Warnungen angeglichen.
- In „Aktuell“ bleibt die Wetter-Hauptfläche klar dominant; die nachgelagerten Metriken wirken nun als flacher Instrumentstreifen statt als zweite große Karte.
- In der Vorhersage sind ausgewählter Tag, Zeitlupe und Quellen-/Diagnostikbereich als eingebettete Sekundärsektionen gestaltet und treten hinter den eigentlichen Forecast-Flow zurück.
- Im Wasser-/Tide-Bereich werden Pegel-, Messwert- und Metadatengruppen weiter entgewichtet; Gezeitenereignisse und Wasser-/Tide-Signal bleiben visuell führend.
- Auf Smartphone, Tablet und Desktop werden starke Zusatzkonturen, Schatten und übergroße Rundungen in diesen Sekundärbereichen reduziert, ohne Informationen auszublenden.
- Die Schutzregeln aus v0.9.85.50–53 bleiben bestehen: mobile Niederschlagslesbarkeit, ruhiger Kartenhintergrund, Bottom-Bar/Safe-Area, Taupunkt primär, Favoriten, kein horizontaler Overflow und 24-stündige nicht normalisierte Skybar.
- Keine meteorologische Datenlogik, fachliche Zeitskala oder Warnsemantik wurde verändert.

# MID v0.9.85.53

- App-weite Typografie überarbeitet: Mikrotexte in Labels, Quellenstatus, Warnzeitbahn, Wasser-/Meteogramm-Metadaten und Bedienelementen erhalten eine höhere, konsistente Lesbarkeitsbasis.
- Versalsatz und Zeichenabstände werden zurückgenommen, damit die Oberfläche weniger technisch und gedrängt wirkt.
- Wichtige Status- und Wetterinformationen dürfen auf schmalen Geräten umbrechen, statt durch Ellipsen oder weitere Schriftverkleinerung verloren zu gehen.
- Bedienelemente in Vorhersage, Radar/Karten, Meteogramm und Wasser erhalten einheitlichere Schriftgrößen und Zeilenhöhen.
- Auf Touch-Geräten verhindern die wichtigsten Select-Felder mit 16-px-Schrift das automatische Safari-Zoomen beim Fokussieren.
- Die Schutzregeln aus v0.9.85.50–52 bleiben bestehen: Niederschlagslesbarkeit, ruhiger mobiler Kartenhintergrund, Bottom-Bar/Safe-Area, Taupunkt primär, Favoriten, kein horizontaler Overflow und 24-stündige nicht normalisierte Skybar.
- Keine meteorologische Datenlogik, fachliche Zeitskala oder Warnsemantik wurde verändert.

# MID v0.9.85.52

- Mobile Bottom-Bar-Freistellung app-weit vereinheitlicht: Der letzte Inhalt bleibt in Aktuell, Vorhersage, Tide/Wasser, Meteogramm, Radar/Karten und Warnungen oberhalb der fixierten Navigation plus Safe-Area erreichbar.
- Die bestehende C9-Scrollarchitektur der Vorhersage bleibt unverändert; die neue Reserve wird außerhalb der gemessenen Forecast-Arbeitsfläche gesetzt.
- Quellen-, Modell- und Aktualitätsinformationen bleiben vollständig vorhanden, treten im Normalzustand aber sichtbar hinter das Wettersignal zurück. Begrenzte, ausstehende oder gestörte Quellenzustände bleiben ausdrücklich hervorgehoben.
- Sekundärflächen werden weiter entgewichtet: 24-h-Metriken, Forecast-Detail, Warnzeitbahn, Wasser-Messwertgruppen, Meteogramm-Nebenblöcke und Radar-Zusatzsteuerungen nutzen ruhigere Hintergründe und weniger dominante Konturen.
- Schutzregeln aus v0.9.85.50/51 bleiben bestehen: Niederschlagslesbarkeit, ruhiger mobiler Kartenhintergrund, Taupunkt primär, Favoriten, kein horizontaler Overflow und 24-stündige nicht normalisierte Skybar.
- Keine meteorologische Datenlogik, Warnsemantik oder fachliche Zeitskala wurde verändert.

# MID v0.9.85.51

- Der Redesign-Schwerpunkt liegt nun app-weit stärker auf einer klaren fachlichen Primärfläche statt auf vielen gleichgewichtigen Karten.
- Vorhersage: Horizontwahl kompakter, aktive Tages-/Zeitraumflächen deutlicher hervorgehoben, Kontext- und Quellenbereiche optisch nachgeordnet.
- Meteogramm: Diagramme erhalten mehr visuelles Gewicht; Steuerung, Datenquelle und einzelne Diagrammblöcke sind als zusammenhängender Analysebereich statt als Kartenstapel gestaltet.
- Radar/Karten: Die Karte wird deutlich als Hauptarbeitsfläche priorisiert; Schnellwahl, erweiterte Layersteuerung und Legende treten optisch zurück.
- Warnungen: Warnstatus und amtliche Warnungen stehen klar vor Zeitbahn und ergänzenden MID-Hinweisen; „Quelle nicht verfügbar“ bleibt sichtbar von „keine Warnung“ getrennt.
- Tide/Wasser: Eignung sowie Tide-/Wasserinformation werden priorisiert; die zahlreichen Messwertkarten werden zu ruhigeren Gruppen zusammengeführt.
- Die Schutzregeln aus v0.9.85.50 bleiben bestehen: mobile Niederschlagslesbarkeit, ruhiger Kartenhintergrund, Bottom-Bar/Safe-Area, Taupunkt primär, Favoriten, kein horizontaler Overflow und 24-stündige nicht normalisierte Skybar.
- Keine meteorologische Datenlogik, fachliche Zeitachse oder Warnsemantik wurde verändert.

# MID v0.9.85.50

- Die mobile Niederschlagsfläche in „Aktuell“ ist wieder vollständig und ruhig lesbar: Beschriftung und Hauptwert stehen klar getrennt, die Zusammenfassung erhält die volle verfügbare Breite und Quellen-/Detailtext wird nicht mehr abgeschnitten.
- Die bisherige enge 104-Pixel-Aufteilung des trockenen Niederschlagsstatus entfällt auf Smartphones; die Darstellung bleibt kompakt, ohne Text oder Werte zusammenzuquetschen.
- Die rein dekorative helle Ecke im oberen Bereich der aktuellen Wetterkarte wird auf Smartphones entfernt. Hinter Temperatur, Beschreibung und Messwerten liegt nun eine ruhige, kontrastreiche Fläche.
- Die 24-Stunden-Skybar bleibt vollständig stündlich und unverändert unnormalisiert. Bottom-Bar/Safe-Area, Favoriten sowie Taupunkt als primärer Feuchteparameter bleiben erhalten.
- Replit-Sichtprüfung: 390×844 und 430×932 jeweils Light/Dark sowie Tablet hoch/quer und Desktop bestanden.

# MID v0.9.85.49

- Die mobile Vorhersage erhält einen eigenen, sauber begrenzten Scrollbereich oberhalb der dauerhaft sichtbaren Bottom-Bar. Tageskarten und Detailinhalte werden dadurch nicht mehr von der Navigation überdeckt.
- Die verfügbare Höhe wird aus der tatsächlichen Position der Bottom-Bar berechnet und bei Größen- oder Layoutänderungen neu angepasst; iOS-Safe-Area und unterschiedliche Smartphone-Höhen werden berücksichtigt.
- Favoriten, Ortskopf und die bereits reparierte Niederschlagsdarstellung bleiben unverändert sichtbar; es entstehen keine zusätzlichen unbegründeten Leerflächen.
- Taupunkt bleibt der primäre Feuchteparameter, die relative Feuchte nachgeordnet. Die Skybar bleibt vollständig stündlich mit 24 Positionen und wird nicht normalisiert.
- Light/Dark und die bestehenden meteorologischen Datenpfade bleiben unverändert; die Korrektur betrifft die mobile Komposition und Scrollgrenze.

# MID v0.9.85.48

- MID-C9 schließt den Smartphone-Blocker aus Ortskopf und Nowcast: Standort und Warnlage konkurrieren nicht mehr mit der aktuellen Niederschlagsfläche um dieselbe Grid-Zeile; lange Ortsnamen bleiben horizontal lesbar.
- Favoriten bleiben auf schmalen Geräten vollständig horizontal erreichbar, während der Verwaltungszugang außerhalb der Scrollfläche sichtbar bleibt.
- Der echte Platzbedarf der schwebenden Bottom-Bar einschließlich iOS-Safe-Area wird reserviert. Inhalte, Skybar-Beschriftungen und Nowcast lassen sich dadurch vollständig oberhalb der Navigation erreichen, ohne horizontalen Seitenüberlauf.
- Taupunkt ist in der kompakten Hauptkarte eindeutig der Primärwert; die relative Feuchte bleibt als nachgeordnete Zusatzinformation erhalten.
- Die Änderung ist ausschließlich grafisch. MID verwendet unverändert seine kanonischen Echtzeit-, Nowcast- und Stundenreihen; Replit-Vorschauwerte wurden nicht übernommen.

# MID v0.9.85.47

## v0.9.85.90 · 2026-09-22

- **Mehr klarer geordnet:** Das Menü folgt jetzt einer einzigen Aufgabenlogik ohne missverständliche Zähler oder doppelte Wege zu Prognose und Karten.
- **Einstellungen neu sortiert:** Darstellung, Wetterdarstellung, Navigation, Einheiten/Zeit, Orte/Profile, Benachrichtigungen, Datenqualität, Synchronisation und System sind getrennt.
- **Kernnavigation geschützt:** Aktuell, Warnungen, Heute, Vorhersage und Karten bleiben erreichbar, auch wenn optionale Module ausgeblendet werden.
- **Fachbegriffe geschärft:** Warnlage und Push-Benachrichtigung, Vorhersagekonfidenz und Gefahr sowie lokale Korrektur und Datenquelle werden klar getrennt.
- **Mobil bis Desktop geprüft:** Mehr und Einstellungen verwenden einen kontrollierten Scrollbereich und berücksichtigen Hoch-/Querformat sowie Safe Areas.

## Design 2.0.1 · 12-h-Temperaturtrend wissenschaftlich nachgeschärft

- Die 12-h-Kurve unter „Aktuell“ ist nicht mehr nur beschriftet, sondern wird jetzt auch **skalentreu und zeitlich ehrlich** dargestellt.
- Der linke Punkt ist am tatsächlich angezeigten aktuellen Temperaturwert verankert; die weiteren Punkte bleiben die vorhandenen stündlichen MID-Prognosewerte.
- Zusätzlich wird die Temperaturänderung bis zum Ende des Fensters als Richtung und Delta in Kelvin angezeigt.
- Die Kurve verwendet mindestens **4 K Darstellungsbereich**. Kleine Änderungen von z. B. 0,5–1 K werden dadurch nicht mehr künstlich über die gesamte Diagrammhöhe aufgeblasen.
- Die gestrichelte Referenzlinie liegt auf dem aktuellen Temperaturwert statt auf einer bedeutungslosen geometrischen Mitte.
- Fehlende Stunden werden nicht mehr optisch überbrückt: Datenlücken unterbrechen die Linie, statt eine scheinbare Zwischenentwicklung zu erzeugen.
- Die 13 Stundenpositionen von jetzt bis +12 h bleiben erhalten; fehlende Werte werden nicht herausgefiltert und dadurch zeitlich zusammengeschoben.
- Taupunkt bleibt der primäre Feuchtewert, relative Luftfeuchte die sekundäre Zusatzinformation.
- Klassisch, Wetterlogik, Skybar, RUC/Nowcast, Warnungen und Datenquellen bleiben unverändert.

# MID v0.9.85.46

## Design 2.0.1 · kritischer iPhone-Pass und aussagekräftiger 12-h-Wetterfaden

- Der bisher nahezu dekorative 12-h-Temperaturfaden wurde fachlich und visuell aufgewertet: Er zeigt nun **Jetzt**, einen mittleren Zeitanker und das Ende des 12-Stunden-Fensters jeweils mit Temperaturwert.
- Das Fenster umfasst exakt **Jetzt bis +12 Stunden** und verwendet dafür 13 vorhandene stündliche Temperaturpunkte. Es werden keine Zwischenwerte erfunden oder zeitlich verschoben.
- Die markierte Messposition liegt jetzt korrekt am **aktuellen** Stundenwert; der frühere hervorgehobene Punkt am rechten Ende konnte fälschlich wie ein aktueller Messpunkt wirken.
- Zusätzlich werden Min/Max der nächsten 12 Stunden kompakt ausgewiesen; die Kurve bleibt bewusst schlicht und datengetreu.
- Taupunkt bleibt im Hauptbereich der primäre Feuchteparameter; relative Luftfeuchte ist die sekundäre Zusatzinformation.
- Trockene Kurzfristlagen werden als kompakte Statuszeile statt als zweite große Karte dargestellt.
- Die geöffneten Zusatzwerte wurden weiter verdichtet: UVI und Luftqualität erhalten kollisionsfreie volle Breite, Sonnenschein sowie Sonne/Mond sind kompakte Zeilen, Beschriftungen werden nicht mehr unnötig abgeschnitten.
- Der Warnstatus im Ortskopf wird auf kleinen Geräten vollständig im Viewport gehalten.
- Die Bottom-Bar blendet bei Abwärtsscrollen früher aus und erscheint erst nach einem deutlicheren Aufwärtsscrollen wieder, damit sie laufende Inhalte weniger verdeckt.
- Klassisch, Skybar, Warnlogik, Modellfusion, RUC/Nowcast und Datenquellen bleiben fachlich unverändert.

# MID v0.9.85.45

## Design 2.0.1 · iPhone-QA und Feinschliff „Aktuell“

- Die mobile Aktuell-Ansicht wurde anhand der realen iPhone-Darstellung erneut kritisch überarbeitet.
- **Taupunkt steht jetzt vor der relativen Luftfeuchte**: In den vier Kernwerten wird der Taupunkt in °C groß angezeigt, die Feuchte in % bleibt als Sekundärwert erhalten.
- Der Ortskopf wurde korrigiert: Der Warnstatus bleibt vollständig im Viewport und soll „Keine Warnung“ nicht mehr abschneiden.
- Die vier Kernwerte wurden auf normalen iPhones in eine kompakte Viererzeile verdichtet; nur auf sehr schmalen Geräten fällt MID auf 2×2 zurück.
- UVI und Luftqualität erhalten volle Breite, damit Einstufung, Info-Schaltfläche und Skalen nicht mehr miteinander kollidieren.
- Sonne/Mond und Sonnenscheindauer wurden als kompakte Zeilen neu gewichtet; der große blaugraue Leerraum der geöffneten Zusatzwerte entfällt.
- Sichtbare Info-Schaltflächen bleiben klein, die Touchfläche bleibt ausreichend groß.
- Der doppelte untere Sicherheitsabstand wurde entfernt; dadurch verschwindet der übergroße Leerraum zwischen Footer und Bottom-Bar. Die Navigation bleibt weiterhin safe-area-sicher.
- Klassisch, meteorologische Fachlogik, Warnschwellen, Modelle, Skybar und Datenquellen bleiben unverändert.

# MID v0.9.85.44

## Design 2.0.1 · mobile Aktuell-Ansicht deutlich nachpoliert

- Der erste produktive Design-2.0.1-Transfer wurde anhand der iPhone-Screenshots korrigiert: Die Aktuell-Ansicht ist jetzt als eine zusammenhängende Wetter-/Instrumentenfläche aufgebaut statt als große, fast leere Karte.
- Wetterpiktogramm, Temperatur, Wetterzustand, Tmin/Tmax und 12-h-Wetterfaden wurden enger und klarer hierarchisiert.
- Tmin/Tmax ist keine großflächige weiße Überlagerung mehr, sondern eine kompakte Inline-Angabe.
- Die vier unmittelbar sichtbaren Kernwerte sind wieder klar lesbar und in einer kompakten 2×2-Matrix angeordnet.
- Zusatzparameter wurden zu einem ruhigen Datenfeld verdichtet; sichtbare Info-Schaltflächen bleiben klein, besitzen auf Touch-Geräten aber weiterhin eine 44-px-Trefferfläche.
- Kopf, Suche und Favoritenleiste wurden mobil verkleinert und an die Materialität der Bottom-Bar angeglichen.
- Die Bottom-Bar wurde niedriger und leichter gestaltet; zugleich wurde der untere Inhaltsabstand vergrößert, damit abschließende Inhalte vollständig oberhalb der Navigation erreichbar bleiben.
- Eigene Regeln für schmale iPhones, Smartphone-Querformat und Tablet-Hochformat schützen die neue Komposition.
- Klassische Ansicht, Wetterlogik, Datenquellen, Warnschwellen und Modellfusion bleiben unverändert.

# MID v0.9.85.43

## Design 2.0.1 · Heute und 24-h-Wetterprofil

- „Heute“ erhält im neuen Designpfad eine zusammenhängende meteorologische Arbeitsfläche: 90-Minuten-Kontext oben, darunter das vollständige gleitende 24-h-Wetterprofil als dominantes Instrument.
- Das Profil läuft weiterhin exakt von jetzt bis +24 Stunden auf einer gemeinsamen Zeitachse für Wetter, Temperatur, Niederschlag, Wind/Böen, Luftdruck, Bewölkung, Sonnenereignisse und Einschränkungen.
- Die Skybar bleibt in jedem Darstellungsmodus **stündlich aufgelöst**. Die optionale 3-h-Ansicht verdichtet nur Kurven, Marker und Beschriftungen; die Skybar wird nicht gemittelt, interpoliert oder zeitlich verschoben.
- Legende, Zeit-Lupe/Einzeldaten und Signale wurden grafisch beruhigt und auf Mobil, Tablet hoch/quer und Desktop neu gewichtet.
- Die klassische Oberfläche und sämtliche meteorologischen Fachverträge bleiben unverändert.

# MID v0.9.85.42

## Design 2.0.1 · Aktuell, Kopf und Favoriten

- Die neue Oberfläche erhält einen deutlich kompakteren, professionellen Kopf mit responsivem Original-MID-Logo, ruhiger Suche und einer Favoritenleiste im gleichen Instrumentenstil.
- „Aktuell“ wird zu einer zusammenhängenden Wetterfläche: Wetterzeichen, Temperatur und Zustand stehen klar im Vordergrund; vier Kernwerte bleiben direkt sichtbar.
- Ein dezenter 12-Stunden-Temperaturfaden ergänzt die aktuelle Lage. Er verwendet ausschließlich die bereits vorhandenen stündlichen MID-Werte und verändert keine Prognosedaten.
- Niederschlags-/Gefahrenlage und Datenstatus bleiben in derselben Arbeitsfläche integriert; zusätzliche Messwerte werden als sekundäre Instrumentfläche dargestellt.
- Mobil, Tablet hoch/quer und Desktop erhalten eigene Anordnungen, ohne die klassische Oberfläche zu verändern.
- Meteorologische Logik, Warnschwellen, Skybar-Auflösung, Modellfusion und Datenquellen bleiben unverändert.

# MID v0.9.85.41

## Design 2.0.1 parallel zur klassischen Oberfläche

- MID besitzt jetzt zwei klar getrennte Darstellungswege: **Klassisch** behält die bisherige Dashboard-Struktur und Navigation, **Design 2.0.1** nutzt die neue responsive Arbeitsflächen- und Bottom-Navigation.
- Der Umschalter in den Einstellungen ändert nur Darstellung und Navigation. Ort, Favoriten, Wetterdaten und Fachlogik bleiben gemeinsam und werden nicht neu erfunden oder dupliziert.
- Die Redesign-Styles der bereits umgesetzten Arbeitsflächen sind auf Design 2.0.1 begrenzt, damit spätere grafische Änderungen die klassische Oberfläche nicht unbeabsichtigt verändern.
- Ohne bereits gespeicherte Auswahl startet MID vorerst sicher in **Klassisch**. Die neue Oberfläche kann jederzeit persistent gewählt werden.
- Meteorologische Logik, Skybar-Zeitauflösung, Warnschwellen, Modellfusion, Parameterfarben und Datenquellen bleiben fachlich unverändert.

# MID v0.9.85.40

## MID-C9 · Prognose- und Kartenflächen weiter poliert

- Die 7-Tage-Vorhersage bleibt auf Smartphones ein kompaktes horizontales Tagesband. Die frühere lange Einspaltenliste entfällt; Stundendetails öffnen weiterhin direkt im selben Arbeitsraum.
- Die Parameterwahl der 14-Tage-Ensembleansicht ist eine ruhige, zusammenhängende Instrumentleiste. Touch-Tooltips zeigen ihre vollständigen Werte mit größerer, lesbarer Schrift und sicherem Bildschirmrand.
- Karten-Layer bleiben auf kleinen Displays in einer horizontal bedienbaren Werkzeugleiste. Die Kartenhöhe passt sich in Hoch- und Querformat besser an, während Zeitachse, Legende und mindestens 44 px große Touchziele erreichbar bleiben.
- Wetterdaten, Ensemblewerte, Parameterfarben, Kartenebenen und die DWD-Georeferenzierung bleiben fachlich unverändert.

# MID v0.9.85.39

## MID-C9 · Mobile Layoutkorrektur nach Screenshots

- Aktuell: vier Kernparameter tatsächlich als 2×2-Raster; alte übergreifende Zellbelegungen zurückgesetzt. Wetterkopf, Quellenzeile und Niederschlagsinformation kompakter; doppelte Freifläche vor dem Footer reduziert.
- Kurzfrist: alle Zeitpunkte bleiben in genau einer horizontal scrollbareren Zeile. Die feste Sechs-Spalten-Begrenzung entfällt, auch der siebte Zeitpunkt bleibt oben.
- Favoriten: einzeilige Anordnung mit klarer Auswahl, separater Verwaltung und einmaliger Standard-Kennzeichnung; keine überlagerten Grid-Bereiche oder doppelte Abkürzung.
- Aktiver Kurzfrist-Schalter mit lesbarem Textkontrast. Wetterwerte, Quellen und Bedienfunktionen bleiben erhalten.

# MID v0.9.85.38

## MID-C9 · Einheitlicheres Design und ruhigere Bildsteuerung

- Die 90-Minuten-Vorschau bildet eine durchgehende Zeitleiste mit klar hervorgehobenem Zeitpunkt.
- Auf Tablets passen Seitenleiste und Inhaltsabstand zusammen; auf großen Bildschirmen sind die Navigationsziele wieder beschriftet. Lange Ortsnamen bleiben lesbar.
- „Mehr“ erhält übersichtliche Einstellungszeilen und einen beim Scrollen erreichbaren Kopf. Flächen und Abstände sind ruhiger und einheitlicher.
- Das DWD-Originalbild lässt sich in feineren Schritten von 50 bis 500 Prozent zoomen. Der betrachtete Ausschnitt bleibt beim Zoomen erhalten; „Standort“ und „100 %“ führen gezielt zurück.
- Verzögerte Zentrierungssprünge entfallen. Die eingebettete Originallegende wird nicht mehr durch allgemeine Bildgrößenregeln verkleinert.
- Wetterwerte, Warnschwellen, Parameterfarben und die bisherige geografische Bildkalibrierung bleiben unverändert.

# MID v0.9.85.37

## DWD Wolken/Niederschlagsart wieder standorttreu zentriert

- Der zoombare Ausschnitt des amtlichen DWD-Originalbilds wird nach Öffnen, Größenänderung und Bildladen wieder zuverlässig auf den tatsächlich gewählten Standort zentriert.
- Die seit v0.9.76.11 an 17 sichtbaren DWD-Stadtankern kalibrierte Georeferenzierung bleibt unverändert; korrigiert wurde die mobile Darstellungs- und Zentrierungslogik.
- Der Standortmarker besitzt jetzt einen eindeutigen exakten Ankerpunkt statt eines plattformabhängigen Emoji-Pins. Zusätzlich gibt es einen direkten „Standort“-Knopf zum erneuten Zentrieren, ohne den gewählten Zoom zu verlieren.
- Der Bildausschnitt wird während der Zentrierung nicht mehr durch eine Breitenanimation verschoben. Die Originallegende bleibt erhalten, nimmt auf kleinen Displays aber weniger Kartenfläche ein.

# MID v0.9.85.36

## Heute: 24-h-Diagramm wieder in passenden Proportionen

- Das 24-h-Wetterprofil war auf schmalen Smartphone-Displays zuletzt sichtbar zu hoch gestreckt. Die vertikale Diagrammgeometrie wird jetzt responsiv verdichtet, während alle Wetterspuren, Skalen, Zeitbezüge und Warnschwellen erhalten bleiben.
- Überschrift und Kurzfristtexte umbrechen wieder sauber statt am rechten Rand abgeschnitten zu werden. Der Zusatztext der 90-Minuten-Leiste entfällt auf sehr schmalen Displays, wenn er nur bereits sichtbare Informationen wiederholt.
- Das amtliche DWD-Originalprodukt bleibt vollständig verfügbar, startet in „Heute“ jetzt aber zuverlässig geschlossen und öffnet die große Bildfläche nur nach einer bewussten Nutzeraktion. Die Klappzeile bleibt auch im Dark Mode auf der regulären dunklen MID-Fläche statt in eine helle Ersatzfläche zu kippen.
- Smartphone, Tablet und Desktop verwenden weiterhin dieselben meteorologischen Daten und dieselbe 24-h-Zeitlogik; geändert wurden ausschließlich Proportionen, Textfluss und progressive Darstellung.

# MID v0.9.85.35

## Heute ruhiger und kompakter

- Das amtliche DWD-Bild „Wolken + Niederschlagsart“ bleibt vollständig verfügbar, öffnet sich in „Heute“ aber erst auf Wunsch. Dadurch dominiert das Originalbild nicht mehr den 24-Stunden-Verlauf und lädt erst beim Öffnen.
- Das 24-h-Wetterprofil benötigt auf Smartphones weniger Höhe oberhalb des Diagramms: Drucktrend und weitere Signale liegen kompakt in einer horizontalen Leiste; Auflösung, Legende und Info bleiben erreichbar.
- Breite Diagramme, Hilfetexte und das geöffnete DWD-Original bleiben an ihren eigenen Viewport gebunden. Die fachlichen Wetterspuren, DWD-Warnschwellen, Parameterfarben, Quellen und Zeitlogik wurden nicht verändert.

# MID v0.9.85.34

## Karten nutzen den Bildschirm als Arbeitsraum

- Radar, Satellit, Nowcast und Synoptik bekommen auf Smartphones, Tablets und Desktop deutlich mehr zusammenhängende Kartenfläche. Überschriften, Umschalter und Zeitleiste treten gegenüber der Karte zurück.
- Die Kartenzeit bleibt eine gemeinsame, durchgehende Steuerung. Beobachtungen, Nowcast und Modelltermine werden weiterhin fachlich getrennt gekennzeichnet, ohne zusätzliche doppelte Zeitauswahl.
- In den DWD-Wetterkarten bleiben nur Modell und Kartenprodukt direkt sichtbar. Druckfläche beziehungsweise Höhe, Kartenbasis, Deckkraft sowie Quellen- und Laufdetails sind bei Bedarf einklappbar erreichbar.
- Der Startbereich auf Smartphones ist nochmals verdichtet: Kopf, Suche, Favoriten, Ortskopf und aktuelle Kernwerte folgen jetzt tatsächlich der Redesign-Hierarchie statt von älteren Layoutregeln wieder vergrößert zu werden.
- Das Impressum bleibt auch im Smartphone-Hochformat vollständig innerhalb des Displays; der Schließen-Button bleibt jederzeit erreichbar.
- Zoombare DWD-Originalbilder und breite Diagramme dürfen nur noch innerhalb ihrer eigenen Darstellungsfläche wachsen oder scrollen und nicht mehr die gesamte App über den Displayrand hinaus verbreitern.
- Die gemeinsame Kartenzeitachse ist für einen späteren fachlich gekennzeichneten Übergang von echten Satellitenbeobachtungen zu modellbasierten Pseudo-Satellitenbildern vorbereitet. Solche Zukunftsbilder werden erst angezeigt, wenn dafür reale Modellprodukte angebunden sind; MID erzeugt keine künstlichen Zwischenbilder.
- Datenquellen, Modell-/Nowcastlogik, Warnregeln, meteorologische Ebenen und Farbcodierungen wurden dabei nicht verändert.

# MID v0.9.85.33

## Kompakter Startbereich auf Smartphones

- Ort und Warnstatus stehen wieder direkt vor dem aktuellen Wetter statt am Ende des Abschnitts.
- Der mobile Kopf ist deutlich kleiner und scrollt mit der Seite. Suche und Favoriten bleiben am Seitenanfang verfügbar, während die kompakte Bottom-Navigation dauerhaft erreichbar bleibt.
- „Mehr“ blendet ergänzende aktuelle Werte jetzt tatsächlich ein und aus. Geöffnete Zusatzwerte erscheinen als ruhige Detailliste statt als Kachelmatrix.
- Aktuelles Wetter, Radar-Nowcast und Quellenhinweis benötigen auf kleinen Displays weniger Höhe. Meteorologische Daten, Parameterfarben, Warnlogik und Quellenbewertung bleiben fachlich unverändert.

# MID v0.9.85.32

## Vorhersage als zusammenhängender Arbeitsraum

- Die 7-Tage-Vorhersage führt nun zuerst den Wetterverlauf; die Tage bilden darunter ein zusammenhängendes Band statt einzelner gleichgewichteter Karten.
- Stündliche Details erscheinen direkt beim gewählten Tag und bleiben Teil derselben Vorhersagefläche.
- Die 14-Tage-Ansicht bleibt ensemblegestützt, zeigt die Tage aber als fortlaufende Spalten. Unsicherheit, Modellkonsistenz, Wetterpiktogramme und Parameterfarben bleiben erhalten.
- Smartphone-, Querformat-, Tablet- und Desktopansichten wurden so abgestimmt, dass Auswahl, Texte und Detailbereiche ohne abgeschnittene Inhalte bedienbar bleiben.

# MID v0.9.85.31

## Heute als durchgehender 24-h-Wetterfaden

- Wetterfaden und 24-h-Zeitmatrix bilden eine zusammenhängende Wetterfläche.
- Einzelne Zeitpunkte zeigen zusätzliche Details erst nach Auswahl; auf Mobilgeräten bleibt die Detailansicht oberhalb der schwebenden Navigation.
- Nowcast-/RUC-Zeitlogik, DWD-Niederschlagsart, Warnungen, Wetterpiktogramme und Parameterfarben bleiben fachlich unverändert.

# MID v0.9.85.30

## Aktuell klarer gegliedert

- Der Ortsbereich ist nun ein kompakter Kontextkopf statt einer zusätzlichen Wetterkarte.
- Die aktuelle Wetterfläche bleibt die fachliche Primärdarstellung; doppelte Niederschlags- und Hazard-Angaben im Ortskopf wurden entfernt.
- Vier Kernparameter stehen sichtbar im Vordergrund. Ergänzende Messwerte bleiben erreichbar, wiederholen die Kernwerte aber nicht noch einmal gleichrangig.
- Mobile Safe-Areas, Bottom-Bar-Abstände, Suche und Favoriten wurden für die kompakte Darstellung weiter abgesichert.

# MID v0.9.85.29

## MID-C9 · durchgehender Kartenzeitraum

- Die Kartenzeitachse führt bestätigte Radar- und Satellitenbeobachtungen, amtliche Nowcast-Stände und die real verfügbaren Modelltermine in einer durchgehenden Reihenfolge zusammen.
- Der Wechsel in einen Modelltermin verlangt keinen separaten Ansichtsschalter mehr: Die Karte zeigt dort automatisch Isobaren und 500-hPa-Isohypsen und kennzeichnet den Stand eindeutig als „Modell · Synoptik“.
- Radar, Satellit und Blitze enden weiterhin an ihren echten Produktzeiten. MID erzeugt keine optischen Übergangsbilder und keine Radar- oder Satellitenprognose.

# MID v0.9.85.28

## MID-C8 · sichtbarer Konzeptumbau

- MID Next ordnet den Startbereich jetzt als zusammenhängende Wetterbühne: Ortslage, Wetterkern und Messwerte sind klar getrennte Ebenen statt einer Folge gleichrangiger Kacheln.
- Kopf, Ortsschnellzugriff und Navigation folgen dem Konzeptbild als kompakte Kontrollflächen. Die schwebende Bottom-Bar bleibt auf Mobilgeräten erreichbar; die fachlichen Wetterflächen bleiben bewusst ruhig und ohne dekoratives Glas.
- Kurzfrist, Vorhersage und Karten verwenden weiterhin ihre echten Zeit- und Produktdaten, erscheinen aber als durchgehende Arbeitsflächen statt als gestapelte Einzelkarten.

# MID v0.9.85.27

## MID-C7 · sichtbare Konzeptkorrekturen

- Die Bottom-Bar markiert nun immer genau einen Hauptbereich. `Heute` und `Vorhersage` können nicht mehr gleichzeitig aktiv sein.
- Eine lokale Speicherquota wird automatisch und datenerhaltend bereinigt; die technische Browsermeldung erscheint nicht mehr zwischen Wetterinhalten.
- Die Kurzfristdarstellung ist jetzt eine fortlaufende Zeitmatrix statt einer Reihe einzelner Wetterkacheln. Zeit, Wetter, Temperatur, Niederschlag und Wind folgen derselben festen Hierarchie.

# MID v0.9.85.26

## MID-C7 · Kartenarbeitsraum

- Karten sind nun klarer als eigener Arbeitsbereich aufgebaut: Livebild, Analyse und Ebenen lassen sich ruhiger unterscheiden, ohne die Farben der amtlichen und meteorologischen Produkte zu verändern.

# MID v0.9.85.25

## MID-C7 · verlässliche Darstellung auf allen Bildschirmgrößen

- MID prüft Navigation, sichere Bildschirmränder und die Trennung der Arbeitsbereiche nun zusätzlich gegen typische Handy-, Tablet- und Desktopgrößen. Spätere Änderungen können diese Darstellung nicht unbemerkt verschieben.
- MID Next erhält eine sichtbar zusammenhängende Arbeitsfläche: Ortskopf und Kernaussage stehen im Vordergrund, die Zeitauswahl ist klar abgesetzt und Karten sowie Planer erscheinen als ruhige, eigenständige Arbeitsräume.

# MID v0.9.85.24

## MID-C7 · zuverlässige Aktualisierung

- Eine bereits geladene neue MID-Version übernimmt jetzt auch dann zuverlässig, wenn die App während des Releases geöffnet war. Beim nächsten sicheren Wechsel aktiviert MID den wartenden App-Cache und lädt die neue Oberfläche, ohne Orte oder persönliche Einstellungen zu löschen.

# MID v0.9.85.23

## MID-C7 · fokussierte Arbeitsbereiche

- MID Next startet bei **Aktuell** mit einer verdichteten Übersicht. Weitere Messwerte bleiben über **Mehr** jederzeit verfügbar und die persönliche Wahl wird wie bisher auf dem Gerät gespeichert.
- **Vorhersage**, **Karten** und **Planen** besitzen nun jeweils eine eigene sichtbare Arbeitsfläche. Die Horizontleiste erscheint nur in der Vorhersage; Planer-Inhalte erscheinen nur im Planen-Bereich.
- Die Navigation bleibt auf Desktop, Tablet und Smartphone vollständig erreichbar. Insbesondere wird die Desktop-Leiste nicht mehr aus dem sichtbaren Bereich verschoben.

# MID v0.9.85.22

## MID-C6 · fehlend ist nicht klar

- Fehlende Wolken- oder Tiefwolkenwerte werden in Vorwärtsintervallen, kurzzeitiger Ortsanpassung und der zentralen Nowcast-/RUC-Endstufe nicht mehr als 0 % Bewölkung gelesen. Ohne belastbare Wolkeninformation bleibt die trockene Darstellung neutral statt einen klaren Himmel zu behaupten.
- Die operative Radar-Mengenanpassung wendet ihren Trockenluft-Abschlag nur noch bei tatsächlich vorhandener niedriger und Gesamtbewölkung an. Fehlende Wolkenfelder erzeugen damit weder eine zusätzliche Entwarnung noch Niederschlag.

# MID v0.9.85.21

## MID-C6 · 90-Minuten-Nowcast und RUC-Abgleich

- Ein frischer, trockener DWD-Radarabschnitt unterdrückt in jeder betroffenen 15-Minuten-Karte Menge, Niederschlagsart und Regen-Piktogramm. Eine entfernte Zelle bleibt damit keine ortsfeste Regenmeldung.
- Trockene DWD-ICON-D2-RUC-Kurzfristwerte können die Modell-Restwahrscheinlichkeit nun auch absenken; sie erzeugen bei 0,0 mm keinen Regen-Code. Direkte Radar-Beobachtungen behalten im Nowcast-Fenster Vorrang.

# MID v0.9.85.20

## MID-C6 · aktueller Niederschlagsabgleich

- Ein frischer DWD-Radarwert von 0 mm/h gilt jetzt ausdrücklich als trockener Standortbefund. MID fällt dann weder auf einen älteren Modell-Schauercode zurück noch zeigt es eine davon abgeleitete Intensität.
- Bei realem Radarsignal bleiben Art und Intensität unverändert aus dem geprüften, aktuellen Niederschlagszustand abgeleitet.

# MID v0.9.85.19

## MID-C6 · Schritt 4: ein Prognose-Arbeitsraum

- Im neuen Bedienkonzept sind Kurzfrist, 7 Tage und 14 Tage jetzt stets eine gemeinsame Prognosefläche. Der gewählte Horizont wechselt ohne doppelte Kartenstapel oder einen zusätzlichen Einstellschritt.
- Die fünfteilige Horizontleiste steuert diese Fläche direkt; gewählte Tage, horizontale Positionen und die Detailansicht bleiben beim Wechsel erhalten.
- Die klassische Darstellung außerhalb des Redesigns bleibt unverändert verfügbar.

# MID v0.9.85.18

## MID-C5 · verifizierte K3D-Zugspuren

- Eine gestrichelte K3D-Zugspur, Zeitstempel und der Unsicherheitskorridor werden ausschließlich aus mindestens zwei zeitlich getrennten, amtlichen KONRAD3D-Prognosepunkten erzeugt. Geschwindigkeit und Richtung allein werden nicht mehr zu einer Route hochgerechnet.
- K3D-Objekte werden nur mit bestätigtem, frischem Beobachtungszeitpunkt gezeigt. Unbekannte oder alte Datenstände können daher nicht mehr wie eine aktuelle Lage erscheinen.

# MID v0.9.85.17

## MID-C5 · schnellere lokale Lage und belastbare Zugspuren

- Der aktuelle Standortstand erhält amtliche Stationsquellen im schnellen Pfad parallel zur Sammelabfrage. Die vollständige Gelände-/Oberflächenanalyse verfeinert danach weiter, ohne die erste sichtbare Korrektur aufzuhalten.
- Der Radar-Nowcast liefert den schnellen DWD-Standortabgleich früher aus. Scheitert die Startvorladung, startet MID automatisch einen frischen Schnellversuch und anschließend wie bisher die vollständige Kalibrierung mit Radar, Stations- und Qualitätsabgleich.
- KONRAD3D-Zellen und ihre prognostizierten Zugkorridore sind auf neuen Kartenansichten direkt sichtbar. Die gestrichelte Spur markiert nun alle 15 Minuten mit relativer und optional absoluter Zeit; Unsicherheitsellipsen bleiben klar getrennt vom beobachteten Zellbereich.

# MID v0.9.85.15

## MID-C3 · Schritt 3: Aktuell, Heute und Tagesprofil

- Die aktuelle Atmosphärenkarte konzentriert sich jetzt auf vier sofort entscheidungsrelevante Werte: Niederschlag, Wind/Böen, Feuchte/Taupunkt und Sicht. Luftdruck bleibt in der Detailtiefe zugänglich.
- Der gemeinsame 24-Stunden-Verlauf verbindet Aktuell und Heute nun sichtbar mit einem MID-Wetterfaden. Skybar, Zeitleiste und Quellenlogik bleiben synchron.
- Zeitdetails öffnen ausschließlich für den gewählten Zeitschritt; nicht aktive Werte treten visuell zurück.

# MID v0.9.85.14

## MID-C3 · Schritt 2: gemeinsames Seitenraster

- MID Next ordnet Ortskopf, Kernaussage, Datenmodule und Quellenabschluss jetzt nach einem gemeinsamen vertikalen Raster.
- Auf Tablets und Desktop wird der Ortskopf bewusst zweispaltig gruppiert; auf schmalen Geräten bleiben die Informationsgruppen ruhig untereinander lesbar.
- Abschnittsflächen verwenden dieselben Oberkanten, Abstände und Scrollanker. Wetterdaten, Warnlogik, Quellen und Parameterfarben bleiben unverändert.

# MID v0.9.85.13

## MID-C3 · Schritt 1: klare Hauptnavigation und Warnstatus

- Die schwebende Hauptnavigation führt auf kompakten Geräten jetzt mit fünf eindeutigen Zielen: **Aktuell · Heute · Vorhersage · Karten · Mehr**.
- Warnungen nehmen keinen gleichwertigen Tabplatz mehr ein, bleiben aber als gut sichtbarer, jederzeit antippbarer Status direkt im Ortskopf erreichbar.
- Der Status unterscheidet amtliche Warnungen, MID-Hinweise, eine ruhige Entwarnungslage und eine Störung der amtlichen Quelle. Eine Störung wird nie als „keine Warnlage“ ausgegeben.
- **Heute** öffnet die kanonische Kurzfristansicht; **Vorhersage** führt in den passenden zuletzt verwendeten Prognosehorizont. Wetterdaten, Warnlogik, Radarfarben, Favoriten und Einheiten bleiben unverändert.

# MID v0.9.85.0

## MID Next · Designgrundlage

- Neue, klar gegliederte Instrumentenflächen für aktuelle Werte, Prognosen, Karten und aufklappbare Module.
- Abstände, Radien und Bedienflächen skalieren nun kontrolliert von schmalen Smartphones über Tablets im Hoch- und Querformat bis zum Desktop.
- Die Informationsfarben für Wetter, Warnungen und Diagramme bleiben unverändert; das Design verbessert Hierarchie und Lesbarkeit, nicht die meteorologische Bedeutung.
- Unter **Einstellungen → Ansicht & Einheiten → MID Designsystem** kann jederzeit auf **Klassisch** zurückgestellt werden. Diese Rückfalloption wird pro Gerät gespeichert.

## Technische Umsetzung

- Opt-in-Designschicht über `data-mid-design` mit responsiven Tokenwerten und Unterstützung für reduzierte Bewegung.
- Keine neue Datenabfrage, keine Änderung an Zeitauflösung oder Prognoselogik; Stunden-, Tages- und Langfristansichten verwenden dieselben Datenkomponenten.
- Release-Preflight korrigiert: historische Versionsprüfungen akzeptieren spätere Funktionsreleases; die ICON-D2-RUC-15-Minuten-Phasenachse verarbeitet ISO-Zeitwerte ohne Zeitzonensuffix verbindlich als UTC.

# MID v0.9.84.105

## Extern
- Der fehlgeschlagene Installer #1060 ist korrigiert. Die GitHub-/Codex-Schreibworkflow-Vorbereitung aus v0.9.84.104 bleibt unverändert erhalten.
- An Wetterlogik, Karten, Isohypsen, Ceiling, Radar, Warnungen oder App-Bedienung wurde für diesen Hotfix nichts fachlich verändert.

## Intern
- Ursache: Mit dem neuen `chatgpt-pr-gate.yml` verwaltet MID nun acht statt sieben GitHub-Konfigurationsdateien. `test-github-workflow-bootstrap-08263.mjs` erwartete noch die alte Anzahl.
- `test-no-actions-workflow-self-modification-093911.mjs` erzeugte in seinem isolierten Test-Repository noch keinen kanonischen `chatgpt-pr-gate.yml`-Fixture und lief deshalb in `ENOENT`.
- Beide Regressionen wurden an den neuen expliziten Workflow-Synchronisationsvertrag angepasst. Die verwaltete Dateiliste wird nun direkt aus `sync-github-workflows.mjs` exportiert und von den Tests wiederverwendet, damit künftige Workflow-Erweiterungen nicht erneut durch doppelte Zähllisten auseinanderlaufen.
- Keine Worker-Fachlogik geändert; Worker-/Service-Worker-Dateien unterscheiden sich nur durch die synchronisierte Releaseversion.

# MID v0.9.84.104

## Extern
- GitHub-/Codex-Änderungen erhalten einen dauerhaften, fail-closed Repositoryvertrag: Agenten arbeiten nur auf `chatgpt/*`- bzw. `codex/*`-Branches und umgehen weder `main` noch `mid-stable`.
- Ein neues PR-Gate ist als kanonische Workflowquelle vorbereitet. Es prüft das unversionierte `MID-professional-replacement.zip` bereits im Pull Request mit Dependency-Audit, Produktionsbuild und vollständigen Regressionen.
- Die bestehende Release-Architektur bleibt unverändert: Erst nach grünem PR und Merge verarbeitet `install-mid.yml` das ZIP, veröffentlicht den Build und promotet anschließend den validierten Stand nach `mid-stable`.

## Intern
- `AGENTS.md` hinterlegt die verbindlichen Repositoryregeln für Codex/coding agents direkt im Projekt.
- `MID_CHATGPT_GITHUB_CONTRACT.md` dokumentiert Branch-, PR-, Fehler- und Berechtigungsvertrag.
- `ci/github/workflows/chatgpt-pr-gate.yml` ist die kanonische Quelle des read-only PR-Gates; `scripts/sync-github-workflows.mjs` kann sie bei einer expliziten Workflow-Wartung nach `.github/workflows/` spiegeln.
- Neuer Regressionstest `test-chatgpt-github-write-contract-098510.mjs` schützt Least-Privilege, SHA-Pinning, Agent-Branchfilter und den vollständigen `npm run verify`-Pfad.
- Die normale ChatGPT-GitHub-Verbindung selbst bleibt laut OpenAI-Livezugriff schreibgeschützt; direkte Repository-Schreibaktionen müssen daher über Codex oder eine gesondert autorisierte GitHub-App erfolgen.

# MID v0.9.84.103

## Extern
- Ceilinghöhen werden im aktuellen Wetter jetzt direkt in der sichtbaren Bewölkungskachel angezeigt. Eine frische beobachtete Wolkendecke bleibt vorrangig; fehlt diese, wird das verfügbare DWD-ICON-D2-RUC-Ceiling eindeutig als „Modell-Ceiling“ gekennzeichnet.
- Die bisherige Bewölkungsbeschreibung (z. B. „stark bewölkt“) bleibt erhalten und wird um die Höhenangabe ergänzt.

## Intern
- Ursache in v0.9.84.102: CEILING war bereits vollständig vom RUC-Datenpfad bis in den kanonischen Forecast verdrahtet, wurde in `CurrentMetrics` aber nur im (i)-Detailtext zusammengesetzt. Die sichtbare Bewölkungskachel verwendete ausschließlich `cloudCompactDetail`.
- Die sichtbare Kachel verwendet nun `cloudVisibleDetail = cloudCompactDetail + ceilingCompactDetail`.
- Priorität: frische Beobachtung (`ceilingHft`) > DWD ICON-D2-RUC `Hour.ceiling` > bei FEW/SCT optional beobachtete Wolkenuntergrenze. Modellwerte werden nicht als beobachteter grüner Statuspunkt ausgegeben.
- Der RUC-Lauf #549 für 2026-09-14T12:00 hat CEILING 15/15 erfolgreich dekodiert und veröffentlicht; damit ist die Datenquelle selbst nachweislich vorhanden.
- Keine neue Worker-Fachlogik; separater Worker-Upload ist nicht erforderlich.

# MID v0.9.84.102

## Extern
- Der fehlgeschlagene Installer #1056 ist korrigiert. Die sichtbaren Korrekturen aus v0.9.84.99 bis v0.9.84.101 bleiben unverändert: geglättete 500-hPa-Isohypsen, bereinigte Frontdarstellung, konservativere Niederschlagsphasen und saubere Desktop-Wetterpiktogramme.
- Für diesen Hotfix wurde keine Wetter-, Karten-, Datenquellen- oder Bedienlogik verändert.

## Intern
- GitHub #1056 hat TypeScript 7 und den Vite-Produktionsbuild erfolgreich bestanden und wurde nur noch von zwei veralteten statischen Regressionserwartungen blockiert.
- `test-maplibre-precip-probability-09390.mjs` schützt jetzt die absichtlich strengeren Radar-Echoschwellen aus v0.9.84.99: gefrierend 9 dBZ, Schnee 6 dBZ.
- `test-radar-colortables-09404.mjs` erwartet nicht mehr das bewusst entfernte Spiral-/„Schnecken“-Symbol, sondern das neue Regen+Eis-Piktogramm und schützt zusätzlich vor einer Rückkehr der Spiralform.
- Keine neue Worker-Fachlogik; separater Worker-Upload ist nicht erforderlich.

# MID v0.9.84.101

## Extern
- Der Installerfehler von v0.9.84.100 ist behoben. Die Korrekturen an 500-hPa-Isohypsen, Frontdarstellung, Niederschlagsart-Piktogrammen und Desktop-Wettersymbolen bleiben unverändert erhalten.
- Für diesen Hotfix wurde keine sichtbare Wetter-, Karten- oder Bedienlogik verändert.

## Intern
- Installer #1055 scheiterte ausschließlich im TypeScript-Gate an der verwaisten Hilfsfunktion `compositeFrontDash` in `src/RadarPanel.tsx`. Sie gehörte zu den bereits entfernten parallelen Front-Renderpfaden und hatte keine aktive Verwendung mehr.
- Die tote Hilfsfunktion wurde vollständig entfernt; TypeScript-Regeln wurden nicht abgeschwächt und es wurde keine künstliche Referenz eingeführt.
- Relevante Synoptik-, Isohypsen-, Radarphasen-, Responsive-, Versions- und Release-Lineage-Verträge wurden erneut geprüft.
- Keine neue Worker-Fachlogik; separater Worker-Upload ist nicht erforderlich.

# MID v0.9.84.100

## Extern
- Der Buildfehler des Release-Kandidaten v0.9.84.99 ist behoben. Die Korrekturen an Synoptik, Niederschlagsart-Piktogrammen und Desktop-Wettersymbolen bleiben vollständig erhalten.
- An der sichtbaren Wetterdarstellung wurde für diesen Hotfix nichts zurückgenommen oder neu umgestellt.

## Intern
- Installer #1054 scheiterte ausschließlich an zwei nach der Synoptik-Bereinigung übrig gebliebenen, nicht mehr verwendeten Front-Renderern. Beide toten Codepfade wurden entfernt.
- Der Regionalfront-Regressionsvertrag schützt jetzt ausdrücklich davor, diese parallelen Fallback-Pfade wieder einzuführen.
- Der Radar-Phasentest wurde an die bewusst strengeren Kälte-/Echo-Schwellen aus v0.9.84.99 angepasst, ohne den fachlichen Schutz zu lockern.
- Keine neue Worker-Fachlogik; separater Worker-Upload ist nicht erforderlich.

# MID v0.9.84.99

## Extern
- **Komposit / 500-hPa-Isohypsen:** Die stufige native WMS-Isohypsendarstellung wird nicht mehr sichtbar verwendet. MID zeichnet die 500-hPa-Geopotentialhöhen wieder als deutlich geglättete, gold/amber gestrichelte Konturen mit gpdm-Beschriftung; DWD-WMS bleibt für die gut funktionierenden Isobaren aktiv.
- **Frontdarstellung:** Doppelte Roh-/Fallback-Layer und die auffälligen parallelen violetten Frontalzonen wurden aus dem sichtbaren Pfad entfernt. Angezeigt werden nur ausreichend starke, geglättete θe-850-Frontalzonen; klassische Frontfarben/-symbole erscheinen nur bei belastbarer Typisierung.
- **Niederschlagsart:** Die missverständlichen spiraligen „Schnecken“-Symbole für gefrierenden Niederschlag wurden durch ein verständliches Regen+Eis-Piktogramm ersetzt. Gleichzeitig ist die Phasenklassifikation gegen warme False Positives deutlich strenger.
- **Desktop-Piktogramme:** Senkrechte Randstriche an Tages-/Perioden-Wetterpiktogrammen werden in der Desktopansicht nicht mehr gezeichnet.

## Intern
- Isohypsenpfad auf kontrolliertes MID-Canvas/Vektor-Rendering mit stärkerer Binomial-/Chaikin-Glättung festgelegt; WMS-Isohypsen bleiben als Datenquelle/Metadaten verfügbar, werden aber nicht mehr als sichtbarer Linienlayer genutzt.
- Fronten werden qualitätsgefiltert und geglättet; redundante Canvas-/Polyline-Doppelrenderings sind aus dem aktiven Pfad entfernt.
- Radar+Modell-Niederschlagsarten verlangen für gefrierende/feste Phasen zusätzlich konsistente Temperatur-/Feuchtkugel-Unterstützung und höhere Echo-Schwellen.
- Neuer Regressionstest `test-synoptic-phase-pictogram-cleanup-098499.mjs`; betroffene ältere Synoptiktests auf den aktuellen Renderingvertrag aktualisiert.
- Keine semantische Worker-Fachlogik geändert; Worker-/Service-Worker-Dateien unterscheiden sich nur durch synchronisierte Release-Metadaten.

# MID v0.9.84.98

## Extern
- Die obere Prognoseleiste fasst **90 min** und **24 h** wieder zu einem gemeinsamen Einstieg **Kurzfrist** zusammen. In der Kurzfristansicht stehen die 90-Minuten-Übersicht und das 24-h-Wetterprofil wieder gemeinsam untereinander statt hinter zwei getrennten Horizont-Schaltflächen.
- **MID · PLANEN** besitzt nun auf Desktop, iPad und Smartphone dieselbe fertige Karten-/Buttonsprache wie die übrigen modernen MID-Bereiche. Roh wirkende Standardbuttons, gequetschte Beschriftungen und der doppelte separate „Planer“-Kopf wurden entfernt.
- Beim UI-Audit wurde derselbe Desktop-Cascade-Fehler auch in den Schnellzugriffen des **Mehr**-Drawers gefunden und mit derselben Kartenlogik bereinigt.
- Die fünf Prognosehorizonte **Kurzfrist · 7 T · 14 T · 46 T · Saison** passen auch auf schmalen iPhones in eine Zeile; es entsteht kein unnötiger horizontaler Scrollbereich.

## Intern
- Persistierte Altstände mit Horizont `24h` werden beim Einlesen verlustfrei auf den gemeinsamen Kurzfrist-Horizont migriert. Die eigentlichen 90-min-/24-h-Inhalte und ihre meteorologischen Datenpfade bleiben unverändert.
- `modern-planner-hub`, `modern-planner-actions`, `modern-planner-section` und `modern-more-quick-actions` besitzen jetzt gemeinsame Desktop/Tablet/Mobil-Basisstile statt Kernregeln nur innerhalb des Mobile-Media-Queries.
- Neue Regression `test-shortterm-planner-polish-098498.mjs` schützt die Zusammenführung und den desktopfesten Planen-/Mehr-Designvertrag.
- Keine Worker-Fachlogik geändert.

# MID v0.9.84.97

## Extern
- Der fehlgeschlagene Installer #1050 wurde korrigiert. Die fachlichen Verbesserungen aus v0.9.84.96 bleiben unverändert erhalten: robustere 500-hPa-Isohypsen/Fronten, schneller gestartete hyperlokale Analyse und klar gekennzeichnetes ICON-D2-RUC-Modell-Ceiling.
- Wetterdaten, Modellfusion, Warnlogik, Radar, Satellit, Synoptikdarstellung und UI wurden durch diesen Hotfix nicht fachlich verändert.

## Intern
- `test-ensemble-wind-selection-cloud-reconciliation-08173.mjs` schützt jetzt die aktuelle Bewölkungsprovenienz mit `baseCloudSource` sowie der zusätzlichen Modell-Ceiling-Quellenangabe, statt die entfernte Direktzuweisung zu verlangen.
- `test-view-simulation-bottom-isohypsen-smoothing-098494.mjs` akzeptiert nun fachlich korrekt das native DWD-WMS als primären Isohypsenpfad und den geglätteten Vektor-/Canvas-Pfad als Fallback.
- GitHub #1050 hatte `npm ci`, Dependency-Audit, TypeScript und Vite bereits erfolgreich abgeschlossen; nur diese zwei von 789 statischen Verträgen blockierten die Veröffentlichung.
- Keine neue Worker-Fachlogik; Versionsmetadaten auf 0.9.84.97 synchronisiert.

# MID v0.9.84.96

## Extern
- Die Synoptik im Komposit rendert 500-hPa-Isohypsen robuster: DWD ICON-WMS ist der bevorzugte Linienpfad; bis dieser verfügbar ist, zeigt MID dieselben Höhenfelder zusätzlich über einen geglätteten MapLibre-Canvas-Fallback. Dadurch sollen nicht mehr nur gpdm-Beschriftungen ohne zugehörige Linien erscheinen.
- Fronten erhalten zusätzlich einen eigenen MapLibre-Canvas-Layer. Die objektiv diagnostizierten Front- und Frontalzonen bleiben damit auch dann sichtbar, wenn der bisherige Leaflet-kompatible Vektorpfad in der aktuellen Kartenengine ausfällt. Die amtliche DWD-Bodenanalyse bleibt als unveränderte Referenz verfügbar.
- Der Start der hyperlokalen Wetteranalyse wurde parallelisiert. Stationsdaten, Radar-/Niederschlagsabgleich und vollständige Stationsanalyse beginnen auf normalen Verbindungen deutlich früher, ohne Datenquellen, Qualitätsprüfungen oder meteorologische Berechnungen zu streichen. Langsame bzw. datensparende Verbindungen behalten den konservativeren Ablauf.
- DWD ICON-D2-RUC-Ceiling wird nun auch im aktuellen Wetter und im Flug-/Eventwetter genutzt. Frische beobachtete Ceiling-Werte bleiben vorrangig; Modellwerte werden ausdrücklich als „Modell-Ceiling“ gekennzeichnet.

## Intern
- 500-hPa-Geopotentialhöhe nutzt im Komposit den vorhandenen DWD-WMS-Pfad `Icon_reg025_fd_pl_GH` auf 500 hPa; ein Canvas-Fallback über `CanvasOverlay` bleibt aktiv, bis der native WMS-Stand geladen ist.
- Frontdarstellung um einen von Leaflet-SVG unabhängigen Canvas-Pfad für Synoptik-Kandidaten und regionale Frontalzonen erweitert.
- Startup-Preload auf normalen Verbindungen enger gestaffelt (`fastStation` 35 ms, Radar 85 ms, vollständige Stationsanalyse 140 ms); die spätere vollständige Fusion und alle Qualitäts-/Fallbackpfade bleiben erhalten.
- RUC-CEILING wird in die kanonische Kurzfriststunde durchgereicht und von aktuellem Wetter sowie Flug-/Eventwetter verwendet. Reguläre ICON-D2-/ICON-EU-Ceiling-Brokerpfade bleiben eine separate Ausbaustufe.
- Keine neue Worker-Fachlogik gegenüber v0.9.84.95; Worker-Dateien unterscheiden sich nur durch synchronisierte Release-Metadaten. Ein separater manueller Worker-Upload ist für die fachlichen Änderungen dieser Version nicht erforderlich.

# MID v0.9.84.95

## Extern
- Der fehlgeschlagene Installer #1048 wurde korrigiert. Die sichtbaren Verbesserungen aus v0.9.84.94 bleiben unverändert erhalten: sichere mobile Bottom-Bar, zuverlässigere 500-hPa-Isohypsen und geglättete Kurven im 24-h-Profil.
- Wetterdaten, Modellfusion, Warnlogik, Radar, Satellit und meteorologische Berechnungen wurden durch diesen Hotfix nicht verändert.

## Intern
- Installer #1048 scheiterte im kombinierten Build-/Regression-Gate. Lokal ließ sich der erste Blocker exakt als veralteter Vertrag in `test-navigation-composite-ruc-098491.mjs` reproduzieren: Der Test verbot noch den inzwischen bewusst panegebundenen Leaflet-SVG-Renderer.
- Ein anschließender vollständiger statischer Regressionsdurchlauf deckte vier weitere veraltete Quelltextverträge derselben v0.9.84.94-Änderungen auf. Aktualisiert wurden deshalb auch die Verträge für monotone Wind-/Böenkurven, das Modelllinien-Pane mit Grid-Isohypsen-Fallback, den größeren sichtbaren Bottom-Bar-Griff und die panegebundenen Konturpfade.
- Die fünf korrigierten Altverträge sowie die angrenzenden Bottom-Bar-, Synoptik-, 24-h-, Viewport-, Versions- und Release-Lineage-Regressionen bestehen im korrigierten Stand.
- Keine Worker-Fachlogik geändert; Versionsmetadaten wurden auf 0.9.84.95 synchronisiert.

# MID v0.9.84.94

## Extern
- Die mobile Bottom-Bar bleibt auf iPhone und anderen kompakten Displays sichtbar oberhalb des unteren Bildrands. Auch im Auto-Minimierungszustand bleibt ein klar erkennbarer Griffbereich erhalten.
- Die Bottom-Bar-Einstellung ist optisch an die Favoritenleisten-Einstellung angeglichen.
- 500-hPa-Isohypsen werden im Synoptikmodus zuverlässiger als echte geglättete Gold-/Amber-Linien mit gpdm-Beschriftung dargestellt, auch wenn der Grid-Frame früher als der vollständige Modellframe verfügbar ist.
- Die Linien der Tagesansicht sind ruhiger und geglättet: Temperatur, gefühlte Temperatur, Taupunkt, Luftdruck, Wind und Böen verwenden nun dieselbe monotone Kurvenführung wie bereits die Niederschlagswahrscheinlichkeit.

## Intern
- Bottom-Bar-Safe-Area-Offsets und Auto-Hide-Translation nach Viewport-/iPhone-Simulation nachgeschärft.
- Synoptik-Bereitschaft und Modelllinien-Pane von der unnötigen Abhängigkeit eines vollständigen `dominantModelFrame` entkoppelt; Grid-Isohypsen können eigenständig rendern.
- Tagesprofilpfade auf `monotoneSvgPath` umgestellt; die Temperaturfläche schließt entlang der geglätteten Kurve.
- Keine neue Worker-Fachlogik; Worker-Deploy ist für diese Änderungen nicht erforderlich.

# MID v0.9.84.93

## Extern
- Der fehlgeschlagene Installer #1046 wurde korrigiert. Der Produktionsbuild selbst war bereits erfolgreich; blockiert hatten ausschließlich zwei veraltete automatische Prüferwartungen.
- Die mit v0.9.84.92 eingeführte robuste Speicherung der Komposit-Einstellungen bleibt unverändert erhalten, einschließlich der gewählten Wiedergabegeschwindigkeit.
- Die 500-hPa-Isohypsen bleiben gridbevorzugte, geglättete Vektorkonturen mit sicherem Modellframe-Fallback und gpdm-Beschriftung. An Wetterdarstellung, Datenquellen oder Bedienlogik wurde für diesen Hotfix nichts fachlich geändert.

## Intern
- `test-composite-buffered-playback-097881.mjs` prüft jetzt die aktuelle `compositeSettingsRef`-/Flush-Persistenz statt eines entfernten historischen `writeCompositeSettings({...} satisfies CompositeSettings)`-Quelltextmusters.
- `test-synoptic-isoheight-visibility-098455.mjs` schützt jetzt den aktuellen Grid-first-`vectorIsoheightFrame` samt vektorfähigem Modellframe-Fallback und tatsächlichem Polyline-Rendering, statt ausschließlich den alten Direktzugriff auf `dominantGridFrame.isoheights` zu verlangen.
- Keine zusätzliche Worker-Fachlogik in v0.9.84.93. Installer #1047 veröffentlichte den kumulativen Stand erfolgreich.

# MID v0.9.84.92

## Extern
- **Aktuelles Wetter** ist wieder direkt über die mobile Bottom-Bar erreichbar. Die sechs Primärziele lauten jetzt **Aktuell · Kurzfrist · 7 Tage · 14 Tage · Komposit · Mehr**; „Aktuell“ wird nicht zusätzlich in „Mehr“ dupliziert.
- Die Bottom-Bar kann unter **Einstellungen → Bottom-Leiste → Verhalten beim Scrollen** wahlweise **Auto** oder **Fixiert** betrieben werden. „Fixiert“ hält sie dauerhaft vollständig sichtbar; „Auto“ minimiert sie erst nach deutlicher Abwärtsbewegung und zeigt sie beim Hochscrollen sofort wieder vollständig.
- Die schwebende Bottom-Bar sitzt auf iPhones näher und sauberer am Home-Indicator. Die Safe Area wird nicht mehr doppelt als äußerer Abstand aufgeschlagen; Touch-Ziele bleiben trotzdem ausreichend groß.
- Die zuletzt gewählte **Komposit-Konfiguration** wird nun robuster gespeichert – auch bei schnellem Modulwechsel, Wechsel in den Hintergrund oder Schließen der PWA.
- **500-hPa-Isohypsen** werden im Synoptik-Layer wieder als gold-/amberfarbene gestrichelte Vektorlinien **mit gpdm-Beschriftung** geladen. Der Abruf des Europagitters wurde beschleunigt, ohne Rasterdichte oder 8-gpdm-Konturintervall zu reduzieren.

## Intern
- Bottom-Bar-Vertrag auf sechs mobile Primärziele erweitert; Current/Aktuelles Wetter ist wieder kanonischer Direkt-Tab. Der frühere Beta-Current-Pfad bleibt entfernt.
- Neue persistente Einstellung `mid:bottom-bar-behavior:v1` (`auto`/`fixed`) ergänzt. Der automatische Modus nutzt eine größere Abwärtshysterese und eine kleine Aufwärtshysterese.
- Komposit-Einstellungen werden zusätzlich sofort bei Preset-/Ansichtswechsel sowie bei `pagehide` und beim Wechsel des Dokuments in den Hintergrund geschrieben; die React-Effekt-Persistenz bleibt als zusätzliche Sicherung bestehen.
- Synoptik-Frontend nutzt einen robusten `vectorIsoheightFrame`-Fallback zwischen Grid- und Modellframe. Der Worker bündelt das 17×25-Europagitter in Vierer-Zeilenblöcke und reduziert den Open-Meteo-Abruf damit von bis zu 17 auf etwa 5 parallele Requests; Raster, Konturintervall und Frontendiagnostik bleiben fachlich unverändert.
- Worker-Fachlogik wurde geändert; für diesen Release ist ein Worker-Upload erforderlich.

# MID v0.9.84.91

## Extern
- Die mobile Bottom-Bar priorisiert jetzt **Kurzfrist · 7 Tage · 14 Tage · Komposit · Mehr**. Das frühere experimentelle „Aktuell“-Dashboard ist entfernt; das vollständige **Aktuelle Wetter** bleibt unter **Mehr → Überblick** erreichbar.
- Die Bottom-Bar blendet beim Abwärtsscrollen deutlich später aus und bleibt im minimierten Zustand als sichtbarer Glass-Griff erreichbar. Aufwärtsscrollen oder Antippen stellt sie sofort wieder her.
- **Komposit** ist als Primärziel direkt erreichbar. In **Mehr** stehen zusätzlich Schnellzugriffe auf Favoriten, Benachrichtigungen, Einstellungen, Wetterzwilling und Updates – Funktionen der früheren Top-Bar bleiben damit leicht auffindbar.
- 500-hPa-Isohypsen werden im Komposit wieder als echte geglättete, gold-/amberfarbene gestrichelte Vektorlinien gerendert; die sichtbaren gpdm-Beschriftungen und die Linien teilen denselben Leaflet-Layerpfad.
- Komposit-Auswahlen werden unmittelbar gespeichert. Unnötige Basiskartenhinweise wie „schlüsselfrei“ wurden entfernt.
- Der Niederschlagsphasen-Layer nutzt bei vorhandenen Daten zusätzlich native **DWD ICON-D2-RUC**-Signale für Regen, Schnee und Graupel (15-minütig). Die Phase wird nur über realem OPERA-Radarecho visualisiert; die bisherige thermodynamische Regionalmodell-Phase bleibt als sicherer Fallback erhalten.

## Intern
- Breites 5-Minuten-Densifying aller RUC-Felder wurde bewusst verworfen: die zusätzliche Datenmenge wäre groß, ohne für langsam veränderliche Zustandsfelder einen proportionalen Prognosegewinn zu liefern. 5-Minuten-Niederschlagsmengen bleiben Timing-Kern, 15-Minuten-Phasen bleiben in ihrer nativen DWD-Auflösung.
- Der bestehende RUC-Phase15-Speicherpfad (`RAIN_GSP`, `SNOW_GSP`, `GRAU_GSP`) wird nun vom Radar-Phasenadapter genutzt; fehlende/stale Daten fallen fail-safe auf den bisherigen Modellpfad zurück.
- Die alten Beta-Heute-Regressionen und historische Navigations-Stringverträge wurden an die kanonische Bottom-Bar-/Current-Architektur angepasst.
- Worker-Fachlogik wurde geändert; für diesen kumulativen Release ist ein Worker-Upload erforderlich.

# MID v0.9.84.90

- Release-Gate korrigiert: drei veraltete Radar-/Livequellen-Regressionen an die seit v0.9.84.88 bewusst verdichtete Kompositdarstellung angepasst.
- Keine Wetter-, Radar-, Synoptik-, Push- oder Navigationslogik geändert.
- Diagnoseinformationen zu Niederschlagsart, KONRAD3D und NowCastMIX bleiben vollständig über Status-/Infoebenen erhalten.

# MID v0.9.84.89

- Die mobile Web-/PWA-Navigation ist jetzt eine schwebende, iOS-inspirierte Bottom-Bar mit **Aktuell, Kurzfrist, 7 Tage, 14 Tage und Mehr**.
- Die Beschriftungen bleiben auch auf kleinen iPhones einzeilig; die Leiste berücksichtigt Home-Indicator/Safe Areas und wird im Querformat platzsparender.
- Beim Herunterscrollen blendet sich die Leiste nach einer kleinen Hysterese aus; beim Hochscrollen, am Seitenanfang oder bei Bedienfokus erscheint sie wieder.
- Die frühere Einstellung **Bedienkonzept** und **Bottom-Leiste · Beta** wurde entfernt. Weitere Karten-, Planer- und Fachmodule bleiben über **Mehr** erreichbar.
- Keine Änderung an Wetterdaten, Radar-/Satellitenprodukten, Warnlogik oder Parameterfarben.
- Installer #1042 des vorherigen v0.9.84.88-Uploads wurde vor dem neuen Paket analysiert: einziges TypeScript-Problem war ein ungenutztes `latestLightningTime`-Binding in `RadarPanel.tsx`; dieses tote Binding ist entfernt.

## 0.9.84.88

### Extern
- Tagespiktogramme bewerten Sonnenscheindauer und Tagesbewölkung ausgewogener. Ein Tag mit hohem Sonnenanteil wird nicht mehr allein wegen einzelner wolkiger Stunden als wolkendominant zusammengefasst; überwiegend dichte Bewölkung und relevante Niederschläge begrenzen sonnige Klassen weiterhin.
- Push-Mitteilungen sind kürzer und scannbarer. Die Niederschlagsvorwarnung nennt Beginn, Dauer und Menge kompakt; der redundante Satz „Radar bestätigt die Annäherung“ entfällt. Gewitterhinweise wurden ebenfalls gestrafft, ohne den Hinweis „Keine amtliche Warnung“ zu entfernen.
- Synoptik erhält zusätzlich großräumige modell-diagnostische Frontalzonen aus dem θe-Gradienten in 850 hPa. Lokal typisierte Kalt-/Warmfronten, Okklusionen, Tröge und Konvergenzen bleiben als strengere Mehrparameteranalyse erhalten. 500-hPa-Isohypsen werden ausschließlich als geglättete MID-Vektoren in Gold/Amber und gestrichelt dargestellt; der treppenartige weiße WMS-Isohypsenfallback wurde entfernt.
- Die Layerfelder im Kompositbild sind deutlich kompakter: kurze Primärinformationen, kleinere Icons, eine einzeilige Statuszeile und weiterhin touchfreundliche Mindesthöhen. Ausführliche Quellen-/Methodeninformationen bleiben über den Infozugang erhalten.

### Intern
- Tagescharakteristik gewichtet Sonnenscheindauer substanzieller (`72/28` Stundenhelligkeit/Sonnenscheindauer; zusätzliche Sonnenuntergrenze) und behält harte Caps für überwiegend dichte Bewölkung bei.
- Niederschlags-Push: Titel `MID · <Art> in <Min.>`; Body `<Ort> · Beginn … · Dauer … · ca. … mm`. Gewitter-Pushtexte ebenfalls gekürzt.
- Europa-Synoptikraster ergänzt Temperatur und relative Feuchte in 850 hPa, berechnet θe, robuste Gradientenschwellen und zusammenhängende Frontalzonen. Diese werden ausdrücklich als Modell-Diagnose und nicht als amtliche DWD-Bodenanalyse gekennzeichnet.
- Native DWD-Isobaren bleiben nutzbar; native DWD-500-hPa-Isohypsen werden nicht mehr als sichtbarer Fallback gerendert. MID-Isohypsen nutzen `9 5` (Zwischenlinien) bzw. `18 7` (Hauptlinien) und die vorhandene Goldpalette mit Halo.
- Neue/aktualisierte Regressionen schützen Sonnenschein-Piktogramme, Push-Kürzung, regionale Frontalzonen, gestrichelte Isohypsen und Komposit-Layerdichte über zwölf Referenz-Viewports.
- Worker-Fachlogik wurde geändert; für diesen Release ist ein Worker-Upload erforderlich.

## 0.9.84.87

### Extern
- Installerfehler aus GitHub Actions #1040 behoben. Die App selbst und die bisherigen Korrekturen bleiben unverändert; blockiert hatte ausschließlich ein versionsfest geschriebener Viewport-Regressionsvertrag.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Radar, Satellit, Karten, Pegeln oder sichtbarer Bedienlogik.

### Intern
- `test-viewport-textflow-098485.mjs` ist nicht mehr auf `0.9.84.85` fest verdrahtet. Der Test schützt weiterhin Header, Bottom-Navigation, Prognose-Kompass, 24-h-Einzeldaten und Pegelzugang, verwendet für die Protokollausgabe aber die jeweils aktuelle Paketversion.
- Damit bleibt der Viewport-/Textflussvertrag über Wartungsreleases hinweg gültig und blockiert künftige Versionsanhebungen nicht erneut ohne fachlichen Grund.
- Versionsmetadaten auf 0.9.84.87 synchronisiert; Worker-Fachlogik unverändert.

## 0.9.84.86

### Extern
- Installerfehler aus GitHub Actions #1039 behoben. Die App selbst hatte erfolgreich gebaut; zwei ältere Regressionstests erwarteten noch die vor v0.9.84.85 gültigen Texte.
- Die beabsichtigten Verbesserungen aus v0.9.84.85 bleiben unverändert erhalten: In den 24-h-Einzeldaten stehen Lufttemperatur, gefühlte Temperatur und Taupunkt getrennt ohne zusätzliche Delta-K-Angabe; der Wassersport-Bereich nennt „Pegel“ weiterhin ausdrücklich.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Karten-, Radar-, Satelliten- oder Pegelberechnungen.

### Intern
- `test-mid-weather-profile-thermal-sun-09320.mjs` an den aktuellen 24-h-Einzeldatenvertrag angepasst: die drei Temperaturwerte werden positiv geprüft, die veraltete sichtbare `K`-Delta-Ausgabe wird ausdrücklich verworfen.
- `test-sports-section-collapse-09280.mjs` schützt nun die aktuelle Modulbeschreibung „Pegel, Wasserwetter, Gezeiten und Bedingungen“.
- Der Fehler aus Installer #1039 war damit ein veralteter Testvertrag und kein Produktionsbuild- oder npm-/Dependency-Fehler.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist nicht erforderlich.

## 0.9.84.85

### Extern
- Mobile Kopfzeile und Hauptnavigation passen sich konsequenter an den verfügbaren Platz an: Versionsnummer und kurze Register bleiben vollständig lesbar, ohne mitten im Wort umzubrechen.
- Prognose-Konfidenz und weitere kompakte Informationskarten stapeln Inhalte auf schmalen Displays geordnet, statt Text über Kartenränder laufen zu lassen.
- Die 24-Stunden-Einzeldaten sind kompakter: Lufttemperatur, gefühlte Temperatur und Taupunkt werden als drei klar getrennte Werte gezeigt; die Delta-Temperaturangabe entfällt.
- Pegelstände sind leichter auffindbar: Wasser/Wassersport und die Favoritenprofile benennen amtliche Pegel nun ausdrücklich.
- Responsive Schutzprüfung über zwölf Smartphone-, Tablet- und Desktopgrößen ergänzt.

### Intern
- Mobile Header priorisiert auf schmalen iPhones Logo/Version und essentielle Aktionen; der permanente „installiert“-Status belegt dort keinen wertvollen Platz mehr.
- Bottom-Navigation schützt kurze Register vor Worttrennung und reduziert Icons/Typografie adaptiv, ohne die vorhandenen Touchziele zu verkleinern.
- Prognose-Konfidenzkarten wechseln mobil auf eine gestapelte Informationshierarchie; lange Methodentexte bleiben über den bestehenden Infozugang vollständig verfügbar.
- Neue Regression `test-viewport-textflow-098485.mjs` schützt Versionsdarstellung, Pegel-Auffindbarkeit, Bottom-Navigation, Konfidenzkarten und die kompakte 24-h-Einzeldatenansicht.
- Repräsentative Layoutgeometrie wurde für 320×568, 360×640, 375×667, 390×844, 402×874, 430×932, 768×1024, 820×1180, 1024×768, 1280×800, 1440×900 und 1920×1080 geprüft; im Audit wurden keine Grenzüberschreitungen gefunden.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist nicht erforderlich.

## 0.9.84.84

### Extern
- Release-Fehler aus GitHub Actions #1037 behoben: Der Produktionsbuild war bereits erfolgreich; anschließend widersprachen vier ältere Regressionstests der inzwischen verbindlichen gemeinsamen Portal-/Popover-Architektur. Diese Altverträge wurden an den aktuellen MID-Stand angepasst.
- Meteogramm-Tooltips verwenden nun ebenfalls die gemeinsame viewportfeste MID-Portalprimitive. Dadurch bleiben die Werte in iPhone-, iPad-, Querformat- und Desktopansichten außerhalb horizontaler Scrollcontainer lesbar; Touch-Tooltips schließen weiterhin automatisch.
- Die in v0.9.84.83 wieder sichtbaren RADOLAN-Mengen für 1 h und 24 h bleiben unverändert erhalten.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Radar-/Satellitenfachlogik oder Niederschlagsmengen selbst.

### Intern
- `MeteogramPanel` enthält kein eigenes `react-dom/createPortal` mehr; die Punkttooltips laufen über `AppPortalPointTooltip` in `AppPortalPopover.tsx`.
- Veraltete Regressionserwartungen in Code-Quality, Map-Focus und React-19 wurden vom früheren lokalen `useDismissibleLayer`-Pfad auf die neuere `AppPortalPopover`-Architektur migriert.
- Neuer Release-Gate-Vertrag `test-release-gate-architecture-098484.mjs` schützt die gemeinsame Portalarchitektur und verhindert, dass widersprüchliche Altverträge den Installer erneut blockieren.
- Der vorherige Installer #1037 erreichte erfolgreich npm-Installation, Dependency-Audit, TypeScript- und Vite-Build; er scheiterte erst an vier Regressionen. Die vier betroffenen Tests sowie die angrenzenden Overlay-/Karten-/RADOLAN-/Versionsverträge bestehen im korrigierten Stand.
- Lokales `npm ci` konnte in der isolierten Arbeitsumgebung wegen eines Transport-Timeouts nicht vollständig bezogen werden; deshalb wird der komplette 778-Test-GitHub-Gate nicht vorgetäuscht. Der nächste Installerlauf bleibt die definitive Vollprüfung.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist nicht erforderlich.

## 0.9.84.83

### Extern
- Aktuelles Wetter → Niederschlag zeigt die vorhandene RADOLAN-Rückschau wieder vollständig sichtbar: sowohl die letzte 1-h-Menge als auch die letzte 24-h-Menge stehen direkt in der Kachel und nicht nur hinter der Info-Schaltfläche.
- Die fachliche Herkunft bleibt transparent: für die Stunde wird angeeichtes RADOLAN RW bevorzugt; nur bei noch nicht ausreichend aktuellem RW darf RY als ausdrücklich nicht angeeichter Ersatz dienen. Die 24-h-Menge stammt weiterhin aus angeeichtem RADOLAN SF.
- Keine Änderung an Niederschlagsberechnung, Radar-Nowcast, Modellfusion oder Mengenwerten selbst; korrigiert wurde ausschließlich die sichtbare Darstellung der bereits vorhandenen Rückschauwerte.

### Intern
- `Current` führt eine eigene kompakte sichtbare Historienzeile für 1 h und 24 h; Produkt- und Angeeicht-Status bleiben in den technischen Details erhalten.
- Neuer Regressionstest `test-current-precip-radolan-history-visible-098483.mjs` schützt sichtbare 1-h-/24-h-Werte sowie RW/RY/SF- und Angeeicht-Vertrag.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist nicht erforderlich.

## 0.9.84.82

### Extern
- App-weiten Karten-/Diagramm-Audit fortgesetzt: Meteogramm-Tooltips werden auf iPhone, iPad und Desktop nun viewportfest angezeigt, dürfen umbrechen und verschwinden auf Touch automatisch wieder. Dadurch werden lange Werte nicht mehr am Diagrammrand oder durch horizontale Scrollcontainer abgeschnitten.
- Wetterkarten-Kopf und Quellenblock brechen auf schmalen Displays kontrolliert untereinander um; Modell-/Quellenmetadaten bleiben vollständig lesbar statt unmarkiert zu ellipsieren.
- DWD-Kombinationskarten zeigen die Niederschlagsarten-Legende auf mobilen Geräten als sichere, scrollbar begrenzte Viewport-Fläche inklusive Safe-Area-Abstand.
- Synoptik und Extremwetter wurden für kleine Smartphones und Split-View nachgezogen: keine 6-px-Rückfälle bei zentralen Phasen-/Legendentexten, lange Regions-/Stationshinweise dürfen umbrechen, Kartenlegenden bleiben begrenzt und scrollbar.
- Für flache Querformate werden Wetterkarten-, Synoptik-, Extremwetter- und Radarflächen in der Höhe begrenzt, damit Bedienelemente und Navigation nicht unnötig aus dem sichtbaren Bereich gedrängt werden.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Radar-/Satellitendaten, Piktogrammen oder Parameterfarben.

### Intern
- Meteogramm-Tooltipkoordinaten von diagramminternen SVG-Koordinaten auf `clientX/clientY` plus `react-dom`-Portal umgestellt; Touch-Tooltips besitzen einen 4,2-s-Auto-Dismiss.
- Neuer Pflichtvertrag `test-map-chart-responsive-continuation-098482.mjs` simuliert die Tooltip-Horizontalgeometrie auf den zwölf vereinbarten iPhone-/Handy-/iPad-/Desktop-Viewports und schützt Wetterkarten-, DWD-Legenden-, Synoptik-, Extremwetter- und Querformatregeln.
- Bestehende Verträge für Overlay-Viewport, allgemeine Tooltip-Responsivität, Visualisierungslesbarkeit, Wetterkarten, Radarinteraktion, Design-Abdeckung und appweite Touchziele bleiben bestanden. Zwei ältere fachliche Layouttests benötigen weiterhin `typescript-strada`, das im Transport-ZIP nicht enthalten ist; dies wird nicht als bestanden ausgegeben.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist nicht erforderlich.
- Buildfix nach dem fehlgeschlagenen Installer #1036: Der nach der Trend-14d+-Portalumstellung nicht mehr verwendete lokale `clamp`-Helfer wurde aus `SubseasonalTrendPanel.tsx` entfernt. Damit ist der gemeldete TypeScript-Fehler `TS6133` beseitigt; der Overlay-Vertrag schützt diesen Rückfall künftig mit.

## 0.9.84.81

### Extern
- iPhone-Kopfbereich nach dem gemeldeten Screenshot nachgebessert: Benachrichtigungs-/Aktionsbuttons liegen nicht mehr optisch in der Suchzeile. Die Suche erhält auf regulären iPhones eine eigene volle Zeile; sehr schmale Geräte behalten einen sicheren dreizeiligen Fallback.
- Die fünf Hauptziele der optionalen Bottom-Leiste bleiben einzeilig. „Kurzfrist“, „7 Tage“ und „14 Tage“ werden nicht mehr mitten im Wort bzw. unnötig auf zwei Zeilen getrennt.
- Favoriten-Schnellleiste robuster gemacht: Der Standardort wird auf schmalen iPhones kompakt als „Std.“ gekennzeichnet, die Verwaltungsfläche bleibt getrennt und die Favoritenleiste horizontal scrollbar.
- Keine Änderung an Wetterdaten, Prognosefusion, Warnlogik, Piktogrammen, Karteninhalten oder Parameterfarben.

### Intern
- Neuer Pflichtvertrag `test-mobile-header-bottom-nav-098481.mjs` schützt die Screenshot-Korrekturen gegen spätere allgemeine Lesbarkeits-/Umbruchregeln.
- Bestehende Verträge für vollständige Versionsanzeige, Favoriten, Touch-Suche, Bottom-Navigation, Header-Dichte, appweite Touchziele, Design-Abdeckung, Versionierung und Release-Lineage bleiben bestanden.
- Ein Headless-Chromium-Screenshotlauf wurde versucht, beendet sich in der isolierten Umgebung jedoch nicht zuverlässig; er wird deshalb ausdrücklich nicht als bestandene Sichtprüfung gewertet.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist nicht erforderlich.

## 0.9.84.80

### Extern
- App-weiten Interaktions-/Overlay-Audit fortgesetzt: Punktdetails im „Trend 14d+“ sowie Ebenen- und Dateninformationen im Kompositbild bleiben nun auch an Displayrändern vollständig im sichtbaren Bereich und können bei langem Inhalt intern scrollen.
- Langfrist-/Witterungstrend verwendet für sichtbare Bedien-, Status- und Modelltexte keine historischen 6–9-px-Schriften mehr; wissenschaftliche Achsen bleiben bewusst kompakt.
- Favoriten-, Einstellungs-, Update- und Installationsdialoge reagieren robuster auf dynamische iPhone-Safari-Leisten, Notch und Home Indicator.
- Touchbedienung der neu geprüften Popover bleibt mit mindestens 44-px-Zielen abgesichert.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Piktogrammen oder Parameterfarben.

### Intern
- Trend-14d+-Punkttooltips und Komposit-Popover auf die gemeinsame `AppPortalPopover`-Architektur umgestellt.
- Neuer Pflichtvertrag `test-overlay-viewport-continuation-098480.mjs` simuliert die Portalpositionierung auf zwölf iPhone-/Handy-/iPad-/Desktopgrößen und schützt `visualViewport`, Safe Areas, interne Scrollbarkeit und das kanonische Stylesheet-Aggregat.
- Trend-/Langfrist-Fachregressionen für EC46/GEFS, Klimamittel 1991–2020, P10–P90/P25–P75, Parameterfarben und Fallbacks bleiben bestanden.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten werden synchronisiert. Ein manueller Worker-Upload ist für diese UI-/Interaktionskorrektur nicht erforderlich.

## 0.9.84.79

### Extern
- App-weite Darstellungsprüfung aus MID 17.7.23 fortgesetzt und auf sämtliche aktivierbaren Dashboard-Module sowie Einstellungen, Quellenanalyse, Routenwetter, moderne Heute-Ansicht und Installationsdialoge ausgedehnt.
- Die optionale moderne Heute-Ansicht verwendet keine historischen 7–9-px-Beschriftungen mehr; Wetterbeschreibung, Kennwerte und Kurztrend bleiben vollständig lesbar und dürfen sinnvoll umbrechen.
- Lokale Istwetter-/Gefahrenhinweise, Warnkopf, Prognosegüte, Quellen-/Modellnamen und Routenwetter wurden auf die gemeinsame MID-Lesbarkeit angehoben.
- Lange Quellennamen und Ensemble-Szenariotitel werden nicht mehr mit Ellipse abgeschnitten. Touchziele bleiben auf mobilen Geräten mindestens 44 px.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Piktogrammen oder Parameterfarben.

### Intern
- Neue Vollständigkeitsmatrix `MID_APP_VIEW_AUDIT_0.9.84.79.md` deckt alle 18 Dashboard-Module plus globale Shell-/Sekundärbereiche ab.
- Neuer Pflichtvertrag `test-appwide-readability-continuation-098479.mjs` schützt die Rest-Audit-Regeln, die vollständige Modulliste und das kanonische Stylesheet-Aggregat.
- 22 relevante lokale Regressionen bestanden. Zwei ältere Tests und der vollständige TypeScript-Build benötigen die im Professional-ZIP nicht enthaltenen Projektabhängigkeiten; dies ist im Testbericht transparent dokumentiert.
- Worker-Fachlogik unverändert; ausschließlich Versionsmetadaten synchronisiert. Ein manueller Worker-Upload ist für diese UI-/Designkorrektur nicht erforderlich.

## 0.9.84.78

### Extern
- Mobiler Header neu abgesichert: Die vollständige Versionsnummer bleibt auf schmalen iPhone-/Handybreiten sichtbar. Unter 430 px stehen Marke/Version, Aktionsleiste und Suche in getrennten Zeilen; die 44-px-Touchziele werden nicht verkleinert.
- Schweizer Hydrologie ergänzt: Für Orte in der Schweiz kann MID die öffentliche BAFU-Datenplattform direkt über GraphQL nutzen und aktuelle Wasserstände, Abflüsse und Wassertemperaturen aus dem nationalen hydrologischen Messnetz anzeigen.
- Schweizer Wasserstände bleiben im nativen Höhenbezug `m ü. M.`; sie werden nicht in den deutschen PEGELONLINE-cm-Vertrag umgerechnet. Deutschland bleibt unverändert auf WSV PEGELONLINE einschließlich vorhandener WV-Vorhersagen.
- Keine Änderung an DWD-/OPERA-Radar, Warnlogik, Modellfusion, Wetterpiktogrammen oder Parameterfarben.

### Intern
- Neuer Header-Vertrag `test-header-version-readability-098478.mjs` schützt die vollständige Versionsanzeige app-weit und erzwingt bei <=430 px getrennte Layoutzeilen für Brand, Aktionen und Suche.
- Neuer BAFU-Vertrag `test-bafu-hydrology-098478.mjs` prüft amtliche Stationsauswahl, `data_live` für W/Q/WT, native Einheiten, Freshness-Schutz und die Trennung vom PEGELONLINE-cm-Schema.
- BAFU-GraphQL-Endpunkt `https://data.bafu.admin.ch/api` wird ohne Zugangsdaten angesprochen; aktive Stationsmetadaten werden Worker-seitig zwischengespeichert. Live-Werte älter als 90 Minuten werden nicht als aktuell ausgegeben.
- Quellenübersicht und Worker-Health wurden um BAFU ergänzt. Worker-Fachlogik geändert; Worker-Deployment erforderlich.

## 0.9.84.77

### Extern
- Buildfix für den fehlgeschlagenen Installer #1032: NOAA MRMS bleibt in den USA die amtliche Standort-/Nowcast-Analyse, während die sichtbare Radarkarte bis zu einem eigenen MRMS-Rasteradapter explizit auf RainViewer zurückfällt.
- Dadurch bleibt die US-Radarkarte sichtbar und die Quellen werden transparent getrennt statt einen nicht vorhandenen MRMS-Kartenlayer vorzutäuschen.
- Keine Änderung an DWD-/OPERA-Radar, Warnungen, Modellfusion, Wetterwerten, Piktogrammen oder Design.

### Intern
- TypeScript-Fehler `TS2322` in `RadarPanel.tsx` behoben: `RadarNowcast.source='mrms'` wird nicht mehr ungeprüft als `CompositeSource` zurückgegeben.
- `CompositeSource` bleibt bewusst auf tatsächlich renderbare Kartenquellen beschränkt; MRMS wird separat als Standortanalyse ausgewiesen.
- Neuer Regressionstest `test-mrms-display-source-contract-098477.mjs` schützt Compilervertrag und verhindert einen leeren MRMS-Rasterpfad.
- Temporäre lokale Diagnose-Logs der v0.9.84.76-Sandbox wurden aus dem Transportstand entfernt.
- Worker-Fachlogik unverändert; nur Versionsmetadaten werden synchronisiert.

## 0.9.84.76

### Extern
- Design-Audit fortgesetzt: Event-, Gewitter-, Klima-, Flugmet-, Radar-, Warn-, Navigations- und Einstellungsinformationen bleiben auf schmalen Displays besser lesbar; lange Eventtitel werden vollständig umgebrochen.
- PEGELONLINE zeigt bei vorhandener `WV`-Reihe nun den tatsächlichen nächsten amtlichen Vorhersage-/Abschätzungswert statt nur „Vorhersage vorhanden“.
- Amtliche Beobachtungsadapter erhalten einen Freshness-Schutz, damit veraltete Stationswerte bei Quellstörungen keine frischeren Fallbacks überstimmen.
- UBA-Luftdaten werden zeitlich abgesichert und führen die amtliche Quellenattribution explizit mit.
- Quellen-Audit bestätigt aktuelle KNMI-EDR-, SwissMetNet-STAC-, ECMWF-50r1-/AIFS-v2-, DWD-KONRAD3D/Mesozyklonen- und WIS2-Verträge; BAFU/LINDAS wird als nächster P1-Wasserpfad für die Schweiz vorgemerkt.

### Intern
- PEGELONLINE `WV/measurements.json` liefert kompakt bis zu 16 zukünftige Werte inkl. Forecast/Estimate, Initialisierungszeit und verfügbaren P10/P90.
- Providerabhängige Freshness-Grenzen im Official Observation Broker; fehlende/unplausible Zeitstempel werden nicht priorisiert.
- Neuer Wartungsvertrag `test-source-maintenance-098476.mjs` und erweiterter Designvertrag `test-design-readability-3-098476.mjs`.
- Chromium-Layoutmatrix mit dem erzeugten MID-CSS für 320×568 bis 1920×1080 ohne horizontalen Auditüberlauf; geprüfte sichtbare Mikrotexte mindestens 11 px.
- Worker-Fachlogik geändert; Worker-Deployment erforderlich.

## 0.9.84.75

### Extern
- Quellen-Audit erweitert MID gezielt um amtliche und spezialisierte Datenwege: EUMETSAT MTG-LI, UBA-Luftdaten, SwissMetNet/KNMI-Beobachtungen, PEGELONLINE, MeteoAlarm EDR, NOAA MRMS, WIS2, Copernicus Marine und GloFAS.
- Luftqualität trennt in Deutschland aktuelle UBA-Messwerte von der CAMS/Open-Meteo-Prognose; EEA bleibt Fallback.
- Wasseransicht kann amtliche PEGELONLINE-Pegel und einen ausdrücklich als Modell gekennzeichneten GloFAS-Abflussausblick zeigen; Copernicus Marine kann Marineparameter serverseitig reduziert liefern.
- Europäische Konvektion nutzt MTG-FCI/LI vollständiger; US-Radar kann regional NOAA MRMS verwenden. Nationale Warn-/Radar-/Beobachtungsquellen und OPERA bleiben erhalten.
- EFAS wird wegen des öffentlichen Zeitverzugs nicht als aktuelle Hochwasserprognose ausgegeben.

### Intern
- Neue Adapter sind fail-safe und optional; Rohformate NetCDF/GRIB2/GeoTIFF/BUFR werden nicht im mobilen Requestpfad dekodiert.
- KNMI-Legacyquellen sowie ECMWF-50r1-Legacystreams werden durch den neuen Quellenvertrag abgefangen.
- WIS2 akzeptiert das kanonische Schema `mid-official-observation-v1`; nationale Direktquellen behalten Vorrang.
- Neuer Pflichtvertrag `test-source-audit-official-sources-098475.mjs`; bestehende OPERA-/EEA-Regressionen bleiben aktiv.
- Historischer Selected-Line-Test an die seit v0.9.84.74 bewusst flüchtige Profil-Overlay-Architektur angepasst; sichtbare Wind-/Luftdruckwerte bleiben geschützt.
- Worker-Fachlogik geändert; Worker-Deployment erforderlich.

## 0.9.84.74

### Extern
- Geräteübergreifender Layout-Audit mit typischen iPhone-, Android-/Handy-, iPad-/Split-View- und Desktopgrößen: kritische Text-, Karten-, Tooltip- und Overlay-Muster wurden auf Überlauf, unschöne Umbrüche und abgeschnittene Inhalte geprüft.
- Eventplaner auf schmalen Displays vollständig lesbar: Workspace-Tabs, Sortierung, lange Eventnamen, Orte und Wetterkurzinfos werden nicht mehr per Ellipse abgeschnitten, sondern erhalten bei Bedarf zusätzlichen Platz bzw. Zeilen.
- Das 24-h-Wetterprofil zeigt die Werte-Pillen nicht mehr dauerhaft. Maus/Trackpad: nur bei Hover/Fokus; Touch: nach Antippen zeitlich begrenzt und danach automatisch ausgeblendet. Die dauerhafte Zeitmarkierung und der Bereich „Einzeldaten“ bleiben erhalten.
- Ensemble-Diagramm-Tooltips nutzen auf Mobilgeräten die verfügbare Viewportbreite, können intern vertikal scrollen und zeigen auch lange Modell-, Niederschlags-, Sonnenschein- und Hinweisangaben vollständig. Sehr schmale und niedrige Landscape-Fenster besitzen eigene Fallbacks; die Tooltipfläche ist deckend, damit darunterliegende Diagrammtexte die Lesbarkeit nicht beeinträchtigen.
- Keine Änderung an Wetterdaten, Modellfusion, Ensembleberechnung, Warnlogik, Piktogrammen oder Parameterfarben.

### Intern
- Browser-Viewport-Matrix geprüft: 320×568, 360×800, 390×844, 430×932, 844×390, 600×1024, 768×1024, 834×1194, 1024×1366, 1366×768, 1440×900 und 1920×1080. Die repräsentativen Hochrisikomuster bestanden ohne dokumentweiten horizontalen Überlauf.
- `ForecastCockpit` trennt nun dauerhafte Zeitauswahl und flüchtige Werte-Overlays; Touch-Overlay schließt nach 4,8 s, Escape/Outside/Blur sowie Pointer-Leave bei Fine Pointer schließen sofort. Outside-/Escape-Dismissal nutzt wieder die zentrale MID-Primitive `useDismissibleLayer`.
- Event-Center-Sortierung erhält mobil eine eigene volle Zeile; Event-Workspace-Beschriftungen und Wetterkurzinfos dürfen sinnvoll umbrechen.
- Ensemble-Tooltip beseitigt ältere hochspezifische `nowrap`-/7,8-px-Overrides bei Einzelwertzeilen; lange Schlüsselwörter werden auf breiten Tooltips nicht mitten im Wort getrennt und auf schmalen Geräten gestapelt.
- Bestehende historische Tooltip-/Interaktionstests wurden nur dort versionsresilient gemacht, wo spätere Wartungsstände bewusst neue Layoutverträge setzen. Zusätzlich wurden die zehn im v0.9.84.73-CI noch auf die frühere ausführliche Istwetterdarstellung fixierten Verträge auf die neue kompakte `(i)`-Informationsarchitektur aktualisiert; die fachlichen Informationen bleiben erhalten.
- Neuer Pflichtvertrag `test-responsive-layout-tooltip-098474.mjs`; Stylesheet-Aggregat erneut aus den fünf kanonischen Modulen erzeugt.
- Releaseversion und Cache-/iOS-/Worker-Metadaten auf 0.9.84.74 synchronisiert; Worker-Fachlogik unverändert.

## 0.9.84.73

### Extern
- Detailansichten, Popover und Sekundärbedienung auf iPhone, iPad und Desktop weiter vereinheitlicht: Quelleninformationen, UV-Hinweise, Modellstände und erweiterte Einstellungen sind besser lesbar.
- Modellstand- und Inline-Steuerungen in Berg-/Wasseransichten verwenden keine historischen 7–8-px-Beschriftungen mehr; auf Touchgeräten bleiben die Bedienziele bei 44 px.
- Ensemble-Tooltips wurden für schmale Displays neu skaliert: größere Beschriftungen und Metadaten bei weiterhin kompakter, kollisionsarmer Matrix.
- Die mobile Tmin/Tmax-Pille unterschreitet nicht mehr die aktuelle MID-Lesbarkeitsschwelle.
- Langfrist-/C3S-/DWD-Statusinformationen wurden nachgezogen; kleine Modell-/Qualitätslabels verwenden jetzt die semantische MID-Typografie.
- Keine Änderung an Wetterdaten, Modellfusion, Ensembleberechnung, Warnlogik, Piktogrammen oder Parameterfarben.

### Intern
- `metric-source-info`, UVI-Popover, Modelländerungsradar, Advanced-Feature-Disclosures und Push-Hinweise auf `--mid-text-*` standardisiert.
- Spät geladenes `v078.css` erhält einen expliziten Kaskadenabschluss für Modellstände, `module-inline-*` und die mobile Tmin/Tmax-Pille, damit ältere 6,5–8-px-Regeln die neueren Designverträge nicht mehr überschreiben.
- Ensemble-Tooltip erhält einen 340/320-px-Desktop-/Mobile-Vertrag und einen separaten <=360-px-Fallback mit mindestens 9,5–10 px in den dichtesten Metazeilen.
- Stunden-Tooltip-Schließen sowie Langfrist-Legenden erreichen auf groben Touch-Pointern 44 px.
- Der v0.9.84.72-Headervertrag wurde versionsresilient gemacht, damit er Folge-Wartungsstände weiterhin schützt.
- Buildfix für den fehlgeschlagenen v0.9.84.72-Installer: die nach der Istwetter-Verdichtung nicht mehr verwendeten Astronomie-Imports `formatDayLengthChange` und `formatDuration` wurden aus `App.tsx` entfernt; keine Funktionslogik wurde zurückgerollt.
- Neuer Pflichtvertrag `test-secondary-detail-popover-readability-098473.mjs`; Stylesheet-Aggregat erneut aus den fünf kanonischen Modulen erzeugt.
- Releaseversion und Cache-/iOS-/Worker-Metadaten auf 0.9.84.73 synchronisiert; Worker-Fachlogik unverändert.

## 0.9.84.72

### Extern
- Screenshot-getriebener Header-/Istwetter-Audit für iPhone, iPad und Desktop: die vollständige Versionsnummer bleibt auch bei schmaler Kopfzeile sichtbar.
- Sehr schmale Geräte erhalten einen sicheren zusätzlichen Header-Fallback, statt Versionsnummer oder Aktionsschalter zu überdecken.
- Die kompakte Beschriftung „Feuchte / Taupunkt“ darf auf kleinen Breiten sauber zweizeilig umbrechen und kollidiert nicht mehr mit dem Feldrand.
- Die Kacheln unter „Aktuelles Wetter > mehr“ zeigen nur noch die unmittelbar entscheidungsrelevante Kurzinfo. Quellen, Methodik und längere Einordnungen liegen hinter dem jeweiligen (i)-Button.
- Sichtbare Karten-Zusammenfassungen sind auf höchstens zwei Zeilen begrenzt; die vollständigen Informationen bleiben erreichbar.
- Keine Änderung an Messwerten, Modellfusion, Wettercodes, Warnlogik, Piktogrammen oder Parameterfarben.

### Intern
- Responsive Header-Kaskade für <=430 px auf getrennte `max-content`-Spalten umgestellt; <=360 px zusätzlicher dreizeiliger Fallback für Brand/Aktionen/Suche.
- `Current`-MetricCards in Primärwert, optionale Kurzbeschreibung und ausführliche Infoebene getrennt; Datenquellen werden nicht entfernt, sondern in die bestehende Info-Popover-Struktur verschoben.
- Taupunkt-/Feuchte-Fact erhält mobil explizite Umbruchfreigabe; Infoziele der Istwetter-Karten bleiben auf Touch bei 44 px.
- Neuer Pflichtvertrag `test-current-header-density-098472.mjs`; Stylesheet-Aggregat erneut aus den fünf kanonischen Modulen erzeugt.
- Releaseversion und Cache-/iOS-/Worker-Metadaten auf 0.9.84.72 synchronisiert; Worker-Fachlogik unverändert.

## 0.9.84.71

### Extern
- Visualisierungs-Audit Block 2 abgeschlossen: Wasser/Tide, Flugmeteorologie, Events/Reise, Warn-/Gefahrendarstellungen sowie Karten-/Radar-Tooltips sind auf iPhone, iPad und Desktop besser lesbar.
- Sehr kleine historische 5–9-px-Beschriftungen wurden dort gezielt angehoben; wissenschaftlich dichte Karten-/Diagrammwerte bleiben kompakter als normale UI-Texte.
- Auf Touchgeräten erhalten zentrale Warn-, Reise-, Event-, Flug- und Radarbedienelemente weiterhin robuste 44-px-Trefferflächen.
- Für iPad Split View und schmale Fenster werden Wasser-, Tide-, Reise- und Flugkarten weniger stark zusammengedrückt; horizontale Zeitreihen nutzen Scroll-Snap statt Mikrotypografie.
- Keine Änderung an Wetterdaten, Tide-/Strömungsberechnung, Fluggefahren, Warnschwellen, Event-/Reiselogik, Radar/Nowcast, Piktogrammen oder Parameterfarben.

### Intern
- Zweiter Visualisierungsvertrag in `30-modern.css` für Wasser/Tide, Flug-/Routenwetter, Events, Reise, Warn-/Gefahrendarstellungen und Karten-/Radar-Tooltips.
- Flug-Cross-Section-Achsen/Standardwerte, Wasser-Timeline, Reise-Tagesstreifen, kompakte Radarlegende und Druck-/DWD-Kartentooltips komponentenbezogen standardisiert.
- Neuer Pflichtvertrag `test-visualization-readability-2-098471.mjs`; Stylesheet-Aggregat erneut aus den fünf kanonischen Modulen erzeugt.
- Releaseversion und Cache-/iOS-/Worker-Metadaten auf 0.9.84.71 synchronisiert; Worker-Fachlogik unverändert.

## 0.9.84.70

### Extern
- Mobile, iPad und Desktop verwenden den neuen MID-Designvertrag nun über alle Hauptansichten hinweg konsistenter.
- Klima, Meteogramme, Ensemble-, 7-Tage-, Langfrist- und Synoptikdarstellungen sind besser lesbar, ohne Wetterinformationen zu entfernen.
- Touchbedienung und Formulare auf iPhone/iPad wurden weiter vereinheitlicht; Eingabefelder vermeiden unnötigen Safari-Fokuszoom.
- Wetterlogik, Warnungen, Farben und Piktogramme bleiben unverändert.

### Intern
- App-weite Designabdeckung für alle Hauptmodule abgesichert.
- Visualisierungs-Audit Block 1 mit gezielten Achsen-/Legenden-/Tooltip-Größen umgesetzt.
- Neue Regressionen `test-appwide-design-coverage-098470.mjs` und `test-visualization-readability-098470.mjs`.
- Releaseversion und Cache-/iOS-/Worker-Metadaten auf 0.9.84.70 synchronisiert.

## 0.9.84.69

### Extern
- Mobile und Desktop folgen jetzt einem gemeinsamen adaptiven Bedienvertrag: Bedienelemente richten sich stärker nach verfügbarer Fläche und Eingabemethode statt nach einem festen Gerätetyp.
- Auf Touchgeräten erhalten zentrale Schaltflächen und Infoziele eine robuste Trefferfläche; die Fünf-Bereiche-Navigation ist auf iPhone besser lesbar und bleibt in niedrigen/breiten Fenstern kompakt bedienbar.
- iPad-/Desktop-Navigation nutzt bei regulärer Breite weiterhin die platzsparende Seitenleiste; Safe Areas, Split View und zusätzliche Trackpad-/Mausbedienung werden sauberer berücksichtigt.
- Einstellungen, Systemdialoge, Planner, Quellenhinweise und Istwetter-Metadaten verwenden eine konsistentere Mindesttypografie.
- 14-Tage-Karten werden auf schmaleren Breiten nicht mehr durch Mikrotypografie verdichtet, sondern als breitere, horizontal scrollbare Karten dargestellt. Alle Prognoseparameter bleiben sichtbar.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Niederschlagsfarben, MID-Piktogrammen oder wissenschaftlichen Berechnungen.

### Intern
- Neuer Apple-2026-WebApp-Vertrag mit getrennten Mindestgrößen für Touch und Fine Pointer sowie zusätzlicher `any-pointer: coarse`-Absicherung für iPad mit Trackpad/Maus.
- Safe-Area-Innenabstände und die optionale Fünf-Bereiche-Navigation auf verfügbare Breite/Höhe standardisiert; neuer Compact-Height-Pfad ersetzt für den aktuellen Kaskadenabschluss die bisherige reine Querformatverdichtung.
- Semantische MID-Typografietokens angehoben; normale UI-Mikrotexte beginnen bei 11 px, während datenreiche SVG-/Diagrammachsentexte bewusst separat kompakt bleiben.
- 14-Tage-Ansicht auf kompakten Breiten auf 188–196 px breite Scroll-Snap-Karten mit lesbaren 11–15-px-Inhalten und 44-px-Infoziel umgestellt.
- Boot-Recovery-Schaltflächen auf 44 px Mindesthöhe angehoben; `viewport-fit=cover` und bestehende Safe-Area-Verträge bleiben erhalten.
- Neuer Pflichtvertrag `test-apple-adaptive-design-contract-098469.mjs`; Worker-Fachlogik unverändert, ausschließlich Versionssynchronisierung.

## 0.9.84.68

### Extern
- Open-Meteo-Watch-Patch integriert: die derzeit von Open-Meteo suspendierten KMA-UM-Pfade LDPS/GDPS werden nicht mehr als aktive Prognosemodelle angeboten oder in die MID-Fusion aufgenommen.
- Für Südkorea nutzt der Hyperlokal-Hintergrund während der KMA-KIM-Migration JMA MSM/JMA Seamless und anschließend Open-Meteo Best Match als Fallbackkette.
- Météo-France AROME HD 15 min bleibt aktiv und wird im Worker vor dem stündlichen AROME-HD-Fallback verwendet; damit bleibt die von Open-Meteo am 11.09.2026 korrigierte 15-min-Niederschlags-/Schneelogik nutzbar.
- Ensemble-Offenlegung und Prognose-Kompass sind auf iPhone/iPad besser lesbar: Status-/Erklärungstexte nutzen die gemeinsame MID-Typografieskala und der zentrale Auf-/Zuklappbereich erhält größere Touchziele.
- Keine Warn-, Schwellen-, Niederschlagsphasen-, Piktogramm- oder Modellgewichtungslogik entfernt.

### Intern
- KMA LDPS/GDPS aus Frontend- und Worker-Katalog entfernt; veraltete `globalIds`-Referenz ebenfalls bereinigt.
- `meteofrance_arome_france_hd_15min` als erster Worker-API-Pfad der bestehenden Météo-France-AROME-Familie ergänzt; stündliches HD, AROME France und Seamless bleiben als Fallbacks erhalten.
- Bestehenden Modellfamilienvertrag um Suspendierungs-, Südkorea-Fallback- und AROME-15-min-Schutz erweitert.
- Neuer Pflichtvertrag `test-openmeteo-watch-ensemble-ui-098468.mjs` schützt Patchintegration, Aggregate und Ensemble-UI-Standardisierung.
- Worker-Fachlogik geändert; Worker-Deployment ist für diesen Stand erforderlich.

## 0.9.84.67

### Extern
- Kurzfrist-, 90-Minuten- und 24-h-Flächen auf iPhone/iPad besser lesbar: Wetter-, Niederschlags-, Wind- und Zeitangaben verwenden konsistentere Mindestgrößen statt historischer 5–9-px-Einzelwerte.
- Kompositbild übersichtlicher bedienbar: Tabs, Layeruntertitel, Kartenstatus, Zeitlinie, Standortzusammenfassung und minimierte Legende wurden typografisch vereinheitlicht und zentrale Touchziele vergrößert.
- Das 24-h-Wetterprofil behält seine wissenschaftliche Informationsdichte; Achsen-, Zeit-, Wolken- und Warnschwellenbeschriftungen wurden nur moderat vergrößert, damit Kurven und Skalen nicht überlagern.
- Keine Änderung an Wetterdaten, Zeitintervallen, Niederschlags-/Windlogik, Komposit-Layern, Radar/Nowcast, Piktogrammen oder Warnschwellen.

### Intern
- Kurzfrist-/Nowcast-/Komposit-UI schrittweise auf `--mid-text-micro/xs/sm` weitergeführt; keine globale CSS-Vergrößerung.
- Komposit-Tabs mindestens 44 px; Live-/Ortungs-/Legenden- und Profilaktionen erhalten robustere Touchflächen, auf groben Touch-Pointern bis 40–44 px.
- Mobile Alt-Overrides, die 90-Minuten-/Komposittexte wieder auf 5,9–8 px verkleinerten, durch einen expliziten Kaskadenabschluss neutralisiert.
- Neuer Pflichtvertrag `test-shortterm-composite-readability-098467.mjs` schützt Lesbarkeit, Touchziele, Funktionsbestand und kanonische Stylesheet-Synchronität.
- Worker-Fachlogik unverändert; ausschließlich Versionssynchronisierung.

## 0.9.84.66

### Extern
- Extremwetter-Ausblick auf iPhone/iPad und Desktop besser lesbar: Zeitraum, Gültigkeit, Regionen, Legenden, Methodik und Schwellentabellen nutzen jetzt die gemeinsame MID-Typografieskala statt historischer 7–9-px-Einzelwerte.
- Gefahrenarten, Zeitraum, Aktualisieren, Regionsauswahl, Karten-Zoom und Methodik-Info besitzen konsistentere Touchflächen; auf Touchgeräten werden zentrale Ziele auf 40–48 px angehoben.
- Die Kartenlegende und modellierten Flächenbeschriftungen bleiben kompakt, sind aber klarer ablesbar. Fachliche I1–I4-/Wahrscheinlichkeitslogik, Schraffur, amtliche Warntrennung und Karteninhalte bleiben unverändert.

### Intern
- `25-extreme-outlook.css` komponentenweise auf `--mid-text-micro/xs/sm/meta` standardisiert; kein globaler CSS-Umbau.
- MapLibre-Zoomtasten und Methodik-Info nur innerhalb des Extremwetter-Moduls vergrößert, damit andere Kartenmodule nicht unbeabsichtigt verändert werden.
- Neuer Pflichtvertrag `test-extreme-outlook-readability-098466.mjs` schützt Lesbarkeit, Touchziele, wissenschaftliche Einordnung und Funktionsbestand.
- Worker-Fachlogik unverändert; ausschließlich Versionssynchronisierung.

## 0.9.84.65

### Extern
- Kopfzeile, Suche und Favoriten auf iPhone/iPad konsistenter bedienbar: kleine Suchfeldaktion und Favoriten-Schaltflächen besitzen größere Trefferflächen.
- Favoriten-Untertexte sowie Kennzeichen wie Standard/Ski/Wasser und POI-Typen sind besser lesbar, ohne die kompakte Schnellleiste aufzugeben.
- Im optionalen Bottom-Tab-Layout werden Favoriten nicht mehr auf 30 px Bedienhöhe verkleinert; horizontales Scrollen und kompakte Darstellung bleiben erhalten.
- Keine Änderung an Favoritenauswahl, Standortbestimmung, Reihenfolge, Wetterdaten oder meteorologischer Fachlogik.

### Intern
- Kopf-/Favoritenbereich auf die vorhandenen MID-Typografietokens `micro/xs/sm` weitergeführt.
- Suchfeldaktion 36 px, auf groben Touch-Pointern 40 px; Favoritenverwaltung und Schnellzugriffe erhalten konsistente Mindestgrößen.
- Drag-Griff der Favoritenleiste sichtbar verbreitert; Drag-and-drop und vorhandene Pfeiltasten bleiben parallel erhalten.
- Favoritenverwaltung: Regel-, Berg- und Wasserprofil-Beschriftungen von historischen Mikrogrößen auf semantische UI-Typografie angehoben.
- Neuer Pflichtvertrag `test-header-favorites-readability-098465.mjs` schützt Lesbarkeit, Touchziele, Funktionsbestand und Stylesheet-Synchronität.
- Worker-Fachlogik unverändert; ausschließlich Versionssynchronisierung.

## 0.9.84.64

### Extern
- Reise-Center auf iPhone/iPad besser lesbar: Navigation, Reisezeitraum, Schnellkennwerte sowie Quellen- und Modellinformationen verwenden keine extrem kleinen 6–8-px-Beschriftungen mehr.
- Schaltflächen zum Öffnen von Details, Bearbeiten und Lösen angehefteter Reisen besitzen größere Bedienflächen, ohne die kompakte Darstellung aufzugeben.
- Keine Änderung an Reiseprognose, Klimareferenz, Wetterdaten oder Modellgewichtung.

### Intern
- Reise-Center schrittweise auf die bestehenden MID-Typografietokens `micro/xs/sm` migriert; das setzt den UI-/Konsistenzaudit aus 0.9.84.62 komponentenweise fort.
- Touchziele der Reise-Center-Navigation und -Aktionen auf mindestens 36 px, auf groben Touch-Pointern teilweise 40 px angehoben.
- Neuer Pflichtvertrag `test-travel-center-readability-098464.mjs` schützt Lesbarkeit, Touchziele und die Synchronität des kanonischen Stylesheets.
- Worker-Fachlogik unverändert; ausschließlich Versionssynchronisierung.

## 0.9.84.63

### Extern
- Release-Installer #1018 korrigiert; der Design-/Konsistenzstand aus 0.9.84.62 und sämtliche Wetterfunktionen bleiben unverändert erhalten.
- Keine Änderung an Wetterdaten, Piktogrammen, Warnungen, Modellfusion oder Bedienlogik.

### Intern
- Veralteten Present-Weather-Regressionsvertrag an die seit 0.9.84.61 erweiterte WMO/DWD-Code-Priorisierung angepasst.
- UI-Audit-Regression 0.9.84.62 so stabilisiert, dass spätere Wartungsversionen den geschützten Designstand weiter prüfen können, ohne an eine historische Versionsnummer als aktuelle Releaseversion gebunden zu sein.
- Releaseversion auf 0.9.84.63 synchronisiert.

## 0.9.84.62

### Extern
- Design-/Bedienaudit: Lesbarkeit und visuelle Hierarchie der zentralen Istwetter- und Einstellungsflächen vereinheitlicht, ohne Wetterfunktionen oder Datenquellen zu entfernen.
- „Aktuelles Wetter“ zeigt Sichtweite und Luftdruck jetzt auch auf schmaleren Displays weiter an; die fünf Kernfakten ordnen sich responsiv statt ausgeblendet an.
- Kleine Info- und Sortier-Schaltflächen besitzen auf Touch-Geräten größere Trefferflächen. Die vorhandenen Pfeiltasten als Alternative zum Ziehen werden deutlicher benannt.
- Sehr kleine Beschriftungen im aktuellen Wetter, Temperaturbereich und ausgewählten Kompaktinformationen wurden auf eine besser lesbare semantische Typografieskala angehoben.

### Intern
- Semantische MID-Typografietokens (`micro/xs/sm/meta`) moderat standardisiert; chart- und kartenspezifische Mikrotypografie bleibt bewusst separat, damit keine Diagramme überlaufen.
- Responsiver Istwetterblock nutzt unter 900 px ein 6-Spalten-Raster: Niederschlag/Wind/Feuchte in der ersten, Sicht/Luftdruck in der zweiten Zeile; im niedrigen Querformat bleiben fünf Werte einzeilig.
- Dashboard-Sortierung und Favoritenreihenfolge behalten Drag-and-drop, verweisen aber expliziter auf die bereits vorhandenen Pfeiltasten als barriereärmere Alternative.
- Bestehende Wetterfarben, Piktogramme, Modell-/Beobachtungslogik und Datenquellen unverändert.
- Neuer Pflichtvertrag `test-ui-audit-standardization-098462.mjs`.
- MapLibre GL 6.9.0 als verfügbares Minor-Update identifiziert, in diesem Wartungsstand aber bewusst nicht aktualisiert, da in der isolierten Build-Umgebung keine vollständige Dependency-Neuinstallation verifiziert werden konnte.

## 0.9.84.61

### Extern
- Wetterzustände app-weit sprachlich und fachlich vereinheitlicht: zeitpunktbezogene Schauer werden korrekt im Singular bezeichnet, z. B. „Leichter Regenschauer“, „Mäßiger Schneeschauer“ und „Starker Hagelschauer“.
- Numerische DWD-SYNOP-ww-Codes werden im Bereich „Aktuelles Wetter“ jetzt direkt als Wetterzustand und passende Piktogrammintensität interpretiert.
- Der Startpfad für aktuelles Wetter/Hyperlokalanalyse wurde auf Mobilgeräten priorisiert, ohne Beobachtungsquellen oder Qualitätskontrollen zu reduzieren.

### Intern
- Present-Weather-Texte in `WeatherPictogram.tsx` grammatisch vereinheitlicht und Satzanfänge konsistent großgeschrieben.
- DWD/WMO-ww 80–92 auf Singularformen synchronisiert; generierte Wetteraggregate neu aufgebaut.
- Fast-Observation-Vorladung von 120 auf 40 ms vorgezogen; Ensemble-Bootstrap von 260 auf 420 ms versetzt.
- Nichtkritische UI-Chunk-Vorladung startet erst nach Forecast/Station oder spätestens nach 700 ms.
- Vollständige Hyperlokalanalyse nach dem Provisional-Pass von 180 auf 80 ms vorgezogen.
- Neue Pflichtregression `test-german-weather-terminology-performance-098461.mjs`.

## 0.9.84.60

### Extern
- Widget-Kurvenübersicht: Temperatur-Hilfslinien moderat kontrastreicher, ohne die Kurve optisch zu überlagern.
- Aktuelles Wetter: Bewölkungsabgleich in Deutschland nutzt DWD CDC 10-min, direkten DWD-SYNOP/OpenData-POI und METAR/SPECI gemeinsam; Bright Sky bleibt ausschließlich Fallback.
- In der Hyperlokal-Info wird die tatsächlich verwendete Bewölkungsbasis feldbezogen ausgewiesen.

### Intern
- DWD-SYNOP `cloud_cover_total` wird als Achtelwert 0–8/8 erkannt und auf 0–100 % normalisiert; 9 (Himmel nicht auswertbar/verdeckt) wird nicht als 112,5 % oder künstlich bedeckt interpretiert.
- DWD-SYNOP-Gesamtbewölkung erzeugt eine qualitative Himmelsbeobachtung und nimmt damit an derselben offiziellen SYNOP/METAR-Plausibilisierung teil.
- Beim Zusammenführen derselben physischen Station darf eine sekundäre METAR-Qualitativmeldung den bereits höher gewichteten SYNOP-Wolkenwert nicht mehr überschreiben.
- BUFR wird bewusst nicht als zusätzliche unabhängige Quelle gezählt, wenn es dieselbe DWD-Stationsbeobachtung nur in einem anderen Transportformat enthält.
- Neuer Regressionsvertrag `test-current-observation-multisource-cloud-098460.mjs`.

## 0.9.84.59

### Extern
- Release-Installer #1014 korrigiert; Synoptik mit Isohypsen, Fronten und Druckzentren bleibt vollständig erhalten.

### Intern
- Veralteten Performancevertrag aktualisiert: `synoptic.ts` ist seit der gewünschten Komposit-Synoptik bewusst wieder aktiv.
- Performancegrenze bleibt erhalten: `RadarPanel` wird weiterhin per `lazy()` geladen; `synoptic.ts` ist ausschließlich über diesen lazy Radar-/Kompositpfad erreichbar.
- Das separate alte `SynopticPanel.tsx`, Routenwetter und verworfene Rekonstruktionsmodule bleiben dormant.
- Keine Änderung an meteorologischer Logik, Frontanalyse, Isohypsen, H/T-Zentren oder Worker-Domainlogik gegenüber v0.9.84.58.

## 0.9.84.58

### Extern
- Release-Installer #1013 korrigiert; Fronten, Isohypsen, Geopotentialwerte und Druckzentren aus den vorherigen Synoptikverbesserungen bleiben unverändert erhalten.

### Intern
- TypeScript-7-Typfehler im Fronten-Tooltip behoben: das im lokalen MID-Leaflet-Typvertrag nicht unterstützte `sticky`-Prop wurde entfernt.
- Neue Regression `test-composite-front-tooltip-types-098458.mjs` schützt den #1013-Fehler.
- Keine fachliche Änderung an Frontanalyse, Konturen, H/T-Zentren oder Worker-Gridlogik.

## 0.9.84.57

### Extern
- Release-Installer #1012 korrigiert; Synoptik-Fallback, Fronten, Isohypsen und Druckzentren aus v0.9.84.56 bleiben vollständig erhalten.

### Intern
- TypeScript-Parserfehler in `compositeFrontSymbols()` behoben. Die Frontensymbole werden nicht mehr als fragile Einzeilen-TSX-Struktur erzeugt.
- Frontsymbol-Variante ist explizit auf `cold | warm` typisiert; `L.divIcon()` und `<Marker />` sind strukturell getrennt.
- Neue Regression `test-composite-front-symbol-jsx-098457.mjs` schützt genau den #1012-Fehler.
- Keine fachliche Änderung an Frontdiagnostik, Isohypsenlogik oder Worker-Gridparametern gegenüber v0.9.84.56.

## 0.9.84.56

### Extern
- Komposit-Synoptik vollständig verdrahtet: 500-hPa-Isohypsen erscheinen sofort über einen DWD-WMS-Fallback und werden nach Verfügbarkeit durch geglättete MID-Konturen ersetzt.
- H/T-Druckzentren werden aus dem großräumigen Druckraster nachgeladen.
- Objektiv erkannte Kalt-/Warmfronten, Okklusionen, Trog- und Konvergenzachsen werden jetzt auch im Komposit-Synoptikmodus dargestellt.
- Mobile Erstladung der großräumigen Synoptik robuster gegen langsame Netze.

### Intern
- Ursache für den Screenshotbefund: native Isobaren, geglättete Isohypsen/Druckzentren und Frontdiagnostik liefen über drei getrennte Pfade; nur der Isobarenpfad war im Komposit zuverlässig unmittelbar sichtbar.
- Grid-Timeout für `model-contours?renderer=grid` von 15 s auf 45 s erhöht, Cache/Fallback getrennt abgesichert.
- Worker-Gridabfrage behält das 17×25-Europa-Raster bei, erhöht aber die begrenzte Zeilenparallelität von 4 auf 6.
- Objektive Frontanalyse aus `synoptic-analysis` in RadarPanel eingebunden.
- Neuer Regressionsvertrag `test-composite-synoptic-completeness-098456.mjs`.

## 0.9.84.55

### Extern
- Synoptik: 500-hPa-Isohypsen werden wieder als deutlich sichtbare Linien dargestellt, nicht nur als Geopotential-Labels. Isohypsen sind automatisch amber/gold mit dunklem Halo und damit klar von den nativen DWD-Isobaren getrennt.
- Hauptisohypsen werden durchgezogen, Zwischenisohypsen gestrichelt; die Darstellung bleibt auf heller Karte, Satellitenunterlage und im Dark Mode kontrastreich.
- Release-Installer #1010 korrigiert: drei veraltete bzw. folgebetroffene Regressionen zu CAVOK, Radar-Nowcast und dem absichtlich entfernten Widget-Windpfeil-Schatten wurden auf den aktuellen Vertrag synchronisiert.

### Intern
- Leaflet- und MapLibre-Modelllinien-Panes werden beide explizit abgesichert; Isohypsen erhalten eine eigene sichtbare Stroke-/Halo-Konfiguration.
- CAVOK-Regression schützt die fachliche Trennung zwischen „keine signifikante tiefe Bewölkung“ und „0 % Gesamtbewölkung“.
- Radar-Nowcast darf weiterhin in der aktuellen Wetterkarte direkt erscheinen; Prognoseansichten bleiben an den kanonischen 15-Minuten-/Stundenreihen.
- Widget-Light-Export schützt explizit `box-shadow:none`, `filter:none` und `text-shadow:none` am Windrichtungspfeil.

## 0.9.84.54

### Extern
- Widget-Kurvenexport: grauen Pfeilschatten in der Windkachel entfernt.
- Aktuelles Wetter zeigt Wind und Böen sowie relative Feuchte und Taupunkt gemeinsam; frischer Standort-Radarwert wird für die aktuelle Niederschlagsrate bevorzugt.
- Hyperlokale Bewölkung verbessert: CAVOK wird fachlich als Ausschluss signifikanter tiefer Bewölkung behandelt, nicht als 0 % Gesamtbewölkung. Einzelne entfernte Gesamtbedeckungswerte dürfen den lokalen Modellhintergrund nicht mehr ungebremst auf 8/8 ziehen.

### Intern
- Emsdetten/EDDG-Fall analysiert: öffentliches EDDG-METAR um 10:50 UTC CAVOK; vorherige Filterung verlangte zusätzlich numerischen cloudCover und verlor dadurch die qualitative CAVOK-Gegeninformation.
- CAVOK und explizit wolkenlose Meldungen werden getrennt behandelt; Gesamtbewölkung bleibt modellgestützt, CAVOK begrenzt nur die lokale Korrektur.
- Neue Regression schützt CAVOK-Semantik, schattenfreien Widget-Windexport und die erweiterten aktuellen Wetterwerte.
- Keine Worker-Domainlogik geändert.

## 0.9.84.53

### Extern
- Release-Installer #1008 korrigiert; die Änderungen an „Aktuelles Wetter“, Niederschlagsintensitäten und MID-Piktogrammen bleiben unverändert erhalten.

### Intern
- Zwei veraltete Regressionserwartungen an die vor-v0.9.84.51-Struktur aktualisiert.
- Appweite Niederschlagsprüfung erwartet nun `currentPictogramIntensity` statt der alten direkten `currentPrecip.intensity`-Bindung.
- Layoutprüfung schützt jetzt das neue Aktuell-Wetter-Faktenband und den darunterliegenden Tmin/Tmax-Bereich in Desktop und Mobile.
- Keine Änderung an meteorologischer Laufzeitlogik oder Worker-Domainlogik.

## 0.9.84.52

### Extern
- Release-Installer #1005 korrigiert. Der in v0.9.84.51 eingeführte Aktuelles-Wetter-/Niederschlagsintensitätsstand bleibt unverändert erhalten.

### Intern
- Verbliebene TS2339-Ursache in `EnsemblePanel.tsx` behoben: `ensembleHazardDetail()` liefert bereits einen String; die alte nachgeschaltete `.filter(Boolean).join(' ')`-Kette wurde entfernt.
- Regression schützt den String-Rückgabevertrag des Hazard-Detail-Helfers.
- Keine Änderung an meteorologischer Logik, Piktogrammen, Niederschlagsintensität oder Worker-Domainlogik.

## 0.9.84.51

### Extern
- „Aktuelles Wetter“ app-weit nach dem freigegebenen Konzept aufgeräumt, ohne das bestehende MID-Piktogrammset zu ersetzen.
- Wetterzustände mit Niederschlag zeigen jetzt – soweit belastbar – auch die Intensität: z. B. „Leichter Regen“, „Mäßiger Regen“ oder „Starker Regen“.
- Frische Stations-/SYNOP-/METAR-Angaben steuern Text und Piktogrammintensität gemeinsam; „RA“ wird als mäßiger Regen verstanden, `-RA` als leicht und `+RA` als stark.
- Der aktuelle Wetterblock erhält eine responsive Kernparameterzeile. Mobil: Niederschlag, Wind, Feuchte; bei mehr Platz zusätzlich Sicht und Luftdruck.

### Intern
- Zeitauflösung von Stationsniederschlag fließt in die Intensitätsklassifikation ein; 10-Minuten-Mengen werden nicht mehr stillschweigend wie Stundenmengen behandelt.
- Fehlende beobachtete Niederschlagsrate wird bei vorhandenem Present Weather nicht als 0 mm/h ausgegeben.
- Bestehender WMO/DWD-Piktogramm-, Phasen- und Gewittervertrag bleibt erhalten.
- Neue Regression `test-current-weather-intensity-design-098451.mjs`.

## 0.9.84.50

### Extern
- Release-Installer #1003 korrigiert. Die kompakte 14-Tage-Ensemble-Hinweiszeile bleibt unverändert erhalten.

### Intern
- TypeScript-7-Buildfehler in der Verknüpfung von Windrichtung und Ensemble-/Umfeldkontext behoben.
- Die bisherige fragile Inline-Arrayverkettung wurde durch `ensembleHazardDetail()` mit expliziter String-Typwache ersetzt.
- Keine Änderung an meteorologischer Logik, Rundung, Warnstufe oder Worker-Domainlogik.

## 0.9.84.49

### Extern
- 14-Tage-Ensemble: MID-Hinweise sind wieder meteorologisch intuitiv formuliert. Sichtbar steht der Best-Match-Ereigniswert, z. B. „Sturmböen bis zu 40 kt“, statt eines niedrigeren P90-Kontextwerts.
- Das Tages-Overlay bleibt kompakt. Ensemble-/Umfeldmethodik und Unsicherheitsinformationen liegen hinter einem Info-Button.

### Intern
- Sichtbarer Hinweiswert und Warnbezeichnung stammen wieder aus derselben kanonischen Punktprognose.
- P10/P90 und echtes 12-km-Umfeld bleiben ausschließlich Unsicherheits-/Verlagerungskontext und verschärfen die Warnstufe nicht automatisch.
- Parameterabhängige Rundung: Böen/Wind einheitenbezogen aufwärts; Hitze ganze °C aufwärts; Frost abwärts; Niederschlag/Schnee auf sinnvolle Mengen.
- Neue Regression schützt Best-Match-Hauptwert, „bis zu“-Wording und kompakten Info-Zugang.

## 0.9.84.48

### Extern
- Aktuelles Wetter auf Mobilgeräten neu ausbalanciert: Tmin/Tmax bleibt vollständig innerhalb der Wetterkarte.
- Im Hochformat nutzt der Kopfbereich wieder die verfügbare Breite; Wetter, Nowcast und Hyperlokale Analyse sind ruhiger lesbar.
- Querformat erhält eine überlauffeste Zweispalten-Darstellung mit kompakterem Tagesbereich.

### Intern
- Responsive Regeln nach dem v0.9.84.45-Tagesbereich ergänzt, damit spätere Desktop-Regeln die Mobile-Breakpoints nicht mehr übersteuern.
- Neuer Regressionstest schützt Hoch-/Querformat und Tmin/Tmax vor erneutem Überlauf.
- Keine Änderung an Wetter-, Nowcast-, Hyperlokal- oder Worker-Datenlogik.

## 0.9.84.47

### Extern
- Release-Installer #1000 korrigiert: Die sichtbare Bezeichnung „MID-Hinweise“ im 14-Tage-Ensemble bleibt erhalten.
- Vier veraltete Regressionstests wurden auf die neue, fachlich eindeutige Tooltip-Bezeichnung synchronisiert.

### Intern
- `test-code-quality-0783.mjs`, `test-dwd-warning-markers.mjs`, `test-maintenance-07821.mjs` und `test-warning-ui-07822.mjs` erwarten nun `<b>MID-Hinweise</b>` statt des alten `<b>Hazards</b>`.
- Keine Änderung an Wetterlogik, Warnstufen, Ensemble-/Umfeldwerten oder Worker-Domainlogik.

## 0.9.84.46

### Extern
- 14-Tage-Ensemble: MID-Hinweise zeigen nun tatsächlich die gerundeten probabilistischen/Umfeldwerte statt weiterhin nur den ungerundeten Punkt-Hinweiswert.
- Der Tooltip weist den zugehörigen P10/P90- bzw. 12-km-Umfeldkontext sichtbar aus.
- Release-Installer: zwei durch das Tmin/Tmax-Redesign veraltete Regressionserwartungen aus #999 korrigiert.

### Intern
- `ensembleHazardDisplayValue()` koppelt sichtbaren Hinweiswert und `ensembleHazardContext()` an dieselbe wissenschaftliche Datenbasis.
- Böen: P90/Umfeld-P90 mit einheitenabhängiger Aufrundung; Hitze/Frost ganze °C; Stark-/Dauerregen passende mm-Rundung.
- Keine Warnstufenverschärfung allein durch die Zusatzdarstellung.
- #999: TypeScript 7/Vite waren erfolgreich; nur zwei statische Alt-Tests erwarteten die frühere Tmin/Tmax-DOM-Struktur.

## 0.9.84.45

### Extern
- Aktuelles Wetter: Der heutige Tmin-/Tmax-Bereich ist kompakter, besser lesbar und visuell klarer gegliedert. Tiefst- und Höchstwert stehen nun als ruhige, farblich differenzierte Wertepaarung statt weit auseinandergezogener Einzelwerte.

### Intern
- `hero-day-range` auf gemeinsame Tmin/Tmax-Wertegruppe umgestellt; responsive Darstellung für Desktop, iPhone Hoch-/Querformat abgesichert.
- Dezente Blau-/Rot-Semantik nur für Tmin/Tmax, tabellarische Ziffern und expliziter Accessibility-Text beibehalten.
- Regression `test-current-weather-tmin-tmax-098445.mjs` ergänzt.


## 0.9.84.44

### Extern
- 14-Tage-Ensemble-Meteogramm: MID-Hinweise nutzen nun dieselbe probabilistische Umfeld-/Rundungslogik wie die Kurzfrist-Hinweise, soweit die Daten dies fachlich tragen.
- Wind/Böen, Hitze/Frost, Dauerregen sowie kurzfristig auch Starkregen erhalten gerundete Ensemble-/Umfeldkontexte; lange Vorläufe bleiben bewusst ohne künstliche lokale Schärfung.

### Intern
- `warningEnsemble` wird an alle EnsemblePanel-Pfade (14d-Cockpit, Ensemblemodul, Widget-Ensemble) weitergereicht.
- P90/P10-Kontext: Böen P90, Tmax P90, Tmin P10; 12-km-Umfeld nur bei tatsächlich verfügbaren stündlichen Kurzfristdaten.
- Starkregen nutzt nur echte stündliche Umfeld-P90-Mengen; Tages-P90 wird nicht in 1-/6-h-Mengen umgerechnet. Dauerregen darf P90-Tagesmenge nutzen.
- Werte werden fachlich robust gerundet: Wind 5 km/h bzw. 5 kt/mph oder 2 m/s, Temperatur 1 °C, Niederschlag 1 mm, PoP 5 %.
- Warnstufen bleiben vom zusätzlichen Unsicherheitskontext getrennt; keine automatische Hochstufung aus P90/Umfeldwerten.
# MID v0.9.84.43

## Extern
- Der Release-Blocker aus GitHub-Lauf #996 ist beseitigt. Die Widget-Hinweislage bleibt wie in v0.9.84.42 über den vollständig ausgewählten 3- bis 7-Tage-Zeitraum aktiv.
- An Wetterdaten, Warnschwellen, Piktogrammen oder Widgetdarstellung wurde gegenüber v0.9.84.42 nichts zurückgenommen oder fachlich verändert.

## Intern
- Der einzige #996-Fehler war eine veraltete Regression, die weiterhin den früheren festen Aufruf `summarizeDwdWarnings(..., 24)` erwartete.
- `test-weather-profile-pressure-hazards-09656.mjs` schützt nun den aktuellen Vertrag: 24-h-Standard außerhalb des Widgets, `throughDate` für Widgets und daraus berechnetes `startLimit`.
- GitHub #996 hatte bereits npm ci, Dependency-Audit, TypeScript 7.0.2, Vite 8.2.2 und 740 von 741 Regressionen erfolgreich abgeschlossen.
- Keine neue Worker-Semantik gegenüber v0.9.84.42.

# MID v0.9.84.42

## Extern
- Die MID-Hinweislage in Widgets reicht jetzt über den gesamten gewählten 3-, 4-, 5-, 6- oder 7-Tage-Zeitraum. Hinweise können an jedem ausgewählten lokalen Kalendertag erscheinen; ein pauschales Ende nach 24 Stunden gibt es im Widget nicht mehr.
- Die normale MID-Hinweislage außerhalb des Widgets bleibt unverändert kurzfristig ausgerichtet.
- GitHub-Lauf #995 wurde behoben: TypeScript 7 und Vite waren dort bereits erfolgreich; vier veraltete Regressionserwartungen wurden an den verbindlichen Wetterpiktogramm-Standard 2.1 angepasst.

## Intern
- `hazards()` besitzt einen optionalen `throughDate`-Vertrag. Nur Widgets setzen ihn auf den letzten tatsächlich ausgewählten Tag; ohne Enddatum bleibt der 24-h-Standard erhalten.
- Der 72-h-Folgekontext für mehrstündige DWD-Hazardfenster bleibt fachlich erhalten, während `widgetAutomaticHazardsForDay()` weiterhin nur tatsächliche Tagesüberlappungen rendert.
- Die vier #995-Regressionen schützen nun Stations-/Present-Weather-Felder, Piktogramm-Phänomen + Tag/Nacht, die erweiterten Radarphasen-Schwellen und die aktuellen Nacht-/Gewittergradienten semantisch.
- `MID_FORECAST_CONSISTENCY_CONTRACT.md` schreibt den vollständigen ausgewählten Widget-Hinweishorizont verbindlich fest.

# MID v0.9.84.41

## Extern
- Die Wetterpiktogramme folgen jetzt app-weit dem verbindlichen Wetterpiktogramm-Standard 2.1: Eisnadeln, Schneegriesel, einzelne Schneesterne und Eiskörner sind getrennt; Gewitter mit Graupel/Hagel werden ohne Zusatzinformation nicht mehr fälschlich als reiner Hagel dargestellt.
- Gewitter 95/97 zeigen Regen, Schnee oder Mischphase nur noch, wenn diese Niederschlagsphase tatsächlich bekannt ist. Schauer nach Gewitter (91/92) erscheinen ohne Blitz und ohne fälschlich auflockernde Sonne-/Mondkomponente.
- Sichttrübungen wie Dunst, Rauch, Staub und Sand bleiben grafisch verwandt, werden in Texten, Tooltips und Barrierefreiheit aber eindeutig unterschieden.
- Der PNG-/Zwischenablage-Export der Widget-Kurvenübersicht stellt die Nachtbereiche nicht mehr als schwarze Blöcke dar. SVG-Farben werden vor dem Bildexport auf stabile berechnete Werte festgeschrieben.

## Intern
- `MID_WEATHER_PICTOGRAM_STANDARD.md` auf Standard 2.1 angehoben; Present-Weather- und Phaseninformation wird durch die relevanten Prognose-, Event-, Route-, Wasser-, Radar-, Wetterkarten- und Detailpfade erhalten.
- Alte Niederschlags-/Schnee-Whitelists wurden um 76/78/79 und die getrennten festen Phasen ergänzt; Radar-/Modelllegenden unterscheiden Schneegriesel, Schneesterne, Eisnadeln, Eiskörner, Graupel und Hagel konsistent.
- Neuer Export-Helfer `widgetImageExport.ts`: friert `fill`, `stroke`, Gradient-Stopps und Opazitäten vor `html-to-image` als browseraufgelöste Werte ein und stellt danach den Live-DOM wieder her. Nachtbänder besitzen zusätzlich einen expliziten exportfesten Fallback.
- Neue Regressionen für den app-weiten Piktogrammvertrag und den SVG-Export. Worker-Semantik ist durch die Present-Weather-/Phasenpräzisierung berührt und bleibt über den abgesicherten automatischen Worker-Deploypfad releasepflichtig.

# MID v0.9.84.40

## Extern
- Der verbliebene Release-Blocker aus GitHub #993 ist beseitigt. Der eigentliche MID-Build einschließlich TypeScript, Vite, Regressionen und iOS-Webkopie war bereits vollständig erfolgreich; der Lauf stoppte erst anschließend bei der sicheren Worker-Veröffentlichung.
- Die Cloudflare-Worker-Vorbereitung und die kontrollierte Prüfung ihrer Metadaten laufen jetzt in getrennten GitHub-Actions-Schritten. Dadurch wird der temporäre, zufällig erzeugte Metadatenpfad erst verwendet, nachdem GitHub ihn tatsächlich als Step-Output bereitgestellt hat.
- Wetterberechnung, Temperatur-/Luftdruckdarstellung, kontinuierliche RUC/MOSMIX-Fusion und die kompakten Wetterregime-Pillen bleiben gegenüber v0.9.84.39 fachlich unverändert.

## Intern
- Ursache von #993: `steps.remote_worker.outputs.meta_path` wurde innerhalb desselben Schritts referenziert, der dieses Output erst erzeugt. GitHub Actions löste den Ausdruck deshalb vor Schrittende zu einem leeren String auf; die nachfolgende Python-Prüfung scheiterte an `META_PATH=""`.
- `remote_worker` erzeugt nun ausschließlich die private temporäre Wrangler-/Metadatenkonfiguration und deren Outputs. Ein eigener Folgeschritt übernimmt `meta_path`, validiert Existenz und liest ausschließlich die nicht geheimen Binding-Metadaten.
- Die Regression `test-worker-auto-deploy-09693.mjs` verbietet künftig explizit die fehlerhafte Selbstreferenz eines Step-Outputs und schützt die zweistufige Übergabe. `ci/github/workflows/install-mid.yml` und `workflow-patches/install-mid.yml` sind synchron.
- Da `mid-stable` weiterhin v0.9.84.37 ist, bleibt die fachliche RUC-Worker-Änderung aus v0.9.84.38 deployrelevant. Vor dem nächsten Release-Upload muss deshalb der aktive `.github/workflows/install-mid.yml` einmalig aus der korrigierten kanonischen Fassung synchronisiert werden.

# MID v0.9.84.39

## Extern
- Der Release-Blocker aus GitHub #992 wurde beseitigt. Die fachlichen Änderungen aus v0.9.84.38 an Temperatur-/Luftdruckkonsistenz, kontinuierlicher Tagesfusion, RUC/MOSMIX-Übergängen und den kompakten Regime-Pillen bleiben unverändert erhalten.
- Es wurden keine Wetterwerte, Gewichte oder Darstellungen gegenüber v0.9.84.38 erneut verändert; korrigiert wurden ausschließlich vier nach den bewussten .38-Änderungen veraltete Regressionserwartungen und eine explizite Vertragsdokumentation im Fusionscode.

## Intern
- `test-coherent-weather-bundles-08340.mjs` und `test-priority-forecast-fusion-08320.mjs` erkennen wieder den expliziten Vertrag, dass Menge, Phase, Wahrscheinlichkeit, Wettercode und relevante Wolken-/Konvektionsfelder als kohärentes Wetterbündel erhalten bleiben.
- `test-mosmix-adaptive-fusion-08330.mjs` schützt nun die kontinuierliche `mosmixHourlyLeadStrength()`-Funktion und verbietet den früheren harten +6-h-Gewichtssprung.
- `test-weather-profile-daily-extremes-consistency-09402.mjs` prüft die gemeinsame kanonische Stundenbasis `profileStateSource` für Temperaturkurve, Extrema und Luftdruckskala statt des alten direkten `profileTemperatureSource.map`-Literals.
- GitHub #992 hatte TypeScript 7 und Vite bereits erfolgreich abgeschlossen; der Abbruch erfolgte ausschließlich bei diesen vier von 739 Regressionen.
- Keine neue fachliche Worker-Änderung gegenüber v0.9.84.38; da v0.9.84.38 nicht veröffentlicht wurde, bleibt der in .38 enthaltene RUC-Worker-Fix gegenüber `mid-stable` v0.9.84.37 deployrelevant.

# MID v0.9.84.38

## Extern
- Der auffällige Temperaturverlauf im 24-h-Profil wurde auf Datenfusion und Darstellungsebene geprüft. Echte stündliche Temperaturänderungen bleiben erhalten; künstliche Knicke an Modell-/Tagesgrenzen werden vermieden.
- Temperatur, gefühlte Temperatur, Taupunkt und Luftdruck stehen konsequent auf derselben stündlichen Zeitbasis. Beim Wechsel auf 3 h werden punktbezogene Zustandswerte nicht zu künstlichen 3-h-Mittelwerten geglättet oder verschoben.
- Tagesbasierte Temperaturkorrekturen gehen nun kontinuierlich zwischen den lokalen Tagesmitten ineinander über, statt am Kalendertageswechsel einen harten Sprung erzeugen zu können. ICON-D2-RUC läuft vor +14 h weich aus; MOSMIX-Stundenbeiträge verwenden geglättete Lead-Time-Übergänge.
- Die Luftdruckachse bleibt dynamisch in hPa; der 6-h-Drucktrend wird unabhängig von der gewählten Darstellungsdichte aus der stündlichen Reihe bestimmt.
- In der klassischen 7-Tage-Ansicht erscheinen „Sonnig“, „Ruhig“, „Schauer“ usw. nun als dieselben kompakten Wetterregime-Pillen wie in den übrigen Prognoseansichten. Die versehentlich übergroßen blauen Schaltflächen sind entfernt.

## Intern
- `applyForecastFusionHours()` interpoliert die affine Tageskorrektur für Temperatur sowie Wind/Böen zeitlich stetig zwischen lokalen Tagesmitten. Die bisherige harte, datumsweise Transformation ist entfernt.
- DWD ICON-D2-RUC verwendet geglättete Gewichtsübergänge und läuft zwischen +12 und +14 h kontinuierlich auf null aus. Damit kann das Ende des realen RUC-Horizonts keine künstliche Kante erzeugen.
- Der 3-h-Aggregator verändert Temperatur, gefühlte Temperatur, Feuchte/Taupunkt und Luftdruck nicht mehr zu Blockmittelwerten; punktbezogene Zustandswerte bleiben am gültigen Stundenzeitpunkt erhalten.
- Temperatur-/Thermik- und Luftdruckpfade sowie Druckskala und Drucktrend verwenden dieselbe kanonische stündliche 24-h-Quelle. Niederschlagsakkumulationen bleiben echte Intervallgrößen.
- `ForecastConditionPills` verwendet für die Haupt-Regimepille nicht länger die globale `.primary`-Klasse. Die klassische Regime-Pille übernimmt den gemeinsamen kompakten 2×6-px-/Regimefarbvertrag.
- Bestehende Regressionen für kanonische Temperatur-Extrema, RUC/MOSMIX-Konsens und gemeinsame Wetterregime schützen die neuen Kontinuitätsverträge.
- Fachliche Worker-Änderung durch die geglättete RUC-Gewichtung: Worker-Upload für v0.9.84.38 erforderlich.

# MID v0.9.84.37

## Extern
- Der Release-Blocker aus GitHub #990 wurde beseitigt; die sechs betroffenen Regressionen prüfen jetzt die tatsächlich aktuelle MID-Funktion statt veralteter Texte oder alter Farbwerte.
- Die Quellenangabe benennt DWD Open Data für ICON-D2/RUC/RUC-EPS/MOSMIX wieder ausdrücklich und präzisiert das europäische Radarkomposit als EUMETNET OPERA CIRRUS-Komposit.
- ICAO-Suche, eigenständige Gewitterinformation und das neue Niederschlags-Farbkonzept bleiben unverändert funktional erhalten.

## Intern
- `test-appwide-parameter-colors-09779.mjs` prüft die zentralen Niederschlags-Phasentokens statt obsoleter Hexwerte.
- `test-pictogram-intensity-snow-depth-098426.mjs` schützt die neue Trennung Graupel/Schnee, Misch-/Gefrierphase und Hagel/Gewitter.
- ICAO- und Gewitter-Regressionen wurden von überholten Literalüberschriften auf die aktuelle funktionale/strukturelle UI umgestellt.
- Quellen-/Visible-Internals-Verträge wurden an die aktuelle nutzerorientierte Fußleiste angepasst.
- Keine Änderung an Prognoseberechnung, Event-PoP-Logik, Update-Algorithmus oder Worker-Funktion.

# MID v0.9.84.36

## Extern
- Der Release-Build wurde nach dem fehlgeschlagenen GitHub-Lauf #989 gezielt gehärtet. Die bereits eingeführte Event-PoP- und Update-Logik bleibt fachlich unverändert.
- Sporadisch fehlende Niederschlagswahrscheinlichkeiten können weiterhin nicht allein eine Event-Verschärfung auslösen.

## Intern
- Event-PoP-Deltas verwenden vor der Subtraktion explizit validierte endliche Werte; damit ist die Null-/Undefined-Behandlung unter TypeScript 7 eindeutig.
- Die Service-Worker-Registrierungsabfrage akzeptiert den aktuellen DOM-Vertrag `readonly ServiceWorkerRegistration[]` und materialisiert erst lokal eine filterbare Kopie.
- Die bestehende Update/Event-Regression wurde auf den typsicheren Ausdruck aktualisiert; zusätzlicher CI-Typvertrag `scripts/test-ci-types-event-update-098436.mjs`.
- Keine fachliche Änderung an Wetterfusion, Event-Bewertungsschwellen oder Worker-Logik.

# MID v0.9.84.35

## Extern
- Die Niederschlagsbalken der Tagesansicht folgen jetzt sichtbar und vollständig dem MID-Farbvertrag. Regen, Sprühregen und Schauer bleiben in derselben blauen Niederschlagsfamilie; Schauer erscheinen nicht mehr als eigenständiger türkisfarbener Parameter.
- Schnee und Graupel werden hellblau dargestellt, Misch-/gefrierender Niederschlag violett und Gewitter/Hagel purpur. Graupel und Hagel sind zusätzlich über unterschiedliche Balkenmuster unterscheidbar.
- Die gestrichelte Niederschlagswahrscheinlichkeitskurve bleibt bewusst blau und damit als eigener Wahrscheinlichkeitsparameter unabhängig von der Niederschlagsphase erkennbar.
- Die in v0.9.84.34 umgesetzten Verbesserungen für Updateprozess, Quellenfuß, Event-PoP-Lücken und iOS-26/27-Navigation bleiben vollständig erhalten.

## Intern
- Zentrale Phasenfarbtokens `--param-precipitation-snow`, `--param-precipitation-mixed` und `--param-precipitation-storm` in der kanonischen Foundation eingeführt; Hell-/Dunkelmodus besitzen jeweils abgestimmte Werte.
- `precipitationPhaseColor.ts`, Tagesdetail-SVG-Muster und Legenden verwenden denselben zentralen Vertrag. `hailShowers` ist der Purpur-/Sturmfamilie zugeordnet; Graupel bleibt in der hellblauen Schnee-/Graupelfamilie.
- Gefrierender Regen und Schneeregen verwenden nicht länger überwiegend blaue Füllungen, sondern die verbindliche violette Misch-/Gefrierphase.
- Neue Regression `scripts/test-day-precipitation-color-contract-098435.mjs`; der ältere Skybar-Phasentest wurde auf zentrale Tokens statt veralteter Hex-Literale aktualisiert.
- Keine fachliche Änderung an Wetterberechnung oder Cloudflare-Worker-Logik.

# MID v0.9.84.34

## Extern
- Der Updatevorgang wurde weiter gegen seltene Hänger abgesichert. Langsam installierende App-Shells werden länger beobachtet, ein noch nicht fertiges Update lässt die laufende Version unangetastet, und nach einem bestätigten Service-Worker-Wechsel gibt es einen iOS/PWA-Sicherheitsfallback. Ein vorübergehender Ausfall einer Wetterdatenquelle kann eine technisch korrekt gestartete MID-Version nicht mehr fälschlich zurückrollen.
- Die Quellenübersicht in der Fußleiste wurde auf den aktuellen MID-Datenstand gebracht und nach Leitprognose/Kurzfrist, Ensembles, Langfrist/Saison, Beobachtungen, Warnungen/Radar/Satellit, Klima/Reise/Wasser, Flugmeteorologie sowie Karten/Luftqualität gegliedert. Sie macht deutlicher, dass Quellen nur nach Ort, Horizont und tatsächlicher Verfügbarkeit genutzt werden.
- Event-Bewertungen werden nicht mehr allein deshalb verschärft, weil vorübergehend keine formale Ereignis-Niederschlagswahrscheinlichkeit geliefert wird. Bei vollständiger Stundenabdeckung kann transparent ein zeitgewichtetes Stunden-PoP-Mittel einspringen; fehlt auch dieses, bleiben die übrigen Wetterparameter trotzdem neutral weiter bewertbar.
- Die optionale moderne Navigation wurde behutsam an das aktuelle iOS-Designsystem herangeführt: schwebende, safe-area-fähige Navigation mit glasartiger Funktionsschicht, zurückhaltender Akzentfarbe sowie eigenen Fallbacks für reduzierte Transparenz und erhöhten Kontrast. Wetterkarten und Inhaltsflächen bleiben bewusst klar und informationsorientiert.

## Intern
- Updateinstallation: `updatefound`-Beobachtung bis 45 s, automatische Aktivierungswiederholung und 3-s-Navigationsfallback ausschließlich nach echtem `controllerchange`; kein Reload durch einen alten Controller. Shell-Assets werden begrenzt parallel und weiterhin all-or-nothing gecacht.
- Runtime-Health trennt jetzt stabile App-Shell von Datenquellen-Health. Rollback bleibt für echte Startup-/Shell-Fehler erhalten; Core-Daten werden separat als `ready`/`degraded` diagnostiziert.
- Event-PoP: Ensemble-Ereigniswahrscheinlichkeit bleibt Priorität; vollständige Stunden-PoP-Abdeckung ermöglicht expliziten `hourly-window-average-fallback`. PoP-Deltas werden nur zwischen derselben Quelle verglichen; ein frischer gecachter Event-PoP darf partielle Ensemble-Nachladungen überbrücken, ohne sein Alter zu erneuern.
- Neuer Designvertrag `MID_IOS_26_27_DESIGN_CONTRACT.md` und neue kombinierte Regression `test-update-event-sources-ios27-098434.mjs`. Bestehende Update-/Event-Verträge und Regressionen wurden auf den korrigierten Datenwahrheits- und Recovery-Vertrag aktualisiert.

# MID v0.9.84.33

## Extern
- Der Prognose-Designstand aus v0.9.84.31/32 bleibt nun auch im tatsächlichen Release-Build vollständig erhalten. Die vereinheitlichten Einstiege, mobilen 90-min/24-h-Umschalter, 7-/14-Tage-Layouts und Niederschlagsfarben werden beim Build nicht mehr zurückgesetzt.
- Keine Änderung an den meteorologischen Daten oder Berechnungen gegenüber v0.9.84.32.

## Intern
- Die Forecast-/Responsive-CSS-Regeln wurden aus der generierten Datei `src/styles.css` in die kanonische Quelle `src/styles-src/30-modern.css` überführt. `build-maintenance-aggregates` erzeugt sie damit reproduzierbar in jedem lokalen und GitHub-CI-Build.
- Die Regression `test-forecast-entry-consistency-098430.mjs` schützt diesen Quellvertrag weiterhin und läuft nach dem Aggregat-Neubau grün.
- Der in Run #987 bereits erfolgreiche TypeScript-7- und Vite-Buildpfad bleibt unverändert; behoben wird ausschließlich der nachgelagerte Regression-Rückfall durch die CSS-Aggregation.
- Keine fachliche Worker-Änderung.

# MID v0.9.84.32

## Extern
- Der nach dem Upload von v0.9.84.31 fehlgeschlagene GitHub-Release wird gezielt repariert; die sichtbaren Prognose- und Niederschlagsdarstellungen aus v0.9.84.31 bleiben unverändert erhalten.
- Die farbigen Niederschlagsbalken der 7-Tage-Kurvenübersicht verwenden weiterhin das MID-Phasenfarbkonzept, jetzt ohne TypeScript-Buildfehler.

## Intern
- GitHub-Run #986 analysiert: ZIP-Validierung, npm-ci und Dependency-Audit waren erfolgreich; der Abbruch entstand ausschließlich im TypeScript-Build in `src/ForecastCockpit.tsx`.
- `curveRainBarStyle()` leitet die Niederschlagsphase nun korrekt aus `precipitationParts(hour).type` ab. Der fehlerhafte Einzelstunden-Aufruf von `dominantPrecipitationForm()` wurde entfernt.
- CSS-Custom-Properties der Kurven-Niederschlagsbalken werden explizit als `CSSProperties` typisiert.
- Der bestehende Modern-Workspace-Regressionstest wurde auf die neue gemeinsame Forecast-Headerklasse aktualisiert, statt den neuen Headervertrag fälschlich als Regression zu werten.
- `test-forecast-entry-consistency-098430.mjs` schützt jetzt zusätzlich genau die in Run #986 sichtbar gewordenen Typfehler.
- Keine fachliche Worker-Änderung.

# MID v0.9.84.31

## Extern
- Die Prognose-Einstiege für 90 Minuten, 24 Stunden, 7 Tage, 14 Tage und 46 Tage+ wurden noch einmal gemeinsam auf Smartphone, Querformat und Desktop abgeglichen. Überschriften, Abstände, Akzentfarben und Zeithorizont-Navigation wirken nun einheitlicher.
- Der Umschalter zwischen 90-Minuten- und 24-Stunden-Ansicht nutzt auf kleinen Displays die volle Breite und bleibt besser bedienbar.
- Die 14-Tage-Ansicht wurde auf Mobilgeräten besser lesbar: Im Hochformat sind Schrift und Kennwerte größer; im Querformat werden die Tageskarten nicht mehr auf sieben extrem schmale Spalten zusammengedrückt, sondern bleiben lesbar horizontal verschiebbar.
- Niederschlagsbalken der Tagesansicht übernehmen konsequent die MID-Farblogik für Niederschlagsart und Intensität. Auch die 7-Tage-Kurvenübersicht verwendet denselben Parameterfarbvertrag.
- Der im Release-Lauf sichtbare TypeScript-Fehler im Reiseprognose-Pfad ist bereinigt.

## Intern
- Der gemeinsame `forecast-entry-head`-Vertrag wurde so verfeinert, dass Eyebrow, Titel, Beschreibung und Statuszeilen nicht mehr versehentlich dieselbe Großschreibungs-/Akzentformatierung erben.
- Mobile Scroll-/Snap-Regeln für Prognosehorizonte und 14-Tage-Karten wurden vereinheitlicht; die 14-Tage-Landschaftsansicht verwendet feste lesbare Kartenbreiten statt Mikroschrift.
- Die Tagesansicht nutzt `precipitationPhaseColor()` plus die vorhandenen Phasenmuster für ihre Niederschlagsbalken; die Intensität steuert zusätzlich Deckkraft und Kontur.
- `mediumDay()` im Reise-Fusionspfad enthält keinen ungenutzten `date`-Parameter mehr.
- Regression `test-forecast-entry-consistency-098430.mjs` wurde auf die verfeinerte Darstellung erweitert.
- Keine fachliche Änderung am Cloudflare-Worker; nur die Releaseversionsmarke wird synchronisiert.

# MID v0.9.84.30

## Extern
- Die Prognose-Einstiege wurden in mobiler und Desktop-Ansicht gestalterisch vereinheitlicht: Kurzfrist-, Prognose-, Warn-, Langfrist- und Reiseplaner-Köpfe nutzen nun ein gemeinsames, farblich abgestimmtes Einstiegsmuster.
- Die Tagesansicht nutzt das MID-Farbkonzept jetzt auch bei Niederschlagsbalken konsequenter. Phase und Intensität treten dadurch klarer hervor.
- Ein Build-/Release-Fehler im Reiseprognose-Fusionspfad wurde bereinigt, damit der ZIP-Installationsworkflow nicht mehr an einem ungenutzten TypeScript-Parameter scheitert.

## Intern
- Neue gemeinsame CSS-Basis `forecast-entry-head` für prognosenahe Einstiege inklusive Responsive-Fallbacks und angeglichener Modern-Forecast-Horizon-Navigation.
- Niederschlagsbalken in Tagesansicht und 7-Tage-Kurvenübersicht erhalten phasenabhängige Farb-/Kontursteuerung statt nur einer generischen Standarddarstellung.
- `src/travelForecastFusion.ts` entfernt den ungenutzten `date`-Parameter in `mediumDay`, womit der TypeScript-Verifier wieder sauber läuft.
- Neue Regression `scripts/test-forecast-entry-consistency-098430.mjs`.

# MID v0.9.84.29

## Extern
- Der Reiseplaner erhält ein eigenes Reise-Center: geplante Reisen können festgepinnt und später direkt wieder geöffnet oder bearbeitet werden.
- Festgepinnte Reisen zeigen bereits in der Übersicht die bekannten Kernwerte Temperatur, Niederschlag/Regentage, Sonnenschein, Wind, Schnee und – sofern verfügbar – Wassertemperatur. Die vollständige bisherige Auswertung bleibt über „Details“ erreichbar.
- Liegt ein Reisezeitraum innerhalb aktueller Modellhorizonte, fließen künftig passende Prognose-, Ensemble- oder Witterungssignale ein. MID kennzeichnet sichtbar, ob die Bewertung aus Modellprognose + Klima, Witterungstrend + Klima, Saisontrend + Klima oder nur aus Klimatologie besteht.
- Mit wachsendem Vorlauf nimmt der Modellanteil kontrolliert ab; weit entfernte Termine werden weiterhin überwiegend klimatologisch bewertet, statt tägliche Scheingenauigkeit vorzutäuschen.

## Intern
- Neuer persistenter Reise-Center-State getrennt von Ortsfavoriten und Event-Center-Einträgen.
- Neue horizontabhängige Forecast-/Klimafusion: operationelle Prognose/Ensembles bis Tag 14, ECMWF-EC46-Wochenanomalien mit GEFS-Bestätigung für Tag 15–46 und schwach gewichtete saisonale Multi-Modell-Anomalien ab Tag 47.
- Modellfamilien werden über Unabhängigkeitsgruppen zusammengeführt; Ensemblemitglieder werden nicht als zusätzliche Qualitätsstimmen gezählt. DWD GCFS2.2/EPISODES kann im passenden Gebiet über vorhandene Gütemaße als Qualitätsanker wirken.
- Quellen außerhalb ihres Prognosehorizonts werden nicht unnötig geladen. Quellenstatus, modellgestützte Reisetage, Modellanteil und unabhängige Modellfamilien werden im Detailbereich transparent ausgewiesen.
- Neuer Vertrag `MID_TRAVEL_CENTER_FORECAST_FUSION_CONTRACT.md` und Regression `scripts/test-travel-center-forecast-fusion-098429.mjs`.
- Keine fachliche Änderung an der Cloudflare-Worker-Logik; NOAA OISST v2.1 bleibt für Küsten-Wassertemperaturen unverändert die klimatologische Referenz.

# MID v0.9.84.28

## Extern
- Weather Icon System 2.0 unterscheidet Graupel und Hagel nun klarer: Graupel erscheint als kleinere, weich gerundete Pellets; Hagel als größere, kantigere Körner.
- Die zuletzt eingeführte Nachschärfung bei gefrierendem Regen und den gleichmäßigeren Niederschlagsintensitäten bleibt unverändert erhalten.

## Intern
- `src/WeatherPictogram.tsx` trennt Graupel- und Hagelpartikel jetzt auch bei kleinen Darstellungen geometrisch deutlicher über Rundung, Facettierung, Kontur und Lichtkante.
- Der bestehende Audit `test-pictogram-intensity-snow-depth-098426.mjs` prüft zusätzlich, dass Graupel rund und Hagel facettiert gerendert wird.
- Keine fachliche Änderung an Wetterberechnung, Datenquellen oder Cloudflare-Worker-Logik.

# MID v0.9.84.27

## Extern
- Keine sichtbare Funktionsänderung gegenüber v0.9.84.26: Die neue Niederschlagsintensitäts-, Tag-/Nacht- und Schneehöhendarstellung bleibt unverändert erhalten.
- Der Release-Installer wird nicht mehr durch ältere Prüfregeln blockiert, die noch die vorherige Piktogramm- und Schneehöhenlogik erwarteten.

## Intern
- 17 Regressionen aus GitHub-Run #982 an den v0.9.84.26-Fachvertrag angepasst.
- DWD/WMO 91/92 bleiben Regenschauer nach Gewitter in der vorangegangenen Stunde; WMO 89/90 sind explizite Hagelschauer, WMO 98 bleibt Gewitter ohne erfundenen Niederschlag.
- Schauerprüfungen respektieren die konservative DWD-Lücke 0,4–<0,7 mm/10 min sowie die vierte Stufe für WMO 82.
- Schneehöhen-, Sonnenstands-, Ensemble- und Skybar-Regressionen prüfen die aktuelle Semantik statt veralteter JSX-/Implementierungsdetails.

# MID v0.9.84.26

## Extern
- Wetterpiktogramme unterscheiden Niederschlagsstärken appweit klarer; sehr starke Regenschauer erhalten eine eigene kräftigste Stufe. Graupel- und Hagelschauer sind als eigene Phänomene erkennbar.
- Schauer zeigen den Tages-/Nachtbezug weiterhin nur dort, wo er meteorologisch sinnvoll ist: Sonne tagsüber, Mond nachts. Dauerregen/-schnee erhalten keinen künstlichen Himmelskörper.
- Niederschlag nach einem bereits vorangegangenen Gewitter wird nicht mehr mit einem aktuell andauernden Gewitter verwechselt.
- Schneehöhen und Schneedecken werden in der gesamten App in ganzen Zentimetern angezeigt. Neuschnee-/Schneefallmengen bleiben als separate Akkumulationsgröße ausreichend präzise.

## Intern
- WMO 82 wird als sehr starke Schauerintensität geschützt; gröbere Stundenakkumulationen dürfen einen expliziten Schauer-Intensitätscode nicht künstlich abschwächen.
- WMO 87–90, 91/92 und 93/94 wurden in Piktogramm-, Detail-, Perioden-, Berg-, Wasser-, Event-, Routen- und Farblogik konsistent ergänzt.
- WMO 95–99 wurden ebenfalls vereinheitlicht: 95/97 erfinden ohne zusätzliche Phaseninformation keinen Regen, 96/99 zeigen Hagel/Graupel ohne Zusatzregen, 98 bleibt Gewitter mit Staub/Sand ohne erfundenen Niederschlag.
- Ein älterer Tag-/Nacht-Strukturtest für den Höhenwetter-Verlauf wurde auf die inzwischen korrekte Intensitätsdurchleitung aktualisiert; die astronomische Tag-/Nachtlogik selbst blieb erhalten.
- Perioden-/Impact-Whitelists wurden erweitert, damit Graupel/Hagel und phasenunscharfer winterlicher Niederschlag nicht durch ältere Selektoren verloren gehen.
- Schneehöhenformatierung und -achse verwenden ganze cm; interne Rohdaten bleiben ungerundet.
- Neuer Vertrag `MID_PRECIP_PICTOGRAM_SNOW_DEPTH_CONTRACT.md` plus Regression `test-pictogram-intensity-snow-depth-098426.mjs`.

# MID v0.9.84.25

## Extern
- iOS-Rückkehr: Der zuletzt in dieser App ausgewählte Ort bleibt beim Wechsel aus dem Hintergrund erhalten; MID springt nicht mehr durch einen Geräteabgleich auf den Standard-/ersten Favoriten zurück.
- Beim Zurückkehren werden vorhandene Wetterdaten am aktiven Ort weiterverwendet, während eine nötige Aktualisierung im Hintergrund anläuft. Ein unnötiger Neustart mit „Wettermodelle werden geladen …“ wird dadurch vermieden.
- Favoriten und gespeicherte Standortprofile bleiben geräteübergreifend synchronisierbar; nur der **aktuell ausgewählte Ort** und die **letzte physische Geräteposition** bleiben gerätelokal.

## Intern
- `mid:lastLocation`, seine semantische Revision und `mid:lastTrackedLocation` sind aus dem portablen Geräte-Snapshot ausgeschlossen. Remote-Snapshots können die aktive lokale Auswahl daher weder überschreiben noch als „fehlenden“ Schlüssel löschen.
- StorageSafety bewertet `mid:lastLocation` über `mid:lastLocation:updated-at`; ein technischer IndexedDB-Mirror-Zeitstempel darf einen vorhandenen nativen Auswahlort bei der Migration nicht mehr verdrängen.
- Reale und von WKWebView ergänzte Sichtbarkeitsimpulse werden für den portablen Sync 15 s gedrosselt und über einen gemeinsamen In-Flight-Promise entdoppelt.
- Der frühe Dashboard-Preload bleibt parallel erhalten, wird nach StorageSafety/Persistenz aber nochmals gegen den tatsächlich wiederhergestellten Ort abgeglichen; ein falscher Preload wird abgebrochen statt den regulären Forecast zu blockieren.
- Neuer verbindlicher Vertrag `MID_IOS_RESUME_LOCATION_CONTRACT.md` plus Regression `test-ios-resume-location-preservation-098425.mjs`.
- Keine meteorologische Logik- oder Worker-Fachänderung.

# MID v0.9.84.23

## Extern
- Widget-Tageskarten halten Wetterbild, Beschreibung, Tmin/Tmax sowie Niederschlag, Sonnenschein und Wind/Böen jetzt über alle Tage auf festen, gleich hohen Zeilen. Längere Wettertexte verschieben nachfolgende Parameter nicht mehr.
- In der Kurvenübersicht des Export-Widgets wird der erste Tag nicht mehr hellblau als scheinbar ausgewählt hinterlegt.
- Aktivierte ECMWF-Temperaturfarben bleiben sowohl in den Tageswerten als auch in der Temperaturkurve erhalten; ohne ECMWF-Option gelten weiterhin die normalen MID-Parameterfarben.

## Intern
- Die kompakte Kartenansicht verwendet ein explizites vertikales Raster mit festen Höhen für Piktogramm, Wettertext, Temperaturzeile und Parameterpillen; Wind/Böen bleiben unverändert zweizeilig.
- `SevenDayCurveOverview` trennt interaktive Tagesauswahl von `presentationReady`: Export-/PowerPoint-Widgets setzen keine künstliche aktive Tagesfläche mehr. Eine CSS-Fallback-Regel verhindert auch bei älteren Zuständen eine aktive Hintergrundtönung im Kurvenexport.
- Bestehende Widget-Regressionsverträge wurden erweitert; kein zusätzlicher regelmäßiger CI-Testjob nötig. Keine meteorologische Berechnungs- oder Datenquellenänderung.

# MID v0.9.84.22

## Extern
- Reiner Release-Hotfix ohne Änderung an Wetterberechnung, Darstellung, Datenquellen oder Bedienung gegenüber v0.9.84.21.
- Die bereits aktivierte, ressourcenschonendere RUC-/GitHub-Actions-Logik bleibt unverändert erhalten.

## Intern
- GitHub-Run #977 repariert: Produktionsbuild, Dependency-Audit und 730 von 731 Regressionen waren erfolgreich; ausschließlich `scripts/test-ruc-scheduler-watchdog-09751.mjs` erwartete noch den früheren manuellen RUC-Standard `force=true` und die sechs alten Watchdog-Slots.
- Der Regressionstest schützt jetzt den gewünschten Vertrag `force=false` sowie den verdichteten GitHub-Watchdog `:23/:53`. Primäre RUC-Slots `:11/:41`, Active-Run-Sperre, Cooldown und unabhängiger Cloudflare-Watchdog bleiben geschützt.
- Keine fachliche Workeränderung.

# MID v0.9.84.21

## Extern
- Keine Änderung an Wetterberechnung, Darstellung oder Bedienung gegenüber v0.9.84.20.
- GitHub-Actions konkurrieren seltener miteinander; Release- und RUC-Publishes werden verlustfrei in einer gemeinsamen Warteschlange serialisiert.

## Intern
- GitHub-RUC-Watchdog von sechs auf zwei same-provider Prüfungen pro Stunde reduziert (`:23/:53`); primäre RUC-Slots `:11/:41` und unabhängiger Cloudflare-Watchdog bleiben erhalten.
- Manuelle RUC-Läufe verwenden standardmäßig den Freshness-Guard (`force=false`); erzwungene Vollverarbeitung bleibt explizit möglich.
- RUC-Pages-Pfad nutzt ein schlankes Dependency-Profil ohne das nur für R2 benötigte `awscli`; RUC-EPS-Decodierung arbeitet konservativ mit zwei, maximal vier Prozessen; P25/P50/P75 werden gemeinsam berechnet.
- Pages-Retries verwenden ein erfolgreich hochgeladenes Artefakt erneut; Neuaufbau/Neu-Upload erfolgt nur, wenn noch kein gültiges Artefakt vorliegt.
- `mid-pages` verwendet `queue: max` bei `cancel-in-progress: false`, damit wartende Publishes nicht mehr durch neuere Pending-Jobs verdrängt werden.
- Der historische `mid-code-revision`-Installer wird administrativ von automatischen `main`-Pushes entkoppelt; CI, Nightly, Health, Performance und CodeQL bleiben unverändert aktiv.
- Ein einmaliger administrativer `npm run sync:github-workflows`-Commit aktiviert alle Workflowänderungen gesammelt; es sind keine manuellen YAML-Änderungen nötig.
- Versions-Sync hält künftig auch `worker.js` und `worker/metar-proxy.js` automatisch bytegleich; der Release-Gate schützt diese Spiegelung.

# MID v0.9.84.20

## 0.9.84.20
- Release-Prüfung korrigiert: Die Widget-Erweiterung aus v0.9.84.19 bleibt unverändert erhalten.
- Wind/Böen bleiben im Widget zweizeilig; die optionalen ECMWF-Temperaturfarben bleiben für Standard-Exporte aktiviert.
- Keine Änderung an Wetterberechnung, Datenquellen, Darstellung oder Bedienung gegenüber v0.9.84.19.

## Intern
- GitHub-Run #975 repariert: TypeScript 7.0.2 und Vite 8.2.2 waren bereits vollständig erfolgreich; nur zwei ältere, quelltextorientierte Regressionen erwarteten noch die Struktur vor dem neuen optionalen `ecmwfTemperatureColors`-Prop.
- Der 7-Tage-Test akzeptiert jetzt die optionale ECMWF-Farbsteuerung und schützt zugleich, dass die Standardansicht weiter mit `ecmwfTemperatureColors=true` startet.
- Der Widget-Kurventest prüft Wind und ECMWF-Farboption unabhängig voneinander statt eine zufällige Prop-Reihenfolge festzuschreiben.
- Keine fachliche Workeränderung.

# MID v0.9.84.18

## 0.9.84.19
- Widget: Wind und Böen bleiben auch bei knappen Tageskarten konsequent in zwei Zeilen und brechen nicht mehr zusätzlich um.
- Export: ECMWF-Temperaturfarben können für die Widget-/PNG-Ausgabe ein- oder ausgeschaltet werden; neue Standard-Exporte verwenden sie automatisch.
- Die Temperaturfarben sind in Hell/Dunkel kontrastiert und gelten auch für die Kurvenübersicht sowie feste Live-Export-URLs.

## Extern
- Reiner Release-/Regression-Hotfix: Wetterberechnung, Skybar, Niederschlagsdarstellung und Bedienung bleiben gegenüber v0.9.84.17 unverändert.
- Die seit v0.9.84.15 fachlich gewollte Intensitätslogik bleibt erhalten: 0,8 mm Regen in einer Stunde ist nach dem MID/DWD-Vertrag mäßiger Regen und wird entsprechend mit dem WMO-Regenintensitätscode 63 dargestellt.

## Intern
- GitHub-Run #973 repariert: TypeScript 7 und der Vite-Produktionsbuild waren bereits erfolgreich; ausschließlich drei veraltete Regressionserwartungen verlangten weiterhin den leichten Regencode 61 bzw. „leichter Regen“ bei 0,8 mm/h.
- Die drei Regressionen für Niederschlagscharakter, allgemeine Niederschlagsformen und Detailpiktogramme sind auf die bereits zentrale, intervallabhängige Intensitätsklassifikation synchronisiert.
- Keine fachliche Workeränderung.

# MID v0.9.84.17

## Extern
- Reiner Release-Hotfix ohne Änderung an Wetterberechnung, Darstellung, Datenquellen oder Bedienung.
- Die Update-/Recovery-, Performance-, Skybar- und Niederschlagskorrekturen aus v0.9.84.15/16 bleiben unverändert.

## Intern
- GitHub-Run #972 repariert: Der nullable Update-Status wird vor dem Versionsvergleich auf zwei optionale skalare Werte reduziert. Dadurch muss TypeScript 7 keine Objekt-Narrowing-Annahme über `status` mehr treffen.
- Die Update-Recovery-Regression schützt genau diese TS7-sichere Form und verhindert eine Rückkehr zum zuvor zweimal fehlgeschlagenen Ausdruck.
- Keine fachliche Workeränderung.

# MID v0.9.84.16

## Extern
- Reiner Release-Hotfix: Die Grundaudit-, Performance- und Update-Recovery-Korrekturen aus v0.9.84.15 bleiben unverändert.
- Keine Änderung an Wetterberechnung, Darstellung, Datenquellen oder Bedienung.

## Intern
- GitHub-Run #971 repariert: Der Post-Update-Healthcheck behandelt einen nicht verfügbaren Update-Status jetzt TypeScript-sicher, bevor `pendingVersion` und `appVersion` verglichen werden.
- Regression erweitert, damit die null-sichere Prüfung dauerhaft geschützt bleibt.
- Keine fachliche Workeränderung.

# MID v0.9.84.15

## Extern
- App-Updates sind robuster: MID wartet nicht mehr unbegrenzt auf einen festhängenden Startabruf, hält während eines wartenden Updates die laufende App-Shell versionsrein und kann einen nicht gesund gestarteten neuen Stand gezielt auf die vorherige Version zurücksetzen. Dadurch soll der bisher gelegentlich nötige manuelle Komplett-Neustart nach Updates entfallen.
- Radar-, Sensor-, Open-Meteo-, externe Beobachtungs-/Geocoding- und Hintergrundabrufe besitzen nun belastbare Zeitgrenzen; lange Karten- oder App-Sitzungen sollen weniger anfällig für Hänger und unnötig wachsenden Speicherverbrauch sein.
- Niederschlagsstärken werden genauer nach Niederschlagsart und tatsächlichem Zeitintervall bewertet. Sonnige Schauer bleiben in der Skybar sichtbar, Dauerregen erhält keine künstliche vierte Intensitätsklasse.
- Eigene Wetterstationen mit Standard-JSON behandeln Regenraten jetzt korrekt als Raten und nicht als aufsummierte Niederschlagsmengen.

## Intern
- Service-Worker-Aktivierung atomisiert: neuer Cache und neuer Controller übernehmen erst gemeinsam im `activate`-Schritt; die aktive `index.html` bleibt bis dahin cachegebunden, sodass kein neuer Server-HTML-Stand mit alten JS/CSS-Assets vermischt wird. Update-Assets und Updateprüfungen besitzen harte Zeitbudgets.
- Post-Update-Healthcheck basiert auf nutzbaren Kernforecastdaten statt nur auf gerenderten React-Frames; Offline-Zustand gilt nicht als falscher Positivnachweis. Bei einem pending Update greift online nach 20 s ein gezieltes Rollback.
- Forecast-/Stations-/Ensemble-Preloads, Best-Match/Worker-Fallback, verbundene Stationen, externe Beobachtungs-/Geocodingdienste, Radar-/Rasterquellen, private Sensoren, Lüftungsassistent und Gerätesync sind abortierbar und zeitlich begrenzt.
- Große Wetterzwilling-/Archivarbeiten laufen erst nach dem ersten sichtbaren Render; HY-ME-C/NG-, Event-Flugwetter-, Saison- und Terrain-Morphologie-Caches sind begrenzt.
- Zentrale intervall- und niederschlagsartbewusste Intensitätsklassifikation; generische `rainRate`/`precipitationRate`-Semantik korrigiert.
- Version-/Manifest-Cachebuster werden auf kanonische Cache-Schlüssel abgebildet; regelmäßige Updatechecks können den App-Shell-Cache nicht mehr mit immer neuen Query-Varianten aufblasen.
- Keine fachliche Workeränderung.

# MID v0.9.84.12

## Extern
- Release-Korrektur ohne sichtbare Änderung: Die neue Skybar-Logik aus v0.9.84.11 bleibt vollständig erhalten.
- Gesamtbewölkung steuert weiterhin das gelbe/graue Grundband; sonnige Schauer bleiben als farbiger Niederschlagslayer über Sonne sichtbar.

## Intern
- GitHub-Run #966 repariert: direkter Sonnenscheinparameter und wolkenbasierter visueller Sonnenanteil sind wieder sauber getrennt.
- Der wissenschaftliche Auditvertrag `sunVisualShare(0,0) = 0` ist wieder erfüllt, ohne die Wolkenpriorität der Skybar zurückzunehmen.
- Keine fachliche Workeränderung.

# MID v0.9.84.11

## Extern
- Skybar: Gesamtbewölkung ist jetzt die primäre Himmelsgröße. Hohe Sonnenscheindauer kann eine überwiegend bewölkte Stunde nicht mehr als maximal sonnig darstellen.
- Klassische Schauerlagen bleiben sichtbar: farbiger Niederschlag liegt über einem vorhandenen gelben Sonnenband; ein breiteres Sonnenband bleibt seitlich sichtbar, ein gleich dicker oder dickerer Niederschlagsbalken verdeckt es vollständig.
- Niederschlagsdicken orientieren sich an den DWD-Intensitäten leicht/mäßig/stark; die höchste vierte Dicke ist eine klar dokumentierte MID-Darstellungsunterteilung innerhalb „stark“.

## Intern
- Zentrale `detailSkyBar`-Engine für alle sichtbaren Skybar-Verwendungen vereinheitlicht.
- Wolkenpriorität, Sunshine-Fallback, Schauer-Layerreihenfolge und Intensitätsschwellen regressionsgeschützt.
- Keine fachliche Workeränderung.

# MID v0.9.84.0

## Extern
- Kurzfristige Starkregen-, Schnee- und Eisrisiken nutzen ICON-D2-RUC und RUC-EPS jetzt gemeinsam vorsichtiger und aussagekräftiger. RUC-EPS kann die kurzfristige Eintrittswahrscheinlichkeit bestätigen oder begrenzt dämpfen, ohne eine bereits ensemblegestützte Gefahr einfach verschwinden zu lassen.
- Sehr nasse einzelne RUC-Läufe werden zusätzlich mit der RUC-EPS-Verteilung abgeglichen. Dadurch reagieren lokale Niederschlagsprognosen weniger empfindlich auf isolierte Ausreißer.
- Im Extremwetter-Ausblick ist transparenter erkennbar, wann RUC/RUC-EPS die Gefahreneinschätzung stützt und welche Kurzfristdaten dahinterstehen.
- Weitere Einsatzmöglichkeiten in Push-Mitteilungen, Flugmeteorologie, Bergwetter, Mehrlauf-Trends und Wind-Ensembles wurden geprüft und nach Nutzen/Risiko priorisiert.

## Intern
- `rapid-extreme.json` auf Schema v4 erweitert: voraggregierte RUC-EPS-Niederschlagsevidenz pro 0–6/6–12/12–14-h-Fenster, ohne Veröffentlichung nativer Member-Cubes.
- Hyperlokaler RUC-Niederschlagskonsens nutzt RUC-EPS-Q75 nur als kontinuierliche Upper-Tail-Plausibilisierung, nicht als hartes Mengen-Capping.
- Extremwetter-Regen erhält begrenzte bidirektionale RUC-EPS-Kalibrierung; Gewitter nutzt RUC-EPS als Niederschlagsstütze; Schnee/Eis koppeln RUC-EPS an deterministische Phasen-/Temperaturdiagnostik.
- Keine synthetische RUC-EPS-Windwahrscheinlichkeit: der aktuelle EPS-Preprocessor enthält nur Niederschlagsmember.
- Rückwärtskompatibel zu rapid-extreme v1–v3; v4-Funktionen aktivieren sich automatisch nach dem nächsten vollständigen RUC-Preprocessing.

# MID v0.9.83.5

- Klima: tägliche ERA5-Bedeckungsmittel werden nun zuerst plausibel auf 0–8 Oktas gerundet und danach in die beschrifteten Achtelklassen gruppiert.
- Klima: Wind- und Böentexte verwenden außerhalb der Diagrammlegende eine einheitliche neutrale Textfarbe; Wert und Einheit bleiben zusammen.
- Komposit: Satellitenstände werden in einem Ringpuffer mit bis zu zwölf realen Nachbarbildern verdeckt vorgeladen und beim Wechsel überblendet.
- Synoptik: native DWD-Isobaren bleiben erhalten; geglättete MID-Isohypsen werden separat aus dem Rasterpfad geladen und wieder sichtbar gezeichnet.
- Karte: der Lokalisierungsbutton stoppt laufende Kartenbewegungen, aktualisiert die Kartengröße und zentriert zuverlässig auf Geräte- oder Favoritenort.
- Keine Logo- und keine Workflow-YAML-Änderungen.

# MID v0.9.83.4

## Extern
- Der Release-Installer wird nicht mehr durch einen administrativ noch nicht synchronisierten GitHub-RUC-Workflow blockiert. Wetterdaten, RUC-Berechnung und Darstellung bleiben unverändert.
- Die vollständige Build- und Regressionsprüfung bleibt bestehen; nur die Zuständigkeit für aktive GitHub-Workflowdateien ist jetzt sauber vom normalen ZIP-Release getrennt.

## Intern
- Drei RUC-Fachregressionen prüfen ausschließlich den kanonischen `ci/github`-Workflow, den das Release tatsächlich mitliefert.
- Die aktive `.github`-Konfiguration bleibt wie vorgesehen vom automatischen Release-Installer geschützt und wird weiterhin separat über die vorhandenen Admin-Sync-/Transition-Regressionen fail-closed validiert.
- Kein Lockern des RUC-Catch-up-, Pages-, Speicher-, Health- oder Workflow-Sicherheitsvertrags.

# MID v0.9.83.3

- GitHub-Release-Lauf #942 repariert: Die beiden isolierten Extremwetter-/Flugwetter-Regressionen erhalten `esbuild` wieder als ausdrückliche, im Lockfile fixierte Entwicklungsabhängigkeit.
- Drei nach der Vite-8- und Klima-Farbmigration veraltete Prüferwartungen korrigiert: ein nicht mehr installierter `browserslist`-Pfad gilt als nicht betroffen, Klima-Tmax darf auf den zentralen Tmax-Token verweisen, und die Plugin-React-Policy bleibt maschinenlesbar.
- Die Vite-8/Rolldown-Produktionspipeline bleibt unverändert; `esbuild` wird ausschließlich von den zwei bestehenden Node-Testhüllen zum Bündeln einzelner TypeScript-Fachmodule verwendet.
- Keine Änderung an App-Verhalten, Wetterberechnung, Darstellung oder Worker-Fachlogik.

# MID v0.9.83.2

- Release-Installation unter React 19 repariert: Ensemble- und Radar-Bedienelemente verwenden jetzt die korrekten Referenztypen; der in GitHub-Lauf #941 aufgetretene TypeScript-Abbruch ist damit gezielt behoben.
- Klima: Tmax verwendet wieder die appweite MID-Temperaturfarbe. Wind und Böen sind in Zusammenfassung, Monatswerten, Umschalter und Windrose eindeutig in den bekannten MID-Parameterfarben dargestellt.
- Keine fachliche Änderung an Wetter-, Warn-, Klima- oder Worker-Berechnungen.

# MID v0.9.83.1

## Extern
- Widget: Wenn für einen Tag keine warnwürdigen MID-Ereignisse vorliegen, wird keine leere Entwarnungs-/Hinweispille mehr angezeigt.
- Klima: Die Temperaturachse im Jahresverlauf verwendet jetzt automatisch glatte, leicht lesbare Skalenwerte statt krummer Zwischenwerte.
- Klima: Wind- und Böenwerte werden in Zusammenfassung, Windrose und Monatskarten einheitlich als ganze Werte dargestellt.

## Intern
- Klima-Temperaturskala verwendet adaptive Nice-Steps (1/2/5/10/20/50 °C) mit sauber aufgerundeten Achsgrenzen.
- Widget-Hazardbereich wird nur gerendert, wenn tatsächlich mindestens ein warnwürdiges Ereignis für den jeweiligen Tag vorliegt; der Gesamtzustand behandelt ein komplett warnfreies Widget layoutseitig wie „Hazards aus“.
- Keine Änderung an Warnschwellen, Wetterdaten, Klimadatenquellen oder Worker-Fachlogik.

# MID v0.9.83.0

## Extern
- Keine Änderung an Wetterdaten, Vorhersagen, Warnungen, Radar/Satellit, Synoptik, Klima oder Bedienlogik.
- Die technische Basis der App wurde modernisiert, damit MID mit den aktuellen React-/Vite-Werkzeugen weiterentwickelt werden kann, ohne den bestehenden Funktionsumfang anzutasten.
- Symbole und interne Build-Werkzeuge wurden aktualisiert; Darstellung und gespeicherte Nutzerzustände bleiben erhalten.

## Intern
- React, React DOM und react-is gemeinsam auf 19.2.8 sowie die zugehörigen Typen auf die React-19-Reihe migriert; Recharts 3.10.1 bleibt erhalten und ist peer-kompatibel.
- Vite 8.2.2 und @vitejs/plugin-react 6.1.1 gemeinsam übernommen. Der Build nutzt nun Oxc, Lightning CSS und Rolldown-codeSplitting statt der veralteten esbuild-/manualChunks-Konfiguration.
- Lucide React auf 1.40.0 aktualisiert; TypeScript bleibt exakt auf 7.0.2, der bestehende Strada-Testalias auf 6.0.3.
- deploy-pages auf 5.0.1 und CodeQL init/analyze gemeinsam auf 4.37.9 SHA-gepinnt.
- Keine fachliche Workeränderung; nur Versionssynchronisierung.

# MID v0.9.82.1

## Extern
- Keine Änderung an Wetter-, Klima- oder Reiseplanerfunktionen gegenüber v0.9.82.0.
- Der fehlgeschlagene Release-Lauf #939 ist korrigiert; MID kann den bereits geprüften v0.9.82.0-Funktionsstand wieder regulär veröffentlichen.

## Intern
- Zwei veraltete Reiseplaner-Regressionen wurden an den in v0.9.82.0 ergänzten optionalen Böenabruf angepasst.
- Der Abrufbudget-Test prüft nun den regulären Gust-Pfad und den kompatiblen Fallback, statt die frühere statische `daily:DAILY_VARIABLES`-Form vorauszusetzen.
- Die beiden isolierten Reiseplaner-Testhüllen setzen `--ignoreConfig` nur unter TypeScript 7 und bleiben damit auch mit älteren lokalen Compilern prüfbar.
- Produktionsbuild, TypeScript-Prüfung und 718 weitere Regressionen waren in GitHub Actions #939 bereits erfolgreich; es gibt keine fachliche Workeränderung.

# MID v0.9.82.0

## Extern
- Klima: Die Windrose kann zwischen Wind und Böen umgeschaltet werden, wenn für den gewählten Ort historische Böendaten vorhanden sind. Fehlen Böendaten, bleibt die Oberfläche unverändert und zeigt keinen leeren Schalter.
- Klima: Für den gewählten Zeitraum wird zusätzlich die stärkste modellierte Böe aus der Klimaperiode 1991–2020 angezeigt; auch die Monatskarten führen sie mit, sofern verfügbar.
- Klima: Niederschlags- und Schneefalltage werden jetzt als ganze Tage angezeigt.
- Klima: Das Wertefeld im Jahresverlauf ordnet Temperatur- und Niederschlagswerte auf zwei klar getrennte Zeilen, sodass alle Inhalte innerhalb des Tooltips bleiben.

## Intern
- Das bestehende ERA5-Seamless-Tagesarchiv wird optional um das tägliche Böenmaximum ergänzt; bei fehlender Unterstützung fällt MID automatisch auf den bisherigen Klimadatensatz zurück.
- Böen werden nach der täglichen Hauptwindrichtung gruppiert. MID behauptet damit keine separat gemessene Böenrichtung.
- Der Klima-Cache wurde wegen der zusätzlichen Böenfelder auf Schema v7 angehoben.
- Keine funktionale Workeränderung.

# MID v0.9.80.7

## Extern
- Die parallelen Änderungen aus den beiden zuletzt gleich bezeichneten v0.9.80.6-Ständen sind in einem eindeutigen Release zusammengeführt.
- Kompositbild: Radar und Satellit laufen über eine gemeinsame reale Zeitachse, bereiten den nächsten Stand vor und blenden geladene Nachbarbilder weich ineinander; die wählbaren Tempi bleiben erhalten.
- Synoptik: Linienart ist als Primärwahl erreichbar; Isobaren und geglättete 500-hPa-Isohypsen können einzeln oder gemeinsam dargestellt werden.
- 24-h-Profil, Klima und Widget behalten die zuletzt korrigierte Ausrichtung, Lesbarkeit, Farbtrennung und geglättete Niederschlagswahrscheinlichkeit.

## Intern
- Versionskollision der parallelen v0.9.80.6-Entwicklungszweige durch den konsolidierten Stand v0.9.80.7 aufgelöst.
- Die Komposit-Wiedergabe verwendet ausschließlich echte bestätigte Produktzeiten und erfindet keine meteorologischen Zwischenstände.
- Die Klima-, Zeitachsen-, UI-, Synoptik- und Widget-Verträge sowie die Light-/Dark-Logo-Assets bleiben gemeinsam erhalten.
- Keine funktionale Workeränderung.

# MID v0.9.80.6

## Extern
- Im kompakten Widget stehen Sonnensymbol und Sonnenscheindauer jetzt sauber zentriert und mit erkennbarem Abstand in ihrer Pille.
- Die Niederschlagswahrscheinlichkeit im 24-h-Wetterprofil und in der Tagesansicht wird wieder als ruhige, geglättete Linie dargestellt; die zugrunde liegenden Stundenintervalle bleiben unverändert.
- Die Bedeckungsanteile im Klimabereich sind auch in den dunkleren Klassen gut lesbar.
- Der Klima-Jahresverlauf unterscheidet Mitteltemperatur und Tmin kontrastreicher; das Wertefeld beim Antippen eines Monats ist deutlich größer und besser lesbar.

## Intern
- PoP-Kurven verwenden eine monotone kubische Hermite-Interpolation mit Überschwingungsschutz; Niederschlagsmengen, Auswahlpunkte und Tooltips behalten die kanonische Vorwärtsintervall-Geometrie.
- Klimafarben: Mitteltemperatur in der Hellansicht #111827, Tmin #174f9e; in der Dunkelansicht bleiben kontrastgerechte äquivalente Tokens erhalten.
- Bedeckungslegendeneinträge verwenden neutrale Flächen und separate Farbmuster statt dunkler Vollflächen hinter dem Text.
- Keine funktionale Workeränderung.

# MID v0.9.80.5

## Extern
- Der GitHub-Installer kann den aktuellen MID-Stand wieder veröffentlichen; die Wetterdarstellung und fachliche Logik aus v0.9.80.4 bleiben unverändert.
- Die Prüfung des kompakten Widgets berücksichtigt dessen neue Böen-Warnfarben korrekt, ohne den Schutz vor abgeschnittenen Wetterwerten zu lockern.

## Intern
- CI-Hotfix nach Release-Lauf #934: zwei direkte TypeScript-Prüfungen erkennen TypeScript 7 und setzen dort den erforderlichen `--ignoreConfig`-Schalter; ältere lokale Compiler bleiben weiterhin lauffähig.
- Die Nicht-Abschneiden-Regression erkennt die dynamische Widget-Windklasse `warning-*` und prüft weiterhin Regen-, Wind- und Böen-Teilzeilen.
- Keine Änderung an Wetter-, Hazard-, Klima- oder Workerfachlogik gegenüber v0.9.80.4; Worker-/Service-Worker-Versionen sind lediglich releasesynchronisiert.

# MID v0.9.80.4

## Extern
- Klima ist klarer lesbar: Höchst-, Mittel- und Tiefsttemperatur sowie Niederschlag haben dauerhaft unterschiedliche Farben.
- Bedeckung wird in fünf verständlichen Anteilen gezeigt; Niederschlags- und Schneefalltage ergänzen die Monatswerte.
- Die Windrose erklärt nun eindeutig, dass sie auf typischen Tageswindrichtungen basiert und wie sich ihre Arme nach Windstärke aufteilen.
- Das MID-Widget verwendet dieselben automatischen Wetterhinweise und Böen-Warnstufen wie die App; Sonnenscheindauer wird dort platzsparend auf ganze Stunden gerundet.
- Die Windwarnfarben sind zwischen Warnhinweisen, Windpfeilen, Forecast-Cockpit und Bergwetter vereinheitlicht.

## Intern
- Zentraler DWD-Windschwellenvertrag für alle beteiligten Oberflächen; 50 und 140 km/h bleiben als strikte „über“-Grenzen erhalten.
- Widget-Hinweise werden aus den kanonischen probabilistischen Hazard-Zeitfenstern abgeleitet.
- Klima-Cache auf Schema v6 erweitert, um Schneefalltage ohne zusätzliche Netzabfrage aus derselben Tagesreihe zu bestimmen.
- Eigene Klima-Farbtokens für Tmax, Mittel und Tmin sowie neue Regression für Klima/Hazard/Widget.
- Keine fachliche Workeränderung.

# MID v0.9.80.1

## Extern
- Änderungen aus dem neueren Klima-/Konzeptstand v0.9.80.0 mit dem zuvor korrigierten v0.9.79.20-Release zusammengeführt.
- Die neue, standardmäßig geschlossene Klima-Sektion bleibt vollständig erhalten; Warn-/LT- und CI-Korrekturen aus v0.9.79.20 bleiben unverändert wirksam.

## Intern
- Vor dem Merge wurden die drei in Release #929 korrigierten Regressionen bytegleich gegen v0.9.79.20 geprüft.
- Klima-Komponente und Klima-Regressionsprüfung sind jetzt zusätzlich in der Baseline als Pflichtbestandteile verankert, damit sie bei späteren Release-Merges nicht still verloren gehen.
- Keine neue fachliche Workeränderung gegenüber v0.9.80.0.

# MID v0.9.80.0

## Extern
- Neue, standardmäßig geschlossene Sektion „Klima“ für den gewählten Ort.
- Klimanormalen 1991–2020 für Tmax, Tmin, Mitteltemperatur, Niederschlag, mittleren Wind und Bedeckungsgrad.
- Frei wählbare, auch jahresübergreifende Monatszeiträume; Direktwahl für Dezember–März, Sommer und Gesamtjahr.
- Gemeinsamer Jahresverlauf, Monatskarten und Windrose in MID-Parameterfarben; für Mobil-Hoch- und Querformat optimiert.

## Intern
- Klimadaten werden erst beim Öffnen geladen, ortsbezogen gerastert und bis zu drei Jahre lokal wiederverwendet.
- Ein einzelner ERA5-Seamless-Tagesabruf versorgt alle Darstellungen; Monatsfilter und Windrose werden ohne weitere Netz- oder Workerabrufe lokal berechnet.
- Windrichtungen werden zirkulär gemittelt; Quellen- und Grenzenhinweis trennt modellierte Klimatologie klar von Vorhersage und lokaler Messung.
- Keine fachliche Workeränderung.

# MID v0.9.79.20

- CI-Fix für Release #929: drei veraltete Regressionstests an die bereits beabsichtigte v0.9.79.19-Darstellung von Warnstufe, Warnzeitfenster und `LT` angepasst.
- Keine Änderung an der produktiven Wetter-, Warn- oder Workerlogik.

# MID v0.9.79.19

## Extern
- Windhinweise nennen die Richtung direkt und weisen markante Drehungen mit einem zeitlich aufgelösten Wechsel aus.
- Warnstufe und Warnzeitfenster werden im 24-h-Wetterprofil aus denselben Warnobjekten wie in der Warnübersicht übernommen.
- In Lokalzeit umgerechnete absolute Zeitstempel werden mit „LT“ gekennzeichnet, damit UTC-/Quellzeiten und Lokalzeit nicht verwechselt werden.

## Intern
- Wetterprofil-Hazardbänder führen die kanonische Stufe und `validFrom`/`validTo` weiter.
- CI-Fehler #928 behoben: die UI-Regression v0.9.79.17 ist nicht mehr an eine historische Patch-Version gekoppelt.
- Keine fachliche Workeränderung.

# MID v0.9.79.18

## Extern
- Keine Änderung an der Wetterdarstellung: Niederschlagswahrscheinlichkeit, Mengenbalken und die seit v0.9.79.16 geltende Vorwärtsintervall-Geometrie bleiben unverändert.

## Intern
- CI-Fehler aus Release #927 behoben: die historische Regression für Niederschlagswahrscheinlichkeit erwartete noch den früheren punktweise aufgebauten `p.map`-Pfad.
- Der Test prüft nun die aktuelle stufenförmige Vorwärtsintervall-Kurve (`p.reduce`) und zusätzlich explizit, dass die PoP-Kurve unabhängig von vorhandenen Niederschlagsmengenbalken gerendert wird.
- Kein fachlicher Rollback und keine Änderung an Forecast-, Skybar- oder Workerlogik.

# MID v0.9.79.17

## Extern
- Einstellungen nutzen ein einheitlicheres Typografie-, Abstands- und Kartenraster.
- Schalter in Einstellungen und Push-Regeln besitzen nun eine konsistente iOS-Geometrie und bessere Fokuszustände.
- Mobile Einstellungsnavigation zeigt wieder kurze Bereichsnamen; die optionale Bottom-Leiste hat klarere Aktivzustände und einheitliche Touchziele.
- Der klassische Navigationsmodus bleibt unverändert als persistenter Fallback erhalten.

## Intern
- UI-Polish aus dem parallelen Zweig „Logos und Konzepte“ auf den fachlich neueren v0.9.79.16-Stand konsolidiert.
- MOSMIX-S/L-Frischelogik und Niederschlags-Vorwärtsintervallgeometrie aus v0.9.79.16 bleiben unverändert erhalten.
- Neuer Pflichtregressionstest schützt Einstellungsraster, Switch-Geometrie, mobile Bereichsnamen, Fokus, Reduced Motion und klassischen Fallback.

# MID v0.9.79.16

## Extern
- MOSMIX-S wird als stündliche Kurzfrist-Aktualitätsreferenz ausgewiesen; MOSMIX-L bleibt separat für 03/09/15/21 UTC sichtbar.
- Niederschlag und Skybar liegen nun geometrisch im tatsächlich bezeichneten Vorwärtsintervall (z. B. 19:00–20:00).
- Niederschlagswahrscheinlichkeit im 24-h-Profil wird als Intervalltreppe statt als linear interpolierter Zeitpunktwert dargestellt.

## Intern
- DWD-MOSMIX-S/L-Laufindizes werden getrennt verifiziert; kein L-Init-Fallback als scheinbar stündliche S-Aktualität.
- Skybar-x-Positionen sind Slotstarts; 24-h-Tagesachse reserviert die rechte Kante für 24:00.
- Neue Pflichtregressionen sichern MOSMIX-S/L und Niederschlags-Intervallgeometrie.

## v0.9.79.15 – MOSMIX-Anteil und Laufaktualität
- Modellstand beziffert den ungefähren direkten MOSMIX-Korrekturanteil für Temperatur, Tmin/Tmax, Taupunkt, Druck, Wind/Böen und den RR1c-Niederschlagskonsens.
- MOSMIX-L-Init wird aus dem offiziellen DWD-OpenData-Laufindex gelesen; „Quelle bereit“ und Laufalter bleiben getrennt.
- Modellzeilen kennzeichnen den Lauf als aktuell oder warnen bei ungewöhnlich altem Init.
- Falls der offizielle Laufindex nicht verifiziert werden kann, wird kein Init geraten.
- Fachliche Workeränderung erforderlich.

## v0.9.79.14 – CI-Buildfix nach Release #925
- GitHub-Release #925 scheiterte im TypeScript-Parser an einer rohen `<50 %`-Schreibweise innerhalb eines JSX-Hilfetexts in `App.tsx`.
- Die Formulierung lautet nun parserfest „unter 50 % Bewölkung“; die fachliche Skybar-No-gap-Regel aus v0.9.79.13 bleibt unverändert.
- Der bestehende No-gap-Pflichttest schützt zusätzlich gegen eine erneute rohe `<50 %`-Schreibweise im JSX.
- Keine fachliche Änderung an Forecast, Skybar-Schwellen, Worker oder Datenquellen.

## v0.9.79.13 – Skybar tagsüber lückenfrei
- Zentrale Ursache der sichtbaren Tageslücken behoben: direkte Sonnenscheindauer ≤50 % plus Gesamtbewölkung <50 % konnte bislang weder Gelb noch Grau erzeugen.
- Bewertbare Tages-Slots erhalten nun immer ein Grundband; im kritischen Zwischenbereich ein graues Mindestband der ersten Dickenstufe.
- 24-h-Tagesdetail, 24-h-Profil, 7-Tage-Kurve und Tageskarten profitieren über dieselbe zentrale Skybar-Engine.
- Klare Nächte und echte Datenlücken bleiben bewusst ausnehmbar; Niederschlagsfarben/-Overlay und vier Dickenstufen bleiben unverändert.

## v0.9.79.12 – CI-Regressionsfix nach Release #923
- Vier historische Regressionen auf den seit v0.9.79.11 zentralen `forecastRegime.ts`-Vertrag umgestellt.
- Keine Rückkehr zu paralleler Regimelogik in `ForecastCockpit.tsx`; Farben und Klassifikation bleiben zentral.
- Keine meteorologische, visuelle oder Worker-Fachänderung.

## v0.9.79.11 – Wetterregime appweit gekoppelt
- Gemeinsame Regimeklassifikation für 7d/14d und klassische 7d-Ansicht.
- Regimefarben vollständig auf zentrale Palette/`--mid-weather-regime-accent` geführt.
- Schauer-Regime und klassische Wetterpille per Regression abgesichert.

# Changelog

## 0.9.79.9

- Skybar appweit erneut geprüft und die vier Dickenstufen auf kleinen Displays klarer voneinander getrennt: `2.4 / 3.6 / 4.8 / 6.0`.
- Sonne und Bewölkung nutzen explizite 50–62,5 / 62,5–75 / 75–87,5 / 87,5–100-%-Klassen; Niederschlag behält vier zeitnormalisierte Intensitätsklassen.
- Jedes Segment trägt die tatsächlich verwendete Stufe 1–4 als DOM-Diagnoseattribut.
- Die bisher 7 Einheiten hohe Grundschiene der 7-Tage-Tageskarten wurde auf eine dezente 1,2-Einheiten-Achse reduziert, damit sie die vier realen Dicken nicht mehr optisch nivelliert.
- Tagesdetail/24 h, 24-h-Profil, 7-Tage-Kurve und Tageskarten bleiben auf derselben zentralen Skybar-Engine.
- Keine fachliche Änderung an Wetterdaten, Radar/Satellit oder Workerlogik.

## 0.9.79.8

- CI-Regressionsfix nach Release-Run #920: fünf noch auf die vor Bottom-Bar-Struktur zugeschnittene Quelltext-Regressionen auf den funktional gleichwertigen v0.9.79.x-Vertrag aktualisiert.
- Sonnenstunden- und Niederschlagsregressionen erkennen die weiterhin zentral reconcilierten `displayHours` nun auch in der optionalen Heute-Fokusstruktur.
- 14-Tage-Favoritenregression prüft die Mindestversion semantisch statt ausschließlich innerhalb der alten `0.9.78.x`-Linie.
- Planer-/Kurzfristregressionen akzeptieren den neuen Planen-Hub und die gemeinsame Horizontnavigation, ohne die geschützten Event-/Reiseplaner-, Modul-, QR- oder Kurzfristverträge abzuschwächen.
- Keine fachliche Änderung an Wetterdaten, Forecast-Fusion, Radar-/Satellitenprodukten, Radarfarben, Parameterfarben, Einheiten oder Workerlogik.

## 0.9.79.7

- CI-Buildfix für das optionale Bottom-Leisten-Bedienkonzept: die deduplizierten Prognosekandidaten werden vor dem `filter()` explizit als `DashboardModuleId[]` typisiert.
- Behebt den TypeScript-Fehler `TS2322: Type 'string[]' is not assignable to type 'DashboardModuleId[]'` aus Release-Run #919.
- Die bestehende Schritt-5-Regression wurde auf den typstabilen Kandidatenaufbau aktualisiert; der Funktionsvertrag selbst bleibt unverändert.
- Keine fachliche Änderung an Navigation, Forecastlogik, Radar-/Satellitenprodukten, Radarfarben, Parameterfarben, Einheiten oder Worker-Fachlogik.

## 0.9.79.6

- Parallelstand v0.9.78.84/.85 vollständig in den Bottom-Bar-Zweig integriert: Synoptik-Buildfix ohne `smoothFactor`, Composite-v3-Linienfarben/Persistenz, Sat/Rad-Wiedergabevertrag und Event-Hitzeempfehlungen bleiben erhalten.
- Optionales Bottom-Leisten-Bedienkonzept, Schritt 7: „Heute“ folgt jetzt **Übersicht → Fokus → Details**; die vollständige Current-Ansicht erscheint im Beta-Modus erst nach explizitem Details-Aufruf.
- Ein erneuter Tap auf „Heute“ führt zurück zur Übersicht; der klassische Current-Bereich bleibt unverändert.
- „Karte“ öffnet im Beta-Modus das bestehende Kompositbild direkt ohne zusätzliche äußere Aufklappstufe.
- Keine Änderung an Radar-/Satellitenprodukten, Radarfarben, Parameterfarben, Einheiten, Forecast-Datenpfaden oder Worker-Fachlogik.

## 0.9.79.5

- Optionales Bottom-Leisten-Bedienkonzept, Schritt 6: neuer Planen-Hub als gemeinsamer Einstieg in Event, Reise, Berg/Winter und Wasser.
- Nicht eingerichtete Aktivitätsprofile führen direkt in Favoriten & Profile; vorhandene Module und Datenpfade bleiben unverändert.
- „Mehr“ erhält im Beta-Modus kompakte Schnellzugriffe auf Einstellungen, Benachrichtigungen, Favoriten/Profile und Wetterzwilling sowie eine deduplizierte Liste weiterer Fachmodule.
- Klassischer Sektions-Drawer, Radar-/Satellitenprodukte, Radarfarben, Parameterfarben, Einheiten und Worker-Fachlogik bleiben unverändert.

## 0.9.79.4

- Optionales Bottom-Leisten-Bedienkonzept, Schritt 5: Prognose als verdichteter Arbeitsraum mit der gemeinsamen Horizontleiste `90 min · 24 h · 7 T · 14 T · 46 T · Saison`.
- Der zuletzt gewählte Prognosehorizont wird persistent gespeichert; der Bottom-Tab Prognose kehrt bevorzugt dorthin zurück.
- Im Beta-Cockpit entfallen doppelte Cockpit-Kopfzeile und interne Horizonttabs; klassische Prognosemodule werden nur im Beta-Modus visuell verdichtet.
- Klassischer Modus, Forecast-Datenpfade, Radar-/Satellitenprodukte, Radarfarben, Parameterfarben, Piktogramme, Einheiten und Worker-Fachlogik bleiben unverändert.

## 0.9.79.3

- Optionales Bottom-Leisten-Bedienkonzept, Schritt 4: kompakte mobile „Heute“-Übersicht aus den bestehenden MID-Datenpfaden.
- „Heute relevant“ priorisiert bis zu drei vorhandene Signale; stündliche Kurzleiste und 7-Tage-Kurzblick führen in die bestehenden Detailmodule.
- Die bisherige Current-Detailansicht bleibt vollständig erhalten; „Alle Details“ führt dorthin.
- Große Orts-Nowcards werden nur im mobilen Bottom-Leisten-Modus aus der Kopfzone genommen; klassischer Modus bleibt unverändert.
- Keine Änderung an Radar-/Satellitenprodukten, Radarfarben, Parameterfarben, Einheiten oder Worker-Fachlogik.

## 0.9.79.2

- Optionaler Bottom-Leisten-Modus: Kompositbild als map-first Fokusansicht mit größerer direkter Kartenfläche.
- Ebenen/Schnellwahl liegen im Fokusmodus als kompakter Karten-Overlay-Dialog; klassische Toolbar bleibt im Fallback unverändert.
- MapLibre-Pan/Pinch und die vorhandenen +/−-Controls bleiben verbindlich; Standortzentrierung bleibt separat erreichbar.
- Timeline, Play/Pause und Geschwindigkeit bleiben direkt unter der Karte; erweiterte Darstellung/Deckkraft folgt danach.
- Keine Änderung an Radarfarbtabellen, Radar-/Satellitenprodukten, Parametern oder Datenpfaden.


## 0.9.79.1

- Optionales Bottom-Bar-Bedienkonzept, Schritt 2: mobiler Kopfbereich im Beta-Modus kompakter; klassischer Modus unverändert.
- Gemeinsame Prognoseleiste `90 min · 24 h · 7 T · 14 T · 46 T · Saison` führt in die bestehenden MID-Prognosemodule statt neue Datenpfade anzulegen.
- 90 min/24 h fokussieren innerhalb von Kurzfrist bzw. Prognose-Cockpit den passenden Abschnitt; 46 T/Saison fokussieren die vorhandenen Langfrist-Unterbereiche.
- Alle neuen Horizont- und Kopf-Aktionsziele bleiben auf iOS mindestens 44 px hoch/breit.
- Radarprodukte und Radarfarben bleiben unverändert auf dem bestehenden Standardfarbenvertrag. Keine fachliche Workeränderung.


## 0.9.79.0
- Optionales neues mobiles Bedienkonzept als persistenter Fallback-sicherer Modus.
- Bottom-Tab-Bar „Heute · Prognose · Karte · Planen · Mehr“ auf kompakten Breiten mit iOS-Safe-Area.
- Klassische Navigation bleibt Standard und jederzeit in den Einstellungen wiederherstellbar.
- Radarprodukte/-farben, Parameterfarben, Einheiten und Datenpfade bleiben unverändert.

# 0.9.78.85

CI-Regressionsfix nach Release #917: stabiler `mid:composite-settings:v3`-Persistenzvertrag mit den neuen Linienfarbfeldern, seriöse Trinkwasser-/Erholungspausen-Semantik im Eventplaner, TypeScript-7-kompatible Event-Regressionen sowie auf die manuell geglätteten/färbbaren MID-Konturen und die nicht mehr scrollbedingt pausierende Sat/Rad-Wiedergabe aktualisierte Komposit-Regressionen. Keine fachliche Workeränderung.

# 0.9.78.84

Synoptik-Buildfix: ungültige `smoothFactor`-Eigenschaften aus den Leaflet/MapLibre-Polyline-Optionen entfernt. Die MID-eigene Konturglättung, Schwarz/Weiß/Akzent-Farbwahl für Isobaren/Isohypsen und die robustere Sat/Rad-Wiedergabe bleiben erhalten. Keine fachliche Workeränderung.

# 0.9.78.83

Eventplaner-Empfehlungen fachlich plausibilisiert: aktivitäts- und umgebungsbezogene Bekleidungs-/Thermiklogik statt pauschaler Übergangskleidung, spezielle Profile für Sport/Indoor/Ski/Wassersport sowie fehlende Ereigniswahrscheinlichkeiten nicht mehr als scheinbare 0 %. Keine fachliche Workeränderung.

# 0.9.78.82

Konsolidierter Stand aus den beiden parallelen 0.9.78.81-Arbeitszweigen: Die gepufferte, quellenwahre Satellitenwiedergabe des hochgeladenen Standes bleibt vollständig erhalten; zusätzlich sind die Skybar-Korrekturen für Open-Meteo-Sonnenscheindauer integriert. Stunden- und 15-Minuten-Akkumulationen werden auf den sichtbaren Vorwärtsslot ausgerichtet, 3-h-Sonnenschein vollständig summiert und Wolkenfelder bei Verdichtung als Intervallmittel behandelt. Keine fachliche Workeränderung gegenüber 0.9.78.81.

# 0.9.78.81

Satellit im Live-Komposit trotz Quellenlatenz sichtbar; bildbereite Wiedergabe mit drei Geschwindigkeiten, gepuffertem Wechsel und wahrheitsgetreuer Zeitbeschriftung. Gesamtstand 0.9.78.80 übernommen.

# MID v0.9.78.80

- 14-Tage-Cockpit: runder Parameter-/Zeitraum-Info-Button direkt neben Modellstand; die bisherige zusätzliche Info-Zeile im Prognose-Kompass entfällt.
- Hochformat: Regime-/Kurzaussage wieder in der ersten Zeile; Tmin/Tmax kompakter zusammengerückt, ohne Werte oder Konfidenz abzuschneiden.

# 0.9.78.79

14-Tage-Karten: Die vergrößerte Konfidenzpille erhält im Hochformat eine kollisionsfreie Kopfzeilenfläche. Regime-Kurzaussage, Wettertext und kompakte Metadaten werden bei knapper Breite nicht mehr abgeschnitten, sondern können umbrechen; Desktopkarten sind moderat verbreitert. Keine fachliche Workeränderung. Siehe MID_IMPLEMENTATION_0.9.78.79.md.

# 0.9.78.78

14-Tage-Konfidenzpille mit größerem Außenabstand zu Temperatur und Wind/Böen sowie klarerer Trennung zwischen Empfangsbalken und 0–100-Index. Fünfstufige Balken- und kontinuierliche Farbsemantik bleiben unverändert. Keine fachliche Workeränderung. Siehe MID_IMPLEMENTATION_0.9.78.78.md.

# 0.9.78.76

24-h-Wetterprofil: fehlende bzw. offensichtlich widersprüchliche H/M/L-Wolkenschichtwerte werden nicht länger als echte 0 % angezeigt. Gesamtbewölkung bleibt unverändert; Schichten werden nicht aus dem Gesamtwert rekonstruiert. Teilweise fehlende Schichten erscheinen als `–`, vollständig nicht belastbare Schichtinformation als `n. v.`. Keine fachliche Workeränderung. Siehe MID_IMPLEMENTATION_0.9.78.76.md.

# 0.9.78.75

Kompositbild: direkte Kartenbedienung mit gemeinsamen +/- Tasten, reale Satellitenhistorie bis etwa −90 min, reparierte WMS-Zeit-/Layerparser und native, lauf- und zeitgebundene DWD-Isobaren/500-hPa-Isohypsen mit numerischem Fallback. Basis 0.9.78.74 vollständig übernommen. Siehe MID_IMPLEMENTATION_0.9.78.75.md. Worker-Update erforderlich.

# v0.9.78.72

- 90-Minuten-Cockpit: Restintervalle unter fünf Minuten direkt vor dem nächsten 15-Minuten-Slot werden nicht mehr als eigene Kachel angezeigt. Die zugrunde liegende Kurzfristserie bleibt unverändert; sichtbar beginnt die Leiste am nächsten belastbaren Slot.
- Wetterzwilling: identische Modellbezeichnungen derselben Unabhängigkeitsgruppe werden in der Gewichtungsanzeige defensiv zusammengeführt. Die Berechnung behält die bereits vorhandenen Modellfamilien-/Unabhängigkeitsbudgets bei; eine doppelte DWD-Anzeige ist nicht als zusätzliche unabhängige Stimme zu verstehen.
- Schneefallgrenze: Niederschlagssignale werden als zusammenhängende Zeitbänder statt regelmäßiger Einzelstreifen dargestellt. Ab Ende der stündlichen Höhenprognose werden native 6-h-Ensemblefenster zeitlich verwendet; die Tageswahrscheinlichkeit aktiviert nicht mehr automatisch jeden 3-/6-h-Punkt. Nicht zeitlich aufgelöste Tageswahrscheinlichkeiten werden ausdrücklich als Tagesband markiert.
- Übergang stündlich → Ensemble bereinigt: 6-h-Fenster auf dem Übergangstag werden am letzten stündlichen Datenzeitpunkt abgeschnitten, sodass z. B. ein bereits stündlich belegtes 03–06-Uhr-Ereignis nicht zusätzlich als 00–06-Uhr-Ensemblefenster erscheint.

## 0.9.78.72

- 14d-Konfidenz wahlweise als Signalbalken, Ampel oder Text+Index; Signalbalken Standard.
- Parameter/weitere Zeiträume hinter kompaktem (i)-Popover.
- 15-Tage-Rohabruf für vollständigen 14. Ensemble-Kalendertag; UI bleibt 14 Tage.
- Datenqualität bleibt vom meteorologischen Konfidenzindex getrennt.
- Event-Stundenintervall- und Symbolkompaktierungsverträge beibehalten und abgesichert.

## 0.9.78.70 – 2026-09-05

- 14d-Konfidenzfenster konsistent zur Tagesbewertung: Datenqualität zerreißt kein meteorologisch hohes Fenster mehr; echte Unterabdeckung bleibt separat sichtbar.
- Nachlaufender nicht bewertbarer Ensemble-Randtag wird als `teilw.`/Randabdeckung statt als vermeintlicher Konfidenzabfall behandelt.
- Kompakte Tagesbadges und Prognose-Kompass zeigen den intuitiven 0–100-Konfidenzindex, ausdrücklich ohne ihn als Treffer-% zu deklarieren.
- Event-Stundenintervall korrigiert: vorangehende Niederschlags-/Sonnenscheinsummen werden nicht mehr durch einen Instantan-Wettercode am Stundenende rückwirkend falsch beschriftet.
- Appweiter Symbolaudit: eindeutige Mikrometriken in 14d, Event-Timeline und Widget platzsparend icon-basiert; Barrierefreiheitsnamen und Einheiten bleiben erhalten.
- Neuer verbindlicher `MID_COMPACT_SYMBOL_CONTRACT.md` und fokussierte Regressionen für Konfidenz-Randtag, Intervallsemantik und Symbolkompaktheit.

## 0.9.78.69 – 2026-09-05

- CI-Hotfix nach GitHub-Run #903: veraltete Mehrparameter-Erwartung entfernt, die schwache Datenbasis fälschlich als meteorologische Mittel-Konfidenz erzwang.
- Verbindlicher Vertrag: Konfidenzfüllung bewertet meteorologische Übereinstimmung; Datenvollständigkeit/Frische bleibt separat im Qualitätsring.
- Fehlender einzelner Kernparameter, unbekannte Lauf-Frische oder reduzierte Member-Abdeckung dürfen bei sonst stark übereinstimmenden Kernsignalen `hoch` bleiben; weniger als zwei Kernparameter bleiben fail-closed nicht bewertbar.
- Neue Regression schützt die Trennung von meteorologischer Konfidenz und Datenqualität.

## 0.9.78.68

- CI-Hotfix: sieben nach der 14d-Konfidenzmodernisierung veraltete Regressionserwartungen an die aktuellen, verbindlichen UI-/Datenqualitäts-/iOS-Touch-Verträge angepasst; keine Produktionslogik zurückgebaut.
- TypeScript-7-Regressionshygiene: `test-ensemble-multiparameter-097865.mjs` verwendet ausschließlich `typescript-strada` und enthält keinen Root-TypeScript-Strada-Fallback mehr.
- Release-Härtung: Der kanonische Professional-ZIP-Packer führt ab jetzt zwingend einen vollständigen lokalen Preflight aus (TS7 + Vite, Worker-Syntax, alle Regressionen, Version, Baseline, Lineage, Uploadbudget) und prüft anschließend die ZIP-Integrität.

## 0.9.78.67 – 2026-09-05
- 14-Tage-Vorhersagekonfidenz robust statt „schwächster Parameter gewinnt“: Niederschlag 32 %, Temperatur 28 %, Wind/Böen 28 %, Sonne 12 %.
- Datenqualität (`gut/eingeschränkt/schwach/nicht ausreichend`) von meteorologischer Konfidenz getrennt; parameterbezogene erwartete Ensemblefamilien verhindern künstliche Ausfälle.
- 50:50-Niederschlagsereignis wird als offener Ausgang, nicht als schlechte Prognose gewertet.
- P10–P90-Spread wird vorlaufabhängig normalisiert; Langfrist-Caps verhindern unrealistisch hohe Sicherheit in Woche 2.
- Lokale MID-Verifikation kann bis 96 h mit stark geschrumpften Fehler-/Brier-Korrekturen einfließen; keine Extrapolation in den Langfristbereich.
- Cockpit und EnsemblePanel nutzen denselben zentralen Konfidenzpfad; Datenqualität wird separat am Konfidenzindikator visualisiert.
- Veraltete 14d-/Bootstrap-Regressionsverträge auf die neue Kalibrierungs- und Datenqualitätsarchitektur aktualisiert.

## 0.9.78.66

- 14d-Wetter-Kurzaussagen bleiben appweit in den Übersichtskacheln einzeilig; historische Responsive-Regeln mit erzwungenem Umbruch werden final übersteuert.
- Favoriten-Schnellleiste auf Touch-Geräten gehärtet: normaler Tap nutzt wieder den nativen Button-Pfad, Drag startet erst nach 8 px Bewegung.
- Antippen des Sortiergriffs wählt den Favoriten ebenfalls aus; Klicks werden nur nach einem echten Drag unterdrückt.
- Sortiergriff wieder als reguläres Grid-Element statt absoluter Touch-Überlagerung; horizontales Scrollen bleibt unverändert erhalten.

## 0.9.78.65

- Gemeinsame Vierparameter-Bewertung in klassischer 14d-Ansicht und Cockpit statt Temperaturindex und 72-Punkte-Grenze.
- Native Parameterabdeckung, vollständige lokale Tage und Laufalter verhindern hohe Einstufung bei Datenlücken oder veralteten Läufen.
- Kalendergenaue gemeinsame und parameterspezifische Zeiträume, spätere Fenster und begrenzende Bereiche sichtbar.
- Qualitative, textlich erklärte Details; keine unkalibrierte Genauigkeits-Prozentzahl.
- Ensemblecache v17, Verhaltenstests und wissenschaftliche Methodendokumentation ergänzt.

## 0.9.78.64

- 14d-Anzeige wissenschaftlich eingegrenzt: unkalibrierter Temperatur-Konsistenzindex statt behaupteter Prognosesicherheit in Prozent; kompakte und ausführliche Streuungsberechnung vereinheitlicht.
- Plausible Ensemble-Minderheitslösungen werden nicht mehr durch Median-/IQR-Beschneidung aus den Unsicherheitsbändern entfernt; Ensemblecache erneuert.
- Fehlende Saison-, Warn-, Skybar- und Lüftungsdaten bleiben unbekannt; erhöhtes CO₂ priorisiert das früheste geeignete Fenster.
- Eventfenster über Mitternacht und Ortszeitzonen korrigiert; kein Stundenmittel als Ersatz für Ereigniswahrscheinlichkeit, vollständige Member-Intervallabdeckung erforderlich.
- Radar-ETA auf Beobachtung +120 min begrenzt; fehlende Bewegungskonfidenz und unbekannte KONRAD-Zeitstempel gesperrt; Szenarioanteile korrekt beschriftet.
- Flugprofile unterscheiden Gelände-AGL, ISA-Druckflächen und geometrische MSL-Schichtgrenzen; keine Randwertextrapolation oder Entwarnung bei unvollständiger Datengrundlage.
- Klimatische Nasshäufigkeit nutzt die gültige Niederschlagsstichprobe; betroffene Cachegenerationen erneuert.
- Neue wissenschaftliche Verhaltenstests und Dokumentation: MID_IMPLEMENTATION_0.9.78.64.md.

## 0.9.78.63
- Skybar-Sonnenklassifikation korrigiert: Gelb beginnt tagsüber erst oberhalb 50 % relativer Sonnenscheindauer und nutzt bis 100 % vier symmetrische Dickenstufen.
- Graues Bewölkungsband bleibt ab 50 % Gesamtbewölkung bis 100 % vierstufig; Gelb und Grau sind als Grundband strikt gegenseitig exklusiv.
- Direkte Sonnenscheindauer ist primär; Gesamtbewölkung dient nur bei fehlender Sonnenscheindauer als komplementärer Sonnenfallback.
- Alte `max(Sonnenschein, Aufklarung)`-Logik entfernt, die geringe Bewölkung systematisch zu einem zu dicken gelben Band machen konnte.
- 3-h-/aggregierte Skybar-Werte werden an der realen Intervalllänge normalisiert; dadurch kein künstliches Hochskalieren aufsummierter Sonnenscheindauer.

## 0.9.78.62
- GitHub-Installer #896 repariert: TypeScript 7 und Vite-Produktionsbuild waren bereits erfolgreich; nur 1 von 680 Regressionen war veraltet.
- Niederschlagsformen-/Schneemengenregression auf den verbindlichen zentralen `compactSevenDayConditionLabel`-Pfad migriert.
- Kompakte 7-Tage-Einzeiler und phasentreue Labels für Regen, Schauer, Schnee und Schneeregen bleiben unverändert erhalten.
- Keine fachliche Produktions- oder Worker-Änderung.

## 0.9.78.61
- Luftdruck-Y-Achsen im 24-h-Wetterprofil und Tagesdetail auf ganzzahlige, gleichmäßig verteilte hPa-Ticks umgestellt.
- Gemeinsame adaptive 2/4/5/10-hPa-Achsenschritte mit sauberer Randreserve eingeführt.
- 7-Tage-Kurzpillen-Vertrag beibehalten und bestehende Altregressionen darauf synchronisiert.

# 0.9.78.60 — 2026-09-04

- Sektion **Kompositbild** als moderne, kartenorientierte Übersicht mit den klar getrennten Modi Radar, Satellit und Synoptik neu geordnet.
- Zeitachse zeigt ausschließlich tatsächlich verfügbare Produktstände im festen Bereich −1 bis +2 Stunden; Beobachtung, Nowcast und Modellprognose sind eindeutig getrennt.
- Unzuverlässigen pauschalen Zeitpfeil durch echogebundene Zugspuren ersetzt: Eine ETA entsteht nur bei realem Radaranker auf Standortkurs und ausreichender Bewegungsqualität; Unsicherheitskorridor, +15- bis +120-Minuten-Knoten und Wachstumstrend werden sichtbar.
- Radar- und Satellitenwechsel mit stabilem Vordergrundbild, Hintergrund-Vorladen, begrenztem Framecache und Fehlerquorum gegen leere/flackernde Vorschauen gehärtet.
- Untimed Satellit, 250-m-Radar, Warnkarte, Blitze und KONRAD3D/NowCastMIX werden nicht mehr in fachlich unzulässige Vergangenheits- oder Zukunftsstände kopiert.
- Schnellwahl, verständliche Overlay-Bezeichnungen, kompakte Facheinstellungen, Datenstatus, Live-Rückkehr und Standortzusammenfassung ergänzt; mobile Darstellung auf eine klare zweispaltige Bedienung optimiert.
- Neue Regression `test-composite-temporal-truth-zugspuren-097860.mjs`; alle historischen Kompositprüfungen auf den neuen Zeit- und Zugspurenvertrag migriert.

# 0.9.78.54 — 2026-09-04

- GitHub Release #886 repariert: TypeScript-7-/Vite-Produktionsbuild war bereits erfolgreich; ausschließlich 7 von 675 historischen Regressionen blockierten anschließend den Release.
- Veraltete Warnungsregressionen an den seit v0.9.78.49–.53 verbindlichen probabilistischen Warnvertrag angepasst: entfernte Hilfstexte bleiben entfernt, Windrichtung bleibt inline, probabilistische Zeitfenster bleiben sichtbar.
- Ensemble-Resume-Test gegen den neuen `warningEnsemble`-Zustand gehärtet, ohne den Schutz des letzten erfolgreichen Ensemble-Stands zu lockern.
- Keine fachliche Produktionslogik geändert; Worker nur versionssynchronisiert.

# 0.9.78.53 — 2026-09-04

- Warnrelevante MID-Prognosehinweise erhalten echte kurzfristige EPS-Unterstützung für Böen, Niederschlag und Temperatur.
- 12-km-Umfeldprüfung mit Standort plus vier Nachbarpunkten; räumliche Extrema werden pro Ensemblemitglied vor der Quantilbildung gebildet, damit keine Pseudomitglieder entstehen.
- Bis zu zwei unabhängige Ensemble-Modellfamilien stützen Warnfenster; Modellfamilien derselben `independenceGroup` werden nicht doppelt gewertet.
- Wind-/Niederschlags-/Schnee-/Hitzehinweise verwenden `bis zu …` statt pseudogenauer Von-bis-Spannen.
- Amtliche Originalwarntexte bleiben unverändert; sichtbare MID-Knotenangaben bleiben `kt`.
- Baseline-Verweise für v0.9.78.50–53 vervollständigt.

## 0.9.78.52 - 2026-09-04
- GitHub-Release #884 repariert: probabilistische Warnfenster verwendeten drei nicht existierende `Hour`-Felder (`precip`, `temp`) bzw. einen falschen Summen-Key und scheiterten deshalb im TypeScript-7-Check.
- Warnlogik nutzt jetzt kanonisch `precipitation`, `temperature` und `snowfall`; Probabilistik, erweiterte Zeitfenster und der `kt`-Anzeigevertrag bleiben unverändert.
- Neue Regression `test-warning-probabilistic-hour-fields-buildfix-097852.mjs` schützt Fragment und generiertes Aggregat.

## 0.9.78.51 - 2026-09-04

- Knoten-Anzeigevertrag präzisiert: MID-generierte Inhalte verwenden sichtbar ausschließlich `kt`; `kn` bleibt nur interner/API-Transportwert.
- Amtliche Originalwarntexte bleiben wortgetreu und dürfen daher weiterhin `kn` enthalten, wenn die Quelle dies so liefert.
- Die kompakte MID-Zusammenfassung einer amtlichen Windwarnung liest `kn`/`kt`/`Knoten` aus dem Original, beschriftet den übernommenen Zahlenwert aber einheitlich als `kt`.
- Verbindlicher Warnvertrag und Regression `test-wind-kt-display-contract-097851.mjs` ergänzt.

## 0.9.78.50 - 2026-09-04

- Warnungsbereich überarbeitet: amtliche DWD-Untertitel ziehen Windwerte nun bevorzugt direkt aus den offiziellen DWD-Einheitenangaben (inkl. `kn`/`kt`) statt aus MID-intern rückgerechneten Werten.
- MID-Prognosehinweise berechnen Gültigkeitsfenster jetzt probabilistisch erweitert und kennzeichnen sie als Wahrscheinlichkeitsbereich; dadurch werden enge Einzelstunden-Treffer bei Windböen und anderen warnfähigen Parametern vermieden.
- Prompt-/Hilfstexte innerhalb und unterhalb der MID-Hinweissektion entfernt, damit nur fachlich relevante Inhalte angezeigt werden.

## 0.9.78.49
- Warnungen & Hinweise als Hybrid-Zentrum neu geordnet: amtliche Warnungen zuerst, MID-Prognosehinweise danach; überlappende Hinweise als MID-Ergänzung.
- Amtliche Warnstufenfarben exklusiv für amtliche Meldungen; MID-Hinweise nutzen Parameterfarben.
- Kompakte amtliche Windzusammenfassungen folgen der gewählten Windeinheit, Originaltexte bleiben unverändert.
- Automatische Warninhalte vermeiden trügerische Genauigkeit: Wind/Regensummen/Schnee/Temperatur als Bereiche, Nebel/Glätte/Gewitter räumlich-qualitativ; schauergebundene Gefahren kennzeichnen unsicheren Ortstreffer.
- Neuer verbindlicher Vertrag `MID_WARNING_HYBRID_CONTRACT.md` und Regression `test-warning-hybrid-uncertainty-097849.mjs`.

## 0.9.78.48
- Release #881 repariert: 19 veraltete Regressionen nach dem Forward-Slot-Niederschlagsvertrag auf den aktuellen Fachstand migriert.
- Isolierte `forecastFusion.ts`-Testharnesses kapseln die neue `precipitationIntervals`-Abhängigkeit, statt wegen eines fehlenden Temp-Moduls abzubrechen.
- Sichtbare Niederschlagszeiten bleiben startgestempelt; Rohakkumulationen bleiben intern endgestempelt.
- 24-h-, Current/Kurzfrist-, Wasser-, Höhenwetter-, Solar-, Radar- und 7d-Beschriftungsregressionen an die bereits verbindlichen Produktionsverträge angepasst.
- Neue Meta-Regression schützt die Forward-Slot-/Harness-Kompatibilität dauerhaft.

## 0.9.78.47
- GitHub-Release #880 repariert: `src/ShortTermForecast.tsx` enthielt nach der Vorwärts-Slot-Umstellung noch die ungenutzte Hilfsvariable `targetOffsetMinutes`; TypeScript 7.0.2 blockierte deshalb mit TS6133.
- Die überflüssige Variable ist entfernt. Der fachliche v0.9.78.46-Vertrag bleibt unverändert: sichtbarer Niederschlag ist am Beginn des Zukunftsintervalls beschriftet, Rohakkumulationen werden weiterhin korrekt am Intervallende gelesen.
- Neue Regression `test-shortterm-forward-slot-buildfix-097847.mjs` verhindert sowohl den TS6133-Rückfall als auch eine versehentliche Rückkehr zur Endstempel-Anzeige.

## 0.9.78.46
- Sichtbare Niederschlagszeiten auf erwartbare Vorwärtsslots umgestellt: `08:00` mit Niederschlag bedeutet nun `08:00–09:00`; rohe Open-Meteo-/DWD-Akkumulationen bleiben intern weiterhin am Intervallende.
- Zentraler Präsentationsadapter koppelt Niederschlagsmenge, PoP, Phase und niederschlagsbestimmten Wettercode an denselben sichtbaren Slot; Temperatur/Wind/Bewölkung bleiben punktbezogen.
- 15-min-/1-h-Übergang, 24-h-Profil, 7d-Kurve/Karten/Skybar, Tag-/Folgenacht-Piktogramme, Widget, Ensemble-Best-Match, Wasser-/Bergsport und Meteogramm auf denselben Zeitvertrag ausgerichtet.
- Berg-/Wintersport-3-h-Matrix zusätzlich korrigiert: Zeitlabel = Slotbeginn; Niederschlag wird aus den normalisierten Einzelstunden summiert, PoP daraus maximiert und das repräsentative Piktogramm aus demselben Intervall gewählt.
- Fehlende Anschlussprobe wird fail-safe nicht als alte Niederschlagsstunde in die Zukunft verschoben; trockene Slots verlieren dabei einen eventuell alten nassen Rohcode.
- Neue Regression `test-precipitation-forward-slot-presentation-097846.mjs`; veraltete statische 7d-/PoP-Assertions an die Präsentationsschicht angepasst.

## 0.9.78.45
- 7-Tage-Cockpit: sichtbare Wetterbeschreibung stammt jetzt aus demselben `dayWeatherCharacter` wie das Tagespiktogramm statt aus der groben Regimeklasse. Dadurch wird z. B. `Wolkig, oft sonnig` nicht mehr pauschal als `Sonnig` beschriftet.
- Die kleine Glyphe in der Beschreibungspille verwendet denselben `dayVisual`-Code und dasselbe Wolkenprofil wie das große Tagespiktogramm; Regime bleibt nur sekundäre Farb-/UI-Metadaten.
- Neuer Regressionstest schützt Text-/Piktogramm-Kohärenz der 7-Tage-Tageskarten.

## 0.9.78.44
- Release #878 repariert: der ältere Event-Lifecycle-Regressionstest erwartete noch das frühere 550-ms-Splashbudget und blockierte damit die bewusst auf maximal 900 ms erweiterte v0.9.78.43-Startvorladung.
- Event-Lifecycle-Regression prüft nun dauerhaft ein hartes Splashbudget von höchstens 900 ms statt einer veralteten exakten Millisekundenzahl.
- Startup-Vertrag an die aktuelle Architektur angeglichen: leichter Mean/Spread-Ensemble-Bootstrap und benötigte UI-Chunks dürfen im Splash vorladen; volle Member-/Mehrmodellfusion, Radar und andere schwere Sekundärdaten bleiben nach dem App-Mount.
- Keine fachliche Änderung an Wetterdaten, Piktogrammen, Skybar oder Worker-Runtime.

## 0.9.78.43
- App-Start auf iPhone/PWA vorgezogen: Best-Match-Prognose beginnt unmittelbar nach dem Bootmarker parallel zu Storage-/Persistenz-Restore; Schnellstation, Ensemble-Mean/Spread-Bootstrap und benötigte Ensemble-UI-Chunks werden gestaffelt im Splash vorgewärmt und anschließend von `App.tsx` über dieselben Promises weiterverwendet statt doppelt abgefragt.
- Das Splash-Wartebudget bleibt hart auf 900 ms nach den lokalen Restore-Schritten begrenzt; volle Ensemble-Memberfusion, Radar-, Warn- und weitere Sekundärabrufe werden bewusst nicht zusätzlich in den Splash gezogen. Der globale Open-Meteo-Guard bleibt auf maximal zwei aktive Abrufe mit Startabstand begrenzt.
- Wetterpiktogramme appweit konsolidiert: neuer zentraler `periodWeatherVisual`-Vertrag koppelt Tagespiktogramme an `dayWeatherCharacter`; kurze Einzelstunden dürfen zusammengefasste Nacht-/Periodenpiktogramme nicht mehr allein dominieren.
- 7-Tage-Karten mit zwei Symbolen trennen nun verbindlich Tagescharakter und tatsächlich folgende Nacht: großes Tagespiktogramm folgt Tageslicht-/Sonnenschein-/Niederschlagscharakter, kleines Nachtpiktogramm aggregiert ausschließlich die Folgenacht nach Dauer, Wahrscheinlichkeit, Menge, Nebel und mittlerer Bewölkung.
- Derselbe Periodenvertrag wird in klassischer 7-Tage-Ansicht, Cockpit-7d, Tagesdetail und Widget-Vorschau verwendet; lokale konkurrierende Perioden-Icon-Selektoren wurden entfernt. Weather Icon System 2.0 bleibt der einzige Renderer.

## 0.9.78.42
- CI-Hotfix für Release-Run #876: TypeScript 7, Vite-Produktionsbuild und 663 von 664 weiteren Regressionen waren bereits grün; ausschließlich der appweite Parameterfarbtest erwartete nach der zentralisierten Phasenpalette noch den alten Inline-String im ForecastCockpit.
- `test-appwide-parameter-colors-09779.mjs` prüft nun den aktiven gemeinsamen Vertrag: flüssiger Niederschlag nutzt weiterhin `--param-precipitation`, Schnee hellblau, Misch-/gefrierende Phase violett und Gewitter/Hagel purpur; ForecastCockpit und Skybar greifen auf dieselbe zentrale Palette zu.
- Keine meteorologische Fachlogik verändert. Die phasenabhängigen Skybar-/Cockpitfarben, 24-h-Tageskarten-Skybar, Ensemble-Härtung und die erweiterte 7d-Nachtfläche bleiben unverändert.

## 0.9.78.41
- CI-Buildfix für GitHub Release-Run #875: den nach der phasenabhängigen Skybar-Umstellung ungenutzten `sunshineShare`-Parameter aus `precipitationOverlayVisual` entfernt; dadurch wird TypeScript 7 `TS6133` beseitigt.
- Phasenabhängige Niederschlagsfarben, vier Skybar-Dickenstufen, v0.9.78.40-Nachtflächen und Installer-Härtung bleiben unverändert.
- Neue Regression schützt den Buildfix.

## 0.9.78.40
- GitHub-Release-Installer gegen flüchtige frühe CI-Abbrüche gehärtet: `npm ci` und das Produktions-Dependency-Audit werden jetzt bis zu drei Mal mit Bereinigung bzw. kurzer Backoff-Pause wiederholt, bevor der Lauf hart fehlschlägt.
- 7-Tage-Kurvenübersicht: der Nachtgraubereich spannt jetzt bewusst von oberhalb der Skybar bis unter die Niederschlagsbasis, damit Nachtstunden auch hinter Wetterstreifen und Niederschlagsbalken zusammenhängend sichtbar bleiben.
- Parallel-Chat-Stand erneut gegengeprüft: die phasenabhängigen Skybar-Niederschlagsfarben sowie die bereits vereinigten Sicherheits-/Ensemble-/Sonnen-Fixes bleiben unverändert erhalten.
- Neue Regressionen schützen sowohl die Installer-Retries als auch die erweiterte Nachtflächen-Geometrie.

## 0.9.78.39
- Parallel-Chat-v0.9.78.34 vollständig mit dem neueren v0.9.78.38-Hauptstand vereinigt: CodeQL #81–#90, flüchtiger Netatmo-OAuth-Handoff, sichere zufällige Worker-Deploy-Tempdateien sowie die zugehörigen Schutztests bleiben erhalten.
- Neuere Ensemble-/Skybar-/Sonnen-Fixes v0.9.78.35–.38 bleiben gleichzeitig vollständig bestehen.
- Skybar-Niederschlag nach Art/Phase eingefärbt: Regen/Schauer blau, Schnee hellblau, Misch-/gefrierende Phase violett, Gewitter/Hagel purpur; gemeinsame Palette mit dem Forecast-Cockpit.
- Skybar-Legende auf phasenabhängige Niederschlagsfarben umgestellt.

## 0.9.78.38
- Skybar verbindlich auf Gelb/Grau/Blau umgestellt: Sonnenschein gelb, Bewölkung einheitlich grau, Niederschlag unabhängig von der Phase blau; keine Grauton- oder Opacity-Abstufung mehr.
- 50-%-Schwelle präzisiert: ab 50 % Gesamtbewölkung vier Graudicken von 50–100 %, darunter tagsüber vier Sonnendicken aus relativer Sonnenscheindauer bzw. Aufklarung.
- Vier Dickenstufen leicht verstärkt auf 2,4 / 3,3 / 4,2 / 5,1 SVG-Einheiten; mobile Tageskarten-Skybar bleibt auch unter 480 px 16 px hoch.
- Legende auf drei eindeutige Einträge „Sonnenschein · gelb“, „Bewölkung · grau“, „Niederschlag · blau“ sowie den 50-%-Vertrag umgestellt.
- Einheitliche Farbe/Opacity beseitigt künstliche Unterbrechungen bei gleich dicken aufeinanderfolgenden Bewölkungs- bzw. Niederschlagssegmenten.

## 0.9.78.37
- Vollensemble startet 2 s nach dem sichtbaren Mean/Spread-Bootstrap; lange unabhängige Modellfamilien werden zuerst geladen.
- Vollfusion auf sechs erfolgreiche Modellrouten bei maximal zwei parallelen Open-Meteo-Requests begrenzt; 20-s-Modellbudget und fehlerabhängige Variablenfallbacks reduzieren Blockade- und Request-Risiko.
- Finaler Ensemblecache auf 60 min verlängert, um identische Neuabrufe zwischen Modellupdates zu vermeiden.
- Relative 14-Tage-Sonne zeichnet immer alle acht Strahlen und skaliert die Strichstärke sauber bei 12–14 px.
- Release-Run #872: fünf veraltete PoP-Stringregressionen mit dem 24-h-Skybar-Vertrag wieder kompatibel gemacht.

## 0.9.78.36
- Ensemble-Erststart auf iOS auf einen seriellen Mean/Spread-first-Pfad umgestellt: zunächst eine echte Ensemblefamilie sichtbar, anschließend automatische Vollfusion statt parallelem Großabruf.
- Bootstrap auf einen gleichzeitigen Modellabruf begrenzt; Memberdaten dienen nur als Fallback, wenn Mean/Spread nicht verfügbar ist.
- Einzelmodell-Bootstrap wird in der Konsistenz bewusst schwächer bewertet; finaler Mehrmodellvertrag bleibt unverändert.
- Versionssynchronisierung hält `MID_BASELINE.json.releaseVersion` und das Legacy-Feld `version` gemeinsam aktuell.

## v0.9.78.28

- Wartungsbereinigung ohne Funktionsabbau: zwei veraltete TypeScript-5.8-Buildartefakte und generierte Prüfartefakte dauerhaft aus Professional-Releases ausgeschlossen; 33 innerhalb ihrer Quellmodule exakt doppelte CSS-Regeln konsolidiert.
- „Aktuell“-Ansicht rechenärmer: der Minutentimer nutzt nur noch das gecachte Sonnenfenster; die vollständige Sonnen-/Mond-/Finsternisübersicht wird höchstens stündlich neu berechnet.
- iPhone-Handling verbessert: 1-h-/3-h-Schalter des 24-h-Wetterprofils erhalten im Grobzeigermodus dieselbe verlässliche 36-px-Trefferhöhe wie benachbarte Kompaktsteuerungen.
- MapLibre GL JS 6.7.0 und Capacitor Core/iOS/CLI 8.5.1 nach kompatiblem Wartungslauf übernommen; React 18, Recharts 3, Vite 6 und TypeScript 7 bleiben unverändert.
- Bewusst dormant gehaltene Altmodule bleiben vollständig als reaktivierbare Referenz erhalten; keine fachliche Workeränderung und kein Worker-Upload erforderlich.

## v0.9.78.21

- CI-Hotfix für GitHub Release-Run #858: TypeScript 7, Vite-Produktionsbuild und 649 von 650 Regressionen waren bereits grün; ausschließlich `test-seven-day-ecmwf-hourly-09781.mjs` erwartete noch die frühere Nachtdeckkraft `0.18`.
- Regression auf den verbindlichen v0.9.78.20-Vertrag synchronisiert: zusammenhängende Nachtstunden bleiben mit `fillOpacity={0.07}` nochmals deutlich heller; P25–P75-Temperaturband, Skybar-Abstufung und alle Fachberechnungen bleiben unverändert.
- Keine fachliche App-, Forecast-, RUC- oder Workerlogik geändert; Worker nur versionssynchronisiert.

## v0.9.78.20

- 7-Tage-Kurvenübersicht: Nachtflächen nochmals deutlich aufgehellt und zusammenhängend über Mitternacht belassen.
- Temperaturkurve ergänzt um ein hellgraues P25–P75-Unsicherheitsband aus den verfügbaren Ensemblequartilen der ersten sieben Tage.
- Skybar fachlich korrigiert: `sunshineDuration` wird entsprechend dem MID-Vertrag als Sekundenwert behandelt und jetzt durch die reale Intervalllänge (15 min bzw. 1 h) normiert; dadurch entstehen wieder echte abgestufte Sonnenscheinanteile statt nahezu sofortiger 100-%-Sättigung.
- Niederschlagsdicke wird zeitauflösungsneutral aus der auf mm/h normierten Intensität abgeleitet, damit 15-Minuten- und Stundenwerte dieselben vier Dickenstufen fachlich gleich nutzen.
- Skybar ohne 3D-Unterlage und ohne überstehende Round-Cap-Überlappungen: jedes Segment bleibt als abgerundetes Rechteck innerhalb seiner eigenen Zeit-Zelle.
- Keine fachliche Workeränderung; Worker nur versionssynchronisiert.

## v0.9.78.16

- Weather Icon System 2.0: Niederschlagsintensität für alle Phasen weiter geschärft; Regen/Sprühregen sowie Schnee, Schneegriesel, Eiskristalle, Eiskörner, Graupel und Hagel nutzen klar unterscheidbare Partikelanzahl/-dichte/-größe.
- Sichtbare Niederschlagsintensität wird für Forecastdaten aus der finalen MID-Menge nach Fusion/Plausibilisierung rekalibriert, ohne die Niederschlagsphase umzudeuten.
- Niederschlagselemente unter der Wolke kontrastreicher und bei kleinen Piktogrammen besser erkennbar.
- Run #852: sechs veraltete Regressionen auf die aktuellen Verträge migriert; entfernte Prompt-/Supersession-Texte werden nicht wieder verlangt, die neue mehrschichtige Wetterstreifenlogik ersetzt den alten `detailSkyBarSample`-Anker.
- Release-Installer behandelt ein fachlich bereits identisch installiertes ZIP als erfolgreichen No-op statt als Fehler.

## v0.9.78.12

- CI-Hotfix für GitHub Release-Run #850: TypeScript-7-Prüfung und Vite-Produktionsbuild waren vollständig grün; ausschließlich drei Regressionstests erwarteten nach der v0.9.78.10-Niederschlagsintervallkorrektur bzw. dem v0.9.78.11-TS6133-Hotfix noch supersedierte Quelltextanker.
- Kurzfrist-Regression auf den trailing-interval-Vertrag migriert: das erste laufende 15-Minuten-Fenster zeigt nur den tatsächlich noch zukünftigen Anteil ab jetzt (z. B. 7 min), danach folgen volle 15-Minuten-Intervalle.
- Sonne/Niederschlag-Kohärenztest auf die aktuelle fachliche Erläuterung migriert; PoP bleibt Eintrittswahrscheinlichkeit und wird nicht als Regendauer interpretiert.
- 24-h-Zellgeometrietest schützt nun die aktive intervalgebundene `profileBandGeometry` direkt und verbietet ausdrücklich die Rückkehr des in v0.9.78.11 entfernten toten `probabilityCellGeometry`-Helpers.
- Keine fachliche App-, Forecast-, Niederschlags- oder Workerlogik geändert; ausschließlich Regressionen an den bereits aktiven Fachvertrag angepasst.

## v0.9.78.11

- CI-Hotfix für GitHub Release-Run #849: unbenutzten Resthelfer `probabilityCellGeometry` aus `ForecastCockpit.tsx` entfernt.
- Der Fehler war rein typseitig (`TS6133`) und blockierte `verify:types`; die Niederschlags-Intervall-/Nowcast-Fachlogik aus v0.9.78.10 bleibt unverändert erhalten.
- Neuer Regression-Lock verhindert die erneute Einführung des unbenutzten Helpers.
- Keine fachliche Workeränderung; Worker nur versionssynchronisiert.

## v0.9.78.10

- Niederschlags-Intervallsemantik appweit korrigiert: Open-Meteo-/MOSMIX-Akkumulationen werden als rückblickende Intervalle mit Zeitstempel = Intervallende behandelt; Radarfenster sind nicht mehr um den Modellzeitpunkt zentriert.
- 24-h-Wetterprofil „ab jetzt“ zeigt keine bereits vollständig vergangene Stundenmenge mehr. Das erste laufende Intervall wird nur mit seinem Zukunftsanteil bilanziert; finalisierte 15-Minuten-/Radarwerte speisen die ersten Stundenblöcke.
- Niederschlagsbalken und PoP liegen auf ihren realen Intervallgrenzen, während Temperatur, Wind und Druck punktbezogen bleiben.
- Radar-NWP-Blend gehärtet: trockene Standort-Radarstrecken dämpfen auch Modellmengen >1 mm; Echo nur im Umfeld darf die PoP stützen, aber keine ungestützte Standortmenge unverändert durchreichen.
- Kurzfrist-Fallback und hyperlokale Niederschlagsassimilation verwenden das Akkumulationsintervall, das den Ziel-/Beobachtungszeitpunkt enthält.
- Resttages-Niederschlag zählt nur zukünftige Intervallanteile; Tmin/Tmax bleiben unverändert.
- Neuer verbindlicher Vertrag `MID_PRECIPITATION_INTERVAL_CONTRACT.md` und Regression `test-precipitation-trailing-interval-nowcast-097810.mjs`.
- Keine fachliche Workeränderung.

## v0.9.78.9

- Weather Icon System 2.0 visuell appweit verriegelt: H/M/L-Wolkendiagnostik darf die Hauptglyphe nicht mehr in wellige Cirrus-/Altostratusformen umformen; Bedeckt, Niederschlag, Schauer, Gewitter und Nebel folgen nun unabhängig davon der freigegebenen Symbolfamilie.
- Appweite Wetterzustands-Pfade für Aktuell, Kurzfrist, 7/14 Tage, Ensemble, Event, Reise, Route, Wasser und Widget bleiben auf `WeatherPictogram`; Radar-/Komposit-Schalter und Forecast-Parametericons wurden von Wetter-Emoji-Darstellungen auf Vektor-/Lucide-Symbole bereinigt.
- 14-Tage-Desktopdarstellung ab 1025 CSS-px mit 224-px-Karten, horizontalem Scrollband, lesbarer Typografie und klar getrennten Wetter-/Temperatur-/Niederschlags-/Sonnenschein-/Windbereichen. Das 7×2-Mikrolayout bleibt auf Mobil-/Tablet-Querformat bis 1024 px beschränkt.
- Keine fachliche Workeränderung.

## v0.9.78.8

- GitHub-Regression `test-location-thunder-water-tide-layout-09644.mjs` auf den aktuellen Nachfolgevertrag migriert: die separate Kachel „Gewitterrisiko“ bleibt entfernt; relevante Gewitterinformationen werden kompakt in der Niederschlagskachel geführt, während Aktuell und Wassersport weiterhin dieselbe kanonische 6-h-Ortsanalyse verwenden.
- 14-Tage-Desktopdarstellung repariert: der extrem verdichtete 7×2-Querformatmodus greift nur noch bis 1024 CSS-Pixel. Desktopbreiten erhalten wieder mindestens 190 px breite, horizontal scrollbar angeordnete Tageskarten.
- 14-Tage-Kartenkopf und Parameterzeilen kollisionsfrei neu gegliedert; keine Mikroschrift bzw. übereinanderliegenden Tmin/Tmax-, Wind- oder Konsistenzwerte mehr auf Desktop.
- Keine fachliche Workeränderung.

## v0.9.78.5

- GitHub-Installer-Run #843 gezielt korrigiert: Produktionsbuild, TypeScript 7, Vite und 645 von 646 Regressionen waren bereits grün; ausschließlich `test-tmin-tmax-number-tone-097717.mjs` erwartete noch die vor v0.9.78.4 gültige stärkere Tmin/Tmax-Hintergrund-/Rahmenintensität.
- Regression auf den verbindlichen v0.9.78.4-Vertrag migriert: 7-Tage-ECMWF-Tmin/Tmax behalten den bewusst schwachen 10-%-Hintergrund ohne Min/Max-Zusatzlabel; 14-Tage-Tmin/Tmax reagieren weiterhin nichtlinear auf Klimaabweichungen, jedoch mit der gedämpften 5–16-%-Hintergrund- und 20–46-%-Rahmenskala.
- `MID_PARAMETER_COLOR_CONTRACT.md` präzisiert: im 14-Tage-/Ensemblebereich bleibt die signierte Klimareaktion erhalten, während der 7-Tage-Modus ausschließlich absolute ECMWF-Farben ohne Klimadelta verwendet.
- Keine fachliche App-, Forecast-, RUC- oder Workerlogikänderung; Worker nur versionssynchronisiert.

## v0.9.78.4

- 7-Tage-Kurvenübersicht geometrisch auf die gleiche Tagesbreite wie der Piktogramm-/Tageskopf fixiert: die oberen Tagessegmente verwenden jetzt exakt dieselben linken/rechten Plotränder wie die 00–24-h-Tagesabschnitte im Diagramm. Dadurch liegen Tageskopf und Kurventeil pro Kalendertag deckungsgleich übereinander.
- 7-Tage-Tageskarten im Forecast-Cockpit zeigen Tmin/Tmax jetzt kompakter ohne die zusätzlichen "Min"/"Max"-Beschriftungen.
- Klassische 7-Tage-Listenansicht ebenfalls auf die kompakte Tmin/Tmax-Darstellung ohne "Min"/"Max" umgestellt.
- Hintergrundflächen der Tmin/Tmax-Badges in 7 und 14 Tagen bewusst abgeschwächt, damit Zahlen bei warmen und kalten Extremen besser lesbar bleiben; Farbcharakter und Warnwirkung bleiben erhalten.
- Keine fachliche Workeränderung; Worker nur versionssynchronisiert.

## v0.9.78.3

- GitHub-Installer-Run #841 gezielt korrigiert: TypeScript 7, Vite-Build, npm-Installation und Dependency-Audit waren bereits grün; ausschließlich zwei veraltete Regressionen blockierten den Release.
- `test-cockpit-hourly-climate-redundancy-09140.mjs` auf den verbindlichen v0.9.78.1-Nachfolgevertrag migriert: 7 Tage nutzen absolute ECMWF-Temperaturfarben ohne Klima-Delta, stündliche Temperaturen bleiben neutral, 14 Tage behalten signierte Tmin/Tmax-Klimadeltas.
- `test-ruc-pages-free-storage-09700.mjs` verlangt während des ZIP-Installers keine unzulässige Bytegleichheit mehr zwischen aktiver `.github/workflows/install-mid.yml` und der neu installierten kanonischen Kopie. Stattdessen wird der sichere Mindestvertrag der aktiven Pipeline geprüft; der bewusste `.github`-Self-Modification-Schutz bleibt damit erhalten.
- Keine fachliche App-, Forecast-, Wetterpiktogramm-, RUC- oder Workerlogikänderung.

## v0.9.78.2

- Installer-Hotfix für GitHub Release-Run #840: die im Release mitgeführte Spiegeldatei `workflow-patches/install-mid.yml` ist wieder bytegleich zur kanonischen Pipeline unter `ci/github/workflows/install-mid.yml`.
- Damit sind Race-Schutz auf `main`, Ausschluss der automatischen `.github`-Selbstmodifikation, serieller `mid-pages`-Lock ohne Cancellation sowie der gestufte Worker-/Pages-/Stable-Promote-Vertrag wieder konsistent regressionsgeschützt.
- Keine fachliche App-, Forecast- oder Workerlogikänderung; der Fix betrifft ausschließlich die mit dem Release transportierte Installer-Spiegeldatei und die Versionsfortschreibung auf v0.9.78.2.

## v0.9.78.1

- Weather Icon System 2.0 als echter appweiter Screenshot-3-Lock: Wetterglyphen standardmäßig standalone ohne eingebettete Sky-Plate; zusätzliche CSS-Sperre verhindert die Rückkehr alter quadratischer Piktogrammplatten.
- Tagespiktogramme in klassischer 7-Tage-Ansicht und Forecast Cockpit verwenden die kanonisch korrigierte Niederschlagsphase; Regenschauer, Regen, Schnee usw. können nicht mehr durch einen rohen cloud-only Stunden-Code dasselbe Symbol wie trockene Bedingungen erhalten.
- 7-Tage-Kurvenübersicht auf reale Stundenwerte umgestellt: gemeinsame 00/12-Zeitachse für Temperatur und Niederschlag, stündliche Niederschlagsbalken, horizontale Temperaturhilfslinien und geglättete Stundenkurve.
- 7-Tage-Temperaturen nutzen eine zentral interpolierte ECMWF-inspirierte Absoluttemperaturskala in Kurve, Tmin/Tmax und Rangebar; Klimaabweichungen/±K sind im 7-Tage-Modus entfernt. 14-Tage-Klimaanomalien bleiben bestehen.
- Piktogramm-, Farb- und Source-of-Truth-Verträge sowie Regressionen auf v0.9.78.1 erweitert. Keine fachliche Workeränderung.

## v0.9.78.0

- Verbindlicher appweiter Wetterpiktogramm-Standard 2.0: ein zentraler skalierbarer SVG-Renderer für Forecast-, Tages-, Stunden-, Event-, Reise-, Wasser-, Berg-, Routen-, Ensemble- und kompakte Widgetdarstellungen.
- Tag/Nacht und Hell/Dunkel zentralisiert; keine getrennten Rasterassets.
- Niederschlagsarten und -stärken nach WMO-/synoptischer Present-Weather-Logik erweitert: u. a. Sprühregen, gefrierender Sprühregen/Regen, Regen/Schauer, Schnee, Schneegriesel, Schneeschauer, Schneeregen, Eiskristalle, Eiskörner, Graupel, Hagel sowie Gewitter-/Hagelvarianten.
- Leicht/mäßig/stark wird über Dichte, Anzahl, Größe und Strichgewicht unterscheidbar, nicht nur über Farbe.
- SYNOP-/BUFR-/METAR-Brücke für dekodierte Present-Weather-Kürzel ergänzt; alter Forecast-Emoji-Hilfspfad entfernt.
- Keine fachliche Workeränderung; Worker nur versionssynchronisiert.

## v0.9.77.29

- Witterungstrend Tag 15–46 gegen hängende ERA5-Klimatologie entkoppelt: EC46/GEFS erhalten feste Quellbudgets, Klima ein separates Kurzbudget; vorhandene Modellwerte werden nicht mehr dauerhaft hinter „wird geladen …“ versteckt.
- Stale-Witterungsfallback auf 36 h erweitert.
- Langfristvertrag erweitert: numerische Ensemble-Mittel und geeignete deterministische Läufe dürfen wie EPS-Systeme beitragen; weiterhin exakt eine Stimme je unabhängiger Modelllinie. DWD Subseasonal EPISODES zählt als regionaler ECMWF-Downscaling-/Qualitätsanker, nicht als zweite EC46-Stimme.
- Neue responsive 7-Tage-Kurvenübersicht direkt oberhalb der Tageskarten: Wetterpiktogramme, Tmin/Tmax, geglätteter Temperaturverlauf, Niederschlagsbalken und direkte Tagesauswahl.
- Keine fachliche Workeränderung gegenüber v0.9.77.28; Worker nur versionssynchronisiert.

## v0.9.77.26

- Hotfix Langfristtrend: Saison-Rauchfahnen bleiben bereits bei einer numerisch verfügbaren Modellfamilie sichtbar; der reine Single-Model-Hinweiskasten ersetzt die Grafik nicht mehr.
- Bei einer Quelle zeigt MID deren echte Temperatur-/Niederschlags-Ensemble-Streuung; ab zwei Quellen wird automatisch wieder das gleichgewichtete Poor-Man’s-Ensemble plus gemeinsamer Einzelmodellvergleich verwendet.
- Fehlerursache war ausschließlich die Frontend-Gate-Logik aus v0.9.77.25; saisonale Workerquellen und Multi-Modell-Vertrag bleiben unverändert.
- Keine fachliche Workeränderung; Worker nur versionssynchronisiert.

## v0.9.77.25

- Witterungstrend Tag 15–46 bestätigt und regressionsgeschützt: Temperatur ist Standard, die letzte gültige Parameterauswahl wird dauerhaft gespeichert.
- Season auf ein transparentes Poor-Man’s-Ensemble umgestellt: alle tatsächlich numerisch verfügbaren unabhängigen Modellfamilien erhalten je eine Stimme; alle Einzelmodelle werden zusätzlich gemeinsam in einer skalierenden Grafik gezeigt.
- Nicht-numerische Katalog-/Status-/Zusatzmodellkästen und der redundante Einzelmodell-Kartenstreifen aus der Season-Hauptansicht entfernt.
- Tmin/Tmax in 7-/14-Tage wieder als kleine blaue/rote Kästchen; nichtlineare Klimamittelreaktion macht bereits kleine Abweichungen deutlich sichtbar.
- Keine fachliche Workeränderung; Worker nur versionssynchronisiert.

## v0.9.77.24

- KNMI-HARMONIE-EPS Abschnitt 4/4 kostenneutral bis zum reproduzierbaren ecCodes-Wasm32/MEMFS/Nearest-Point-Quellprototyp fortgeführt.
- Direkte In-Memory-GRIB1-ABI über `codes_handle_new_from_message_copy` und native `codes_grib_nearest_find`; kein Vollgittertransfer nach JavaScript.
- Forschungsbuild pinnt ecCodes 2.48.1, verzichtet auf wasm64/NODEFS, begrenzt Wasm auf 24 MiB initial / 96 MiB maximal und reserviert 2,5 MB gzip als fail-closed Bundlebudget.
- Keine npm-Wasm-Dependency, keine Queue, kein neues Cloudflare-Binding, kein Paid-Plan und keine fachliche Workeränderung. Reale P4a-Build-/CPU-/RAM-/Numerikverifikation bleibt offen.

## v0.9.77.23

- 24-h-Wertepillen am aktiven Auswahlcursor leicht transparent (`fill-opacity: .8`), damit darunterliegende Diagramminhalte sichtbar bleiben.
- Gesamtbewölkungs-Grauzellenzeile im 24-h-Profil durch exakt dieselbe Sonne-/Gesamtbewölkungs-Leiste wie in der Tagesansicht ersetzt.
- `detailSkyBarSegments` in `src/detailSkyBar.ts` zentralisiert; Tagesansicht und 24-h-Profil teilen Farben, vier Stärken sowie Tag-/Nacht-Semantik.
- H/M/L-Wolkenintensitätsbänder und gemeinsame `profileXForEpoch`-Zeitachse bleiben erhalten.
- Keine Worker-/Forecast-/KNMI-Fachlogikänderung.
- Abschnitt 4/4 bleibt fail-closed, erhält aber einen geprüften kostenfreien Forschungspfad: fokussierter ecCodes-Wasm32/MEMFS/Nearest-Point-Prototyp und optional asynchroner Cloudflare-Queues-Free-Consumer; in diesem Release werden weder Wasm-Dependency noch Queue/Ressource aktiviert.

## v0.9.77.22

- Dritter der vier verbleibenden KNMI-HARMONIE-EPS-Hauptabschnitte: externer GRIB1-Punktdecoder unter `tools/knmi_eps_decoder/`, strikt an das Worker-Rolling-Manifest und HTTP-206-Ranges gebunden.
- P4a-Rolling-Regen wird batchweise am ersten gemeinsamen Zeitpunkt baselined und in stündliche Mengen differenziert; Signed-URLs bleiben aus Logs und persistenten Caches heraus.
- KNMI-P4a-Europe-Metadaten auf 5,5 km und stündliche Aktualisierung korrigiert; höher aufgelöste 2–2,5-km-HARMONIE-Domänen bleiben davon getrennt.
- Kein Hosting/Cloudflare-Dienst/Workflow aktiviert; reale End-to-End-Aktivierung bleibt Abschnitt 4/4 und unterliegt der Kostenfreigabe.

## v0.9.77.21

- Installer #830 korrigiert: `test-api-contract-health-resilience-09778.mjs` erwartet nicht länger den alten generischen Namen „Hourly Min/Max Aggregation“, sondern den seit v0.9.77.20 tatsächlich geprüften Kernvertrag `ECMWF IFS native 3h Min/Max`.
- Die Regression schützt zusätzlich `models=ecmwf_ifs`, `forecast_hours=24` sowie `temperature_2m_min` und `temperature_2m_max`; damit wird der Healthcheck nicht durch bloßes Umbenennen grün.
- Keine fachliche Forecast-/Workeränderung gegenüber v0.9.77.20; Temperaturglättung und KNMI-HARMONIE-EPS-Produktivpfad bleiben unverändert.

## v0.9.77.20

- Installer #829 korrigiert: zwei veraltete String-/Einpunkt-Regressionen auf den bereits gültigen zentralen Current-/Radar-Endstufenvertrag migriert; Produktionslogik der v0.9.77.19-Temperaturglättung bleibt erhalten.
- Nächtliche Revision / Issue #28: `browserslist` auf den sicherheitskorrigierten 4.28.7-Pfad (plus kompatibles `baseline-browser-mapping`) angehoben; High-Audit GHSA-73wf-gq98-2v4g und GHSA-c83g-rgw3-j3cx beseitigt.
- Open-Meteo-Min/Max-Healthcheck an den dokumentierten ECMWF-IFS-3-h-Vertrag gebunden statt die nicht allgemein garantierten Best-Match-`hourly_6`-Min/Max zu erzwingen.
- KNMI-HARMONIE-EPS-/produktiver-Cache-/Workerstand aus v0.9.77.18/19 bleibt vollständig erhalten.

## v0.9.77.19

- Zweiter der vier verbleibenden Hauptabschnitte: KNMI HARMONIE EPS nutzt den produktiven TAR-Indexcache jetzt im Worker für sechs stündliche 5er-Batches, 30 Rolling-Member, 0–54-h-Alignment und exakte Sparse-Range-Manifeste; GRIB-Dekodierung bleibt außerhalb Cloudflare.
- Current-Temperatur wird mit dem echten standortlokalen Beobachtungszeitpunkt als weiche 120/180-min-Brücke in `displayHours` assimiliert statt einen einzelnen Stundenpunkt zu ersetzen; die sichtbare Delle in 24-h-Profil und Tagesansicht entfällt.
- GitHub Installer #828: veraltete Modularisierungsregression um `worker-src/05-knmi-eps-cache.js` ergänzt; TypeScript/Vite waren im fehlgeschlagenen Run bereits erfolgreich.
- Keine neue Cloudflare-Ressource und kein neuer Workflow; Worker-Fachänderung erfordert den regulären gestagten Worker-Deploy.

## v0.9.77.17

- Klimatische Tmin/Tmax-Abweichung wird ausschließlich über die **Zahlfarbe** sichtbar; Hintergrund und Rahmen der Werte bleiben neutral/transparent.
- Blaue Tmin- und rote Tmax-Zahlen behalten die signierte Klimasättigung, ohne farbige Pillen/Hinterlegungen zu erzeugen.
- 7-Tage-Legende und Parameter-Farbvertrag auf „Zahlfarbe = Abweichung vom jeweiligen Klimamittel“ präzisiert.
- Neuer Regressionstest schützt die reine Zahlfarben-Codierung appweit; keine fachliche Worker-Änderung.

## v0.9.77.16

- 24-h-Wert-Pills im Hell-/Dunkeldesign kontrastfest: definierte Meteogramm-Tooltipfarben statt ungültiger SVG-Hintergrundvariablen.
- Tmin/Tmax- und aktiver Temperaturmarker im 24-h-Wetterprofil deutlich verkleinert.
- Redundanten „Modellstand“ im Header des Witterungstrends entfernt; tatsächliche Läufe bleiben in den Modell-Pills, Datenabruf/Cache bleibt separat sichtbar.
- Langfristige Temperatur-/Niederschlags- und Schneelinien-Diagramme skalieren ohne horizontales Scrollen vollständig auf die verfügbare Breite.
- Keine fachliche Worker-Änderung; manueller Worker-Upload nicht erforderlich.

## v0.9.77.15

- Extremwetter-Popups nennen jetzt die konkrete Gefahr der dargestellten Fläche (z. B. „Gewitter“) statt generisch „Modellierte Gefahrenfläche“.
- Aktuelle und stündliche Temperaturwerte einschließlich „Nächste 90 Minuten“, Tagesdetail und ausgewähltem 24-h-Zeitwert werden neutral in der Theme-Textfarbe dargestellt.
- Tmin/Tmax in 7-/14-Tage-Ansichten verwenden ausschließlich Blau/Rot; die Sättigung folgt jetzt der signierten Abweichung vom jeweiligen klimatologischen Tmin/Tmax.
- Parameter-Farbvertrag und veraltete Regressionen auf die neue, im Anhang definierte Semantik migriert.
- Keine fachliche Worker-Änderung; manueller Worker-Upload nicht erforderlich.

## v0.9.77.14

- Regionale Modellwahl auf reale/konservative Modell-BBoxen vereinheitlicht: BBox gilt vor Länderkennung; grenzüberschreitende Nutzung innerhalb des Modellgebiets ist erlaubt.
- MeteoSwiss ICON-CH1/CH2 und GeoSphere AROME Austria können damit auch im abgedeckten angrenzenden Mitteleuropa als zusätzliche Wetterzwilling-Quellen einfließen, ohne die nationale Priorisierung zu verdrängen.
- App-Modellstandfilter für ALADIN CZ, AROME France/HD, KNMI HARMONIE NL, UKV, MET Nordic sowie HRRR/NAM/NBM an die Worker-Gebiete angeglichen.
- DMI HARMONIE AROME Europe konsistent auf 2 km und 2,5 Tage gestellt; UWC-West-Unabhängigkeitsgruppe bleibt mit KNMI gemeinsam.
- Neuer Regressionstest schützt Modellgebiete, grenzüberschreitende Fusion und Doppelgewichtung.

## v0.9.77.13

- Open-Meteo Rapid-Refresh/RUC-Quellenvertrag korrigiert: echter DWD ICON-D2-RUC bleibt ausschließlich direkt über die MID-DWD-Pipeline; nicht vorhandene Open-Meteo-RUC-Modellalias-Probes entfernt.
- Open-Meteo ICON-D2-15-min wird korrekt als 3-stündlich aktualisiertes Regionalmodell behandelt; HRRR-/AROME-15-min-Rapidpfade explizit geschützt.
- Neuer Regressionstest schützt Best-Match-`minutely_15`, direkte RUC-Frische und die Quellenabgrenzung.

# Changelog

## 0.9.77.12

- Appweiter Parameter-Farbvertrag auch in Tagesdetail/24-h vollständig durchgesetzt.
- Warnstufen färben Windpfeile; Tmin/Tmax-Töne bleiben Blau/Rot und werden klimatologisch nur in ihrer Intensität gewichtet.
- 24-h-Auswahlwerte an der blauen Zeitlinie als lesbare Parameter-Pills; stündliche Temperaturpunkte reduziert.


## v0.9.77.11 - 2026-09-01

- Trend 14d+: Klimareferenz von einem unvollständigen ERA5-Land-Gesamtabruf auf ERA5-Seamless 1991–2020 umgestellt; fachlicher ERA5-Land/ERA5-Fallback schützt Temperatur sowie Niederschlag, Luftdruck, Bewölkung und Wind.
- Appweiter Parameter-Farbvertrag verbindlich eingeführt und 24-h-Wetterprofil sowie 7-Tage-Tagesansichten auf die zentralen `--param-*`-Farben vereinheitlicht.
- Lokale absolute Temperaturfarbskalen und Klimaabweichungsfarben überschreiben tatsächliche Tmin/Tmax-/Temperaturwerte in den betroffenen Ansichten nicht mehr.

## v0.9.77.10 - 2026-09-01
- Install-/Deploy-Run #817: fünf TypeScript-Blocker im Berg-/Witterungstrend-Pfad behoben.
- Witterungstrend zeigt den tatsächlichen Open-Meteo-Modellinitialisierungsstand für EC46/GEFS; Datenabruf wird separat ausgewiesen.
- Kurzfristdiagramm zeigt an der blauen ausgewählten Zeitlinie Werte für Wolken, Temperatur/gefühlt/Taupunkt, Niederschlag, Wind/Böen und Luftdruck in Parameterfarben.

## v0.9.77.8 - 2026-09-01
- CI-Hotfix nach Installer #815: TypeScript und Vite waren bereits grün; 617/618 Regressionen bestanden. `test-extreme-rain-profile-night-097628.mjs` wurde vom veralteten Quelltext-Stringvertrag auf den aktuellen semantischen v0.9.77.8-Vertrag umgestellt: I-Schwelle + tatsächliches Modellsignal sowie identifier-unabhängiger RUC-Regenfallback. Produktionslogik unverändert.
- CI-Hotfix nach Installer #814: ungenutzter `height`-Parameter im Trend-14d+-Chart entfernt; TypeScript-`noUnusedParameters`-Gate wieder erfüllbar.
- Produktivprüfung nach Issue #27 gehärtet: kritische Kern-APIs bleiben fail-closed, regionale Météo-France-/JMA-Einzelmodellstörungen werden als Provider-Degradation statt als kompletter MID-Ausfall bewertet.
- JMA-Druckniveauprüfung auf den expliziten MSM-Profilpfad getrennt; GSM/Seamless werden nicht mehr pauschal an denselben Profilvertrag gekoppelt.
- Extremwetter I/P-Audit: Schwellenreferenz und tatsächliches Modellsignal werden getrennt dargestellt; P1–P4 bezeichnet ausdrücklich die Wahrscheinlichkeit der jeweiligen I-Stufe.
- Regen-/Schnee-Rollfenster sind periodengrenzenfest; Werte aus dem vorherigen Zeitraum können die nächste Periode nicht mehr hochstufen.
- ICON-D2-RUC-Extremwetterpfad auf Schema v3 erweitert: native 5/15-min-Diagnostik +0–6 h, stündlicher Zustandskern +6–12 h und +12–14 h; keine RUC-Unterstellung ab +14 h.
- Subthreshold-RUC-Werte erzeugen keine höhere I-Stufe mehr. Regen/Wind werden an realen I-Schwellen gegatet; Gewitter bleibt ingredient-basiert.
- C3S/Extremflächen-UI aktualisiert Schwellenreferenzen zusammen mit der dargestellten Konturintensität.
- PR #24/#25/#26 fachlich als erledigt identifiziert; GitHub-Connector verweigert das Schließen mit HTTP 403. #6/#18/#20/#21 bleiben bewusst zurückgestellt.
- Worker-Fachlogik und RUC-Payload geändert: Worker-Upload erforderlich.

## v0.9.77.7 - 2026-09-01
- Witterungstrend kombiniert Tmax/Tmin und bereinigt Klimamittel-/Farbkonzept sowie numerisch aktive Langfristmodellquellen.
- Keine fachliche Worker-Änderung.

## v0.9.77.6 - 2026-09-01
- GitHub-Installer Run #812 gefixt: exakt definierter RUC setup-python-v5→v7-Admin-Sync-Übergang wird als pending-admin-sync akzeptiert.
- Jede zusätzliche RUC-Workflow-Abweichung bleibt fail-closed.
- Neuer Regressionstest schützt den Pin-only-Übergang und lehnt kombinierte Drift ab.

# v0.9.77.5

- CI-Hotfix für GitHub Actions Run #811: ZIP-Entpacken, `npm ci` und Dependency-Audit waren grün; ausschließlich der TypeScript-Build des neuen Trend-14d+-Panels schlug fehl.
- `SubseasonalTrendPanel` verwendet wieder den kanonischen MID-`WindUnit` (`kn` intern, Anzeige weiterhin `kt`), wodurch die Übergabe aus `LongRangePanel` wieder typsicher ist.
- Nicht vorhandenes Lucide-Icon `Rain` durch `CloudRain` ersetzt; Tmin nutzt `Snowflake`, Windböen den bereits verwendeten Wind-Iconpfad.
- Lucide-Icon-Typisierung und die Nullability der Klimadifferenz wurden TypeScript-sicher korrigiert.
- Tmin/Tmax, Windböen, EC46-Klimamittel-Zeitachsenfix und Punkt-Tooltips aus v0.9.77.4 bleiben vollständig erhalten.
- Keine fachliche Worker-Änderung; manueller Worker-Upload nicht erforderlich.

# Changelog

## v0.9.77.4 - 2026-09-01
- Witterungstrend Tag 15-46 fachlich nachgeschärft: EC46-Klimamittel werden jetzt über die Wochen-Zeitachse statt über starre Indexe zugeordnet, damit Teilwochen und Endbereiche konsistent bleiben.
- Temperatur-Slot in der Subseasonal-Ansicht in Tmax und Tmin aufgeteilt; Wind um Windböen erweitert, jeweils mit dem appweiten Farbkonzept.
- Hauptdiagramm des Witterungstrends um Klick-/Tipp-Tooltips pro Kurvenpunkt ergänzt, analog zum 24d-Ensemble.
- Wind- und Böenwerte im Witterungstrend auf kn-basierte API-Abfrage vereinheitlicht, damit die Einheiten appweit konsistent bleiben.
- Release-Upload-Budget erneut geprüft; Professional- und Worker-ZIP bleiben innerhalb des vorgesehenen Größenrahmens.

# v0.9.77.3

- RUC-Infrastrukturwartung separat durchgeführt: Dependabot-PR #26 MID-konform übernommen; `actions/setup-python` ist im kanonischen RUC-Workflow und im administrativen Sync auf 7.0.0 / SHA `5fda3b95a4ea91299a34e894583c3862153e4b97` angehoben.
- Python 3.12, pip-Cache, RUC-Scheduler :11/:41, Guard, Pages-Storage und meteorologische RUC-Fachlogik bleiben unverändert.
- Neuer fokussierter PR-Wartungstest schützt #25/#24/#26 gemeinsam und hält React 19, React DOM 19, react-is 19 sowie plugin-react 6 ausdrücklich zurückgestellt.
- Keine fachliche Worker-Änderung; Worker-Upload nicht erforderlich.

# v0.9.77.2

- GitHub-Actions-Wartung: Dependabot-PR #25 MID-konform übernommen; `actions/upload-artifact` ist kanonisch auf 7.0.1 / SHA `043fb46d1a93c77aae656e7c1c64a875d1fc6a0a` angehoben.
- CodeQL-PR #24 korrigiert übernommen: `init` und `analyze` werden gemeinsam auf 4.37.9 / SHA `cdf488f595d80d6e07e03d4674febd5ab45fa938` gepinnt; der im Original-PR entstandene Versionsmix ist ausgeschlossen.
- Expliziter Workflow-Sync und Regressionen schützen nun auch `upload-artifact`; `.github` bleibt im normalen Release-Installer unverändert.
- React-19- und plugin-react-6-Majors bleiben bewusst zurückgestellt.
- Keine fachliche Worker-Änderung; Worker-Upload nicht erforderlich.

# v0.9.76.35

- P0 Gewittersemantik: Blitznachweis klassifiziert weiterhin den **aktuellen Radar-/KONRAD3D-Zustand**, ist aber keine Voraussetzung mehr für eine numerische Gewitterprognose.
- ICON-D2-RUC: Der alte numerische Blitz-Gate wurde entfernt; RUC-/RUC-EPS-Kalibrierung darf bestehende WMO-Gewittercodes nicht mehr zu Schauercodes herabstufen.
- ICON-D2-RUC Rapid: neue ingredient-basierte Mehrparameterdiagnostik aus CAPE/MU-CAPE, CIN/MU-CIN, 5-/15-min-Niederschlag, modellierter Reflektivität, LPI, UH, EchoTop und Aufwind. Kein einzelnes Rapid-Feld allein erzeugt einen synthetischen Gewittercode.
- 15-min-Prognose: hinreichend stark und mehrfach gestützte Rapid-Konvektion darf prognostisch WMO 95 erzeugen; 96/97/99 werden nicht heuristisch erfunden.
- Gewitterinformation: numerische Gewitterprognosen bleiben auch ohne Rapid-Daten möglich. Eine blitzlose aktuelle K3D-Zelle bleibt zugleich korrekt als starke Schauerzelle bezeichnet; numerische Gewitterentwicklung wird davon getrennt dargestellt.
- Worker-Fachlogik geändert; aktualisierter Worker ist erforderlich.

# v0.9.76.34

- CI-Hotfix für GitHub-Run #805: Sechs veraltete Regressionserwartungen wurden an den bereits freigegebenen 24-h-Profilvertrag aus v0.9.76.33 angepasst.
- Die Tests erwarten jetzt die neue Wetterpiktogramm-Höhe `y=78`, die nach oben verlegten Wolkenbänder (`cloudTop=101`), den darunter liegenden Temperaturbereich (`tempTop=150`), die verschobene Luftdruckspur (`498–550`) sowie die dünnere Temperaturkurve (`2.75`).
- Produktcode und fachliche Wetterlogik bleiben unverändert; kein Rollback der neuen Wolkenanordnung oder des 23→00-Uhr-Fixes.
- Keine fachliche Worker-Änderung.

# v0.9.76.33

- Tagesdetail-Stundennavigation: Der Schritt von 23:00 Uhr springt beim Weiterklicken nun korrekt auf 00:00 Uhr des Folgetags statt auf den 12-Uhr-Fallback. Die gewünschte Zieluhrzeit bleibt dabei so lange vorgemerkt, bis der neue Tag tatsächlich den passenden Zeitslot ausgewählt hat.
- 24-h-Wetterprofil: Die Wolkenbänder (Gesamt/H/M/L) sitzen jetzt direkt unter den Wetter-Piktogrammen und damit vor dem Temperaturbereich.
- 24-h-Wetterprofil: Temperatur- und gefühlte Temperaturkurve wurden bewusst etwas dünner ausgeführt, um den oberen Profilbereich ruhiger und präziser wirken zu lassen.
- Keine fachliche Worker-Änderung; nur Versionssynchronisierung des gekoppelten Notfall-/Audit-Artefakts. Ein neuer manueller Worker-Upload ist nicht erforderlich.

# v0.9.76.32

- Release-Gate-Sicherung für die v0.9.76.31-Korrekturen ergänzt.
- Reiseplaner-Vertrag schützt nun explizit den aktuell ausgewählten MID-Ort als Standardziel und verhindert die Wiederkehr eines alten persistenten Reiseziels als Startwert.
- Komposit-Vertrag schützt den robusten Boundary-Fallback sowie numerische/stringbasierte `admin_level`-/`maritime`-Werte, damit oberhalb des Wetterbilds nicht nur Städte, sondern auch Grenzen sichtbar bleiben.
- Keine fachliche Worker-Änderung; kein neuer manueller Worker-Upload erforderlich.

# v0.9.76.31

- Reiseplaner: Das ausgewählte Ziel startet standardmäßig wieder mit dem aktuell gewählten MID-Ort. Ein zuvor lokal gespeichertes Reiseziel überschreibt den Startzustand nicht mehr ungewollt.
- Reiseplaner: Solange kein alternatives Reiseziel gewählt wurde, bleibt die Zielkarte automatisch mit dem aktuellen MID-Ort synchron.
- Kompositbild: Der obere Referenzlayer zeichnet Grenzen robuster. Zusätzlich zum hervorgehobenen Länder-/Regionsrahmen wird ein allgemeiner Boundary-Fallback eingeblendet, und `admin_level`/`maritime` werden sowohl numerisch als auch als String akzeptiert.
- Keine fachliche Worker-Änderung; ein neuer Worker-Upload ist für diese Korrektur nicht erforderlich.

# v0.9.76.30

- CI-Hotfix: Zwei veraltete 24-h-Wetterprofil-Regressionen wurden an den seit v0.9.76.28 gültigen Nacht-Fade-Vertrag angepasst.
- Geschützt bleiben eine einzige 24/00-Uhr-Tagesgrenze sowie der dezente Nacht-Hintergrund mit weichem Fade an Sonnenuntergang und Sonnenaufgang; die frühere Schraffur wird nicht wieder eingeführt.
- Keine fachliche oder sichtbare Rücknahme der v0.9.76.28/29-Änderungen.

# v0.9.76.29

- Release-Gate-Hotfix nach GitHub-Actions-Run #801: TypeScript, Vite-Build und 604 von 605 Regressionen waren grün; ausschließlich `test-thunder-affected-places-route-09151.mjs` erwartete noch den vor v0.9.76.26 verwendeten Text `+{hidden} weitere im (i)`.
- Der historische Gewitter-Orts-/Zugbahntest schützt nun den aktuellen Vertrag: sichtbarer Restzähler, Rest-Pille und `Weitere Orte anzeigen (...)`-Disclosure bei unverändert vollständiger Now/likely/possible/corridor-Fachlogik.
- Kein Rollback der verdichteten mobilen Gewitterdarstellung. Die Extremregen-, Geländehöhen- und 24-h-Nachtprofil-Korrekturen aus v0.9.76.28 bleiben vollständig enthalten.
- Fachlicher Worker-Diff aus v0.9.76.28 bleibt enthalten; aktualisierter Worker ist weiterhin erforderlich.

# v0.9.76.28

- Extremwetter-Ausblick: Bei Regenlagen im 0–6-h-Fenster übernehmen Regionsliste und Detailkarte nun bevorzugt die verfügbare ICON-D2-RUC-Akkumulation, sodass irreführende `0 mm`-Anzeigen trotz vorhandener Rapid-Signale entfallen.
- Extremwetter-Details: Geländehöhen werden lesbarer auf 10 m bzw. 100 m gerundet.
- 24-h-Wetterprofil: Es wird nur noch eine einzige senkrechte Tagesgrenze für 24/00 Uhr gezeichnet; zusätzliche hervorgehobene Vollhöhenlinien entfallen.
- 24-h-Wetterprofil: Nachtstunden erhalten einen dezenten Hintergrund mit weichem Fade an Sonnenuntergang und Sonnenaufgang statt der bisherigen harten Schraffur.
- Fachliche Worker-Änderung enthalten; ein aktualisierter Worker-Upload ist erforderlich.

# v0.9.76.25

- CI-Hotfix nach Release-Run #799: TypeScript 7.0.2, Vite 6.4.3, Dependency-Audit und 602 von 603 Regressionen waren grün; ausschließlich der historische RUC-Watchdog-Test erwartete noch zwei getrennte `:18/:48`-Cron-Einträge.
- Der bestehende Watchdog-Test schützt nun die fachlich bereits aktive Scheduler-Resilienz: eine sechsfach gestaffelte `:08/:18/:28/:38/:48/:58`-Cron-Expression, Active-Run-Sperre, 18-Minuten-Cooldown, `force=false`, `trigger_source=github-watchdog` und Push-Self-Test.
- Primärer RUC-Vertrag `:11/:41` unverändert; GitHub-Watchdog bleibt ausdrücklich same-provider. Der optionale Cloudflare-Cron-Watchdog bleibt nur quellseitig vorbereitet.
- Kein Produktcode-Rollback und keine fachliche Worker-Änderung; manueller Worker-Upload bleibt unnötig.

# v0.9.76.22

- CI-Vertragshotfix nach Release-Run #795: TypeScript 7.0.2, Vite 6.4.3 und Dependency-Audit waren bereits grün; vier veraltete Regressionserwartungen wurden an die bewusst freigegebenen v0.9.76.21-Verträge angepasst.
- Wolkenprofil-Tests schützen nun die kollisionsfreie `cloudCellGeometry` statt frühere randberührende/überlappende Rechteckmaße zu verlangen.
- Szenariocluster-Test schützt die Resume-Recovery, bei der eine transiente leere Teilantwort den letzten erfolgreichen Ensemble-Stand nicht mehr löscht.
- Pages-/Installer-Test schützt jetzt den neuen `MID / release-candidate-quality`-Status, die Vorfahrprüfung und die ausschließlich Fast-Forward erfolgende Stable-Promotion ohne Force-Push.
- Kein Produktcode-Rollback und keine fachliche Worker-Änderung. Die UI-/Budget-/Stable-Härtung aus v0.9.76.21 bleibt vollständig erhalten.

# v0.9.76.21

- Parallelkonsolidierung ohne Rollback: die separat auf v0.9.76.20 erstellten UI-Änderungen werden unter der eindeutigen nächsten Releaseversion übernommen. Das 24-h-Wetterprofil nutzt echte Zellzwischenräume, einheitliche Achsenwert-Abstände und eine dünnere Temperaturkurve; der DWD-Ortsausschnitt zeigt nur noch die kompakte Stecknadel, und Tages-/Stunden-Windpfeile übernehmen die appweiten DWD-Böenwarnfarben.
- Auto-Revision/Build-Budget: komprimierbarer Webcode und bereits komprimierte statische Medien werden getrennt budgetiert. 5,2 MB Code/Text-gzip, 7,0 MB statische Medien und 8,5 MB Gesamt-gzip bilden getrennte Sicherheitsnetze.
- Stable-Härtung: der kanonische Installer setzt nach Build/Audit/Regressionen/Worker-Gate/Pages zuerst `MID / release-candidate-quality` und promotet anschließend ausschließlich per Fast-Forward ohne Force-Push nach `mid-stable`; divergierende Historien brechen fail-closed ab.
- Startperformance: der Boot-Logo-Preload erhält seinen `href` erst nach synchroner Theme-/Logoauflösung und lädt damit nicht unnötig zuerst die Light-Variante.
- Regression: der Parallel-UI-Test bleibt vollständig erhalten und wird mit den drei Budget-/Stable-Hardening-Tests gemeinsam geschützt. Keine fachliche Worker-Änderung; nur Versionssynchronisierung, daher kein manueller Worker-Upload erforderlich.

# v0.9.76.20

- CI-Hotfix nach Install-Run #793: drei veraltete Regressionserwartungen wurden auf den bereits erfolgreich mit TypeScript 7.0.2 und Vite 6.4.3 gebauten Produktvertrag migriert.
- Wolkenprofil-Regressionen schützen nun ausdrücklich die nicht überlappenden Gesamt/H/M/L-Zellen (`x = columnLeft + 0,7`, `width = columnWidth - 1,4`) statt die frühere überlappende Geometrie zu verlangen.
- Szenariocluster-Regression schützt jetzt den Resume-Recovery-Vertrag: eine transiente Teilantwort darf vorhandene Ensemble-Szenarien nicht mit einem leeren Array überschreiben.
- Kein Produktcode-Rollback, keine fachliche Worker-Änderung. Der Ensemble-Resume-Fix und die 24-h-/DWD-UI-Finalisierung aus v0.9.76.19 bleiben vollständig erhalten.

# v0.9.76.19

- 14-Tage-Ensemble: same-location Resume/Reload startet Ensemble-Daten zuverlässig neu; der bisherige Lebenszyklusfehler, bei dem der Ensemble-State geleert und der Request nicht erneut ausgelöst wurde, ist behoben.
- Letzter erfolgreicher Ensemble-Stand bleibt bei transienten Fehlern sichtbar; bei sichtbarer Online-App folgt nach 45 s automatisch ein neuer Versuch.
- 24-h-Profil-Finalisierung: Nacht-Schraffur wieder sichtbar, rote Jetzt-Linie/„JETZT“ entfernt, gewählte Uhrzeit an der blauen Auswahlachse, kein „gleitend ab …“, keine überlappenden Thermik-/Wolken-/Hazard-Zellen.
- DWD Wolken/Niederschlagsart: dünnere Stecknadel als Ortsmarker. Kein fachlicher Worker-Upload erforderlich.

# v0.9.76.18

- CI-Hotfix: zwei überholte 24-h-Wetterprofil-Regressionen an den bereits produktiv gültigen kompakten Profilvertrag angepasst (vollzählige Stundenpiktogramme, aktuelle SVG-Position und responsive 2/4/8-px-Dateninsets).
- Kein Rückbau des neuen 24-h-Layouts und keine fachliche Worker-Änderung.

# v0.9.76.17

- DWD „Wolken + Niederschlagsart“: Zentrierung des standortbezogenen Originalbild-Ausschnitts nach Zoomwechsel robuster gemacht, indem der Ortsmittelpunkt nach Layout-/Scroll-Updates mehrfach nachgeführt wird. Bei höheren Zoomstufen bleibt der Zielort damit deutlich zuverlässiger im Fokus.
- DWD-Ortsmarker optisch entschärft (kleiner, transparenter) und die fest eingebettete Originallegende weiter verkleinert, damit weniger Bildinhalt verdeckt wird.
- 24-h-Wetterprofil: obere Zeitmarker näher an die Zeitachse gerückt, linke/rechte Diagrammränder weiter verdichtet und die Lane „Therm. Empfinden“ zweizeilig ausgeführt, sodass die Nutzbreite insbesondere mobil besser ausgenutzt wird.
- Achsenpolitur im 24-h-Profil: Niederschlags-, Wind- und Luftdruck-Skalen erhalten mehr Abstand zur Achse; Wetterpiktogramme werden nun vollständig, etwas kleiner und mit besserer Konturierung dargestellt.
- Nachtstunden im 24-h-Profil werden jetzt als zusammenhängende, hellere Flächen statt unruhiger Streifen hervorgehoben; gemeinsamer Browser/PWA/iOS-Fachkern bleibt erhalten. Keine fachliche Worker-Änderung und kein manueller Worker-Upload erforderlich.

# v0.9.76.16

- Lucide React 1.34.0 → 1.35.0 nach isoliertem Dependabot-Kandidatenlauf; TypeScript/Vite und CodeQL waren grün.
- Zwei historische Versionspin-Regressionen auf den qualifizierten Lucide-Stand aktualisiert; neue Regression schützt den isolierten Wartungsschritt.
- React 18.3.1, Vite 6.4.3 und plugin-react 4.7.0 bleiben unverändert; keine funktionale Wetter-, UI-, Karten-, Worker- oder iOS-Änderung.

# v0.9.76.15

- MapLibre GL JS 6.6.0 qualifiziert und übernommen; die bisherigen 6.5.0-Pin-Regressionen folgen dem neuen reproduzierbaren Vertrag.
- `uuid@7.0.3` als transitiver Dev-/iOS-Tooling-Pfad `@capacitor/cli -> xcode -> uuid` dokumentiert und gegen riskante Overrides geschützt.
- `MID_BRANCH_RULESET.json` als konkrete Stable-Schutzvorlage mit `MID CI verify`, Release-Evidenzstatus und gezieltem Workflow-Bypass gehärtet.
- Keine fachliche Wetter-, Karten-, Radar-, Worker-, React- oder Vite-Major-Änderung.

## v0.9.76.14

- CI-Hotfix nach Run #788: drei historische 24-h-Profil-Regressionen auf den bereits fachlich freigegebenen, kompakteren v0.9.76.13-Achsenvertrag migriert; kein Produktcode-Rollback.
- Die Tests erwarten nun die reduzierten mobilen Seitenränder, die vereinfachte obere Zeitachse ohne dominante Kalenderzeile, kompakte Tageswechselmarker sowie den aktuellen `major`-/`profile-bottom-date`-Vertrag.
- TypeScript 7.0.2 und Vite 6.4.3 waren in #788 bereits vollständig grün; DWD-Ortsausschnitt, Originalpixel-Auswertung und 24-h-Profil-Feinschliff bleiben unverändert erhalten.
- Gemeinsamer Browser/PWA/iOS-Fachkern bleibt erhalten; keine Worker-Fachänderung.

## v0.9.76.13

- Buildfix für den einzigen Fehler aus GitHub-Release #787: nach Entfernung der redundanten 24-h-Zeitpille verblieb `profileWindowEndLabel` als unbenutzte Konstante und wurde von TypeScript 7 mit TS6133 abgewiesen.
- Die Konstante ist entfernt und die zugehörige 24-h-Profil-Regression schützt den Fehler künftig explizit. Die in v0.9.76.12 zusammengeführten DWD-Ortsausschnitt- und 24-h-Profiländerungen bleiben vollständig erhalten.
- Keine funktionale Worker-Änderung.

## v0.9.76.12

- Konsolidiert die beiden nahezu zeitgleich auf v0.9.76.10 entstandenen v0.9.76.11-Linien ohne Rollback: der DWD-Ortsausschnitt mit Originallegende/Originalpixel-Auswertung und der mobile Feinschliff des 24-h-Wetterprofils sind gemeinsam enthalten.
- 24-h-Profil: redundante Zeit-Pille entfernt, linke/rechte Diagrammränder deutlich verdichtet, Achsen-/Einheiten-/Wolkenbeschriftungen gegen Überdeckung gehärtet, Nachtstunden weniger dominant und obere/untere Zeitachse auf eine sparsame gemeinsame Struktur reduziert.
- DWD „Wolken + Niederschlagsart“: standortzentrierter Deutschland-Ausschnitt, feste Originallegende, Originalpixel-Klickauswertung, Georeferenzierungs-/Randtests und zugehörige UI-Geometrie aus dem hochgeladenen parallelen v0.9.76.11-Stand bleiben vollständig erhalten.
- Gemeinsamer Browser/PWA/iOS-Fachkern bleibt erhalten; keine Worker-Fachänderung und kein manueller Worker-Upload erforderlich.

## v0.9.76.11

- „Wolken + Niederschlagsart“ startet für deutsche Standorte und Favoriten als standortzentrierter, verschieb- und zoombarer Ausschnitt des unveränderten amtlichen DWD-Originalbilds.
- Standortmarker und freie Bildklicks bleiben an den normierten Originalpixeln des vollständigen DWD-PNG gebunden. Die reine Ansichtsabbildung wurde an 17 sichtbaren DWD-Stadtankern sowie fünf deutschen Randorten geprüft und erzeugt keinen Kartenlayer.
- Die im amtlichen DWD-Bild eingebettete Originallegende bleibt fest am Ausschnitt sichtbar und stammt aus derselben Bildantwort. Reisewetter v0.9.76.9 und das modernisierte 24-h-Wetterprofil v0.9.76.10 bleiben vollständig erhalten.
- Keine Änderung an Worker-Fachlogik oder iOS-Architektur; kein manueller Worker-Upload erforderlich.

## v0.9.76.10

- 24-h-Wetterprofil grafisch nach dem klareren Prinzip der Tagesansicht neu geordnet: rollend von jetzt bis +24 h, alle Parameter exakt auf denselben senkrechten Zeitschritten und ohne mobile Verkleinerung eines künstlich überbreiten Diagramms.
- Windbereich ergänzt um die appweit identischen DWD-Böenwarnschwellen mit dezenten Warnbändern/-linien; die Windskala zeigt mindestens die erste Warnschwelle.
- Nachtstunden werden über alle Bahnen gemeinsam abgedunkelt; Sonnenaufgang und Sonnenuntergang stehen dezent an ihrer exakten Zeitposition. Einheitliche Parameter-/Einheitenspalte, sparsamere Skalen und eine zweite kompakte Zeitreferenz am unteren Rand verbessern die vertikale Lesbarkeit.
- Gemeinsamer Browser/PWA/iOS-Fachkern bleibt erhalten; keine Worker-Fachänderung.

## v0.9.76.9

- Reisewetter/Fester Zeitraum: historische modellierte ERA5-Schneehöhe wird jetzt immer mit ausgewertet; Schneefall bleibt getrennte Zusatzinformation und wird bei einem Schneehöhen-Ausfall nicht als Ersatzwert ausgegeben.
- Wunschzeitraum: Alternative Reisezeiträume werden nicht mehr in nahezu identische, tageweise verschobene Fenster verdichtet. Neuer editierbarer Mindestabstand; Standard = Reisedauer, Untergrenze = 50 % der Reisedauer.
- Bei 7 Tagen Reisedauer beträgt der Standardabstand damit 7 Tage; der Nutzer kann ihn bis minimal 4 Tage korrigieren. Browser/PWA/iOS teilen weiterhin denselben Fachkern; keine Worker-Fachänderung.

## v0.9.76.7

- Kurzfristtexte sprachlich geglättet: relative Uhrzeiten werden satzgrammatisch statt durch bloßes Voranstellen einer Präposition erzeugt. Dadurch heißt es z. B. „morgen um 19:00 Uhr“ und „morgen ab 14:00 Uhr“ statt „um morgen 19:00“ bzw. „ab morgen 14:00“.
- Derselbe Zeitphrasen-Helfer gilt für trockene, Niederschlags- und Böen-Zusammenfassungen im Prognose-Cockpit; Tagesbezug und „Uhr“ bleiben auch für übermorgen bzw. spätere Tage eindeutig.
- Keine Änderung an Forecast-Daten, RUC-Fusion, Worker-Fachlogik oder iOS-Architektur.

## v0.9.76.5

- Modellstände: Best Match wird nicht mehr irreführend mit `Init –` dargestellt, sondern als modellabhängiger Laufverbund. Bei tatsächlich verwendeten Quellen ohne publizierten Init-Zeitstempel steht explizit „von Quelle nicht ausgewiesen“; bekannte Einzelmodell-Inits bleiben in UTC erhalten.
- 24-h-Wetterprofil: Maximum und Minimum werden robust aus der vollständigen kanonischen stündlichen 24-h-Temperaturkurve bestimmt und immer am tatsächlichen Kurvenpunkt markiert. Sichtbar steht nur noch der Wert (`21°`, `15°`) ohne `Tmax`/`Tmin`-Präfix; der 3-h-Modus verliert die Extrema nicht.
- Reisewetter „Hohe Schneelage“: Optimierung basiert zwingend auf historischer Schneehöhe und Schneedeckendauer. Kumulierter Schneefall ist nur noch Zusatzinformation und ersetzt die Schneehöhe bei einem Quellfehler nicht. Die Schneelage-Kachel zeigt primär Ø Schneehöhe und zusätzlich die Schneefallsumme.
- Langfrist: kostenneutraler Ausbaupfad für C3S-CDS, DWD GCFS2.2/EPISODES, NOAA NMME und eine getrennte Extended-Range-Ebene dokumentiert; keine zusätzlichen kostenpflichtigen Dienste aktiviert.

## 0.9.76.4
- CI/iOS-Status: `MID_IOS_STATUS.json.releaseVersion` wird bei Versionsänderungen nun idempotent durch `sync-version.mjs` mitgeführt; damit kann ein Patch-Bump die iOS-Strukturregressionen nicht mehr durch veraltete Release-Metadaten blockieren.
- Release #778 bestätigte bereits TypeScript 7.0.2 und Vite 6.4.3; der Patch ändert keinen Forecast-, RUC-, Worker-, 24-h-, Modellstand- oder Komposit-Fachcode.

## 0.9.76.3

- Mitigiert die fünf verbliebenen Regression-Gate-Fehler aus GitHub-Run #777, nachdem TypeScript 7.0.2 und Vite bereits vollständig grün waren.
- Akzeptiert im RUC-Sync-Vertrag ausschließlich den real aktiven, bekannten `:11/:41`-Pre-Watchdog-Zwischenstand; unbekannte Workflow-Drift bleibt fail-closed.
- Entkoppelt den TypeScript-7-Meilensteintest von einer hart codierten Patchversion und hält Compiler/Lockfile/Strada-Vertrag weiterhin exakt.
- Entfernt die veraltete SEO-Erwartung eines sichtbaren `kostenlos`-Hinweises; Discoverability bleibt unverändert geschützt.

## v0.9.76.1

## 0.9.76.2

- Behebt die vier im realen GitHub-TypeScript-7-Gate von Release #776 gefundenen Strict-Compilerfehler.
- Korrigiert die `timezone`-Übergabe im Modellstand der ForecastCockpit-Ansicht.
- Entfernt drei nach den UI-/Diagnosebereinigungen ungenutzte TypeScript-Symbole, ohne Fachlogik zu verändern.
- TypeScript bleibt 7.0.2; die TS7-/Capacitor-JSON-Migration aus v0.9.76.1 bleibt vollständig bestehen.

- Kanonische Tmin-/Tmax-Konsistenz appweit geschlossen: vollständig abgedeckte Tage beziehen ihre Extrema aus `displayHours`; im 24-h-Profil stehen `Tmin` und `Tmax` wieder direkt an den tatsächlichen Punkten der T-Kurve, auch bei 3-h-Anzeigedichte.
- Modellstände fachlich präzisiert: `Init`, `Quelle bereit` und `Eingeflossen` sind getrennte Zustände; nur tatsächlich in der kanonischen Forecast-Fusion verwendete Quellen erhalten `Eingeflossen`. Dieselbe Transparenz wird auch für die Kurzfristvorhersage bereitgestellt.
- Sichtbare Entwicklungs-/Hosting-/Kosteninterna aus Produkttexten entfernt, ohne interne Architektur-, Kosten- oder Deploymentverträge anzutasten.
- Kompositbild repariert: oberster Referenzlayer ist transparent und vektorbasiert und zeichnet nur Grenzen/Orte über das weiterhin sichtbare Satellitenbild.
- RUC-Resilienz erweitert: Primärslots `:11`/`:41` bleiben bestehen; kanonischer `force=false`-Recovery-Dispatch und unabhängiger Watchdog sind für den expliziten GitHub-Workflow-Sync vorbereitet.
- TypeScript bleibt exakt 7.0.2; den unter Node 22.16 gescheiterten Capacitor-Konfigurationspfad beseitigt, indem die äquivalente reine Metakonfiguration von `capacitor.config.ts` nach `capacitor.config.json` verschoben wurde. Kein TypeScript-Downgrade und kein iOS-Fork.
- Worker-Metadaten zur tatsächlichen Modellnutzung sind semantisch geändert; der bestehende semantische Release-Gate soll den automatischen Worker-Deploy auslösen. Kein manueller Worker-Upload vorgesehen.

## v0.9.76.0

- Eigenständigen TypeScript-7-Kompatibilitätsmeilenstein abgeschlossen: Compiler und Lockfile von 5.9.3 auf exakt 7.0.2 angehoben.
- App- und Node-Typecheck bleiben artefaktfrei und bestehen ohne fachliche Quellcode- oder `tsconfig`-Änderung; React/React DOM/react-is 18.3.1, Vite 6.4.3 und @vitejs/plugin-react 4.7.0 bleiben bewusst unverändert.
- Die von TypeScript 7 entfernte Strada-JavaScript-Compiler-API wird für API-basierte Regressionen über den offiziell vorgesehenen Side-by-side-Alias `typescript-strada` 6.0.3 bereitgestellt; Produkt-Typecheck und alle `tsc`-Aufrufe bleiben ausschließlich auf 7.0.2.
- Dependency-Policy und historische Wartungswächter auf den qualifizierten TypeScript-7-Stable-Vertrag umgestellt; neue Required Regression schützt Compiler-/Lockfile-Stand, No-Emit-Konfiguration, Plattformgleichlauf und die Abgrenzung zu React 19/Vite 8/plugin-react 6.
- Gemeinsamer Browser/PWA/iOS-Fachkern und Worker-Semantik unverändert; kein iOS-Fork und kein manueller Worker-Upload erforderlich.

## v0.9.75.0

- 24-h-Wetterprofil auf eine verbindliche gemeinsame Zeitgeometrie umgestellt: Wetterpiktogramme, Stundenraster, Sonnenereignisse, Kurven, Windpfeile, Wolken, Hazards und Auswahlcursor stehen jetzt senkrecht exakt übereinander.
- Bewölkung als vier schmale, kontinuierlich ein-/ausfadende Grauintensitätsbänder in der Reihenfolge Gesamt/H/M/L umgesetzt. Rechte Wolken-Prozentbeschriftung entfernt; exakte Werte bleiben in Tooltips und Einzeldaten erhalten.
- Luftdruckbahn vergrößert und Kurve in Hell-/Dunkelmodus deutlich kontrastreicher ausgeführt; responsive Hochformat- und Querformat-Master-/Detailansicht bleibt erhalten.
- Grundlage ist der verbindliche letzte Build-Stand v0.9.74.10 einschließlich PNG-Integritäts- und 24-MB-Uploadbudget-Verträgen. Gemeinsamer Browser/PWA/iOS-Fachkern, keine Worker-Fachänderung und kein manueller Worker-Upload erforderlich.

## v0.9.74.10

- RUC-/Release-Pages-Collision behoben: alle drei Release-Pages-Jobs teilen `mid-pages` nun mit `cancel-in-progress: false`; laufende RUC-Publikationen werden dadurch nicht mehr von einem Release abgebrochen. Release-Supersession auf `mid-install-${{ github.ref }}` bleibt bewusst aktiv.
- RUC-Resilienz unverändert: versetzte `:11`-/`:41`-Schedule-Slots plus Freshness-/Catch-up-Guard; ein von GitHub verworfener best-effort-Schedule-Event kann weiterhin erst durch den nächsten Slot aufgefangen werden.
- GitHub-Browser-Upload wieder ermöglicht: native Light-/Dark-Splashscreens auf je eine vollständige 2732×2732-Asset-Catalog-Quelle dedupliziert und reproduzierbaren Professional-Packer ergänzt. Generiertes `ios/App/App/public` wird nicht transportiert, sondern im Installer nach grünem Build via `cap copy ios` neu erzeugt.
- Professional-Packer erzwingt 24.000.000 Byte Sicherheitsbudget; Forecast-/Worker-/RUC-Fachlogik und Apple-Capabilities unverändert, kein manueller Worker-Upload erforderlich.

## v0.9.74.9

- iOS-Light-Splash-Hotfix: alle drei zuvor abgeschnittenen `2732 × 2732`-PNG-Dateien aus dem verbindlichen Light-Splash-Asset vollständig neu erzeugt.
- Neuer echter PNG-Integritätsvertrag prüft Signatur, Chunkgrenzen, CRC, IEND und IDAT-Dekompression für native Light-/Dark-Splashscreens und App-Icons; reine IHDR-Abmessungsprüfungen reichen nicht mehr aus.
- Keine fachliche Worker-, RUC-, Forecast-, PWA- oder Apple-Capability-Änderung; nächstes Gate bleibt die macOS-/Xcode-Simulator-Qualitätssicherung.

## v0.9.74.8

- Verbindliche Light-/Dark-Logo-Sets für Header, Web-Bootscreen, Favicons, Social Card, PWA-Icons sowie native iOS-App-Icons und Splashscreens eingeführt; Auto folgt dem wirksamen Theme, manuelle Auswahl bleibt persistent.
- Einsatzspezifische Kompakt-, Horizontal-, Icon- und Splash-Assets ersetzen die bisherige Mehrfachverwendung eines quadratischen Logos; beide Theme-Sets werden offline vorgehalten.
- iOS-Webcontainer mit demselben geprüften React/Vite-Build synchronisiert; kein Plattformfork und keine neue native Berechtigung.
- TypeScript, Vite, Worker-Syntax und alle 579 Regressionen bestanden. Worker-Fachlogik unverändert; kein manueller Worker-Upload erforderlich.

## v0.9.74.7

- Release-CI Run #771 mitigiert: npm ci, Dependency-Audit, TypeScript und Vite waren grün; 576/577 Regressionen bestanden. Ausschließlich `test-ruc-dwd-pipeline-09690.mjs` enthielt noch ein v0.9.74.5-only Übergangsfenster.
- Drei verteilte, versionsgebundene RUC-Workflow-Ausnahmen durch einen gemeinsamen zustandsgebundenen Sync-Vertrag ersetzt: bytegleich synchron oder exakt bekannter geschützter Legacy-.github-Zustand bei vollständig validiertem kanonischem :11/:41-Catch-up-Workflow.
- Unbekannte Workflow-Drift und unvollständiger kanonischer Catch-up-Stand bleiben fail-closed. Neue Regression prüft synced, pending-admin-sync, unsafe-drift und invalid-canonical.
- RUC-Fachdaten, Pages-Free/950-MB-Grenze, Forecast-Fusion, iOS und Worker-Semantik unverändert; manueller Worker-Upload bleibt unnötig.

## v0.9.74.6

- Release-CI Run #770 mitigiert: npm ci, Dependency-Audit, TypeScript, Vite und 576/577 Regressionen waren grün; ausschließlich `test-ruc-pages-free-storage-09700.mjs` erwartete trotz bewusst geschütztem `.github`-Self-Modification-Block noch Bytegleichheit zum bereits aktualisierten kanonischen RUC-Workflow.
- Release-vor-Admin-Sync-Ausnahme konsistent auf beide RUC-Workflow-Regressionen angewendet und exakt auf v0.9.74.5/.6 sowie den bekannten Legacy-Workflowzustand begrenzt. Ab v0.9.74.7 ist die Ausnahme automatisch wieder geschlossen.
- RUC-Catch-up (:11/:41), 950-MB-Pages-Limit, Forecast-/Worker-Semantik und Kostenvertrag unverändert. Nach grünem v0.9.74.6-Release ist der explizite Workflow-Sync auf `main` und `mid-stable` unmittelbar nachzuholen; manueller Worker-Upload bleibt unnötig.

## v0.9.74.5

- Release-CI Run #769 mitigiert: npm ci, Audit, TypeScript und Vite waren grün; die einzigen 2/576 Fehler waren historische CARTO-Token-Regressionsasserts. Sie schützen nun den seit v0.9.74.3 gültigen schlüsselfreien OSM+MapLibre-Tone-Vertrag statt entfernte CARTO-URLs.
- DWD-RUC-Scheduler gegen ausgelassene GitHub-`schedule`-Ereignisse gehärtet: bestehender :41-Slot plus versetzter :11-Recovery-Slot, äußeres `cancel-in-progress: false` und billiger exact-run Catch-up/Freshness-Guard vor apt/ecCodes/pip.
- Der Guard überspringt nur bei strukturell gültigem, exakt aktuellem Pages-Free-RUC; neuer/stale/unklarer Stand läuft fail-open in die vollständige Verarbeitung. `fetch_and_build_ruc.py` bleibt authoritative Completeness-Gate.
- Pages-Free-Projektion, 950-MB-Grenze, Post-Deploy-Health-Convergence, Forecast-Fusion und Worker-Runtime bleiben unverändert. RUC-Workflow-Sync ist explizit erforderlich; manueller Worker-Upload nicht.

## v0.9.74.4

- DWD-RUC Run #12 analysiert: RUC/RUC-EPS-Build, Pages-Free-Prüfung, 918-MB-Seitenzusammenstellung, Artifact-Upload und Pages-Deployment waren erfolgreich; ausschließlich der unmittelbar folgende Worker-Health-Probe sah noch den vorherigen stale `latest.json`.
- Post-Pages-Healthcheck um ein kurzes begrenztes Konvergenzfenster mit eindeutigen No-Cache-Probes und Backoff ergänzt. Der neue veröffentlichte Lauf muss weiterhin exakt `ready + fresh + schemaValid` werden; stale/falsche Runs werden niemals akzeptiert.
- Persistiert der stale Zustand nach dem Retry-Budget, bleibt der Workflow fail-closed. Neue Required Regression simuliert sowohl `stale -> stale -> fresh` als auch dauerhaft stale.
- Keine Änderung an RUC-Fachlogik, Forecast-Fusion, Pages-Free-Profil, Worker-Runtime oder iOS-Nativfähigkeiten; kein manueller Worker-Upload erforderlich.

## v0.9.74.3

- Kompositbild: die anonym inzwischen gesperrten CARTO-Positron-/Dark-Matter-Kacheln samt "API KEY REQUIRED"-Wasserzeichen vollständig entfernt; bestehende Kartenbasis-IDs bleiben für Persistenz erhalten.
- Schlüsselfreie OpenStreetMap-Kacheln bilden nun Standard, "Schlicht hell" und "Schlicht dunkel". Die beiden schlichten Varianten werden ausschließlich lokal über MapLibre-Raster-Sättigung, Kontrast und Helligkeit aufbereitet; kein API-Key, Konto oder kostenpflichtiger Kartendienst erforderlich.
- Gleichen Schutz appweit auf Wetterkarten und Synoptikkarte ausgeweitet, damit der bereits bei der Extremwetterkarte behobene CARTO-Ausfall nicht in anderen Kartenmodulen wiederkehrt.
- Neue Required Regression verhindert produktive `basemaps.cartocdn.com`-Rückfälle und schützt die persistierten hell/dunkel-Auswahlvarianten sowie den lokalen Raster-Tone-Vertrag. Worker- und Wetterdatenlogik bleiben unverändert.

## v0.9.74.2

- Pages-Release-Restore gegen transiente `HTTP 429/500/502/503/504`- und Netzwerkfehler gehärtet: begrenzte Retry-/Backoff-Logik mit `Retry-After`-Beachtung statt sofortigem Abbruch eines kompletten Release-Versuchs.
- RUC-Snapshot-Restore intern auf maximal 8 parallele Chunk-Downloads begrenzt, um Lastspitzen auf `midwx.app`/GitHub Pages zu vermeiden; Workflow-Selbsterneuerung ist dafür nicht erforderlich.
- Fail-closed bleibt erhalten: persistente Fehler brechen nach dem Retry-Budget weiterhin ab; Größe und SHA-256 jedes Chunks werden unverändert geprüft, unvollständige temporäre Restores werden verworfen.
- Anlass war Run #766: Versuch 1 traf einen transienten HTTP 503, Versuch 2 war erfolgreich; der Gesamt-Release v0.9.74.1 war bereits grün.

## v0.9.74.1

- Release-CI-Hotfix nach Run #765: `midCloud` und `highCloud` bleiben im ShortTermForecastPoint optional; die neue SVG-Wolkenstruktur akzeptiert daher korrekt `number | undefined` und normiert fehlende Werte auf 0 %.
- Keine Änderung am visuellen Wolkenkonzept, an Forecast/RUC/Worker-Semantik oder an nativen iOS-Fähigkeiten.
- Regression des 24-h-Wolkenprofils um den optionalen H/M-TypeScript-Vertrag erweitert; zwei ältere Texttoken-Regressionsprüfungen auf die seit v0.9.74.0 korrekte Beschriftung Gesamt/H/M/L synchronisiert.

## v0.9.74.0

- 24-h-Wetterprofil: Wolkenbereich nach dem abgestimmten Konzept neu aufgebaut – Gesamtbewölkung plus höhentypische H/M/L-Strukturen statt optisch gleichartiger Wolkenblöcke.
- Hohe Wolken cirrusartig/faserig, mittlere Wolken altocumulus-/schichtartig und tiefe Wolken cumulus-/stratocumulusartig; 0–100-%-Bedeckung steuert sichtbar Dichte, Breite, Masse und Opazität.
- Nachbarstunden-Fading gilt nun für Gesamt + alle drei Wolkenhöhen; Randwerte und Einzeldaten zeigen Gesamt/H/M/L.
- Kanonischer Forecast-/RUC-Datenvertrag unverändert; Pages-Free-Speichermitigation aus v0.9.73.13 bleibt enthalten, kein zusätzlicher Worker-Fachpfad und keine kostenpflichtige Infrastruktur.

## v0.9.73.13

- Release-Run #762 vollständig analysiert: ZIP, Dependencies, TypeScript, Vite, Regressionen und Capacitor waren grün; der einzige Fehler lag im separaten Worker-Smoke, weil ein stale RUC-Snapshot die Promotion blockierte.
- Zirkuläres RUC-Bootstrap-Gate behoben: Ein **schema- und metadatenvalider** Snapshot mit exakt `RUC-Lauf nicht frisch` darf den Worker-Release einmalig bootstrap-sicher passieren; alle anderen RUC-Healthfehler bleiben fail-closed.
- Stale RUC-Daten bleiben im Forecast weiterhin deaktiviert; der RUC-Preprocessor verlangt nach Veröffentlichung unverändert einen echten `ready + fresh`-Lauf.
- Automatischer 0-%-Worker-Smoke, Rollback und Kostenvertrag bleiben unverändert; kein manueller Worker-Upload und kein R2 erforderlich.

## v0.9.73.12

- Release-CI-Hotfix nach Run #761: veraltete exakte Extremwetter-Funktionssignatur-Regression an die bereits gültige `env`-Verdrahtung angepasst; fachlicher Mitteleuropa-Extremwetterpfad unverändert.
- Der parameter-native ICON-D2-RUC-Multiproduktpfad aus v0.9.73.11 bleibt unverändert: stündlicher Zustandskern, 5-minütiges `TOT_PREC` sowie separate 15-minütige Konvektions-/Diagnostikprodukte.
- Produktionsvalidierung bleibt fail-closed: erst grüner Release-CI-Lauf, danach automatischer semantischer Worker-Deploy und frischer RUC-Workflow; kein manueller Worker-Upload und keine kostenpflichtige Infrastruktur.

## v0.9.73.11

- DWD ICON-D2-RUC appweit auf parameter-native Taktung umgestellt: gemeinsamer Zustandskern stündlich bis +14 h, `TOT_PREC` nativ 5-minütlich bis +6 h und Konvektions-/Reflektivitäts-/Phasenprodukte 15-minütlich bis +6 h.
- 114 aktuell gelistete RUC-v1-Parameter appweit auditiert; hochwirksame Severe-, Strahlungs- und Specialist-Diagnostik gezielt ergänzt, große/mehrdimensionale oder redundante Felder bewusst zurückgestellt.
- 0–6-h-Extremwetterpfad um räumliche RUC-Rapid-Signale für Niederschlagsrate, CAPE/CIN und optionale DBZ/UH/LPI/EchoTop/Hagel-Diagnostik erweitert.
- `VIS`, `CEILING`, `HZEROCL`, `SNOWLMT`, `CLCM`, `CLCH`, `T_G`, `H_SNOW` als stündliche Specialist-Diagnostik; Sicht mit 10-m-Wireauflösung ohne 32,7-km-Clipping.
- `SRH` und `WSHEAR_U/V` wegen zusätzlicher DWD-`lvt1`-Layersemantik bewusst nicht blind importiert; separater Layer-Audit vorgesehen.
- RUC-Strahlungsfelder werden diagnostisch geführt, ersetzen aber den appweiten Sunshine-Duration-Contract nicht ohne DNI-/Sonnengeometrie-Validierung.

## v0.9.73.10

- Produktiven RUC-Run #6 repariert: gemeinsames ICON-D2-RUC-Mehrparameterbundle nutzt die tatsächlich gemeinsame native Stundenachse 0…+14 h statt nicht vorhandene Viertelstundenwerte für Temperatur/Wind/Druck/Wolken zu verlangen.
- Kein künstliches Interpolieren auf :15/:30/:45; native 15-Minuten-/Radar-/Nowcast-Quellen bleiben für die feine Kurzfrist zuständig, RUC bleibt kanonischer stündlicher Kurzfristkalibrator.
- RUC-EPS bleibt stündlich; Worker-/Modellmetadaten melden für den gemeinsamen RUC-Punktadapter korrekt 3600 s.
- Neuer Common-Hourly-Axis-Regressionsschutz; letzter fehlerhafter Run #6 ist im RUC-Status dokumentiert und wird nicht auf dem alten SHA erneut ausgeführt.

## v0.9.73.9

- Beide neuen MID-Logovarianten integriert und in den Einstellungen als Auto / Dunkles Logo / Helles Logo wählbar gemacht; Auto folgt dem Layoutkontrast und greift auch im Startbildschirm.
- Wolkenkästchen im 24-h-Wetterprofil wieder sauber an die Stundenwerte gekoppelt: H/M/L als eingerückte Rasterzellen mit dezenten Frames statt losgelöster Vollbandoptik.

## v0.9.73.8

- Release-Gate-Hotfix: veralteten Integrationsassert zur früheren RUC-„Verfügbarkeitsquelle“ auf den produktiven DWD→Pages→Worker-Vertrag umgestellt.
- Run #759 hatte TypeScript, Vite und 567/568 Regressionen grün; der einzige Fehler war dieser historische Wortlaut-Test.
- v0.9.73.7-Fachstand bleibt vollständig erhalten: RUC 0–6 h / 15 min, danach stündlich bis +14 h; RUC-EPS stündlich; appweite Modelltexte/Badges und Wolkenprofil unverändert.

## v0.9.73.7

- DWD-RUC-Hybridraster: deterministisch 0–6 h in 15-Minuten-Schritten, danach stündlich bis +14 h; RUC-EPS bleibt stündlich.
- Wolkenprofil vereinheitlicht: ein neutraler Grauton für H/M/L, Intensität ausschließlich nach jeweiligem Bedeckungsgrad und weichere Fade-in/Fade-out-Übergänge.
- Modellstand-/RUC-Texte app-weit an den produktiven DWD Open Data → GitHub Pages → Worker-Pfad angepasst.
- `RUC`-Badge nur noch für echte DWD ICON-D2-RUC/RUC-EPS-Zeilen; andere Rapid-Update-Modelle tragen `Rapid`.
- RUC-Downloader konsistent zum Hybridraster nachgezogen; bestehende Modellmeta-/RUC-/Pipeline-Regressionen aktualisiert und bestanden.

## v0.9.73.6

- DWD ICON-D2-RUC: native triangular-grid lookup now derives coordinates from authoritative `CLAT`/`CLON` fields instead of unavailable ecCodes `latitudes`/`longitudes` arrays.
- RUC preprocessing keeps v0.9.73.5 hourly preselection and bounded parallel downloads (`TOT_PREC` 15/325; RUC-EPS 300/6500 observed in run #4).
- Added fail-closed coordinate, point-count and radians-to-degrees validation.

## v0.9.73.5

- Release-Gate-Hotfix: historische Extremwetter-Persistenzregression auf den aktuellen semantischen StorageSafety-Revisionsvergleich angepasst.
- RUC-Workflow-Spiegel wieder byteidentisch zum geschützten produktiven `.github`-Workflow; die Beschleunigung bleibt vollständig im Python-Fetcher und benötigt keine Workflowänderung.
- v0.9.73.4-Favoriten- und RUC-Fachfixes unverändert beibehalten; keine Worker-/R2-/Apple-/Kostenänderung.

## v0.9.73.4

- RUC-Preprocessing beschleunigt: Für das 0–14-h-Bundle werden aus DWD-`PTxxxHyyM`-Bäumen vor dem Download nur die 15 benötigten vollen Stunden ausgewählt; 5-/15-Minuten-Zwischenstände und spätere Leads werden nicht mehr unnötig geladen.
- RUC-Download mit begrenzten 8 parallelen Transfers und sichtbarem Fortschritt; ecCodes extrahiert das native Lat/Lon-Gitter pro Parameter/EPS-Gitter nur einmal.
- Favoriten-Dauerhaftigkeit repariert: StorageSafety vergleicht Primär-/Shadow-Favoriten jetzt über `mid:favorites:updated-at`, sodass ein älterer IndexedDB-Mirror einen neueren nativen Favoritenstand nach Suspend/Reload nicht mehr zurücksetzen kann.
- Keine fachliche Worker-, R2-, Apple-Capability- oder Kostenänderung.

## 0.9.73.1

## v0.9.73.3

- RUC-Bootstrap-Hotfix: iOS-Statusversion mit Release synchronisiert; keine fachliche RUC-/Worker-Änderung.
- Generierte Python-`__pycache__`-Artefakte aus dem Release entfernt.

## 0.9.73.2
- RUC Pages bootstrap: ein noch nicht vorhandenes `/ruc/latest.json` (HTTP 404) blockiert den allerersten Release nach Aktivierung der kostenlosen RUC-Pipeline nicht mehr. Andere Restore-Fehler bleiben fail-closed.


- Hotfix für die kostenlose DWD ICON-D2-RUC/RUC-EPS-Pipeline: URL-kodierte DWD-Laufverzeichnisse (`%3A`) werden vor der Run-Erkennung dekodiert.
- Verhindert den falschen Fehler `No common DWD RUC/RUC-EPS run directories found` bei vorhandenen stündlichen Läufen.
- Fail-safe-Vollständigkeitsprüfung, gemeinsamer RUC/RUC-EPS-Lauf, Pages-Pfad und deaktiviertes R2 bleiben unverändert.

## 0.9.73.0

- iOS Privacy: Haupt-App und `MIDWidgets` besitzen jeweils ein eigenes, im Target gebündeltes `PrivacyInfo.xcprivacy`; Tracking bleibt überall deaktiviert.
- App-Manifest: Precise Location, optionaler zufälliger Device-Sync-Identifier, verschlüsselter portabler Nutzerinhalt sowie Cloudflare-RUM Produktinteraktion/Performance sind mit passenden AppFunctionality-/Analytics-Zwecken deklariert.
- Required Reason API: `@capacitor/filesystem` wird mit `NSPrivacyAccessedAPICategoryFileTimestamp` / `C617.1` abgedeckt.
- Widget-Manifest: ausschließlich Precise Location und frei eingegebener Standortinhalt für `mid.native.widget.v1`; keine Tracking-Domains und keine Required-Reason-API.
- iOS Regression: historische Adaptertests verwenden nun eine zentrale semantische Next-Milestone-Funktion, damit abgeschlossene Apple-Meilensteine nicht erneut durch harte Altvergleiche blockiert werden.
- Keine neue Apple-Berechtigung oder Capability: kein ATT, kein Push-Opt-in, kein Background Mode, kein `aps-environment`, keine Signierung. Nächstes Gate ist macOS/Xcode-Simulatorqualität.

## 0.9.71.1

## 0.9.72.0

- iOS: APNs-Callback- und BGAppRefresh-Quellen im Haupt-App-Target vorbereitet, ohne Berechtigungs-, Entitlement-, Token-Upload- oder Scheduling-Aktivierung.
- iOS: `BGTaskSchedulerPermittedIdentifiers` enthält den vorbereiteten Identifier `app.midwx.weather.background-refresh`; `UIBackgroundModes` und `aps-environment` bleiben absichtlich deaktiviert.
- Vertrag: `MID_APPLE_PUSH_BACKGROUND_CONTRACT.md` schützt den gemeinsamen React/Vite-/Worker-Fachkern und das Apple-/Kosten-Gate.
- RUC/Push/Widget: v0.9.71.1-Auditfixes bleiben enthalten; Ortsforecast-Schattenpfade nutzen die kanonische Forecast-Fusion.


- Vier veraltete iOS-Regressionen erwarten ab v0.9.71.0 korrekt `apple-push-background-refresh-source-preparation`; die WidgetKit-Xcode-Struktur bleibt vollständig erhalten.
- RUC-Appweit-Audit: Lüftungsassistent/-Push und Prognoseänderungs-Push verwenden die kanonische `forecast-fusion` statt eigener Best-Match-Ortsprognosen.
- Der native `mid.native.widget.v1`-Feed übernimmt stündliche/tägliche Forecastwerte aus der kanonischen Mehrmodell-/RUC-Fusion; Current und Astronomie bleiben als Rohhülle erhalten.
- DWD ICON-D2-RUC/ICON-D2 teilen weiterhin das DWD-ICON-Familienbudget; KNMI/DMI HARMONIE werden konservativ unter `uwc-west-harmonie` gruppiert, ohne Anbieterdiagnostik zu verlieren.
- Wasser-/Warnquellen benennen die kanonische MID-Ortsprognose korrekt; Druckniveau-, Berg-, Marine-, Radar-/Raster- und Mitteleuropa-Extremwetterpfade bleiben fachlich getrennte Spezialdaten.
- KNMI Direkt-GRIB wird nicht zusätzlich aktiviert: vorhandener kostenloser Open-Meteo-Pfad deckt die stündliche HARMONIE-Rapid-Quelle ab, während ein zweiter Datei/API-Key-/Dekodierpfad derzeit nur Betriebsaufwand duplizieren würde. R2 bleibt deaktiviert.

## 0.9.71.0

- Das vorbereitete Apple-Widget-Gerüst ist als echtes `MIDWidgets`-App-Extension-Target in `ios/App/App.xcodeproj` integriert und wird über `Embed Foundation Extensions` samt Target-Abhängigkeit in die bestehende Capacitor-App eingebettet.
- Die Widget-Swiftquellen liegen nun kanonisch unter `ios/App/MIDWidgets`; parallele alte Swift-Kopien unter `native/apple` wurden entfernt. Der gemeinsame Wetter-/Worker-Fachkern bleibt unverändert.
- Der unveränderte Datenvertrag `mid.native.widget.v1` wird beim Decodieren explizit validiert; der Widget-Provider nutzt den produktiven HTTPS-Endpunkt `mid-data-proxy.midwx.workers.dev`.
- Die Widget Extension verwendet iOS/iPadOS 17.0 für `AppIntentConfiguration`; das Haupttarget bleibt auf iOS 15.0. iOS unterstützt systemSmall/Medium/Large und die Lock-Screen-Familien Inline/Circular/Rectangular; `accessoryCorner` ist für ein späteres watchOS-Target per Compile-Grenze geschützt.
- Keine App Group, kein Apple-Entitlement, keine Signierung und kein kostenpflichtiger Dienst werden in diesem Quellmilestone aktiviert. Neue Regression schützt Xcode-Target, Einbettung, Info.plist, Bundle-ID, Plattformgrenzen und den Feedvertrag.

## 0.9.70.2

- Release-Hotfix für den Lifecycle-/Offline-Meilenstein: die historische v0.9.53.14-Core-Cache-Regression prüft nicht länger eine einzelne alte Quelltextzeile, sondern den aktuellen dreistufigen Cachevertrag aus Offline-Warmstart, Fresh-Cache und Stale-Netzfallback.
- Die Laufzeitlogik selbst bleibt unverändert: Offline wird vor jedem Netzpfad auf einen lokalen Kernforecast zurückgegriffen; frische Cachewerte werden normal wiederverwendet und ein belastbarer letzter Stand bleibt nach Netz-/Rate-Limit-Ausfall als begrenzter Fallback verfügbar.
- Run #749 bestätigte vor dem Testabbruch TypeScript und Vite-Build für v0.9.70.1 sowie 563 von 564 Regressionen; Worker, Pages und `mid-stable` blieben fail-closed unangetastet.

## 0.9.70.1

- Gemeinsamer Browser/PWA-/Capacitor-Lifecycle-Bridge: `pagehide`, Sichtbarkeit und nativer `appStateChange` sichern den lokalen Persistenzstand best-effort, ohne Favoriten, Events, Einstellungen oder Wetterzwilling-Daten zu löschen oder zurückzusetzen.
- Offline-Warmstart: ein höchstens 18 Stunden alter erfolgreicher Kernforecast wird ohne aussichtslosen Netzwerkversuch sofort aus dem lokalen Cache geliefert; ohne Cache endet der Ladevorgang unmittelbar mit einer verständlichen Offline-Meldung statt in einem Endlos-Ladezustand.
- Die Oberfläche kennzeichnet Offline-Betrieb kompakt samt Standzeit des gespeicherten Wetterstands; bei Netzrückkehr und nach längerer Wiederaufnahme wird derselbe gemeinsame Forecast-Loader gezielt neu angestoßen.
- Bestehende Browser-/PWA-Sichtbarkeits-Refreshpfade werden beim nativen Resume weiterverwendet; es entsteht kein iOS-Fachlogik-Fork und keine neue native Datenhaltung.
- Neue Required Regression schützt Lifecycle, Offline-Short-Circuit, Cache-Metadaten, lokalen Datenbestand und Dark-Mode-Offlinestatus.

## 0.9.70.0

- DWD ICON-D2-RUC/RUC-EPS kann ohne Cloudflare R2 über den kostenfreien GitHub-Pages-Pfad `pages-free-v1` veröffentlicht werden; GRIB-Decodierung bleibt vollständig im GitHub-Actions/ecCodes-Vorprozessor.
- Deterministischer RUC, voraggregierte RUC-EPS-Wahrscheinlichkeiten/Quantile und räumlicher Lookup werden als kleine immutable Chunks publiziert; der Worker benötigt für Pages keine HTTP-Range-Requests.
- Normale MID-Pages-Releases bewahren einen vorhandenen RUC-Snapshot mit Größen-/SHA-256-Prüfung und brechen bei aktivierter Pipeline fail-closed ab, statt RUC-Daten lautlos zu löschen.
- Tagesansicht: Niederschlagswahrscheinlichkeit bleibt nun auch bei gleichzeitig sichtbaren Niederschlagsbalken als kontrastierte cyanfarbene Kurve sichtbar.
- Tagesansicht: Windrichtungspfeile erhalten in der dunklen Ansicht einen hellen, leicht konturierten Kontrast; eine zuvor globale dunkle Cockpit-CSS-Regel ist auf das Cockpit begrenzt.
- R2 bleibt vollständig optional und inaktiv; für diesen Meilenstein wird kein kostenpflichtiger Speicher aktiviert.

## 0.9.69.7

- Extremwetter-Ausblick vom versehentlich wiederverwendeten v0.9.66.19-DACH-Stand auf den bereits in v0.9.67.7–v0.9.67.11 eingeführten vollständigen Mitteleuropa-/ICON-D2-Vertrag zurückgeführt.
- Native ICON-D2-Gebietsmaske, erweitertes Regionsnetz, resilienter Batch-/Teilcache und 0–6-h-KONRAD3D-/Meso-Beobachtungsabgleich wiederhergestellt; Browser-Direktpfad bleibt derselbe Fachkern.
- Freie OSM-Kontextlage wird über sämtlichen Gefahrenflächen erneut gezeichnet; Ländergrenzen, Kartenlinien und Städtenamen bleiben auch bei mehreren überlagerten Gebietslayern sichtbar.
- Neue Required Regression verhindert einen erneuten DACH-/v4-Rückfall und schützt die Karten-Layerreihenfolge.

## 0.9.69.6

- Worker-Auto-Deploy: reale `cloudflare/wrangler-action`-Ausgabe wird über den dokumentierten `command-output` statt über eine nicht erzeugte `/tmp`-Datei ausgewertet.
- Version-ID-Erkennung bleibt fail-closed und akzeptiert exakt eine Worker-Version-ID.
- Regression deckt die echte Wrangler-4.125.0-Zeile `Worker Version ID: ...` ab.

## 0.9.69.5

- Worker-Auto-Deploy-Hotfix: der in einer temporären `/tmp`-Wrangler-Konfiguration gespeicherte Worker-Einstiegspfad ist jetzt absolut und zeigt sicher auf den ausgecheckten Release-Arbeitsbaum.
- Regression schützt davor, `worker/metar-proxy.js` künftig wieder relativ zum Speicherort der temporären Config statt zum Repository aufzulösen.
- Der v0.9.69.4-Fehlversuch stoppte erneut vor Staging/Traffic; Pages und `mid-stable` blieben korrekt blockiert.

## 0.9.69.4

- Worker-Auto-Deploy-Hotfix: ein leeres Cloudflare-`placement` wird nicht mehr als ungültiges `placement: {}` an Wrangler übergeben.
- Gültiges Smart Placement bzw. genau ein expliziter Placement-Hinweis bleibt erhalten; unbekannte oder widersprüchliche Remote-Angaben brechen weiterhin fail-closed ab.
- Der fehlgeschlagene v0.9.69.3-Erstlauf änderte keinen produktiven Traffic; Pages und `mid-stable` blieben korrekt blockiert.

## 0.9.69.3

- Sicherer automatischer Cloudflare-Worker-Deploy mit fachlicher Änderungserkennung, Remote-Konfigurationsspiegel, 0-%-Staging, Versionsoverride-Smoke, 100-%-Promotion und automatischem Rollback.
- Dashboard-Variablen/Secrets bleiben erhalten; unbekannte Bindings und mehrdeutige Split-Deployments blockieren fail-closed.

## 0.9.69.2

- Cloudflare-R2-Betrieb auf **private-by-default** gehärtet: `r2.dev` wird beim einmaligen Bootstrap deaktiviert; ein Custom Domain bleibt optional und benötigt weiterhin eine gesonderte Freigabe.
- Bootstrap validiert Cloudflares aktuelle kleingeschriebene R2-Location-Hints (`weur`, `eeur`, …); der bisherige vorbereitete Großschrift-Default wird nicht mehr an die API gesendet.
- Lifecycle-Leckschutz für verwaiste `runs/` auf 48 h gesetzt. Die unmittelbare Vier-Run-Bereinigung bleibt Aufgabe des atomaren Publishers, der den aktuell durch `latest.json` referenzierten vollständigen Lauf vor dem Pointerwechsel niemals löscht.
- Neuer `ruc-health`-Workerpfad prüft Binding, Metadatenschema, Laufalter, Punkt-/Zeit-/EPS-Vertrag und die tatsächliche Existenz aller vier Laufobjekte, ohne Bucketnamen, Tokens oder URLs offenzulegen.
- GitHub-Stundenpublisher bleibt auf einen bucket-spezifischen R2-Object-Read-&-Write-Zugang begrenzbar; Bucket-/Lifecycle-Administration bleibt vom laufenden Publisher getrennt.
- Browser/PWA und iOS bleiben auf demselben React/Vite-/Worker-Fachkern; keine native Sonderlogik oder Persistenzänderung.

## 0.9.69.1

- Kostenfreien DWD-RUC-Produktionspfad gehärtet: der GitHub-Actions/ecCodes-Vorprozessor versucht mehrere gemeinsame RUC/RUC-EPS-Laufkandidaten und veröffentlicht nur einen vollständig dekodierten 0–14-h-Lauf.
- RUC-EPS wird für den normalen Forecast bereits im Vorprozessor zu >0,2-mm- und >5-mm-Wahrscheinlichkeit, Mittel sowie Q25/Q50/Q75 verdichtet; native Member bleiben ausschließlich für die kurzfristige Event-Ensembleauswertung abrufbar.
- Alle Laufobjekte einschließlich `lookup.bin` liegen unveränderlich unter `runs/<run>/`; `latest.json` wird erst nach Remote-Größenprüfung zuletzt ersetzt. Ein identischer vollständiger Lauf verursacht beim nächsten Workflow keine neuen Schreiboperationen.
- Alte RUC-Läufe werden erst nach erfolgreichem Pointerwechsel entfernt; vier vollständige Läufe bleiben als Rückfallreserve erhalten. Best Match/ICON-D2/ICON-D2-EPS bleiben jederzeit sichere Fallbacks.
- Cloudflare-R2-Bootstrap als Dry-Run/Fail-Closed-Werkzeug ergänzt. R2-Erstellung erfordert `MID_RUC_COST_APPROVED=true`; ein öffentliches Custom Domain zusätzlich `MID_RUC_PUBLIC_DOMAIN_APPROVED=true`. Ohne ausdrückliche Freigabe wird nichts im Cloudflare-Konto verändert.
- Browser/PWA und iOS verwenden weiterhin denselben React/Vite-/Worker-Fachkern; der nächste native Lifecycle-/Offline-Meilenstein bleibt unverändert.

## 0.9.68.1

- Netatmo-OAuth wird im nativen Container über Capacitor Browser im iOS-Systembrowser geöffnet; Browser/PWA behalten den bestehenden externen beziehungsweise Same-Window-Pfad.
- Der eng begrenzte Rücksprung `midwx://oauth/netatmo` verarbeitet Warm- und Kaltstarts, validiert Callback-Daten und öffnet anschließend die vorhandene MID-Stationsansicht.
- Fremde Deep Links, unsichere externe Zieladressen und ungültige Stationskennungen werden verworfen; Fachwerte und Stationspersistenz bleiben außerhalb des Adapters.

## 0.9.68.0

- Der gemeinsame React-/Vite-Kern verwendet für eine ausdrückliche Standortaktion im nativen Container den Capacitor-Geolocation-Adapter; Browser/PWA behalten den bisherigen `navigator.geolocation`-Pfad.
- Berechtigungen werden erst bei Bedarf angefordert. Es gibt weder einen Standort-Watcher noch Hintergrund-Ortung oder neue Koordinatenpersistenz.
- Nicht berechtigungsbedingte Brückenfehler können auf den bestehenden Browserpfad zurückfallen; eine Ablehnung wird nicht mit einem zweiten Prompt umgangen.
- Die iOS-Berechtigungsbeschreibungen und eine neue Required Regression schützen den Adaptervertrag.

## 0.9.67.5

- MapLibre GL JS 6.5 erhält im Vite-Produktionsbuild wieder den vorgeschriebenen selbstständigen ESM-Worker; dadurch erscheinen die modellierten DACH-Gefahrenflächen wieder, während Browser/PWA und iOS denselben Kartenkern behalten.
- Ein neuer Required-Test prüft die Worker-URL vor der ersten Karte sowie den gebündelten Produktions-Worker und verhindert einen erneuten lautlosen Ausfall der GeoJSON-Flächen.

## 0.9.67.4

- Release-Hotfix für den v0.9.67.3-Installer: Der Dependency-/Actions-Wartungstest verlangt nicht länger, dass der absichtlich vor Workflow-Selbstmodifikation geschützte aktive `.github`-Stand bereits innerhalb desselben ZIP-Installationslaufs aktualisiert wurde.
- `sync-github-workflows.mjs` synchronisiert beim ausdrücklich administrativen Lauf nun neben checkout v7.0.1 und setup-node v7.0.0 auch CodeQL `init`/`analyze` auf 4.37.7 (`ff2f1c621b7f889edc0d3c761ac2e6a3f8cdb0dd`).
- Der Installer-Sicherheitsvertrag bleibt unverändert: `.github` wird weder durch das Release-Overlay noch durch den automatischen Release-Commit selbst verändert; die Workflow-Aktualisierung erfolgt getrennt über den expliziten Sync.
- Versionssynchronisierung gehärtet: `sync-version.mjs` aktualisiert nun auch die kanonische Worker-Teilquelle, damit der Aggregate-Neubau den Release-Worker nicht auf die Vorversion zurücksetzen kann.
- Keine Änderung an Wetterlogik, UI, MapLibre/Lucide-Versionen oder Datenquellen gegenüber v0.9.67.3.

## 0.9.67.3

- PR #16 übernommen: Lucide React 1.31.x → 1.34.0; Package/Lockfile, Dependency-Policy und Freigabetest sind gemeinsam auf den neuen Stable-Pin umgestellt.
- PR #17 übernommen: MapLibre GL JS 5.24.0 → 6.5.0 einschließlich synchronisierter Transitivreihen und MapLibre-Pin-Regression; der verwendete Stand enthält die DOM-Sanitizing-Korrektur aus der 6.4.1-Linie.
- PR #15 übernommen: CodeQL 4.37.7 ist für `init` und `analyze` auf `ff2f1c621b7f889edc0d3c761ac2e6a3f8cdb0dd` SHA-gepinnt.
- PR #1/#2 nicht blind gemergt: `sync-github-workflows.mjs` synchronisiert alle Workflows auf checkout v7.0.1 (`3d3c42e5aac5ba805825da76410c181273ba90b1`) und setup-node v7.0.0 (`820762786026740c76f36085b0efc47a31fe5020`).
- React 18.3.1, TypeScript 5.9.3, Vite 6.4.3 und @vitejs/plugin-react 4.7.0 bleiben unverändert; die größeren Toolchain-Sprünge sind weiterhin separat zurückgestellt.

## 0.9.67.2

- Ein vollständig gecachtes Browser-/PWA-Update wird nun kontrolliert aktiviert und lädt offene App-Fenster auf den neuen Stand. Die vorherige geprüfte Version bleibt bis zur erfolgreichen Laufzeit-Gesundheitsmeldung als Rückfallversion erhalten.
- Dadurch kann nach einem erfolgreichen Release-Upload nicht länger unbemerkt eine wartende neue Version neben der weiterhin sichtbaren Altversion laufen.
- Die kompakte Event-Center-Übersicht zeigt neben Niederschlagsart und -wahrscheinlichkeit wieder die für den gesamten Eventzeitraum berechnete Niederschlagsmenge in mm.

## 0.9.66.19

- Regionsnamen von modellierten Gefahrenflächen werden ausschließlich aus der räumlichen Lage der jeweiligen Kontur bestimmt; meteorologische Spitzenwerte einer entfernten Rasterzelle können das Popup nicht mehr falsch benennen.
- „Stärkste Regionen“ fasst nur noch identische Kombinationen aus Region, Gefahr und Intensität zusammen und behält dabei die höchste Wahrscheinlichkeit. Mehrfache gleichlautende Einträge wie „Ostschweiz“ entfallen.
- Flug-Events behandeln fehlende Wolkenuntergrenzen strikt nullsicher. Ein noch nicht vorhandener TAF-/Ceiling-Wert wird nicht mehr durch `Number(null)` zu 0 und anschließend als „unter 100 ft AGL“ formatiert.
- Sehr niedrige diagnostische Untergrenzen bleiben zusätzlich gegen Sichtweite, tiefe Bewölkung und Wettercode plausibilisiert; ältere Flugwetter-Zwischenspeicher werden über einen neuen Cachevertrag entwertet.

## 0.9.66.18

- DACH-Extremwetterkarte und „Stärkste Regionen“ verwenden nun denselben flächenbezogenen Konturdatensatz. Zwei getrennte Gefahrenflächen bleiben auch dann zwei Listeneinträge, wenn ihre frühere grobe Regionsbezeichnung identisch war.
- Jede modellierte Gefahrenfläche erhält eine stabile ID; Auswahl, Marker, Prozentwert und Detailkarte sind dadurch eindeutig gekoppelt.
- Karten-Popups zeigen wieder die zur jeweiligen Fläche gehörende Regionsbezeichnung vor Prognosestufe und Wahrscheinlichkeit.
- Alpenregionen feiner zugeordnet: Wallis, Zentralschweiz, Tessin, Graubünden, Vorarlberg und Tirol ersetzen zu grobe Sammelzuordnungen.

## 0.9.66.17

- DACH-Extremwetterkarte: Beschriftungen werden nun aus den tatsächlich dargestellten, getrennten Konturkomponenten erzeugt. Zwei räumlich getrennte Felder derselben zusammengefassten Region erhalten damit jeweils eine eigene Stufen- und Prozentangabe; eingebettete stärkere Kerne verdrängen doppelte Hüllenbeschriftungen.
- Die in der Extremwetterkarte anonym nicht mehr nutzbaren CARTO-Kacheln wurden durch eine schlüsselfreie OpenStreetMap-Kartenbasis mit transparentem Orientierungslayer ersetzt. Das von CARTO gelieferte Wasserzeichen „API KEY REQUIRED“ erscheint dort nicht mehr.
- Flug-Events: Standortbezogene Zusammenfassungen für Wolkenuntergrenze, Sicht und Böen bleiben strikt auf dem lokalen Modell-/Druckniveaupfad. Räumlich entfernte METAR-/TAF-Hazards bleiben im amtlichen Hazard-Screening sichtbar, dürfen aber lokale Eckwerte nicht mehr überschreiben.
- Ungültige bzw. nicht spezifizierte Terminal-Cloud-Basen unter 100 ft und außerhalb des physikalischen Wertebereichs werden bereits im Worker verworfen. Die bestehende Low-Cloud-/Sicht-/Wettercode-Plausibilisierung bleibt zusätzlich aktiv.

## 0.9.66.16

- Vier veraltete Extremwetter-DACH-Regressionen an die seit 0.9.66.14 getrennte Kontur-/GeoJSON-Architektur angepasst. Die Tests prüfen nun `extremeOutlookAreaGeoJson.ts` und `buildExtremeOutlookContourGeoJson` statt entfernte Implementierungsstrings im Overlay.
- Keine Rücknahme der fachlichen Flächenkorrektur: Multipolygone, Lochringe, >60-%-Kerne und Schraffur bleiben unverändert.
- Korrekturen aus 0.9.66.15 für GeoJSON-TypeScript-Build, Wolkenuntergrenzen-Plausibilität und chronologische amtliche Warnungen bleiben erhalten.

## 0.9.66.15

- Produktionsbuild repariert: Extremflächen-GeoJSONs sind nun explizit als `FeatureCollection<MultiPolygon, ...>` typisiert; der TypeScript-Fehler `type: string` gegen `type: "Feature"` ist beseitigt.
- Flug-Events: sehr niedrige modell-diagnostische Wolkenuntergrenzen werden gegen `cloud_cover_low`, Sicht und Wettercode plausibilisiert; insbesondere wird `unter 100 ft AGL` bei guter Sicht ohne stützendes Low-Cloud-Signal nicht mehr ausgegeben.
- Amtliche Wetterwarnungen werden chronologisch nach Beginn, dann Ende sortiert; Warnstufe oder Provider-Reihenfolge übersteuern die Zeitachse nicht mehr.

## 0.9.66.14
- Flug-Event-Plausibilität für Wolkenuntergrenzen verbessert: diagnostische Angaben wie "unter 100 ft AGL" werden nur noch gezeigt, wenn Low-Cloud-, Sicht- oder Wettercode-Signale diese niedrige Untergrenze stützen; bei guter Sicht ohne Low-Cloud-Support bleibt die Angabe nun aus.
- Build-Fix für Extremflächen-GeoJSON: `buildExtremeOutlookContourGeoJson` liefert nun explizit typisierte GeoJSON-FeatureCollections/MultiPolygons, damit der Produktionsbuild nicht mehr an `Feature<Geometry, GeoJsonProperties>` scheitert.

- DACH-Extremwetterkarte: rechteckig wirkende >60-%-Teilflächen ursächlich behoben. Die bereits fachlich korrekten Konturringe werden nun als sauber verschachtelte GeoJSON-Multipolygone an MapLibre übergeben, statt Außenringe, Lochringe und innere Inseln implizit zu vermischen.
- Schraffur unter 60 % und ungeschraffte Kerne über 60 % bleiben auch bei geschachtelten Flächen korrekt getrennt; Inseln innerhalb einer Aussparung werden als eigene Fläche erhalten.
- Das Overlay aktualisiert seine GeoJSON-Quellen nun auch für leere Zwischenzustände sauber weiter. Veraltete Restgeometrien bleiben dadurch nicht auf der Karte stehen.
- Meteorologische Feldberechnung, Schwellen, Diagnostik und Worker-Fachlogik bleiben unverändert; fachlich ist dies ein Frontend-Fix.

## 0.9.66.13

- Fachlich falsche Umrechnung der stündlichen Niederschlagswahrscheinlichkeit in Niederschlagsminuten entfernt: 66 % werden nicht mehr als 40 Minuten Regen ausgegeben. Ohne zeitlich aufgelöste Teilintervalle zeigt MID keine Scheindauer.
- Sonnenscheindauer appweit nach der letzten Modell-, Wetterzwilling-, Lokal- und Radarstufe plausibilisiert: Nacht sowie mehrfach gestützter Nebel, geschlossene tiefe Bewölkung und stratiformer Niederschlag begrenzen widersprüchliche Werte; Wahrscheinlichkeit allein und Schauer-/Gewitterlagen tun dies ausdrücklich nicht.
- Fehlende Sonnenscheinwerte bleiben fehlend. Die 3-Stunden-Ansicht summiert die drei Stundenwerte korrekt und kann bis 180 Minuten anzeigen, statt einen Mittelwert auf 60 Minuten zu begrenzen.
- Aktuelle Ansicht, 15-Minuten-/Stundenprofil, Tagesaggregation, Events und native Widgets verwenden denselben Zeitkonsistenzvertrag. Für native Apple-Widgets ist der synchronisierte Worker erforderlich.

## 0.9.66.12

- Aktuelle Radar-Nowcast-Karte gegen Breitenüberlauf abgesichert: Summen- und Ensembleangaben ordnen sich abhängig von der tatsächlichen Kartenbreite neu an, statt Diagramm, Balken oder Info-Schaltfläche zu überdecken.
- Zeitmarken und die Jetzt-Markierung besitzen getrennte Lesebereiche; der komplette Nowcast-Rahmen bleibt innerhalb seiner Karte.
- Derselbe responsive Kartenvertrag gilt für Gewitter-, Starkregen- und Sturzflut-Zusatzfelder: lange Überschriften, Statusangaben, Ortszeilen, Fakten und Quellen brechen innerhalb der verfügbaren Breite um.

## 0.9.66.11

- Der lange Methodik- und Einschränkungstext unter der DACH-Gefahrenkarte wurde aus dem normalen Layout entfernt. Er ist vollständig über einen kompakten, appweit standardisierten Info-Button abrufbar.

## 0.9.66.10

- Kartenlegende des DACH-Extremwetter-Ausblicks deutlich verkleinert: I1–I4 stehen nun in einem zweispaltigen Raster mit kurzen Kartenbezeichnungen; die vollständigen fachlichen Benennungen bleiben in der ausführlichen Legende unterhalb der Karte erhalten.
- Der redundante Erklärungstext zu Farbe, Prozent und Deckkraft wurde aus der Kartenlegende entfernt. Die Schraffur wird dort nur noch kompakt als Wahrscheinlichkeit unter 60 % ausgewiesen.
- Länder-, Verwaltungs- und Verkehrsgrenzen werden über einen transparenten Karten-Kontextlayer oberhalb der Gefahrenflächen nachgezeichnet; der separate Beschriftungslayer bleibt als oberste Orientierungsebene erhalten.
- Wahrscheinlichkeitsband und Prozentanzeige verwenden dieselbe Rundungsbasis. Der Grenzfall eines intern knapp unter 10 % liegenden Signals kann daher nicht mehr gleichzeitig als `10 %` und `P0` erscheinen; angezeigt wird konsistent `10 % · P1`.

## 0.9.66.9

- Extremwetterkarte auf die kontrastreichere CARTO-Voyager-Orientierungskarte umgestellt. Beschriftungen bleiben als eigener Vordergrundlayer oberhalb der Gefahrenflächen; geringere Flächendeckkraft hält Länder- und Verwaltungsgrenzen besser erkennbar.
- MID-Prognosestufen fachlich an die DWD-Warnlogik angenähert, ohne eine amtliche Warnung vorzutäuschen: Wettergefahr, markante Wettergefahr, Unwetterpotenzial und extremes Unwetterpotenzial. Die frühere grüne Stufe entfällt zugunsten der gelb–orange–rot–violetten Gefahrenskala.
- Schraffur korrigiert: Sie folgt nun dem interpolierten Wahrscheinlichkeitsfeld innerhalb eines Gefahrengebiets und kennzeichnet exakt die Teilflächen unter 60 %, nicht mehr pauschal den Spitzenwert der gesamten zusammenhängenden Fläche. Legende und Kartenerklärung nennen die Bedeutung ausdrücklich.
- Dashboard-Reihenfolge erhält einen eigenen Änderungszeitpunkt. Neu hinzugekommene Sektionen werden einmalig verlustfrei migriert; die Migration wird gespeichert. Beim Start gewinnt ein neuerer synchroner Wert gegen einen veralteten IndexedDB-Spiegel, und der Geräteabgleich schützt die lokal neuere Sektionsreihenfolge vor älteren Remote-Ständen.

## 0.9.66.8

- DACH-Kartenbeschriftungen wurden als eigener Vordergrundlayer über die Gefahrenpolygone gelegt; Gültigkeits- und Popuptexte erhielten mehr Kontrast.
- Datumsübergreifende Vorhersagefenster nennen Start- und Enddatum. `Gefrierhöhe` heißt im Ausblick nun `Nullgradgrenze`.
- Sektionsänderungen werden funktional und synchron geschrieben; 0.9.66.9 ergänzt die notwendige Revisions- und Spiegelkonfliktbehandlung.

## 0.9.66.7

- Fehlende Wassertemperatur im Reiseplaner ursächlich behoben: Der bisherige Open-Meteo-/ERA5-Ocean-Aufruf lieferte real ausschließlich leere SST-Werte und wurde vollständig entfernt.
- Küstennahe Wassertemperaturen stammen nun aus dem täglichen NOAA-OISST-v2.1-Langzeitmittel der Normperiode 1991–2020. MID wählt für den konkreten Reisezeitraum die nächste vollständige 0,25°-Meereszelle innerhalb von 80 km; Binnenland erhält weiterhin keinen Ersatzwert.
- Neuer CORS-sicherer Workervertrag `travel-water-climate` mit strikt validiertem Schema, gezielten OPeNDAP-Zeit-/Raumausschnitten, Land-/Fehlwertfilter, Schaltjahrbehandlung und transparenter NOAA-Kennzeichnung in der Oberfläche.
- Alte leere SST-Caches werden durch `noaa-oisst-1991-2020:v5` invalidiert. Nur positive Ergebnisse werden langfristig gespeichert; Fehler und saubere Nichtverfügbarkeit bleiben wiederholbar. Ein alter Worker wird sichtbar diagnostiziert.
- Der konkrete Nutzerfall Iberostar Waves Creta Panorama, 18.–27.10.2026, wurde gegen den realen NOAA-Datensatz verifiziert: 22,66 °C am 3,6 km entfernten Meeresgitter. Professional-App und Worker müssen gemeinsam auf 0.9.66.7 aktualisiert werden.

## 0.9.66.6

- Wiederholt gleichförmige Sechseck-/Stützkernflächen im DACH-Extremwetter-Ausblick entfernt. Gefahrengebiete entstehen nun als Schwellenkonturen aus dem vollständigen räumlichen I1–I4-Wahrscheinlichkeitsfeld und nicht mehr als Puffer um ausschließlich sichtbare Stützpunkte.
- Der Datenvertrag liefert für jedes Rasterfeld auch Wahrscheinlichkeiten unterhalb der Darstellungsschwelle. Dadurch bestimmen reale Modellgradienten Lage, Ausrichtung, Ausdehnung und Rand der Gebiete; benachbarte Signale verschmelzen fachlich, stärkere Intensitätskerne können innerhalb größerer Flächen liegen.
- Die bestehenden Schwellen bleiben unverändert: 40 % in der Gesamtlage, 10 % je Einzelgefahr und 5 % für I4-Ausnahmesignale. Farbe, Deckkraft, Schraffur, appweite Einheiten, Mehrparameterdiagnostik und Trennung von amtlichen Warnungen bleiben erhalten.
- Worker und kostenloser Browser-Direktweg nutzen dieselbe erweiterte Feldberechnung ohne zusätzliche Modellabrufe. Ein älterer Worker bleibt kompatibel; die volle durch Unterschwellenwerte geformte Geometrie setzt Worker 0.9.66.6 oder den Direktweg voraus.
- Vollständig auf MID 0.9.66.5 aufgebaut: Die dort reparierte klimatologische Reise-Wassertemperatur und ihre SST-v4-Regression bleiben unverändert Bestandteil beider neuen Builds.

## 0.9.66.5

- Reiseplaner: klimatologische Wassertemperatur für Küstenziele robust gemacht. Alle acht ERA5-Ocean-Referenzjahre werden unabhängig geprüft; 1991 ist kein harter Gatekeeper mehr.
- Alte SST-Negativcaches werden durch den neuen v4-Cachevertrag invalidiert; negative/unvollständige Ergebnisse werden nicht mehr über Jahre gespeichert und können sich beim nächsten Abruf erholen.
- Küstenradius an das native ERA5-Ocean-0,5°-Raster angepasst (80 km statt 45 km), ohne binnenländische Ersatzwerte zu erfinden. Technische SST-Ausfälle werden im Reiseergebnis sichtbar, während die übrige Klimatologie verfügbar bleibt.
- Neue dynamische Regression prüft fehlendes Referenzjahr, grobe gültige Meereszelle und Wiederherstellung nach einem negativen SST-Versuch.

## 0.9.66.4

- Der DACH-Extremwetter-Ausblick bleibt auch bei ausgeschöpftem täglichem Cloudflare-Worker-Kontingent verfügbar: Nach dem bevorzugten Worker-Abruf berechnet die App dieselbe Prognose kostenfrei direkt im Browser aus DWD ICON-D2-EPS und ICON-D2.
- Die Direktberechnung wird automatisch aus derselben kanonischen Worker-Fachquelle erzeugt. Raster, Schwellen, Mehrparameterdiagnosen, Wahrscheinlichkeiten, Intensitäten, appweite Einheiten und Zeitdarstellung bleiben daher identisch.
- Ein persistenter lokaler Ausfallcache hält gültige Prognosen über App-Neustarts hinweg vor. Erkanntes Worker-Tageslimit wird bis zum Tageswechsel lokal vorgemerkt; aussichtslose Wiederholungsaufrufe entfallen.
- Datenweg und Ausfallstatus werden verständlich auf Deutsch ausgewiesen. Die pauschale DNS-/CORS-/Netzwerkdiagnose erscheint nicht mehr als Endzustand des Moduls.
- Worker-Fachcache und Antwortcache wurden auf 30 Minuten verlängert; Browser-Direktabruf und bestehende Open-Meteo-Schutzlogik verursachen keine zusätzlichen Kosten oder kostenpflichtigen Abhängigkeiten.

## 0.9.66.3

- Rechteckige DACH-Rasterzellen durch geglättete, georeferenzierte Isoplethenflächen ersetzt. Direkt und diagonal benachbarte Stützfelder gleicher Intensität verschmelzen zu unregelmäßigen, zusammenhängenden Gefahrengebieten; isolierte Signale erhalten abgerundete Konturen.
- Farbe bleibt an I1–I4 gekoppelt, Deckkraft und Prozentmarker bleiben an die Wahrscheinlichkeit gekoppelt. Gebiete unter 60 % werden zusätzlich dezent schraffiert; eine helle Außen- und farbige Innenkontur hält die Abgrenzung auf der Basiskarte lesbar.
- Auch die unsichtbaren Popup-Trefferflächen sind nicht mehr rechteckig. Kartenlegende und Erläuterung unterscheiden die geglättete Regionalprognose ausdrücklich von amtlichen Warnpolygonen und gemeindescharfen Aussagen.
- Keine Änderung an DACH-Raster, Modellen, meteorologischen Schwellen, Diagnosen, Datenquellen, Abrufzahl oder appweiten Einheiten. Professional-App und Worker sind gemeinsam auf 0.9.66.3 synchronisiert.

## 0.9.66.2

- DACH-Extremwetterkarte zeigt die Gefahrenfelder nun zuverlässig als flächig eingefärbtes Regionalraster: Intensität bestimmt die Farbe, Wahrscheinlichkeit die Deckkraft; klare farbgleiche Konturen erhalten die räumliche Abgrenzung.
- Die Flächen werden über ein eigenes, mit Zoom, Bewegung und Größenänderung synchronisiertes Karten-Canvas gerendert und hängen damit nicht mehr von der Sichtbarkeit des MapLibre-Vektorfülllayers ab.
- Prozent-/Intensitätsmarker sind auf höchstens sechs regionale Maxima begrenzt. Sie verdecken damit nicht mehr nahezu jede Rasterfläche, während alle betroffenen Felder und die vollständige Rangliste erhalten bleiben.
- Keine Änderung an DACH-Raster, Modellen, Schwellen, Wahrscheinlichkeiten, Intensitäten, Datenquellen oder Einheiten. Professional-App und Worker sind gemeinsam auf 0.9.66.2 synchronisiert.

## 0.9.66.1

- Startfehler des neuen DACH-Extremwetter-Ausblicks behoben: Dezimalwerte für Niederschlag, Schnee, Glatteis, Schichtung, Scherung und Aufwind verwenden nun die korrekte Reihenfolge der appweiten Nachkommastellenparameter.
- Der zentrale deutsche Zahlenformatierer normalisiert ungültige oder vertauschte Nachkommastellenbereiche defensiv. Ein einzelner fehlerhafter Aufruf kann MID dadurch nicht mehr mit `minimumFractionDigits > maximumFractionDigits` am Start hindern.
- Keine Änderung an Modellen, Schwellen, Wahrscheinlichkeiten, Intensitäten, Datenquellen oder appweiten Einheiten. Professional-App und Worker sind gemeinsam auf 0.9.66.1 synchronisiert.

## 0.9.66.0

- Neuer „MID Extremwetter-Ausblick · DACH“ als eigener, konfigurierbarer Hauptbereich direkt nach den Warnungen: Gesamtlage sowie Gewitter, Stark-/Dauerregen, Sturm, Schnee und Glätte/Eisregen für 0–6, +6–12, +12–24 und +24–48 Stunden.
- Eigene probabilistische MID-Prognose aus DWD ICON-D2-EPS und deterministischer ICON-D2-Diagnostik; amtliche Warnungen bleiben fachlich und optisch getrennt.
- Feste Wahrscheinlichkeitsklassen P1–P4 und Wirkungsintensitäten I1–I4 mit transparenten Schwellen. Die Gesamtkarte blendet unter 40 % aus, Einzelgefahren unter 10 %; mögliche I4-Extremereignisse werden vorsorglich ab 5 % gezeigt.
- Gewitterbewertung verwendet CAPE nicht allein, sondern zusammen mit CIN, 850–500-hPa-Temperaturgradient, 700-hPa-Feuchte, vektorieller Scherung, Aufwind/LPI, Niederschlag und Gefrierhöhe; Hagel-, Downburst- und Starkregenpotenzial werden als Umfeldsignale ausgewiesen.
- Regen wird über 1-/6-/24-h-Akkumulationen, Sturm über EPS-Böen und höhenabhängige Exposition, Schnee über 6-/24-h-Neuschnee und Höhenzonen sowie Eisregen über Niederschlags-, Feuchttemperatur-, Wettercode-, Dauer- und Glatteisindikatoren bewertet.
- Übersichtliche MapLibre-DACH-Karte mit Intensitätsfarben, Prozentmarken, Liste der stärksten Regionen, Detailparametern, barrierefreier Textlegende, Mobilansicht, Fehler-/Stale-Zustand und manueller Aktualisierung.
- Appweite Vorgaben werden übernommen: Wind in der gewählten MID-Einheit, Niederschlag in mm, Schnee in cm, Höhe in m sowie Zeitangaben gemäß Lokal-/Z-Zeit-Einstellung.

## 0.9.65.16

- Kurzfrist-Wetterprofil: Windrichtungspfeile deutlich schlanker dimensioniert, damit sie die Windkurve nicht mehr optisch überdecken.
- Pfeile erhalten eine schmale, kontrastierende Kontur (Halo) hinter einem dünnen farbigen Kern; dadurch bleiben Richtung und Pfeilspitze in Hell- und Dunkelmodus auch bei Kurvenkreuzungen klar erkennbar.
- Keine meteorologische Daten-, Warn-, Forecast- oder Worker-Fachlogik geändert.

## 0.9.65.15

- Streckenbriefing: Höheneingabe mit expliziter Wahl zwischen FL und ft AGL repariert; keine Einheitssprünge während der Eingabe.
- Unter FL050 sind 100-ft-genaue AGL-Eingaben möglich; ab FL050 wird erst beim Commit auf 10-FL-Schritte gerundet.
- Neue Regression schützt die Flugniveau-Eingabe.


## 0.9.65.14

- Reiseplaner: historische Wassertemperatur auf die korrekte Open-Meteo Marine API / ERA5-Ocean umgestellt; fehlerhaften SST-Archive-Pfad entfernt und Wasserklima-Cache auf v3 migriert.
# v0.9.65.13

- Reiseplaner: Wassertemperatur wird bei Küstenzielen nicht mehr über einen sehr großen 30-Jahres-Stundenabruf nachgeladen. Stattdessen nutzt MID kleine, exakt auf die Kalendertage des geplanten Reisezeitraums begrenzte historische ERA5-SST-Ausschnitte aus gleichmäßig über 1991–2020 verteilten Referenzjahren. Der alte v1-Wasserklimacache wird invalidiert.
- Das erste Reiseergebnis wartet auf die klimatologische Wassertemperatur-Auswertung, sodass die Wassertemperatur-Kachel bei erfolgreicher Küstenprüfung direkt mit dem Ergebnis erscheint statt erst nachträglich. Aktuelle Marinewerte bleiben ausgeschlossen.
- Event-Center: Sonnenscheindauer wird wieder aus der kompakten Übersichtszeile entfernt. Die Übersicht bleibt bei Temperatur, Niederschlag/PoP, Wind und Böen.
- Sunshine-Duration-Contract präzisiert: stündliche Event-Zeitfenster zeigen Sonnenscheindauer in Minuten; die über ein mehrstündiges Event aggregierte Sonnenscheindauer erscheint in Detail-/Ratansichten in Stunden.
- Neue Regression schützt Reise-SST-Sichtbarkeit, Cachemigration und Event-Sunshine-Einheiten.

# v0.9.65.12

- Automatische Warnlage: laufende Stundenwarnungen werden nicht mehr nach der halben Stunde durch den nächstgelegenen Folgestundenwert verdrängt.
- Warnhorizont verwendet jetzt den letzten bereits begonnenen Stundenwert (`epoch <= jetzt`); Wechsel erst zum tatsächlichen Beginn der nächsten Stunde.
- Neue Regression für Warnzustände an Stunden-/Halbstundengrenzen.

# v0.9.65.11

- Aktuelle Niederschlagskarte: Bei trockenem Radar-/Modellkonsens und höchstens 5 % Rest-PoP wird kein künstlicher 5-%-Wert mehr angezeigt, sondern 0 %. Echte niedrige Prognosewahrscheinlichkeiten außerhalb dieses klar trockenen Nowcast-Falls bleiben erhalten.
- Reisewetter: erwartete Niederschlagstage werden in der Oberfläche und im Narrativ auf ganze Tage gerundet; die interne kontinuierliche Erwartung bleibt für Bewertung und Optimierung erhalten.
- Küstenreiseziele erhalten eine klimatologische Wassertemperatur für den tatsächlich gewählten Reisezeitraum. MID bildet dazu aus historischen ERA5-Stundenwerten der Meeresoberflächentemperatur 1991–2020 Tagesklimatologien am nächsten geeigneten Meeresgitter; aktuelle Marinewerte werden dafür nicht verwendet.
- Reisebeginn, Reiseende und Reisedauer bleiben lokal gespeichert; nach Änderung des Startdatums kann das Enddatum weder per Picker noch per Zustandslogik vor dem Start liegen.
- Der aktuelle automatische Warnkopf bleibt strikt gültigkeitszeitbezogen: Ein erst künftig beginnendes Warnfenster ist bis zu seinem `validFrom` keine aktuelle Warnlage.
- Neue Regression schützt trockenen Nowcast, Reise-SST, ganze Niederschlagstage und den zeitstrengen Warnkopf; Professional- und Worker-Version sind synchron.

# v0.9.65.10

- Appweiter Niederschlagswahrscheinlichkeitsvertrag korrigiert: Es gibt keine künstliche 5-%-Untergrenze mehr. 0 %, 1 %, 2 %, 3 % und 4 % bleiben als echte Modell-/Fusionswerte erhalten und werden entsprechend angezeigt.
- Kurzfristfusion und 24-h-Wetterprofil übernehmen die kanonische PoP unverfälscht; Darstellungslogik darf niedrige Wahrscheinlichkeiten weder anheben noch als Niederschlagssignal erfinden.
- Prognose-Kompass und Ensemble-Kompass verwenden eine gemeinsame Trockenheitsformulierung: Bei höchstens 0,1 mm im betrachteten Folgeabschnitt und maximal 5 % PoP lautet die Tendenz eindeutig „trocken“ statt „überwiegend trocken“.
- Geringes, aber reales Restniederschlagsrisiko behält die abgestufte Formulierung „überwiegend trocken“; erhöhte Regenneigung und wechselhaftes Risiko bleiben unverändert abgestuft.
- Neue Regression schützt Nullboden und Wortlaut appweit; Professional-/Worker-Versionen bleiben synchron.

# v0.9.65.6

- Das rollierende 24-h-Wetterprofil ergänzt zwischen Wind und Wolken eine sehr kompakte Luftdruckspur mit dynamischer hPa-Skala, Verlaufslinie und selektiertem Wert. Die Gesamt-SVG-Höhe bleibt unverändert.
- Wetter-Hazards werden aus derselben finalen Stundenreihe und mit derselben `summarizeDwdWarnings(..., 24)`-Logik wie die appweite Warnübersicht abgeleitet. 1 h/3 h verdichtet nur die Anzeige.
- Hazardfarben sind an die zentralen DWD-Stufen gekoppelt; warnungsfreie Stunden werden grün dargestellt.
- Keine zusätzlichen API-, Radar-, Cache- oder KV-Zugriffe. Worker-Fachlogik unverändert; Worker nur auf 0.9.65.6 synchronisiert.

# v0.9.65.5

- Appweiter Sunshine-Duration-Contract: 15-Minuten-Werte bilden vollständige Stunden; vollständige lokale Stunden bilden den Kalendertag. Daily bleibt Fallback und Qualitätsreferenz.
- Physikalische Grenzen gelten zentral: höchstens 15 min je Viertelstunde, 60 min je Stunde und je Tag höchstens die astronomische Zeit zwischen Sonnenauf- und -untergang. Fehlende Werte bleiben fehlend statt 0.
- Tageskacheln, Detailansicht, 7 Tage, 14 Tage/Ensemble, Events/Aktivitäten sowie Web- und Apple-Widgets verwenden dieselbe kanonische Sonnenscheindauer. Stündliche Darstellungen zeigen Minuten, Tages-/Ensemblewerte Stunden.
- Best Match bleibt in der Ensembleansicht der Hauptwert; P10–P90 zeigt die Modellbandbreite. Tooltips verwenden die vollständige Bezeichnung „Sonnenscheindauer“.
- Der Worker-Widgetfeed liefert optionale Sonnenscheinwerte mit Intervall-/Tageslichtbegrenzung. Professional-App und Worker bilden gemeinsam Release 0.9.65.5.

# v0.9.65.4

- Der Ortskopf verwendet die freigegebene Compact-Variante: aktuelles Wetter, Tmin/Tmax, Niederschlagswahrscheinlichkeit, Radarkurzlage und Datenbasis sind in einer gemeinsamen responsiven Karte zusammengeführt; der Detailschalter sitzt platzsparend in der Quellenzeile.
- Lokale Gewitter-/Starker-Schauer- und Starkregen-/Sturzflutkarten sind generische Compact-Disclosures. Alle bisherigen Status-, Orts-, Zugbahn-, Fakten-, technischen Detail- und Quelleninformationen bleiben erreichbar.
- Die automatische Warnübersicht ist eine gemeinsame, nach Tagen gruppierte Karte. Zeitfenster öffnen ihre Details unmittelbar unter der jeweiligen Zeile und kehren beim Zuklappen zur kompakten Ansicht zurück; DWD-Stufenfarben und Kennwerte bleiben erhalten.
- Amtliche CAP-Warnungen sind optisch direkt angebunden, ohne Textverlust: Originalbeschreibung, Handlungsanweisung, Gebiet, Sprache, Quelle und Gültigkeit werden weiterhin vollständig dargestellt.
- Eigene Hoch-/Querformatregeln verhindern abgeschnittene Information. Wetter-, Radar-, Warn- und KV-Abfragebudgets bleiben unverändert; Professional-App und Worker bilden gemeinsam Release 0.9.65.4.

# v0.9.65.3

- Das Wetterprofil verwendet ein exakt ab der aktuellen Zeit laufendes 24-h-Fenster; die Ansicht aktualisiert den Zeitanker automatisch und bietet eine persistente 1-h-/3-h-Darstellungswahl, ohne die stündlichen Rohdaten zu verändern.
- Nachtstunden, Tageswechsel sowie Sonnenauf- und -untergang werden dezent, aber eindeutig markiert. Eigene vertikale Bahnen und responsive Hoch-/Querformatlayouts verhindern das Überdecken von Zeittexten, Wettersymbolen, Pfeilen und Messwerten.
- Temperatur, gefühlte Temperatur und Taupunkt stehen gemeinsam auf einer Skala; das thermische Empfinden verwendet zentral dieselben DWD-Farben wie die übrige App.
- Niederschlagsmenge und -wahrscheinlichkeit besitzen getrennte Balken-/Kurvendarstellungen. Hohe, mittelhohe und tiefe Bewölkung bleibt mit eigenständigen 0–100-%-Zellen und selektierten Prozentwerten klar erkennbar.
- Sämtliche Warngebiets-, KV-/Sync-, Info-Button- und ERA5-Seamless-Reiseplaneränderungen aus v0.9.64.8 bis v0.9.65.2 bleiben erhalten. Der Open-Meteo-Audit ergänzt lediglich den aktuellen UKMO-Seamless-Fallback; zusätzliche Kernabfragen oder KV-Schreibvorgänge entstehen nicht.

# v0.9.65.2

- Reiseplaner-Klimatologie von einem fachlich unvollständigen ERA5-Land-Basisabruf auf Open-Meteo ERA5-Seamless umgestellt: ERA5-Land liefert die feinere Landtemperatur, ERA5 ergänzt Niederschlag, Solarstrahlung/Sonnenschein und Wind; optionale historische Schneehöhe bleibt separat auf ERA5-Land.
- Reise-Klimacache auf v3 migriert, damit bereits lokal gespeicherte fehlerhafte 0-h-/0-Wind-Datensätze nicht wiederverwendet werden.
- Nullwerte historischer API-Felder werden nicht länger per `Number(null)` als meteorologische 0 interpretiert; Plausibilitätsguards verwerfen unvollständige Reihen sowie unmögliche durchgehende 0-h-Sonnenschein- bzw. 0-Wind-Serien statt daraus Texte wie „eher sonnenarm“ abzuleiten.
- Appweiter Einheitenvertrag auf den Reiseplaner übertragen: Wind wird intern wie im übrigen MID in Knoten geführt, Ausgabe und Wind-Grenzwerte folgen der globalen Auswahl kt/km/h/m/s/mph; Temperatur bleibt °C, Niederschlag mm und Schnee cm.
- Quellen-/Methodentexte auf ERA5-Seamless standardisiert und irreführende reine ERA5-Land-/10-km-Aussagen entfernt. Worker-Fachlogik bleibt unverändert.

# v0.9.65.1

- Installations-Hotfix für die drei in v0.9.65.0 aufgedeckten Regressionen.
- Benannte Worker-Testexports für synoptische Richtungsprüfung und Gewitter-Push-Konsistenz wiederhergestellt, ohne Produktionslogik zu verändern.
- 36-px-Touchvertrag bleibt erhalten, wird bei Info-Buttons aber ausschließlich über eine unsichtbare Trefferfläche erfüllt; sichtbare Buttons bleiben kompakt.
- Sämtliche KV-/Sync-/Wetterzwilling-Einsparungen aus v0.9.65.0 bleiben unverändert bestehen.

# v0.9.65.0

- KV-Scheduler-Index reduziert reguläre `list()`-Operationen bei unveränderter 5-Minuten-Push-Kadenz auf vier automatische Reconciliations pro Tag plus Bootstrap/Recovery.
- Wetterzwilling speichert fachlich identische Beobachtungs-/Capture-/Referenzstände nicht erneut und bündelt Cloud-Vollarchive über zehn Minuten.
- Geräte-Sync erhält SHA-256-Inhaltssignaturen und 3-s-Burst-Deduplizierung; identische portable Zustände bleiben write-frei.
- Touch-Regressionsfix: sichtbare Info-Buttons wieder kompakt, Trefferfläche weiterhin groß und layoutneutral.
- Push-Unsubscribe-Routerpfad ist nun vollständig implementiert und bereinigt den Scheduler-Index.

# v0.9.63.1

- CI-Kompatibilität: die Flugbriefing- und Wartungsvertragsregressionen werden unter dem festgelegten Node.js 22.16.0 über das projektlokale TypeScript transpiliert statt `.ts`-Dateien direkt zu importieren.
- Wartungsregressionen: isolierte Forecast-Fusion-Tests berücksichtigen den gemeinsamen Cachevertrag; historische Persistenz- und Radar-Zeitpfeilprüfungen validieren die ausgelagerten Nutzerverträge statt frühere Quelltextformen.
- Keine Änderung an Wetterzwilling, Modellfusion, Radar-/Nowcast-Fachlogik, Kompositdarstellung, Persistenzsemantik oder Worker-Datenquellen gegenüber v0.9.63.0.

# v0.9.60.2

- CI/TypeScript: TS7006 im eventbezogenen Ensemble-Frischecallback dauerhaft in der kanonischen weather-Teilquelle behoben.
- Regression schützt, dass `maintain:aggregates` die Typisierung nicht wieder entfernt.

# v0.9.60.1

- Wetterzwilling: stabile Modellfamilien, gruppengeteilte Modellbudgets und effektive Stichprobengröße aus eindeutigen Zieltagen.
- P0: abgeleitete MID-Fusionen aus dem Modelllernen ausgeschlossen und tägliche Niederschlagswahrscheinlichkeit semantisch vereinheitlicht.
- P1: tatsächliche Lauf-Frische, horizonweise Variantenwahl und MeteoSwiss-CH1/CH2-Reichweiten konsolidiert.
- P2: Auflösungsprior gedämpft/parameterspezifisch; Mean/Spread klar von nativer Member-PoP getrennt.

# v0.9.59.2

- Flugmeteorologie: Cross Section als nicht-grafisches Streckenbriefing für 2–8 Flugplätze reaktiviert; Route, Flight Level sowie Start-/Landezeiten steuern orts- und zeitbezogene Gefahrenhinweise.
- Flugstrecke: Modellprofil-Diagnosen für Vereisung, Windscherung/Turbulenz, Konvektion, Höhenwind, Niederschlag, Sicht und Wolkenuntergrenze plus verfügbare amtliche/operative Signale an Start, En-route und Ziel.
- Kompositbild: Zeitpfeil verwendet primär eine wolkengewichtete vertikale Schwerpunktströmung aus dem 950–300-hPa-Profil; Radar-/KONRAD-Verlagerung dient als Plausibilisierung/Fallback.
- Kompositbild: Bewegungsachse und Pfeilspitze werden explizit in eigenen Leaflet/MapLibre-Kompatibilitätspane gerendert, damit der Zeitpfeil oberhalb der Wetter-/Referenzlayer sichtbar bleibt.

# v0.9.58.4

- Ortsfavoriten-Reihenfolge erhält eine eigene persistente Order-Revision und wird bei Appstart/Shadow-Recovery wiederhergestellt.
- Geräte-Sync migriert die lokale Reihenfolge vor dem ersten Pull und merged konkurrierende Reihenfolgen nach eigener Revision, ohne Favoriten zu verlieren.

# v0.9.58.3

- Regression-Hardening: zwei historische Radar-/Zeitpfeiltests auf den aktuellen Schwerpunktströmungs-Vertrag migriert.
- Keine funktionale Änderung an Zeitpfeil, Radar-Nowcast oder Workerlogik.

# v0.9.58.2

- TypeScript-Fix für den neuen Komposit-Zeitpfeil: `CompatBounds` stellt nun Südwest-/Nordost-Ecken typisiert bereit.
- Keine fachliche Änderung an Zeitpfeil, Schwerpunktströmung oder Radar-/Nowcast-Logik.
- Neue Regression gegen erneute TS2339-Fehler im MapLibre-Kompatibilitätsadapter.

# v0.9.58.1

- Komposit-Zeitpfeil vollständig neu aufgebaut: lange viewportbezogene Achse, kleine nordreferenzierte Zielpfeilspitze am gewählten Ort, zwei dezente Zeitmarken und Schwerpunktströmung aus der OPERA-Mehrframe-Regressionsbewegung; der frühere 90°-Darstellungsversatz der Pfeilspitze ist ausgeschlossen.
- Kurzfrist-Nebelrisiko verschärft: ein 2-K-Spread allein erzeugt tagsüber/bei guter Sicht kein erhöhtes Nebelrisiko; echte Sichtbeschränkung, WMO-Nebelcode und schwachwindige Nachtsättigung bleiben wirksam.
- lucide-react kontrolliert auf 1.31.0 aktualisiert; React 19, Vite/plugin-react 6 und TypeScript 7 bleiben zurückgestellt.

# v0.9.58.0

- Release-Pipeline gegen GitHub-Codeload-429 gehärtet: configure-pages entfernt; Pages-Deployment vom Release-Build entkoppelt und mit drei frischen Runner-Versuchen sowie 75/180-s-Backoff abgesichert.
- Pages-Artefakte je Versuch eindeutig benannt; fehlgeschlagene Versuche 1/2 sind recoverable, Versuch 3 bleibt harter Fehler.
- Stable-Finalisierung läuft erst nach tatsächlich erfolgreichem Pages-Versuch; Status-API bleibt 429/5xx-resilient.
- Manueller Stable-Deploy erhält denselben Pages-Retry-Vertrag.

# v0.9.57.4

- Installer: Release-ZIP wird vor dem Entpacken auf Dateigröße, SHA-256, ZIP-Signatur und CRC-Integrität geprüft.
- Wartung: kanonische Worker-Teilquelle auf denselben Release-Stand synchronisiert, damit `maintain:aggregates` die Worker-Version nicht zurückstuft.
- Regression: Installer-ZIP-Schutz wird sowohl im Workflow-Patch als auch in der kanonischen Workflowquelle geprüft.

# v0.9.57.3

- Stable-Release-Abschluss gegen temporäre GitHub-API-/Transport-5xx gehärtet: harter mid-stable-SHA-Vertrag mit Retry sowie Quality-Status mit fünf Backoff-Versuchen.
- Ein ausschließlich temporärer GitHub-Status-API-5xx markiert einen bereits gebauten, deployten und SHA-verifizierten Release nicht mehr fälschlich als fehlgeschlagen; 4xx/Auth-Fehler und SHA-Abweichungen bleiben harte Fehler.

# v0.9.57.2

- Installer gegen paralleles Weiterlaufen von `main` gehärtet: eventgebundener Checkout, sicherer Fetch/Rebase nur für `.github`, Abbruch bei neueren fachlichen Änderungen und Push-Retry ohne Force-Push.

# v0.9.57.1

- Regressionsverträge für den finalen Komposit-Zeitpfeil auf lange sichtbare Achse, Zielspitze am Standort und reduzierte Zeitlabels aktualisiert.
- Flug-Event-Einheitenregression auf die amtliche METAR/TAF-Priorisierung vor der Modell-Diagnose aktualisiert.
- Keine fachliche Rücknahme der Funktionen aus v0.9.57.0.

# v0.9.57.0

- Kompositbild auf einen einzelnen langen Zeitpfeil mit Zielspitze am gewählten Ort umgestellt.
- Lucide React auf 1.30.0 und Recharts kontrolliert auf 3.10.1 aktualisiert.
- GitHub Actions checkout auf 7.0.1 und setup-node auf 7.0.0 angehoben und SHA-gepinnt.
- React 19, TypeScript 7 und Vite/plugin-react 8/6 bleiben zurückgestellt.

# v0.9.56.0

- Funktionsneutrales Wartungsrelease: 7-Tage-Trend und App-Laufzeitcaches aus `App.tsx` ausgelagert.
- Styles, `weather.ts` und Worker besitzen nun kanonische, kleinere Quellfragmente; die bisherigen Aggregate werden vor Typecheck/Regression bytegleich generiert, sodass CSS-Kaskade, Weather-Importoberfläche, Cloudflare-Deployment und bestehende Verträge unverändert bleiben.
- Veraltete Regressionen für heutigen Niederschlag und die neue einzelne Radar-Zugbahn auf den aktuellen Vertrag migriert.
- Keine Datenquellen-, UI-, Persistenz- oder Wetterlogikänderung.

# v0.9.55.4

- 7-Tage-Trend: Der aktuelle Kalendertag berücksichtigt Niederschlag aus 00–24 Uhr, auch wenn Niederschlagsphasen bereits vor „Jetzt“ liegen.
- Für die Wettercharakteristik bleibt der verbleibende Tagesverlauf maßgeblich; vergangener Tagesniederschlag wird jedoch nicht mehr aus der Trendklassifikation entfernt.

# v0.9.55.3

- Flug-Events verwenden konsistente flugmeteorologische Einheiten: Wind/Böen folgen der gewählten MID-Windeinheit, Sicht wird in m bzw. km dargestellt und Wolkenuntergrenzen in ft AGL.
- Die kompakte Flug-Event-Übersicht zeigt Sicht und Wolkenuntergrenze statt des für Flugplanung weniger relevanten UVI-Felds.
- Amtliche METAR/TAF-Wind-, Sicht- und Ceiling-Signale liefern zusätzlich strukturierte Rohwerte; Sicht wird nicht mehr in Statute Miles ausgegeben.

# v0.9.55.2

- Kompositbild: Zugpfeile in „Zugbahn“ umbenannt.
- Deutlicher Zielpfeil mit lesbarer Achsenbeschriftung ergänzt; Pfeil wird nun oberhalb des Standortmarkers gerendert.
- Zugrichtung gegen das aktuelle Echofeld verifiziert und bei deutlichen Abweichungen aus den lokalen Bewegungsankern korrigiert bzw. gemischt.

# v0.9.55.1

- Produktions-Typecheck des Kompositbilds repariert: ungenutzte Altpfade `motionTimeMarkers`/`displayMotionAnchors` samt ausschließlich dafür benötigter Hilfstypen entfernt.
- Die neue einzelne Zugspur aus v0.9.55.0 bleibt unverändert aktiv: Pfeilspitze am gewählten Ort, Zeitmarken stromaufwärts entgegen der Zugrichtung.
- Neue Buildfix-Regression verhindert künftig die Rückkehr toter Motion-Altpfade.
- Keine funktionale Worker-Änderung; Worker nur versionssynchronisiert.

# v0.9.55.0

- 14-Tage-Modellstand zeigt Ensemblemodelle und deterministische Best-Match-/Kontrollmodelle getrennt; JMA MSM/Seamless/GSM werden dort fachlich korrekt als deterministische Modelle statt als nicht existentes JMA-Ensemble geführt.
- Ensemble-/Mean-Spread-Katalog app-weit vervollständigt: zusätzliche DWD-ICON-EPS- und GEFS-Mean/Spread-Reservevarianten sowie regionale MeteoSwiss-ICON-CH-Ensembles in der alpinen Schneefallgrenzenanalyse.
- Kompositbild besitzt eine oberste transparente Referenzkartenebene für Grenzen und Ortsnamen mit eigenem Deckkraftregler.
- Das bisherige Mehrpfeilfeld wurde durch genau eine Zugspur ersetzt: Pfeilspitze am gewählten Ort, Zeitlabels entgegen der Zugrichtung stromaufwärts.
- Die Stable-/Dependency-/Recharts-Hardening-Verträge aus v0.9.53.57 und die Open-Meteo-Auditverträge aus v0.9.54.x bleiben Bestandteil der Regression.

# v0.9.54.2

- CI-Regressionsfix für den in v0.9.54.1 übernommenen Vendor-Chunking-Vertrag: `test-performance-budget.mjs` akzeptiert jetzt ausschließlich die auditierte `ReactVendor`-/`ChartsVendor`-Aufteilung.
- Generisches oder zusätzliches manuelles Vendor-Chunking bleibt gesperrt; MapLibre darf weiterhin nicht manuell gechunkt werden und behält seine bestehende Lazy-Importgrenze.
- Keine Änderung an Open-Meteo-, AQI-, JMA-, Météo-France-, Ensemble-, Favoriten-, Event- oder Worker-Wetterlogik.

# v0.9.54.1

- Audit-Nachtrag aus v0.9.53.57 übernommen: React sowie Recharts/D3 werden als stabile Vendor-Chunks vom Hauptbundle getrennt; die bestehende MapLibre-Lazy-Grenze bleibt erhalten.
- Dependency-Audit sichert den vollständigen npm-Auditbericht auch bei Befund für 30 Tage als Artefakt; das High-Severity-Gate bleibt hart.
- Release-CI verifiziert nach Pages-Deployment den tatsächlich veröffentlichten `mid-stable`-SHA und setzt darauf `MID / stable-release-quality`.
- Recharts-Wartungsvertrag verlangt weiterhin einen exakt reproduzierbaren 3.x-Lockstand, blockiert kompatible 3.x-Minor-/Patch-Kandidaten aber nicht mehr durch einen historischen 3.8.1-Literal.
- Eigene Stable-Hardening-Regression schützt Vendor-Chunking, Audit-Artefakt, Stable-SHA-Status und Recharts-3-Kompatibilitätsvertrag dauerhaft.
- Historischer Buildstabilitätsvertrag akzeptiert nur die auditierte React-/Charts-Aufteilung; generisches Vendor-Chunking und erzwungenes MapLibre-Chunking bleiben verboten.

# v0.9.54.0

- Open-Meteo-Audit 17.08.2026 übernommen: AIFS-Europe-Ensemble mit Cloud-/Niederschlags-Plausibilitätsgate.
- Météo-France-Migrationsvertrag aktualisiert: AROME/ARPEGE, Seamless, 15-Minuten-Varianten sowie Niederschlag/Wind/Bewölkung/Sonnenschein regressionsgeschützt.
- JMA MSM/GSM/Seamless ergänzt; japanischer Meteogramm-Best-Match-, Höhen- und Druckniveaupfad vereinheitlicht.
- EU-AQI auf Open-Meteo-Gesamt-/Teilindizes erweitert; stündliche PM-/AQI-Reihen werden mitgeführt, Konzentrationsschwellen bleiben Fallback.
- API-Regression für getrennte 6-h-Min/Max-Aggregationen, Mondfelder und DWD-ICON-Begleitverträge ergänzt.

# v0.9.53.56

- Niederschlagswarnungen: einstellbare Vorwarnzeit (15–120 min) und Mindestmenge (0,1–5,0 mm); keine verspätete Beginnwarnung erst bei bereits laufendem Niederschlag. Bestehende Meldungspause bleibt verbindlich.
- Aktuelle Niederschlagswahrscheinlichkeit: textlicher Hinweis auf erwarteten Niederschlag jenseits des betrachteten +2-h-Nowcastfensters.

## 0.9.53.54

- Netatmo OAuth-Rücksprung auf iOS/PWA gehärtet: Callback bleibt als sichtbare Erfolgs-/Fehlerseite stehen statt sofort zur App zurückzuspringen.
- Letztes OAuth-Ergebnis wird 30 Minuten serverseitig je MID-Verbindung gespeichert und vom Stationsstatus zurückgegeben; Fehler gehen beim Wechsel zwischen Safari und installierter PWA nicht mehr verloren.
- Callback-Information wird zusätzlich in sessionStorage und localStorage gespiegelt.

## 0.9.53.53

- Netatmo OAuth auf iOS/PWA: Autorisierungs-URL wird vor dem Nutzertap vorbereitet und in Standalone-PWAs direkt in einem externen Browserkontext geöffnet.
- OAuth-Callback transportiert die `connectionId`, damit die Verbindung auch bei getrennten Safari-/PWA-Storage-Kontexten korrekt zugeordnet wird.
- Rückkehr aus dem OAuth-Browser aktualisiert den Netatmo-Status automatisch.

## 0.9.53.52

- Netatmo-OAuth-Start für iOS/PWA synchronisiert: der Nutzer-Tap navigiert ohne vorgeschaltetes `await` unmittelbar zum Worker; der bereits geladene Worker-Status entscheidet vor dem Tap über die Verfügbarkeit.
- Jeder OAuth-Versuch erhält einen eindeutigen Cache-Buster; Worker- und Callback-302-Antworten tragen explizit `no-store/no-cache`, damit Safari bzw. Edge keine frühere Fehlweiterleitung wiederverwenden.
- OAuth-Rückkehr wird vor dem Öffnen der Einstellungen in `sessionStorage` gesichert; Fehler/Erfolg gehen dadurch auch bei verzögertem Mount des Stationsbereichs nicht verloren.
- Netatmo-Status liefert die tatsächlich laufende Worker-Version zur sichtbaren Diagnose in den Einstellungen.

## 0.9.53.51

- Netatmo OAuth auf browserfeste direkte Worker-Weiterleitung (HTTP 302) umgestellt; damit wird die externe Netatmo-Seite insbesondere auf iOS/PWA nicht mehr von asynchronen UI-Schritten abhängig.
- OAuth-Fehler werden nach dem Rücksprung mit Phase und sanitisiertem Netatmo-Fehlertext sichtbar statt still durch den Status-Refresh überschrieben.
- Neue Regression für Direkt-Redirect und Callback-Fehlerdiagnose.

# v0.9.53.47

- CI-Regressionsvertrag gehärtet: `test-mid-followups-095323.mjs` prüft Default-Closed-Hauptmodule jetzt mengenbasiert statt über eine fragile feste Array-Reihenfolge.
- Veraltete Sensor-Deaktivierungsannahme aus `test-weather-twin-stages-0800.mjs` entfernt; eigene Sensoren sind seit der reaktivierten Stations-/Lüftungsintegration wieder zulässig und werden durch dedizierte Funktionsregressionen abgesichert.
- Keine Änderung an Wetter-, OAuth-, Stations-, Wetterzwilling- oder Lüftungslogik.

# v0.9.53.46

- GitHub-Actions-Regressionsfix: zwei veraltete Testverträge an die bereits beabsichtigten Änderungen aus v0.9.53.45 angepasst.
- `test-mid-followups-095323.mjs` akzeptiert den neuen default-closed Hauptmodulvertrag mit vorangestelltem Lüftungsassistenten.
- `test-weather-twin-stages-0800.mjs` erwartet wieder die bewusst reaktivierte private Sensorintegration statt des historischen Deaktivierungszustands.
- Keine funktionale Änderung an Wetter-, Stations-, OAuth-, Wetterzwilling- oder Lüftungslogik.

# v0.9.53.45

- Eigene Wetterstationen wieder aktiviert: Netatmo wird per OAuth/Login statt manueller Token-Eingabe verbunden; Tokens bleiben Worker-seitig verschlüsselt.
- Netatmo-Innenraumsensoren werden als Räume erkannt und liefern Temperatur, Feuchte und CO₂ für den neuen Lüftungsassistenten.
- Neuer Lüftungsassistent Stufe 1: pro Raum erlaubte Zeiten, absolute-Feuchte-/Kühlpotenzial, CO₂-Dringlichkeit sowie Wetter-Sicherheitsprüfung aus Niederschlag, Gewitter und Böen.
- Lüftungsfenster erscheinen im Dashboard und können über den bestehenden Web-Push angekündigt werden. Stufe 1 steuert ausdrücklich keine Fenster, Lüfter oder Anlagen.
- Plausible private Außenmessungen können wieder „Aktuelles Wetter“ ergänzen und in die lokale Wetterzwilling-Verifikation einfließen.

# MID v0.9.53.36

- Ensemble-Modellauswahl success-driven: fehlgeschlagene Quellen und nicht konfigurierte optionale Regionaladapter verbrauchen keinen Erfolgsplatz.
- ECMWF IFS/AIFS ENS verwenden in Europa einen Native-Europe→Global-Fallback innerhalb derselben Variantengruppe, ohne Doppelgewichtung.
- Modellstanddiagnose zeigt numerisch aktive Modelle auch bei fehlenden Laufmetadaten und kennzeichnet Aktiv, Fallback, Nicht verfügbar, Adapter fehlt und Reserve.
- Open-Meteo Mean/Spread-Reserve um NOAA AIGEFS, UKMO Global/UK, MeteoSwiss CH1/CH2 und BOM ACCESS erweitert.
- Worker-Capability-Endpunkt für KNMI HARMONIE-AROME EPS und ECCC REPS sowie verbindlicher Modellquellen-/Adaptervertrag ergänzt.

# MID v0.9.53.33

- App-weiter astronomischer Tag-/Nachtsymbolvertrag: zeitpunktbezogene Wetterpiktogramme wechseln exakt an Sonnenaufgang/Sonnenuntergang des jeweiligen Prognoseortes.
- 90-Minuten-/15-Minuten-Punkte übernehmen nicht mehr blind `is_day` der nächstgelegenen vollen Stunde; minutengenaue Sonnenstandsgrenzen werden in den kanonischen Forecast-Reihen mitgeführt.
- Aktuelles Wetter, Komposit/Radar, Kurzfrist-/Stundenpfade und Berg-/Höhenwetter auf denselben zentralen `astronomicalIsDayAt()`-Entscheider vereinheitlicht.
- Native Widgets verwenden `sunrise`/`sunset` statt Provider-`is_day` als primäre Symbolgrenze; Worker-Update erforderlich.
- Neuer verbindlicher `MID_SOLAR_SYMBOL_CONTRACT.md` und Required Regression `test-solar-symbol-contract-095333.mjs`.

# MID v0.9.53.32

- Langfrist-/Hauptsektions-Startzustand nachhaltig repariert: Modul-Offenzustände sind jetzt aus Recovery-Snapshot und StorageSafety-IndexedDB-Spiegel ausgeschlossen.
- Alte Spiegelwerte werden beim Start verworfen; `mid:module-open-contract:v5` setzt alle Hauptsektionen einmalig geschlossen.
- Öffnen/Schließen wird synchron mit der Nutzeraktion gespeichert, nicht erst in einem nachgelagerten React-Effect.
- Neue Required Regression `test-module-open-recovery-isolation-095332.mjs`.

# MID v0.9.53.31

- Favoritenstern auf einen einzigen semantischen Click-Pfad umgestellt; verspätete iOS-Synthetic-Clicks können einen neu gespeicherten Favoriten nicht mehr unmittelbar wieder entfernen.
- Mutierende Favoritenidentität von großzügiger Navigationsnähe getrennt; Koordinaten-/Namensnähe darf keine Löschung auslösen.
- Derselbe Ort kann ausdrücklich gleichzeitig Event/Event-Favorit und Ortsfavorit sein. Event-Metadaten werden aus Ortsfavoriten defensiv entfernt.
- Favoriten-Authoritätsref wird nur noch commit-sicher synchronisiert, nicht während des Renderns zurückgesetzt.
- Neue Required Regression `test-favorite-event-coexistence-touch-095331.mjs`.

# MID Changelog

## v0.9.53.30

- Favoriten werden bei jeder Änderung sofort und atomar in Primär-/Shadow-Snapshot geschrieben; Start-Recovery wendet Lösch-Tombstones zwingend an.
- Tombstones verfallen nicht mehr still und Geräte-Sync arbeitet bei Pending-Änderungen mit Favoriten-pull/merge/push.
- Push-Status prüft Browser, Workerregistrierung und Scheduler-Heartbeat statt nur das lokale Browser-Abonnement.
- Ende-zu-Ende-Testmitteilung und Reparatur der Workerregistrierung ergänzt.
- Niederschlagsbeginn auf kanonische 15-Minuten-Reconciliation inkl. Wahrscheinlichkeit und 45-Minuten-Vorwarnfenster umgestellt.
- Push-Scheduler paginiert alle KV-Empfänger; stilles 24-Favoriten-Limit entfernt.

## 0.9.53.29

- Produktionsbuild-Fix für den verlustfreien Favoriten-/Geräte-Sync: `mergeFavoriteSnapshots` akzeptiert einen fehlenden Remote-Snapshot nun explizit als `null`.
- Behebt GitHub Actions `TS2345` in `src/deviceSync.ts` aus v0.9.53.28, ohne Favoriten-Union, Shadow-Recovery, Tombstones oder Event-/Ortsfavoriten-Trennung zu verändern.
- Neue Required Regression `test-device-sync-nullability-buildfix-095329.mjs` typecheckt genau den zuvor fehlerhaften Nullability-Pfad.

## 0.9.53.28

- Dezente, platzneutrale Wetter-Ampel in den kompakten Eventdarstellungen ergänzt: grün = gut umsetzbar, gelb/amber = mögliche Beeinträchtigung, rot = deutlich beeinträchtigt/kritisch, neutral = noch nicht analysiert.
- Glocken-Popover und Event-Center-Kurzkarte zeigen den Punkt als Overlay direkt am bestehenden Wetterpiktogramm; Kartenhöhe und Zeilenanzahl bleiben unverändert.
- Ausführliche Eventbewertung nutzt dieselbe gemeinsame Komponente in der vorhandenen Statusplakette.
- Die Ampel verwendet ausschließlich den zentralen `EventAdvice.status`; kein zusätzlicher paralleler Wetterscore oder neue Schwellenwertlogik.
- Barrierearme Textbeschreibung sowie zusätzliche Musterunterscheidung für kritische/ungeklärte Zustände ergänzt.
- Dauerhaft im UI-Architekturvertrag und als Required Regression `test-event-feasibility-indicator-095328.mjs` geschützt.

## 0.9.53.27

- Favoritenintegrität app-weit verschärft: keine stille 20er-Kappung oder Verdrängung beim Hinzufügen, Laden oder Import.
- Ortsfavoriten und Event-Favoriten dauerhaft getrennt; Event-artige Datensätze können `mid:favorites` nicht ersetzen oder überlagern.
- Ortsfavoriten erhalten Shadow-Recovery sowie explizite Lösch-Tombstones; Geräte-Sync vereinigt konkurrierende Favoritenstände statt komplette Listen gegeneinander auszutauschen.
- Einheitlicher Hauptsektionsvertrag v4: alle großen `CollapsibleModule`-Sektionen starten bei Vertragsmigration geschlossen und bewahren danach nur die jeweilige lokale Nutzerentscheidung.
- Alte `#mid-section-*`-Hashes werden bei jedem App-Bootstrap neutralisiert; Hauptmodul-Offenzustände sind bewusst gerätelokal und werden nicht über Geräte-Sync überschrieben.
- Neuer verbindlicher `MID_STATE_INTEGRITY_CONTRACT.md` sowie Required Regression `test-state-integrity-contract-095327.mjs`.

## 0.9.53.26

- Verbindlicher appweiter Prognose-Konsistenzvertrag: sichtbare Forecastmodule verwenden die kanonischen Reihen `displayHours` und `displayMinutes15`.
- Hyperlokale Beobachtungskorrekturen werden feldbezogen und zeitlich abklingend zentral in die operative Stundenprognose übernommen.
- Erhöhte lokale Niederschlagswahrscheinlichkeit, Radar-/Nowcast- und Konvektivsignale fließen konsistent in 90-Minuten-, Kurzfrist-, Stunden-/Tagesdarstellungen, Widget, Hazards sowie Event-/Aktivitätsauswertungen ein.
- 15-Minuten-Daten werden vor der sichtbaren Verwendung zentral finalisiert; ansichtsspezifische Doppel-Assimilation von Radar oder Stationsankern ist entfernt.
- Architekturregel dauerhaft in `MID_FORECAST_CONSISTENCY_CONTRACT.md`, Hyperlokalvertrag und Source-of-Truth verankert; Required-Regression ergänzt.

## 0.9.53.24

- Aktuelles Wetter wieder kompakter: marginale Temperatur-/Gelände-Windkorrekturen werden als „Temp./Wind nahe Modell“ zusammengefasst; relevante Abweichungen bleiben numerisch sichtbar.
- Einzelparameter-Kacheln von redundanten Modell-/Korrekturhinweisen entlastet.
- Datenbasis-Infos erweitert: Modellhintergrund, Analyseverfahren, Kontextquellen und parameterbezogene Messwertquellen bleiben über die Info-Dialoge vollständig nachvollziehbar.
- Ohne geeignete aktuelle Messwertquelle kennzeichnet MID ausdrücklich den Modellhintergrund als Datenbasis.
- Buildfix: `forecastSourceLabel` wird vor der Hyperlokal-Datenbasis deklariert; die Required-Regression schützt diese Deklarationsreihenfolge künftig ausdrücklich.

## 0.9.53.23

- Hauptmodul-Öffnungszustand auf v3 migriert; insbesondere `Langfrist` wird nicht mehr durch einen alten gespeicherten Offen-Zustand als Standard geöffnet.
- Eventhinweise sachlicher formuliert und in Lagehinweise sowie empfohlene Maßnahmen gegliedert; Hitzehinweise nennen Trinkwasserversorgung, Erholungspausen und reduzierte direkte Sonnenexposition.
- 7-Tage-PoP: DWD-6-h-Zeitfenster nur bei klarer Abweichung vom Mittel der Tagesfenster; 0 % weiterhin ohne Zeitfenster, ansonsten 00–24 h ohne markanten Schwerpunkt.
- Events: Niederschlagswahrscheinlichkeit gilt über das vollständige Eventfenster; Ensemble-Member werden über den Zeitraum aufsummiert, der Stundenfallback ist zeitgewichtet statt Maximum einer Einzelstunde.
- Aktuelles Wetter und Parameterkacheln zeigen den hyperlokalen Modellhintergrund (z. B. DWD ICON-D2) sowie Temperatur- und Gelände-/Oberflächen-Windkorrekturen wieder transparent an.

## 0.9.53.22

- AQI-Erklärung sprachlich neutralisiert: sichtbare Prompt-/Gestaltungsbegriffe entfernt.
- Standort-Rückkehr appweit auf Request-Reuse umgestellt: Stationsanalyse, Luftqualität, Radar, Radarhistorie, amtliche Warnungen, Gewitter- und Starkregenbasis werden innerhalb fachlich geeigneter Frischefenster räumlich tolerant wiederverwendet, statt beim Zurückwechseln unnötig komplett neu geladen zu werden.
- Automatische Standortbestimmung nutzt einen 14-Tage-Cache für Reverse-Geocoding mit GPS-Jitter-Toleranz; Open-Meteo/CAMS-Luftqualität erhält 15 Minuten Fresh-Cache plus 2 Stunden Stale-if-error.
- EEA-Messstationsmetadaten sind cache-first; Push-Abonnementssync erfolgt nur noch bei tatsächlich geändertem Payload.
- Manueller Reload bleibt ausdrücklich force-fresh; periodische Hazard-Aktualisierung und alle Funktionen bleiben erhalten.
- Neue Required-Regression `test-location-return-request-reuse-095322.mjs`.

## 0.9.53.21

- EU-AQI-Detaildialog erweitert: Jeder Einzelparameter (PM2,5, PM10, NO₂, O₃, SO₂) zeigt jetzt eine kompakte horizontale Vergleichsskala mit offizieller sechsstufiger EU-AQI-Einteilung.
- Ein Positionsmarker verdeutlicht zusätzlich die relative Lage des Messwerts innerhalb der jeweiligen Stufe; die aktive Belastungsstufe wird visuell hervorgehoben.
- Luftqualitätsdialog auf schmaleren Ansichten responsiv verdichtet.

## 0.9.53.20

- Hauptmodule verwenden einen einheitlichen persistenten Öffnen-/Schließen-Vertrag. Ein beim letzten Navigieren verbliebener `#mid-section-*`-Hash öffnet beim App-Neustart kein Modul mehr automatisch.
- Einmalige Migration bereinigt den aus älteren Versionen potenziell erzwungenen Offen-Zustand der standardmäßig geschlossenen großen Module; danach gilt ausschließlich die jeweilige Nutzerauswahl.
- Modulzustände werden über denselben zentralen Schlüsselvertrag gespeichert und optional zwischen offenen Tabs synchronisiert.

## 0.9.53.19

- Hyperlokale Analyse fachlich geprüft: sehr kleine Restfeldkorrekturen sind zulässig und bedeuten, dass Messung und Modellhintergrund bereits eng übereinstimmen. Die kompakte Ergebniszeile hebt deshalb Temperaturkorrekturen erst ab 0,2 K und Gelände-/Oberflächen-Windkorrekturen erst ab 1 % hervor; kleinere Werte werden als „Temp./Wind nahe Modell“ zusammengefasst. Die Detailinfo behält die exakten Werte und kennzeichnet sie als vernachlässigbar.
- Event-Glocke: jedem Eintrag ist nun dasselbe Wetterpiktogramm wie im Event-Center vorangestellt. Glocke und Event-Center verwenden dabei den gespeicherten Tag-/Nachtstatus des repräsentativen Event-Wetters.

## 0.9.53.18

- Datenabruf wieder foreground-first stabilisiert: sichtbare Best-Match-Kernvorhersage erhält exklusiven Vorrang; automatische Event-/Favoritenjobs warten auf einen erfolgreichen Core-Forecast und eine ruhige Netzwerkphase.
- Aggressive Event-Hintergrundlogik aus v0.9.53.8 zurückgebaut: kein 5-Minuten-Modellmetadatenpolling je Eventort und kein erzwungener 30-Minuten-Fullrefresh mehr. Events werden passiv stündlich fällig, alle 15 Minuten geprüft, höchstens vier pro Hintergrundzyklus und strikt seriell aktualisiert.
- Nur manuelle Event-Reloads erzwingen `forceFresh`; automatische Pflege nutzt Cache-/Freshness-Verträge.
- Best-Match-Modellmetadaten werden als Aggregat 20 Minuten gecacht (6 h stale-if-error), statt bei jedem Eventlauf erneut viele Einzelabfragen auszulösen.
- Open-Meteo-429-Cooldown wird PWA-neustartfest gespeichert; während eines aktiven Cooldowns versucht der sichtbare Forecast zuerst Worker/Cache statt den limitierten Direktpfad erneut zu belasten.
- Automatisches Wetterzwilling-Lernen aller Favoriten ist wieder Opt-in und läuft bei Aktivierung über dieselbe globale Hintergrund-Netzwerkbremse.
- Neue Required-Regression `test-background-fetch-stability-095318.mjs`; ältere Event-Regressionen auf den ressourcenschonenden Vertrag aktualisiert.

# 0.9.53.17

- Vollständige Best-Match-Vorhersage und etablierte Kacheldarstellung wiederhergestellt: kein feldärmerer Fremdprovider mehr als Ersatz für die Standard-Kernprognose.
- Foreground-Prognose wieder direkt Best-Match-priorisiert; appweiter Open-Meteo-Guard, 429-Cooldown und gestaffelte Hintergrundabrufe bleiben erhalten.
- Worker dient für `forecast-core` nur noch als Cache/Resilienzpfad für vollständiges Open-Meteo Best Match; alte MET-Norway-Fallback-Caches werden verworfen.
- Standard-Herkunft der Stunden-/Tagesdaten, PoP, Sichtweite und Kachelsemantik wiederhergestellt; DWD-nahe Tages-PoP-Zeitfenster aus 0.9.53.14 bleiben erhalten.
- Neue Required-Regression `test-core-forecast-restoration-095317.mjs`.

## 0.9.53.16

- Kernvorhersage ohne Single-Provider-Ausfallpunkt: alle Core-Abrufe worker-first; Open-Meteo bleibt Primärquelle, MET Norway Locationforecast dient bei 429/5xx/Timeout und fehlendem Cache als unabhängiger globaler Ersatzpfad.
- Worker-Fallback wird transparent als tatsächliche Kernquelle ausgewiesen; Zeitzone/Höhe werden appweit an sichtbare, Event- und Favoriten-Core-Abrufe weitergegeben.
- Fehlende Niederschlagswahrscheinlichkeit des unabhängigen Ersatzproviders wird als `–` statt als künstliche `0 %` dargestellt; deterministische Niederschlags-/Wetterdaten bleiben nutzbar und die Quelle wird transparent ausgewiesen.
- Open-Meteo-429 aus dem Worker setzt zugleich den zentralen Browser-Cooldown, damit Hintergrundmodule den limitierten Dienst nicht weiter belasten.
- Neue Runtime-Regression simuliert ausdrücklich Cold Start ohne Cache bei Open-Meteo-429 und verlangt trotzdem einen nutzbaren Kernforecast.

## 0.9.53.15

- Kernvorhersage gegen anhaltende Open-Meteo-HTTP-429 nach App-Reaktivierung gehärtet: foreground-first Worker-Proxy mit Edge-Cache und 18-h-Stale-Fallback.
- Forecast-Cache toleriert GPS-Jitter und migriert vorhandene v1-Cacheeinträge; ein Neustart verliert den letzten belastbaren Stand nicht mehr wegen geringfügig veränderter Standortkoordinaten.
- Direkter Open-Meteo-Zugriff bleibt als Rückfallpfad erhalten.

# 0.9.53.14

- Buildfix nach fehlgeschlagenem Installerlauf: TravelPlanner-Regressions lösen den neu zentralisierten `openMeteoGuard` im temporär kompilierten ESM-Test korrekt als `.js` auf; Produktionscode und Open-Meteo-Guard bleiben unverändert.

- TypeScript-Buildfix für den Open-Meteo-Guard: `RequestInit.signal` wird vor Queue-/Wait-Helfern von `AbortSignal | null | undefined` auf `AbortSignal | undefined` normalisiert; behebt den GitHub-TS2345-Produktionsbuild ohne funktionale Änderung der Rate-Limit-Logik.

- 7-Tage-PoP wieder DWD-nah: 00–24 h oder nur bei klar isoliertem Schwerpunkt ein klassisches 6-h-Fenster; bei 0 % ohne Zeitfenster.
- Appweiter Open-Meteo-Request-Guard mit Priorisierung, Deduplizierung, begrenzter Parallelität und gemeinsamem 429-Cooldown.
- Favoriten-/Resume-Resilienz: Kernvorhersage mit Fresh-/Stale-Cache; bei Rate Limit bleibt die letzte erfolgreiche Wetterlage sichtbar und MID versucht automatisch erneut, statt rohes `HTTP 429` als Vollfehler zu zeigen.
- Wetterzwilling, Event-Flugwetter, Meteogramm, Berg-/Wintersport, Referenzdaten, Saison- und Reise-Klimadaten auf denselben Open-Meteo-Schutzpfad gezogen.
- Neue Required-Regression `test-dwd-pop-and-openmeteo-rate-guard-095314.mjs`; Worker fachlich unverändert.

# 0.9.53.13

- Event-Favoriten und normale Ortsfavoriten strikt getrennt; gleiche Orte dürfen gleichzeitig in beiden Favoritenarten geführt werden.
- Geräte-Sync führt Event-Favoritenrevision und Wetterplan unabhängig zusammen.
- Event-Ortssuche auf appweite Live-Suche mit Debounce, Request-Abbruch, PLZ/ICAO/POI und mobiler Search-Semantik umgestellt.
- Neue Required-Regression `test-event-favorite-search-independence-095313.mjs`; Worker fachlich unverändert.

# 0.9.53.12

- Event-Persistenz an der eigentlichen Speicherursache korrigiert: quota-sicherer Durable-Store ist für Eventdaten und Refresh-Marker nun direkt maßgeblich, statt von einer überschreibbaren `localStorage`-Methode abzuhängen.
- Bei iOS/Safari konnte ein Quota-Fallback bereits den neuen Eventplan in IndexedDB/Fallback speichern, während ein älterer nativer `localStorage`-Wert weiter bevorzugt gelesen wurde. Dadurch erschien dauerhaft z. B. „Stand 13.08., 07:41“, obwohl Refreshes tatsächlich liefen.
- Durable Reads priorisieren jetzt den gespiegelt neuesten Wert; Event-Center liest und schreibt seine Daten explizit über diese Schicht. Cross-Tab-Storage-Änderungen synchronisieren den Fallback mit.
- Alle bisherigen Reload-, Modelllauf-, Hintergrund- und Geräte-Sync-Regeln bleiben bestehen; neue Required-Regression `test-event-durable-storage-fallback-095312.mjs`.
- Worker fachlich unverändert.

# 0.9.53.11

- Event-Refresh grundlegend korrigiert: ein erfolgreich später gestarteter Fresh-Reload ist nun die maßgebliche Persistenzfrische; optionale/partielle Modellmetadaten dürfen einen neuen Plan nicht mehr wegen einer niedrigeren Quellenrevision blockieren.
- Der konkrete Rücksprung auf alte Event-Stände (z. B. 13.08., 07:41) wird damit an der eigentlichen Ursache behoben: Quellenrevision ist nur noch Provenienz/Tie-Breaker, nicht Commit-Autorität.
- Nach jedem Event-Refresh wird der Plan aus LocalStorage erneut gelesen; erst ein tatsächlich dauerhaft gespeicherter neuer Transaktionsstand gilt als erfolgreicher Reload.
- Geräte-Sync und geöffnete Eventdetails verwenden dieselbe transaktionsbasierte Frischeordnung, sodass ältere Remote-/UI-Snapshots den neuen Stand nicht zurücksetzen können.
- Modelllaufüberwachung bleibt vollständig aktiv: neue Läufe lösen weiterhin die zentrale Event-Neuberechnung aus, ohne selbst die Persistenzreihenfolge zu dominieren.
- Neue Required-Regression `test-event-refresh-transaction-authority-095311.mjs`; bestehende Event-Refresh-/Sync-Regressionen auf den korrigierten Frischevertrag aktualisiert.
- Security-Patches aus v0.9.53.10 (nanoid 3.3.18, protocol-buffers-schema 3.6.1) bleiben enthalten. Worker fachlich unverändert.

# 0.9.53.10

- Security-Wartung nach nächtlichem Dependency-Audit: nanoid im kompatiblen 3.x-Pfad auf 3.3.18 und protocol-buffers-schema auf 3.6.1 angehoben.
- Bestehende nächtliche Dependency-Regression verschärft und um protocol-buffers-schema ergänzt; keine Major-/Toolchain-Migration.
- Dependency-Upgrade-Policy um sofortige kompatible Security-Patches ergänzt.
- Worker fachlich unverändert; kein funktionaler Worker-Upload erforderlich.

# 0.9.53.9

- Event-Wetteraktualisierung vollständig aus der lazy EventPlanner-UI herausgelöst: zentraler appweiter Refresh-Broker und eigenständige Event-Wetterengine.
- Alle Reload-Wege (App-Kopfzeile, Event-Center-Popover, Event-Übersicht, Einzelkarte und Detail) verwenden denselben awaitbaren Fresh-Refresh und lesen nach dem Commit den persistenten Stand neu ein.
- Serielle Per-Event-Queue plus 55-s-Transaktionsgrenze verhindert verspätete Rückschreibungen und dauerhaft blockierende Hintergrundrequests.
- Event-Persistenz, geöffnete Details und Geräte-Sync priorisieren Modell-/Quellenrevision und Refresh-Start vor einem bloß späteren `refreshedAt`.
- Event-Monitor startet unabhängig von der geöffneten Sektion; Start/Resume/Fokus/Online, 5-Minuten-Stale-Check, neue Modellläufe und 30-Minuten-Fallback lösen passende Neubewertungen aus.
- Favoriten-Sammelläufe bleiben vollständig; allgemeine 20-Event-Grenze gilt nicht für Favoriten oder explizite Modelllauf-Ziele.
- Neue Required-Regression `test-event-refresh-broker-model-runs-09539.mjs`; bestehende Event-/Modell-/Hyperlokal-Verträge auf die UI-unabhängige Engine umgestellt.
- Worker fachlich unverändert; kein Worker-Upload erforderlich.

# 0.9.53.8

- Aktuelles Wetter: Piktogramme wechseln am standortbezogenen Sonnenauf-/untergang und werden bei Resume/Fokus neu bewertet.
- Event-Refresh-Aufträge werden persistent nachgeführt; 5-Minuten-Fälligkeitsprüfung und geschützter 30-Minuten-Autorefresh ergänzt.
- Frühere Event-Refresh-Koordination blieb noch an einer versteckten/lazy EventPlanner-Instanz gekoppelt und wird mit v0.9.53.9 vollständig ersetzt.

# 0.9.53.7

- Event-Center: verhindert Rücksprung auf alte Wetterstände nach erfolgreichem Reload.
- Geräte-Sync führt Event-Pläne konfliktfest nach `plan.refreshedAt` zusammen und schützt lokale Änderungen, die während eines laufenden Pull/Push entstehen.
- Lokaler Event-Store verwirft verspätete ältere Plan-Schreibvorgänge.

# 0.9.53.6

- Hyperlokale 2-m-Temperatur erkennt stabile, schwachwindige Nächte nur bei tatsächlich erhöhter räumlicher Temperatur-/Residualstreuung.
- Temperaturresiduen werden dann dynamisch enger lokalisiert; nahe standortähnliche Messpunkte gewinnen, entfernte bzw. thermisch unähnliche Stationen werden stärker gedämpft.
- Entfernte Flugplatz-/METAR-Temperaturen werden für urbane/suburbane Zielpunkte im stabilen Nachtregime konservativer gewichtet, ohne METAR-Wind/Sicht/Wolken abzuwerten.
- Kein pauschaler Nachtabschlag: Korrekturen bleiben vollständig beobachtungs- und modellresidualgestützt.
- Hyperlokal-Info zeigt aktives thermisches Nachtregime, Gewichtungsreichweite und Stationsstreuung.
- Neue Required-Regression `test-stable-night-hyperlocal-temperature-09536.mjs`; Tages-, Wind-, Bewölkungs- und Homogenitäts-Gegenproben enthalten.
- Worker fachlich unverändert; kein Worker-Upload erforderlich.

# 0.9.53.5

- Appweiter Reload aktualisiert gespeicherte Events bis zum sichtbar neuen `Stand`; Event-Refresh hängt nicht mehr von einem bereits vollständig geladenen Ortsforecast ab.
- Optionale langsame Zusatzquellen können den Kern-Eventrefresh nicht mehr unbegrenzt blockieren.
- LocalStorage, Event-Ref und sichtbarer Event-State werden nach erfolgreicher Neuberechnung gemeinsam aktualisiert.
- Glockenlogik bleibt meteorologisch relevant: ein neuer Zeitstempel allein erzeugt keine rote Änderung.
- Worker fachlich unverändert; kein Worker-Upload erforderlich.

# 0.9.53.4

- Events & Aktivitäten: alle Reload-Schaltflächen erzwingen jetzt eine echte Neuberechnung statt Wiederverwendung der bereits gerenderten Ortsvorhersage.
- Forecast-Fusion und Event-Ensemble umgehen beim expliziten Reload lokale Fresh-Caches; der Worker unterstützt `refresh=1` und umgeht dabei den 20-Minuten-Upstream-Cache.
- Automatischer 30-Minuten-Eventrefresh nutzt denselben Fresh-Pfad.
- Hyperlokaler Info-Button rechts innerhalb der bestehenden Analysekarte positioniert, ohne zusätzliche Kartenhöhe.
- Worker funktional geändert; Cloudflare-Upload erforderlich.

# 0.9.53.3

- Tages-Niederschlagswahrscheinlichkeit wieder mit 00–24-h- bzw. klar erhöhtem 6-h-Zeitfenster.
- Best-Match-Fallback bleibt als stündliches Maximum transparent gekennzeichnet.
- Niederschlagsdauer wird bei vorhandener Dauer kompakt in ganzen Stunden ergänzt.

# 0.9.53.2

- Hyperlokale Analyse platzsparend verdichtet; Details hinter Info.
- Event-Aktualisierung repariert: echte Neuberechnung und sofortige Synchronisierung des sichtbaren Stand-Zeitpunkts.

# MID Changelog

## 0.9.53.1

- CI-/Regressions-Hotfix für v0.9.53.0: vier veraltete bzw. durch die neue Architektur überholte Assertions an den aktuellen Funktionsvertrag angepasst.
- Event Center: Favoritenlauf prüft alle aktiven Favoriten; die 20er-Grenze gilt nur für den allgemeinen Hintergrundlauf.
- Hyperlokale Analyse: dynamische Ergebniswerte (Modellhintergrund, lokale Korrektur, Gelände, Windexposition und Oberflächenkontext) bleiben im erweiterten Modus direkt sichtbar; nur Methodik/Erklärung liegt hinter dem Info-Hinweis.
- ICON-D2-RUC-Regression an den optionalen Worker-Punktadapter und den weiterhin gültigen Availability-only-Rohdatenpfad angepasst.
- Forecast-Fusion-Regression an den env-fähigen Worker-Aufruf `forecastFusionResponse(u,env)` angepasst.
- Keine neue kostenpflichtige RUC-Infrastruktur und keine Aktivierung eines RUC-Punktdecoders.
- Worker fachlich unverändert; kein Worker-Upload erforderlich.


## 0.9.53.0

- Event Center: automatische Neubewertung aktiver Events bei sichtbarer App sowie Catch-up nach Wiederaufnahme/Fokus; zusätzlicher `Neu laden`-Button direkt im Glocken-Popover.
- Bergwetter: zentrale DWD-Näherung der Schneefallgrenze aus T850 und tatsächlichem Z850 mit 0,65 K/100 m und +2-°C-Schneefallgrenzenansatz; Ensemble-Spread wird in Höhenunsicherheit übertragen.
- Gezeiten: `Flut`/`Ebbe` statt `Hochpunkt`/`Tiefpunkt`.
- Eventplaner: kompakter Niederschlagsblock ohne Zusatzwort `Zeitraum`; Niederschlagsart-Symbol statt `PoP` in den Details.
- Hyperlokale Analyse: statische/methodische Erklärungen der erweiterten Ansicht in appweites Info-Popover verschoben.
- ICON-D2-RUC: optionaler numerischer Worker-Punktadapter (`MID_DWD_RUC_POINT_ENDPOINT`) ergänzt; direkte DWD-Verfügbarkeitsprüfung bleibt erhalten.
- Copernicus CLMS: direkte LCM10-Abfrage über CDSE/Sentinel-Hub Statistical API mit OAuth-Client-Credentials; GIS-Oberflächenkontext vor OSM-Proxy priorisiert.
- Hyperlokale Exposition: acht richtungsabhängige DEM-Sektoren, Interpolation zur aktuellen Modellwindrichtung und konservative dynamische Wind-/Böenkorrektur unter Einbezug der Rauigkeit.
- Synoptik: aktuelle DWD-Synoptische Übersichten Kurz-/Mittelfrist als kontrollierte Fachvokabularquelle; keine Übernahme fremder Textpassagen.
- Neue Required-Regression `test-mid-nine-step-integration-09530.mjs`.
- Worker funktional geändert; Worker-Upload erforderlich.


## 0.9.52.3

- Appweiter Responsivitäts-/Touch-Cleanup ohne Funktionsabbau: native Einzelaktivierung für einklappbare Dashboardmodule statt paralleler Pointer-/Click-Umschaltung.
- Forecast-Cockpit-Hitflächen lösen die Auswahl nur noch einmal über den nativen Click-Pfad aus; redundante PointerDown-/TouchStart-State-Updates entfallen.
- Ortssuche auf iOS stabilisiert: Treffer bleiben beim Fokusverlust des Eingabefelds erhalten und werden erst über den bestehenden Außenklick-/Fokuswechsel-Mechanismus geschlossen, sodass der erste Tap auf einen Treffer zuverlässig ankommt.
- Appweiter Touchvertrag ergänzt (`touch-action: manipulation`, unterdrückte Tap-Highlights/Touch-Callouts, dekorative SVGs ohne eigenes Hit-Target).
- Kompakte Touch-Controls erhalten auf groben Zeigern mindestens 36 px Trefferhöhe/-breite, ohne Desktop-Dichte oder Funktionen zu verändern.
- Neue Required-Regression `test-appwide-touch-responsiveness-09523.mjs`.
- Worker fachlich unverändert; nur Versionssynchronisation.

## 0.9.52.2

- Regression-Hotfix: `test-hyperlocal-quality-audit-08200.mjs` an den seit v0.9.52.0 verpflichtenden Oberflächenkontext angepasst.
- Eine hochwertige Stationsanalyse gilt nur dann als vollständig, wenn `surfaceClass` vorhanden ist; fehlender Oberflächenkontext löst weiterhin bewusst die DGM-/Landnutzungs-/Rauigkeitsanreicherung aus.
- Keine Änderung an meteorologischer Hyperlokal-, DWD-10-Minuten-, DGM-, Versiegelungs-, UHI-, Rauigkeits- oder Wetterzwilling-Logik.

## 0.9.52.1

- Build-Hotfix: `LocalSurfaceContext` erfüllt jetzt den Fehlervertrag von `fetchWorkerJson<T extends WorkerPayload>`.
- Keine Änderung an Hyperlokal-, DGM-, DWD-10-Minuten-, Versiegelungs-, Rauigkeits- oder Wetterzwilling-Logik.
- Neue Required-Regression `test-local-surface-worker-payload-type-09521.mjs`.

## 0.9.52.0

- Hyperlokale Qualitätsstufe 2: direkte DWD-CDC-10-Minuten-Netze für Temperatur/Feuchte, Mittelwind/Windrichtung, Böenspitzen und Niederschlag; zusätzlich das DWD-Stadtklima-10-Minuten-Netz für urbane Thermodynamik.
- Kleine CDC-ZIP-Produkte werden im Worker nativ per `DecompressionStream('deflate-raw')` gelesen; Feldzeitstempel und native 10-Minuten-Auflösung bleiben erhalten.
- Copernicus-DEM-GLO-90-Mikroreliefprofil für Ziel und Stationskandidaten: Hangneigung, Exposition/Aspekt, lokales Relief sowie Kuppen-/Senkenposition beeinflussen parameterabhängig die Restfeldübertragung.
- Oberflächenkontext ergänzt: exakter GIS-Punktadapter für Versiegelung, LCZ, Bebauungsanteil und Rauigkeitslänge; ohne Adapter ausschließlich klar gekennzeichneter OpenStreetMap-Morphologieproxy.
- Thermische Standortähnlichkeit berücksichtigt bei echten GIS-Daten Versiegelungsunterschiede stärker nachts und bei schwachem Wind; kein pauschaler UHI-Temperaturzuschlag.
- Wind-Restfelder werden bei stark unterschiedlicher Oberflächenrauigkeit bzw. Kuppen-/Abschirmungslage deutlicher gedämpft; kein blindes logarithmisches Windprofil ohne bekannte Modell-/Stationsrauigkeit.
- Keine doppelte pauschale Höhenkorrektur: der bereits höhen-downskalierte hochaufgelöste Modellhintergrund bleibt Basis; DEM dient zur Morphologie- und Übertragbarkeitsbewertung.
- Fast-Analyse wird bei fehlendem Oberflächenkontext automatisch durch eine vollständige Qualitätsanalyse angereichert.
- Neuer verbindlicher `MID_HYPERLOCAL_DOWNSCALING_CONTRACT.md` und Required-Regression `test-hyperlocal-downscaling-09520.mjs`.

## 0.9.51.0

- Hyperlokale Analyse konsequent parameterbezogen: harte Alters-, Distanz- und Höhengrenzen verhindern übermäßigen Einfluss alter/weiter Messwerte.
- Feldzeitstempel und native Datenintervalle werden getrennt transportiert; kein künstliches Verjüngen alter Temperatur durch aktuellere andere Stationsfelder.
- Restfeldkorrektur ohne festen Mindestanteil; hochaufgelöste Regionalmodelle dienen landesabhängig als Hintergrund vor Best Match.
- Stadt/Land/Suburban- und Höhenanpassung präzisiert; generische PPL-Orte werden nicht mehr pauschal urban gewertet.
- Hochfrequente amtliche Beobachtungen ausgebaut: DWD/GeoSphere/KNMI/MeteoSwiss-Metadaten sowie SMHI-Minutenparameter.
- Aktuelles Wetter, Kurzfrist und Event-Anker auf gemeinsame feldbezogene Frische-/Repräsentativitätsprüfung umgestellt; die Haupttemperatur gilt nur bei selbst frischer Temperaturquelle als stationsgeprüft.
- Wetterzwilling-Lernreferenzen ebenfalls feldweise abgesichert: alte Temperatur/Niederschlag/Böe/Bewölkung werden nicht mehr über einen jüngeren fremden Stationsparameter mitarchiviert.
- Neuer verbindlicher `MID_HYPERLOCAL_ANALYSIS_CONTRACT.md` und Required-Regression `test-hyperlocal-parameter-relevance-09510.mjs`.

## 0.9.50.0
- UI-/Architekturstandardisierung ohne Funktionsabbau: gemeinsame `AppPortalPopover`-Primitive für appweite verankerte Popover und Forecast-Cockpit.
- `AppInfoHint` nutzt nur noch die gemeinsame Body-Portal-/Außenklick-/Escape-/Scroll-Positionierungslogik.
- Neuer verbindlicher `MID_UI_ARCHITECTURE_CONTRACT.md` für neue Sektionen, Menüs, Tooltips, Drawer, Zeit-/Einheitenformatierung, Responsive-Verhalten und kanonische Fachpfade.
- Neue Regression verhindert künftig generische Portal-/Dismiss-Kopien in neuen Dateien; spezialisierte Ensemble-Charttooltips bleiben eng begrenzte Ausnahme.

## 0.9.49.1

- Event-PoP visuell eindeutig als **Zeitraumwahrscheinlichkeit** gekennzeichnet; ausgewerteter Start-/Endzeitraum steht direkt an der Niederschlagskachel.
- Stündliche Event-Niederschlagswerte an die Open-Meteo-Semantik „vorangehende Stunde“ angepasst: nur tatsächlich mit dem Event überlappende Intervalle werden dargestellt und summiert.
- Teilstunden werden für Mengen zeitanteilig zugeschnitten; Einzelstunden-PoP bleibt als Wahrscheinlichkeit des jeweils ausgewiesenen Stundenintervalls erhalten.
- Der bisherige ±30-Minuten-Punktfilter wurde für Event-Niederschlag entfernt, damit z. B. die 12:00-PoP (11–12 Uhr) nicht fälschlich in ein ab 12:00 Uhr beginnendes Event einfließt.
- Neue Regression `test-event-period-pop-alignment-09491.mjs`.

## 0.9.49.0

- Event-Niederschlagswahrscheinlichkeit jetzt für den **exakten Start-/Endzeitraum** aus echten Ensemble-Mitgliedern mit den appweiten DWD-nahen Schwellen >0,2 mm und >5,0 mm berechnet; Modellfamilien werden entkorreliert, Stunden nur nach tatsächlicher Zeitüberdeckung gewertet.
- Bei unzureichender Ensembleabdeckung bleibt das bisherige Stundenmaximum ausschließlich als klarer Fallback erhalten.
- Wetterzwilling geprüft und an v0.9.48.x-Endstufe angepasst: lokal validierte Temperatur-/Böen-Biases gelten nun auch für abweichende Eventorte mit vorhandenem Lernstand; Events am aktiven Ort übernehmen den bereits angewandten Twin-Status korrekt.
- Doppelten Wetterzwilling-Radarblend entfernt: operativer Radar-/Konvektiv-Nowcast läuft ausschließlich über die gemeinsame `finalizeForecastHours(...)`-Endstufe; der Twin-Schalter steuert nur noch Radarlernen/Rückblick.
- Neue Regression `test-event-pop-weather-twin-09490.mjs`; bestehende Event-/PoP-/Twin-/Radarverträge fortgeschrieben.

## 0.9.48.1

- Release-Pipeline: veraltete versionsfeste TS18048-Regression auf fortlaufenden Schutzvertrag umgestellt.
- Wetterzwilling-Regression an die zentrale finale Forecast-Pipeline von v0.9.48.0 angepasst.
- Keine fachliche Änderung an Event-, Astronomie- oder Hyperlokallogik.

## 0.9.48.0

- Event-Wetter nutzt app-weit dieselbe finale MID-Prognosekette wie die reguläre Ortsvorhersage; am identischen aktiven Ort werden exakt dieselben finalisierten Stundenwerte übernommen.
- Sonne/Mond-Astronomie vollständig auf Astronomy Engine 2.1.19 vereinheitlicht: Auf-/Untergänge, Dämmerung, Mondphase/-beleuchtung/-alter und Finsternis-Sichtbarkeit aus einer gemeinsamen Ephemeridenbasis.
- Hyperlokale Stationsanalyse nach v0.9.47-Quellenausbau neu kalibriert: GMA/Straßenwetter für allgemeine Luftwerte deutlich gedämpft und nahe geeignete Stationen mit sanftem Lokalitätsbonus versehen.
- Neue Regression `test-event-astronomy-hyperlocal-consistency-09480.mjs`; v0.9.47-Quellenbroker-Regression versionsfortschreibungsfest gemacht.

# MID v0.9.47.1

- Build-Hotfix für v0.9.47.0: die parameterbezogene Messquellenanzeige gibt ihre Quellenzeilen jetzt explizit als `StationFieldSource[]` zurück.
- Dadurch sind `rows`, `rows.length`, `rows[0]` und `group.rows.map(...)` unter TypeScript `strictNullChecks` nicht mehr fälschlich als möglicherweise `undefined` typisiert.
- Keine fachliche Wetter-, Quellen-, Ensemble-, UI- oder Worker-Logik gegenüber v0.9.47.0 geändert; der Worker ist nur versionssynchronisiert.
- Neue Regression `test-current-source-info-type-safety-09471.mjs` schützt den Buildvertrag.

# MID v0.9.47.0

- „Aktuelles Wetter“ nutzt für Deutschland direkte DWD-SYNOP/POI-Beobachtungen vor dem bisherigen Bright-Sky-Rückfall.
- Länderabhängiger amtlicher Beobachtungsbroker ergänzt: direkte Pfade für SMHI, FMI, NWS/MADIS und ECCC/SWOB-GeoMet; GeoSphere bleibt für Österreich erhalten; AEMET ist mit Worker-Secret nutzbar. MeteoSwiss, KNMI, Météo-France und DWD-Straßenwetter besitzen explizite numerische Punktadapter.
- Quellenbewertung bleibt parameterbezogen. Straßenwetter/GMA ist als `road-weather` spezialisiert und darf allgemeine Wind-, Sicht-, Wolken- oder Niederschlagswerte nicht wegen bloßer Nähe dominieren.
- Hyperlokale Analyse führt nun je Parameter konkrete Herkunftsmetadaten (Quelle, Station, Entfernung, Messzeit und QC); die erweiterten Info-Popover von „Aktuelles Wetter“ zeigen diese Herkunft an.
- Ensemblekatalog erweitert: HGEFS ausschließlich als Mittel/Spread; KNMI HARMONIE-AROME Cy43 EPS und ECCC REPS als regionale, gebiets- und horizontbegrenzte Ensemblequellen mit Familien-/Abhängigkeitsgruppen.
- Regionale Direktmodelle werden ausschließlich über numerische Punktadapter geladen; es gibt keinen stillen Open-Meteo-Fallback mit unbekannten Modellkennungen und keine erfundenen Einzelmitglieder.
- Bewusst kein allgemeiner BUFR-/GRIB-Decoder im Worker; binäre amtliche Produkte werden nur über dokumentierte numerische Adapter angebunden.
- Worker funktional erweitert; Deployment des neuen Workers ist erforderlich.

# MID v0.9.46.0

- Events & Aktivitäten: kompakte Böenabkürzung **G** statt **B**.
- Aktivität Flug nutzt amtliche ICAO-SIGMET/TAF, bei Nahterminen METAR/SPECI und PIREP/AIREP sowie regionale AWC-Hazardprodukte.
- WAFS-SIGWX beider WAFC wird über den autorisierten WIFS-API-Pfad standort- und zeitbezogen ausgewertet; Polygon- und Punktgeometrien sowie Hazard-/Intensitätskennungen aus IWXXM-Attributen werden berücksichtigt.
- Optionaler direkter KNMI-AIRMET-/SIGMET-Pfad für die Amsterdam FIR ergänzt; weitere nationale SWC-Spezialprodukte werden nur bei dokumentierter API-/Nutzungsfreigabe angebunden.
- Quellenstatus und technische Hintergründe liegen hinter dem Info-Button; die Hauptansicht bleibt kompakt.
- Neuer Worker-Modus `aviation-hazards`; Worker-Deployment ist erforderlich.

# MID v0.9.45.5

- CI-/Regression-Hotfix für den fehlgeschlagenen v0.9.45.4-Installerlauf.
- Historische Funktionssuite `test-feature-suite-0797.mjs` auf den aktuellen Standortvertrag synchronisiert: der veraltete Quellcode-Zwang `locate(false)` wurde entfernt.
- Die aktive Standortlogik bleibt unverändert: gespeicherter/manueller Ort bleibt geschützt; die separate aktuelle GPS-Standortermittlung wird weiterhin durch die neueren Standort-/Favoriten-Regressionen abgesichert.
- Keine fachliche Wetter-, Event-, Planer-, UI- oder Worker-Änderung gegenüber v0.9.45.4.

# MID v0.9.45.2

## Sonne / Mond

- Nächste standortrelevante Sonnen- oder Mondfinsternis mit zukünftigem Maximum, Datum, Detailzeiten und sinnvoller Verdeckungsangabe ergänzt.
- Sonnenfinsternisse werden lokal berechnet; reine Halbschatten-Mondfinsternisse werden ohne irreführende 0-%-Angabe ausgewiesen.

# MID v0.9.45.2

- **Events & Aktivitäten kompakter:** gespeicherte Events zeigen zunächst nur Titel, Rahmen/Aktivität, Termin, Ort und Wetter-Kernwerte.
- Analyseheadline, Bewertung, Änderungsdetails sowie Bearbeiten/Aktualisieren/Löschen liegen jetzt in einer gezielt aufklappbaren Detailansicht.
- Der Favoritenstern bleibt direkt in der Kurzansicht erreichbar; Mehrfachfavoriten bleiben unverändert unterstützt.
- Das Event-Center unter der Glocke nutzt dieselbe progressive Darstellung: kompakte Eventzeile, aufklappbare Zusatzinfo und eindeutiger Sprung in den vollständigen Eventplaner.
- Abstände, Kartenhöhen, Aktionsflächen und Mobile-Layout wurden weiter verdichtet; Hell-/Dunkel-Design bleibt über die bestehenden MID-Themevariablen konsistent.
- Neuer Regressionstest `test-event-progressive-disclosure-09451.mjs`.

# MID v0.9.45.0

- Neue sichtbare Dashboard-Sektion **Planer** bündelt Eventplaner und Reiseplaner.
- Beide Planer bleiben in den Einstellungen weiterhin separat aktivier- und deaktivierbar.
- Eventplaner: **Rahmen** und **Aktivität** jetzt deutlich kompakter als platzsparende, umbrechende Chips statt großflächiger Kacheln.
- Neuer Regressionstest `test-planner-section-compact-event-controls-09450.mjs`.

# MID v0.9.44.0

- Event-Center: chronologische Standardsortierung plus wählbare Sortierung.
- Gespeicherte Events sind nun eindeutig bearbeitbar.
- Wind wird zusammen mit Böen ausgegeben.
- Niederschlags-% werden an die dominante plausibilisierte Niederschlagsform gekoppelt.

# MID v0.9.43.0

- **Event-Center mit echten Mehrfachfavoriten:** mehrere gespeicherte Events können gleichzeitig favorisiert und gemeinsam nacheinander aktualisiert werden; ein zuvor geladenes Event überschreibt beim Anlegen eines neuen Termins keinen anderen Favoriten mehr.
- Event-Center und Eventplaner für **helles und dunkles Design** neu abgestimmt; Status-, Änderungs- und Favoritenfarben verwenden theme-adaptive Kontraste.
- Primäransicht deutlich verdichtet: erklärende Hintergrundtexte, Modellmethodik und Update-Hinweise liegen hinter kompakten Info-Bedienelementen.
- Texte und Statusbezeichnungen vereinheitlicht und professioneller formuliert; unnötige Wiederholungen in Ergebnis- und Eventkarten entfernt.
- Eventparameter an die appweiten Formatregeln angeglichen: gewählte **Windeinheit** wird übernommen, **UVI wird ganzzahlig** dargestellt, Niederschlagswahrscheinlichkeit und Sicht bleiben konsistent formatiert.
- Neue Aktivität **Flug**. Zusätzlich zum normalen Event-Wetter führt MID ein Flugwetter-Screening aus Druckniveau-Daten durch: Gewitter/Konvektion, Vereisung, Turbulenz, CAT, Wolkenuntergrenze, Sicht und Böen; Nullgradgrenze wird ergänzend ausgewiesen.
- Flugwetter-Hazards sind ausdrücklich diagnostische MID-Indikatoren und keine amtliche Flugwetterberatung oder Navigationsgrundlage.
- Neuer Regressionstest `test-event-center-flight-multifavorite-09430.mjs` schützt Mehrfachfavoriten, Flugaktivität, Flugwetter-Hazards, Theme-Kontrast, Info-Verdichtung sowie appweite UVI-/Windeinheiten.

# MID v0.9.42.0

- **Event-Center deutlich unauffälliger:** der große Dashboard-Block entfällt; gespeicherte Events sind jetzt über eine kompakte Glocke in der Top-Leiste erreichbar.
- Bei ungesehenen Änderungen erhält die Glocke einen dezenten roten Statuspunkt und Akzent. Das Popover zeigt die nächsten Events und führt direkt zum jeweiligen Eintrag im Eventplaner.
- Technisches Status-Wording korrigiert: statt „Einschätzung jetzt Achtung statt beobachten“ erscheinen natürliche Formulierungen wie „Bewertung verschärft: jetzt „Achtung“ (zuvor „Beobachten“).“
- Bereits gespeicherte alte Event-Center-Texte werden beim Einlesen automatisch in die neue Form migriert.
- Navigation neu geordnet: Berg-/Wintersport und Wassersport liegen unter **Profile**; **Eventplaner** und **Reiseplaner** gemeinsam unter der neuen Oberkategorie **Planer**.
- Eventplaner und Reiseplaner bleiben in den Dashboard-Einstellungen jeweils separat aktivier- und deaktivierbar.
- Neuer Regressionstest `test-event-center-topbar-planner-group-09420.mjs` schützt die neue Topbar-, Text- und Planerstruktur.

# MID v0.9.41.7

- CI-/Regressionsfix für den fehlgeschlagenen v0.9.41.6-Installerlauf: zehn veraltete Testverträge auf den tatsächlich bereits in v0.9.41.5/v0.9.41.6 eingeführten Stand synchronisiert.
- Forecast-Fusion-Cache v7 und Ensemble-Cache v12 sind nun auch in allen historischen Schutztests konsistent hinterlegt; die beabsichtigte Cache-Migration bleibt unverändert.
- Navigationstest erwartet jetzt `Profile & Planung`; AIFS-Metadatenprüfung nutzt die exakte aktuelle `ecmwf_aifs025_single`-ID.
- Ensemble-Modellprüfung behandelt `bom_access_global` korrekt als gültige deterministische Modellkennung und verwechselt sie nicht mehr mit einer veralteten Ensemble-ID.
- Keine funktionale Wetter-/UI-Änderung gegenüber v0.9.41.6; ausschließlich Build-/CI-Stabilisierung.

# MID v0.9.41.6

- **Wetterplaner auf gemeinsamen MID-Vorhersagepfad umgestellt:** Event-Auswertungen verwenden dieselbe Mehrmodell-Fusion, Radar-/Nowcast-Korrektur, konvektive Plausibilisierung und zentrale `precipitationParts()`-Logik wie Kurzfrist, 7-Tage und Dashboard. Sprühregen, Schauer und konvektiver Niederschlag werden dadurch nicht mehr in einer separaten Parallel-Logik bewertet.
- Wettertitel, Piktogramme und Niederschlagsbeschreibung im Event-Center werden aus dem plausibilisierten Stundenpfad abgeleitet; für Termine im Nowcast-Fenster fließen vorhandene Radar-/Gewittersignale ein.
- **App-weite Modellfamilienprüfung:** Forecast-Fusion, Ensemble und Schneefallgrenze unterscheiden jetzt Modellvarianten/auflösungen von unabhängigen Modellfamilien. Mehrere Varianten derselben Unabhängigkeitsgruppe bleiben als Datenquellen/Fallback sichtbar, erhalten im Konsens aber nicht mehrfaches Gewicht.
- Rapid-Cycle-Modelle werden innerhalb ihrer tatsächlichen Vorhersagereichweite priorisiert. DWD ICON-D2-RUC/RUC-EPS bleiben als Verfügbarkeits-/Ausbaupfad gekennzeichnet, solange kein numerischer Adapter verfügbar ist; es werden keine Ersatzwerte erzeugt.
- NOAA-NBM und DWD-MOSMIX werden als Postprocessing behandelt und nicht als zusätzliche unabhängige Modellstimme gewertet.
- Ensemblegewichtung gruppiert DWD-, NOAA-, ECMWF-, CMC-, UKMO- und MeteoSwiss-Varianten nach Unabhängigkeitsgruppe; Szenarioanteile und Modellzahlen folgen derselben Familienlogik. Ensemblecache auf v12 angehoben.
- Schneefallgrenze gruppiert ECMWF IFS/AIFS und andere Varianten familienweise; die Varianten bleiben sichtbar, verdoppeln aber nicht das Familiengewicht.
- Saison-/Langfristpfad behält die bereits vorhandene Deduplizierung nach Modellfamilie bei.
- Forecast-Fusion-Cache auf v7 angehoben, damit alte Ergebnisse mit früherer Gewichtungslogik nicht wiederverwendet werden.
- Neuer Regressionstest `test-model-family-consistency-09416.mjs` schützt Wetterplaner-Plausibilisierung, Rapid-Cycle-Reichweiten, unabhängige Modellgruppen, Postprocessing-Ausschluss, Ensemble-/Schneefallgrenzengewichtung und saisonale Familiendeduplizierung.

# MID v0.9.41.2

- Mobiles Temperatur-Ensemble-Tooltip korrigiert: Sonne, Niederschlag und Modelle verwenden eine gemeinsame Beschriftungsspalte mit sauber getrennter flexibler Wertspalte.
- Lange Metawerte umbrechen nur rechts und an natürlichen Trennstellen; insbesondere „Niederschlag“ läuft nicht mehr in den Werttext.
- Tooltip-Größe, Padding, Schriftgrößen, Temperaturmatrix und Desktop-Darstellung bleiben unverändert.

# MID v0.9.41.1

- CI-Kompatibilitätsfix: Die Langfrist-Methodik formuliert die gleichgewichtete Modellfamilienlogik wieder vertragskompatibel als „gewichtet Modellfamilien gleich“, ohne die fachliche Einschränkung auf unabhängige Modellfamilien zu verlieren.
- Keine Änderung an C3S-/DWD-Datenpfaden, Ensembleberechnung oder UI-Funktionalität gegenüber v0.9.41.0.

# MID v0.9.41.0

- **C3S numerisch vorbereitet:** Die neun aktuellen C3S-Zentren bleiben als Modellkatalog sichtbar; ein neuer serverseitiger CDS-/Worker-Pfad kann echte lokale monatliche Ensemblewerte von ECMWF, UK Met Office, Météo-France, DWD, CMCC, NCEP, JMA, ECCC und BOM dekodieren. Nicht konfigurierte Zentren bleiben ausdrücklich „Katalog“ und liefern keine Ersatzwerte; Kartenfarben werden niemals zu Zahlen rekonstruiert.
- Für echte C3S-Rauchfahnen ist `seasonal-monthly-single-levels` als numerischer Memberpfad vorgesehen; `seasonal-postprocessed-single-levels` kann die monatliche Anomalie-/Bias-Referenz liefern. Der Browser erhält ausschließlich normalisierte Punktwerte und Verteilungen.
- **DWD GCFS2.2 / EPISODES:** eigener Deutschland-Pfad für 3-Monats-Anomalien (Monate 1–3, 2–4, 3–5, 4–6), `tasAnom`/`prAnom`, Referenz 1991–2020 und `DE-015x01` (~10 km). Roh-QA `mse`/`corr_pea` sowie optional numerisch bezogene MSESS/RPSS werden unterstützt; GCFS2.1-Karten werden nicht als GCFS2.2 ausgegeben.
- Langfristansicht zeigt den Live-/Konfigurationsstatus der neuen Datenpfade, trennt C3S-Rauchfahnen von der DWD-Deutschlandperspektive und kennzeichnet C3S-Zentren eindeutig als **Numerisch** oder **Katalog**.
- Neue globale Einstellung **Informationsdichte: Auto / Kompakt / Komfortabel**. Auto reagiert auf Displaybreite und Hoch-/Querformat; die Einstellung wird über den bestehenden MID-Einstellungs-/Sync-Pfad persistiert.
- Mobile Bedienlogik vereinheitlicht: zentrale Popover reagieren auf Outside-Tap, Escape und Swipe-down; Touchflächen und Abstände folgen gemeinsamen MID-Größenvariablen.
- Dynamische Langfristlegenden: im Standardmodus zunächst kompakt, Details per Tippen; der erweiterte Modus zeigt die vollständige Diagnostik.
- Section-local Sticky Controls für Langfrist, Ensemble-Trend/Wind/Niederschlag und Wetterkarten halten Modell-/Zeitraum-/Layersteuerung in langen Ansichten erreichbar.
- Progressive Disclosure bleibt konsequent erhalten: technische Adapter-/Quellendetails erscheinen im erweiterten Modus statt in primären Bedienflächen.
- Sichtbarkeitsgesteuertes Rendering baut auf dem vorhandenen `ViewportGate` auf und umfasst nun zusätzlich Berg-/Wintersport; vorhandene iOS-Stabilitätsregeln werden nicht durch aggressives `content-visibility` überschrieben.
- Prognose-Cockpit bewahrt horizont-/sektionseigene Scrollpositionen beim Wechsel Kurzfrist/7/14 Tage; bestehende Tages-/Modellauswahlen werden nicht unnötig zurückgesetzt. Langfristmodell und Modellstreifenposition werden standortbezogen gespeichert.
- Release auf **v0.9.41.0** synchronisiert; neuer Regressionstest schützt C3S/DWD-Datenverträge, Informationsdichte, Sticky Controls, Gesten und Scroll-Restore.

# MID v0.9.40.16

- Favoritenleiste in den Einstellungen auf **Auto / Dauerhaft / Aus** umstellbar; Auto bewahrt das bisherige Verhalten.
- Dashboard-Sektionskonfiguration erhält **Standard wiederherstellen** und setzt Reihenfolge sowie Sichtbarkeit auf die MID-Defaults zurück.
- Auf-/Zuklappen von Modulen, insbesondere des Kompositbilds, auf Touchgeräten robuster: Bewegungsfilter und Unterdrückung des nachlaufenden Klicks verhindern Doppel-/Fehlauslösungen beim Scrollen.
- Niederschlagsart-Layer nutzt kompakte meteorologische Schwarzweiß-SVG-Symbole nach der gelieferten Vorlage. Unterstützt werden Schnee, Schneekörner, Schneeregen/Mischphase, gefrierender (Sprüh-)Regen, Graupel/Eiskörner und Hagel; reiner Regen bleibt ohne Zusatzsymbol.
- Technischer Fehlertext im Niederschlagsart-Schalter wird zu **Phasendaten nicht erreichbar** verkürzt; Details bleiben im Status-/Info-Bereich.
- Langfristansicht zu echter Rauchfahnen-Darstellung erweitert: P10–P90 über den gesamten Horizont, P25–P75 in der ersten Hälfte. ECMWF nutzt echte Memberquantile; alle im aktuellen NOAA-NMME-ENSMEAN-Lauf lesbaren unabhängigen Modellfamilien fließen gleichgewichtet in das Multi-Modell ein, CFSv2 E1/E2/E3 bleibt Fallback.
- Niederschlagsanomalien erhalten auch in mm/Tag echte P10/P25/P75/P90-Felder, soweit die Quelle Ensemble-/Initialisierungsdaten liefert.
- C3S-Modellkatalog bleibt als Ausbaupfad für ECMWF, UKMO, Météo-France, DWD, CMCC, NCEP, JMA, ECCC und BOM sichtbar; keine Rekonstruktion numerischer Punktwerte aus Kartenfarben.

# MID v0.9.40.15

- CI-/Regressionsbereinigung: drei veraltete Schutztests wurden auf den aktuellen Niederschlagsart-Vertrag mit Hagel und Graupel/Eiskörnern sowie den aktuellen Rapid-Update-Statuspfad migriert.
- Die neue Symbolerweiterung aus v0.9.40.14 bleibt unverändert erhalten; es wird keine Funktion zurückgenommen.
- Der neue Regressionstest für Layerstatus, Hagel und Graupel/Eiskörner ist nun Bestandteil des Baseline-Vertrags.
- Versionssynchronisierung umfasst jetzt auch package-lock, Service-Worker-Cache, public/version.json, Baseline und Worker.

# MID v0.9.40.14

- Komposit-Niederschlagsart gibt jetzt im Layerstatus eindeutig Rückmeldung, ob der Layer aktiv ist und ob im aktuell sichtbaren Ausschnitt momentan überhaupt feste, gemischte oder gefrierende Niederschlagsarten erkannt werden. So ist auch bei rein flüssigem Niederschlag nachvollziehbar, dass der Layer funktioniert.
- Die Symbolik wurde erweitert: zusätzlich zu Schnee, Mischphase und gefrierendem Niederschlag werden nun auch Hagel sowie Graupel/Eiskörner als kleine semitransparente meteorologische Symbole auf dem ausgewählten Radarbild dargestellt.
- Die Symbolgrößen bleiben bewusst klein, damit Staffelungen der Radarechos erkennbar bleiben; Hagel- und Graupelsymbole erhalten zugleich etwas stärkere Abstandsregeln, damit sie lesbar bleiben.
- Die Legende im Kompositbild erklärt nun auch, dass ein fehlendes Symbol bei aktivem Layer schlicht bedeuten kann, dass im aktuellen Ausschnitt keine feste bzw. gemischte Niederschlagsphase vorliegt.

# MID v0.9.40.9

- Niederschlagswahrscheinlichkeit app-weit vereinheitlicht: Ensemble-Tageswerte werden explizit als 00–24-h-Ereigniswahrscheinlichkeit bezeichnet und zusammen mit dem stärksten 6-h-Zeitfenster angezeigt.
- Mathematische Konsistenz abgesichert: Die 00–24-h-Wahrscheinlichkeit kann nicht unter der Wahrscheinlichkeit eines darin enthaltenen 6-h-Fensters liegen; Entsprechendes gilt für die >5-mm-Schwelle.
- Best-Match-Fallback eindeutig gekennzeichnet: statt eines scheinbaren Tageswerts erscheint „max. Std.“ für das Stundenmaximum.
- Ensembleübersicht, 7-Tage-/Cockpit-Tageskarten, klassische Vorhersage sowie Widget/PNG nutzen denselben 00–24-h-/6-h-Vertrag.
- Alle Komposit-/Radaränderungen aus v0.9.40.8 bleiben vollständig enthalten.

# MID v0.9.40.6

- TypeScript-Buildfix: `RadarPhase` wird wieder als Union-Typ aus `radarColorTables.ts` exportiert; dadurch sind die festen Niederschlagsartfarben ohne `any`-Indexierung typisiert.
- Farbtabellen-Scope unverändert: Auswahl ausschließlich für 1-km-/250-m-Radar, feste klassische Phasefarben im Niederschlagsartmodellradar.

## 0.9.40.5
- Korrektur der Radar-Farbtabellen: Auswahl gilt ausschließlich für das normale 1-km-Radar und das 250-m-PX/HX-Radar.
- Einstellungen enthalten dafür DWD Standard und DWD Starkregen mit kleiner Farbvorschau; beim 1-km-DWD-RV wird der offiziell dokumentierte WMS-Stil `Starkregen` verwendet.
- Das Niederschlagsartmodellradar besitzt keine Farbtabelle-Auswahl mehr und nutzt fest die klassischen meteorologischen Phasenfarben: Regen grün, Mischphase pink/violett, Schnee blau, gefrierender Niederschlag rot.
- Der temporäre v0.9.40.3-Latest-only-Eingriff in den normalen 1-km-Radarpfad wurde zurückgenommen; 1-km-DWD-Zeitframes und 250-m-PX/HX-Pfade bleiben wie im bewährten v0.9.40.2-Vertrag erhalten.

## 0.9.40.4
- Niederschlagsart-Radar erhält wählbare professionelle Farbtabellen (Meteo klassisch, Meteo kräftig, Barrierearm) inklusive kleiner Vorschau in den Komposit-Einstellungen.
- Legende des Niederschlagsart-Layers zeigt jetzt die aktive Farbtabelle samt Vorschau und Phasenfarben direkt im Kompositbild.
- Die Anpassung bleibt auf das Niederschlagsart-Radar begrenzt; die bestehenden 1-km-DWD-, OPERA- und 250-m-PX/HX-Radarpfade bleiben unverändert aktiv.

# MID v0.9.40.3

- Kompositbild: der DWD-Radarpfad behandelt den `dwd:Niederschlagsradar`-Alias jetzt wieder korrekt als Latest-only-WMS-Layer und erzwingt dort keinen fehlerhaften `TIME`-Parameter mehr; dadurch werden die Radarechos im Komposit wieder angezeigt.
- Für Latest-only-DWD-Radar rendert MID genau einen Snapshot mit stabiler Fehlerbehandlung, statt denselben Alias mehrfach als zeitgebundene Frames anzufragen.
- Die Komposit-Legende wird mit aktiven Overlays nun direkt geöffnet und blendet die Niederschlags-/Radar-Skala zuverlässig im Panel ein.
- Neue Regression `test-composite-radar-legend-buildfix-09403.mjs` schützt DWD-Radar-Snapshot und Legendenverhalten dauerhaft.

# MID v0.9.40.2

- 24-h-Wetterprofil: Tmin/Tmax verwenden jetzt exakt dieselben zentral reconcilierten Tageswerte (`displayDays[].min/max`) wie 7-Tage-Ansicht, 14-Tage-Best-Match, Widget und klassische Vorhersage.
- Stundenwerte dienen im Wetterprofil nur noch zur zeitlichen Positionierung des jeweiligen Tagesextrems auf der Kurve; sie erzeugen keine abweichenden Extremwert-Zahlen mehr.
- Tagesminimum/-maximum werden weiterhin nur eingeblendet, wenn der zugehörige Stunden-Proxy des betreffenden Kalendertags innerhalb des sichtbaren 24-h-Intervalls liegt; das sichtbare Fenster selbst wird nicht als falsches Tages-Tmin/Tmax interpretiert.
- Neue Regression `test-weather-profile-daily-extremes-consistency-09402.mjs` schützt die app-weite Konsistenz der Extremwerte.

# MID v0.9.40.0

- App-weite Rapid-Update-Policy: hochauflösende stündliche Regionalmodelle werden im Kurzfristbereich nach Standort, Frische, Auflösung und Datenlatenz priorisiert; mit zunehmendem Vorlauf sinkt ihr Gewicht.
- DWD ICON-D2-RUC/RUC-EPS werden über DWD Open Data als echte Rapid-Läufe erkannt; numerische Verwendung bleibt ehrlich capability-gated, solange kein JSON-/GRIB2-Adapter verfügbar ist.
- Radar-/Modell-Niederschlagsart wählt dynamisch das frischeste geeignete Rapid-/Regionalmodell; Météo-France AROME 15-min nutzt den dedizierten API-Endpunkt, HRRR die dokumentierte Modell-ID.
- Forecast-Fusion reicht Rapid-Provenienz bis ins Frontend durch; KNMI HARMONIE Europe/NL, UKV, MET Nordic, HRRR/NBM werden standort- und vorlaufabhängig berücksichtigt.
- Meteogramme um KNMI HARMONIE Europe und UKV ergänzt; UKMO UK Ensemble 2 km innerhalb seiner Domain höher priorisiert.
- Konservative Phase-/Rate-Limit-Schutzmechanismen aus v0.9.39.13 bleiben bestehen und wurden um laufaltersabhängige Rapid-Freshness ergänzt.

# MID v0.9.39.12

- 7- und 14-Tage-Cockpit: dezente, touch-taugliche Schaltfläche „Modellstand“ mit Best-Match- bzw. Ensemble-Laufmetadaten.
- 14-Tage-Cockpit: Konsistenz-Prozentpillen öffnen per Klick/Tipp einen randfesten Tooltip analog zur klassischen Ensembleansicht mit Klassifikation, Modellzahl, Mitgliederzahl und Streuungshinweis.
- 14-Tage-Tageskarten semantisch entkoppelt, damit die interaktive Konsistenzpille kein verschachtelter Button ist und beim Öffnen nicht gleichzeitig den Tag wechselt.
- Temporäre Regressionstest-Verzeichnisse werden nicht mehr als Releaseinhalt bzw. Commit-Artefakte mitgeführt.

# MID v0.9.39.9

- CI-Regressionsfix: der historische node_modules-Bootstrap-Test untersucht nach `npm ci` nicht mehr das live befuellte Projektverzeichnis.
- Der alte Installervertrag wird isoliert in einem temporaeren Checkout mit `minimist/.git`-Rest reproduziert.
- Der einmalige leere `node_modules/minimist/`-Bootstrap bleibt fuer den noch alten Installer auf `main` erhalten.

## v0.9.39.6

- GitHub-Installer gegen versehentlich versioniertes `node_modules/` gehärtet; lokale Paketinstallation wird vor dem Releasevergleich entfernt bzw. ausgeschlossen.
- `.gitignore` schützt `node_modules/` dauerhaft, und der CI-Prebuild entfernt historische Node-Pakete aus dem Git-Index, ohne die lokale Installation zu löschen.
- Verwaltete GitHub-Workflows werden vor dem Build aus `ci/github` synchronisiert, damit der korrigierte Installer im selben Release-Commit dauerhaft übernommen wird.
- Ein einmaliger ZIP-Bootstrap-Platzhalter erlaubt v0.9.39.6 auch mit dem noch auf `main` aktiven alten Installer zu installieren; `npm ci` entfernt ihn vor dem Build.
- Neue Regression reproduziert den v0.9.39.5-Fehler und schützt die Repository-Hygiene.

## v0.9.39.5

- Komposit-Niederschlagsart: DWD HymecNG vollständig aus dem aktiven Layerpfad entfernt; einzige aktive Variante ist beobachtetes OPERA-CIRRUS-Echo + zeitnahes ICON-D2-Phasenfeld.
- Radar-/Modellfusion gehärtet: konservative Zeitprüfung, mindestens 90 % vollständige Modellstichpunkte, verdichtetes lokales Phasenraster ohne künstliche Unterteilung und transparente Grenzfälle statt erfundener Klassifikation.
- Hagel wird nicht mehr allein aus einem Modell-Wettercode als beobachtete Niederschlagsart ausgegeben.
- 15-minütige ICON-D2-Phasenfelder werden clientseitig zeitlich normalisiert und wiederverwendet, damit 5-min-Radarscrubbing keine redundanten Modellraster lädt.
- 7-Tage-Trend sprachlich korrigiert: vollständige Mischwetter-Sätze, korrekt flektierte Tropennacht-Formulierung und großgeschriebene Wetterereignisse mit finitem Verb (z. B. „In der Nacht zum Sonntag sind Schauer möglich.“).
- Neue Regression schützt exklusiven Radar-/ICON-D2-Pfad und Trend-Grammatik.

## v0.9.39.4

- Fachliche Wetterwerte in kompakten Karten werden nicht mehr per Ellipsis abgeschnitten; enge Ansichten nutzen kürzere Notation, Umbruch und volle verfügbare Breite.
- DWD-nahe 6-h-Niederschlagswahrscheinlichkeit in Tageskarten kompakter dargestellt; redundante `0 min` entfallen, echte Niederschlagsdauer bleibt vollständig sichtbar.
- Appweiter Audit für Warnungen, Wettertexte, Quickfacts, Ensemble-Szenarien, Synoptik-, Radar-/Karten- und Detailwerte; Ellipsis bleibt nur für Navigation bzw. technische Namen zulässig.

## v0.9.39.3

- TypeScript-Buildfix für die MapLibre-Migration: dynamische GeoJSON-Layer werden als `maplibregl.AddLayerObject` an `Map.addLayer()` übergeben.
- Marker-Anchor-Typ von nicht vorhandenem `maplibregl.Anchor` auf den in MapLibre 5.24 exportierten `maplibregl.PositionAnchor` korrigiert.
- Ensemble-Mean/Spread-Fallback erzeugt nun ebenfalls die vier 6-h-Niederschlagsfenster 00–06, 06–12, 12–18 und 18–24 Uhr und erfüllt damit den vollständigen `MemberDay`-Vertrag.
- Neue Pflichtregression schützt die drei GitHub-CI-Buildfehler aus v0.9.39.2 dauerhaft.

## v0.9.39.2

- Niederschlagswahrscheinlichkeit DWD-nah zeitbezogen umgesetzt: Ereignisschwellen > 0,2 mm und > 5,0 mm werden für 24 h sowie die vier Ortszeitfenster 00–06, 06–12, 12–18 und 18–24 Uhr aus Ensemble-Membern berechnet.
- Kompakte Tagesdarstellung zeigt das relevanteste 6-h-Fenster (z. B. `12–18 h · 70%`) statt eines irreführenden Stundenmaximums als Tageswahrscheinlichkeit; vollständige 24-h-/6-h-Aufschlüsselung im Tooltip.
- Ohne Ensembleauswertung wird das Best-Match-Stundenmaximum nur noch als `zeitw. bis … %` gekennzeichnet und ausdrücklich nicht als DWD-Tagesereigniswahrscheinlichkeit ausgegeben.
- Ereigniswahrscheinlichkeiten werden vor der robusten Mengen-Ausreißerfilterung aus allen plausiblen Ensemble-Membern berechnet; Mengenquantile und Eintrittswahrscheinlichkeit sind statistisch getrennt.
- Ensemble-Cache auf v11 invalidiert, damit alte Tages-PoP-Datensätze ohne 6-h-Zeitfenster nicht weiterverwendet werden.

## v0.9.39.1

- Tages-Niederschlagswahrscheinlichkeit auf DWD-Ereignisschwellen > 0,2 mm und > 5,0 mm umgestellt.
- Eigene >= 0,1-mm-Tagesdefinition aus v0.9.39.0 entfernt.
- Zweite DWD-Wahrscheinlichkeit (> 5,0 mm) in Tages-/Ensembleinformationen ergänzt.
- Prognoseverifikation auf dasselbe > 0,2-mm-Ereignis synchronisiert.
- Ensemble-Cache invalidiert (v10), damit alte PoP-Werte nicht fortgeschrieben werden.

## v0.9.39.0

- Kartenengine: MID app-weit von Leaflet/react-leaflet auf MapLibre GL JS 5.24.0 migriert; gemeinsamer Kartenkern für Raster/WMS, GeoJSON, Marker, projektionstreue Canvas-Raster und deterministische Layerreihenfolge.
- Kompositbild: OPERA wird bei verfügbarem DWD-Radar nicht mehr optisch über das DWD-Bild gemischt, sondern als Kontroll- und Phasenquelle genutzt; als sichtbares Radar erscheint OPERA nur, wenn es selbst die aktive Radarquelle ist.
- Niederschlagsart: frisches DWD HymecNG bleibt Primärklassifikation; fehlt es, kombiniert MID beobachtete OPERA-Echos mit zeitnahem ICON-D2 (WMO-Code, Schneefall, bodennahe Temperatur/Feuchte und Feuchtkugeltemperatur). Außerhalb realer Radarechos wird keine Niederschlagsart erzeugt.
- Niederschlagswahrscheinlichkeit: Tageswerte verwenden bei verfügbarer Ensembleauswertung den modellgewichteten Anteil nasser Ensemble-Member ab 0,1 mm/Tag statt des höchsten Stundenwerts; `precipitation_probability_max` bleibt klar gekennzeichneter Fallback. Stündliche und 15-Minuten-Ansichten behalten ihre zeitintervallspezifischen Wahrscheinlichkeiten.
- Tages-PoP in Vorhersage, 7-Tage-Cockpit und Widget kompakt/überlaufsicher integriert; Herkunft ist per Tooltip nachvollziehbar.
- Worker: ICON-D2-Wetterkartenraster liefert zusätzlich 2-m-Temperatur, 2-m-relative Feuchte, Wettercode, Niederschlag und Schneefall für die Radar-Modell-Phasenklassifikation.
- Regressionen: rendererabhängige Leaflet-Prüfungen auf identische MapLibre-Fachverträge migriert und neuer kombinierter Schutztest für Kartenengine, Tages-PoP und Radar-Modell-Niederschlagsart ergänzt.

## v0.9.38.6

- Kompositbild: HymecNG-Projektion wertet ODIM `+ellps=WGS84` und `+ellps=GRS80` nun als echtes Ellipsoid statt als Kugel aus; dadurch wird das aktuelle DWD-HDF5 korrekt in Leaflet/WebMercator zurückprojiziert.
- Satellit: kontrollierter DWD-RGB/IR-Live-Snapshot als Fallback, wenn der offene 3-h-WMS-Layer keine auswertbare TIME-Dimension liefert; EUMETSAT bleibt TIME-pflichtig.
- Satelliten-Live-Snapshot erhält eine eigene Revision und wird über den Worker mit `no-store`/Cache-Buster geladen, ohne benachbarte Frames zu mischen.
- Legacy-HG (BUFR/BZip2) bleibt ausschließlich Diagnosepfad; das kartierte Niederschlagsartenprodukt bleibt das offizielle HymecNG-HDF5.
- Regressionen für WGS84/GRS80-HymecNG und DWD-Satellit ohne TIME-Dimension ergänzt bzw. bestehende Live-/Performance-Verträge angepasst.

## v0.9.38.5

- Komposit-Satellitenbild: produktspezifische Frischefenster statt pauschaler 55-Minuten-Sperre.
- Amtlicher DWD-Meteosat-3h-Layer bleibt bis zum nächsten regulären 3h-Termin als explizit zeitgestempelter Fallback sichtbar.
- EUMETSAT-NRT bleibt streng auf aktuelle explizite Zeitstände begrenzt; Snapshot-Schutz gegen Mischkacheln bleibt erhalten.

## v0.9.38.4

- Komposit/HymecNG: direkter offizieller `composite_HymecNG_LATEST_000-hd5`-Pfad vor Directory-Index, mit Root-Frischevergleich und Cache-Busting.
- HymecNG: interner HDF5-Zeitstempel, defensive 0–10-Klassencodierung und bounds-freies natives Leaflet-Tile-Rendering.
- Legacy-HG (`HG_LATEST_000.bz2`) wird nur diagnostisch geprüft; kein ungeoreferenzierter/undekodierter Ersatzlayer.

## v0.9.38.3

- Kompositbild: HymecNG-Layer-Lifecycle stabilisiert; ODIM-HDF5-Klassencodes werden mit gain/offset dekodiert und vor dem Rendern plausibilisiert.
- HymecNG: beide offiziellen DWD-Open-Data-Roots werden geprüft; nur der jüngste Stand und maximal 25 Minuten alte Live-Daten werden angezeigt.
- Satellit: ausschließlich ein explizit zeitgestempelter, frischer WMS-Snapshot; unzeitgestempeltes latest und Nachbarframe-Preloading entfernt, um alte/neue Tile-Mosaike auszuschließen.
- Neue Regression schützt HymecNG-Frische/Klassendekodierung und Satelliten-Snapshot-Konsistenz.

## v0.9.38.2

- Tagesdetaildiagramm: schlanke Leiste „Thermisches Empfinden“ zwischen Temperatur und Luftdruck, mit denselben Belastungsklassen/Farben wie im 24-h-Wetterprofil.
- Tagesdetail-Einzeldaten: thermisches Empfinden direkt unter „Temperatur / gefühlt“.
- 24-h-Wetterprofil: sichtbare Stunde-zurück/-vor-Steuerung sowie Desktop-Bedienung per Pfeil links/rechts und Mausrad über der Diagrammfläche.
- 24-h-Wetterprofil: dynamische Böen-/Hazard-Details folgen konsequent der gewählten Windeinheit.

## v0.9.38.1

- App-Neustart nach Update korrigiert: normale `midwx.app`-, Update-, Refresh- und Rollback-URLs werden nicht mehr fälschlich als Geräte-Synchronisationscode interpretiert.
- Nur explizite `#mid-sync=…`, `?mid-sync=…`, `mid-sync:…` oder eigenständige Synchronisationscodes öffnen weiterhin Einstellungen → Synchronisation.
- Neuer Regressionstest schützt den normalen Startpfad nach Service-Worker-/Update-Neustarts.

## v0.9.38.0

- Stable-Audit 10.08.2026 vollständig umgesetzt: explizite finale TypeScript- und Vite-Produktionsbuildphasen im Releasevertrag.
- Langfrist/Saisonmodelle: gemeinsamer 4-h-Cache, bis 36 h Stale-if-error und bewusster manueller Refresh für ECMWF sowie NOAA NMME/CFSv2.
- Druckniveau-Meteogramm: 15-min-TTL, 3-h-Stale-Fallback, expliziter Refresh, Memoisierung und Offscreen-Rendering-Containment.
- OPERA-Raster: begrenzter Cache fertig projizierter Viewport-Canvases nach Frame, Zoom, Bounds und Größe zur Vermeidung identischer Neuberechnungen.
- Dependency-Policy: React 18.3.1, Recharts 3.8.1, TypeScript 5.9.3 und Vite 6.4.3 reproduzierbar geschützt; größere Upgrades nur isoliert bzw. als getrennte Kompatibilitätsmigration.
- Bestehende mid-stable-Schedule-Pins und HymecNG-Dormant-/Performance-Verträge bleiben erhalten.

## v0.9.37.3

- CI-/Performance-Fix für HymecNG: die historisch gesperrten Module `HymecNgSource.ts` und `HymecNgOverlay.tsx` bleiben dormant.
- Der echte DWD-HymecNG-Kompositlayer läuft jetzt über einen separaten lazy geladenen Pfad (`CompositeHymecNgSource.ts` / `CompositeHymecNgOverlay.tsx`).
- Regression `test-interaction-performance-cleanup-08155.mjs` und HymecNG-Schutztest entsprechend abgesichert.

## v0.9.37.2

- Kompositbild: neuer echter DWD-HymecNG-Layer für "Niederschlagsart" statt recyceltem WN/Cloud-PNG.
- HymecNG wird im Komposit nativ aus dem aktuellen DWD-HDF5 gerendert, inklusive ODIM-Georeferenzierung und eigener Deckkraftregelung.
- Quellenhinweise, Legende und Komposit-Infos auf HymecNG aktualisiert.

## v0.9.37.1
- Kompositbild: den irreführenden Layer „Niederschlagsart“ vollständig entfernt. Er verwendete kein WN-/HymecNG-Radarraster, sondern recycelte das kombinierte DWD-Webbild „Wolken + Niederschlagsart“ und spannte es über feste Kartenbounds.
- Fachliche Produktkorrektur: DWD WN ist ein Reflektivitätskomposit und darf nicht als Niederschlagsart bezeichnet werden. Das aktuelle echte DWD-Produkt für die bodennahe Hydrometeorklasse ist HymecNG (HDF5).
- HymecNG wird im Komposit bewusst noch nicht aktiviert: Die vorhandene MID-Implementierung besitzt weder eine verifizierte HDF5-Klassencodetabelle noch einen anhand aktueller Dateien nachgewiesenen vollständigen Renderpfad. Es werden keine Klassen oder Georeferenzierungen geraten.
- HymecNG-Parser gehärtet: fehlende native ODIM-Projektionsdefinition führt jetzt zum Abbruch; der historische Kugel-/RADOLAN-Fallback ist entfernt.
- Das eigenständige DWD-Originalbild „Wolken + Niederschlagsart“ bleibt als separat gekennzeichnete optionale Darstellung erhalten, wird aber nicht mehr als Kartenlayer missbraucht.
- Regression `test-composite-precipitation-type-layer-09366.mjs` prüft nun explizit gegen PNG-Recycling, WN-Fehlbezeichnung und Legacy-Georeferenzierung.

## v0.9.37.0
- Radar-Nowcast: DWD-RS wird in der Enrichment-Stufe als amtlicher 1-h-Mengenanker für die ersten zwei Stunden eingebunden; RV bleibt für 5-Minuten-Timing und Intensitätsstruktur maßgeblich. Abwärtskorrekturen sind vollständig möglich, Aufwärtskorrekturen werden begrenzt.
- Radar-Nowcast: DWD-HX 250 m wird ausschließlich bei unsicheren Randtreffern zur Standorttrefferprüfung genutzt und verändert keine Niederschlagsmenge eigenständig.
- Radar-Nowcast: leichtgewichtiges Wachstum-/Zerfallsmodell und lokales Bewegungsfeld aus den bereits geladenen Radarframes ergänzt; dadurch entstehen keine zusätzlichen Radarrequests für diese beiden Schritte.
- Radar-Nowcast: 9-Member-Mikroensemble aus Timing- und Intensitätsvarianten liefert Trefferwahrscheinlichkeit sowie P25/Median/P75 der 2-h-Menge. Die Nowcast-Leiste summiert kalibrierte 5-Minuten-Mengen statt roher mm/h-Werte.
- Radar-Nowcast: frische, nahe DWD-Niederschlagsstationen dürfen die Kurzfristmenge vorsichtig nachkalibrieren; Einfluss sinkt mit Distanz, Alter, Lead Time und Konvektivität.
- Ladezeit: schneller Radar-Erstpfad bleibt unverändert; RS und Stationsabgleich laufen erst im verzögerten Enrichment, HX nur bei tatsächlichen Grenzfällen.

## v0.9.36.9
- Kompositbild: zusätzlicher Layer "Niederschlagsart" ergänzt. MID prüft jetzt vorrangig DWD HymecNG und blendet – solange keine verifizierte Klassenabbildung vorliegt – automatisch das amtliche DWD-WN-Originalprodukt als sichere Ersatzdarstellung ein.
- Für den neuen Layer gibt es einen eigenen Schalter, eine separate Deckkraftregelung sowie eine über die Komposit-Legende ausblendbare Niederschlagsart-Legende.
- Quellen-/Hinweistext des Kompositbilds und die globale Quellenliste wurden um DWD HymecNG bzw. DWD WN erweitert.
- Neue Regression `test-composite-precipitation-type-layer-09366.mjs`.

## v0.9.36.4
- 14-Tage-Ensemble-Niederschlag „kumuliert“: ENS-Mittel ist jetzt unabhängig vom Standard-/Erweitert-Modus immer als eigene gestrichelte kumulierte Linie sichtbar.
- Kumulierte Legende und Tooltip zeigen ENS-Mittel ebenfalls immer; Export-Metadaten enthalten es verbindlich.
- CI-Analyse: der gemeldete Wartungstest ist auf den exakten v0.9.36.2- und v0.9.36.3-Ständen sowie nach allen 188 davor laufenden Regressionen unter simuliertem GitHub-Actions-Umfeld reproduzierbar grün. Der zeitgleiche Dependabot-PR für Recharts 3.10.1 erklärt den roten PR-CI-Lauf, weil der Stable-Vertrag bewusst Recharts 3.8.1 festschreibt. Stable-Code wird deshalb nicht aufgeweicht.
- Neue Regression `test-ensemble-cumulative-ens-mean-09364.mjs`.

## v0.9.36.3
- 14-Tage-Ensemble-Niederschlag „kumuliert“: P10/P25/P75/P90 und ENS-Mittel werden jetzt statistisch korrekt aus den **kumulierten Niederschlagssummen jedes einzelnen Ensemblemitglieds** berechnet. Die in v0.9.36.2 verwendete Addition täglicher Quantile wurde entfernt.
- Dadurch bleibt das innere P25–P75-Band auch bei tageweise stark null-inflationiertem Niederschlag aussagekräftig und kann nicht mehr allein deshalb auf `0,0–0,0 mm` kollabieren, weil die täglichen Quartile jeweils null waren.
- Bestehende Ensemble-Caches ohne memberbasierte kumulierte Quantile werden automatisch verworfen und einmalig frisch berechnet; sonstige Cache-/Favoriten-/Nutzerdaten bleiben unangetastet.
- Tooltip, P10–P90- und P25–P75-Flächen sowie ENS-Mittel verwenden denselben kumulierten Member-Datensatz.
- Neue Regression `test-ensemble-cumulative-member-quantiles-09363.mjs`; die bisherigen kumulierten Niederschlagsverträge auf die fachlich korrekte Member-Trajektorien-Methode aktualisiert.

## v0.9.36.2
- 14-Tage-Ensemble-Niederschlag, Modus „kumuliert“: zusätzliches inneres P25–P75-Unsicherheitsband ergänzt, bewusst dunkler als der äußere P10–P90-Bereich.
- P25/P75 werden bereits in der täglichen gewichteten Niederschlags-Ensembleverteilung berechnet und anschließend analog zu P10/P90 kumuliert.
- Kumulierte Legende, Tooltip, Erklärung und Export-Metadaten um P25–P75 erweitert; die normale Tagesansicht bleibt unverändert.
- Neue Regression `test-ensemble-cumulative-rain-quartiles-09362.mjs`; Navigationsregression releasefest gemacht.

## v0.9.36.1
- Navigationskonzept umgesetzt: Mobile Schnellnavigation „Heute · Kurzfrist · 7 Tage · Mehr“, vollständiger Sektionen-Drawer, einklappbare Desktop/Tablet-Seitenleiste und fachliche Gruppen.
- Navigation nutzt weiterhin ausschließlich die bestehende Dashboard-Modulkonfiguration für Sichtbarkeit/Reihenfolge; bedingte Berg-/Wasser- sowie Profi-Module werden automatisch berücksichtigt.
- Abschnittsanker, Browser-Zurück, Auto-Expand eingeklappter Module und direkte Cockpit-Horizontumschaltung für Kurzfrist/7/14 Tage ergänzt.
- 24-h-Wetterprofil: erster Stundenpunkt erhält einen zusätzlichen inneren X-Abstand zur linken Y-Achse; Achsenbeschriftung und erster Datenpunkt überdecken sich nicht mehr.
- Neue Regression `test-section-navigation-profile-inset-09361.mjs`; ältere Geometrie-/Dashboard-Verträge auf die neue Anker- und Innenabstandslogik synchronisiert.

## v0.9.36.0
- 14-Tage-Ensemble-Niederschlag: neue optionale kumulierte Ansicht mit monoton ansteigender Best-Match-Kurve, kumuliertem P10–P90-Unsicherheitsband und optionalem kumuliertem ENS-Mittel. Die bestehende Tagesansicht bleibt Standard.
- Navigationskonzept für die wachsende Zahl an MID-Sektionen ergänzt: Dashboard beibehalten, zusätzlich Sektionen-Drawer mit fachlichen Gruppen und bestehender Modulverwaltung als Single Source of Truth.

## v0.9.35.2
- 24-h-Wetterprofil: Diagramm verwendet wieder ausschließlich stündliche Werte und beginnt mit der aktuellen Stunde; die 15-Minuten-Schritte bleiben auf Kurzfrist/Nowcast beschränkt.
- Schneefallgrenzen-Ensemble: fehlende API-Werte werden nicht mehr durch `Number(null)` fälschlich als 0 m interpretiert; der Nullgradgrenzen-Fallback greift wieder korrekt.
- Schneefallgrenzendiagramm: feste Y-Achse 0–4,5 km, bestehende Multi-Modell-/10–90-%-Unsicherheitsdarstellung bleibt erhalten.
- Schneefallgrenzendiagramm: Zeitschritte mit erwartbarem Niederschlag werden dezent als vertikale Hintergrundmarkierungen angezeigt und im gewählten Zeitschritt kompakt quantifiziert.

## v0.9.35.1
- 24-h-Wetterprofil: Diagramm startet nun bereits mit dem ersten verfügbaren Kurzfrist-Zeitschritt (15-Minuten-Raster) statt erst nach dem 90-Minuten-Block mit dem ersten reinen Stundenpunkt.
- 24-h-Wetterprofil: X-Achse auf echte Zeitabstände umgestellt, damit 15-Minuten-Punkte am Anfang und spätere Stundenpunkte proportional korrekt verteilt werden.
- 24-h-Wetterprofil: Achsenbeschriftung zeitbasiert statt indexbasiert; volle Kurzfristserie bis zum 24-h-Horizont fließt in Diagramm, Hazards und Einzeldaten ein.

## v0.9.35.0
- Langfrist: echtes numerisches Multi-Modell statt mehrerer ECMWF-Varianten. ECMWF EC46/SEAS5 wird mit allen im aktuellsten verfügbaren NOAA-NMME-ENSMEAN-Lauf direkt numerisch verfügbaren unabhängigen Modellfamilien kombiniert; CFSv2-E1/E2/E3 bleibt als Fallback erhalten.
- Langfrist: Multi-Modell-Rauchfahne gewichtet Modellfamilien gleich. Temperatur zeigt Ensemble-/Intermodell-Spanne in K; Niederschlag wird im gemeinsamen Modellvergleich als Anomalie in mm/Tag relativ zum jeweiligen Modellklima dargestellt. Einzelmodelle bleiben separat auswählbar.
- Langfrist: Monatspositionen mit zusätzlichem linken Innenabstand, damit der erste Monat nicht mit der Y-Achsenbeschriftung kollidiert.
- Berg-/Wintersport: Schneefallgrenze als einklappbare Multi-Modell-Ensemble-Schnellübersicht neu aufgebaut. Auswahl 1/3/7/14 Tage, kompakter selektierter Zeitschritt, vertikale Auswahlmarke, Modell-/Memberzahl sowie 25–75- und 10–90-%-Unsicherheitsband.
- Schneefallgrenze: Bereich oberhalb der Medianlinie blau, darunter grün; konfiguriertes Tal/Mitte/Berg als kontrastreiche Höhenlinien direkt im Diagramm.
- Schneefallgrenzen-Ensemble nutzt Open-Meteo Ensemble Mean/Spread für mehrere Systeme (u. a. ICON-EPS, ECMWF IFS/AIFS, GEFS, GEM/GEPS, WeatherNext soweit am Standort verfügbar); Best Match bleibt als Fallback erhalten.
- Neuer Worker-Endpunkt für NOAA-NMME/CFSv2-Monatsanomalien mit NetCDF-Classic-Punktparser und 6-h-Edge-Cache.
- Neue Regression `test-true-multimodel-snowline-09350.mjs`; bestehende Langfrist-Verträge auf echtes Modellfamilien-Multi-Modell aktualisiert.

## v0.9.34.1
- Buildfix Langfrist: drei ältere Regressionstests prüften fälschlich exakt auf v0.9.33.2 und blockierten dadurch jede spätere Releaseversion. Die Verträge prüfen jetzt Baseline-Synchronität und mindestens den Einführungsstand v0.9.33.2.
- Neuer Schutztest sichert die releasefeste Langfristprüfung, die Multi-Modell-Rauchfahne und die Schneefallgrenzen-Schnellübersicht ab.

## v0.9.32.22

- Niederschlagsformen appweit konsolidiert: Tageskarten verwenden die zentrale phasentreue Niederschlagsart statt pauschal „Regen“/„Schauer“.
- Schneefall wird bei vorhandenem Modellfeld zusätzlich kompakt in cm angegeben (`mm · ❄ x,x cm`) und ersetzt die Niederschlagsmenge in mm nicht.
- Kurzfrist-, 24-h-, Tages-, Detail-, Meteogramm-, Ensemble-, Wasserwetter- und Widgetausgaben auf die gemeinsame Mengenformatierung umgestellt, soweit Schneefalldaten verfügbar sind.
- Neue Regression schützt Schnee, Schneeschauer, Schneeregen, Schneeregenschauer, Schneegriesel, gefrierende Formen und die zusätzliche cm-Ausgabe.

## v0.9.32.20

- Kompositbild: EUMETSAT EUMETView bleibt die direkte Primärquelle für MTG-FCI-RGB/GeoColour; die Produktauswahl priorisiert nun den tatsächlich jüngsten nominellen Satellitenstand vor einer bloßen Quellenpriorität.
- Satelliten-/Radar-/Blitz-WMS-Raster werden während eines Zoomvorgangs wieder vollständig ausgehängt und nach `zoomend` mit einem neuen Cache-/Layer-Schlüssel aufgebaut. Damit wird eine frühere Schutzlogik aus v0.7.34/v0.7.35 wiederhergestellt, die im aktuellen Code versehentlich zu `tileRevision=0` / `rasterZooming=false` zurückgefallen war.
- Satelliten-Layer behalten keine WMS-Kacheln über Zoomstufen hinweg (`keepBuffer=0`, kein Update während Zoom).
- Für EUMETView-Produkte ohne belastbare Zeitdimension wird kein alter `latestTime` mehr als `TIME` erzwungen. Stattdessen wird der offizielle WMS-Default „latest“ genutzt und bei jedem Metadatenrefresh mit einem neuen MID-Token neu geladen.

## v0.9.32.19
- 24-h-Wetterprofil: UVI platzsparend in die bestehende Einzeldatenzeile „Wolken H/M/L + UVI“ integriert; der UVI wird aus demselben Best-Match-Zeitschritt wie die übrigen Einzeldaten übernommen.
- 24-Stunden-Leiste auf Handydisplays deutlich flacher konsolidiert: kleinere Abstände, kompaktere Tages-/Zeit-/Temperaturdarstellung, kleinere Piktogramme und engere Niederschlags-/Windzeilen, ohne Wetterparameter zu entfernen.

## v0.9.32.18
- Buildfix der quota-sicheren Wetterzwilling-Archivwarteschlange: `mirrorStore()` behält seinen Erfolgsstatus für Sicherheitsentscheidungen, die Queue verwirft diesen Rückgabewert jedoch korrekt und bleibt `Promise<void>`-kompatibel.
- Keine funktionale Rücknahme der in v0.9.32.17 eingeführten Storage-/Quota-Sicherung.

## v0.9.32.17
- Nachhaltige Quota-Sicherung: zentrale lokale Speicherverwaltung mit automatischer Bereinigung ausschließlich rekonstruierbarer Caches, Retry des ursprünglichen Schreibvorgangs und zusätzlicher IndexedDB-Spiegelung dauerhafter Nutzerdaten.
- Favoriten und andere dauerhafte Einstellungen bleiben auch dann erhalten, wenn Safari/iOS `localStorage` vorübergehend nicht mehr beschreiben kann.
- Wetterzwilling-Langzeitdaten bleiben vollständig in IndexedDB/Sync erhalten; nur die redundante lokale Schnellstartkopie wurde platzsparend begrenzt.

## v0.9.32.16
- 24-h-Kurzfristkacheln vollständig auf denselben 24-Stunden-Datensatz wie die sichtbare 24-h-Leiste umgestellt; keine 12-h-/Gesamtdatensatz-Mischung mehr.
- Favoriten-Synchronisation mit eigener Favoritenrevision abgesichert: ältere Favoritenlisten aus anderen verbundenen Safari-/PWA-Instanzen können neuere lokale Favoriten nicht mehr zurücksetzen.
- POI-Favoriten erkennen nahe Namensvarianten mit gemeinsamen Kernbegriffen robuster, z. B. Sponsorenpräfixe bei Stadien.

## v0.9.32.15
- Favoriten-Dauerhaftigkeit: Hinzufügen/Entfernen über den Stern wird jetzt sofort in `mid:favorites` persistiert, statt erst nach dem verzögerten Idle-Speicherfenster. Das schließt insbesondere unter iOS/PWA eine Suspend-/Reload-Lücke.
- Favoritenidentität für POIs präzisiert: gespeicherte Orte werden über exakte Koordinaten/stabile ID bzw. gleichen Namen mit enger Toleranz (POI 120 m, sonst 450 m) erkannt. Die bisherige allgemeine 350/900-m-Nahbereichslogik bleibt nur für GPS-/Standorttracking erhalten.
- Dadurch können nahe, aber unterschiedliche POIs nicht mehr gegenseitig als derselbe Favorit behandelt oder versehentlich entfernt werden.
- Neue Regression `test-favorite-durable-poi-093215.mjs`; ältere Favoriten-Navigationstests auf die Trennung zwischen Favoritenidentität und GPS-Nähe synchronisiert.

## v0.9.32.14
- `MID-ribbons-ui-text-cleanup.patch` angewendet: redundante Erklärtexte in Kurzfrist-, 7-/14-Tage-Ribbons und 24-h-Wetterprofil entfernt bzw. gekürzt; Drucktrend-/Nebel-Signalkarten ohne zusätzliche Erklärungssätze.
- DWD „Wolken + Niederschlagsart“: Zoom in festen 100-%-Schritten von 100 bis 500 % erweitert.
- Zoom-Sicherheit auf Touchgeräten verbessert: vertikales Overscroll-Chaining zurück zur App und stets erreichbarer 100-%-Reset über dem Bildfenster verhindern ein Festhängen im vergrößerten Originalbild.

## v0.9.32.13
- CI-/Regression-Fix für die in v0.9.32.12 bewusst auf 5-Minuten-Niederschlagsmengen umgestellte Radar-Nowcast-Skala.
- Drei ältere Schutztests auf den neuen Sollvertrag synchronisiert: Achse `mm/5 min`, Balkenhöhe aus der jeweiligen 5-Minuten-Menge und aktuelle Releaseversion.
- Die neue Radar-Nowcast-Darstellung selbst bleibt unverändert.

## v0.9.32.12
- Radar-Nowcast-Leiste: y-Achse auf Niederschlagsmenge je 5-Minuten-Balken umgestellt (`mm/5 min`) statt auf stündliche Rate.
- Balkenhöhen orientieren sich nun direkt an der prognostizierten bzw. beobachteten 5-Minuten-Menge je Balken; dadurch bleiben schwache Signale sichtbar, ohne überhöht zu wirken.
- Umfeld-/Nahbereichsechos ohne direkten Standorttreffer bleiben weiterhin erkennbar, werden aber deutlich zurückhaltender dargestellt.

## v0.9.32.10
- Buildfix für die kombinierten Kurzfrist-/7-Tage-Mini-Diagramme: `tempMin` wird in beiden Temperatur-Skalierungen wieder korrekt definiert.
- Regression ergänzt, die diesen TypeScript-Buildfehler künftig verhindert.

## v0.9.32.9
- Cockpit-Registerkarten „Kurzfrist“ und „7 Tage“: Mini-Diagramme zu einem kombinierten Verlauf zusammengeführt. Temperaturtrend und Niederschlagsbalken werden nun jeweils in einem gemeinsamen, kompakteren Mini-Chart dargestellt und ersetzen die getrennten Darstellungen.

## v0.9.32.8
- 24-h-Wetterprofil: Tmin- und Tmax-Markierungen im Temperaturfeld vergrößert, mit stärkerem Kontrast/Halo versehen und vertikal etwas weiter vom Kurvenverlauf abgesetzt, damit die Werte auf mobilen Displays besser lesbar sind.

## v0.9.32.7

- 24-h-Wetterprofil: Zeitangaben in den oberen Signalkarten verwenden jetzt wie die unteren Kurzfristfelder „heute“ bzw. „morgen“ vor der Uhrzeit.
- Betrifft insbesondere Nebel-/Sichtsignal und „Stärkste Einschränkung“; Datumsanhänge hinter der Uhrzeit entfallen dort.

## v0.9.32.6

- 24-h-Wetterprofil: „Wetterberuhigung“ vollständig entfernt; stärkstes Warnsignal wird als „Stärkste Einschränkung“ ausgewiesen.
- Wetter-Hazards verwenden nun direkt die zentrale appweite MID/DWD-Warnauswertung samt identischen Warnschwellen und Warnfarben.
- Zustand der 24-h-Legende wird favoritenübergreifend in `localStorage` gespeichert und beim nächsten Standort/Favoriten wiederhergestellt.
- Header-Pille „Stündlich · ein Blick“ entfernt; 24-h-Leiste ohne Hinweis „Seitlich wischbar …“.
- Sämtliche y-Achsenbeschriftungen und Einheiten des Wetterprofils auf die linke Diagrammseite verlegt.
- Temperaturkurve: Tagesmaximum nur bei tatsächlich im Anzeigeintervall liegendem Tagesmaximum; nächtliches Minimum nur einmal je zusammenhängender Nacht.
- Info-Schaltfläche der Einzeldaten platzsparend direkt in die Titelzeile integriert.
- Kurzfrist-Spotlights kennzeichnen Uhrzeiten jetzt explizit mit „heute“ bzw. „morgen“.
- Neue Regression `test-mid-weather-profile-ux-hazards-09326.mjs`; bestehende Wetterprofil-Verträge auf den neuen Sollstand synchronisiert.
- Vollständige Regression: 331/331 Tests bestanden.

## v0.9.32.5

- 24-h-Einzeldaten: Füllwort „signifikant“ aus den negativen Risiko-/Hazard-Angaben entfernt („kein Risiko“, „keine Wettergefahren“).
- Schwüle wird nur noch bei tatsächlich erfüllter Mehrfaktorenlage angezeigt; bei unauffälliger Lage heißt das Feld ausschließlich „Taupunkt“.
- Die frühere starre Schwüleprüfung `Td ≥ 17 °C` wurde durch eine DWD-orientierte Mehrfaktorenbewertung ersetzt: Wasserdampfdruck aus Taupunkt/Feuchte als Feuchtekern, Luft- und gefühlte Temperatur, Windentlastung sowie Strahlungsproxy aus Sonnenscheindauer/Bewölkung.
- Kräftiger Wind kann grenznahe Schwülelagen abschwächen; starke Feuchte bleibt dabei robust berücksichtigt.
- Fachhinweis hinter (i) auf die Grenzen gegenüber dem vollständigen Klima-Michel-Verfahren präzisiert.
- Neue Regression `test-mid-weather-profile-sultry-09325.mjs`; ältere Wetterprofil-Verträge entsprechend synchronisiert.

## v0.9.32.4

- 24-h-Wetterprofil: Info-Schaltfläche bereinigt; nur noch das eigentliche Informationssymbol wird angezeigt.
- Responsivitätsfix für das 24-h-Wetterprofil: Canvas-Höhe passt sich der real verfügbaren Breite an; übergroßer Leerraum auf mobilen Displays entfällt.
- Touch-Bedienung des Wetterprofils robuster gemacht; Zeitschritte reagieren direkter auf Taps/Touches.
- Zeitlabels oberhalb des Profils folgen jetzt einem regelmäßigen Raster statt ungleichmäßiger Abstände.
- Tages-Tmin/Tmax werden je Kalendertag als Zahlenwert am Verlauf markiert, jedoch nur innerhalb des tatsächlich sichtbaren Anzeigeintervalls.
- Wetterpiktogramme im Profil ohne querlaufenden Hintergrundstreifen; Windpfeile etwas dezenter.
- Wolkenbänder H/M/L ohne zusätzlichen kontrastreichen Hintergrund; Kontrast entsteht nur noch durch echte Bewölkungsanteile.
- Versions- und Regressionsstand vollständig auf v0.9.32.4 synchronisiert; 329/329 Tests bestanden.

## v0.9.32.3

- 24-h-Wetterprofil: vertikale Abstände oberhalb des Diagramms reduziert; Stunden-, Kalender- und Piktogramme rücken näher an die Grafik.
- Temperaturachse auf runde Tickwerte umgestellt; Tagesmaximum und -minimum im sichtbaren Zeitraum werden direkt im Temperaturverlauf markiert.
- Stündliche Wetterpiktogramme vollständig dargestellt; Zeitlabels oberhalb des Diagramms auf kleinen Viewports entzerrt.
- Wolkenbänder optisch neutralisiert: gleicher Hintergrund für H/M/L und kontrastreichere Bewölkung, damit die tatsächliche Ausprägung klarer erkennbar bleibt.
- 24-h-Signalkarten nur noch bei fachlichem Bedarf sichtbar; „Ruhiges Fenster“ verständlich in „Wetterberuhigung“ umbenannt.
- Legende jetzt ein-/ausblendbar; Erklärtexte über ein (i) erreichbar.
- Einzeldaten kompakter gefasst: Temperatur+gefühlt, Taupunkt+Schwüle sowie Sichtweite+Nebelrisiko jeweils kombiniert.
- CI-/Regression-Verträge auf den neuen v0.9.32.3-Sollstand synchronisiert; kein Test pinnt mehr die Vorgängerversion v0.9.32.2. Neue Layout-Schutzregression ergänzt.

## v0.9.32.2

- 24-h-Wetterprofil: Achsen optisch und funktional verfeinert.
- Temperatur links mit sauberer °C-Skala und Tickmarken; Niederschlag und Wind rechts mit eigenen Einheiten/Skalen.
- Zeitachse mit Grundlinie, Ticks und klareren Tageswechseln; Rasterlinien ruhiger abgestimmt.

## v0.9.32.0
- 24-h-Wetterprofil mit klickgebundener senkrechter Zeitschrittmarkierung erweitert; Zeitangaben nach Tageswechsel tragen zusätzlich das Datum.
- Wolkenbasis-Näherung entfernt. Temperaturdifferenzen werden fachgerecht in Kelvin ausgewiesen.
- Neues Band „Thermisches Empfinden“: Best-Match-Gefühlte-Temperatur wird nach den DWD-Klassen von sehr kalt bis sehr heiß eingeordnet; Einflussfaktoren wie Windkühlung, Feuchte und Sonneneinstrahlung werden transparent benannt.
- Thermische Belastung und Wetter-Hazards fachlich getrennt; Nebel/Sichteinschränkung, Gewitter, Niederschlagsgefahren und Wind/Böen verbleiben im Hazard-Band.
- Windrichtungspfeile für jeden 24-h-Zeitschritt ergänzt und analog zur bestehenden MID-Warnlogik grün bzw. nach Warnstufe eingefärbt.
- Wolkenschichten als lückenlose H/M/L-Bänder (H oben, L unten) mit zeitlichem Fading dargestellt; markante sprunghafte Bewölkungsänderungen bleiben als schärferer Übergang erhalten.
- Ensemble-Temperaturdiagramm: Sonnenscheinband neu kalibriert; ≤ 50 % der astronomisch möglichen Sonnenscheindauer entspricht bereits Grau, 50–100 % bildet den Verlauf bis Gelb ab.
- Neue Regression `test-mid-weather-profile-thermal-sun-09320.mjs`; v0.9.31.0-Wetterprofilregression auf die bewusst entfernte Wolkenbasis synchronisiert.

## v0.9.31.0
- Wolken + Niederschlagsart: im DWD-Abdeckungsgebiet wieder das amtliche DWD-Kombinationsbild als unveränderte Quelle; 100–300 % Zoom mit verschiebbarem Bildfenster und bildgebundenen Radar-/Satellitenzeitständen.
- 24-h-Meteogramm durch ein gemeinsames Wetterprofil für Temperatur/Gefühlt/Taupunkt, Niederschlag/Wahrscheinlichkeit, Wind/Böen, Wolkenschichten und Wetterbelastung ersetzt.
- Abgeleitete Nutzersignale ergänzt: ruhiges Wetterfenster, 6-h-Drucktrend, Feuchte-/Nebelhinweis, Wetterbelastungsindex und gekennzeichnete T–Td-Wolkenbasis-Näherung.
- Betroffene Altregressionen auf die neue Sollarchitektur synchronisiert; zusätzliche Regression `test-mid-original-dwd-weather-profile-09310.mjs`.

## v0.9.22.1
- Buildfix für das DWD-Niederschlagsarten-Radar: `RadarMeta` und `RadarPointInfo` erfüllen jetzt den `WorkerPayload`-Vertrag von `fetchWorkerJson`, wodurch die TypeScript-Fehler TS2559 im Produktionsbuild beseitigt werden.
- Neue Regression `test-dwd-radar-worker-payload-buildfix-09221.mjs` sichert die WorkerPayload-Kompatibilität dauerhaft ab.

## v0.9.22.0
- DWD-Niederschlagsarten-Radar geometrisch neu kalibriert: Standortposition linear an die geografischen Bildgrenzen gekoppelt, um die bisherige systematische Südverschiebung durch eine ungeeignete Web-Mercator-Interpolation zu beseitigen.
- Radar-Komposit erweitert um Bild-/Kompositzeitstände, semitransparente Legende, transparenten ein-/ausblendbaren Standortmarker und eine Klickanalyse für Niederschlagsklasse sowie Wolkensignal am Bildpunkt.
- Wetterkartenmodul auf reine DWD-Modell-/Nowcastkarten bereinigt: Meteosat/Satellitenkarte entfernt, explizite Zeitschrittauswahl ergänzt, NowCastMIX-Karten für signifikantes Wetter geprüft/erweitert und die öffentlich verfügbaren ICON-, ICON-EU-, ICON-EPS- sowie AICON-WMS-Serien verbreitert.
- DWD-WMS-Layerabgleich im Worker namespace-robust gemacht und Radar-Metadaten-/Punktanalyse-Endpunkte ergänzt.
- Wetterkarten-Regression `test-weather-maps-module-09210.mjs` an die neue reine Modellkartenarchitektur angepasst; zusätzliche Interaktionsregression `test-radar-weather-maps-interaction-09220.mjs` ergänzt.

## v0.9.21.2
- Regression-Fix für das Wetterkartenmodul: `test-weather-maps-module-09210.mjs` prüft die Versionskonsistenz nun dynamisch statt die Ursprungsreleaseversion `0.9.21.0` fest zu verdrahten.
- Package-, Baseline- und Worker-Version müssen übereinstimmen; Folgereleases ab v0.9.21.0 bleiben damit testbar.
- Behebt den GitHub-Actions-Abbruch beim Installieren von v0.9.21.1.

## v0.9.21.1
- DWD-Niederschlagsarten-Radar: Ortsausschnitt und Standortmarker verwenden jetzt dieselbe ungerundete Mercator-/Bounding-Box-Projektion. Das Bild wird über eine echte Bildtransformation exakt auf den aktiven Ort zentriert; die bisherige CSS-Background-Positionierung mit systematischem Versatz entfällt.
- DWD-Niederschlagsarten-Radar: vollständige Klassenlegende gemäß DWD-Produkt hinter einem kompakten `(i)` ergänzt (großer/kleiner Hagel, Graupel, gefrierender Regen/Sprühregen, Schnee/Schneeregen, Regen/Sprühregen, nicht klassifizierbar, kein Niederschlag).
- Kurzfristmeteogramm: Wetterpiktogramme liegen nun direkt im SVG-Koordinatensystem des Temperaturgraphen und verwenden exakt dieselben X-Punkte. Dadurch laufen Piktogramme bei responsiver Skalierung nicht mehr vom Graphen auseinander.

## v0.9.21.0
- Start-/Splashscreen mit deutlich größerem, responsivem MID-Logo und ruhigerem Startbildschirm überarbeitet.
- Optionales Wetterkartenmodul für den erweiterten Modus ergänzt; standardmäßig deaktiviert und über die Dashboard-Einstellungen aktivierbar.
- DWD-WMS-Auswahl für ICON-EU, ICON, ICON-EPS, NowCastMIX und Meteosat mit Karten-, Modell-, Zeitschritt-, Druckflächen-, Basiskarten- und Deckkraftsteuerung ergänzt.
- Worker um freigegebene, validierte Wetterkarten-WMS- und Metadaten-Endpunkte erweitert.

## v0.9.20.1
- Buildfix: drei Cockpit-Meteogrammregressionen an das aktuelle Vollbreitenlayout und Einzeldatenfeld synchronisiert.
- CSS-Prüfungen der betroffenen Regressionen whitespace- und formatierungsrobust gemacht, ohne die fachlichen Layoutverträge abzuschwächen.
- Neue Meta-Regression `test-cockpit-regression-sync-09201.mjs` schützt die Synchronisierung dauerhaft.
- DWD-Niederschlagsarten-Radar aus v0.9.20.0 unverändert beibehalten; dessen Regression akzeptiert nun Folgereleases ab v0.9.20.0 statt nur exakt v0.9.20.0.

## v0.9.19.2
- 24-h-Meteogramm und erweiterte Einzeldaten auf die veröffentlichte Stable-Codeoptimierung v0.9.19.0 portiert.
- Automatisierte Code-Revisions-, Live-, API-, Browser- und Build-Budget-Prüfungen aus v0.9.19.0 beibehalten.

## v0.9.18.7
- Kurzfrist-Meteogramm optisch an der meteorologischen Vorlage ausgerichtet: Hauptzeitachse jetzt mit sauberer 6-Stunden-Beschriftung bei weiterhin stündlicher Datenauflösung.
- Overlay-Positionen für Zeit, Tageslabel, Wetterpiktogramme, Windfiedern und Hitlayer auf prozentuale Breiten-Skalierung umgestellt, damit Mobil- und Desktop-Layout korrekt mit dem SVG mitlaufen.
- Meteorologische Windfiedern im 24-h-Meteogramm präziser an der Zeitachse ausgerichtet; Datum/Zeitachse und Windreihe bleiben nun vollständig sichtbar.
- Neue Regression: responsive Meteogramm-Overlay-Skalierung und 6h-Hauptzeitachse abgesichert (`scripts/test-cockpit-meteogram-overlay-scale-09186.mjs`).

## v0.9.18.5
- Buildfix: Windfiedern verwenden die gültige interne WindUnit `kn`; ungenutzter ForecastCockpit-Windpfeil-Helfer entfernt.
- Fix: Die Screenreader-Hinweistexte der Kurzfrist-Hitlayer werden wieder korrekt versteckt und erscheinen nicht mehr im 24-h-Meteogramm.
- Fix: Die optische Auswahlumrandung im 24-h-Meteogramm wurde entfernt; die Einzeldatenkarte bleibt als primäres Feedback erhalten.
- UI: Plotgeometrie des 24-h-Meteogramms nachgeschärft, um die Darstellung auf schmalen Displays vollständiger und kompakter auszubalancieren.

## v0.9.18.5
- Kurzfrist-Meteogramm: Titel auf „24-h-Meteogramm“ verkürzt.
- Kurzfrist-Meteogramm: überlagernde Auswahlumrandung entfernt und Einzeldatenfeld unter dem Diagramm wiederhergestellt.
- Kurzfrist-Meteogramm: 24-h-Vollansicht für alle Displaybreiten beibehalten und Beschriftung auf Einzeldatenfokus präzisiert.

## v0.9.18.2
- Buildfix: acht veraltete Cockpit-Regressionen auf den bewusst entfernten 1-h/3-h-Schalter, das entfernte Zusatzdatenfeld und das nun vollbreit skalierende Meteogramm synchronisiert.
- Kurzfrist-Meteogramm dauerhaft auf einstündige Darstellung umgestellt; 1 h-/3 h-Schalter entfernt.
- Diagrammbereich bereinigt: zusätzliche störende Textlayer am/über dem Plot entfernt.
- Meteogramm auf vollbreit skalierende Darstellung umgestellt, sodass es ohne horizontales Scrollen vollständig sichtbar bleibt.
- 24-h-Leiste erneut komprimiert und flacher gestaltet.

## v0.9.18.1
- Buildfix: ungenutzten Alt-Helfer `shortTermVisibilityText` nach Entfernung der redundanten Detailkarte beseitigt; TS6133 verhindert.
- Kurzfrist-Meteogramm bereinigt: störenden Detailtext aus dem Diagrammbereich entfernt.
- Zusätzliches Detailfeld zwischen Legende und 24-h-Leiste entfernt.
- Datenfeld unter dem Diagramm komprimiert (ganzzahlige Temperaturen, Wind inkl. Böenspitze, Luftdruck statt Böen-Zeile).
- 24-h-Leiste weiter abgeflacht und kompakter gestaltet.

# MID v0.9.18.0

- Kurzfristdiagramm im Cockpit vollständig als eigenständiges, hochauflösendes Meteogramm neu aufgebaut.
- Dark Mode und Light Mode erhalten nun jeweils eigene, kontraststarke Meteogramm-Farbvariablen.
- Temperatur wird als ECMWF-Farbverlauf dargestellt; die gefühlte Temperatur bleibt als neutrale gestrichelte Vergleichslinie erkennbar und wird nicht als Tmin/Tmax-Farbcodierung interpretiert.
- Desktop zeigt ein echtes Overlay, Mobilgeräte eine separate kompakte Detailbox unterhalb des Diagramms.
- Alte kollidierende Diagramm-CSS-Klassen werden nicht mehr verwendet; dadurch entfallen die schwarze, leere Plotfläche und die seitlich herausgerückte Legende.
- Der TS5076-Regressionscheck ist jetzt vollständig deterministisch und ohne lokale TypeScript-Pfade.

# MID v0.9.17.5

- Buildfix: ungültige Mischung aus Nullish-Coalescing (`??`) und logischem ODER (`||`) in der Berechnung der Meteogramm-Achsenschritte beseitigt; die Tick-Fallbacks sind nun explizit getrennt. Die dedizierte TS5076-Regression lädt TypeScript portabel aus den Projektabhängigkeiten und verwendet den CAAS-Pfad nur noch als lokalen Fallback.
- Feinschliff: Achsen, Raster und Tagestrennung des Kurzfrist-Meteogramms optisch näher an einer professionellen Meteogramm-Darstellung ausgerichtet.
- Tooltip des Kurzfristdiagramms als kompakte Infobox mit Wettericon, klaren Parameterzeilen und besserer Lesbarkeit auf Mobilgeräten überarbeitet.
- Korrektur: Ganzzahlige maximale Niederschlagswahrscheinlichkeit im Cockpit wieder mit dem bestehenden Build-Regressionstest synchronisiert.
- Cockpit-Kurzfristbereich als kompaktes Meteogramm neu aufgebaut
- Tooltip/Overlay passt sich auf schmalen Displays mobil unten an statt Inhalte zu verdecken
- Temperatur- und gefühlte Temperatur im Kurzfristdiagramm farblich konsistent ohne alte Blau/Rot-Gegenüberstellung
- 24-Stunden-Leiste und Kurzfrist-Insights beibehalten, aber auf das neue Diagramm abgestimmt

# MID v0.9.17.4

- Die Cockpit-Kurzfristansicht ersetzt die bisherige Kurzfristmatrix nun durch eine neue, innovative Parametertimeline. Wetter, ECMWF-Temperatur, Niederschlag, Wind/Böen sowie Wolken- und Sichtsignal werden je Zeitpunkt in einer diagrammatischen Lane-Struktur verdichtet.
- Die 24-h-Leiste kennzeichnet Start und Ende jetzt eindeutig mit Datum und Uhrzeit. Damit entfällt die missverständliche reine Zeitspannen-Anzeige.
- Für schmale/mobile Ansichten wird die 24-h-Leiste deutlich flacher und kompakter gerendert. Die Stundenchips bündeln weiterhin Temperatur, Wetter, Niederschlag und Wind, verbrauchen aber spürbar weniger Höhe.
- Responsive CSS- und Interaktionsanpassungen sichern, dass sowohl die neue Kurzfristdiagrammansicht als auch die verdichtete 24-h-Leiste auf kleinen Displays nutzbar bleiben.
- CI-Korrektur: Die Temperatur-Lane erklärt weiterhin ausdrücklich das Temperaturmittel, sodass der bestehende Cockpit-Usability-Vertrag und die zugehörige Regression erfüllt bleiben.

# MID v0.9.17.3

- Die Cockpit-Kurzfristansicht reagiert nun wirklich auf Klick/Tipp: Sowohl die Kurzfristmatrix als auch 90-Minuten-Slots und 24h-Stundenfelder öffnen bzw. aktualisieren sofort die Kurzfristdetails.
- Temperaturen in den Kurzfristansichten werden jetzt mit einer ECMWF-orientierten Farbskala dargestellt.
- Die bisherige Grafik wurde durch eine neue interaktive Kurzfristmatrix ersetzt, die Temperatur, gefühlte Temperatur, Wetter, Niederschlag, Wind/Böen, Bewölkung, Feuchte, Sicht und Gewittersignal direkt pro Zeitpunkt zusammenführt.
- Für schmale/mobile Displays werden die Kurzfristkacheln gezielt in flache, horizontal gestreckte Felder umgebaut. Damit bleiben Scrollen und Überblick auf kleinen Geräten deutlich besser nutzbar.
- Die responsive 24h-Vorschau wurde ebenfalls auf echte Interaktion und mobile Einspaltigkeit nachgeschärft. Eine neue Regression prüft Interaktivität, ECMWF-Farben, Matrixdarstellung und mobile Flachfelder.

# MID v0.9.17.2

- Der Kurzfristbereich unterhalb der 90-Minuten-Vorhersage wurde gestalterisch erneut überarbeitet. Statt einer einfachen Kachelmatrix erscheint dort jetzt eine hochwertigere, professionellere Kurzfrist-Sektion mit klarerer Informationshierarchie.
- Die stündliche Vorschau zeigt nun bis zu 24 Stunden in einer kompakten, horizontal scrollbaren Timeline-Leiste. Damit entfallen die bislang als unzweckmäßig bewerteten zweispaltigen Stundenkacheln.
- Die Kurzfrist-Metriken bleiben als Premium-Spotlights sichtbar und passen sich je nach Displaybreite abgestuft an Desktop, Tablet und Smartphone an. Für schmale Geräte werden nur die Kennzahlen gestapelt; die Stundenleiste bleibt einspaltig beziehungsweise horizontal nebeneinander.
- Die Änderung folgt ausdrücklich dem MID-Grundsatz, neue UI-Bausteine immer displaygrößen- und gerätegerecht auszuarbeiten. Eine neue Regression sichert 24h-Timeline, Premium-Layout und responsive Einspaltigkeit der Kurzfristvorschau ab.

# MID v0.9.17.1

- Das Kurzfrist-Cockpit unterhalb der 90-Minuten-Vorhersage wurde grafisch neu aufgebaut. Die bisherige knappe Kennzahlenleiste wird durch eine responsive Kurzfrist-Insight-Zone mit stündlicher Vorschau, Temperaturspanne, Windspitze und Niederschlagsfenster ersetzt.
- Die Kurzfristgrafik nutzt kompaktere Proportionen mit weniger Leerraum und bleibt je nach Rasterwahl beziehungsweise Displaybreite besser lesbar. Unterhalb des Diagramms passt sich die Stunden-Vorschau flexibel an schmale und breite Displays an.
- In den Cockpit-Übersichten wird der zusätzliche 14-Tage-Streuungstext oberhalb des MID-Prognose-Kompasses entfernt, da der Kompass diese Information bereits inhaltlich abdeckt. Die Überschrift bleibt erhalten, die Legende bleibt kompakt sichtbar.
- Neue Regression schützt die neue Kurzfrist-Insight-Zone, die stündliche Vorschau und das Entfallen des redundanten 14-Tage-Textblocks im Cockpit.
- CI-Korrektur: Die maximale Niederschlagswahrscheinlichkeit wird im neu gestalteten Bereich weiterhin direkt ganzzahlig aus allen dargestellten Kurzfristpunkten berechnet; der bestehende Schutztest `test-build-percent-integers-091513.mjs` bleibt damit erfüllt.

# MID v0.9.16.1

- Die 14-Tage-Übersicht verhindert auf Smartphones im Querformat Überlagerungen zwischen benachbarten Karten. Kartenkopf, Konsistenzfeld und Messzeilen besitzen nun feste responsive Raster und bleiben vollständig innerhalb ihrer Kachel.
- Konsistenzwerte werden stets einzeilig dargestellt. Auf schmalen Displays liegen Messwert und Bezeichnung über dem zugehörigen Balken, sodass Regen- und Windangaben nicht mehr in die nächste Karte ragen.
- Der Widget-/PNG-Generator erhält eine moderat breitere Exportfläche und größere Schriften für alle wesentlichen Inhalte.
- Widget-Hazards werden auf die höchste am jeweiligen Tag vorhandene Warnstufe begrenzt; niedrigere Warnstufen werden in dieser kompakten Exportansicht ausgeblendet.
- Neue Regression schützt Querformatlayout, Konsistenzfelder, Widget-Lesbarkeit und Hazard-Priorisierung.

# MID v0.9.15.14

- KONRAD3D rendert im Kompositbild jetzt die vollständigen Vektorelemente nicht mehr nur für genau eine, sondern für bis zu drei der relevantesten sichtbaren Zellen. Dadurch erscheinen Zugbahn, Unsicherheitskorridor, Ellipsen und Prognosepunkte wieder vollständig, wenn mehrere plausible K3D-Zellen im Kartenausschnitt liegen.
- Die K3D-Vektorlayer wurden optisch nachgeschärft. Spur, Zellfläche, Ellipsen und Korridor erhalten nun stärkere Konturen beziehungsweise Schatten und nutzen im dedizierten Pane einen normalen Mischmodus, damit sie über Radar- und Satellitenraster auch im Dark-Theme zuverlässig sichtbar bleiben.
- Die Prognoseellipsen werden bei den hervorgehobenen Zellen dichter dargestellt, sodass fehlende Zwischenelemente im 5-Minuten-Raster nicht mehr wie abgerissene K3D-Spuren wirken.

# MID v0.9.15.13

- Produktionsbuild repariert: `RadarNowcastInterval` wird in `forecastFusion.ts` nun als TypeScript-Typ importiert. Die Intervallauswertung für die appweite DWD-RV-Punkt-Nowcast-Fusion kompiliert dadurch ohne TS2304.
- Prozentanzeigen werden an der Oberfläche konsequent ganzzahlig ausgegeben. Insbesondere zeigt das Kurzfrist-Cockpit das maximale Niederschlagsrisiko gerundet statt mit langen Fließkommazahlen.
- Weitere potenziell kontinuierliche Prozentwerte in Wetterzwilling, Modellverifikation, Gewitterrisiko, Ensemble-Konsistenz, Radar-Deckkraft und Synoptik werden vor der Anzeige gerundet; interne Berechnungen behalten ihre volle Genauigkeit.
- Bestehende Gewitter-Detailregressionen wurden auf die nun ausdrücklich ganzzahlige Prozentdarstellung aktualisiert.
- Neue Regression schützt den fehlenden `RadarNowcastInterval`-Import und verhindert die erneute Ausgabe ungerundeter Prozentwerte an den betroffenen Oberflächen.

# MID v0.9.15.12

- Die 5-Minuten-DWD-RV-Standortserie aus dem Radar-Nowcast wird zentral in alle Kurzfristdarstellungen übernommen. Standalone-Kurzfrist, Cockpit und Wetterzwilling verwenden damit dieselben direkten Standorttreffer, trockenen Intervalle, Unterbrechungen und reinen Umfeldsignale.
- Direkte Standorttreffer werden über sämtliche im Zielintervall liegenden 5-Minuten-Schritte mengen- und wahrscheinlichkeitsgewichtet. Unterbrochene Phasen bleiben getrennt; reine Umfeldechos erhöhen keine Standortmenge und dürfen die Standortwahrscheinlichkeit nur begrenzt beeinflussen.
- Für ältere beziehungsweise reduzierte Radarantworten ohne Punktserie bleibt ein eng begrenzter, standortgebundener Aggregat-Fallback erhalten; als „nearby“ oder „approximate“ gekennzeichnete Echos sind davon ausgeschlossen.
- KONRAD3D übernimmt die amtliche aktuelle Zellfläche aus den geodätischen Polygonkoordinaten und nutzt deren plausibilisierten Mittelpunkt für Marker, Zellfläche und die konsistent verschobene Prognosespur.
- K3D-Vektoren und HTML-Marker liegen in getrennten, expliziten Leaflet-Panes. Prognosepunkte werden als robuste HTML-Marker gerendert; nur die relevanteste sichtbare, radarbestätigte Zelle erhält die vollständig beschriftete Zugbahn.
- Lokale K3D-Zellen werden gegen aktuelle DWD-Radaranker plausibilisiert. Zellen ohne räumlich passende Radarechos werden im Nahbereich nicht mehr über der Karte angezeigt. Zellfläche, Geschwindigkeitseinheiten und Flächenangaben werden aus den amtlichen XML-Feldern normalisiert.
- Neue Regression schützt die appweite Punkt-Nowcast-Fusion, den Ausschluss reiner Umfeldechos, unterbrochene Standortphasen, K3D-Polygon-/Geschwindigkeitsauswertung, getrennte Pane-Ebenen und die räumliche Echo-Plausibilisierung.

# MID v0.9.15.10

- KONRAD3D-Objekte werden an den aktuell gewählten Radarzeitstand gebunden; außerhalb eines engen Zehn-Minuten-Fensters werden keine zeitlich fremden Zellobjekte über das Radar gelegt.
- K3D-Zugbahnen werden nur noch für Zellen gezeichnet, deren aktuelles Zellzentrum im sichtbaren Kartenausschnitt liegt. Beim Verschieben der Karte erscheinen daher keine losgelösten Prognosespuren ohne zugehörige aktuelle Zelle mehr.
- Vollständige Zugbahn, Prognosepunkte und Unsicherheitsgeometrie werden auf die zwei relevantesten sichtbaren Zellen begrenzt; weitere sichtbare Zellen behalten Marker und aktuelle Zellfläche.
- Amtliche Prognosepunkte werden räumlich gegen Zellgeschwindigkeit und Vorlauf plausibilisiert. Unplausibel weit versetzte Koordinaten werden verworfen und nur bei belastbarem Zugvektor transparent ersetzt.
- Unsicherheitsradien und permanente Zeitbeschriftungen wurden begrenzt, damit fehlerhafte Einheiten oder viele benachbarte Zellen keine kartengroßen Ellipsen und Beschriftungsteppiche erzeugen.
- Der KONRAD3D-Worker liest bei Längenfeldern nun sowohl das amtliche XML-Attribut `unit` als auch `units`; Meterwerte werden dadurch nicht mehr fälschlich als Kilometer interpretiert.
- Neue Regression schützt Kartenausschnitt-, Zeit- und Geometrieplausibilität sowie die Singularform des DWD-Einheitenattributs.

# MID v0.9.15.9

- Ein Tipp auf eine Push-Benachrichtigung öffnet immer die normale MID-Startansicht im Scope-Root. Von Push-Payloads mitgegebene Deep-Links oder Einstellungs-Hashes werden verworfen; der Benachrichtigungsort bleibt über sichere Standortparameter erhalten.
- Bereits geöffnete MID-Fenster erhalten ein eigenes `MID_NOTIFICATION_OPEN`-Signal, schließen Einstellungs- und Impressumsdialoge und springen an den Anfang der Startansicht.
- KONRAD3D-Vektorelemente verwenden einen expliziten Leaflet-SVG-Renderer im dedizierten Nowcast-Pane. Zellfläche, Zugbahn, Unsicherheitskorridor, Ellipsen und Prognosepunkte liegen dadurch zuverlässig oberhalb des Radarrasters.
- K3D-Geometrien erhalten kontrastierende Halos und permanente, kompakte Zeitmarken. Bei fehlenden Einzelpunkten kann zusätzlich eine vorhandene prognostizierte Endposition zur transparent abgeleiteten Spur bis +60 Minuten genutzt werden.
- Neue Regression schützt Startansicht bei Benachrichtigung, Overlay-Schließung, K3D-Pane/Renderer, sichtbare Geometrie und Endpunkt-Fallback.

# MID v0.9.15.8

- DWD-HX-250-m-Radar wird nicht mehr als rechteckiges WGS84-Bild über die Karte gestreckt, sondern kachelweise und projektionstreu aus der im HDF5 hinterlegten ellipsoidischen Polarstereografie nach Web-Mercator abgebildet.
- Die HX-Rasterachse wird gemäß Produktmetadaten korrekt behandelt: Pixelzentren beginnen bei x=0/y=0, die y-Koordinate nimmt je Rasterzeile um 250 m ab.
- Falsche Verortungen gegenüber dem DWD-RV-1-km-Komposit, insbesondere im Westen und Norden Deutschlands, werden dadurch beseitigt.
- Sichtbare Kartenausschnitte werden als Leaflet-Canvas-Kacheln berechnet; Farb-Lookup, Kachelpuffer und asynchrones Rendering begrenzen Rechenlast und Speicherbedarf.
- Neues Projektionsmodul verarbeitet `+a`, `+b`, `+x_0`, `+y_0`, `+lat_ts` und `+lon_0` aus `projdef` einschließlich ellipsoidischer Vorwärts- und Rücktransformation.
- Neue Regression prüft alle vier amtlichen HX-Eckreferenzen auf Zentimetergenauigkeit sowie die Rasterzelle für Münster.

# MID v0.9.15.7

- Produktionsbuild repariert: `ResolvedKonradTrackPoint[]` ist für die veränderliche KONRAD3D-Prognosepunktliste nun explizit typisiert.
- Amtliche und abgeleitete K3D-Punkte können dadurch gemeinsam verarbeitet werden; `derived` ist im TypeScript-Build zulässig.
- Keine funktionale Änderung an Radar-, Nowcast- oder Worker-Datenlogik.

# MID v0.9.15.6

- Ensemble-Diagramme für Temperatur, Niederschlag und Wind besitzen am Desktop nun eine eigene, von Recharts unabhängige Treffer- und Tooltip-Schicht. Hover, Klick zum Fixieren, Außenklick, Escape sowie Pfeiltasten funktionieren einheitlich; eine senkrechte Führungslinie kennzeichnet den aktiven Tag.
- Das 250-m-Radar verwendet in Deutschland vorrangig das flächendeckende DWD-HX-Deutschlandkomposit statt eines einzelnen Standortradars. Lokales PX250 bleibt nur als klar gekennzeichneter Fallback erhalten.
- HX-/PX250-Reflektivität wird für die gemeinsame Darstellung über Z=200·R^1,6 in eine äquivalente Regenrate umgerechnet und mit derselben mm/h-Farbskala wie das 1-km-Radar dargestellt.
- Der KONRAD3D-XML-Parser verarbeitet die amtlichen `forecast/centroid_forecasts/centroid_forecast`-Elemente einschließlich aller 5-Minuten-Positionen und Unsicherheitsellipsen. Ein fehlerhaft escaptes dynamisches RegExp, das Prognosepunkte verschluckte, wurde korrigiert.
- Das Kompositbild zeichnet aktuelle Zellfläche, Zugbahn bis +60 Minuten, Prognosepunkte, 1σ-Korridor und Unsicherheitsellipsen oberhalb des Radars. Nur bei fehlenden amtlichen Einzelpunkten wird eine transparent gekennzeichnete Vektor-Spur ergänzt.
- Neue Regression prüft alle drei Desktop-Ensemble-Interaktionen, HX-Priorisierung, gemeinsame Regenratenskala sowie das echte amtliche KONRAD3D-XML-Schema funktional.

# MID v0.9.15.5

- Tagescharaktere werden appweit ausschließlich aus dem astronomischen beziehungsweise zivilen Tagesfenster abgeleitet; Nachtregen desselben Kalendertags beeinflusst weder Text noch Tagespiktogramm.
- Die auf einen Tag folgende Nacht wird zentral und datumsübergreifend als Abend des Prognosetags plus Morgen des Folgetags gebildet. Cockpit, klassische Tageskarten, Detailansicht, Widgets und Tropennachtprüfung verwenden dieselbe Grenze.
- Das 7-Tage-Cockpit weist relevante Tagesschauer auch bei moderater Tageswahrscheinlichkeit als „Schauer“ aus und fällt nicht mehr auf „Ruhig“ zurück.
- Die 7-Tage-Kurzinterpretation verwendet für Wetterregime und Niederschlagsstärke nur Tagesstunden; kalendernächtliche Mengen können den Tagesabschnitt nicht mehr als regnerisch deklarieren.
- Neue Regression schützt Tages-/Folgenachtgrenzen, Nachtregen-Ausschluss, Tagesschauerklassifikation und die gemeinsame appweite Periodenlogik.

# MID v0.9.15.4

- Gewitter-Ortslisten werden bei zu wenigen Overpass-Treffern aktiv durch entlang der 60-Minuten-Zugbahn gesampelte Ortsabfragen ergänzt; der Bezugsort bleibt nur ein Eintrag unter mehreren.
- Eine fehlende oder zu kurze KONRAD3D-Prognosespur wird aus offizieller Zugrichtung und -geschwindigkeit in 10-Minuten-Schritten transparent ergänzt.
- Overpass-Endpunkte werden parallel abgefragt, Rückwärtsgeokodierungen gecacht und begrenzt parallelisiert; dadurch bleibt die Gewitterinformation trotz Mehrortanalyse reaktionsfähig.
- Radar- und Nowcast-Layer bleiben beim Zoomen montiert, behalten Kachelpuffer und laden angrenzende Zeitstände mit minimaler Deckkraft vor. Dadurch sinken Flackern und Nachladen beim Panning, Zoomen und Abspielen.
- Die Wetterblick-Prüfung wurde als Transfer-Audit dokumentiert: Bedienprinzipien werden eigenständig nachgebaut; proprietärer Code und Wetterblick-Daten werden nicht kopiert oder gescrapt.
- Neuer Regressionstest schützt Mehrort-Fallback, 60-Minuten-Spur, Quellenkennzeichnung und Layer-Performance.

# MID v0.9.15.3

- Cockpit-Registeransicht: Die 14-Tage-Angabe zur zunehmenden Unsicherheit nennt neben dem Wochentag nun immer auch das eindeutige Datum im Format dd.mm.
- Auch die Tooltip-Beschriftung des 14-Tage-Mini-Ribbons kombiniert Wochentag und Datum.
- Neuer Regressionstest schützt die Datumsangabe in der Registerzusammenfassung.

# MID v0.9.15.2

- 7-Tage-Stundenübersicht: ECMWF-orientierte Temperaturfarben deutlich dezenter und kompakter dargestellt.
- Ensemble-Diagramme: Desktop-Hover nach dem Schließen oder einem Außenklick zuverlässig reaktiviert; Tooltips stehlen dem Diagramm nicht länger den Mauszeiger.
- Regressionstest für Temperaturfeld-Geometrie und Desktop-Tooltip-Reaktivierung ergänzt.

# Changelog

## 0.9.66.8

- DACH-Gefahrenflächen sind native MapLibre-MultiPolygone; ein separater Beschriftungs-Rasterlayer rendert Grenzen, Länder-, Regions- und Städtenamen darüber.
- Datumsübergreifende Zeitfenster zeigen Start- und Enddatum eindeutig, „Gefrierhöhe“ heißt im Extremwetter-Ausblick nun „Nullgradgrenze“, und Popup-/Diagnosefelder sind kontrastreicher und größer gesetzt.
- Änderungen an Sichtbarkeit und Reihenfolge der Dashboard-Sektionen werden synchron und mit funktionalen Zustandsänderungen gespeichert, sodass sie einen App-Neustart zuverlässig überstehen.

## 0.9.15.11

- Niederschlags-Nowcast: vollständige 5-Minuten-DWD-RV-Punktserie bis +120 Minuten.
- Getrennte Niederschlagsphasen werden mit Unterbrechungen und tatsächlicher letzter Endzeit ausgewiesen.
- Echos im Kilometerumfeld werden nicht mehr als Standorttreffer oder Standortmenge gewertet.
- Aktuelle Standortbeobachtung wird mit nativem RADOLAN YW gegengeprüft; OPERA dient nur als Kontrollabgleich.

## 0.9.15.1
- Gewitterinformationen weisen jetzt mehrere aktuell vom radarbestimmten Zellbereich erfasste Orte mit „Jetzt“ aus.
- Auf der prognostizierten Zugbahn liegende Orte erhalten eine individuelle lokale Ankunftszeit beziehungsweise ein Zeitfenster und werden chronologisch sortiert.
- Vier klar getrennte Ortsstatus verhindern falsche Sicherheit: aktuell betroffen, voraussichtlich auf der Zugbahn, möglicher Treffer und nur im Unsicherheitskorridor.
- Die Ortsbestimmung kombiniert den geometrischen KONRAD3D-Zell- und Prognosekorridor mit OpenStreetMap/Overpass; ein sparsamer BigDataCloud-Sampling-Fallback bleibt bei Ausfällen verfügbar.
- Der Bezugsort wird separat gegen aktuelle Zellfläche, Zugachse und Prognoseunsicherheit geprüft und bei Relevanz in die Ortsliste aufgenommen.
- Direkt in der Gewitterkachel erscheinen die wichtigsten Orte; die vollständige Liste mit Statusbegründung, Zugachsenabstand, Ankunftsfenster und Quellenangabe liegt hinter dem Info-Button.
- Neue Regression schützt Ortskorridor, Statusklassifizierung, Zeitlokalisierung, vollständige UI-Liste und Worker-/Frontend-Datenvertrag.

## 0.9.15.0
- Kurzfristige Temperatur- und Gefühlstemperaturwerte erhalten eine meteorologische Plausibilitätsprüfung gegen isolierte 15-Minuten-Ausreißer. Bei ruhiger, trockener Wetterlage werden einzelne ungestützte Sprünge zeitlich interpoliert und transparent als plausibilisiert gekennzeichnet.
- Die klassische 7-Tage-Stundenübersicht öffnet den aktuellen Tag direkt an der aktuellen Ortsstunde. Im 3-Stunden-Raster werden alle Zeitschritte gezeigt; im 1-Stunden-Raster zunächst ein sinnvoll zentriertes Zeitfenster und auf Wunsch der vollständige Tag.
- Wettertexte der Stundenkacheln wandern in ein Hover-/Fokus-Overlay; die Piktogramme werden größer. Temperaturfelder verwenden eine ECMWF-orientierte 2-m-Temperaturfarbskala mit kontrastangepasster Schrift.
- Gewitterinformationen übernehmen zusätzliche KONRAD3D-, HYMEC-, Radar-, Zell-, Zugbahn-, Hagel-, Starkregen-, Wind- und NWP-Parameter. Relevante Auswirkungen stehen direkt in der Kachel; vollständige Detailgruppen einschließlich optionaler DWD-Mesozyklonenerkennung liegen hinter dem Info-Button.
- Historische Release-Hinweise zu später vollständig entfernten oder stillgelegten Großfunktionen wurden aus der nutzerseitigen Historie bereinigt. Statusmeldungen zur Stilllegung bleiben erhalten; der Wetterstationsanbieter „Synoptic Data“ ist davon ausdrücklich nicht betroffen.
- Neue Regression schützt Plausibilisierung, Stundenfokus, 3h-/1h-Umfang, Piktogramm-Overlay, Temperaturfarblogik, Gewitterdetails und bereinigte Release-Historie.

## 0.9.14.5
- Empfehlungen aus den zuletzt gesichteten Wartungs-/UI-Hinweisen werden für kommende Releases als fortlaufende Release-Leitlinie übernommen.
- Nachtpiktogramme wurden kontrastreicher gemacht: hellere Nacht-Hintergründe, hellere Nachtwolken und stärkere Mond-/Niederschlagskontraste verbessern die Erkennbarkeit auf hellen Karten und in kleinen Größen.
- Tag- und Nachtpiktogramm stehen in Tageskarten, klassischer 7-Tage-Ansicht und Widget/Quickfacts nun nebeneinander; das Nachticon liegt nicht mehr auf dem Tagesicon.
- Größenverhältnis von Tages- zu Nachtpiktogrammen harmonisiert; Nachticons bleiben kleiner, aber deutlich besser lesbar.
- Böenangaben im 7-Tage-Cockpit werden nicht mehr abgeschnitten; das Layout reserviert mehr Platz und die kompakte Beschriftung bleibt vollständig sichtbar.
- Klassische 7-Tage-Stundenansicht: Wetter-/Bewölkungstext wird nicht mehr hart abgeschnitten und die Temperaturkachel wurde optisch an das übrige App-Design angeglichen.
- Neuer Regressionstest schützt die UI-Politur für Nachtpiktogramme, Böenlayout und klassische Stundenliste.

## 0.9.14.4
- Buildfix im 3-Stunden-Aggregator des Prognose-Cockpits: `wind` ist jetzt im typisierten Mittelwertvertrag enthalten; der GitHub-Fehler TS2345 ist beseitigt.
- Eigener Regressionstest schützt die Windaggregation im 3-Stunden-Raster.
- Der Piktogramm-/ISO-Test isoliert die WMO-Klassifikationsfunktion robust, auch nachdem zusätzliche SVG-Hilfskomponenten ergänzt wurden.

## 0.9.14.3
- Wolkenformen werden zusätzlich zum Wolkenstockwerk klassifiziert: Stratus/Hochnebel, Altostratus, Cirrus, Cumulus, Cumulonimbus und mehrschichtige Bewölkung besitzen nun klar getrennte SVG-Formen.
- Flache Schichtbewölkung, mittelhohe Wolkendecken, faserige hohe Wolken, Haufenwolken und hochreichende Gewitterwolken sind in kleinen Tages-, Nacht- und Stundenpiktogrammen deutlicher unterscheidbar.
- Tag-/Nacht-Hintergründe reagieren jetzt zusätzlich auf die Wolkenform; Nachtnebel, Schichtbewölkung und konvektive Lagen bleiben dadurch auch auf hellen Karten lesbar.
- Bei hoher bzw. mittelhoher Schichtbewölkung kann Sonne oder Mond gedämpft hinter der Wolkendecke erscheinen; nächtlicher Nebel erhält einen schwach durchscheinenden Mondhinweis.
- Neuer Regressionstest schützt Wolkenformklassifikation, Tag-/Nacht-Hintergrund und appweite Metadatenattribute der Piktogramme.

## 0.9.14.2
- Wetterpiktogramme weiter geschärft: klarere visuelle Trennung zwischen Schichtbewölkung, mehrschichtiger Bewölkung und konvektiver Bewölkung.
- Tages- und Nachtpiktogramme erhalten nun einen dezenten semitransparenten Hintergrund: tagsüber heller, nachts dunkler, damit der Tag-/Nachtcharakter schneller erkennbar bleibt.
- Nachtpiktogramme sind dadurch auf hellen Karten und in kleinen Darstellungen besser ablesbar, ohne stilistisch aus dem App-Bild zu fallen.
- Hohe Bewölkung und Quellwolken wurden zeichnerisch kontrastreicher ausgearbeitet, damit die Wolkenstockwerke stärker voneinander unterscheidbar sind.

## 0.9.14.1
- 3h-/1h-Umschalter im Prognose-Cockpit summieren Niederschlagsmengen im 3-Stunden-Raster jetzt korrekt auf; Wahrscheinlichkeiten und repräsentative Wettercodes werden blockweise neu verdichtet.
- Tages- und Nachtpiktogramme nutzen nun konsequent die Folgnachtlogik: Das kleine Nachticon eines Tages wertet nur die folgende Nacht aus und nicht mehr die zurückliegende Nacht desselben Kalendertages.
- Nachtpiktogramme wurden appweit vereinheitlicht (auch im Cockpit, in Widgets und Tageskarten): transparenter Stil ohne weiße Kachel, klarerer Größenunterschied zu Tagesicons und stärkere Erkennbarkeit auf hellem Hintergrund.
- Klassische Tagesansicht klappt die Stundenliste jetzt auch am Desktop direkt unter dem jeweiligen Tag auf; damit werden redundante Parallelansichten reduziert.
- Bewölkungsdarstellung der Piktogramme kontrastreicher verfeinert, insbesondere für hohe Bewölkung und klare Nachtlagen.

## 0.9.14.0
- Tmin/Tmax in Tageskarten werden relativ zum jeweiligen Klimamittel dezent abgestuft; höhere Tmax-Abweichungen erscheinen dunkler rot, deutlich kühlere Tmin dunkler blau.
- 7-Tage-Cockpit: Tageskarte öffnet direkt den einstündigen klassischen Tagesverlauf als Akkordeon; Rückkehr über „Tagesansicht“.
- Redundante vollständige Kurzfrist- und 7-Tage-Module aus Cockpit-Untermenüs entfernt; nur die eigenständige Ensemble-Analyse bleibt separat aufklappbar.
- Register- und Ribbon-Cockpit in den Einstellungen klarer voneinander abgegrenzt.

## 0.9.13.3
- SEO-Buildfix: Die statische HTML-Releaseversion wird nun durch `sync-version.mjs` automatisch mit Paket, Baseline, Worker und Service Worker synchronisiert.
- Der Regressionstest `test-seo-discoverability-0990.mjs` läuft damit wieder erfolgreich.

## 0.9.13.2
- Buildfix für die meteoblue-ähnliche Tagesdetailansicht: `detailListWeatherLabel()` verwendet jetzt korrekt `PrecipitationParts` statt `PrecipSample`.
- Die dadurch ausgelösten TS2339-/TS2345-Fehler für `type`, `displayCode` und `weatherLabel` sind beseitigt.
- Neuer Regressionstest schützt den Niederschlagstypvertrag der aufklappbaren Tagesdetails.

## 0.9.13.1
- Tageskarten zeigen das kleine Nachtpiktogramm jetzt ohne zusätzlichen „Nacht“-Schriftzug; Tages- und Nachticon überlappen dabei nicht mehr.
- Die tageweise Vorhersage erhält für kompakte Ansichten ein meteoblue-ähnliches Akkordeon: Klick auf einen Tag klappt 3h-Details direkt darunter auf, inklusive Umschalter auf 1h.
- Das 14-Tage-/Cockpit-Tag-Nacht-Paar übernimmt ebenfalls die schriftzugfreie Nachtpiktogramm-Darstellung.
- Regressionstests für Wolkenschicht-/Tag-Nacht-Piktogramme und Tagesdetails an die neue UI angepasst.

## 0.9.12.2
- GitHub-Produktionsbuild repariert: die nach der Radar-Metadatenverdichtung ungenutzte Hilfsfunktion `radarClockRange` wurde entfernt.
- Radarzeitformatierung, hervorgehobene 2-h-Summe und Info-Popover aus v0.9.12.1 bleiben unverändert.
- Eigener Regressionstest verhindert die erneute Einführung der ungenutzten Deklaration.

## 0.9.11.1
- GitHub-Produktionsbuild repariert: `RadarNowcast | null` wird an den drei neuen Kurzfrist-/Cockpit-Props explizit zu `undefined` normalisiert.
- Keine fachliche Änderung gegenüber v0.9.11.0.

## 0.9.11.0
- Kurzfrist-Nowcasting auf die ersten 90 Minuten erweitert: standardmäßig 5–6 15-Minuten-Kacheln statt nur vier, inklusive Radar-/Nowcast-Einfluss auf Niederschlagswahrscheinlichkeit und -signal.
- Windpfeile im Prognose-Cockpit, in der Kurzfristvorhersage und in den Tageskarten weiter vereinheitlicht; warnstufenabhängige Einfärbung bleibt konsistent.
- Kurzfrist-Zusammenfassung sprachlich korrigiert: keine irreführenden Formulierungen wie „Klar ab 16:00 Uhr“ mehr, sondern zukunftsbezogene oder laufende Aussagen.
- Kurzfristdiagramm optisch entzerrt: mehr vertikaler Platz, getrennte Ebenen für Piktogramme, Temperaturwerte, Windpfeile und Uhrzeit, sodass keine Überlagerungen mehr auftreten.
- Professionelle Wetterpiktogramme werden in den betroffenen Kurzfrist- und Cockpit-Modulen konsistent verwendet.

## 0.9.10.0
- 14-Tage-Cockpit um professionelle Wetterpiktogramme je Tag und in der Fokuskarte ergänzt.
- Windpfeile in Kurzfrist-, 7-Tage- und 14-Tage-Cockpit vereinheitlicht; Richtung und warnstufenabhängige Farbformatierung entsprechen der Kurzfristvorhersage.
- Hyperlokaler Stationsanker wird gemeinsam auf 90-Minuten-Ultrakurzfrist, Cockpit-Kurzfrist und vollständige Kurzfristvorhersage angewandt.
- Kurzfristtexte verdichtet: z. B. „Trocken · Böen bis 26 kt um 21:00“ statt der sperrigen bisherigen Formulierung.

## 0.9.9.0
- Suchmaschinen-Discoverability für `https://www.midwx.app/` ergänzt: Canonical, indexierbare Meta-Tags, Open Graph, strukturierte WebApplication-Daten, robots.txt, XML-Sitemap, CNAME und statischer No-JavaScript-Fallback.
- Prognose-Cockpit auf Desktop repariert: Icon, Titel, Zusammenfassung und Mini-Ribbon besitzen feste Gridbereiche; kein seitliches Verrutschen oder unkontrolliertes Umbrechen von „7 Tage“.
- Register- und Ribbon-Cockpit für 1, 2 und 3 aktive Horizonte sowie Desktop, Tablet und Smartphone responsiv abgesichert; klassische Ansicht bleibt unberührt.

## 0.9.8.0
- Warnungsbereiche für automatische und amtliche Warnungen auf allen Displaygrößen deutlich verdichtet; Titel und Gültigkeit bleiben im eingeklappten Zustand sichtbar.
- Kurzfrist-Cockpit mit eindeutiger 3-h/1-h-Umschaltung, meteorologisch vollständigem 90-Minuten-Schnellblick, verbesserten Achsen, Wetterpiktogrammen und warnstufenabhängig eingefärbten Windpfeilen.
- 14-Tage-Schalter fachlich neu aufgebaut: Temperatur relativ zum Klimamittel, ein kombinierter Niederschlagsbalken und Wind/Böen in den Farben der vollständigen Diagramme.
- Temperaturabweichungen werden in Kelvin, Tmin blau und Tmax rot dargestellt.
- Niederschlagsdiagramm: P10–P90-Schalter blendet nur die schwarzen Spannen aus; Achsen und Diagrammrahmen bleiben erhalten.
- Ensemble-Tooltips auf Desktop auf Hover/Fine-Pointer umgestellt; Touchgeräte behalten Klickbedienung.
- Nutzlose durchschnittliche Ensemble-Mitglieder-Zeile entfernt und Konsistenz-/Modellstatus kompakter dargestellt.

## 0.9.7.1
- GitHub-Produktionsbuild repariert: fünf ungenutzte Deklarationen in `ForecastCockpit.tsx` entfernt (`CloudRain`, `Compass`, `GaugeCircle`, `finite`, `circularDelta`).
- Keine fachliche oder visuelle Änderung gegenüber v0.9.7.0.

## 0.9.7.0
- Prognose-Cockpit: Kurzfrist standardmäßig auf 3h-Darstellung mit 1h-Umschaltung und 90-Minuten-Schnellblick erweitert.
- 7-Tage-Farblogik durch Legende und geschärfte Tagesregime verständlicher gemacht.
- 14-Tage-Übersicht auf 3-Parameter-Tageskarten umgestellt und Konsistenzformel app-weit harmonisiert.
- Amtliche Warnungen standardmäßig eingeklappt; sichtbarer Fokus auf Titel und Gültigkeitspille.
- Niederschlagssystematik für konvektiv vs. stratiform in Frontend und Worker nachgeschärft.

# MID v0.9.7.0

- Kurzfristansicht auf klare 3-Stunden-Standarddarstellung umgestellt; per Umschalter lässt sich stündlich verdichten.
- Die horizontale Temperatur-Referenzlinie in der Kurzfrist ist nun explizit als 24h-Mittel ausgewiesen; die bisher missverständliche Darstellung wurde ersetzt.
- Zusätzlicher 90-Minuten-Schnellblick mit kompakten 15-Minuten-Slots für Niederschlag/Wahrscheinlichkeit direkt im Prognose-Cockpit.
- 7-Tage-Karten inhaltlich entschärft und objektiver gemacht: `Regenreich`/`Windig` werden nicht mehr bei geringen Mengen oder Einzelereignissen ausgelöst.
- 14-Tage-Übersicht erhält pro Tag drei selbsterklärende Parameterbalken für Temperatur relativ zum Klimamittel, kombinierten Niederschlag sowie Wind/Böen.
- Konsistenz im 14-Tage-Cockpit an dieselbe Bewertungslogik wie in der vollständigen Analyse angeglichen.
- Amtliche Warnungen bleiben standardmäßig kompakt eingeklappt; Titel und Gültigkeitspille sind sofort sichtbar.
- Relevante Regressionen bestanden: Cockpit-Klarheit, optionale Prognose-Cockpits sowie app-weite konvektiv/stratiforme Niederschlagslogik.

# MID v0.9.6.0

- Prognose-Cockpit auf eine sofort lesbare Stunden-/Tagesübersicht umgestellt; nichtssagende blaue Platzhalter und die unpassende Balkenerklärung entfernt.
- Kurzfrist-Ribbon zeigt konkrete Schlüsselzeitpunkte, Temperatur, Niederschlag und Böen; die erweiterte Ansicht fasst die drei wichtigsten Wetterfaktoren kompakt zusammen.
- Sieben-Tage-Darstellung verwendet benannte Wetterkategorien und direkt sichtbare Mengen/Wahrscheinlichkeiten statt schwer interpretierbarer Phasenbalken.
- App-weite objektive Klassifikation für konvektiven, stratiformen, gemischten und unbestimmten Niederschlag ergänzt.
- Explizite Modellanteile `rain`/`showers` führen; Wettercode, CAPE, Lifted Index, CIN, Feuchte, Bewölkung und Sonnenschein dienen als konsistente Zusatzbelege.
- Sprühregen und Schneegriesel bleiben nur bei passender tiefer Schichtbewölkung und Feuchte bestehen.
- Forecast-Fusion, Tagesaggregation, Kurzfrist, Meteogramm, Widget-/Push-Feed und Worker nutzen dieselbe Niederschlagskonsistenz.
- 262 automatisch erkannte Regressionstests bestanden.

# MID v0.9.5.1

- GitHub-Buildfehler `TS2345` in der Wind-/Böen-Vorschau behoben.
- Interne Einheit auf den zentralen `WindUnit`-Wert `kn` korrigiert; sichtbare Ausgabe bleibt `kt`.
- Regressionstest für den WindUnit-Vertrag ergänzt.

# MID v0.9.4.1

- GitHub-Produktionsbuild repariert: ungenutzte `quartileFill`-Deklaration entfernt.
- Nicht mehr verwendete lokale `weatherFamily`-Hilfsfunktion aus dem Prognose-Cockpit entfernt.
- Überholten `frame`-Parameter aus `mapBounds` und dessen Aufruf entfernt.
- Die übrigen meteorologischen und visuellen Funktionen von v0.9.4.0 bleiben unverändert.
- Neuer Regressionstest schützt alle drei `TS6133`-Buildfehler.

# MID v0.9.4.0

- Winddarstellung vereinheitlicht: Phasenpfeile und Stationswindfahnen zeigen ohne zusätzliche 180-Grad-Drehung die meteorologische Herkunftsrichtung „Wind aus“.
- Gemeinsames Temperatur-/Niederschlag-/Wind-Böen-Deck oberhalb der klassischen Ensembleansicht und im 14-Tage-Cockpit.
- Cockpit verwendet dieselben professionellen Ensemblediagramme wie die vollständige Analyse; Temperaturwerte sind rot/blau beschriftet und späte Tage konsistenzabhängig ausgeblendet.
- Horizontales Scrollen in der 7-Tage-Matrix löst keinen Cockpit-Horizontwechsel mehr aus.
- Zentrale Niederschlagsplausibilisierung verhindert ungestützte Sprühregenvisualisierung.
- 256 automatisch erkannte Regressionstests bestanden.

# MID v0.9.2.0

- Zwei zusätzliche optionale Prognoseoberflächen: gemeinsames Register-Cockpit und kompakter Ribbon-Stapel.
- Die klassische Darstellung von Kurzfrist, 7 Tagen und 14 Tagen bleibt unverändert der Standard.
- Adaptive 24-Stunden-MeteoRibbon mit priorisierten Wetterwechseln, Temperatur, Niederschlag und Wind.
- Sieben-Tage-Wetterband mit gemeinsamer Temperaturskala, Wetterphasen und synchronem Tagesfokus.
- Vierzehn-Tage-Unsicherheitshorizont mit Parameter-Miniaturen, Ensembleband, Konsistenz und Szenarien.
- Persistente Auswahl über die Einstellungen, Wischbedienung und vollständige alte Analysen als zweite Ebene.
- 253 bestehende und neue Regressionstests bestanden.

# MID v0.8.35.0

- Sonnenstunden des aktuellen Tages bleiben die vollständige tägliche Best-Match-Aggregation und werden abends nicht mehr auf die noch verbleibenden Stunden gekürzt.
- Reine Best-Match-Tage behalten die offizielle Tagesaggregation; nur vollständig abgedeckte Zukunftstage mit tatsächlicher kohärenter Stundenreparatur werden neu summiert.
- Best Match ist wieder die operative Hauptprognose für Kurzfrist, 7 Tage und alle gemeinsamen Wettersektionen.
- Multi-Model-Antworten werden über die tatsächlich gelieferten API-Suffixe getrennt und diagnostiziert; ein fehlendes Modell wird gezielt einzeln nachgeladen.
- Widersprüchliche Best-Match-Stunden werden ausschließlich als vollständiges Wetterbündel aus einem einzigen plausiblen Modell ersetzt.
- Modellvergleich, MOSMIX und Wetterzwilling korrigieren nur eng begrenzte geeignete Parameter; Niederschlag, Wettercode, Bewölkung und Sonne bleiben gekoppelt.
- Der lokale Wetterzwilling setzt nun auf den bereits geprüften Fusion-Stunden und -Tagen auf und kann Bündelreparaturen oder MOSMIX nicht mehr umgehen.

# MID v0.8.33.17

- Ursache von Niederschlagsmengen bei 0 % behoben: Ein nasser WMO-Code kann keine Tagesmenge mehr auf eine probabilistisch ungestützte Stunde ziehen.
- Forecast-Menge, Niederschlagsart und Wettercode werden bei 0–5 % nun unabhängig von der Mengenhöhe zentral gemeinsam entfernt.
- Finale Stundenreihe wird nach Fusion, Wetterzwilling, Nowcast und Tages-/Stundenabgleich nochmals vollständig reconciliert.
- Aktuelles Wetter, Wassersport, Gewitterauswertung, Tagesdetail, 7-Tage-Prognose, Ensemble-Referenz, Widgets und Worker verwenden dieselbe Konsistenzregel.

# MID v0.8.33.16

- iOS-Scrollpfad ohne globale Karten-Neustilisierung und ohne fortlaufende Scroll-rAF-Schleife.
- Durchgehender Root-Hintergrund und reduzierte mobile Blur-/Compositor-Ebenen gegen weiße Scrollflächen.
- Viewport-Module aktivieren im Vorladebereich ohne zusätzliche Timer-/Idle-Verzögerung.
- Aktuelle Temperatur erweitert den heutigen Tagesbereich nach oben oder unten und wird in Stunden-/Tagesansichten konsistent berücksichtigt.

# Changelog

## 0.8.33.15

- Suchfeld erhält einen bewegungstoleranten Touch-end-Fokuspfad, sodass der erste Tap auch unmittelbar nach einer Momentum-Scrollbewegung aktiviert.
- Tagespfeile der stündlichen Detailansicht reagieren direkt auf Touch-end, unterdrücken Ghost-Clicks und besitzen mobil 44 × 44 Pixel große Trefferflächen.
- Aktiver Detailtag aus dem globalen App-State in die Forecast-Komponente verlagert; ein Tageswechsel rendert nicht mehr das gesamte Dashboard neu.
- Statische Inhalte der sieben Tageszeilen von der aktiven Auswahl entkoppelt, damit Tages-Hazards und Tagescharaktere beim Pfeiltipp nicht erneut berechnet werden.
- Fast-Scroll-Erkennung von Timeout-Neuanlage je Scrollereignis auf einen einzelnen rAF-Settle-Zyklus umgestellt; Header-Blur bleibt während des Nachlaufs deaktiviert.

## 0.8.33.14

- Mobile Ersttipper abgesichert: Radar- und Ensembleflächen bleiben auch unmittelbar nach Scrollbewegungen interaktiv; der Fast-Scroll-Modus reduziert nur noch visuelle Effekte.
- Stündliches Detaildiagramm reagiert direkt über einen bewegungstoleranten Pointer-Tap-Pfad und erzwingt auf Touchgeräten keinen unnötigen Fokus mehr.
- Ensemble-Tooltips werden bereits beim Pointer-down freigeschaltet, damit ein zuvor geschlossenes Tooltip beim nächsten Tap sofort erscheint.
- Einstellungsdialog, Schalter und Diagramme erhalten konsistente Touch-Actions; layoutverändernde Hover-Effekte sind auf groben Zeigern deaktiviert.
- Flugmeteogramm-Tooltips werden pro Animationsframe gebündelt statt bei jeder Pointerbewegung neu gerendert.
- React-Hook-Reihenfolge der 7-Tage-/Detailkomponente repariert und unzulässigen State-Update aus einem Meteogramm-`useMemo` entfernt.
- Tageszeilen der 7-Tage-Vorhersage memoisiert, damit die Auswahl einer Detailstunde nicht erneut alle Tages-Hazards und Tagescharaktere berechnet.

## 0.8.33.11

- Hauptkarte und Bewölkungskarte verwenden denselben frischen hyperlokalen Himmelszustand.
- 7/8 Bewölkung wird als „Stark bewölkt“, 8/8 als „Bedeckt“ bezeichnet; lokaler Nebel behält Vorrang.

## 0.8.33.10

- Luftdruckkarte zeigt Werte mit einer Nachkommastelle.
- Technische Feldbezeichnung `pressure_msl` aus der sichtbaren Quellenzeile entfernt.

## 0.8.33.9

- Warnfreier Status auf „Keine Warnung“ verkürzt.
- Tagespiktogramm und Tagesbeschreibung gewichten den dominierenden Tagesverlauf stärker; ein einzelner schwacher Regenimpuls am späten Abend erscheint nur noch als Zusatz „abends Regen möglich“.
- 7-Tage-Karte, Detailansicht und 14-Tage-Übersicht verwenden denselben vollständigen Tagescharakter.

## 0.8.33.8
- Stunden-Detailansicht: Niederschlagsart wird in der Niederschlagskachel nicht mehr doppelt wiederholt.
- Der frei gewordene Platz zeigt bei vorhandener Konvektion das Gewitterrisiko vollständig an.

## 0.8.33.6
- Niederschlagswerte zwischen 7-Tage-Karte, Tagesdetail und finaler Stundenreihe konsistent zusammengeführt

## 0.8.33.5
- UVI app-weit auf ganze Indexwerte vereinheitlicht
- Aktuelle Niederschlagswahrscheinlichkeit an die trockene operative Nowcast-Gewichtung angeglichen

## 0.8.33.4
- GitHub-CI-Fix für den Nowcast-/Tageskonsistenztest: projektlokale TypeScript-Auflösung statt exklusivem festem NVM-Pfad
- Keine Änderung der Prognose- oder Nowcast-Logik

## 0.8.33.3
- Radar-Nowcast und trockener MOSMIX-/Mehrquellenkonsens im Kurzfristbereich stärker priorisiert
- Regen-Wettercodes bei belastbar trockenem Nowcast bereinigt
- 7-Tage-Karte, Tagesdetail und Kurzfristvorhersage auf dieselben finalen Niederschlagswerte vereinheitlicht
- Heutiger 7-Tage-Trend ignoriert abgelaufene Modellstunden

## 0.8.33.2
- Temperatur-Ensembletooltip: Sonne-Wertblock leicht nach rechts versetzt, damit Beschriftung und Werte klar getrennt und vollständig lesbar bleiben

## 0.8.33.1
- Temperatur-Ensembletooltip: Sonne samt P10–P90 und Niederschlag samt Wahrscheinlichkeit jeweils bündig in einer einzigen Zeile dargestellt.
- Ortssuche: Suchfeld reagiert über die gesamte Eingabefläche bereits auf die erste Berührung und fokussiert ohne Scrollsprung.
- Favoriten: Standortstern, Standort-Schnellzugriff und Favoritenblasen reagieren auf Touch unmittelbar beim ersten gültigen Tap; störende Pointer-Capture-Logik entfernt.

## 0.8.33.0
- DWD MOSMIX als stationsbezogene statistische Nachkorrektur der adaptiven Mehrquellen-Prognose integriert.
- MOSMIX wird wegen seiner ICON-/IFS-Basis nicht als zusätzliche unabhängige Modellfamilie gezählt, sondern nur nach robustem Mehrmodellkonsens angewendet.
- Kurzfristvorhersage erhält direkte stündliche MOSMIX-Korrekturen; Radar- und Gewitternowcast bleiben im unmittelbaren Niederschlagszeitraum vorrangig.
- 7-Tage- und 14-Tage-Best-Match-Referenz verwenden die adaptive Fusion; MOSMIX wirkt nur innerhalb seiner maximalen Zehn-Tage-Abdeckung.
- Wetterzwilling archiviert Modellfusion mit und ohne MOSMIX getrennt, damit der lokale Zusatznutzen messbar wird.
- Nicht blockierende Hintergrundabfrage mit Worker-/Local-Cache und Qualitätsfiltern für Entfernung und Höhenunterschied.

## 0.8.32.1
- Modelllauf-Metadaten für ECMWF AIFS auf die aktuelle Open-Meteo-Quelle `ecmwf_aifs025_single` umgestellt.
- Monatealte oder zeitlich unplausible Modelllauf-Metadaten werden nicht mehr angezeigt oder für die Mehrquellenfusion verwendet.
- Best-Match-Information fachlich präzisiert: statt einer nicht belegbaren Modellkette zeigt MID nur noch potenziell relevante Regionalmodelle und kennzeichnet die Metadatenquelle.
- Worker-Aliase und Forecast-Fusion für ECMWF AIFS Single aktualisiert.

## 0.8.31.0
- Einstellungs- und Favoritenmenüs öffnen mit sofortiger Dialoghülle und verzögertem Inhaltsaufbau.
- Viewport-Gates aktivieren schwere Module nur noch nach stabiler Sichtbarkeit und in einer Idle-Phase.
- iOS-Scrollstabilität verbessert: problematisches content-visibility für schwere Dashboard-/Ensemblebereiche deaktiviert.
- Schnelle Scrollphasen reduzieren temporär teure visuelle Effekte und Karten-/Chart-Interaktionen.

## 0.8.30.9
- Ensemble-Tooltips schließen zuverlässig durch Antippen/Klicken der geöffneten Tooltipkarte sowie weiterhin durch Außenklick und Escape.
- Niederschlags- und Wind/Böen-Diagramm verwenden wieder dieselbe Recharts-Datumsachse wie das Temperaturdiagramm; die problematische externe HTML-Achse wurde entfernt.
- Senkrechte Tageshilfslinien für Niederschlag und Wind/Böen werden als achsgebundene Referenzlinien sichtbar über den Datenflächen gerendert.
- Hochformat-, Querformat- und Desktop-Geometrie der Ensemble-Achsen durch neue Layoutregression abgesichert.

## 0.8.30.8
- Niederschlag und Wind/Böen: robuste externe Datumsachse im Hochformat; alle 14 Tage bleiben sichtbar.
- Ensemble-Tooltips: Tippen auf die geöffnete Tooltipkarte schließt sie wieder; Außenklick und Escape bleiben erhalten.
- Niederschlag und Wind/Böen: senkrechte Tageshilfslinien werden direkt vom gemeinsamen Recharts-Tagesraster erzeugt.

## 0.8.30.7
- Niederschlagsdiagramm: Zeitachsenbeschriftung im Hochformat wieder dauerhaft sichtbar.
- Ensemble-Tooltips: Interaktion innerhalb der Tooltipkarte schließt die Auswahl nicht mehr.
- Niederschlag und Wind/Böen: senkrechte Tageshilfslinien als sichtbare Vordergrundebene ergänzt.

## 0.8.30.6
- Temperatur-Ensemble: senkrechte Tageshilfslinien wieder sichtbar und direkt aus den tatsächlich gerenderten X-Achsenmarken abgeleitet.
- Temperatur-Ensemble: Sonne-/Wolkenkästchen verwenden dieselben vermessenen Tageszentren; Zellgrenzen liegen exakt in der Mitte benachbarter Achsmarken – einschließlich des letzten Tages rechts.
- Zusätzliche Regression verhindert die Rückkehr zur theoretischen, nach rechts driftenden Wetterband-Geometrie.

## 0.8.30.4
- TypeScript-Buildfix: ungenutzte `cellSlotWidth`-Deklaration entfernt
- Prognose-Kompass professioneller und meteorologisch konkreter formuliert
- Szenario-Cluster mit sofort sichtbarer Prozentübersicht und Anteilsskalen ergänzt

## 0.8.30.2
- Synchronisations-Worker: `midwx.app` und `www.midwx.app` dauerhaft als freigegebene Ursprünge ergänzt.
- Konfigurierte Cloudflare-Originlisten ergänzen nun die MID-Standarddomains, statt sie zu ersetzen.
- Originwerte werden auf den tatsächlichen URL-Ursprung normalisiert; abschließende Schrägstriche verursachen keine Fehlablehnung mehr.
- Einstellungsmenü zeigt bei einem noch veralteten Worker eine konkrete Upload-Anweisung.

## 0.8.30.1
- Temperatur-Ensemble: Sonne-/Wolkenleiste nutzt exakte Tagesintervallgrenzen; die letzte Zelle endet exakt am Plotrand und alle Zellmittel liegen auf den Tagesmarken.
- Temperatur-Ensemble: Zellfüllungen ohne überstehende Einzelrahmen, mit gemeinsamer Außenkontur und exakt positionierten Tagestrennern.
- Kurzfristvorhersage: ausschließlich eine Detailkachel gleichzeitig geöffnet; Wechsel auf eine andere Zeit ersetzt die bisherige Auswahl unmittelbar.
- Kurzfristvorhersage: doppelte Touch-/Click-Auslösung entfernt und Auswahl bei Datenaktualisierung abgesichert.

## 0.8.30.0
- Menü „Daten & Synchronisation“ widerspruchsfrei neu geordnet: automatische Web-App-Synchronisation zuerst, manuelle iCloud-Sicherheitskopie als zusätzlicher Notfallschutz.
- Gemeinsame portable Datenrichtlinie für Sicherung und Synchronisation eingeführt; Ensemble-, Diagramm-, Modul- und weitere App-Einstellungen werden nicht mehr durch zu breite Ausschlüsse übergangen.
- Vollständiger Snapshot-Abgleich v2 synchronisiert nun auch Löschungen und setzt portable Einstellungen auf verbundenen Web-Apps konsistent gleich.
- Sicherungsformat v3 übernimmt auf Wunsch den bestehenden Geräteverbund und stellt Wiederherstellungsstände für weitere Web-Apps bereit.
- Klare iOS-Hinweise ergänzt: Safari und installierte Home-Bildschirm-Web-Apps müssen einmal mit demselben Synchronisationscode verbunden werden.

## 0.8.28.1
- Ensemble-Diagramme im Hochformat verbreitert und in der Höhe reduziert; Achsen, Legenden und leicht diagonale Tagesbeschriftungen vereinheitlicht.
- Ensemble-Tooltips auf Klick/Tipp umgestellt, Animation und Blur entfernt und Outside-Dismiss ergänzt, um iOS-Lags zu vermeiden.
- Temperatur-Tooltip verdichtet; „Best Match“ in der Niederschlagszeile entfernt und Tmin/Tmax-Spalten enger angeordnet.

## 0.8.28.0
- Neue iCloud-Drive-Dateisicherung für Favoriten, App-Einstellungen, Profile und vollständige Wetterzwilling-Langzeitdaten einschließlich Wiederherstellung und Integritätsprüfung
- Vollständiger Neuaufbau der Ensemble-Diagramme auf einer gemeinsamen professionellen Chart-Engine mit identischen Tagespositionen, Achsen, Plotmaßen und responsiven Tooltips
- Temperatur-Wetterleiste als lückenlose Tageszellen; Tageshilfslinien liegen exakt in den Zellmitten
- Mehrstufiger PWA-Startschutz gegen weiße Startseiten mit Cache-Reparatur ohne Löschung lokaler Daten
- Wiederherstellungsoberfläche ermöglicht vor Reparatur eine Datensicherung

## 0.8.27.14
- Sämtliche veralteten Ensemble-, Achsen-, Tooltip-, Wetterband-, Export- und Touch-Regressionstests auf den aktuellen Funktionsvertrag synchronisiert
- GitHub-Installer wird nicht mehr durch Prüfungen der früheren Einzelgeometrien blockiert
- Prognose-Kompass bleibt dynamisch: weitgehend gesicherte Prognosedauer statt pauschal drei Tage

## 0.8.27.13
- GitHub-/CI-Buildfix für gemeinsame Ensemble-Achs- und Diagrammhöhen
- Prognose-Kompass zeigt jetzt die tatsächlich weitgehend gesicherte Prognosedauer statt pauschal 3 Tage

## 0.8.27.12
- Ensemble-Tagesleisten und Tagesachsen vereinheitlicht
- Detailansicht-Pillen verdichtet und UVI kompakter benannt
- Ortssuche und Kurzfrist-Kacheln reaktionsschneller

## 0.8.27.11

- Veröffentlichungsfehler nach erfolgreichem Produktionsbuild behoben: veraltete Regressionstests an die aktuelle Temperatur-Ensemble-, Tooltip- und Achsengeometrie angepasst
- Schutztests für Hoch-/Querformat, Exportgeometrie, Datumsachse, Wetter-/Hazardband und Tooltip-Randsicherung auf den aktuellen Vertrag aktualisiert
- Interaktions-, Referenzdesign-, UI- und Gezeiten-/Tooltip-Layering-Prüfungen mit der neuen responsiven Darstellung synchronisiert
- Vollständiger Lauf aller automatisch erkannten MID-Regressionen erfolgreich

## 0.8.27.10

- Ensemble-Temperaturtrend weiter verdichtet: Tooltip nochmals deutlich kompakter, mobile X-Achse freier und Wetter-/Hazardband sauberer über der Datumsachse positioniert
- Temperatur-Ensemble responsiver abgestimmt: mehr vertikale Reserve für Achsentitel, bessere mobile Geometrie und sicherere Tooltip-Auslenkung am rechten Rand
- Ortssuche spürbar direkter: schnellere Suchauslösung, suchoptimierte Eingabeeigenschaften und direktere Touch-Bedienung
- Kurzfrist-Kacheln für Touch-Bedienung entschärft: direktere Tap-Reaktion und mobile Interaktion mit weniger Verzögerung

## 0.8.27.9
- Ensemble-Temperaturtooltip wieder deutlich kompakter und dichter gesetzt.
- Ensemble-Temperaturdiagramm: zusätzliche Freiräume für Wetterkästchen, Datumsachse und Achsentitel.
- Wetterkästchen schmaler und höher positioniert, damit die X-Achsenbeschriftung nicht mehr verdeckt wird.
- Tooltip-Rechtsausrichtung weiter verschärft, damit rechte Inhalte nicht abgeschnitten werden.

## 0.8.27.8
- Ensemble-Temperaturdiagramm: Tageskästchen optisch enger und klarer auf die Tagesachsen zentriert.
- Ensemble-Temperaturdiagramm: mehr vertikale Reserve für Datumsachse und Achsentitel, damit Hoch- und Querformat stabiler aussehen.
- Temperatur-Tooltip: bei rechten Datenpunkten automatische Linksverschiebung, damit die rechte Spalte nicht mehr abgeschnitten wird.
- Regressionstests für Temperaturband und Tooltip-Geometrie erweitert.

## 0.8.27.7
- GitHub-Veröffentlichung repariert: acht veraltete Regressionstests auf die seit v0.8.27.6 beabsichtigte Temperaturachsen- und Wetterkachelgeometrie aktualisiert.
- Historische Versionsprüfungen prüfen nun Mindeststand und Synchronität mit `MID_BASELINE.json`, statt spätere Wartungsreleases fälschlich abzulehnen.
- Die sichtbaren Achsen- und Kachelkorrekturen aus v0.8.27.6 bleiben unverändert erhalten.

## 0.8.27.6
- Ensemble-Temperaturdiagramm: Tagesachsenbeschriftung wieder klar sichtbar gemacht.
- Wetter-/Bewölkungskästchen im Temperatur-Ensemble höher positioniert, damit Datumslabels nicht verdeckt werden.
- Wetterkacheln im Temperatur-Ensemble kompakter und präziser auf die Tagesachse ausgerichtet.

## 0.8.27.5
- Tagesdetailansicht: kompaktere Info-Pillen oberhalb des Diagramms.
- Neue UVI-Pille in der Detailansicht mit dem maximalen UV-Index des gewählten Tages.
- Wetter-Pille der Detailansicht platzsparender gestaltet, damit die Zusatzinformation erhalten bleibt ohne unnötig Höhe zu verbrauchen.

## 0.8.27.4
- Vite-Build mit explizitem 4-GB-Heap und deterministischen Vendor-Chunks gegen lange Hänger bei „rendering chunks …“ abgesichert.
- Dynamischen `:has()`-Selektor der Tooltip-Ebene durch eine statische, browser- und buildstabile Ebenenreihenfolge ersetzt.
- Explizite esbuild-Minifizierung für JavaScript und CSS festgelegt; komprimierte Größenberechnung bleibt deaktiviert.
- Sämtliche fachlichen und optischen Änderungen aus v0.8.27.3 bleiben erhalten.

## 0.8.27.3
- Ensemble-Tooltip über Temperaturdiagrammen priorisiert, damit es auf Mobilgeräten nicht mehr vom nachfolgenden Diagramm überdeckt wird.
- Wetter-/Bewölkungskästchen im Ensemble-Temperaturdiagramm neu zentriert und mit präziserer Plot-Geometrie an die Tagesachsen angebunden.
- Niederschlags-/Gewittersymbole in den Kästchen vergrößert; Blitzsymbol kontrastreicher und besser erkennbar innerhalb des Kästchenrahmens.

## 0.8.27.2
- Ensemble-Temperaturtooltips halten Metadatenzeilen nun ohne unerwünschte Umbrüche zusammen.
- Wind-/Böendiagramme reservieren einen eigenen Bereich für diagonale Datumsbeschriftungen und den Achsentitel.
- Favoriten reagieren auf Touch-/Pen-Eingaben bereits beim ersten eindeutigen Antippen; das Verschieben bleibt über den Griff erhalten.
- Hintergrundlernen der Wetterzwillinge wird bei Nutzerinteraktion sofort abgebrochen und erst nach einer Ruhephase fortgesetzt.

## 0.8.27.1
- TypeScript-Buildfehler TS2353 in der hyperlokal angepassten Kurzfristvorhersage behoben.
- Die Gewitterrisikoprüfung erhält nun ausschließlich die im `DetailThunderRiskSample` definierten meteorologischen Felder; die benötigten Instabilitätsparameter bleiben vollständig erhalten.
- Eigene Regression gegen erneut eingeschleuste, nicht unterstützte Felder ergänzt.

## 0.8.27.0
- Modelllauf-Änderungsradar und Szenario-Cluster nur noch im erweiterten Modus, jeweils einklappbar und im geschlossenen Zustand nicht gerendert.
- Tagesdetail-Sonne-/Bewölkungsbalken direkt an den aktuellen React-Datenstand gebunden; veraltete DOM-Nachbearbeitung entfernt.
- Weitere Rendering-, Observer-, Scroll-, Resize- und Ensemble-Aufbereitungsbremsen beseitigt; MID-Prognose-Kompass ergänzt.

## 0.8.26.19
- Kurzfristvorhersage wird bei frischer hyperlokaler oder stationsgestützter Analyse für die ersten Zeitstufen kontrolliert an Temperatur, Feuchte, Taupunkt, QFF-Luftdruck, Wind/Böen, Windrichtung, Bewölkung, Sicht und Niederschlag angeglichen.
- Wetterpiktogramme und Detailwerte folgen der lokalen Ausgangslage und laufen je nach Veränderlichkeit des Parameters gestuft zum Best Match zurück.
- Veraltete Stationswerte bleiben ausgeschlossen; km/h-Stationswind wird vor der Angleichung korrekt in kt umgerechnet und die aktive Datenbasis wird in der Kurzfristkarte gekennzeichnet.

## 0.8.26.18
- Gezeitenzeiten werden mittels robuster lokaler Kurvenanpassung zwischen den Modellstützstellen minutengenau geschätzt.
- Ensemble-Hazardmarker erhalten mehr Abstand zum Bewölkungsband; Niederschlagssymbole werden zusätzlich im jeweiligen Tagesfeld beschnitten.
- Temperatur-, Niederschlags- und Windkarten erhalten eindeutige Ebenen, damit Tooltips weder von Hazardmarkern noch von nachfolgenden Diagrammüberschriften verdeckt werden.

## 0.8.26.17
- Wasserwetter-Zeile auf „Gezeiten“ verkürzt und Wendepunktzeiten per Zwischenwertberechnung minutengenau ausgegeben.
- Ensemble-Hazards oberhalb der Bewölkungsfelder angeordnet; mehrere Marker stehen kollisionsfrei nebeneinander.
- Niederschlagssymbole werden dynamisch auf die Abmessungen des jeweiligen Bewölkungsfeldes begrenzt.

## 0.8.26.15
- TypeScript-Buildfehler TS18048 in der hyperlokalen Kurzfrist-Temperaturbrücke behoben; optionale Anker- und Horizontwerte werden vor dem Vergleich typsicher normalisiert.
- Eigene Regression gegen die erneute direkte Gegenüberstellung optionaler Werte ergänzt.

## 0.8.26.14
- Gewitterinformation auf der Startseite kompakter und vollständiger dargestellt; Ortsbezug bevorzugt nun Stadtniveau statt Stadtteilniveau.
- Kurzfristvorhersage für die ersten 15-Minuten-Schritte thermisch an die aktuelle hyperlokale Analyse angenähert.
- Szenariocluster sprachlich und strukturell verständlicher aufbereitet.

## 0.8.26.13

- Ensemble-Hochformat: Temperatur-Tooltip in Größe, Aufbau und Inhalt auf den bewährten Stand v0.8.25.4 zurückgeführt.
- Ensemble-Temperaturdiagramm: Sonne-/Wolkenfelder, Niederschlagssymbolik und Hazardmarker werden wieder tagesgenau am unteren Plotrand statt mitten im Diagramm dargestellt.
- Recharts 3: Die Wetterebene erhält eine explizit aus Chartgröße, Achsenreserven und Tagesdomäne berechnete SVG-Geometrie; die Linien bleiben darüber sichtbar, Hazardmarker darüber.
- Ensemble-Geometrie: identische Tagesdomänen und Achsenreserven der Temperatur-, Niederschlags- und Winddiagramme bleiben erhalten.

## 0.8.26.12

- Ensemble-Diagramme: Optik und Bedienung des Temperaturdiagramms wieder auf den bewährten Stand von v0.8.25.4 zurückgeführt, weiterhin mit stabilem Recharts-3-Größenrahmen.
- Ensemble-Diagramme: schmale tagesgenaue Sonne-/Wolkenfelder, Niederschlagssymbolik und Hazardmarker als leichte, exakt an der gemeinsamen Tagesachse ausgerichtete Ebene wiederhergestellt.
- Ensemble-Diagramme: Temperatur-Tooltip kompakt und vollständig ohne partielle Zeilenumbrüche; lange technische Bezeichnungen wurden fachlich verkürzt statt abgeschnitten.
- Performance: zusätzliche Recharts-Accessibility-Schicht, experimentelle Skalenebenen, große Wetterkarten-Overlays und content-visibility-Rasterisierung entfernt; vertikales Touch-Scrollen priorisiert.

## 0.8.26.11

- Buildfix: Der im Temperatur-Ensemble-Tooltip verwendete Helfer `compactPrecipitationTooltipLabel` ist wieder eindeutig deklariert.
- Ensemble-Funktionalität bleibt unverändert: Wetterkästchen, Niederschlagssymbolik, Hazardmarker, Tooltips und die gemeinsame Tagesausrichtung werden nicht verändert.
- Neue Regression verhindert eine erneute Verwendung des Tooltip-Helfers ohne passende Deklaration.

## 0.8.26.10

- Ensemble-Temperaturdiagramm: Sonne-/Wolken-Kästchen, Niederschlagssymbolik und Hazardmarker werden wieder als eigenständige, stets sichtbare Tageszeile oberhalb der Datumsachse dargestellt. Die Tagespositionen nutzen dieselben linken und rechten Achsenreserven wie alle drei Ensemble-Diagramme.
- Ensemble-Temperaturtooltip: sämtliche Tabellen-, Zusatz- und Hazardzeilen bleiben einzeilig; lange Inhalte werden kontrolliert gekürzt statt umgebrochen.
- Ensemble-Performance: experimentelle Recharts-Skalenhooks und die zusätzliche Accessibility-DOM-Schicht wurden entfernt. ResizeObserver nutzt direkt die gelieferten Maße, Offscreen-Diagramme verwenden content-visibility und Touch-Flächen erlauben ungehindertes vertikales Scrollen.
- Regressionen: Sichtbarkeit der Wetterzeile, Niederschlags- und Hazardmarker, gemeinsame Tagesgeometrie, Tooltip-Zeilen und mobile Scrollentlastung sind zusätzlich abgesichert.

## 0.8.26.9

- Ensemble-Diagramme: TypeScript-Buildfehler der wiederhergestellten Niederschlagssymbolik behoben. Der Zustand `none` wird vor der Übergabe an das Regen-/Schnee-/Mischform-Piktogramm explizit ausgeschlossen.
- Neue Regression schützt die sichtbaren Sonne-/Wolken-Kästchen, Niederschlagssymbole und Hazardmarker vor einer erneuten ungültigen Typübergabe unter Recharts 3.

## 0.8.26.8

- Ensemble-Temperaturdiagramm: Sonne-/Wolken-Kästchen, Niederschlagssymbole und Hazardmarker werden unter Recharts 3 über eine eigene hoch priorisierte Koordinatenebene zuverlässig oberhalb der Diagrammflächen gerendert.
- Ensemble-Temperaturtooltip: Werte, Überschriften und Metadaten bleiben einzeilig; lange Niederschlags- und Hazardtexte werden kompakt dargestellt und behalten den vollständigen Inhalt als Titelinformation.
- Ensemble-Geometrie: gemeinsame Tagesdomäne, Tickfolge und horizontale Ausrichtung von Temperatur-, Niederschlags- und Winddiagramm bleiben unverändert erhalten.

## 0.8.26.7

- Ensemble-Diagramme: Interaktive Darstellung wie vor dem Wartungsaudit wiederhergestellt; Temperatur-, Niederschlags- und Winddiagramm verwenden wieder zuverlässig Tooltips und explizit gemessene Recharts-3-Pixelabmessungen.
- Temperatur-Ensemble: Sonne-/Wolken-Kästchen, Niederschlagssymbolik und Hazardmarker werden wieder innerhalb der Diagrammfläche dargestellt.
- Ensemble-Ausrichtung: Alle drei Diagramme verwenden dieselbe linke und rechte Achsenreserve, dieselbe Tagesdomäne und dieselbe Exportbreite, sodass identische Vorhersagetage vertikal exakt übereinanderliegen.
- Ensemble-Achsen: Die Beschriftung „Vorhersagetag“ wurde enger an die Datumsachse angebunden und optisch vom nachfolgenden Inhalt abgegrenzt.

## 0.8.26.6

- Buildfix: In der Gezeiten-Glättung des Wasserwetter-Moduls wurde ein ungenutzter Callback-Parameter entfernt, der bei aktiviertem `noUnusedParameters` den TypeScript-Produktionsbuild mit TS6133 abbrach.
- Regression ergänzt, damit derselbe Buildfehler nicht erneut eingeführt wird.
- Die Ensemble-/Flugwetterquellen-Regression akzeptiert nun spätere Wartungsstände der v0.8.26-Linie und blockiert dadurch keine legitimen Buildfix-Releases mehr.

## 0.8.26.5

- Ensemble-Diagramme: Recharts-3-Liveansicht auf den nativen responsiven Diagrammmodus umgestellt und mit einer belastbaren Mindesthöhe versehen; Temperatur-, Niederschlags- und Winddiagramme kollabieren dadurch nicht mehr auf 0 Pixel.
- Ensemble-Export: feste, deterministische PNG-Geometrie bleibt unverändert erhalten und ist vom responsiven Livepfad getrennt.
- Flugmeteogramme: Datenherkunft für Vereisungs- und Turbulenzfelder transparent gekennzeichnet. Die dargestellten Felder bleiben MID-Diagnosen aus Druckniveaudaten und werden nicht fälschlich als direkte DWD-ADWICE- oder WAWFOR-EDP-Produkte bezeichnet.
- DWD-Flugwetterprüfung dokumentiert: ADWICE ist ein Produkt für den europäischen Luftraum; globale Turbulenz-/EDP-Daten werden über den vertragspflichtigen WAWFOR-Datensatz in GRIB2 bereitgestellt und sind kein frei abrufbares Open-Data-Produkt.

## 0.8.26.4

- Wasserwetter-Verlauf: Gezeitenwendepunkte werden mit einer amplitudenadaptiven, zeitfensterbasierten Extremenerkennung ermittelt. Dadurch werden Hoch- und Tiefpunkte auch bei flachen 15-Minuten-Wasserstandskurven zuverlässig erkannt.
- Gezeiten: unvollständige oder für die Wendepunkterkennung ungeeignete 15-Minuten-Daten fallen automatisch auf die vollständige stündliche Wasserstandsreihe zurück.
- Marine-Datenabruf: der 15-Minuten-Wasserstand wird ausdrücklich für den vollständigen achtägigen Vorhersagezeitraum angefordert; nicht benötigte 15-Minuten-Strömungsfelder entfallen zugunsten geringerer Datenlast.

## 0.8.26.3

- GitHub-Regressionen von der im Repository bereits aktiven Workflowgeneration entkoppelt: geprüft wird nun das kanonische, im Release gebündelte Workflowpaket. Dadurch bleibt der reguläre MID-Installer auch mit dem älteren aktiven Installationsworkflow lauffähig.
- Automatische Selbständerung von `.github/workflows` aus dem laufenden Installationsjob entfernt. Der jobgebundene `GITHUB_TOKEN` besitzt hierfür keinen eigenständigen Workflow-Schreibvertrag; Workflowupdates werden daher bewusst als separates, manuell einzuspielendes Paket bereitgestellt.
- Kanonische CI-Dateien zusätzlich unter `ci/github/` aufgenommen und mit einem expliziten, idempotenten Synchronisationsskript versehen. Nicht von MID verwaltete Workflows bleiben dabei unangetastet.
- Neue Regression simuliert ausdrücklich einen alten aktiven Installer und stellt sicher, dass Build- und Wartungsprüfungen trotzdem reproduzierbar bestehen.

## 0.8.26.2

- CI-Regressionsprüfungen stabilisiert: Workflowprüfung ist nicht mehr von unverbindlichen Versionskommentaren abhängig und kontrolliert ausschließlich die verbindlichen MID-Workflows.
- Wartungs-/Recharts-3-Test vollständig deterministisch gemacht: die umgebungsabhängige Offline-npm-Unterprozessprüfung wurde durch direkte Lockfile-Struktur-, Quellen- und Integritätskontrollen ersetzt.
- Neue Regression schützt die GitHub-Actions-Prüfungen vor Abhängigkeiten vom Runner-Cache, von npm-Metadaten und von Workflow-Kommentaren.

## 0.8.26.1

- Recharts-3-Buildfix: die nicht mehr unterstützte `isFront`-Eigenschaft der beiden `ReferenceDot`-Marker wurde durch das offizielle `zIndex`-Prop ersetzt. Niederschlags- und Hazardmarker bleiben damit oberhalb der Diagrammflächen sichtbar.
- Die nach der Recharts-3-Migration ungenutzte Konstante `ENSEMBLE_EXPORT_PLOT_WIDTH` wurde entfernt und der TypeScript-Produktionsbuild dadurch von TS6133 bereinigt.
- Neue Regression prüft sämtliche `ReferenceDot`-Marker auf Recharts-3-kompatible Props und verhindert die Wiedereinführung der ungenutzten Exportkonstante.
- Die Wartungsregression prüft Versionsgleichheit nun ohne einen fest codierten Einzelrelease und bleibt dadurch auch für nachfolgende Wartungsstände wirksam.

## 0.8.26.0

- Ensemble-Diagramme auf **Recharts 3.8.1** migriert; `react-is` ist passend zu React 18.3.1 festgeschrieben. Temperatur-, Niederschlags- und Winddiagramm behalten sämtliche Datenreihen, Tooltips, Fehlerbalken, Warnmarker und PNG-Exporte.
- Die drei Ensemble-Diagramme verwenden die Recharts-3-Zugänglichkeitsschicht; responsive Größenänderungen werden gedrosselt und der feste Exportpfad wurde in ein eigenes, wiederverwendbares Chart-Frame-Modul ausgelagert.
- Buildwerkzeuge auf die bereits geprüften stabilen Stände TypeScript 5.9.3, Vite 6.4.3 und `@vitejs/plugin-react` 4.7.0 festgeschrieben. Node-/npm-Vertrag über `engines` und `packageManager` ergänzt.
- Versionssynchronisierung aktualisiert nun auch `package-lock.json`; Paket, Lockfile, Frontend, Baseline, Service Worker und Cloudflare Worker werden gemeinsam auf denselben Releasewert gesetzt.
- TypeScript-Prüfung auf artefaktfreies `--noEmit` umgestellt. Generierte `*.tsbuildinfo`- und `vite.config.*`-Ausgaben werden nicht mehr Bestandteil der Quell- oder Releasebasis.
- Radarhistorie, KOSTRA-Punktdaten und Reise-/Klimatologiecache erhalten LRU-Grenzen, Ablaufbereinigung und bei Local-Storage-Engpässen einen kontrollierten Bereinigungs-/Wiederholungsversuch. Bestehende Cache- und Stale-Fallback-Funktionen bleiben erhalten.
- Die nachträgliche UI-Aufwertung beobachtet nicht mehr das gesamte Dokument einschließlich Attributänderungen. Sie ist auf den App-Baum, relevante Interaktionen und Größenänderungen der betroffenen Diagrammcontainer begrenzt.
- GitHub Actions auf vollständige Commit-SHAs festgeschrieben, Berechtigungen je Job reduziert und regelmäßige npm-Sicherheitsprüfung sowie Dependabot für npm und GitHub Actions ergänzt.
- Das Release enthält eine kanonische, separat einspielbare `.github`-Konfiguration mit SHA-fixierten Actions, Audits und Dependabot; Workflowänderungen werden aus Sicherheitsgründen nicht vom laufenden Installationsjob selbst geschrieben.
- Neue Wartungsregression schützt Recharts-3-Vertrag, Lockfile-Konsistenz, Cachegrenzen, DOM-Beobachtung, SHA-Pinning, Audits, Laufzeitvertrag und Release-Sauberkeit.

## 0.8.25.4

- Wasserwetter-Verlauf: Gezeiten- und Wasserstandswendepunkte werden je angezeigtem Prognosetag für den vollständigen Kalendertag ermittelt und nicht mehr auf das jeweilige Tageslicht-, Aktivitäts- oder Stundenfenster begrenzt.
- Für angebrochene 15-Minuten-Datenreihen verwendet MID automatisch die vollständigere stündliche Wasserstandsreihe, damit am aktuellen Tag auch bereits vor dem sichtbaren Verlauf liegende Hoch- und Tiefpunkte aufgeführt werden.
- Die kompakte allgemeine Gezeitenübersicht bleibt auf kommende Wendepunkte beschränkt; nur die Tageszeile im Wasserwetter-Verlauf zeigt sämtliche Fälle des jeweiligen Kalendertags.

## 0.8.25.3

- 7-Tage-Trend: Eine Tropennacht wird nun auf die dem jeweiligen Prognosetag folgende Nacht bezogen. Bevorzugt werden die Stunden von 20:00 Uhr bis 08:00 Uhr ausgewertet; der Tiefstwert des Folgetags dient nur als Fallback.
- Tageswarnungen: Stark- und Dauerregenhinweise werden nicht mehr einem trockenen Kalendertag zugeordnet, nur weil ein langes 12-/24-/48-/72-Stunden-Fenster erst später einsetzenden Niederschlag umfasst.
- 7-Tage-Trend und Tageskarten bleiben dadurch konsistent: Bei 0,0 mm und trockener Stundenprognose erscheint keine vorgezogene Dauerregen-Aussage mehr.

## 0.8.25.2

- Produktionsbuild repariert: Die in `RadarPanel.tsx` nicht verwendete Variable `pxFactor` wurde entfernt.
- Die Sichtbarkeitslogik des DWD-250-m-Radars bleibt über die explizit verwendete Bedingung `pxDisplayAvailable` vollständig erhalten.
- Eine neue Regression verhindert, dass der ungenutzte PX250-Faktor oder eine gleichartige TypeScript-TS6133-Regression erneut in den Produktionsstand gelangt.

## 0.8.25.1

- Kompositbild: Die Blickrichtungsspitze erscheint nur noch beim tatsächlich per Geräteortung geöffneten Standort; bei gesuchten Orten und Favoriten wird ausschließlich der neutrale Ortsmarker angezeigt.
- Kompositbild: Isobaren und 500-hPa-Isohypsen werden nach dem Laden der MID-Modellkonturen mehrfach geglättet und mit abgerundeten Linien gezeichnet; der DWD-ICON-WMS bleibt als schneller Lade- und Ausfallfallback erhalten.
- Kompositbild: DWD PX250/HX wurde durch redundante DWD-Open-Data-Endpunkte, tolerantere Aktualitätsfenster, robustere HDF5-Datensatzerkennung, korrigierte Projektionsparameter und eine statische Darstellung des neuesten Einzelstands stabilisiert.
- Kompositbild: Blitzpunkte besitzen nun eine eigene, über Radar-, Satelliten- und Warnrastern liegende Kartenebene sowie deutlich sichtbare gefüllte Marker mit Halo.
- Kompositbild: Zugpfeile werden kleiner und transparenter dargestellt, nur noch an tatsächlich nassen Ankerpunkten gesetzt und innerhalb eines Sicherheitsabstands zum Kartenrand ausgeblendet; künstliche Ersatzanker entfallen.
- Radar-Bewegungsanalyse: Ankerpunkte aus den äußeren Rasterzellen werden verworfen, damit NoData- und Kompositränder keine scheinbaren Verlagerungspfeile erzeugen.

## 0.8.25.0

- Kompositbild: OPERA CIRRUS wird nach erfolgreicher HDF5-Rastervalidierung auch dann geladen, wenn der gewählte Standort in einem trockenen oder lokalen NoData-Pixel liegt; die Kartenreprojektion wurde auf mobilen Geräten entlastet.
- Kompositbild: optionale amtliche DWD-Warnkarte auf Gemeindeebene mit eigener Deckkraftsteuerung ergänzt.
- Kompositbild: Isobaren und 500-hPa-Geopotential werden primär als serverseitig gerenderte DWD-ICON-WMS-Layer geladen; die bisherigen MID-Konturen bleiben als automatischer Fallback erhalten.
- Kompositbild: Blitzdarstellung verwendet bei fehlenden Punktdaten nun zuverlässig das jeweils aktuelle DWD-Blitzdichte- beziehungsweise EUMETSAT-MTG-LI-Raster auch ohne veröffentlichte Zeitdimension; NowCastMIX-Punkte unterdrücken das Blitzraster nicht mehr.
- Kompositbild: KONRAD3D nutzt für Zuglinie und Wahrscheinlichkeitskegel den zeitlich weitesten belastbaren Prognosepunkt; falls nur Bewegungsrichtung und Geschwindigkeit vorliegen, wird ein gekennzeichneter 30-Minuten-Zugpfad abgeleitet.
- Kurzfristvorhersage: Überschreitet die prognostizierte Böe eine DWD-Warnschwelle, erhält der Windrichtungspfeil die Farbe der höchsten erreichten Warnstufe.

## 0.8.24.2

- Eigene Warnungen: Der erläuternde Fußtext wurde auf den einzigen Satz „Automatisch aus Best Match abgeleitet.“ gekürzt.
- Aktuelles Wetter: Die Schaltfläche für die Messwertkacheln heißt jetzt kompakt „mehr“ beziehungsweise im geöffneten Zustand „weniger“.
- Aktuelles Wetter: Die Schaltfläche wurde aus dem Inhaltskopf an den unteren rechten Modulrand verlegt. Reservierter Außenabstand, eigener Ebenenwert und mobile Abstände verhindern Überdeckungen mit Tmin/Tmax, Wettertext, Analysekarte und nachfolgenden Modulen.

## 0.8.24.1

- Ensemble-Diagramme: Datumsbeschriftungen der Temperatur-, Niederschlags- und Windachsen werden jetzt diagonal dargestellt, sodass alle 14 Vorhersagetage auch auf schmalen Displays eindeutig lesbar bleiben.
- Ensemble-Diagramme: Mobile Achsenticks verwenden eine stärkere Neigung als Desktop und Export; zusätzlicher Achsenraum verhindert Überdeckungen mit Diagramminhalten und dem externen Achsentitel.

## 0.8.24.0

- Aktuelles Wetter: Die nachfolgenden Messwertkacheln lassen sich über eine kompakte Schaltfläche im Kopfbereich ein- und ausklappen.
- Der gewählte Zustand der Aktuell-Wetter-Kacheln wird lokal gespeichert und beim nächsten Öffnen von MID wiederhergestellt.
- Die Schaltfläche ist für Maus, Touch und Tastatur bedienbar und weist ihren Zustand über `aria-expanded` aus.

## 0.8.23.0

- Wetterdarstellung vollständig auf ein transparentes, skalierbares SVG-Piktogrammsystem umgestellt. Alle relevanten WMO-Wettergruppen besitzen eigenständige professionelle Symbole für Tag und Nacht, einschließlich Nebel, Reifnebel, Sprühregen, gefrierendem Niederschlag, Schneeregen, Schneegriesel, Schauern, Gewitter und Hagel.
- Das bisher plattformabhängig eckig oder intransparent gerenderte Nebel-Emoji wurde durch ein transparentes Vektor-Piktogramm mit Wolken- und Nebelbändern ersetzt.
- Die neuen Wetterpiktogramme werden konsistent in aktuellem Wetter, Kurzfristvorhersage, 7-Tage-Prognose, Tagesdetail, Ensemble, Widget sowie Berg-, Wasser- und Reisewetter verwendet.
- Gewitterinformation: Bezugsort, aktuelle Zellposition und prognostizierte Zellposition erhalten hinter dem Ortsnamen den dreistelligen ISO-3166-Alpha-3-Ländercode, beispielsweise „Niederkassel, DEU“.
- Der Ortsnamencache der Gewitterinformation wurde auf eine neue Version migriert, damit vorhandene Einträge ohne Ländercode nicht weiterverwendet werden.

## 0.8.22.3

- Kurzfristvorhersage: Die Karten zeigen in der obersten Zeile jetzt direkt die Uhrzeit; die relative +xx-min-Angabe entfällt aus der Kartenansicht und bleibt nur in der Detailansicht erhalten.
- Kurzfristvorhersage: Der Hinweis im Header wurde auf die fachliche Quellenangabe „Best Match“ reduziert; der Zusatz „ohne zusätzlichen Abruf“ entfällt.
- Kurzfristvorhersage: Windpfeile der Karten wurden erneut korrigiert und berücksichtigen nun die 45°-Grundausrichtung des Navigationssymbols, sodass Pfeilrichtung und ausgeschriebene Herkunftsrichtung wieder konsistent zusammenpassen.

## 0.8.22.2

- Radar-Nowcast: Der bisher missverständliche Relativtext „Radarecho erreicht den Standort in … Minuten“ wurde für prognostizierte Standortniederschläge durch einen eindeutigen Uhrzeitraum ersetzt.
- Radar-Nowcast: Sichere Standorttreffer werden als „Niederschlag am Standort voraussichtlich von HH:MM bis HH:MM Uhr“ ausgegeben; unsichere Umgebungsechos bleiben ausdrücklich als mögliches Trefferfenster gekennzeichnet.
- Worker: Das Ende eines prognostizierten Niederschlagsereignisses entspricht nun dem Ende des letzten nassen Radarintervalls statt dessen Beginn. Dadurch entfallen widersprüchliche Angaben wie Ankunft bis 20:30 Uhr und Ende bereits 19:50 Uhr.

## 0.8.22.1

- Kurzfristvorhersage: Zeitachsenstufen rasten nun auf die nächste volle Viertelstunde ein, zeigen vier 15-Minuten-Schritte und wechseln danach auf volle Stunden bis +24 Stunden.
- Kurzfristvorhersage: Windpfeile zeigen jetzt konsistent in die Richtung, in die der Wind weht, während die Himmelsrichtung weiterhin die Herkunftsrichtung des Windes benennt.
- Kurzfristvorhersage: Gewitter-Badges erhalten auf schmalen Karten eine eigene Zeile und überdecken dadurch weder Temperatur noch Wettersymbol.

## 0.8.22.0

- Gewitterinformation: modellierte Böengeschwindigkeiten verwenden nun durchgängig die in MID gewählte Windeinheit.
- Neue optionale Kurzfristvorhersage direkt zwischen Warnungen und 7-Tage-Prognose: +15, +30, +45 Minuten, +1 Stunde und anschließend stündlich bis +24 Stunden; horizontal scrollbar und mit kompakter Detailansicht bei Auswahl. Die Darstellung nutzt ausschließlich bereits geladene 15-Minuten- und Best-Match-Stundendaten und verursacht keine zusätzlichen Abrufe.
- Dashboard-Sektionen können in den Einstellungen einzeln ein- oder ausgeschaltet sowie per Drag-and-drop, Touch-Griff oder Schaltflächen neu angeordnet werden. Deaktivierte Module werden nicht gerendert und lösen dadurch keine modulbezogenen Ladevorgänge aus.
- Gerätesynchronisation: lokal erzeugter QR-Code mit sicherem Fragmenttransfer. Das Zielgerät kann den Code über die Kamera-App scannen, MID öffnen und die Übernahme nach ausdrücklicher Bestätigung durchführen; der Schlüssel wird weder an einen QR-Dienst noch als URL-Anfrage an den Server übertragen.

## 0.8.21.0

- Hyperlokale Analyse: zentrales Quellenqualitätsregister mit feldspezifischer Bewertung von Entfernung, Alter, Standorttyp und Vertrauensfaktor
- Hyperlokale Analyse: lokale Restfeldkorrekturen werden bei geringer Stationsstützung konservativ gedämpft; mehrere übereinstimmende Messpunkte erhalten stärkeres Gewicht
- Niederschlagsmessungen: explizite 10-/60-Minuten-Bezugsintervalle und einheitliche Normalisierung vor der lokalen Assimilation
- Performance: Kurzzeitcache für Stationsanalyse und Modellhintergrund, begrenzte Stale-Fallbacks sowie Cache-Größenlimits
- Workerzugriffe: lokaler Antwortcache, Stale-if-error und temporärer Circuit-Breaker für wiederholt fehlschlagende Endpunkte
- Worker: Quellenvertrag um Niederschlagsintervalle für DWD/Bright Sky, GeoSphere und Synoptic ergänzt; Stations- und Warnantworten abrufschonend zwischengespeichert

## 0.8.20.0

- Hyperlokale Analyse: physische Stationsentdopplung über Kennung, Lage, Höhe, Messzeit und Temperaturplausibilität; Quellenalias-Dopplungen werden vor der Gewichtung entfernt.
- Hyperlokale Analyse: zirkuläre modellgestützte Restfeldanalyse der Windrichtung sowie abschließende Konsistenzprüfung von Temperatur/Taupunkt/Feuchte und Wind/Böen.
- Hyperlokale Analyse: Sicht, Bewölkung, Ceiling, Wolkenuntergrenze und Niederschlag werden nur aus amtlichen beziehungsweise professionellen Beobachtungsnetzen korrigiert.
- Abrufbudget: GeoSphere/Bright Sky werden bei vorhandenem Worker nur bei fehlender Quelle direkt nachgeladen; ein zweiter Stationslauf erfolgt nur bei geringer Dichte, hoher Unsicherheit oder großer effektiver Entfernung.
- Quellen- und Qualitätsaudit für nowcast/LINET, weitere Beobachtungsquellen, App-Architektur, Cachevertrag und Buildprozess ergänzt.

## 0.8.19.12

- 7-Tage-Vorhersage: Haupt- und Untertitel beginnen zuverlässig mit Großbuchstaben.
- Gewitterinformation: aktuelle und prognostizierte Zellposition erhalten nach Möglichkeit einen Ortsnamen; die Ortsauflösung wird räumlich gerastert und 12 Stunden lokal zwischengespeichert.
- Gewitterinformation: nächste Annäherung beziehungsweise möglicher Standorttreffer wird mit Ortszeit und Abstand zum ausgewählten Ort deutlich benannt.
- Gewitterkarte kompakter gestaltet; der freie doppelte Zusammenfassungstext entfällt und Kerndaten stehen ausschließlich in Status- und Unterfeldern.

## 0.8.19.11

- GitHub-Produktionsbuild repariert: Der nach der Gewittertext-Verfeinerung nicht mehr benötigte Parameter `cell` wurde aus `threatHeadline` und dem zugehörigen Aufruf vollständig entfernt.
- Die verfeinerte Gewitterinformation und die natürlichere Sprache der 7-Tage-Untertitel bleiben unverändert erhalten.

## 0.8.19.10

- Gewitterinformation weiter verfeinert: natürliche, wirkungsorientierte Überschriften, klar priorisierte Zellbewegung und farblich differenzierte Kernauswirkungen.
- Erweiterte Gewitterdetails erscheinen in einem größeren, mobilen Infofenster mit Schließen-Schaltfläche.
- 7-Tage-Untertitel verwenden natürliche Zeit-vor-Ereignis-Formulierungen wie „Abends Regen möglich“.

## 0.8.19.9

- Gewitterinformation erweitert: kompakte Kerndaten jetzt direkt auf der Gewitterkarte sichtbar
- Ausführlichere KONRAD3D-Gewitterdetails per Info-Button als strukturierte Übersicht mit Schwerpunkt, Annäherung, Böen-, Hagel-, Blitz- und Zugbahnangaben

## 0.8.19.8

- Tagesdetailansicht: Die kompakte Gewitterrisiko-Prozentangabe erscheint jetzt ab 30 %. Die Schwelle bleibt an die kombinierte Mehrindexdiagnose aus Instabilität, Feuchte, Auslösung und CIN gekoppelt; CAPE allein erzeugt weiterhin kein Signal.
- 7-Tage-Trend: Gewitterformulierungen verwenden jetzt dieselbe stündliche Mehrindexdiagnose wie die Tagesdetailansicht. Die frühere grobe Ersatzregel aus CAPE ≥ 700 J/kg und Tages-Niederschlagswahrscheinlichkeit ≥ 45 % wurde entfernt.
- Bei 30–69 % wird im Trend von Gewitterrisiko gesprochen; erst bei direktem WMO-/Warnsignal oder mindestens 70 % von Gewittern. Dadurch bleiben Kurztrend, Tagesdetail und eigene Warnungen konsistent.

## 0.8.19.7

- Tagesdetailansicht: Gewitterrisiko in der stündlichen Niederschlagskachel jetzt als kompakte Prozentangabe dargestellt
- 14-Tage-Ensemble: Niederschlags-/Schneesymbole bleiben innerhalb der Bewölkungskästchen; Blitzsymbol für Gewitter deutlicher und besser erkennbar

# MID v0.8.19.6

- Tagesdetailansicht: Das kompakte stündliche Gewitterrisiko basiert nicht mehr im Wesentlichen auf CAPE und Niederschlag, sondern auf einer kombinierten Best-Match-Diagnose aus WMO-Gewittercode, CAPE, Lifted Index, konvektiver Hemmung (CIN), Feuchteprofil, integriertem Wasserdampf sowie Schauer-/Niederschlags- und Auslösesignalen.
- Hohe CAPE-Werte allein lösen keine Gewitteranzeige mehr aus. Eine starke konvektive Hemmung kann das Signal unterdrücken, während übereinstimmende Instabilitäts-, Feuchte- und Triggerparameter die Stufe „erhöht“ oder „hoch“ stützen.
- Die Darstellung in der Niederschlagskachel bleibt unverändert kompakt als „⚡ erhöht“ beziehungsweise „⚡ hoch“; die Kachelgröße wird nicht verändert.
- Die zusätzlichen Open-Meteo-Parameter werden im bestehenden Best-Match-Abruf mitgeführt und verursachen keine weiteren Netzaufrufe.
- Neuer Regressionstest schützt Datenvertrag, Mehrindex-Bewertung, starke CIN-Deckelung, konservativen Fallback und direkte WMO-Gewittersignale.

# MID v0.8.19.5

- Tagesdetailansicht: Die bestehende stündliche Niederschlagskachel nennt bei signifikantem Modellhinweis nun kompakt ein erhöhtes oder hohes Gewitterrisiko. WMO-Gewittercodes werden unmittelbar berücksichtigt; zusätzlich werden CAPE, Niederschlagssignal und Niederschlagswahrscheinlichkeit gemeinsam plausibilisiert.
- Die Gewitterinformation wird in der vorhandenen Detailzeile der Niederschlagskachel ausgegeben und per Ein-Zeilen-Kürzung begrenzt, sodass die Kachelgröße unverändert bleibt.
- Ensemble-Temperaturtrend: Die Niederschlagsmenge wird in den Bewölkungs-/Sonnenkästchen nur noch über ein kleines oder großes Symbol unterschieden. Regen nutzt einen Tropfen, Schnee eine Schneeflocke; Mischformen kombinieren beide kompakt.
- Gewitterblitze werden neben das Niederschlagssymbol versetzt und passend verkleinert, damit weder Blitz noch Tropfen/Flocke einander verdecken und die Symbolik vollständig innerhalb des bestehenden Kästchens bleibt.
- Neuer Regressionstest schützt die stündliche Gewitterrisikologik, die kompakte Kachelintegration und die vereinfachte Ensemble-Symbolik.

# MID v0.8.19.4

- GitHub-/TypeScript-Buildfix für die ICAO-Ortssuche: Der Rückgabetyp des neuen Worker-Aufrufs wurde an den bestehenden `fetchWorkerJson`-Vertrag angepasst. Damit ist `Location` nicht mehr fälschlich direkt gegen den optionalen Worker-Fehlerumschlag typisiert.
- Die ICAO-Suche, ihr 30-Tage-Cache, die NOAA-AviationWeather-Auflösung und die Darstellung in Haupt- und Reisewettersuche bleiben funktional unverändert.
- Neuer Regressionstest schützt vor dem konkreten TS2559-Buildfehler.

# MID v0.8.19.3

- Ortssuchen erweitert: Neben Ort, Region, PLZ und POI können nun weltweit exakte vierstellige ICAO Location Indicators wie EDDG, EDDF oder KJFK eingegeben werden.
- Die gemeinsame Suchfunktion steht damit auch in der Hauptsuche und im Reisewetter-Reiseplaner zur Verfügung. ICAO-Treffer werden als Flughafen gekennzeichnet und mit Koordinaten sowie Höhenlage übernommen.
- Abrufschutz: Eine ICAO-Abfrage wird nur bei einem exakten vierstelligen Suchmuster und fehlendem gleichnamigem Orts-/PLZ-Treffer ausgelöst. Erfolgreiche Ergebnisse werden 30 Tage lokal gespeichert; parallele identische Abfragen werden zusammengeführt.
- Der Worker löst ICAO-Kennungen über NOAA AviationWeather auf und speichert erfolgreiche Antworten zusätzlich mit einem 30-Tage-HTTP-Cache.
- Neuer Regressionstest schützt Datenvertrag, Caching, Worker-Endpunkt und alle drei Suchoberflächen.

# MID v0.8.19.2

- Ensemble-Temperaturdiagramm: In den Bewölkungs-/Sonnenkästchen erscheinen nun bei Best-Match-Niederschlag kompakte Niederschlagssymbole direkt innerhalb des bestehenden Rahmens. Je nach Niederschlagsart werden Tropfen, Schneeflocken oder gemischte Symbole gezeigt; Gewittertage erhalten zusätzlich einen Blitz.
- Die Symbolik wird nach Best-Match-Niederschlagsmenge und -wahrscheinlichkeit in ein bis drei Zeichen abgestuft, ohne die Diagrammgröße oder die Kästchengeometrie zu verändern.
- Der Tooltip des Temperaturtrends nennt zusätzlich die zugehörige Best-Match-Niederschlagsart, -menge und die Best-Match-Wahrscheinlichkeit.

# MID v0.8.19.1

- Reisewetter-Abrufe deutlich reduziert, ohne die Sektion zu deaktivieren: pro ungefähr 10-km-Klimaraster und Höhenklasse wird nur ein kompakter Basisdatensatz angefordert und anschließend drei Jahre lokal wiederverwendet.
- Parallele oder wiederholte identische Klimaanfragen werden zusammengeführt; mehrfaches Tippen beziehungsweise gleichzeitige Auswertungen lösen dadurch keinen doppelten Netzabruf aus.
- Der Basisabruf wurde um nicht benötigte historische Variablen verkleinert. Temperaturmittel und Bewölkungsnähe werden aus den verbleibenden Tageswerten abgeleitet.
- Detaillierte historische Schneehöhe wird nicht mehr automatisch allein durch die Optimierung „Hohe Schneelage“ geladen. Sie erfordert eine ausdrückliche Zusatzoption oder eine definierte Mindestschneehöhe; ohne Zusatzabruf bewertet MID das bereits enthaltene Schneefallpotenzial.
- Die Reisewetter-Sektion nutzt weiterhin keinen MID-Worker und bleibt standardmäßig eingeklappt. Ein neuer Regressionstest schützt Abrufbudget, In-Flight-Entdopplung, Rastercache, reduzierten Variablensatz und die explizite Schneehöhenfreigabe.

# MID v0.8.19.0

- Neue, standardmäßig eingeklappte Sektion „Reisewetter & Reiseplaner“ im unteren App-Bereich. Sie ist im Standard- und Erweiterten Modus verfügbar und wird erst beim Scrollen beziehungsweise Öffnen lazy geladen.
- Freie Zielortsuche unabhängig vom aktuell geöffneten MID-Ort. Für einen festen Reisezeitraum werden klimatologisch erwartbare Temperatur, Niederschlagstage, Sonnenschein, Wind, Schneefall und ein kompakter Tagesverlauf dargestellt.
- Flexibler Reiseplaner: Innerhalb eines Suchzeitraums von bis zu 120 Tagen kann ein 2- bis 42-tägiges Reisefenster nach „ausgewogen“, möglichst trocken, warm, kalt, sonnig, schneereich oder windarm optimiert werden.
- Optional definierbare Bedingungen: Mindest-/Höchsttemperatur, maximale Regentage, Mindestsonnenschein, maximales Windmaximum und Mindestschneehöhe. Falls kein Fenster alle Bedingungen erfüllt, zeigt MID transparent die beste Annäherung und die noch verfehlten Kriterien.
- Datengrundlage ist die Open-Meteo-ERA5-Land-Reanalyse 1991–2020. Historische Schneehöhe wird nur bei ausdrücklicher Schneewahl zusätzlich aus Stundenwerten geladen; alle Klimadaten werden lokal aggregiert und für 180 Tage zwischengespeichert. Die Sektion erzeugt keine automatischen Workerzugriffe.
- Neuer Regressionstest schützt Modulposition, eingeklappten Standardzustand, Zielortsuche, feste und flexible Planung, Bedingungen, Klimadatenpfad, optionale Schneehöhe und die dynamische Auswahl des besten Zeitfensters.

# MID v0.8.18.15

- Wasserwetter-Verlauf: Gezeiten- und Wasserstandswendepunkte werden nun direkt in der Tagesmatrix angezeigt. Jeder Tag enthält eine kompakte Tabellenzeile mit Hoch-/Tiefpunkt, exakter Uhrzeit und modelliertem Wasserstand.
- Die Wendepunktanalyse wurde von sechs auf bis zu 18 Ereignisse erweitert, damit beim Aufklappen der Option „Nächste 3 Tage“ alle verfügbaren Tageswendepunkte abgedeckt werden können.
- Die neue Zeile spannt übersichtlich über die Zeitspalten, bleibt horizontal scrollbar und unterscheidet Hoch- und Tiefpunkte farblich, ohne die stündlichen beziehungsweise dreistündlichen Wasserstandswerte zu verdrängen.
- Neuer Regressionstest schützt Drei-Tage-Abdeckung, Datenübergabe, Tabellenintegration und responsive Darstellung.

# MID v0.8.18.14

- Eigene Warnkarten: Identische niedrigere Warnphasen werden jetzt über eine dazwischenliegende höhere Warnstufe hinweg zu einem einzigen einrahmenden Gültigkeitszeitraum verbunden. Im gezeigten Wärmebeispiel gilt die starke Wärmebelastung damit einmal von 11:00 bis 21:00 Uhr, während die extreme Wärmebelastung weiterhin separat von 15:00 bis 17:00 Uhr ausgewiesen wird.
- Eine niedrigere Warnung wird nur zusammengeführt, wenn Warntyp, Warnstufe und sichtbarer Inhalt unverändert bleiben und die zeitliche Lücke vollständig durch eine höhere Warnstufe desselben Typs abgedeckt ist. Inhaltlich unterschiedliche Phasen bleiben getrennt.
- Neuer Regressionstest schützt die einrahmende Zusammenfassung und verhindert zugleich das versehentliche Zusammenführen unterschiedlicher Warninhalte.

# MID v0.8.18.13

- Ensemble-Temperaturdiagramm: Warnmarker werden nun vor der Darstellung nach Warntyp zusammengefasst. Je Warntyp erscheint ausschließlich die höchste erreichte Warnstufe; unterschiedliche Warntypen bleiben parallel sichtbar.
- Ensemble-Tooltip: Auch die Hazard-Liste enthält je Warntyp nur noch die höchste Warnung. Niedrigere Schwellen desselben Typs werden dort nicht mehr doppelt aufgeführt.
- Neuer Regressionstest schützt die gemeinsame Filterung von Diagrammmarkern und Tooltip sowie den Erhalt verschiedener Warntypen.

# MID v0.8.18.12

- 7-Tage-Vorhersage: Die kompakten Warnsymbole zeigen pro Warntyp nur noch die höchste erreichte Warnstufe. Mehrere Wind-, Schnee-, Regen- oder andere Intensitätsstufen werden in dieser engen Übersicht nicht mehr gestapelt.
- Die vollständige Mehrstufenanzeige mit niedrigeren Intensitäten, Gültigkeitszeiträumen und Windrichtung bleibt in den ausführlichen eigenen Warnkarten unverändert erhalten.
- Neuer Regressionstest schützt die Trennung zwischen kompakter Tagesübersicht und vollständiger Warnkartendarstellung.

# MID v0.8.18.11

- GitHub-/TypeScript-Buildfix für die Mehrstufen-Warnlogik: Die nach der Umstellung nicht mehr verwendeten Hilfsfunktionen `levelFromThresholds` und `windClassification` wurden entfernt.
- Die aktive Mehrstufenberechnung über `windClassifications` sowie alle niedrigeren Warnstufen, Gültigkeitszeiträume und Windrichtungstexte bleiben unverändert erhalten.
- Neuer Regressionstest schützt vor erneutem Einbringen ungenutzter Warnungs-Helper und sichert die aktive Mehrstufen-Windlogik ab.

# MID v0.8.18.10

- Eigene Warnungen: Beim Überschreiten mehrerer Schwellen werden nun neben der höchsten Warnstufe auch die niedrigeren Intensitätsstufen ausgegeben.
- Jede Warnstufe erhält einen eigenen, automatisch berechneten Gültigkeitszeitraum; bei Wind bleibt die niedrigere Stufe über den gesamten Zeitraum aktiv, in dem ihre Schwelle überschritten wird, während höhere Stufen als zusätzliche engere Warnphase erscheinen.
- Windwarnungen nennen bei niedrigeren Stufen Schwellenwert und zeitweilige Spitze, etwa „Windböen über 50 km/h; zeitweise bis 71 km/h“, einschließlich Windrichtung beziehungsweise Richtungsänderung.
- Niedrigere Warnstufen werden kompakt als solche gekennzeichnet, ohne die bestehende übersichtliche Kartenstruktur oder die Datums-/Zeitkapsel zu vergrößern.
- Neuer Regressionstest schützt Mehrstufenlogik, überlappende Warnzeiträume, Windrichtungstext, Datenvertrag und responsive Darstellung.

# MID v0.8.18.9

- Eigene Windwarnungen korrigiert: Die reale stündliche Best-Match-Windrichtung wurde intern im Feld `direction` geführt, die Warnlogik hatte jedoch ausschließlich `windDirection` ausgewertet. Dadurch blieb die Richtung trotz vorhandener Daten im Warntext leer.
- Die Warnlogik akzeptiert nun beide Feldbezeichnungen und übernimmt damit die tatsächlich von MID verwendeten Stundenwerte zuverlässig.
- Stabile Richtungen erscheinen direkt im Satz, etwa „Windböen bis 29 kt (54 km/h) aus westlicher Richtung.“; markante Drehungen werden weiterhin als „anfangs …, später …“ formuliert.
- Neuer dynamischer Regressionstest verwendet ausdrücklich den echten `Hour.direction`-Datenvertrag und schützt sowohl konstante Richtung als auch Richtungswechsel vor erneutem Ausfall.

# MID v0.8.18.8

- Eigene Windwarnungen: Die modellierte Windrichtung steht nun direkt im laufenden Warntext – analog zur Formulierung amtlicher DWD-Warnungen – und nicht mehr in einer separaten Kapsel.
- Bei stabiler Richtung lautet die Warnung beispielsweise „Sturmböen bis 39 kt (71 km/h) aus westlicher Richtung.“
- Bei markanter Drehung wird der Text unmittelbar erweitert, etwa „…; anfangs aus südwestlicher, später aus nordwestlicher Richtung.“
- Die separate Windrichtungs-Kapsel einschließlich ihrer CSS-Regeln wurde entfernt; die kompakte Gültigkeitskapsel bleibt unverändert bestehen.
- Regressionstests schützen die Inline-Formulierung, Richtungswechsel, den 360°-/0°-Übergang und das Fehlen der separaten Richtungsanzeige.

# MID v0.8.18.7

- Eigene Windwarnungen zeigen jetzt zusätzlich die modellierte Windrichtung im jeweiligen Warnzeitraum.
- Bei stabiler Windrichtung erscheint eine kompakte Angabe wie „Aus südwestlicher Richtung“.
- Markante Richtungsänderungen werden zeitlich verständlich beschrieben, beispielsweise „Anfangs aus südwestlicher, später aus nordwestlicher Richtung“.
- Die Richtungsbewertung verwendet zirkuläre Mittelwerte, sodass der Übergang über 360°/0° korrekt als nördliche Strömung erkannt wird.
- Die aktuelle Warnkarte erhält eine kompakte Windrichtungs-Kapsel; Tages-, Widget- und Ensemble-Hazard-Tooltips übernehmen die Richtungsinformation ebenfalls.
- Neuer Regressionstest schützt konstante Windrichtung, Richtungswechsel, 360°-Übergänge und responsive Darstellung.

# MID v0.8.18.6

- Eigene Warnindikatoren: Warnzeiträume, die erst morgen beginnen, zeigen nun kompakt sowohl „Morgen“ als auch das konkrete Datum, zum Beispiel „Morgen, 30.07. · 08:00–12:00 Uhr“.
- Spätere Warnungen tragen ebenfalls das Datum; heutige Warnungen bleiben platzsparend bei der Uhrzeit. Zeiträume über Mitternacht zeigen weiterhin Start- und Enddatum vollständig.
- Neuer Regressionstest prüft Morgen-, Folgetag-, Heute- und Mitternachtsdarstellung in der Ortszeitzone.

# MID v0.8.18.5

- Eigene Warnindikatoren zeigen jetzt einen kompakten Gültigkeitszeitraum in Ortszeit. Aktive Zeitfenster beginnen verständlich mit „jetzt“, künftige sowie über Mitternacht reichende Zeiträume werden mit Uhrzeit beziehungsweise Datum dargestellt.
- Die Gültigkeit wird aus den zusammenhängenden Stunden beziehungsweise Akkumulationsfenstern des jeweiligen Warnsignals berechnet; getrennte Ereignisse werden nicht zu einem einzigen langen Zeitraum vermischt.
- Die neue Zeitangabe erscheint als platzsparende, responsive Kapsel direkt in der Warnkarte und bleibt auf schmalen Displays umbrechbar. Amtliche Warnungen und deren bestehende CAP-Zeiträume bleiben unverändert.
- Neuer Regressionstest schützt Berechnung, Datenvertrag, Ortszeitformatierung und kompakte Darstellung.

# MID v0.8.18.4

- Dauerhaft erreichbares Impressum im App-Footer ergänzt und zusätzlich als eigener Bereich „Rechtliches“ im Einstellungsmenü aufgenommen.
- Anbieterkennzeichnung mit vollständigem Namen und ladungsfähiger Anschrift integriert.
- Die Kontaktadresse liegt weder im initialen DOM noch als zusammenhängender Klartext im App-Quellcode vor. Sie wird erst nach bewusster Nutzerinteraktion aus getrennten Zeichencodes zusammengesetzt und anschließend als anklickbare E-Mail-Adresse angeboten.
- Barrierearmes Impressumsdialogfenster mit Escape-, Außenklick- und mobiler Vollbildbedienung ergänzt.
- Neuer Regressionstest schützt Erreichbarkeit, Pflichtangaben, responsives Design und die E-Mail-Obfuskation.

# MID v0.8.18.3

- Cross Section vorerst vollständig pausiert: Im Erweiterten Modus erscheint nur noch eine statische Karte „To be continued“. Das aktive Flugmeteorologie-Modul importiert oder rendert die Cross-Section-Komponente nicht mehr.
- Der Worker-Endpunkt `flight-cross-section` ist hart deaktiviert, aus dem Health-Servicekatalog entfernt und antwortet ohne externe Datenabrufe mit HTTP 410. Dadurch entstehen durch diese Funktion keine NOAA-, Open-Meteo- oder Elevation-Subrequests mehr.
- Druckniveau-Meteogramme bleiben unverändert aktiv. Der Cross-Section-Quellcode wird für eine spätere Weiterentwicklung erhalten, aber nicht in den aktiven Frontendpfad eingebunden.
- Neuer Regressionstest schützt die UI-Pausierung, den entfernten Frontendpfad und die serverseitige Sperre.

# MID v0.8.17.0

- Aktuelle Daten: Die Uhrzeiten der Kachel „Sonne / Mond“ verwenden nun eine ausdrücklich begrenzte, an den übrigen Kachelwerten orientierte Schriftgröße. Die Kachel besitzt keine eigene Mindesthöhe mehr und vergrößert die gesamte Parameterzeile weder auf Desktop noch mobil.
- Ensemble: Unterhalb des Niederschlagsdiagramms wurde ein zusätzliches Winddiagramm ergänzt. Es lässt sich zwischen täglichem Windmaximum und Böenspitzen umschalten und zeigt Best Match, gewichtetes Ensemble-Mittel sowie P10–P90 im Stil des Temperaturtrends.
- Die Open-Meteo-Ensembleabfrage und der Worker-Proxy liefern Wind und Böen einheitlich in Knoten. Der Ensemblecache wurde wegen des erweiterten Datenvertrags invalidiert.
- Temperatur-, Niederschlags- und Winddiagramm können einzeln ein- und ausgeklappt werden. Der Zustand wird lokal gespeichert; PNG-Export, Tooltips, Legenden und mobile Darstellung bleiben je Diagramm erhalten.
- Neue und erweiterte Regressionstests schützen Wind-/Böendaten, Worker-Proxy, Exportgeometrie, Diagrammreihenfolge, Einklappzustände sowie die kompakte Sonne-/Mond-Kachel.

# MID v0.8.16.1

- Aktuelle Daten: Die Kachel „Sonne / Mond“ wurde kompakter abgestimmt. Die Zeitwerte für Sonnenaufgang und Sonnenuntergang verwenden nun deutlich kleinere, an die übrigen Kacheln angeglichene Schriftgrößen.
- Die Mindesthöhe der Sonne-/Mond-Kachel wurde spürbar reduziert, damit die gesamte Zeile der aktuellen Daten auf Desktop und mobil nicht unnötig in die Höhe gezogen wird.
- Die Trennung von Sonnenaufgang, Sonnenuntergang, Mondphase und Tageslänge bleibt erhalten, jedoch mit dichterem vertikalem Rhythmus und platzsparenderen Details.
- Der bestehende Regressionstest für die Astronomie-Kachel prüft jetzt ausdrücklich die kompaktere Typografie und die verringerte Kartenhöhe.

# MID v0.8.15.7

- Aktuelle Daten: Die Kachel „Sonne / Mond“ wurde erneut an das Standarddesign der übrigen Kacheln angeglichen. Sonnenaufgang und Sonnenuntergang erscheinen nun als zwei untereinander liegende, sauber getrennte Zeitblöcke mit Trennlinie statt in einer Sonderdarstellung.
- Desktop- und Mobilansicht wurden auf überlappungsfreie Darstellung optimiert: mehr vertikale Reserve, stabile Typografie, kein Zusammenlaufen der Überschriften und keine Kollision mit der Info-Schaltfläche.
- Mondphase, nächste Mondphase und Tageslänge bleiben darunter kompakt erhalten.
- Der Regressionstest für die Astronomie-Kachel prüft jetzt ausdrücklich das standardnahe Kartenlayout sowie die überlappungsfreie Desktop-/Mobilstruktur.

# MID v0.8.15.4

- Standortauswahl mit Favoritenabgleich korrigiert: Nach einer Geräteortung prüft MID die bewährte geografische Nahbereichszuordnung. Entspricht die Position einem gespeicherten Favoriten, wird dessen kanonischer Ort geöffnet statt eines separaten Reverse-Geocoding-Punkts.
- Dadurch werden für die Standortauswahl automatisch die vollständigen Favoritenprofile verwendet, insbesondere Wetterzwilling-Daten, lokale Lernhistorie sowie Berg-/Winter- und Wasserprofile. Die tatsächlich gemessene Geräteposition bleibt separat für Standortstatus und Distanzprüfung gespeichert.
- Favorit und Standort dürfen nun gleichzeitig aktiv markiert sein: Der passende Favorit bleibt in Schnellleiste, Suchmenü und Favoritenverwaltung blau markiert; zusätzlich erhält der Standort-Eintrag seinen blauen Rahmen, solange die Auswahl tatsächlich von der Geräteortung stammt.
- Eine manuelle Orts- oder Favoritenauswahl entfernt weiterhin sofort ausschließlich den Standort-Rahmen. Beim Standortabgleich wird auf den ausdrücklich zugeordneten kanonischen Favoritenort umgeschaltet, damit Wetterdaten, Favoritenschlüssel und Profildaten konsistent aus derselben Ortsbasis stammen.
- Neuer Regressionstest schützt Favoritenabgleich der Geräteposition, kanonische Favoritenauswahl, gleichzeitige Standort-/Favoritenmarkierung und das Zurücksetzen des Standortstatus bei manueller Auswahl.

# MID v0.8.15.3

- Berg-/Wintersport: Der vollständige Höhenwetter-Verlauf ist im Sommer- wie im Winterprofil standardmäßig eingeklappt und lässt sich über eine kompakte Kopfzeile gezielt öffnen und wieder schließen.
- Beim Wechsel zwischen Sommer- und Winterprofil wird der Höhenwetter-Verlauf erneut geschlossen; auch eine zuvor aufgeklappte Drei-Tage-Ansicht kehrt in den kompakten Ausgangszustand zurück.
- Die 1-/3-Stunden-Umschaltung und die Erweiterung auf die nächsten drei Tage bleiben nach dem Öffnen unverändert verfügbar. Auf mobilen Displays beansprucht die geschlossene Darstellung nur noch eine kompakte Zeile.
- Neuer Regressionstest schützt den geschlossenen Startzustand, beide Saisonbezeichnungen, den Saisonwechsel und die bedingte Darstellung der umfangreichen Höhenmatrix.

# MID v0.8.15.2

- Favoriten-Nahbereichslogik wiederhergestellt: Exakte Koordinaten werden weiterhin bevorzugt; Orte und POIs innerhalb der bewährten plausiblen Distanz- und Höhenschwellen werden wieder demselben Favoriten zugeordnet. Dadurch entstehen bei nur wenigen hundert Metern Abweichung keine unnötigen zusätzlichen Favoriten oder Datenneuladungen.
- Die in v0.8.15.1 eingeführte strikte 150-m-/ID-Prüfung wurde vollständig zurückgenommen. Favoritenmenü, Schnellleiste, Favoritenstern, Ortswechsel und mobile Rand-Wischnavigation verwenden wieder dieselbe konsistente Nahbereichszuordnung.
- Standort-Aktivrahmen grundlegend entkoppelt: Die blaue Markierung richtet sich nun nach der ausdrücklich zuletzt gewählten Quelle „Gerätestandort“ oder „manuelle Orts-/Favoritenauswahl“ und nicht mehr allein nach einem potenziell veralteten `autolocated`-Merkmal im Ortsobjekt.
- Auch wenn ein Ortswechsel wegen geringer Entfernung ohne Datenneuladung abgekürzt wird, wird die Auswahlquelle sofort aktualisiert. Ein manuell gewählter Favorit nimmt daher zuverlässig die Standort-Markierung zurück; ein tatsächlich aufgerufener Gerätestandort aktiviert sie gezielt.
- Der Standort-Rahmen verlangt zusätzlich weiterhin eine geografische Übereinstimmung mit der zuletzt ermittelten Geräteposition. Ein rund 200 km entfernter Ort kann damit weder über die Auswahlquelle noch über die Distanzprüfung als aktiver Standort erscheinen.
- Regressionstest erweitert: geprüft werden Nahbereichszuordnung über wenige hundert Meter, Ablehnung weit entfernter Orte, Quellenwechsel vor dem Kurzschluss, Menüsprung und die einheitlichen Info-Schaltflächen.

# MID v0.8.15.1

- Aktuelle Daten: Die Info-Schaltflächen der Kacheln „Luftqualität“ und „Sonne / Mond“ verwenden nun dieselbe Größe, Ausrichtung und visuelle Gestaltung.
- Favoritenmenü stabilisiert: Beim Öffnen werden der aktuell angezeigte Favorit sowohl im Suchmenü als auch in der Favoritenverwaltung nach dem vollständigen Layout mehrfach abgesichert und direkt mittig in den sichtbaren Bereich geführt. Größenänderungen des Menüs lösen die Positionierung erneut aus.
- Favoriten-Schnellleiste springt auch unter iOS/Safari zuverlässig zum aktiven Favoriten; spätere Layoutänderungen und horizontale Überläufe werden berücksichtigt.
- Standortstatus korrigiert: Gespeicherte Favoriten übernehmen den internen Auto-Standortstatus nicht mehr. Der blaue Aktivrahmen des dynamischen „Standort“-Eintrags erscheint ausschließlich bei einer tatsächlich über die Geräteortung geöffneten Position.
- Die aktive Favoritenerkennung verwendet für die Oberfläche keine großzügige geografische Näherungsprüfung mehr, sodass andere Orte oder nahe POIs nicht fälschlich als aktiver Favorit markiert werden.
- Auch der eigentliche Ortswechsel und die mobile Favoriten-Wischzuordnung verwenden nun dieselbe strikte Identität; nahe, aber unterschiedliche Orte werden nicht mehr als bereits geöffnet verworfen.
- Neuer Regressionstest schützt Info-Schaltflächen, direkten Menüsprung, Favoritenverwaltung, Schnellleiste und die Trennung zwischen Auto-Standort und gespeichertem Favoriten.

# MID v0.8.15.0

- GitHub-Produktionsbuild korrigiert: Die Favoriten-Persistenz verwendet für optionale Idle-Callbacks keine TypeScript-Narrowing-Verzweigung mehr, durch die `window` im Fallback als `never` interpretiert wurde. Der bisherige Fehler TS2339 bei `clearTimeout` ist damit behoben.
- Tagesdetaildiagramm um einen eigenen Luftdruckverlauf in hPa ergänzt. Die adaptive Druckskala erhält eine separate kompakte Diagrammspur; der Verlauf ist standardmäßig sichtbar und über die Legende deaktivierbar.
- Die Detaillegende lässt sich vollständig ein- und ausklappen. Der Zustand wird gespeichert; auf schmalen Displays startet sie beim ersten Aufruf platzsparend eingeklappt.
- Stündliche Detailkacheln neu geordnet: Luftdruck mit kurzfristiger Tendenz beziehungsweise Tagesbereich ergänzt; Bewölkung und UVI zu einer gemeinsamen Kachel zusammengeführt, sodass die mobile Darstellung trotz zusätzlicher Information kompakt bleibt.
- Neuer Regressionstest schützt Buildfix, Luftdruck-Datenpfad, Diagrammspur, schaltbare und persistente Legende sowie die mobile Kachelstruktur.

# MID v0.8.14.0

- Neue Favoriten starten ohne aktive numerische persönliche Regeln. Bestehende unveränderte Standardregeln werden bei der Migration ebenfalls als deaktiviert erkannt; individuell angepasste Regeln und Push-Regeln bleiben erhalten. Ein eigener Schalter aktiviert die 24-Stunden-Prüfung bewusst je Favorit.
- Favoritenmenü korrigiert: Beim Öffnen wird der aktuell angezeigte Favorit nach vollständig aufgebautem Menü zuverlässig mittig in den sichtbaren Bereich geführt. Die Positionierung wird über zwei Renderframes und einen kurzen Layout-Fallback abgesichert.
- Performance-Audit erweitert: Favoritenänderungen werden entprellt und in Browser-Leerlaufphasen gespeichert, bei Ausblenden oder Schließen aber sofort gesichert. Unveränderte Push-/Lernsignaturen werden memoisiert, Wetterzwilling-Ableitungen reagieren nur noch auf tatsächlich relevante Schalter, und lange Favoritenlisten werden per Rendering-Containment entlastet.
- Deaktivierte persönliche Regeln erzeugen weder Regelberechnungen noch die zugehörigen kontrollierten Eingabefelder; Push-Benachrichtigungsregeln bleiben davon unabhängig.
- Neuer Regressionstest schützt Standardzustand, Legacy-Migration, robustes Zentrieren des aktiven Favoriten und die zusätzlichen Performance-Maßnahmen.

# MID v0.8.13.0

- Wetterpiktogramme konsequent um Tages-/Nachtvarianten ergänzt: Bewölkung, Sprühregen und Schauer verwenden nachts keine Sonnenpiktogramme mehr. Der Höhenwetter-Verlauf übernimmt dafür nun ebenfalls den jeweiligen `is_day`-Status je Zeitabschnitt.
- Sonne-/Mond-Kachel verdichtet: Sonnenauf- und -untergang bleiben kompakt im Primärwert; Mondphase und die verbleibenden Tage bis zum nächsten Neu- oder Vollmond erscheinen direkt darunter.
- Schließbares Astronomie-Info-Popover ergänzt. Es zeigt chronologisch astronomische, nautische und bürgerliche Dämmerung, blaue und goldene Stunde, Sonnenhöchststand sowie Mondauf- und -untergang. Außenklick/-tippen und Escape schließen wie bei den übrigen MID-Tooltips.
- Astronomiekern erweitert um zusätzliche Sonnenhöhen-Ereignisse und Countdown zum nächsten Neu-/Vollmond.
- Neuer Regressionstest schützt Nachtpiktogramme, Höhenwetter-Tag/Nacht-Bezug, kompakte Mondanzeige und das Astronomie-Popover.

# MID v0.8.12.0

- Wassersportmodul sprachlich auf „Wassersport“ verkürzt; Favoritenprofil, Schnellzugriff und Modulkopf verwenden nun dieselbe Bezeichnung.
- Neuer standardmäßig eingeklappter „Wasserwetter-Verlauf“ analog zur Höhenwetter-Matrix: umschaltbar zwischen 1- und 3-Stunden-Auflösung, mit aufklappbaren nächsten drei Tagen und Tageslichtfenstern.
- Der Verlauf zeigt Wetter, Luft-/gefühlte Temperatur, Wind/Böen, Niederschlag, Sicht sowie Gewitter/UVI; an geeigneten Meeresstandorten zusätzlich Welle/Richtung, Wellenperiode, Wassertemperatur, Strömung und modellierten Wasserstand.
- Automatische Bergsaison korrigiert: Außerhalb der klassischen Skisaison wird im Automatikmodus konsequent „Sommer“ gewählt; einzelne Restschnee- oder Neuschneesignalwerte erzwingen dann kein Winterprofil mehr.
- Neuer Regressionstest schützt Wasserwetter-Verlauf, eingeklappten Startzustand, Wassersport-Wording und die saisonale Sommerwahl.

# MID v0.8.10.2

- Aktuelle Sonnenscheindauer wird in der Wetterkachel konsequent als Minutenwert je ausgewiesenem Stundenfenster dargestellt: beispielsweise „60 min“ statt „1 h“.
- Die Anzeige bleibt auf die tatsächlich abgedeckte Zeitspanne und grundsätzlich auf höchstens 60 Minuten begrenzt; bei nur 45 Minuten Datenabdeckung können daher maximal 45 min erscheinen.
- Tages- und Ensembleangaben bleiben weiterhin in Stunden, da dort mehrstündige beziehungsweise tägliche Summen dargestellt werden.
- Neuer Regressionstest schützt Minutenformat, Stundenobergrenze und die Verwendung der aggregierten 60-Minuten-Auswertung in der aktuellen Wetterkachel.

# MID v0.8.10.1

- Aktuelle Sonnenscheindauer korrigiert: Die 60-Minuten-Auswertung verwendet jetzt exakt die letzten vier 15-Minuten-Intervalle statt durch die inklusive Zeitgrenze versehentlich fünf Werte zu summieren. Eine Anzeige wie „1 h 15 min in den letzten 60 Minuten“ ist damit ausgeschlossen.
- Jedes 15-Minuten-Intervall wird zusätzlich auf höchstens 900 Sekunden Sonnenschein begrenzt; auch Current- und Stunden-Fallback können den ausgewiesenen Zeitraum nicht mehr überschreiten.
- Volle 60 Minuten werden kompakt als „1 h“ statt „1 h 00 min“ dargestellt.
- Neuer Regressionstest schützt Intervallzahl, physikalische Obergrenze und Ausgabeformat.

# MID v0.8.10.0

- Mobile Favoritennavigation ergänzt: Eine deutliche Wischgeste vom linken beziehungsweise rechten Bildschirmrand zur Mitte öffnet den vorherigen beziehungsweise nächsten Favoriten. Die Gesten sind ausschließlich in der Appansicht aktiv und bleiben im Einstellungsdialog gesperrt.
- Favoritenwechsel auf Mobilgeräten und per Desktop-Klick bewahren nun die aktuelle Ansicht: MID merkt sich den sichtbaren Modul-/Sektionsanker, die relative Bildschirmposition und den ausgewählten Prognosetag. Dadurch bleibt beispielsweise das Tagesdetaildiagramm beim Ortswechsel geöffnet und im Sichtbereich.
- Aktuelle Sonnenscheindauer korrigiert: Statt das einzelne 15-Minuten-Current-Intervall fälschlich als letzte Stunde auszugeben, summiert MID bis zu vier echte 15-Minuten-Werte zu einem gleitenden 60-Minuten-Fenster. Der Zeitraum und die Zahl der Intervalle werden transparent ausgewiesen.
- Die aktuelle Viertelstunde der Sonnenscheindauer erhält bei übereinstimmend dichter lokaler und modellierter Bewölkung einen vorsichtigen Plausibilitätscheck; ältere Viertelstunden des 60-Minuten-Fensters bleiben unverändert.
- Neuer Regressionstest schützt Rand-Wischgesten, Ansichts-/Tageserhalt, die 60-Minuten-Sonnenscheinaggregation und den lokalen Bewölkungsabgleich.

# MID v0.8.9.0

- Berg-/Wintersport-Höhenwetter farblich aufgewertet: Wind-/Böenzellen erhalten ab den bestehenden DWD-nahen Schwellen dezente, textkontrastschonende Warnstufen-Hintergründe; Niederschlagszellen reichen von blassem Blau bei geringen Mengen bis zu dunkelblau mit weißer Schrift bei höheren Intervallsummen.
- Wolkenbasis eindeutig referenziert: Die Höhenmatrix zeigt die Untergrenze in Meter über NHN und zusätzlich relativ über dem jeweiligen Tal-/Mittel-/Bergniveau. Unterschiede zwischen Höhenzonen werden als Ergebnis getrennter Punktprognosen und Vertikalprofile erklärt.
- Wolkenschicht- und Sichtplausibilität ergänzt: MID lädt begrenzte Druckniveau-Wolken- und Geopotentialprofile, erkennt Schichten mit mehr als 5/8 Bedeckung und stuft die Sicht innerhalb einer solchen Schicht konservativ als stark reduziert ein. Diese Korrektur fließt auch in die Höhenzonenbewertung ein.
- Neuer Regressionstest schützt Windwarnfarben, Niederschlagsintensitätsfarben, NHN-/Grundbezug und Wolkenschicht-Sichtprüfung.

# MID v0.8.8.1

- Szenariocluster: Temperaturdifferenzen gegenüber Referenzszenario A werden physikalisch korrekt in Kelvin (K) statt in Grad Celsius beziehungsweise mit Gradzeichen ausgewiesen.
- Absolute Temperaturwerte und Temperaturspannen bleiben weiterhin in Grad Celsius (°C).
- Neuer Regressionstest schützt die saubere Trennung zwischen absoluten Temperaturen in °C und Temperaturabweichungen in K.

# MID v0.8.8.0

- Berg-/Wintersport um einen kompakten Höhenwetter-Verlauf erweitert: Für Tal-, Mittel- und Bergzone werden Wetter, Temperatur, Sicht, Wolkenuntergrenze, Wind/Böen, Niederschlag und Schneefallgrenze im Tagesverlauf dargestellt. Die Auflösung ist zwischen 1 Stunde und 3 Stunden umschaltbar; die nächsten drei Tage lassen sich bei Bedarf aufklappen.
- Die bisherige einfache Bergprognose wurde durch die höhenzonierte Vergleichsmatrix ersetzt. Bei 3-Stunden-Auflösung werden Niederschlags- und Schneemengen je Intervall summiert; alle übrigen Parameter bleiben zeitpunktbezogen und kompakt vergleichbar.
- Saison- und Profilstatus im Bergmodul sprachlich und räumlich getrennt: Statt zusammengeschriebenem „WinterAutomatisch · hohe Sicherheit“ erscheint nun beispielsweise „Winter · Saison automatisch erkannt · Profil automatisch abgeleitet · hohe Sicherheit“.
- Szenariocluster vollständig neu visualisiert: Statt blauer Niederschlagssäulen zeigt jede Variante nun sieben Tageskarten mit Temperaturspanne, Niederschlagsmenge und Böenspitze. Ab Szenario B werden die konkreten Tagesabweichungen gegenüber Szenario A direkt ausgewiesen und farblich nach nasser, trockener, wärmer, kühler oder windiger unterschieden.
- Neuer Regressionstest schützt Höhenwetter-Matrix, Auflösungsumschalter, Drei-Tage-Erweiterung, Profilwording und den neuen siebentägigen Szenariovergleich.

# MID v0.8.7.4

- Berg-/Wintersport: Die Analyse nach Höhenzone bewertet nun ausschließlich das Tageslichtfenster von Sonnenaufgang bis Sonnenuntergang des laufenden Tages. Nach Sonnenuntergang wird automatisch der Folgetag ausgewertet und deutlich als „Morgen“ gekennzeichnet.
- Höhenzonenanalyse um einen gestuften Tagesverlauf erweitert: MID ermittelt stundenweise die günstigste Höhenzone und beschreibt relevante Wechsel, etwa eine günstigere Hochlage bis zum Nachmittag und anschließend bessere Bedingungen im Tal wegen Niederschlag, Sichtverschlechterung, Böen oder Gewitterrisiko.
- Gewitterpotenzial und UVI im Bergmodul werden nicht mehr aus dem gesamten 72-Stunden-Zeitraum gebildet, sondern nur aus dem tatsächlich bewerteten Tageslichtfenster. Ein erst übermorgen erwartetes Gewitter beeinflusst damit die heutige oder morgige Höhenzonenanalyse nicht mehr.
- Neuer Regressionstest schützt Tageslichtfenster, Folgetagswechsel, gestufte Höhenzonen und die tagesbezogene Gewitterauswertung.

# MID v0.8.7.3

- Desktop-Hovertext für die niedrigste Gewitterstufe sprachlich korrigiert: Statt „Gewitter: Einfaches Gewitter“ erscheint nun schlicht „Gewitter“.
- Höhere Gewitterstufen bleiben weiterhin als „Starkes Gewitter“, „Schweres Gewitter“ bzw. „Extremes Gewitter“ differenziert.
- Neuer Regressionstest schützt das Wording der niedrigsten Gewitterstufe.

# MID v0.8.7.2

- Szenariocluster sprachlich präzisiert: Die bisher unklare Bezeichnung „abweichende zeitliche Verteilung“ wurde entfernt. MID benennt nun konkret, worin die zeitliche Abweichung besteht, zum Beispiel „Niederschlagsschwerpunkt am Montag statt am Freitag“, „mehr Niederschlag am Sonntag“, „wärmer am Donnerstag“ oder „windiger am Samstag“.
- Die konkrete Beschreibung wird aus dem stärksten Unterschied der Tagesverläufe gegenüber dem führenden Szenario abgeleitet; identische generische Szenariobezeichnungen werden dadurch ebenfalls vermieden.
- Neuer Regressionstest schützt die konkrete parameter- und wochentagsbezogene Szenariobeschreibung.

# MID v0.8.7.1

- Ensemble-Szenariocluster transparenter gemacht: Für jede vertretene Modellfamilie zeigt MID nun, wie viele ihrer Mitglieder dem jeweiligen Szenario zugeordnet sind und welchem Anteil innerhalb dieser Modellfamilie das entspricht. Dadurch ist nachvollziehbar, warum beispielsweise ICON EPS Seamless gleichzeitig in mehreren Szenarien vorkommen kann.
- Szenariobezeichnungen nachgeschärft: Szenario B/C werden relativ zum führenden Szenario beschrieben; doppelte Beschriftungen wie mehrfach „nahe am Ensemble-Schwerpunkt“ werden vermieden.
- Divergenzerkennung robuster eingestellt: Der heutige, bereits teilweise abgelaufene Tag löst keine normale Trennung mehr aus. Eine markante Divergenz wird frühestens ab morgen bei mindestens zwei aufeinanderfolgenden auffälligen Tagen oder ausnahmsweise bei einer außergewöhnlich starken eintägigen Abweichung ausgewiesen. Temperatur, Tagesniederschlag und Böen fließen gemeinsam ein.
- Ensemblecache auf Generation v7 angehoben, damit ältere Szenariodaten ohne Modellfamilienanteile oder mit der früheren empfindlichen Divergenzlogik nicht weiterverwendet werden.
- Neuer Regressionstest schützt Modellfamilienanteile, eindeutige Szenariolabels und die robuste zukünftige Divergenzerkennung.

# MID v0.8.7.0

- „Lokaler Standortfingerabdruck“ in „Lokales Standortprofil“ umbenannt und als standardmäßig eingeklappte, persistente Detailsektion neu gestaltet. Im geschlossenen Zustand bleiben Geländeform, Exposition, Kaltluft-, Nebel- und Gewässereinfluss direkt ablesbar; zum Bearbeiten wird die Sektion wie bisher aufgeklappt.
- Vorbereitung für native Apple-Widgets und watchOS-Komplikationen ergänzt: stabiler Worker-Datenfeed `mid.native.widget.v1`, prüf- und kopierbare Feed-Adresse unter „Daten & Synchronisation“, kompakter 12-Stunden-/5-Tage-Datenvertrag sowie SF-Symbol-Zuordnung.
- Native WidgetKit-Grundstruktur für iOS, iPadOS und watchOS hinzugefügt, einschließlich Swift-`Codable`-Modell, `AppIntentTimelineProvider` und Vorlagen für Home-Screen-, Lock-Screen-, Smart-Stack- und Komplikationsfamilien.
- Neuer Regressionstest schützt Standortprofil-Zusammenfassung, Worker-Feed, Apple-Widgetfamilien und das native Startgerüst.

# MID v0.8.6.2

- Ensemble-Szenariocluster: Die sichtbaren Szenarioanteile werden nun gemeinsam nach dem größten-Rest-Verfahren gerundet und ergeben deshalb immer exakt 100 %. Einzelnes kaufmännisches Runden konnte zuvor wie im Screenshot 42 % + 39 % + 20 % = 101 % erzeugen.
- Die Prozentwerte werden vor der Rundung auf die tatsächlich dargestellten zwei oder drei Szenarien normalisiert; ausgeblendete statistische Restcluster verfälschen die sichtbare Summe damit nicht.
- Erklärung und Tooltip weisen jetzt ausdrücklich darauf hin, dass es sich um relative, gemeinsam gerundete Ensembleanteile und nicht um amtliche Eintrittswahrscheinlichkeiten handelt.
- Neuer funktionaler Regressionstest schützt die exakte 100-%-Summe auch bei Drittelverteilungen, Nullwerten und nicht ganzzahlig summierenden Rohanteilen.

# MID v0.8.6.1

- Open-Meteo-Upstream-Prüfung erweitert: Relevante, verifizierte Änderungen sollen künftig automatisch in den nächsten MID-Entwicklungsstand übernommen werden; unsichere oder inkompatible Änderungen bleiben bis zur fachlichen Verifikation unangetastet.
- Persönlicher Entscheidungszwilling wird im Rückblickmodul vollständig ausgeblendet, solange „Persönliche Empfehlungen“ in den Einstellungen deaktiviert ist. Die Aktivitätsbezeichnung „Draußenaktivität“ wurde appweit durch „Outdoor“ ersetzt.
- Direkte Datenübernahme von Netatmo, Standard-JSON und anderen privaten Wetterstationen bis auf Weiteres vollständig deaktiviert. Bestehende Konfigurationen bleiben für eine spätere Reaktivierung erhalten, werden aber weder abgefragt noch in „Aktuelles Wetter“ oder das Lernarchiv übernommen.
- Harte technische Sperren verhindern Stationsabrufe, OAuth-Starts und private Sensorarchivierung; bei deaktivierter Funktion wird auch kein periodischer Stations-Timer mehr gestartet.
- Neuer Regressionstest schützt bedingte Anzeige des Entscheidungszwillings, Outdoor-Wording und die vollständige Stationssperre.

# MID v0.8.6.0

- Lokale MID-Prognose erhält eine explizite Qualitätsfreigabe: Sie wird erst nach mindestens sechs abgeschlossenen Kontrolltagen, mindestens zwei Modellfamilien, zwei belastbaren aktuellen Prognosetagen und einem mindestens gleichwertigen Vergleich mit Open-Meteo Best Match als Hauptprognose zugelassen.
- Ist die Qualitätsfreigabe erreicht und die Hauptprognose noch nicht aktiviert, erscheint im Dashboard sowie im Modul „Prognosegüte und Rückblick“ ein direktes Aktivierungsangebot.
- Aktivierte lokale Prognosen werden eindeutig als „MID Wetterzwilling · lokal gewichteter Modellmix“ gekennzeichnet. Zusätzlich zeigt MID das führende Modell als Schwerpunkt mit seinem aktuellen Gewichtsanteil; Best Match bleibt ausdrücklich die unveränderte Kontrollgruppe.
- Eine vorzeitig in den Einstellungen aktivierte Hauptprognose wird nur vorgemerkt und erst nach der Qualitätsfreigabe tatsächlich angewendet.
- Neuer Regressionstest schützt Qualitätsfreigabe, Aktivierungsangebot, Modellmix-Kennzeichnung und den Best-Match-Kontrollschutz.

# MID v0.8.5.0

- Geräteübergreifende Synchronisation erweitert: Neben dem kompakten `localStorage`-Stand wird nun das vollständige Wetterzwilling-Langzeitarchiv aus IndexedDB mit sämtlichen Prognosesnapshots, Beobachtungen und Rückblicken exportiert, im Browser per AES-GCM verschlüsselt, in begrenzte Archivteile zerlegt und über den bestehenden Cloudflare-KV-Geräteverbund gesichert.
- Beim Abruf auf einem weiteren Gerät wird das vollständige Langzeitarchiv entschlüsselt und verlustfrei mit dem dortigen lokalen Archiv zusammengeführt. Kein Gerät überschreibt dabei ältere oder zusätzliche Lernfälle eines anderen Geräts; der zusammengeführte Stand wird anschließend wieder verschlüsselt gesichert.
- Der Synchronisationsstatus zeigt nun gesondert Zeitpunkt, Standortzahl und Datensatzumfang des vollständigen Wetterzwilling-Archivs. Manuelle Synchronisation umfasst Einstellungen und Langzeitarchiv; automatische Abgleiche übertragen das Archiv nur bei einem neueren Datenstand.
- Worker um atomare, segmentierte Archivablage mit Manifest, 180-Tage-Aufbewahrung und Bereinigung der vorherigen Archivgeneration erweitert. Es ist weiterhin kein zusätzliches Cloudflare-Binding erforderlich; das vorhandene `MID_PUSH_SUBSCRIPTIONS`-KV wird genutzt.
- Netatmo-Einrichtungsdiagnose verbessert: MID zeigt nun konkret an, welche Worker-Bindings oder Secrets fehlen, deaktiviert den OAuth-Start bis zur vollständigen Konfiguration und erläutert die notwendigen Schritte direkt im Einstellungsbereich.
- Neuer funktionaler Regressionstest schützt Vollarchiv-Export/-Import, verschlüsselte Segmentübertragung, Worker-Manifest, Abruf einzelner Archivteile und die Netatmo-Konfigurationsdiagnose.

# MID v0.8.4.0

- Lokaler Wetterzwilling lernt beim Öffnen beziehungsweise Wieder-Sichtbarwerden der App nun standardmäßig für sämtliche gespeicherten Favoriten und nicht mehr nur für den gerade angezeigten Standort. Die Favoriten werden ressourcenschonend nacheinander verarbeitet; identische Standorte werden entdoppelt, der aktive Ort wird nicht doppelt geladen und jeder Favorit wird höchstens einmal innerhalb von sechs Stunden erneut abgerufen.
- Für jeden fälligen Favoriten werden Best-Match- und Ensembleprognosen archiviert sowie abgeschlossene Rückblicke nachgeführt. Vorübergehende Fehler eines Ortes blockieren die übrige Warteschlange nicht; abgebrochene Läufe werden beim nächsten Öffnen erneut aufgenommen.
- Neuer Wetterzwilling-Schalter „Alle Favoriten beim Öffnen nachführen“ mit sichtbarem Laufstatus und Zeitstempel. Die Funktion ist standardmäßig aktiv, kann aber unabhängig vom eigentlichen Wetterzwilling deaktiviert werden.
- Einstellungsmenü neu geordnet: Ansicht, Farbdesign und Einheiten sind in „Ansicht & Einheiten“ gebündelt; „Lokaler Wetterzwilling“, „Daten & Synchronisation“ sowie „System & Updates“ besitzen eigenständige, intuitiv auffindbare Bereiche. Favoriten heißen nun „Favoriten & Profile“.
- Gerätespezifische Favoritenlauf- und Cooldown-Zustände sind von der Geräte-Synchronisation ausgeschlossen; die eigentlichen Prognosearchive und Lernprofile bleiben synchronisierbar.
- Neuer Regressionstest schützt das Favoritenlernen, die Drosselung, die getrennte Einstellungsnavigation und den Ausschluss technischer Laufzustände aus dem Geräteabgleich.

# MID v0.8.3.0

- Eigene vernetzte Wetterstationen reaktiviert und automatisierbar umgesetzt: Netatmo kann über den offiziellen OAuth-Zugriff mit reinem Stations-Leserecht verbunden, eine Station samt Außenmodul ausgewählt und regelmäßig in MID übernommen werden.
- Anbieterübergreifender Standard-JSON-Adapter ergänzt. Damit können unter anderem Home-Assistant-, Ecowitt-, WeatherLink- oder vergleichbare Bridges über einen HTTPS-Endpunkt Stationswerte an MID bereitstellen.
- Übernommene Eigenmessungen durchlaufen eine feldweise Plausibilitätsprüfung auf Alter, Standortdistanz, meteorologische Wertebereiche, Abweichung zur Referenzanalyse sowie Wind-/Böenkonsistenz. Unplausible Einzelfelder werden verworfen; plausible Werte bleiben nutzbar.
- Plausible Stationswerte ergänzen „Aktuelles Wetter“ und werden mit eigener Quellenkennzeichnung in das Lernarchiv des lokalen Wetterzwillings aufgenommen. Amtliche, analysierte und modellbasierte Referenzen bleiben getrennt nachvollziehbar.
- Netatmo-Zugriffstoken werden im Worker AES-GCM-verschlüsselt gespeichert; lokale Stationszugänge und Bearer-Token sind von der geräteübergreifenden Synchronisation ausgeschlossen.
- Neue Worker-Routen für OAuth-Start, Callback, Status, Beobachtungsabruf und Trennung sowie neuer funktionaler Regressionstest für Netatmo und Standard-JSON.

# MID v0.8.2.2

- Ensemble-Szenariocluster sprachlich korrigiert: Bei genau einer beteiligten Modellfamilie steht nun „1 Modellfamilie“, bei mehreren weiterhin „Modellfamilien“. Die gleiche Singular-/Plural-Logik gilt für die Zusammenfassung der aktiven Modellfamilien.
- Eigene Sensoren bis auf Weiteres vollständig deaktiviert: Eingabefelder und automatischer Abruf wurden aus dem Rückblickmodul entfernt; zusätzlich blockiert der Lernkern sowohl manuelle als auch automatische private Sensorübernahmen. Die Implementierung bleibt stillgelegt für eine spätere belastbare Automatisierung erhalten.
- KPI zur Regenwahrscheinlichkeit eindeutig umbenannt: „Güte der Regenwahrscheinlichkeit“ bezeichnet nun ausdrücklich die historische Kalibrierungsqualität der Best-Match-Wahrscheinlichkeiten und nicht die aktuelle Regenwahrscheinlichkeit. Der zugehörige Brier-Score wird direkt angezeigt und erläutert.
- Neuer Regressionstest schützt Modellfamilien-Wording, die technische Sensor-Deaktivierung und die eindeutige Regenwahrscheinlichkeits-KPI.

# MID v0.8.2.1

- Release-Paketierung korrigiert: Das vorherige ZIP war inkrementell aktualisiert worden und enthielt dadurch neben dem aktuellen Regressionstest noch die veraltete Datei `test-scenario-settings-regime-0820.mjs` sowie ältere Quellstände. GitHub führte deshalb 108 statt 107 Tests aus; der obsolete Test schlug erwartungsgemäß fehl.
- Das Professional-Replacement wird nun als vollständig neu erzeugtes Archiv ausgegeben. Gelöschte oder umbenannte Dateien können damit nicht mehr aus einer Vorgängerversion im ZIP verbleiben.
- Neuer Regressionstest schützt die Release-Sauberkeit und erkennt den veralteten Szenario-/Regime-Test ausdrücklich. Die funktionalen Korrekturen aus v0.8.2.0 zu Szenarioclustern, Dauerregenklassifikation und zentralen Wetterzwilling-Einstellungen bleiben vollständig erhalten.

# MID v0.8.2.0

- Ensemble-Szenariocluster fachlich und visuell überarbeitet: Die führende Karte verwendet keine globale Primärbutton-Klasse mehr, wodurch alle Texte auch im hellen Design lesbar bleiben. Temperaturspanne, Fünf-Tage-Niederschlag und Böenspitze werden nun getrennt ausgewiesen; die Balken sind ausdrücklich als Tagesniederschlag beschriftet.
- Isolierte, statistisch unplausible Niederschlagsausreißer einzelner Ensemblefamilien werden mit einer robusten Median-/MAD-Prüfung vor der Szenarioclusterung entfernt. Der Ensemblecache wurde deshalb auf Generation v6 angehoben.
- Wetterlagenklassifikation korrigiert: Eine Tagesmenge von 5 mm führt nicht mehr pauschal zur „Dauerregenlage“. Dauerregen erfordert nun eine mindestens sechsstündige zusammenhängende Regenphase mit relevanter Menge oder eine DWD-nahe hohe Tagesmenge; Stundenverläufe werden beim Prognosearchiv und aktuellen Rückblick berücksichtigt. Alte gespeicherte Referenzklassifikationen werden neu bewertet.
- Globale Wetterzwilling-Schalter für Hauptprognose, Nowcast-Assimilation, Bias-Korrektur, Wahrscheinlichkeitskalibrierung und persönliche Empfehlungen wurden zentral unter Einstellungen → MID-System zusammengeführt. Das Rückblicksmodul zeigt nur noch den Betriebsstatus; standortbezogene Profile und Aktivitätsprofile bleiben dort editierbar.
- Neuer Regressionstest schützt Szenarioplausibilität, Kennwertdarstellung, Dauerregenklassifikation und die zentrale Einstellungsstruktur.

# MID v0.8.1.0

- Starre 58-%-Grenze der lokalen Modellgewichtung durch eine adaptive, vertrauensabhängige Obergrenze ersetzt. Die zulässige Dominanz eines Modells richtet sich nun nach globaler und wetterlagen-/horizontspezifischer Stichprobe sowie dem echten Kontrollvergleich von „MID lokal gewichtet“ gegen Best Match.
- Adaptive Schutzstaffel eingeführt: in früher Lernphase typischerweise 48–54 %, bei wachsender Evidenz 56–62 % und nur bei ausreichend belegter, nachgewiesener Verbesserung maximal 65 %. Bei negativer Kontrollgüte wird die Grenze automatisch wieder abgesenkt.
- Parametergewichte für Temperatur, Niederschlag, Wahrscheinlichkeit, Böen und Sonnenschein erhalten zusätzlich eigene, von der jeweiligen Stichprobe abhängige Obergrenzen. Die aktuell wirksame Grenze, Vertrauensstufe und Kontrollgüte werden in der Prognoseerklärung ausgewiesen.
- Standortfingerabdruck grundlegend verbessert: MID kombiniert Orts-/POI-Metadaten mit einem 17-Punkte-DEM-Höhenprofil im 10-km-Umfeld und leitet daraus Geländeform, Exposition, Kaltluftsenken-, Nebel- und Gewässereinfluss ab.
- Die Vorauswahl bleibt vollständig editierbar. Ein neuer Schalter „Neu ableiten“ beziehungsweise „Automatik wiederherstellen“ verwirft bei Bedarf manuelle Änderungen und berechnet das Profil erneut. Die Ableitungsgründe sowie DEM-Relief und relative Höhenlage werden transparent angezeigt.
- Neuer Regressionstest schützt adaptive Gewichtsobergrenzen, Kontrollgruppenbezug, parameterbezogene Grenzen, DEM-/Metadatenableitung und die editierbare Rückkehr zur Automatik.

# MID v0.8.0.1

- Umfassendes Audit sämtlicher mit v0.8.0 eingeführter Wetterzwilling-Funktionen durchgeführt und dabei Einheiten-, Herkunfts-, Zeit- und Archivfehler korrigiert.
- Räumliche Umfeldanalyse korrigiert: Stationsentfernungen werden zuverlässig von Metern in Kilometer umgerechnet; bereits gespeicherte fehlerhafte v0.8.0-Werte werden automatisch migriert. Unrealistische Entfernungen werden nicht mehr als reguläre Referenz angezeigt.
- Echozugdarstellung abgesichert: Eine Richtung von 0° wird nur noch bei tatsächlich belastbarer Bewegung ausgegeben; sonst erscheint ein klarer Hinweis. Qualitätsstufen werden vollständig deutsch dargestellt.
- Beobachtungswahrheit bereinigt: Stations-, Radar- und Modellwerte bleiben getrennte Quellen; Radar und Station werden bei der Tagesmenge nicht mehr doppelt gezählt. Hyperlokale Restfeld- und Stationsmittelanalysen werden korrekt als analysiert statt als direkt gemessen gekennzeichnet.
- Zeitzonen- und Tagesgrenzen korrigiert: Prognosehorizonte, Tagesabschluss, Sensorwerte, Rückblicke und persönliche Zeitfenster verwenden nun konsequent die Zeitzone des Standorts.
- Prognosearchiv robuster gemacht: IndexedDB und lokaler Speicher werden verlustfrei zusammengeführt, Schreibvorgänge serialisiert und ältere fehlerhafte Archivdaten migriert.
- Lernlogik gegen Scheingenauigkeit abgesichert: Mindestzahl unabhängiger Tage, gedeckelte Modellgewichte, getrennte Parameterfreigaben und keine vorzeitige Ausweisung eines Modellsiegers.
- Ensemble-Szenarien widerstandsfähiger gemacht: optionale Böen-/Sonnenscheinfelder können fehlen, ohne ganze Modelle oder Cluster unbrauchbar zu machen; entsprechende API-Abfragen besitzen einen reduzierten Fallback.
- Berg-/Wintersportanalyse nach Höhenzone gegen fehlende Werte und NaN-Scores abgesichert; Zeitfenster enden nun am Ende der letzten ausgewerteten Stunde.
- Hintergrundlernen vervollständigt: Archivwiederherstellung und Rückblicksaktualisierung funktionieren auch, wenn das Prognosegüte-Modul nicht geöffnet wird.
- Neuer Wetterzwilling-Audit-Test schützt Einheiten, Quellenherkunft, Zeitzonen, Lernfreigaben, Assimilation, Szenarien und Höhenzonen.

# MID v0.8.0

- Lokaler Wetterzwilling Stufe 1 – Wahrheits-, Standort- und Archivkern: Unveränderliche Prognosesnapshots, unabhängige Beobachtungshierarchie aus Messung, Radar/Analyse, ERA5-Land-Reanalyse und gekennzeichnetem Modell-Fallback; Quellenqualität, Vertrauen und Abdeckung werden mitgeführt. Langzeitspiegel in IndexedDB und Migration bestehender Rückblicksdaten ergänzt.
- Dauerhafter Standortfingerabdruck je Favorit mit Geländeform, Exposition, Kaltluft-, Nebel- und Gewässereinfluss. Eine räumliche Umfeldanalyse macht Stationsdistanz, Echozugrichtung und Standortwirkung sichtbar.
- Wetterzwilling-Archive und Profile bleiben über die vorhandene verschlüsselte Gerätesynchronisation übertragbar.
- Lokaler Wetterzwilling Stufe 2 – Lernkern: Prognosegüte getrennt nach Temperatur, Niederschlag, Regenwahrscheinlichkeit, Böen und Sonnenschein sowie nach Wetterlage und +12/+24/+48/+72 Stunden. Lokale Bias-Korrektur, Brier-Score, Wahrscheinlichkeitskalibrierung, Regularisierung, Mindeststichproben und Vertrauensstufen schützen vor Überanpassung.
- Kontrollgruppen integriert: Open-Meteo Best Match, einfaches Multimodellmittel und MID lokal gewichtet werden parallel archiviert und nachträglich objektiv verglichen. Modellgewichte werden je Parameter, Wetterlage und Horizont berechnet und begrenzt.
- Lokaler Wetterzwilling Stufe 3 – aktiver Zwilling: Die lokal gelernte Vorhersage ist in den Einstellungen als Hauptprognose aktivierbar. Ohne ausreichende Datenbasis bleibt unverändert Best Match aktiv. Für die ersten Stunden können Radar-/Nowcast-Signale nachvollziehbar assimiliert werden; Rohprognosen bleiben unverändert im Archiv.
- Lokaler Wetterzwilling Stufe 4 – persönlicher Entscheidungszwilling: Aktivitätsprofile für Arbeitsweg, Draußenaktivitäten, Garten, Rudern, Hundespaziergang, Berg-/Wintersport und Hitzeschutz. MID ermittelt geeignete Zeitfenster, nennt Auswirkungen und Unsicherheit und lernt über hilfreiche/nicht passende Rückmeldungen.
- Ensemble-Datenbasis für den Lernkern um Böen und Sonnenscheindauer erweitert. Neue Regression schützt sämtliche vier Wetterzwilling-Stufen und die aktive App-Integration.

# MID v0.7.111.1

- GitHub-Produktionsbuild repariert: Zwei durch die neuen Lern-/Szenariofunktionen verbliebene, ungenutzte Funktionsparameter wurden entfernt. Dadurch bestehen `noUnusedLocals` und `noUnusedParameters` wieder ohne TS6133-Abbruch.
- `currentWeightedForecasts` erhält nur noch die tatsächlich verwendeten Prognose-, Ensemble- und Auswertungsdaten; die Funktionalität der lokal gewichteten Prognose bleibt unverändert.
- Die Ermittlung des ersten Szenario-Divergenztags verwendet keinen ungenutzten Datumsparameter mehr; Ensemble-Szenariocluster bleiben unverändert.
- Zusätzliche Compilerprüfung über sämtliche TS-/TSX-Quelldateien bestätigt: keine verbliebenen TS6133-/TS6192-/TS6196-Diagnosen.

# MID v0.7.111.0

- Prognosegüte zum lokalen Lernsystem ausgebaut: Modellfehler werden getrennt nach Wetterlage sowie +12-, +24-, +48- und +72-Stunden-Horizont bewertet. Die Rückblicksreferenz wurde um Wettercode, Böen und Sonnenscheindauer erweitert, um Hochdruck-, Schauer-, Dauerregen-, Gewitter-, Sturm- und winterliche Lagen zu unterscheiden.
- Lokal lernende Modellgewichtung umgesetzt: Gewichte werden aus historischen Fehlern je Wetterlage und Vorhersagehorizont mit globaler Regularisierung, Mindeststichprobe und Gewichtsobergrenze abgeleitet. MID speichert die daraus erzeugte Prognose als eigenen Vergleich und weist die nachträglich gemessene Verbesserung oder Verschlechterung gegenüber Open-Meteo Best Match aus.
- Ensemble-Szenariocluster ergänzt: vollständige Ensemble-Mitglieder werden über bis zu sieben Tage nach Temperatur- und Niederschlagsverlauf gruppiert. MID zeigt zwei bis drei gewichtete Szenarien mit Anteil, beteiligten Modellfamilien, Verlaufszusammenfassung und dem ersten markanten Divergenztag.
- Berg-/Wintersportanalyse nach Höhenzone ergänzt: Für Tal-, Mittel- und Bergzone werden die nächsten Stunden anhand von Temperatur, Wet-Bulb-Temperatur, Sicht, Niederschlag, Gewitterpotenzial und Böen bewertet. MID nennt die günstigste Höhenzone, das beste Zeitfenster, Schneequalität und relevante Einschränkungen.
- Bestehende Prognosearchive der v1-Struktur werden verlustarm in das erweiterte v2-Archiv migriert; die Daten bleiben über die vorhandene verschlüsselte Gerätesynchronisation übertragbar.
- Neuer Regressionstest schützt Lerngewichtung, Wetterlagen-/Horizontbewertung, Szenariocluster, Höhenzonenanalyse und deren App-/UI-Verdrahtung.

# MID v0.7.110.0

- Modelllauf-Änderungsradar auf die nächsten drei Tage fokussiert. Jede erkannte Änderung nennt nun ausdrücklich die betroffene Best-Match- oder Ensemble-Modellfamilie; auch die serverseitige Push-Prüfung verwendet dasselbe Drei-Tage-Fenster.
- Optionale geräteübergreifende Synchronisation in den Systemeinstellungen ergänzt. Favoriten, Darstellungsoptionen, Spezialprofile und Auswertungsverläufe werden vor dem Upload im Browser mit AES-GCM verschlüsselt und über einen persönlichen Synchronisationscode zwischen MID-Geräten abgeglichen.
- Routenwetter vorläufig aus Dashboard, Einstellungen und aktiver Laufzeit entfernt. Die Quellmodule bleiben ausschließlich als stillgelegte Basis für eine spätere Reaktivierung erhalten.
- Im erweiterten Modus das neue Modul „Prognosegüte und Rückblick“ ergänzt. MID archiviert Prognosestände für die nächsten drei Tage, vergleicht abgeschlossene Tage bevorzugt mit der nachträglichen ERA5-Land-Reanalyse und verwendet für noch nicht verfügbare Tage einen klar gekennzeichneten Best-Match-Rückblick als vorläufige Referenz. Daraus werden Temperaturfehler, Niederschlagsfehler, Brier-Score, lokale Modellrangfolge, tagesbezogene Sieger sowie vorläufige Lerngewichte berechnet.
- Gerätesynchronisation im Worker ergänzt und der bestehende KV-Speicher wiederverwendet; es sind keine neuen Bindings erforderlich, sofern MID_PUSH_SUBSCRIPTIONS bereits für Push eingerichtet ist.
- Neue Regression schützt Drei-Tage-Fenster, Modellangaben, verschlüsselte Gerätesynchronisation, Routenwetter-Stilllegung und Prognosegüte.

# MID v0.7.109.2

- Kompositbild: Für KONRAD3D-Zellen wird im K3D-/NowCastMIX-Layer nun zusätzlich ein Wahrscheinlichkeitskegel der Zugbahn gerendert. Der Kegel nutzt die verfügbare Prognoseposition und den Unsicherheitsradius und macht die erwartete Verlagerung wieder direkt auf der Karte sichtbar.
- Die Zellprognose selbst wird im Overlay wieder klar visualisiert: gestrichelte Prognoselinie, markierter Prognosepunkt sowie ein eigener Overlay-Pane sorgen dafür, dass die Darstellung auch über Radar- und Satellitenlayern sichtbar bleibt.
- Die Legende des Kompositbilds wurde passend ergänzt und erläutert nun sowohl die Zellprognose als auch den Wahrscheinlichkeitskegel.
- Neuer Regressionstest schützt Wahrscheinlichkeitskegel, Prognosepunkt, Overlay-Pane und Legendenhinweis.

# MID v0.7.109.1

- Tagesdetaildiagramm im Tablet-Hochformat verbessert: Alle stündlichen Wetterpiktogramme und Windrichtungspfeile bleiben sichtbar.
- Wetterpiktogramme und Richtungspfeile werden im Tablet-Hochformat abhängig vom verfügbaren Stundenabstand kompakter skaliert, damit sich die 24 Stunden nicht überdecken.
- Querformat- und Smartphone-Verhalten bleiben unverändert; ein neuer Regressionstest schützt den zusätzlichen Tablet-Hochformatmodus.

# MID v0.7.109.0

- Dezenter, einmaliger Hinweis zur Nutzung als Web-App ergänzt. Der Hinweis kann über das X dauerhaft geschlossen werden; die Auswahl wird lokal gespeichert und erscheint bei späteren Neustarts nicht erneut.
- PWA-Status aus dem Footer in die Kopfzeile verlagert: links neben Einstellungen steht nun ein kleines „App“-Feld; bei installierter MID-App wird es kompakt als installiert markiert. Die vollständigen Installationshinweise bleiben über dieses Feld erreichbar.
- 7-Tage-Trend als belastbarer Standard abgesichert: Ohne gespeicherte Präferenz ist er nach jedem Neustart aktiv; nur eine ausdrücklich gespeicherte Deaktivierung hält ihn ausgeschaltet.
- Neue Regressionstests schützen die persistente Hinweis-Ausblendung, den kompakten Kopfzeilenstatus und die Standardaktivierung des 7-Tage-Trends.

# MID v0.7.108.3

- Aktuelles Wetter mobil: Die kompakte Tmin-/Tmax-Pille besitzt nun eine feste geringe Höhe; Beschriftungen, Trennpunkt und Temperaturwerte sind vertikal sauber zentriert.
- Kompositbild: Isobaren und 500-hPa-Isohypsen werden unabhängig vom globalen Leaflet-Canvasmodus über einen eigenen SVG-Renderer im Modelllinien-Pane gezeichnet. Linienkontrast, Strichstärke und Halo wurden erhöht, damit vollständige Konturen über Radar- und Satellitenflächen sichtbar bleiben.
- Mobile Komposit-Overlays neu angeordnet: Das Feld „Scrollen“ steht links oberhalb des Kartenfußes und kollidiert nicht mehr mit dem rechts unten liegenden, verkleinerten „Jetzt“-Overlay.
- Neuer Regressionstest schützt mobile Tmin/Tmax-Zentrierung, explizite SVG-Modellkonturen und die kollisionsfreie Overlay-Anordnung.

# MID v0.7.108.2

- Ensemble-Temperaturdiagramm: Achsentitel analog zum Niederschlagsdiagramm aus der Recharts-SVG-Fläche herausgelöst. „Temperatur“/„°C“ und „Vorhersagetag“ besitzen nun reservierte Layoutbereiche und bleiben auf Desktop, Mobilgeräten sowie im PNG-Export lesbar.
- Temperatur-Exportgeometrie angepasst: Der feste 1096-px-Bereich enthält einen 1000-px-Diagrammkern mit getrennten Achsentitel- und Ausgleichsspalten; dadurch bleiben Plot und Achsenticks sauber ausgerichtet.
- Aktuelles Wetter mobil: Tmin/Tmax wird als kleine, dezente Pille am oberen Modulrand dargestellt und aus dem normalen Gridfluss genommen. Dadurch entsteht keine zusätzliche breite Hero-Zeile und kein unnötiger Höhenbedarf.
- Neue bzw. angepasste Regressionstests schützen die externen Temperatur-Achsentitel, die feste Exportgeometrie und die platzsparende mobile Tmin-/Tmax-Anzeige.

# MID v0.7.108.1

- Ensemble-Niederschlagsdiagramm: Achsentitel aus der Recharts-SVG-Fläche herausgelöst und als eigenständige, reservierte Layoutbereiche umgesetzt. Dadurch können „Niederschlag“, „Wahrscheinlichkeit“ und „Vorhersagetag“ weder von Achsenticks noch vom Teilen-/Infobereich überlagert oder abgeschnitten werden.
- Responsive Darstellung angepasst: Auf Desktop stehen die beiden y-Achsentitel in festen seitlichen Spalten; auf schmalen Mobilgeräten wechseln sie in eine kompakte horizontale Kopfzeile über dem Plot.
- Exportgeometrie erweitert: Der 1096-px-Exportbereich wird in feste Achsentitelspalten und einen 992-px-Diagrammkern aufgeteilt, sodass die Titel auch in mobil erzeugten PNGs korrekt positioniert bleiben.
- Neuer Regressionstest schützt Desktop-, Mobil- und Exportposition der Niederschlagsachsen; bestehender Test für die feste Ensemble-Exportgeometrie wurde auf den variablen Diagrammkern erweitert.

# MID v0.7.108.0

- Aktuelles Wetter: Tmin/Tmax aus der frei schwebenden Kicker-Zeile entfernt und als eigener, sauber begrenzter Grid-Bereich zwischen Wettertext und Analysekarte angeordnet. Die Darstellung folgt auf Desktop, Tablet und Mobil nun festen Modulgrenzen.
- Wind-/Böen-Kachel: Wert und Einheit werden als zusammenhängende, responsive Zeile dargestellt; ein unschöner Umbruch innerhalb der Böeneinheit wird verhindert.
- 7-Tage-Trend: Rechtschreibung der Hazard-Sätze korrigiert. Substantive wie „Sturmböen“ bleiben großgeschrieben; nur tatsächlich vorangestellte Adjektive werden im Satzkontext kleingeschrieben.
- Berg-/Wintersport: dezenter, direkt bedienbarer Saisonumschalter Auto/Sommer/Winter im Anzeigebereich ergänzt und dauerhaft im zugehörigen Favoritenprofil gespeichert.
- Wassersport: Gewässertyp und Aktivität als kompakte Direktoptionen in den Anzeigebereich aufgenommen; Änderungen werden ebenfalls dauerhaft im Favoritenprofil gespeichert.
- Neuer Regressionstest schützt Hero-Raster, Windumbruch, Trend-Rechtschreibung und die persistenten Direktoptionen beider Spezialmodule.

# MID v0.7.107.0

- Grundlegendes Performance-Audit ohne Funktionsabbau: Ensemble-Aufrufe nutzen nun einen 20-minütigen Frischcache, Open-Meteo-Modellabfragen werden regional priorisiert und doppelte globale ECMWF-Abfragen in Europa vermieden.
- Kompositdarstellung entlastet: Statt mehrerer gleichzeitig überblendeter Konturframes wird nur der zeitlich maßgebliche Frame gerendert; vorberechnete Konturgeometrien, wiederverwendete Datumsformatierer und verzögertes Speichern der Kartenoptionen reduzieren Rechen-, DOM- und Speicherlast.
- Isobaren und 500-hPa-Isohypsen wieder deutlich sichtbar: eigener Leaflet-Layer oberhalb der Wetterebenen, kontrastreiche Doppelkontur mit dunklem Halo, stärkere Hauptlinien und besser lesbare Beschriftungen sowie Druckzentren.
- Open-Meteo-Modellbestand aktualisiert: regionale ECMWF-IFS- und AIFS-Ensembles für Europa einschließlich offizieller Ensemble-Mittel integriert und gegenüber redundanten globalen Varianten bevorzugt.
- Abrufstrategie an die Open-Meteo-Aktualisierung angepasst: Konturdaten werden client- und worker-seitig 30 Minuten zwischengespeichert, im sichtbaren Modul stündlich geprüft und bei kurzzeitigen Abruffehlern nicht mehr sofort aus der Karte entfernt.
- Neuer Regressionstest schützt die Performanceoptimierungen, aktuellen Open-Meteo-Modellkennungen sowie die sichtbaren Isobaren/Isohypsen. Insgesamt 93 automatische MID-Regressionstests bestanden.

# MID v0.7.106.3

- Berg-/Wintersport-Favoriten robuster gespeichert: automatisch ermittelte Lift-/Stationsprofile werden synchron sowohl im Favoritenbestand als auch separat je Standort gesichert und unmittelbar in die persistente IndexedDB-/Cache-Sicherung übernommen.
- Automatische Lift-/Stationssuche erhält einen zweiten Abrufdurchlauf. Bei einem vorübergehenden Dienstfehler bleibt ein bereits erfolgreich ermitteltes automatisches Profil erhalten, statt durch abgeleitete Standardwerte überschrieben zu werden.
- Wind- und Schneedeckendaten in den Höhenkacheln räumlich getrennt und als eigenständige Informationsblöcke beschriftet.
- Desktopdarstellung von Tmin/Tmax im aktuellen Wetter zu einer größeren, klar gegliederten Tagesbereichskarte mit Temperaturverlauf aufgewertet; mobile Darstellung bleibt kompakt.
- Neuer Regressionstest schützt Bergprofil-Persistenz, Abruffallback, getrennte Wind-/Schneedaten und die überarbeitete Desktop-Tagesbereichsanzeige.

# MID v0.7.106.2

- Ensemble-PNG-Export grundlegend stabilisiert: Während des Exports werden Temperatur- und Niederschlagsdiagramm nicht mehr nachträglich über einen bereits gerenderten responsiven Recharts-Container verbreitert, sondern in einer festen, geräteunabhängigen Plot-Geometrie neu gerendert.
- Ursache der fehlerhaften Exporte beseitigt: Beim Wechsel von der Bildschirmbreite auf 1180 px konnten Achsen bereits die neue Breite verwenden, während Kurven, Flächen oder deren Clip-Pfad noch auf der alten Mobil- bzw. Desktopbreite beruhten. Das führte mobil zur Stauchung/Abschneidung und am Desktop zum Überlaufen rechts über den Achsenbereich.
- Exportmodus nutzt nun einen festen 1096-px-Plot, Desktop-Achsenabstände unabhängig vom Geräte-Viewport, einen expliziten Export-Renderzustand und wartet auf den tatsächlich neu aufgebauten Recharts-Wrapper.
- Recharts-Animationen für die statischen Ensemblekurven und -flächen deaktiviert, damit während der PNG-Aufnahme keine Zwischengeometrie oder unvollständiger Clip-Pfad erfasst wird.
- Exportbereich wird streng beschnitten; Metadaten bleiben wie gewünscht als Fußnote unter dem Diagramm. Neuer Regressionstest schützt die feste Desktop-/Mobil-Geometrie, animationsfreie Aufnahme und den vollständigen Plotbereich.

# MID v0.7.106.1

- Tagesdetaildiagramm: Ursache für Windwerte oberhalb der Böen eingegrenzt. MID verwendet Wind und Böen aus demselben Open-Meteo-Best-Match-Abruf, in identischer Einheit und am identischen Stundenindex; bekannte Modell-/Interpolationskonstellationen können dennoch `wind_gusts_10m < wind_speed_10m` liefern.
- Plausibilitätsbehandlung angepasst: Der Windwert bleibt unverändert. Eine fehlende oder kleinere Böe wird ausschließlich punktweise für denselben Zeitpunkt auf das Windniveau gesetzt – ohne zeitliche Glättung, Mittelwertbildung oder Veränderung benachbarter Stunden.
- Wind- und Böenlinie bleiben im Diagramm erhalten. Bei identischen Werten bleibt die grüne Windlinie durch die Lücken der gestrichelten Böenlinie sichtbar; der Stunden-Tooltip kennzeichnet eine vorgenommene Angleichung.
- Neue Regression schützt die punktweise Angleichung, die endlichen Diagrammwerte und die Sichtbarkeit beider Kurven.

# MID v0.7.106.0

- 7-Tage-Trend fachlich neu gewichtet: Die ersten Prognosetage erhalten deutlich mehr Einfluss als das Ende des Zeitraums; kurze spätere Ausreißer verdrängen damit nicht mehr den unmittelbar bevorstehenden Wettercharakter.
- Wetterverlauf differenzierter ausgewertet: heiter/sonnig, Sonne und Wolken, stark bzw. meist bewölkt, regnerisch, gewittrig und winterlich werden als eigene zeitliche Regime behandelt. Bewölkungstexte haben Vorrang vor einer isoliert hohen Sonnenscheindauer; die Sonnenscheindauer wird zusätzlich relativ zur astronomischen Tageslänge bewertet.
- Temperaturbeschreibung an DWD-Kenntage angelehnt: Sommertag ab 25 °C, heißer Tag ab 30 °C, sehr heiß ab 35 °C, extrem heiß ab 40 °C, Tropennacht ab 20 °C Mindesttemperatur sowie Eistag bei einem Tagesmaximum unter 0 °C. Verfügbare ERA5-Land-Klimamittel 1991–2020 fließen für markante Abweichungen vom örtlichen Klimamittel ein.
- Markante automatische DWD-nahe Warnsignale werden priorisiert in den Kurztrend aufgenommen; dafür bleibt bei einem Hazard stets Platz im maximal dreisätzigen Text.
- Klimamittel werden nun bereits für die aktivierte 7-Tage-Kurzinterpretation geladen und nicht erst nach dem Öffnen des Ensemble-Moduls.
- Quellengetreue Wind-/Böenbehandlung nachgezogen: keine Glättung und keine künstliche Anhebung der Böe mehr. Ist ein Böenwert kleiner als der zugehörige Wind, wird er als unplausibel behandelt und als nicht verfügbar dargestellt.
- Neue und angepasste Regressionstests schützen Frühgewichtung, DWD-Kenntage, Klimavergleich, Hazard-Priorität, Bewölkungsverlauf und die unverfälschte Wind-/Böenprüfung.

# MID v0.7.105.5

- Exportdarstellung der Ensemble-Diagramme stabilisiert: Temperatur- und Niederschlagsgrafiken erhalten ausgewogenere Außenabstände, damit Achsen und Kurven in Desktop- und Mobil-Exports nicht mehr nach rechts verrutschen.
- Export-Metadaten neu angeordnet: „Darstellung“, „Quellen“, „Modellstände“ und „MID“ stehen nun als Fußnote unter dem Diagramm statt oberhalb der Grafik.
- Neuer Regressionstest schützt die Fußnotenposition und die exportstabilen Diagrammmargen; der bestehende Interaktionstest akzeptiert die angepassten Außenmaße.

# MID v0.7.105.4

- Bergmodul sprachlich auf „Berg-/Wintersport“ umgestellt und die Kachelstruktur saisonal aufgewertet: UVI erscheint wieder als eigenständige Kachel; zusätzlich zeigt der Sommermodus das Gewitterpotenzial und der Wintermodus den prognostizierten Neuschnee +24 h.
- Bergindikatoren layoutseitig flexibilisiert, damit die zusätzlichen saisonalen Kacheln auf Desktop und Mobil sauber umbrechen.
- Wind- und Böenwerte appweit für Stunden- und Tagesmapping sowie in den aktuellen und bergbezogenen Anzeigen geglättet: Böen werden nun niemals kleiner als der zugehörige Wind dargestellt.
- Neuer Regressionstest schützt Berg-/Wintersport-Kacheln und die Wind/Böen-Normalisierung; bestehender Wind-Test wurde auf die normalisierte Darstellung erweitert.

# MID v0.7.105.3

- Kachel „Luftqualität“ gestalterisch an die übrigen Aktuell-Wetter-Kacheln angenähert: Die große Primärschrift ist kompakter, EU-AQI steht nun in der Überschrift und die doppelte Wiederholung der Einstufung entfällt.
- AQI-Kachel inhaltlich gestrafft: Primärwert zeigt nur noch die Stufe, die Detailzeile nennt kompakt den maßgeblichen Stoff mit Konzentration und Quelle.
- Neuer Regressionstest schützt die kompaktere AQI-Kachel mit EU-AQI in der Überschrift und ohne doppelte Statusanzeige.

# MID v0.7.105.2

- Desktop-Darstellung der 7-Tage-Vorhersage überarbeitet: Die Temperaturbalken erhalten auf Desktop etwas kompaktere Spalten, damit Niederschlags-, Sonnen- und Windtext nicht mehr von den Temperaturwerten überdeckt wird.
- Die Forecast-Zeile verteilt den verfügbaren Platz auf Desktop nun textfreundlicher; auf mittleren Desktopbreiten darf die Metazeile bei Bedarf umbrechen, auf großen Desktopbreiten bleibt sie weiterhin einzeilig.
- Neuer Regressionstest schützt das Desktop-Layout der 7-Tage-Vorhersage mit schmaleren Temperaturbalken und den angepassten Spaltenbreiten.

# MID v0.7.105.1

- Radar-Nowcast: Die Niederschlagssumme für die nächsten zwei Stunden wird nun konsistent aus allen künftig sichtbaren 5-Minuten-Segmenten der Diagrammleiste gebildet. Dadurch erscheinen heranziehende bzw. unsichere Treffer nicht mehr mit Balken, aber gleichzeitig mit 0,00 mm in der Summenzeile.
- 7-Tage-Kurzinterpretation sprachlich und meteorologisch verfeinert: Der Text wertet jetzt den tatsächlich dargestellten Tagescharakter gröber aus, vermeidet doppelte Formulierungen wie „wechselhaft, danach wechselhaft“ und beginnt am aktuellen ersten Tag natürlich mit „Heute“ statt „bis Montag“.
- Neue Regressionstests schützen die korrigierte Radar-Summenlogik sowie die verbesserte deutsche Satzbildung der 7-Tage-Kurzinterpretation.

# MID v0.7.105.0

- Neue, standardmäßig aktive 7-Tage-Kurzinterpretation vor dem ersten Prognosetag. Zusammenhängende Wetterphasen werden zu einem möglichst kurzen deutschen Satz verdichtet, etwa „Bis Dienstag wechselhaft, ab Mittwoch sonnig, trocken und heiß.“
- Eigener Schalter unter Einstellungen → Ansicht zum vollständigen Deaktivieren der Kurzinterpretation; Auswahl wird dauerhaft lokal gespeichert.
- Tagesdetaildiagramm erkennt zusätzlich sämtliche Querformat-Displays und zeigt dort sämtliche stündlichen Wetterpiktogramme sowie alle Windrichtungspfeile.
- Piktogramme und Richtungspfeile werden abhängig vom verfügbaren Punktabstand dynamisch verkleinert, statt Zeitpunkte auszudünnen.
- Neuer Regressionstest schützt Einstellungs-Persistenz, Position vor dem ersten Prognosetag, phasenbasierte Kurzinterpretation sowie vollständige Hoch- und Querformatmarker.

# MID v0.7.104.0

- Radar-Nowcast als durchgehend horizontal erkundbarer 5-Minuten-Scrubber umgesetzt: Fingerbewegung nach links/rechts aktualisiert den MID-typischen Portal-Tooltip am jeweils berührten Zeitschritt; Außenklick, erneutes Antippen und Escape schließen ihn.
- 5-Minuten-Mengen fachlich korrigiert: Standortwert und Umgebungsecho werden getrennt; ein stärkeres Echo im Suchumfeld ersetzt nicht mehr den tatsächlichen Standortwert. Unsichere Prognoseersatzwerte werden begrenzt und transparent gekennzeichnet.
- +2-h-Niederschlagssumme deutlich zurückgenommen und nur aus zukünftigen Standorttreffern gebildet; Umgebungsechos fließen nicht in die Standortsumme ein.
- Radar-Analyse auf einen progressiven Schnellpfad umgestellt: zuerst wenige WMS-Punktwerte ohne aufwendige Bewegungsfelder/KONRAD-Kontext, anschließend vollständige DWD-/OPERA-Analyse im Hintergrund. Letzte erfolgreiche Analyse wird ortsbezogen kurzzeitig zwischengespeichert.
- Hyperlokale Analyse progressiv beschleunigt: sofortige Kernnetzauswertung mit reduziertem Kandidatenbudget, danach vollständige Mehrnetz-/Restfeldanalyse im Hintergrund; letzte erfolgreiche Ortsanalyse wird kurzzeitig zwischengespeichert.
- Aktuelle Wetterdaten um RADOLAN-Rückschau ergänzt: letzte Stunde aus angeeichtem RW, bei noch nicht ausreichend aktuellem RW aus nicht angeeichten RY-5-Minuten-Produkten; letzte 24 Stunden aus dem aktuellen angeeichten SF-Produkt.
- Neue Worker-Endpunkte `radolan-history-meta` und `radolan-history-file` mit DWD-Produktprüfung, Caching und ortsbezogener Browserauswertung ergänzt.
- Neuer Regressionstest schützt Touch-Scrubbing, progressive Schnellpfade, Trennung von Standort-/Umgebungsecho und die RADOLAN-Rückschau.

# MID v0.7.103.4

- EEA-Messstationssuche auf die aktuellen offiziellen ArcGIS-Dienste `air.discomap.eea.europa.eu` und `eeha.discomap.eea.europa.eu` umgestellt.
- Der bisherige einzelne Legacy-Host, der HTTP 403 lieferte, ist nicht mehr alleinige Datenquelle.
- Worker probiert nun zwei EEA-Spiegelserver und zwei räumliche Abfragestrategien (Umkreissuche und Bounding-Envelope).
- Browserseitiger direkter EEA-Fallback ergänzt, falls der Cloudflare-Worker oder dessen Upstream vorübergehend nicht erreichbar ist.
- Letzte erfolgreich gefundene EEA-Messstation wird ortsbezogen bis zu 30 Tage als Rückfall gespeichert und im Tooltip transparent gekennzeichnet.
- Stationsklasse des aktuellen EEA-Layers wird als Messumfang statt irreführend als Verkehrs-/Umgebungsklasse erklärt.
- Technische Rohfehlermeldungen werden im AQI-Tooltip durch eine verständliche Statusmeldung ersetzt.
- Neuer Regressionstest für EEA-Hostwechsel, Spiegelserver, Geometrie-Fallback, Browser-Rückfall und Cache.

# MID v0.7.103.3

- GitHub-/TypeScript-Buildfehler `TS2540: Cannot assign to current because it is a read-only property` im Radar-Nowcast behoben.
- Der dynamische Popover-Anker der 5-Minuten-Balken verwendet nun ein ausdrücklich schreibbares `useRef<HTMLButtonElement | null>`.
- Das MID-typische Verhalten bleibt vollständig erhalten: Antippen eines Balkens öffnet dessen Tooltip; erneutes Antippen, Außenklick oder Escape schließen ihn.
- Neuer Regressionstest schützt die schreibbare Ref-Typisierung und die Zuordnung des aktiven Balkens als Popover-Anker.

# MID v0.7.103.2

- Radar-Nowcast deutlich verdichtet und auf durchgängige 5-Minuten-Balken umgestellt. Jeder Balken öffnet per Klick/Tippen einen MID-typischen Portal-Tooltip mit Zeitraum, Status, Intensität in mm/h und abgeleiteter 5-Minuten-Menge; Außenklick und Escape schließen den Tooltip.
- Erklärtexte und zusätzliche Ereigniskarten unter der Nowcast-Leiste entfernt; die numerische Intensitätsskala bleibt kompakt erhalten.
- Standortmarker im Kompositbild auf die halbe bisherige Größe reduziert, Blickrichtung und Sensorfunktion bleiben erhalten.
- Ensemble-Diagramme nach Einführung der Export-Wrapper wieder strikt an die verfügbare Viewportbreite gebunden. Der historische globale Mindestwert von 760 px wird innerhalb beider Diagramm-Wrapper aufgehoben.
- Achsen, Ränder, Legenden und Diagrammhöhen werden auf schmalen Displays kompakt angepasst, sodass Temperatur- und Niederschlagsdiagramm vollständig im Bildschirm bleiben.
- Neuer Regressionstest für 5-Minuten-Nowcast, Portal-Tooltip, Markergröße und mobile Ensemblebreite.

# MID v0.7.103.1

- Tagesdetail-Tooltip neu angeordnet: **Taupunkt / Feuchte** steht vor **Wind / Böen**; innerhalb des Feuchtefelds wird zuerst der Taupunkt und danach die relative Feuchte angezeigt.
- Aktuelle Windkachel an die Tagesdetaildarstellung angeglichen: Windrichtungspfeil, Windgeschwindigkeit und Böen stehen gemeinsam im Hauptwert; Richtung und Datenquelle folgen getrennt in der Detailzeile.
- Zentrale Sprühregen-/Schneegriesel-Plausibilisierung verschärft, ohne die Niederschlagsphase zu verändern. Neben Luftfeuchte und tiefer Bewölkung werden Taupunktspreizung, geschätzte beziehungsweise beobachtete Wolkenbasis, Niederschlagsrate und Schauersignal berücksichtigt.
- Sprühregen bei geschätzter/erfasster Wolkenbasis über 3000 ft GND wird innerhalb der flüssigen Phase zu Regen verallgemeinert; bei gleichzeitigem Schauersignal zu Regenschauern. Schneegriesel wird unter unplausiblen Bedingungen ausschließlich zu Schnee beziehungsweise Schneeschauern verallgemeinert.
- Taupunktinformationen werden nun in aktuellem Wetter, Tagesdetail, Meteogramm sowie Berg-/Wintersport an dieselbe zentrale Plausibilisierung übergeben.
- Push-Mitteilungen nennen statt des generischen Wortes „Favorit“ den gegebenenfalls manuell geänderten Ortsnamen; beim dynamischen Standort lautet der Bezug **„am Standort“**. Dies gilt für Titel und Texte von Niederschlags- und Gewittermeldungen.
- Neuer Regressionstest schützt Feldreihenfolge, Winddarstellung, appweite Taupunkt-/Wolkenbasisprüfung und ortsbezogene Push-Texte.

# MID v0.7.103.0

- Ensemble-Datenpfad grundlegend stabilisiert: statt bis zu 14 parallelen Mitgliedermodellfamilien werden höchstens acht priorisierte, räumlich passende Modelle mit maximal zwei gleichzeitigen Abrufen geladen.
- Neuer Cloudflare-Proxy für Open-Meteo-Ensemble- und Modellmetadaten ergänzt, um Browser-/CORS-/Rate-Limit-Ausfälle zu reduzieren und Modellstände zuverlässig bereitzustellen.
- Offizielle Ensemble-Mittel-/Spread-Reserve verwendet Temperatur- und Niederschlagsspreizung zur Rekonstruktion belastbarer Quantile, falls einzelne Mitgliedermodelle ausfallen.
- Letzter erfolgreicher Ensemble-Stand wird ortsbezogen 24 Stunden lokal vorgehalten, sodass Diagramme und Modelllauf-Radar bei vorübergehender API-Störung nicht vollständig verschwinden.
- KONRAD3D-Annäherungslogik korrigiert: Eine Zelle gilt nur als näherkommend, wenn das prognostizierte Zellzentrum tatsächlich näher liegt; eine größere Unsicherheitsellipse darf keine scheinbare Annäherung erzeugen.
- Radar-Nowcast auf 5- bis 15-minütige Einzelintervalle erweitert. Die Balkenhöhe nutzt eine dynamische mm/h-y-Achse; zusammenhängende Zeiträume zeigen maximale Intensität und grob abgeleitete Niederschlagsmenge.
- Neuer Regressionstest schützt Ensemble-Recovery, Worker-Proxy, Modellmetadaten, Zellzentrum-Plausibilisierung sowie Nowcast-y-Achse und Intervallmengen.

# MID v0.7.102.1

- Ensemble-Ladezustand repariert: Ein geöffnetes 14-Tage-Ensemble bleibt während des Wetterladens und bei Ortswechseln aktiv und startet für den neuen Ort zuverlässig einen neuen Ensemble- und Klimadatenabruf.
- Der gespeicherte Offen-Zustand des Ensemble-Moduls initialisiert die Datenanforderung bereits beim App-Start.
- Die PNG-Exportbibliothek wird erst beim tatsächlichen Antippen von „Teilen“ dynamisch geladen. Ein Fehler des optionalen Exportpfads kann Diagramme, Modellstände und Modelllauf-Änderungsradar dadurch nicht mehr gemeinsam ausblenden.
- Modellstände und Modelllauf-Änderungsradar bleiben auch im vorläufigen Ensemble-/Ladezustand sichtbar.
- Neuer Regressionstest schützt die Ensemble-Sichtbarkeit, den Ladepfad und die Entkopplung der Teilen-Funktion.

# MID v0.7.102.0

- Standortmarker im Kompositbild durch ein richtungsabhängiges Symbol mit blauem Positionsring und Pfeil in Blickrichtung ersetzt.
- Gerätekompass nutzt auf iPhone/iPad `webkitCompassHeading` und fordert die notwendige Bewegungssensor-Berechtigung erst nach einem bewussten Antippen des Markers an. Auf anderen Geräten wird ein absoluter Device-Orientation-Wert verwendet; die Anzeige wird geglättet.
- Fehlende oder verweigerte Kompassfreigabe wird transparent im Standort-Popup erklärt, ohne die Karten- oder Positionsfunktion einzuschränken.
- Beide Ensemble-Diagramme erhalten einen eigenen Teilen-Button: Temperaturtrend und Niederschlagsdiagramm können als PNG über das native Teilen-Menü ausgegeben werden.
- Der Export übernimmt exakt die aktuell ausgewählte Diagrammdarstellung, einschließlich ENS-Mittel, Klimamittel, P25–P75 und Niederschlagswahrscheinlichkeit.
- Exportbilder enthalten MID-Name und Version, Standort, aktive Modellfamilien, Initialisierungs-/Verfügbarkeitszeiten, Darstellungsoptionen und Quellenhinweis.
- Fallback für Browser ohne Datei-Teilen: Das PNG wird lokal heruntergeladen.
- Neuer Regressionstest schützt Standort-Blickrichtung, iOS-Berechtigung, beide Teilen-Buttons und den vollständigen Quellenblock.

# MID v0.7.101.1

- Widersprüchliche Gewitter-Pushmeldung korrigiert: Der sichtbare Abstand stammt nun ausschließlich aus der tatsächlichen aktuellen Zellposition und nicht mehr aus dem durch Prognoseunsicherheit reduzierten Relevanzabstand.
- Aktuelle Nähe und künftige Annäherung werden getrennt behandelt. Befindet sich eine Zelle bereits höchstens 20 km entfernt, wird keine zusätzliche spätere Annäherungszeit mehr angezeigt.
- Bei weniger als 1 km Abstand lautet der Hinweis „unmittelbar am Favoriten“ statt „0 km entfernt“.
- Bei einer noch entfernten Zelle nennt die Pushmeldung aktuelle Entfernung, Annäherungszeit und prognostizierten Rohabstand getrennt.
- Dieselbe Grenzlogik wurde in der sichtbaren Gewitterkarte und in der KONRAD3D-Kurzbeschreibung vereinheitlicht.
- Neuer funktionaler Regressionstest bildet den problematischen Fall „aktueller Abstand 42 km, effektiver Prognoseabstand 0 km, Annäherung in 30 min“ sowie unmittelbare und nahe Zelllagen ab.

# MID v0.7.101.0

- Luftqualitätskachel auf die offiziellen sechs Stufen des European Air Quality Index der EEA umgestellt. PM2,5, PM10, NO₂, O₃ und SO₂ werden anhand ihrer aktuellen Konzentration klassifiziert; die schlechteste Einzelstufe bestimmt die Gesamtstufe.
- Offizielle EEA-Farbpalette übernommen: Gut, Mittelmäßig, Mittel, Schlecht, Sehr schlecht und Äußerst schlecht.
- Erweiterter AQI-Tooltip zeigt sämtliche Einzelkonzentrationen, deren jeweilige EU-AQI-Stufe und die nächstgelegene EEA-Messstation mit Name, Entfernung, Klasse und EoI-Kennung.
- Neuer Worker-Endpunkt für die nächstgelegene EEA-Luftgütemessstation; die zusätzliche Abfrage läuft nur im erweiterten Modus.
- KONRAD3D-Abfrage auf primären und offiziellen DWD-Spiegelserver erweitert und als eigener fünfminütiger Liveabruf aus dem initialen Wetter-Ladebündel entkoppelt.
- NowCastMIX prüft sowohl Accumulated Flash Geometry als auch Accumulated Flash Area über primären und redundanten DWD-WFS-Dienst. Eine erfolgreiche Nullmenge wird nun als „Dienst erreichbar, keine Objekte“ statt als Fehler behandelt.
- Kompositbild zeigt für K3D und NowCastMIX eindeutig Datenstand, erreichbaren Leerdatensatz oder Dienstfehler.
- App-weite Performanceprüfung: doppelte Stunden-/Tageskartierung in der aktuellen Wetterkachel entfernt, Detaildiagramm-Uhr nur bei sichtbarem geöffnetem Tageschart aktiv und sämtliche Komposit-Pollings/Animationen außerhalb des Sichtbereichs pausiert.
- Neuer Regressionstest schützt EU-AQI, EEA-Station, Offscreen-Pause und K3D-/NowCastMIX-Fallbacks.

# MID v0.7.100.5

- Großes textliches Zugrichtungs-Overlay im Kompositbild entfernt. Richtung und Geschwindigkeit bleiben im kompakten Layerbutton, im Infofenster und im Standort-Popup verfügbar.
- Niederschlags-Zugpfeile als hoch liegende weiße Div-Marker neu umgesetzt. Dadurch bleiben sie unabhängig vom Canvasrenderer und von Radar-/Satellitenrastern sichtbar.
- KONRAD3D-Zellen als deutliche farbige Marker mit K3D-Stufe und verfügbaren Hagel-, Starkregen-, Blitz- und Böensymbolen neu gerendert.
- NowCastMIX-Blitzobjekte als violette Blitzmarker in einer eigenen, gut sichtbaren Markerebene dargestellt.
- Layerbuttons oberhalb der Karte deutlich verdichtet. Kurze Bezeichnungen wie „Radar · 1 km“, „K3D / MIX“ und „Zugpfeile“ zeigen darunter den aktuellen Datenstand beziehungsweise Objektzahlen.
- Scrollen auf Touchgeräten verbessert: Die Karte startet mobil im Scrollmodus und fängt Ein-Finger-Seitenscrollen nicht mehr ab. Über „Karte aktiv“ lässt sich Verschieben/Zoomen jederzeit wieder einschalten.
- Blitz- und NowCastMIX-Vektoren werden räumlich ausgedünnt und auf ein gerätegerechtes Renderingbudget begrenzt. Die Daten bleiben abrufbar; nur überlagerte Marker werden zusammengefasst.
- Laufende Kompositanimation stoppt beim Seitenscrollen, um Layer-Neuaufbau während der Scrollbewegung zu vermeiden.
- Neuer Regressionstest für kompaktes Layerband, sichtbare Zugpfeile/Nowcast-Symbole und touchfreundliches Karten-Scrolling.

# MID v0.7.100.4

- GitHub-Produktionsbuild repariert: `ChevronDown` wird für die einklappbare Komposit-Legende wieder vollständig aus `lucide-react` importiert. Dadurch ist der TypeScript-Fehler `TS2304: Cannot find name ChevronDown` beseitigt.
- Die Gewitterinformation verwendet nun exakt dieselbe sichtbare Ortsbezeichnung wie der Seitenkopf. Ein manuell vergebener Favoritenname beziehungsweise Alias (z. B. „Rheidt“) ersetzt damit auch in Kurztext und KONRAD3D-Tooltip die automatisch rückwärtsgeocodierte Bezeichnung (z. B. „Mondorf“).
- Änderungen des Favoritennamens lösen unmittelbar eine Neuberechnung der memoisierten Gewittertexte aus. Koordinaten, Entfernungsberechnung und KONRAD3D-Abfrage bleiben unverändert auf dem tatsächlichen Standort.
- Zwei Regressionen schützen die Favoriten-Ortsbezeichnung und den zuvor fehlenden Icon-Import.

# MID v0.7.100.3

- Laufende Ortszeit aus dem großen App-Renderpfad isoliert, sodass nicht mehr alle 30 Sekunden das vollständige Dashboard neu aufgebaut wird.
- Dashboard-, Karten- und Vektorbereiche memoisiert sowie Radar-/Starkregen-Abrufe bei Fokuswechsel entdoppelt.
- Leaflet-Canvas und reduzierte Touch-Effekte verbessern die Responsivität ohne Funktionsabbau.

# MID v0.7.100.2

- Die Kompositbild-Legende startet nun standardmäßig in einer sehr kompakten Ansicht mit Zeitangabe und aktiver Radarquelle. Per Klick oder Tippen lässt sie sich aufklappen und wieder minimieren.
- Die aufgeklappte Legende enthält weiterhin aktive Layer, Niederschlagsfarbskala, Blitzalter sowie KONRAD3D-/NowCastMIX-Erklärung, wurde aber in Abständen und Bedienfläche möglichst kompakt gehalten.
- Die zentrale Plausibilitätsprüfung für Sprühregen und Schneegriesel wurde fachlich eingegrenzt: Sie verallgemeinert nur die seltene Unterart, verändert aber niemals die vom WMO-Code vorgegebene flüssige, gefrierende, gemischte oder feste Niederschlagsphase.
- Unplausibler Sprühregen wird zu Regen, unplausibler gefrierender Sprühregen zu gefrierendem Regen und unplausibler Schneegriesel zu Schnee beziehungsweise Schneeschauern. Schnee- und Schneeschauercodes bleiben unabhängig von bodennaher Temperatur oder parallelen Regenfeldern fest.
- Neuer Regressionstest schützt einklappbare Legende und phasenerhaltende Niederschlagslogik.

# MID v0.7.100.1

- TypeScript-Buildfehler `TS18047: loc is possibly null` in der Gewitterinformation behoben. Der Ortsname wird nun nullsicher aus `loc?.name` abgeleitet und fällt während der initialen Standortauflösung auf „Standort“ zurück.
- Die Ortsbezeichnung wurde in die Abhängigkeiten der memoisierten Gewitterauswertung aufgenommen, damit ein später aufgelöster oder gewechselter Ort zuverlässig neu bewertet wird.
- Neuer Regressionstest verhindert direkte Zugriffe auf `loc.name` innerhalb der Gewitterauswertung und schützt damit exakt den in GitHub Actions aufgetretenen Fehler.

# MID v0.7.100.0

- Die Gewitterinformation trennt jetzt die **aktuelle Entfernung** einer KONRAD3D-Zelle sauber von der prognostizierten größten Annäherung. Zuvor konnte der um die Unsicherheitsellipse verminderte Prognoseabstand wie eine aktuelle Entfernung wirken.
- Jede KONRAD3D-Zelle erhält einen vom ausgewählten MID-Ort aus berechneten Richtungswinkel. Die Kurzkarte nennt aktuelle Distanz, relative Himmelsrichtung, erwartete Annäherungszeit und den unverfälschten Prognoseabstand.
- Neuer schließbarer Info-Tooltip in der Gewitterkarte mit Zellkennung, aktuellen und prognostizierten Koordinaten, Zellstufe/Trend, Zugrichtung und -geschwindigkeit, Blitzrate, Hagel-/Starkregen-/Böensignalen, Unsicherheitsradius, Datenalter und Zahl erkannter Zellen.
- Die KONRAD3D-Karten-Popups wurden um dieselben verfügbaren Zellinformationen erweitert.
- Das Kompositbild besitzt eine eigene Legende für KONRAD3D-Stufen, Zellprognosebahnen und NowCastMIX-Blitzgeometrien.
- Das Verlagerungsoverlay ist nun als eigener, dauerhaft gespeicherter Schalter verfügbar. Er blendet Niederschlagspfeile, Zughinweis und Standort-Zuglabel gemeinsam ein oder aus, ohne Radar oder Nowcast-Objekte abzuschalten.
- Neuer Regressionstest schützt Ortsbezug, Distanztrennung, Unsicherheitsangabe, Objektlegende und Verlagerungsschalter.

# MID v0.7.99.2

- Im Untermenü **Benachrichtigungen** eine dauerhaft gespeicherte Auswahl für den Mindestabstand zwischen Push-Mitteilungen ergänzt. Verfügbar sind 15, 30, 60, 120 und 180 Minuten; Standard ist 30 Minuten.
- Das Intervall gilt geräteweit für Niederschlagsbeginn, Gewitterannäherung und materielle Modelllaufänderungen. Der Cloudflare-Cron darf weiterhin alle fünf Minuten prüfen, der Worker sendet innerhalb des gewählten Zeitraums jedoch höchstens eine Mitteilung an dieses Gerät.
- Der Mindestabstand wird zusammen mit dem Push-Abonnement im privaten Cloudflare-KV-Eintrag gespeichert und bei jeder Einstellungsänderung automatisch synchronisiert.
- Während der Sperrzeit erkannte Ereignisse werden nicht als bereits gemeldet verbucht. Sie bleiben ausstehend und werden nach Ablauf des Intervalls erneut geprüft, sofern das Signal noch relevant ist.
- Bestehende Abonnements ohne gespeicherten Wert verwenden im Worker vorsichtshalber 60 Minuten, bis die aktualisierte App das gewählte Intervall synchronisiert.
- Neue funktionale Regression prüft UI-Auswahl, lokale Persistenz, Client-Übertragung sowie die serverseitige Zeitprüfung.

# MID v0.7.99.1

- Automatische Berg-/Wintersport-Profilermittlung von der Auswahl eines einzelnen Liftpaares auf das zusammenhängende Wander-/Skigebiet umgestellt. MID wählt nun die niedrigste plausible Talstation, eine explizite beziehungsweise vernetzte Mittelstation und die höchste verbundene Bergstation. Der Referenzfall Sölden schützt Giggijoch-Talniveau, Gaislachkogl-Mittelstation und 3.340-m-Bergniveau.
- Höhenhülle für hochalpine, aber noch lokal verbundene Bergstationen erweitert; ortsfremde Gruppen bleiben über Nähe, Geländeanker, Clusterverbindung und maximale Gebietsspanne ausgeschlossen.
- Modelllauf-Änderungsradar speichert die einzelnen eingebundenen Modellstände im Snapshot. Bei identischen Sammelzeiten zeigt es nun das tatsächlich geänderte Modell sowie dessen alten und neuen Initialisierungs- beziehungsweise Verfügbarkeitsstand.
- Push-Deep-Links repariert: fehlende Koordinatenparameter werden nicht mehr durch `Number(null)` als 0°/0° interpretiert. Koordinaten, Ortsname und Land werden zusätzlich im Notification-Payload gespeichert und beim Öffnen durch beide Service Worker erneut in die Ziel-URL geschrieben.
- Dynamischer Standort und nahezu deckungsgleicher statischer Favorit können gleichzeitig aktiv sein. Die Zuordnung berücksichtigt horizontale Entfernung und, sofern vorhanden, die Höhendifferenz.
- Neue funktionale Regression prüft Skigebiets-Extremhöhen, Modelllaufidentifikation, Push-Koordinaten und Favoriten-Gleichsetzung.

# MID v0.7.98.1

- GitHub-Produktionsbuild repariert: Die optionale Radar-Nowcast-Leiste greift während des initialen Wetterladens nicht mehr direkt auf einen möglicherweise noch nicht verfügbaren Wetterdatensatz zu.
- Der Zeitzonenwert wird nullsicher an die Nowcast-Leiste übergeben; bis zum Eintreffen der Wetterdaten verwendet die Darstellung den vorhandenen lokalen Fallback.
- Neue Regression schützt den exakten TS18047-Fall (`w` möglicherweise `null`) und verhindert eine erneute nicht-nullgesicherte Übergabe in der Ortskopfzeile.

# MID v0.7.98.0

- Kompositbild um ein flächiges Niederschlags-Bewegungsfeld erweitert. Richtungspfeile werden nicht mehr nur am ausgewählten Ort, sondern an aus dem aktuellen Radarbild ermittelten Niederschlagsankern dargestellt.
- DWD-RV erzeugt dafür ein zusätzliches großräumiges Bewegungsfeld aus dem neuesten Radarstand; RainViewer- und OPERA-Raster liefern ebenfalls räumliche Niederschlagsanker als Fallback.
- OPERA-CIRRUS vergleicht aufeinanderfolgende Rasterstände jetzt auch flächig, um Zugrichtung und Geschwindigkeit außerhalb der DWD-Abdeckung abzuleiten.
- Pfeildesign an die gewünschte Radaroptik angepasst: helle, kontrastgerahmte Bewegungsvektoren direkt auf den Niederschlagsfeldern.
- Zugrichtung und Zuggeschwindigkeit am ausgewählten Ort werden zusätzlich als permanentes Standortlabel und als frei platzierte Statuskarte angezeigt. Die Anzeige liegt unterhalb der Karten-Schaltflächen und wird nicht mehr von Zoom-, Kartenbasis- oder Standortsteuerung verdeckt.
- Radar-Nowcast-Zeitreihe um standortbezogene Beobachtungs- und Vorhersageframes ergänzt.
- Neue, in den Einstellungen aktivierbare „Radar-Nowcast-Leiste“ in der Kachel „Aktuelle Niederschlagswahrscheinlichkeit“. Sie erscheint nur bei erkanntem oder heranziehendem Radarecho und zeigt eine Zeitachse von −1 bis +2 Stunden mit Jetzt-Markierung und Intensitätssegmenten.
- Einstellung wird versionsunabhängig unter `mid:radarDisplaySettings` gespeichert.
- Neue Regression schützt flächige Echoanker, Standortkennzeichnung, Nowcast-Datenreihe, Einstellungspersistenz und responsive Zeitachse.

# MID v0.7.97.1

- Automatische Bergprofil-Ermittlung gegen ortsfremde Liftkombinationen gehärtet. Der bisherige 25-km-Suchraum und die unbeschränkte Kombination beliebiger Tal- und Bergpunkte konnten extreme, nicht zusammengehörige Profile erzeugen.
- Suchradius auf 18 km begrenzt und Kandidaten zusätzlich an die Geländehöhe des gewählten Ortes gekoppelt. Bei normalen Bergorten darf das automatische Talniveau höchstens 500 m unter beziehungsweise 450 m über der Ortshöhe liegen; der Gipfelpunkt muss oberhalb liegen und bleibt ebenfalls höhenbegrenzt.
- Liftstationen werden nur noch innerhalb räumlich zusammenhängender Liftgruppen kombiniert. Endpunkte derselben Liftanlage werden bevorzugt; Einzelkandidaten aus verschiedenen Skigebieten dürfen nicht mehr allein wegen großer Höhendifferenz gekoppelt werden.
- Stationsknoten werden nahe gelegenen Liftenden zugeordnet, damit Tal-/Bergrollen und Anlagenzusammenhang belastbarer erkannt werden. Eine Mittelstation wird nur noch bei expliziter Mittelrollen-Kennzeichnung oder tatsächlichem Bezug zur gewählten Liftanlage übernommen.
- Zusätzliche Maximalgrenzen für Höhendifferenz, horizontale Spannweite und Entfernung zum Favoriten verhindern Profile wie 490 m Talhöhe bei einem Ort auf rund 1.958 m.
- Bereits gespeicherte automatische Altprofile werden beim Versionswechsel geprüft. Unplausible Höhen oder Koordinaten werden auf sichere lokale Ausgangswerte zurückgesetzt; manuell bearbeitete Profile bleiben unangetastet.
- Neue Regression bildet den gemeldeten Obergurgl-/Hochgurgl-Fall nach und schützt Suchradius, lokale Höhenhülle, Liftcluster und Altprofilmigration.

# MID v0.7.97.0

- Berg-/Wintersportmodus vollständig geprüft und auf Schema 2 gehärtet: Saisonprofile Automatisch/Sommer/Winter, Lift-/Stations- und Geländehöhenprofil, optionale Mittelstation, editierbare Stationsdaten und höhenbezogene Einzelkoordinaten bleiben erhalten.
- Winterdaten je Höhenstufe erweitert: Schneedecke wird getrennt als GeoSphere-Messwert und Open-Meteo-Modellwert dargestellt; Neuschnee der vergangenen 24 Stunden sowie Prognosen für +24 und +48 Stunden bleiben separat sichtbar.
- GeoSphere-Schneemessungen für Österreich über den MID-Worker ergänzt. Messwerte werden nur bei höchstens 25 km Entfernung, höchstens 350 m Höhendifferenz, maximal drei Stunden Alter und plausibler Schneehöhe übernommen.
- Sommerliche Bergparameter wie UV-Index, Sicht, Wind/Böen und Gewitterpotenzial sowie die automatische Migration älterer Favoritenprofile auf das neue Bergschema abgesichert.
- Cloudflare Web Analytics wieder funktionsfähig verdrahtet: Bei vorhandener GitHub-Buildvariable erzeugt MID den offiziellen Beacon im Produktionsbuild selbst und zeigt den Lade-/Blockierstatus im Systembereich an.
- Untermenü „Benachrichtigungen“ optisch an die übrigen Einstellungen angeglichen: gruppierte Auswahlkarten, aktive Zustände und einheitliche Abstände/Radien.
- Push-Mitteilungen enthalten nun einen Zielort-Deep-Link. Beim Antippen öffnet beziehungsweise navigiert die installierte App direkt zum betroffenen Favoriten; Koordinaten dienen als sicherer Rückfall.
- Normales Öffnen der App lädt wieder den zuletzt geöffneten Ort. Automatische Standortverfolgung aktualisiert nur die Benachrichtigungsposition und überschreibt den sichtbaren Ort nicht mehr.
- Kompositbild um aus Radarbildfolgen abgeleitete Zugrichtung ergänzt. Mehrere Richtungspfeile werden direkt auf dem Radarbild angezeigt; Richtung, Geschwindigkeit und Sicherheitsstufe stehen zusätzlich in der Quelleninformation.
- Modelllauf-Änderungsradar auf ein versionsunabhängiges Sammelarchiv umgestellt. Je Ort bleiben mehrere Stände in localStorage sowie der bestehenden IndexedDB-/Cache-Sicherung erhalten und werden aus älteren Einzelständen migriert.
- Neue Gesamtsuite schützt Berg-/Wintersport, GeoSphere-Schnee, Analytics, Benachrichtigungsdesign und Deep-Links, letzten Ort, Radar-Zugrichtung sowie das versionsfeste Modellarchiv.

# MID v0.7.95.30

- Niederschlags-Plausibilisierung appweit vereinheitlicht: aktuelles Wetter, 7-Tage-Vorhersage, stündliche Detailansicht, Ensemble, Meteogramm und Berg-/Wintersportmodul verwenden nun dieselbe zentrale Ableitung für Wettertext, Piktogramm und Niederschlagsart.
- Regen/Sprühregen-Prüfung vollständig wiederhergestellt: Sprühregen-Codes werden nur noch bei plausibler feuchter tiefer Stratuslage und schwacher nicht-konvektiver Rate übernommen; andernfalls erfolgt eine konsistente Umstufung zu Regen, Schauer oder trockener Bewölkung.
- Plausibilitätsprüfung auf Schnee und Schneegriesel erweitert. Bodentemperatur, explizite Schneemenge, Feuchte, tiefe Bewölkung, Niederschlagsrate und konvektiver Anteil verhindern warme oder dynamisch unplausible Schneesymbole; valide nasse Schneefälle mit explizitem Schneefeld bleiben erhalten.
- Auch trockene Fehlcodes werden korrigiert: Ein unplausibler Niederschlagscode ohne messbaren Niederschlag fällt auf einen zur Bewölkung passenden trockenen WMO-Code zurück.
- Meteogramm-Abfrage um Gesamt- und tiefe Bewölkung ergänzt, damit die zentrale Plausibilitätsprüfung dort dieselben Eingangsdaten wie die übrige App verwendet.
- Tagesbezogene DWD-Hazard-Auswertung korrigiert: Warnungen werden nur aus Startstunden des angezeigten Tages gebildet, erhalten aber bis zu 72 Stunden Vorlaufdaten für Schwellen und nächtliche Abkühlung. Dadurch entspricht der Temperaturwert im Wärme-Warnbutton wieder der maximalen gefühlten Temperatur des Tages.
- Neue appweite Regression schützt Niederschlagskonsistenz und den Tageshöchstwert der gefühlten Temperatur; synthetischer Testfall 34 °C am Vormittag und 36 °C am Nachmittag erwartet korrekt 36 °C im Warnhinweis.

# MID v0.7.95.29

- Einstellungsdialog wieder vollständig an das geschützte Design von MID v0.7.95.26 angeglichen: zweispaltiger Desktopdialog, mobile Bereichsnavigation, Auswahlkarten, Einheitenauswahl und eingebettete Detailbereiche.
- Design der erweiterten Funktionen auf die v0.7.95.26-Kartenstruktur zurückgestellt; das Modelllauf-Änderungsradar besitzt wieder die ursprünglichen Gruppen-, Auswahl- und Konfigurationselemente.
- Sämtliche Ensemble-Hilfe- und Modellstände-Popover wieder nach v0.7.95.26 umgesetzt: Body-Portale, Außenklick/-tippen, Escape, erneutes Antippen sowie responsive Positionierung.
- Prognosekonsistenzpunkte verwenden wieder den geschützten v0.7.95.26-Tooltip mit Hover auf Mausgeräten, Ein-Tap-Bedienung und sicherem Außenklick-Schließen.
- Temperaturtrend-Tooltip wieder als sehr kompakte Tmin/Tmax-Matrix von v0.7.95.26 hergestellt, einschließlich P25–P75, P10–P90, ENS-Mittel, Klima, Sonne, Modellzahl und Hazards.
- Veraltete Regressionserwartungen an die wiederhergestellte v0.7.95.26-Darstellung angepasst und neuer verbindlicher Referenztest für Einstellungen und Ensemble-Tooltips ergänzt.

# MID v0.7.95.28

- GitHub-TypeScript-Buildfehler der Luftdrucktendenz behoben: `Hour.pressure` ist wieder typisiert, `pressure_msl` wird stündlich geladen und in `mapHours()` übernommen.
- Eigener Regressionstest schützt API-Feld, Typdefinition, Mapping und dreistündige Drucktendenz gemeinsam.
- Verbindliche maschinenlesbare Quellbasis `MID_BASELINE.json` ergänzt; sie verankert den vollständigen Referenzstand v0.7.95.26 am Commit `213ab6a52a48dcd073066e95551b5d7f057570be`.
- Release-Workflow aktualisiert nach erfolgreichem Build und Pages-Deployment automatisch den Zweig `mid-stable`; manuelle Deployments verwenden ausschließlich diesen letzten erfolgreich veröffentlichten Stand.
- Neuer Quellbasis-Test verhindert fehlende Referenzverträge, unsynchronisierte Releaseversionen und einen Rückfall auf unbestätigte App-Basen.

# MID v0.7.95.27

- Vollständige Funktionskontinuität auf Basis des Referenzstands v0.7.95.26 wiederhergestellt; der fehlerhafte Funktionsabbau der nachfolgenden Paketbasis wurde nicht übernommen.
- Info-Schaltflächen und Modellstände in Best-Match- und Ensemble-Bereichen als robuste Body-Portale abgesichert; Außenklick/-tippen, Escape, erneutes Antippen, Scrollen und Größenänderungen funktionieren zuverlässig.
- Tooltips der farbigen Prognosekonsistenzpunkte schließen bei Klick oder Tippen außerhalb; Interaktionen auf Punkt und Tooltip selbst bleiben erhalten.
- Luftdrucktendenz, Sonne/Mond, Modelllauf-Änderungsradar, Benachrichtigungen, erweitertes Bergprofil, Web-Analytics-Diagnose und die zugehörige Worker-/Service-Worker-Unterstützung wieder vollständig verdrahtet.
- Automatischer v0.7.95.26-Funktionsvertrag und Popover-Regression ergänzt; alle vorhandenen MID-Regressionstests werden weiterhin automatisch erkannt.

# MID v0.7.90.4

- Luftqualitätskarte um einen kompakten Info-Button zur Zusammensetzung des europäischen AQI ergänzt.
- Der Gesamt-AQI wird als höchster Teilindex aus PM2,5, PM10, NO₂, O₃ und SO₂ erläutert; die unterschiedlichen Bezugszeiträume von Feinstaub und Gasen werden genannt.
- Eigenständiger sechsstufiger AQI-Indikator mit Rautenmarkierung, Kategorienbezeichnung und farbiger Segmentleiste ergänzt. Er unterscheidet sich bewusst vom runden grünen Stationsabgleich-Punkt der hyperlokalen Analyse.
- Die fünf europäischen AQI-Teilindizes sowie SO₂ werden zusätzlich von Open-Meteo geladen; der aktuell maßgebliche Schadstoff wird in der Kartenzeile genannt.
- Neuer Regressionstest für AQI-Datenfelder, Erklärung und Indikatordesign.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.90.3

- Layout der Metadaten in der 7-Tage-Vorhersage korrigiert.
- Niederschlagsmenge und -wahrscheinlichkeit, Sonnenscheindauer sowie Windsymbol, exakter 360°-Pfeil, Windgeschwindigkeit und Böen stehen wieder gemeinsam in einer Zeile.
- Auf schmalen Displays nutzt die Metazeile die Breite bis zum rechten Kartenrand und eine responsive Schriftgröße, statt die Windangabe in eine zweite Zeile zu zwingen.
- Hazard-Hinweise bleiben separat in der zweiten Kartenzeile.
- Regressionstest für das einzeilige Windlayout aktualisiert.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.90.2

- Ursache unpassender Wetterpiktogramme im stündlichen Detaildiagramm behoben.
- Open-Meteo liefert `weather_code` als Momentaufnahme, Niederschlagsmengen dagegen als Summe des vorangegangenen Stundenintervalls. Deshalb konnte ein trockener Momentcode über einem vorhandenen Niederschlagsbalken erscheinen.
- Aus Mengenfeldern abgeleitete Niederschlagsarten erhalten jetzt immer einen passenden repräsentativen WMO-Anzeigecode für Regen, Schauer, Schnee, Schneeregen, gefrierenden Niederschlag oder Gewitter.
- Bei responsiv ausgedünnten Wetterpiktogrammen repräsentiert jedes Symbol nun sein umliegendes Zeitfenster. Ein kurzes Niederschlagsereignis zwischen zwei bisherigen Abtaststunden wird dadurch nicht mehr übersprungen.
- Die Piktogrammpositionen bleiben konfliktfrei gleichmäßig verteilt; jedes Symbol repräsentiert das zugehörige Zeitfenster und übernimmt darin ein vorhandenes Niederschlagsereignis.
- Neuer ausführbarer Regressionstest für Intervallbezug, Fallback-Anzeigecodes und kurze Niederschlagsereignisse.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.90.1

- Verrutschte Windangabe in den mobilen Karten der 7-Tage-Vorhersage korrigiert.
- Wind-Symbol, 360-Grad-Richtungspfeil, Geschwindigkeit und Böen werden als untrennbare, eigene zweite Metazeile dargestellt.
- Niederschlagsmenge und Sonnenscheindauer bleiben in der ersten Metazeile und können sich bei sehr schmalen Displays weiterhin responsiv anordnen.
- Neuer Regressionstest verhindert das erneute Aufteilen der Windangabe.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.90

- Sichtbaren Info-/Installationsbutton „MID als App nutzen“ im App-Footer ergänzt.
- Unterstützte Chromium-Browser öffnen über `beforeinstallprompt` den nativen Installationsdialog.
- iPhone und iPad erhalten eine integrierte Safari-Anleitung für „Zum Home-Bildschirm hinzufügen“ und „Als Web-App öffnen“.
- Standalone-Erkennung berücksichtigt CSS-Display-Mode und den iOS-Navigatorstatus; bereits installierte Instanzen werden erkannt.
- Responsiver, zugänglicher Dialog mit Escape-/Hintergrund-Schließen, Installationsstatus und klaren Vorteilen.
- Neuer Regressionstest prüft Manifest, Apple-PWA-Metadaten, Installationsereignisse und responsive Oberfläche.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.89.5

- Die Felder unter dem Detaildiagramm wurden vollständig auf die Regen-/Sprühregen-Plausibilitätsprüfung umgestellt.
- Das Niederschlagsfeld nutzte bereits die plausibilisierte Form; nun verwenden auch Wettertext, Wettersymbol und die Wetterpiktogramme im Detaildiagramm denselben korrigierten Anzeigecode.
- Ein unplausibler Open-Meteo-Sprühregencode erscheint damit überall in der Detailansicht konsistent als leichter, mäßiger oder starker Regen.
- Die Niederschlagsarten der Detaillegende werden nicht mehr als dünne Linien, sondern als kompakte Balken im jeweiligen Farb- und Musterdesign dargestellt.
- Neuer Regressionstest für die Konsistenz der Detailansicht und ihrer Niederschlagslegende.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.89.4

- Windrichtungspfeile in aktueller Lage, Tageskarten, Stunden-Detailansicht, Tooltips, Bergmodus und Widget verwenden jetzt den exakten Winkel von 0 bis 359,9 Grad statt eines Acht-Richtungen-Rasters in 45-Grad-Schritten.
- Die bisherige MID-Konvention bleibt erhalten: Der Pfeil zeigt in die Richtung, in die der Wind weht; im zugänglichen Titel werden Herkunfts- und Zielrichtung in Grad genannt.
- Das Meteogramm nutzte bereits die vollständige 360-Grad-Drehung und bleibt unverändert konsistent.
- Neuer Regressionstest verhindert die Rückkehr der diskreten Unicode-Pfeile.
- README, Changelog, Service-Worker-Cache und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.89.3

- Kritischen Laufzeitfehler nach dem Start von v0.7.89.x behoben.
- Die manuelle Aufteilung von React, Icons, Diagramm-, Karten-, Export- und HDF5-Bibliotheken wurde vollständig zurückgenommen. Sie brachte bei den überwiegend statischen Importen keinen verlässlichen Bedarfsladevorteil und konnte eine fehlerhafte Initialisierungsreihenfolge der erzeugten Browser-Chunks verursachen.
- Das bewährte Vite-Standard-Bundling ist wieder aktiv. Das echte Lazy-Loading der großen MID-Module bleibt unverändert erhalten.
- Sichere Optimierungen bleiben bestehen: ES2020-Ziel, CSS-Code-Splitting, deaktivierte Produktions-Source-Maps, Rendering-Containment, Touch-Scrolling, mobile Tooltip-Begrenzung und reduzierte Bewegung.
- Der Performance-Test verhindert künftig ausdrücklich die erneute Aktivierung manueller Vendor-Chunks.
- Service-Worker-Cache auf v0.7.89.3 erhöht, damit fehlerhafte Assets der vorherigen Version nicht weiterverwendet werden.
- README, Changelog und sämtliche Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.89.2

- Zweiten GitHub-Buildfehler in `vite.config.ts` behoben.
- Die vorherige Ersetzung hatte `indexOf(...) >= 0` falsch geklammert und dadurch einen Vergleich innerhalb des Funktionsarguments erzeugt.
- Sämtliche Pfadprüfungen der manuellen Chunk-Aufteilung verwenden nun korrekt `id.indexOf('...') >= 0`.
- README, Changelog und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.89.1

- GitHub-Buildfehler in `vite.config.ts` behoben.
- Die Chunk-Aufteilung verwendet nun `indexOf(...) >= 0` statt `String.prototype.includes(...)` und ist damit mit der im Node-TypeScript-Projekt verwendeten Bibliothekskonfiguration kompatibel.
- Die Performance-Optimierungen und die funktionale Aufteilung der Ladepakete bleiben unverändert erhalten.
- README, Changelog und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.89

- Intensive Code- und Release-Revision mit Schwerpunkt auf Responsivität, Ladeverhalten und Paketgröße ohne Funktionsabbau.
- Vite-Build in getrennte, bedarfsgerecht ladbare Bibliotheks-Chunks für Diagramme, Karten, Export, HDF5, React und Icons aufgeteilt; Source-Maps im Produktionsbuild deaktiviert.
- Unterhalb des sichtbaren Bereichs liegende Module werden browserseitig über `content-visibility` und intrinsische Platzhalter effizienter dargestellt.
- Horizontale Diagramm- und Zeitachsen erhalten stabileres Touch-Scrolling, begrenztes Overscrolling und mobile Scroll-Snap-Unterstützung.
- Tooltips und Informationsdialoge wurden für schmale Displays gegen Überbreite, abgeschnittene Inhalte und unkontrollierte Umbrüche abgesichert.
- Unterstützung für `prefers-reduced-motion` ergänzt und unnötige Build-Artefakte aus dem Release-ZIP entfernt.
- README, Changelog und sämtliche Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung; Versionsnummer nur synchronisiert.

# MID v0.7.88.3

- Darstellungsfehler im Tooltip des 14-Tage-Ensemble-Trends behoben.
- Der Prozentwert der Prognosekonsistenz wird nun als untrennbare Einheit dargestellt und bricht auch auf schmalen Bildschirmen nicht mehr zwischen Zahl und Prozentzeichen um.
- README, Changelog und Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.88.2

- Die mit v0.7.88.1 eingeführte Sprühregen-Plausibilisierung gilt nun konsequent auch für die Wettertexte und Wettersymbole der 7-Tage-Vorhersage, des Widgets und des 14-Tage-Ensemble-Trends.
- Unplausible WMO-Sprühregen-Codes 51–55 werden in Tageszusammenfassungen nicht mehr als „Sprühregen“ weitergereicht, sondern anhand der DWD/WMO-Stundenschwellen als leichter, mäßiger oder starker Regen behandelt.
- Tagesereignisse, Zeitangaben und repräsentative Wettersymbole greifen jetzt auf dieselbe zentralisierte Niederschlagsform-Auswertung wie die Stundenansicht zurück.
- README, Changelog und sämtliche Versionsstellen aktualisiert.
- Cloudflare Worker ohne funktionale Änderung.

# MID v0.7.88.1

- Plausibilitätsprüfung für Open-Meteo-Sprühregen ergänzt: WMO-Codes 51–55 werden nur noch bei hoher relativer Feuchte, ausgeprägter tiefer Bewölkung und schwacher stratiformer Niederschlagsrate als Sprühregen dargestellt.
- Fehlen die typischen Stratus-/Feuchtemerkmale oder ist die Niederschlagsrate zu hoch, wird der Niederschlag als Regen klassifiziert.
- Regenintensitäten werden nach den DWD/WMO-Stundenschwellen als leicht, mäßig, stark oder sehr stark bezeichnet; Sprühregen nutzt seine eigenen DWD-Intensitätsstufen.
- `cloud_cover_low` wird jetzt in der Best-Match-Stundenprognose geladen und zusammen mit relativer Feuchte, Gesamtbewölkung, Schauersignal und Niederschlagsmenge ausgewertet.
- Regressionstests sichern plausiblen Sprühregen und die Umklassifizierung unplausibler Sprühregen-Codes ab.
- Cloudflare Worker ohne funktionale Änderung; Versionsnummer lediglich synchronisiert.

# MID v0.7.87.1

- Release-Pipeline korrigiert: `package-lock.json` enthält keine internen OpenAI-Paketserver mehr; `jsfive` und `pako` werden über die öffentliche npm-Registry bezogen.
- ZIP-Installation und GitHub-Pages-Deployment sind im Installationsworkflow direkt verkettet, weil ein Bot-Commit mit `GITHUB_TOKEN` keinen weiteren Push-Workflow startet.
- Pages-Actions auf `configure-pages@v6`, `upload-pages-artifact@v5` und `deploy-pages@v5` aktualisiert; vorzeitiges Deployment beim reinen ZIP-Upload wird verhindert.
- OPERA-Nutzung erneut gehärtet: Der Worker ermittelt aktuelle CIRRUS-DBZH-Dateien jetzt primär über die offizielle MeteoGate-ORD-API und parallel über den offenen S3-Index.
- Falls beide Verzeichnisdienste ausfallen, bleibt der begrenzte HDF5-Range-Probe-Fallback aktiv. Dadurch hängt OPERA weder allein vom S3-Listing noch von geschätzten Zeitstempeln ab.
- Kompositbild und aktuelle Niederschlagswahrscheinlichkeit verwenden weiterhin denselben validierten HDF5-Rasterpfad; DWD bleibt in Deutschland primär, OPERA ist sichtbare Unterlage und unabhängiger Abgleich.
- OPERA-Regressionstest um den ORD-API-Pfad erweitert.

# MID v0.7.87

- Belastbare erste Ausbaustufe des automatischen Starkregen-/Überflutungsindikators ergänzt: RADOLAN-YW-Summen für 15/30/60/180/360 Minuten, DWD-RV-Nowcast-Summen bis +120 Minuten, KONRAD3D-Starkregenflag und Zellzug, KOSTRA-DWD-2020-Einordnung für 30/60/360 Minuten sowie DWD-Stationsabgleich.
- Die Starkregenkarte erscheint ausschließlich bei einem tatsächlichen Mess-, Nowcast-, KONRAD-, KOSTRA- oder nahen Stationssignal und bleibt vollständig von amtlichen Warnungen getrennt.
- OPERA-CIRRUS-Georeferenzierung korrigiert: Das offizielle LAEA-Raster verwendet eine Oberkante von y=0 m und den negativen Projektionsursprung y_0=-2.100.000 m. Die frühere Ersatzgeometrie verschob Standortabfragen um 4.400 km und führte dadurch zu NoData.
- Das Kompositbild deklariert OPERA erst nach erfolgreichem Download, HDF5-Dekodierung und realer Standortabdeckungsprüfung als bereit. OPERA wird als europäische Unterlage dargestellt, DWD liegt in Deutschland darüber.
- Die aktuelle Niederschlagswahrscheinlichkeit prüft DWD und OPERA parallel. DWD bleibt in Deutschland primär; OPERA dient als unabhängiger Abgleich und übernimmt bei DWD-Ausfall. RainViewer bleibt der letzte Fallback.
- OPERA-Bereitschaft, Datenstand und Fehlergrund werden im Infodialog des Kompositbildes ausgewiesen.

# MID v0.7.86.1

- Fehler im isolierten Ensemble-Nullability-Regressionstest behoben: Der Test verwendet nun eine eigene temporäre TypeScript-Konfiguration mit `moduleResolution: Bundler`, `skipLibCheck: true` und leerer `types`-Liste.
- Dadurch werden bei der kleinen Testdatei keine projektexternen Ambient-Typdefinitionen aus `node_modules/@types` mehr unnötig mitkompiliert.
- Die im GitHub-Lauf gemeldeten TS2792-Fehler zu `@babel/parser`, `@babel/types` und `csstype` treten nicht mehr auf; der eigentliche strikte Nullability-Test bleibt erhalten.
- Keine funktionale Änderung an Wetterdarstellung oder Cloudflare Worker.

# MID v0.7.86

- Ausführliche Quellen-, Produkt-, Auflösungs-, Zeit-, Alters-, Status- und Lizenzangaben des Kompositbildes in einen barrierefrei beschrifteten Infodialog verschoben.
- OPERA-CIRRUS-Erkennung korrigiert: Der Worker liest nun die tatsächlich vorhandenen DBZH-HDF5-Objekte aus dem offiziellen S3-Index, statt Zeitstempel zu erraten.
- Nur real vorhandene OPERA-Frames werden an Karte und aktuelle Niederschlagswahrscheinlichkeit übergeben; bei einem nicht verfügbaren Index folgt ein kontrollierter Range-Probe-Fallback.
- OPERA-Dateiproxy verwendet validierte Objektschlüssel und liefert Diagnoseheader für Quelle, Produkt, Schlüssel und Worker-Version.
- Regressionstest für Infodialog, reale OPERA-Objektliste, fehlertolerante Erkennung und CORS-HDF5-Proxy erweitert.

# MID v0.7.85

- Z-Zeit unter dem Ortsnamen einheitlich als `hhmmZ` ohne Doppelpunkt dargestellt.
- Separate Gewitterinformation neben der aktuellen Niederschlagswahrscheinlichkeit ergänzt.
- DWD KONRAD3D wird fünfminütig für Zellposition, Zugrichtung, Schweregrad, Trend, Blitzrate, Hagel-, Starkregen- und Böenflags ausgewertet.
- Amtliche DWD-WFS/CAP-Gewitterwarnungen haben Vorrang; Radar, Best-Match und Stationsniederschlag dienen ergänzend der Plausibilisierung.
- Neue Workerroute `thunderstorm-nowcast` und Regressionstest ergänzt.

# MID v0.7.84.1

- GitHub-Buildfehler TS18048 im OPERA-Rasteroverlay behoben.
- Statt des optional typisierten `pixelBounds.min` verwendet die Darstellung nun Leaflets eindeutig typisierten Karten-Pixelursprung.
- Regressionstest verhindert die erneute Verwendung des optionalen Bounds-Minimums.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.84

- Phase 1 der europäischen Radarintegration auf Basis von MID v0.7.83.3 umgesetzt.
- Das Kompositbild lädt das echte EUMETNET-OPERA-CIRRUS-DBZH-Komposit als ODIM-HDF5-Raster mit 1 km Rasterweite und fünfminütigem Produktzyklus.
- Radarpriorität vereinheitlicht: DWD-HX/PX250 beziehungsweise DWD-RV → OPERA CIRRUS → RainViewer als letzter Fallback.
- Die frühere OPERA-Punkt-/Stützstellenauswertung wurde vollständig entfernt.
- Karte und aktuelle Niederschlagswahrscheinlichkeit verwenden denselben OPERA-Rasterdecoder; Standortpixel und 30-km-Umfeld fließen in die Radar-/Best-Match-Kombination ein.
- Neue Worker-Routen `opera-raster-meta` und `opera-raster-file` liefern validierte Metadaten und CORS-sichere HDF5-Dateien.
- Regressionstest für OPERA-Raster, Quellenreihenfolge und Entfernung der Altlogik ergänzt.

# MID v0.7.83.3

- Achsentick-Beschriftungen im Ensemble-Temperaturdiagramm vertikal korrigiert.
- Die zusätzliche CSS-Baseline `dominant-baseline: hanging`, die X- und Y-Achsenwerte leicht nach unten verschob, wurde entfernt.
- Recharts übernimmt wieder die vorgesehene mittige Standardausrichtung der Tickwerte.
- Regressionstest für die Achsenausrichtung ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.83.2

- GitHub-Actions-Warnung zur erzwungenen Node.js-24-Ausführung entfernt: `actions/checkout` und `actions/setup-node` wurden in Installations- und Deployment-Workflow von v4 auf v6 aktualisiert.
- Der Installer-Workflow ist zusätzlich als Wiederherstellungs-/Referenzkopie Bestandteil des vollständigen MID-Projekts.
- Regressionstest verhindert künftig die erneute Verwendung der Node-20-basierten Action-Versionen v1 bis v4.
- Das Projekt selbst wird weiterhin bewusst mit Node.js 22 gebaut; geändert wurde ausschließlich die interne Laufzeit der GitHub-Actions-Bausteine.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.83.1

- GitHub-Buildfehler in `src/EnsemblePanel.tsx` behoben: optionale Klimawerte werden vor der Formatierung gemeinsam als endliche Zahlen eingegrenzt.
- Die Temperatur-Skalierung filtert `number | undefined` nun über einen echten TypeScript-Type-Guard statt über einen unzulässigen `number`-Callback.
- Eine leere optionale Klimareihe fällt für die Skalenberechnung sicher auf die Best-Match-Werte zurück.
- Strikter Regressionstest für die Ensemble-Nullability ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.83

- Warnfreie Tage werden in der 7-Tage-Vorhersage kompakt als „Keine Hazards“ gekennzeichnet.
- Sonnenscheindauer, Prognosekonsistenz und Best-Match-Hazards verwenden im Ensemble-Tooltip einen einheitlichen Abschnittsaufbau.
- Gemeinsame Popover- und Diagrammhilfen reduzieren redundante Listener und doppelte Skalenlogik.
- Ensemble-Diagramm- und Tooltip-Daten wurden stärker typisiert; stabile React-Schlüssel und ein automatischer CodeCheck wurden ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.82.2

- Die 7-Tage-Vorhersage zeigt an warnfreien Tagen wieder einen dezenten Hinweis „Keine Warnhinweise“.
- Best-Match-Hazards ab interner Intensitätsstufe 2 erscheinen im Ensemble-Temperaturtrend wieder als kompakte, farbcodierte Piktogramme direkt oberhalb des Sonnenschein-/Bewölkungsbands; die vollständigen Angaben bleiben im Tages-Tooltip.
- Schriftart und Textfarben des Ensemble-Temperatur-Tooltips wurden vereinheitlicht.
- Aus sämtlichen automatisch erzeugten Warntexten und Windschwellen-Tooltips wurden ausgeschriebene Hinweise auf DWD-Warnstufen entfernt; die interne Farbcodierung und Schwellenlogik bleiben unverändert.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.82.1

- Die ausgeschriebene Bezeichnung zeigt die Anfangsbuchstaben **M**, **I** und **D** innerhalb von „Meteorological Information Dashboard“ fett.
- Das Rückfallsystem versucht eine neuere, vollständig gecachte MID-Version nun automatisch erneut; die Rückfallleiste verschwindet beim manuellen erneuten Test sofort und bleibt nicht dauerhaft an einer älteren Version hängen.
- Warnfelder der 7-Tage-Vorhersage zeigen nur noch den prognostizierten Wert in der gewählten Einheit, ohne zusätzliche Umrechnung oder Beaufortangabe; der vollständige Warntext bleibt im Tooltip.
- Best-Match-Warnhinweise ab Warnstufe 2 wurden im Ensemble-Temperaturtrend aus der Diagrammfläche entfernt und platzsparend in den Tages-Tooltip integriert.
- Im Detaildiagramm besitzt die Niederschlagswahrscheinlichkeit eine unabhängige rechte 0-/50-/100-%-Achse. Niederschlagsbalken werden an den Plotgrenzen beschnitten und können die rechte Achse nicht mehr überdecken.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.82

- Warntexte und kompakte Hazardwerte verwenden die gewählte Windeinheit; bei kt, m/s oder mph wird der km/h-Wert ergänzt, bei km/h die Beaufortstärke.
- Warntexte zeigen prognostizierte Temperaturen und Mengen ausschließlich als ganze Werte ohne Dezimalkomma.
- Die 7-Tage-Vorhersage zeigt ab DWD-Warnstufe 1 nur noch kompakte, stufenfarbige Symbole mit erwartetem Wert; die ausführliche Erläuterung bleibt im Tooltip.
- Best-Match-Warnmarker wurden aus dem stündlichen Detaildiagramm entfernt. Die dezenten Windwarnflächen und horizontalen DWD-Schwellenlinien bleiben bestehen.
- Im Ensemble-Temperaturtrend erscheinen oberhalb des Sonnenschein-/Bewölkungsbands stufenfarbige Best-Match-Hazards ab Warnstufe 2.
- Allgemeine Best-Match-Gefahrenkarten verwenden dieselbe ganzzahlige und einheitenbewusste Warntextformatierung.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.81.1

- DWD-Warnstufe 1 in der zentralen Best-Match-Auswertung ergänzt und fachlich korrigiert.
- Windböen werden ab Überschreiten von 50 km/h als Stufe 1 erkannt; der Windbereich besitzt nun zusätzlich die gelbe Schraffur und Trennlinie zwischen 50 und 65 km/h.
- Einfache Gewitter, leichter Schneefall, Glätte bei Niederschlag und Frost, Frost unter 0 °C bis 800 m, Nebel unter 150 m Sichtweite und starke Wärmebelastung über etwa 32 °C bei geringer Abkühlung werden als Stufe 1 berücksichtigt.
- Die kompakte Warnsymbolzeile oberhalb des Sonnenschein-/Bewölkungsbands zeigt gemäß Vorgabe weiterhin ausschließlich Stufen 2 bis 4; Stufe 1 fließt in die allgemeine 24-Stunden-Gefahrenauswertung und Windskalierung ein.
- UV-Warnstufe 1 wird nicht künstlich aus dem UVI allein erzeugt, weil das DWD-Kriterium zusätzlich eine regionale beziehungsweise klimatologische Abweichung verlangt.
- Regressionstests um sämtliche automatisch ableitbaren Stufe-1-Kriterien und die Filterung der Symbolzeile erweitert.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.81

- Best-Match-basierte Warnhinweise wurden in beiden Modi als eigene Symbolzeile unmittelbar oberhalb des Sonnenschein-/Bewölkungsbands ergänzt.
- Es werden ausschließlich modellseitig überschrittene DWD-Warnstufen 2 bis 4 dargestellt; Ereignisart, Warnfarbe und Stufennummer sind direkt unterscheidbar.
- Warnmarker fassen zusammenhängende Zeiträume zusammen und öffnen per Klick, Tippen oder Tastatur einen kurzen Tooltip; sie sind ausdrücklich keine amtlichen Warnungen.
- DWD-Warnkriterien für Wind, Gewitter, Stark- und Dauerregen, Schneefall, Schneeverwehung, markante Glätte/Glatteis, strengen Frost und extreme Wärmebelastung zentralisiert.
- Windwarnbereiche auf die offiziellen Schwellen 65, 90, 105, 120 und über 140 km/h umgestellt; jede neue Schwelle wird zusätzlich durch eine dezente horizontale Linie markiert.
- Automatische Hazard-Karten und Tagesindikatoren verwenden dieselbe zentrale DWD-Logik und keine bisherigen Mischschwellen aus DWD, Meteoalarm und NWS mehr.
- Regressionstest für DWD-Schwellen, Warnmarker, Intensitäten, Tooltips und horizontale Schwellenlinien ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.80

- Im Windbereich der erweiterten stündlichen Detailansicht werden die vorhandenen DWD-/Meteoalarm-Warnschwellen ab 50, 75, 89 und 103 km/h als dezente gelbe, orangefarbene, rote und violette Schraffurbereiche dargestellt.
- Die Warnflächen werden ausschließlich innerhalb des tatsächlich sichtbaren Windbereichs gezeichnet und liegen hinter Wind-, Böen- und Richtungselementen.
- Meteogramm und Widget-/PNG-Generator besitzen keine eigene zweite Ein-/Ausklappsteuerung mehr; beide werden ausschließlich über den jeweiligen äußeren Modulschalter geöffnet und geschlossen.
- Beim Schließen der Module werden die enthaltenen Komponenten weiterhin ausgehängt und laufende Meteogrammabrufe abgebrochen.
- Regressionstest für Windwarnflächen und eindeutige Modulsteuerung ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.79.3

- Die Zahl der Wetterpiktogramme in der stündlichen Detailansicht wird nun aus der tatsächlich verfügbaren Diagrammbreite bestimmt und bis zur konfliktfrei möglichen Höchstzahl erhöht.
- Auf breiten Tablet- und Desktopansichten können alle stündlichen Piktogramme erscheinen; auf schmaleren Displays werden sie gleichmäßig über den Tag verteilt.
- Der bisher sehr großzügige feste Mindestabstand wurde durch eine an Symbolgröße und Ansichtsbreite angepasste Verteilung ersetzt.
- Cloudflare Worker ohne funktionale Änderung; nur Versionssynchronisierung.

# MID v0.7.79.2

- In beiden Ansichtsmodi folgt der Kopfbereich der stündlichen Detailansicht nun der Reihenfolge: JETZT-Zeitmarkierung, Wetterpiktogramme, Sonnenschein-/Bewölkungsband, eigentliche Diagrammfläche.
- Die blaue Markierung des ausgewählten Zeitschritts reicht jetzt bis in die Piktogramm-Lane und wird hinter den Wetterpiktogrammen gezeichnet, damit diese lesbar bleiben.
- Vertikale Abstände und Diagrammhöhe wurden für schmale und breite Ansichten gemeinsam angepasst.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.79.1

- In der stündlichen Detailansicht wurden Wetterpiktogramme und Sonnenschein-/Bewölkungsband vertikal getauscht: Die Piktogramme stehen nun oben, das Band direkt darunter.
- Abstände zur Jetzt-Zeitmarkierung und zur eigentlichen Diagrammfläche wurden entsprechend angepasst, damit alle Elemente weiterhin getrennt bleiben.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.79

- Im Erweiterten Modus zeigt die Ortszeile nun die aktuelle Ortszeit mit GMT-Abweichung und zusätzlich die Z-Zeit in Klammern; die einzeilige Darstellung passt ihre Schriftgröße responsiv an.
- Erklärungen der stündlichen Detailansicht, der 14-Tage-Ensemble-Übersicht sowie der Temperatur- und Niederschlagsdiagramme wurden auch im Erweiterten Modus in dezente, bei Außenklick schließbare Info-Popover verschoben.
- P10–P90-Fehlerbalken im Ensemble-Niederschlagsdiagramm werden unabhängig vom Best-Match-Wert exakt zwischen P10 und P90 gezeichnet.
- Oberen Bereich der Detailansicht in getrennte Ebenen für Sonnenschein-/Bewölkungsband, Wetterpiktogramme und aktuelle Uhrzeit gegliedert, damit keine Überdeckungen entstehen.
- Temperatur-, Niederschlags- und Windachsen verwenden nun möglichst glatte, an runden Schrittweiten ausgerichtete Werte.
- Dichte der Windrichtungspfeile wird anhand der tatsächlich verfügbaren Diagrammbreite automatisch maximiert, ohne benachbarte Pfeile zu überdecken.
- Regressionstests für Z-Zeit, Info-Popover, exakte P10–P90-Spanne, adaptive Kopfleiste, Achsenskalierung und Windpfeildichte ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.78.1

- TypeScript-Buildfehler TS2367 in der Niederschlagsdarstellung der erweiterten Detailansicht behoben.
- Den Niederschlagstyp `none` vor der Verwendung des engeren `DetailPrecipType` jetzt über einen expliziten Type-Guard ausgeschlossen.
- Dieselbe typsichere Prüfung wird auch für die dynamische Niederschlagsskala verwendet.
- Regressionstest erweitert, damit die fehlerhafte Kombination aus Exclude-Typcast und anschließendem `none`-Vergleich nicht erneut eingeführt wird.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.78

- Open-Meteo-Modellkatalog um CHMI ALADIN Seamless, ALADIN Mitteleuropa 2,3 km und ALADIN Tschechien 1 km ergänzt, damit aktuelle Modellstände im Best-Match-Status korrekt benannt werden.
- Die jüngsten serverseitigen Open-Meteo-Korrekturen für ECMWF-Solarinterpolation, AIGEFS-Abruf und GFS-Niederschlags-Deakkumulation werden automatisch über die bestehenden APIs genutzt; hierfür ist keine eigene MID-Datenumrechnung erforderlich.
- Im Erweiterten Modus lassen sich Temperatur, gefühlte Temperatur, Taupunkt, einzelne Niederschlagsarten, Niederschlagswahrscheinlichkeit, Wind, Böen und Windrichtung unmittelbar über die Legende ein- und ausblenden.
- Taupunkt als zurückhaltende Linie ergänzt; unter dem Niederschlagsbereich erscheinen Wind und Böen sowie darunter Richtungspfeile.
- Nicht mehr benötigte Temperatur-, Niederschlags- und Windbereiche werden dynamisch entfernt. Das SVG passt ViewBox und Höhe per ResizeObserver an Hoch-/Querformat und verfügbare Bildschirmbreite an, ohne die Darstellung zu verzerren.
- Legendenmuster der gefühlten Temperatur in Standard- und Erweitertem Modus an die gestrichelte Diagrammlinie angeglichen.
- Auswahl der erweiterten Detailparameter wird lokal gespeichert.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.77.1

- Beschriftung der gelb-grauen Sonnenschein-/Bewölkungslegende in allen Farbdesigns mit einer festen dunklen Schriftfarbe lesbar gemacht.
- Deutsche Wortstellung bei später einsetzenden Schauern korrigiert, z. B. `Stark bewölkt, abends Schauer` statt `Stark bewölkt, Schauer abends`.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.77

- Widget-/PNG-Generator und Druckniveau-Meteogramm stehen ausschließlich im Erweiterten Modus zur Verfügung.
- Quellen bleiben in beiden Modi über die Fußzeilen-Schaltfläche `Quellen` erreichbar und öffnen sich als bei Außenklick, Touch oder Escape schließbares Popover.
- Beim erstmaligen Öffnen des Standardmodus werden die stündliche Detailansicht sowie alle nachfolgenden einklappbaren Module geschlossen initialisiert.
- Bestehende Modulzustände bleiben nach der Erstinitialisierung weiterhin lokal gespeichert.
- Der Zusatz `Ortsname aus Geodatenbank` wurde in beiden Ansichtsmodi entfernt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.76

- Modellstände-Popover in Best-Match- und Ensemble-Bereichen schließen nun zuverlässig bei Klick oder Tippen außerhalb sowie mit Escape.
- Bisherigen Kompaktmodus in `Standardmodus` umbenannt und als Erststartmodus festgelegt; bestehende Compact-Einstellungen werden automatisch übernommen.
- Bisherigen Vollständig-Modus durch den `Erweiterten Modus` ersetzt. Dieser verwendet weiterhin einklappbare Module, ergänzt jedoch meteorologische und technische Hintergründe direkt in der Oberfläche.
- Im Standardmodus werden ausgewählte Bedien- und Datenerklärungen über dezente Info-Schaltflächen geöffnet und bei Außenklick, Touch oder Escape wieder geschlossen.
- Ausführliche Stationsanalyse, Ensemble-Methodik, Bedienhinweise und lange technische Quellen-/Haftungserklärungen werden im erweiterten Modus direkt angezeigt.
- Alte gespeicherte Vollansicht wird automatisch in den erweiterten Modus migriert.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.75

- Dezente Tagespfeile der stündlichen Detailansicht stehen nun auf Handy, Tablet im Hoch- und Querformat sowie Desktop dauerhaft bereit.
- Die Pfeile bleiben responsiv: Auf kleinen Smartphones nur als Symbole, auf größeren Displays zusätzlich mit abgekürztem Wochentag.
- Neu angelegte Favoriten werden nicht mehr vorne einsortiert, sondern am Ende der bestehenden Reihenfolge ergänzt.
- Auch importierte, bisher noch nicht vorhandene Favoriten werden hinter den vorhandenen Einträgen angefügt; die Reihenfolge innerhalb des Imports bleibt erhalten.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.74

- Favoriten-Schnellleiste platzsparend als eigene zweite Reihe unter der Kopfleiste reaktiviert.
- Aktuelle Position und alle gespeicherten Favoriten sind wieder direkt auswählbar; aktiver Ort, Standardort, Gruppe sowie Berg-/Ski- und Wassersportprofile bleiben erkennbar.
- Reihenfolge lässt sich unmittelbar in der Schnellleiste per Maus-Drag&Drop und auf Touchgeräten über den Griff verschieben; die neue Reihenfolge wird wie bisher lokal gespeichert.
- Das kleine Verwaltungssymbol öffnet direkt den Favoriten-Unterbereich der zentralen Einstellungen. Umbenennen, Gruppen, Regeln, Import/Export, Standardort und Profile bleiben ausschließlich dort.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.73

- Ensemble-Temperaturtooltip horizontal wieder an Diagramm und Viewport begrenzt; am rechten beziehungsweise linken Rand wechselt die Position automatisch zur sichtbaren Seite.
- METAR-Wolkenhöhe fachlich differenziert: `Ceiling` erscheint nur bei mindestens 5/8 Bewölkung aus BKN/OVC/VV, bei 1/8 bis 4/8 wird die niedrigste FEW-/SCT-Lage als `Wolkenuntergrenze` in hft angezeigt.
- Hyperlokale Stationsanalyse um die separate Wolkenuntergrenze erweitert, ohne aus dünner Bewölkung fälschlich eine Ceiling abzuleiten.
- Stündliche Detailansicht auf Handy und Tablet um dezente Randtasten für den tageweisen Wechsel ergänzt; die gewählte Uhrzeit wird beim Tageswechsel beibehalten.
- Konsistenzpunkte im mobilen 14-Tage-Ensemble-Trend reagieren nun beim ersten Tippen. Hover wird ausschließlich auf Geräten mit echter Maus-/Trackpad-Hoverfunktion verwendet.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.72

- Zentrales Einstellungsmenü ergänzt und die bisher verteilten Kopfbereichsregler dort logisch zusammengeführt.
- Ansichtsoptionen, Farbdesign (Auto/Hell/Dunkel), Windeinheit, Favoritenverwaltung und MID-Systemstatus besitzen eigene Unterbereiche.
- Favoritenverwaltung vollständig als Untermenü eingebettet; Gruppen, Reihenfolge, Standardort, Import/Export sowie Berg-/Ski- und Wassersportprofile bleiben erhalten.
- Permanenten Favoritenstreifen sowie direkte Ansicht-, Design-, Einheiten- und Systemstatusregler aus dem Kopfbereich entfernt. Favoriten bleiben über die Ortssuche schnell erreichbar.
- Kopfbereich auf allen Plattformen auf Ortssuche, Standort, Einstellungen und Neuladen reduziert; responsive Vollbilddarstellung des Einstellungsmenüs auf Mobilgeräten ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.71

- Update-System grundlegend erweitert: Eine neue Version wird vor der Aktivierung vollständig in einen eigenen App-Shell-Cache geladen, einschließlich der tatsächlich im produktiven `index.html` referenzierten JavaScript- und CSS-Dateien.
- Die zuletzt geprüfte Vorversion bleibt erhalten. Schlägt der Start der neuen App fehl und wird innerhalb von 20 Sekunden keine Laufzeit-Gesundheitsmeldung gesendet, schaltet MID automatisch auf die vorherige Version zurück.
- Manuelle Systemverwaltung ergänzt: App-/Worker-/aktive Version anzeigen, MID-Cache neu aufbauen, vorherige Version wiederherstellen und Service Worker samt App-Caches zurücksetzen. Favoriten und Einstellungen bleiben beim Reset erhalten.
- Rückfallversion erhält eine feste Wiederherstellungsleiste, über die die aktuelle Version erneut getestet werden kann.
- Datenabrufe entkoppelt: Best Match, Stationsanalyse, Luftqualität, Radar, amtliche Warnungen und Modellinformationen verwenden getrennte AbortController und blockieren einander nicht.
- Ensemble und Klimatologie laden unabhängig voneinander. Ortswechsel, manuelles Neuladen und Ansichtswechsel brechen veraltete Requests ab, damit alte Ergebnisse keinen neuen Standort überschreiben.
- Such-, Meteogramm- und PX250-Metadatenabrufe zusätzlich gegen überholte Antworten und weiterlaufende Netzwerkzugriffe abgesichert.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionssynchronisierung.

# MID v0.7.70.4

- Weltweiten NOAA-AviationWeather-/METAR-Abruf korrigiert: Die geografische Bounding-Box wird entsprechend der aktuellen API-Reihenfolge als Breitengrad/Längengrad übergeben.
- METAR-Zeitfenster auf drei Stunden erweitert und internationale Suchweite außerhalb Deutschlands von 140 auf 220 km erhöht.
- Mehrfachmeldungen derselben ICAO-Station werden auf die jeweils neueste Beobachtung reduziert.
- METAR-Sichtweite wird nun auch über den Worker vollständig an die hyperlokale Analyse weitergereicht.
- Eigener Regressionstest für internationale METAR-Orte ergänzt; funktionale Worker-Änderung, daher Worker vor dem Hauptprojekt bereitstellen.

# MID v0.7.70.3

- Im Ensemble-Niederschlagsdiagramm die getrennten P10-/P90-Kurven durch einen dunkelgrauen P10–P90-Fehlerbalken über dem Best-Match-Niederschlagsbalken ersetzt.
- Fehlerbalken werden nur an Tagen mit Best-Match-Niederschlag angezeigt.

# MID v0.7.70.2

- Mausradnavigation der stündlichen Detailansicht auf die eigentliche SVG-Diagrammfläche begrenzt; Legende, Überschrift, Quickfacts und Stunden-Tooltip scrollen die Seite wieder normal.
- Ursache der ausgefallenen Ensemble-Auswertung behoben: veraltete Open-Meteo-Modellkennungen für Mitgliedsmodelle und Ensemble-Mittel durch die aktuellen API-Kennungen ersetzt.
- Ensemble-Abrufe auf vier parallele Modellanfragen begrenzt und bei HTTP 429/5xx mit kurzen Wiederholungsversuchen abgesichert.
- Ensemble-Mittel-Reserve vollständig auf die aktuellen DWD-, NOAA-, ECMWF-, GEM-, BOM-, UKMO-, MeteoSwiss- und Google-Kennungen aktualisiert.
- Diagnose bei vollständigem Ausfall präzisiert; keine funktionale Worker-Änderung, nur Versionssynchronisierung.

# MID v0.7.70.1

- Ensemble-Diagramm-Tooltip präzisiert: Bei der Sonnenscheindauer heißt der Klammerzusatz nun `P10–P90` statt des unspezifischen Ausdrucks `Bandbreite`.
- Versionsschema auf aufwertungsabhängige Releases umgestellt: Funktionsstände verwenden `0.7.x`, eng begrenzte Wartungsänderungen `0.7.x.y`.
- Versionssynchronisierung, Anzeigeersetzung und Updater-Vergleich für vierteilige Wartungsversionen abgesichert.
- Keine funktionale Worker-Änderung; nur einheitliche Versionssynchronisierung auf `0.7.70.1`.

# MID v0.7.70

- Sichtbare Mess- und Prognosewerte auf einheitliche deutsche Dezimaldarstellung geprüft und erweitert.
- Aktuelle Bewölkung um die METAR-Ceiling in hunderten Fuß über Grund (`hft`) ergänzt; geeignete BKN-, OVC- und VV-Lagen fließen stationsgewichtet in die hyperlokale Analyse ein.
- Desktop-Kacheln der aktuellen Einzelparameter platzsparender angeordnet, sodass bei ausreichender Breite alle Parameter in einer Zeile stehen.
- Cloudflare Worker funktional um strukturierte Wolkenlagen, vertikale Sichtweite und METAR-Rohmeldung erweitert.

# MID v0.7.69

- Sonnenscheindauer in der 7-Tage-Vorhersage und im Ensemble-Tooltip mit maximal einer Nachkommastelle formatiert: volle Stunden erscheinen ohne unnötige Dezimalstelle (`15 h` statt `15,0 h`), Zwischenwerte weiterhin mit deutschem Dezimalkomma.
- Gelb-graue Sonnenscheinlegende im Ensemble-Temperaturdiagramm verkleinert und optisch zurückgenommen, ohne das eigentliche Datenband zu verändern.
- Aktuelle Messwerte um die Karte „Sichtweite“ zwischen Niederschlag und Bewölkung ergänzt.
- Hyperlokale Analyse um Sichtweite erweitert und zugleich Bewölkung sowie Niederschlag in die modellgestützte Restfeldanalyse aufgenommen; Temperatur, Feuchte, Taupunkt, Luftdruck, Wind, Böen, Sichtweite, Bewölkung und Niederschlag nutzen nun alle verfügbaren geeigneten Stationsmessungen.
- Bright-Sky-Sichtweite wird in Metern übernommen; METAR-Sichtweiten werden aus Statute Miles zuverlässig in Meter normalisiert. METAR-Wolkenlagen werden zusätzlich in eine Flächenbedeckung überführt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.67

- Niederschlagsform im stündlichen Detaildiagramm vereinheitlicht: WMO-Wettercode steuert nun Wettertext, Symbol, Balkenmuster, Legende und Stunden-Tooltip konsistent.
- Fehler behoben, durch den reiner Schneefall beziehungsweise Schneeschauer wegen des Wasseräquivalents im Feld `precipitation` fälschlich als Schneeregen oder Schneeregenschauer dargestellt wurde.
- Mischformen werden bei fehlendem geeigneten WMO-Code nur noch dann abgeleitet, wenn gleichzeitig ein messbarer fester und flüssiger Niederschlagsanteil vorliegt.
- Niederschlagsklassifikation in ein separat testbares Modul ausgelagert und mit Regressionstests für Schnee, Schneeschauer, Schneeregen, Schneeregenschauer, Regen und gefrierenden Regen abgesichert.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.66

- Bewölkungs-/Sonnenband im Temperaturtrend farblich an die Referenzskala angepasst: kräftiges Gelb für viel Sonne, abgestufte Beige-Töne und neutrales Grau für wenig Sonne.
- Die Bandfarbe wird ausschließlich aus der täglichen Best-Match-Sonnenscheindauer gebildet; ungültige oder physikalisch zu hohe Werte werden auf das lokale Intervall zwischen Sonnenauf- und Sonnenuntergang begrenzt.
- Ensembleabruf um `sunshine_duration` je Mitglied erweitert; tägliche Summen werden modellgewichtet zu P10, Mittel und P90 aggregiert. Modelle ohne diese Variable bleiben durch einen automatischen Fallback weiterhin für Temperatur und Niederschlag nutzbar.
- Tooltip ersetzt „Bewölkung“ durch die Best-Match-Sonnenscheindauer in Stunden sowie die P10–P90-Bandbreite in Stunden mit deutschem Dezimalformat und responsivem Zeilenumbruch.
- Kompakte Sonnen-/Wolken-Farbskala nach Referenzmuster direkt in die Diagrammlegende aufgenommen, ohne die Außenhöhe des Diagramms zu verändern.
- Regressionsprüfung um Best-Match-Datenpfad, Ensemble-Sonnenbandbreite, Tooltiptext und Farbskala ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.65

- Temperatur- und Niederschlagsdiagramm verwenden nun dieselbe symmetrische Tagesachse mit je einem halben Zeitschritt Abstand zu linker und rechter y-Achse; erste und letzte Werte liegen nicht mehr auf den Achsen.
- Abstand, Beschriftung und Innenränder der x-Achsen wurden vereinheitlicht; Bewölkungsband, Temperaturkurven, Niederschlagsbalken und Wahrscheinlichkeitskurve bleiben taggenau deckungsgleich.
- Einheitenfehler der hyperlokalen Windanalyse behoben: Bright-Sky/DWD-Windwerte werden von km/h nach kt umgerechnet, bevor sie mit dem in kt angeforderten Open-Meteo-Hintergrundfeld verrechnet werden.
- Zusätzliche zentrale Normalisierung fängt künftig sämtliche Stationsdatensätze mit `windUnit: kmh` vor Restfeldanalyse und robuster Mittelung ab.
- Regressionsprüfung um symmetrische Diagrammachsen, identische Achsenabstände und Stationswind-Normalisierung ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.64

- Tooltip und interaktive Temperaturlegende räumlich getrennt, sodass der Tooltip die Legende nicht mehr überdeckt.
- Temperatur- und Niederschlagsdiagramm zunächst auf ein gemeinsames Tagesraster ausgerichtet.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.63

- Buildfehler `TS2304: Cannot find name 'RainTooltip'` in der Ensemble-Niederschlagsgrafik behoben.
- Fehlende `RainTooltip`-Komponente wiederhergestellt und gegen nicht numerische beziehungsweise fehlende Diagrammwerte abgesichert.
- Semantische TypeScript-Prüfung der geänderten Ensemble-Komponente sowie die vorhandenen Updater-, Interaktions- und Radarprüfungen erfolgreich ausgeführt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.62

- Ensemble-Konsistenztooltips werden über ein viewportfestes Portal gerendert, an allen Bildschirmrändern automatisch eingerückt und nicht mehr durch horizontal scrollende Kartenbereiche abgeschnitten.
- Hover und Tastaturfokus öffnen den Konsistenztooltip unmittelbar; beim Verlassen schließt er automatisch, Touch/Klick bleibt ergänzend nutzbar.
- Im Diagramm „Temperaturtrend und Prognoseunsicherheit“ zeigt ein tägliches Bewölkungsband direkt oberhalb der x-Achse Grau für wenig Sonne bis Gelb für viel Sonne.
- Das Bewölkungsband wird aus der Best-Match-Sonnenscheindauer relativ zur astronomischen Tageslänge berechnet und im Diagrammtooltip zusätzlich erläutert.
- Höhe, Außenabstände und Achsenreserven des Temperaturdiagramms bleiben unverändert.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.61

- Tageswechsel im Desktop-Detaildiagramm bewahrt die ausgewählte Ortsstunde: Pfeil hoch springt zum Folgetag und Pfeil runter zum Vortag jeweils auf denselben stündlichen Zeitschritt; an Zeitumstellungstagen wird der nächstliegende vorhandene Stundenwert verwendet.
- Native Dropdownlisten übernehmen das aktive Hell-/Dunkel-Farbschema einschließlich expliziter Hintergrund- und Schriftfarben für Optionen und Optionsgruppen.
- Interaktionsprüfung um Regressionstests für Stundenerhalt beim Tageswechsel und Dropdown-Kontrast ergänzt.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

# MID v0.7.60

- Updatearchitektur bereinigt: nur noch ein zentral registrierter Service Worker; Installation und Aktivierung sind getrennt, der Seitenwechsel erfolgt erst nach `controllerchange` und anschließend cachefrei per `location.replace`.
- Such-/Favoritenbereich schließt zuverlässig bei Außenklick, Fokuswechsel, Escape, Ortswahl und über einen dauerhaft erreichbaren Schließen-Button.
- Ensemble-Konsistenzpunkte besitzen einen CSS-gesteuerten Hover-/Fokus-Tooltip, der ohne Klick erscheint und beim Verlassen automatisch verschwindet.
- Desktop-Detaildiagramm erhält native, nicht-passive Eingabehandler: Pfeil hoch/runter wechselt den Tag, Pfeil links/rechts und Mausrad wechseln stündlich.
- Radarabgleich korrigiert DWD-Kartenpixel durch GetFeatureInfo-Punktwerte auch bei scheinbar trockenem PNG-Pixel, begrenzt Teilabrufe, prüft Aktualität und 3-Stunden-Horizont und aktualisiert alle fünf Minuten sowie bei Sichtbarkeit/Fokus.
- GitHub-Pages-Build übernimmt explizite Radar-, Same-Origin- und Fallback-Worker-Endpunkte.
- Automatisierte Prüfungen für Updater, UI-Interaktionen und den konkreten DWD-Radarfehler ergänzt.

# MID v0.7.59

- Updateablauf stabilisiert: kein automatischer Reload beim Aktivieren der Option, keine Update-URL-Schleife und aktualisierter Service-Worker-Cache.
- Such-/Favoritenmenü schließt bei Klick außerhalb und mit Escape.
- Konsistenzpunkte zeigen ihren Tooltip bereits beim Hover/Fokus und schließen beim Verlassen.
- Desktop-Detaildiagramm: Pfeil hoch/runter wechselt tageweise; Mausrad navigiert stündlich.
- Radarabgleich mit Cache-Buster, Wiederholungsversuch und automatischer Aktualisierung alle fünf Minuten robuster gemacht.

# Changelog

## 0.7.59
- Widget: Der Wettertext erhält einen festen, zweizeiligen Bereich mit sauberem Umbruch; beide Textzeilen bleiben vollständig sichtbar und kollidieren nicht mehr mit den Temperaturwerten.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

## 0.7.55
- Desktop: Ansichtswahl aus der breiten Favoriten-/Suchspalte entfernt und als kompakte Auswahl direkt neben Suchfeld und Standortbutton platziert; auf schmalen Ansichten bleibt der gut bedienbare Segment-Schalter erhalten.
- Worker-Aufrufe verwenden nun mehrere konfigurierbare Endpunkte mit automatischem Failover, Zeitlimit und gespeichertem zuletzt erfolgreichen Endpunkt.
- Optionaler gleichursprünglicher Worker-Pfad und zusätzliche Fallback-Adressen schützen insbesondere gegen gesperrte `workers.dev`-Domains; vollständiger Schutz gegen lokale, DNS- oder Unternehmensnetz-Blockaden ist technisch nicht erzwingbar.
- METAR behält den direkten AviationWeather-Fallback; das Meteogramm fällt bei blockiertem Worker automatisch auf Open-Meteo direkt zurück.
- Warnungen, Radar-Nowcast, Kompositdaten, Blitz, 250-m-Radar und Modellkonturen melden nach Ausschöpfen aller Endpunkte eine eindeutige Blockade-/Netzwerkdiagnose.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

## 0.7.54
- Buildkorrektur: Typdeklaration für `import.meta.env` ergänzt, damit `src/pwa.ts` im GitHub-Workflow kompiliert.
- Buildkorrektur: ungenutzten Tageszeit-Helfer entfernt; TypeScript-Prüfung mit `noUnusedLocals` läuft wieder fehlerfrei.
- Tagesbeschreibung, Wetter-Icon und Tagescharakter werden konsequent aus denselben stündlichen Daten abgeleitet; die tägliche Sonnenscheindauer dient nur noch als schwacher Plausibilitätsfaktor.
- Bewölkte Stunden können dadurch nicht mehr zugleich zu einem unpassenden Tagescharakter wie „Heiter“ führen.
- Wettertexte besitzen feste, semantisch gekürzte Längenlimits: Haupttext maximal 30, Zusatztext maximal 28 Zeichen.
- Unnatürliche Zeitspannen wie „nachts bis abends“ entfallen; getrennte Ereignisfenster erscheinen kurz als „nachts/abends“, längere Verteilungen als „zeitweise“.
- Niederschlagswahrscheinlichkeiten werden nicht mehr doppelt im Beschreibungstext wiederholt, da sie bereits in den Tageswerten stehen.
- Cloudflare Worker ohne funktionale Änderung; nur einheitliche Versionsanhebung.

## 0.7.53
- PWA-Manifest, Apple-Web-App-Metadaten und vorsichtiger Service Worker mit Network-First für Navigation und version.json.
- Favoriten und Einstellungen werden zusätzlich in IndexedDB und Cache Storage gespiegelt und bei leerem localStorage automatisch wiederhergestellt.
- Wettercharakter und Icon werden vorrangig aus der stündlichen Tagesbewölkung abgeleitet; Sonnenstunden dienen nur noch als Plausibilitätsfaktor.
- Favoriten-Griff links zwischen Rand und Stern verlegt.
- Updater um Service-Worker-Aktualisierung ergänzt und durch automatisierten Konsistenztest geprüft.

## 0.7.52

- Wetter-Icons werden nun mit der vollständigen Tagesbeschreibung einschließlich Bewölkungstrend abgeglichen.
- Bei „Stark bewölkt, ab Mittag auflockernd“ erscheint ein Sonne-Wolken-Symbol statt einer reinen Sonne.
- „Heiter“ nutzt ein leicht bewölktes Sonnensymbol; „Heiter, später wolkiger“ und ähnliche Übergänge ein repräsentatives Mischsymbol.
- Niederschlags- und Gewittersymbole bleiben bei dominanten oder markanten Ereignissen vorrangig.

## 0.7.51

- Kurze Tagesbeschreibungen berücksichtigen nun markante Wetteränderungen im Tagesverlauf.
- Später einsetzende Schauer, Regen, Schnee oder Gewitter werden direkt mit Tageszeit genannt, z. B. „Sonnig, ab Nachmittag Schauer“.
- Deutliche Bewölkungstrends erscheinen knapp als „ab Mittag wolkiger“ oder „ab Mittag auflockernd“.
- Früh endender Niederschlag wird als Verlauf wie „Schauer am Morgen, später heiter“ beschrieben.

## 0.7.50

- Mobile Detailansicht ohne technische Kürzel wie „NS“ oder „NS-Wkt.“; stattdessen eindeutige Wetter-Symbole und kurze Klartextangaben.
- „UV“ und „UV-Index“ in der Oberfläche konsequent durch „UVI“ ersetzt.
- UVI-Werte werden für Standorte oberhalb von 500 m transparent näherungsweise höhenkorrigiert (+10 % je weitere 1000 m, gedeckelt auf +35 %).
- Die aktuelle UVI-Kachel weist eine aktive Höhenkorrektur samt Zuschlag und Standortshöhe aus.

# v0.7.46

## 0.7.49

- Tagescharakter der 7-Tage-Vorhersage präzisiert: Sonnenscheindauer, Tageslänge und effektive Tagesbewölkung werden gemeinsam bewertet.
- Statt pauschalem „Stark bewölkt“ erscheinen je nach Verhältnis nun kurze Abstufungen wie „Heiter“, „Wolkig, oft sonnig“, „Sonne und Wolken“, „Meist bewölkt“ oder „Bedeckt“.
- Mobile Detailansicht platzsparender beschriftet, unter anderem mit „Σ NS“, „max. NS-Wkt.“, „Temp.“ und „NS-Wkt.“ in der Legende.
- Desktop-Beschriftungen bleiben ausgeschrieben.

## 0.7.48

- Ansichtswahl direkt unter der Favoritenleiste als kompakte Auswahl „Kompakt“ oder „Vollständig“ mit Kurzbeschreibung.
- Höhenkachel aus den aktuellen Wetterdaten entfernt.
- Sonnenscheindauer der letzten Stunde als aktuelle Kennzahl ergänzt.
- Sonnenscheindauer platzsparend in die Tageswerte der 7-Tage-Vorhersage aufgenommen.

## 0.7.47

- Kompakte Startansicht als neuer Standard mit dauerhaft sichtbarer 7-Tage-Vorhersage.
- Stündliche Details der 7-Tage-Vorhersage sind in der kompakten Ansicht einblendbar.
- Kompositbild, 14-Tage-Ensemble, Meteogramm und Widget-Generator sind einklappbar und werden erst beim Öffnen vorbereitet.
- Modulzustände und gewählte Ansichtsart werden lokal gespeichert.
- Fallback-Schalter zur bisherigen vollständigen Ansicht ergänzt.


- Meteogramm-Höhenachsen: Flight Levels werden konsequent nach unten auf volle Zehner gerundet; hft-Angaben nach unten auf durch fünf teilbare Werte.

# 0.7.44 — stabiler heller Meteogramm-Export

- Problematischen geklonten Theme-Export entfernt.
- Meteogramm-PNG wird direkt aus dem sichtbaren Diagrammbaum in einem temporären, festen hellen Export-Theme erzeugt.
- iOS/Safari erhält damit keine leeren schwarzen oder weißen Exportbilder mehr.

## 0.7.42

- Theme-Auswahl um Auto erweitert; folgt der Betriebssystemeinstellung und reagiert live auf Systemwechsel.
- Bestehende Hell-/Dunkel-Auswahl bleibt gespeichert und kompatibel.

# v0.7.41

- Vollständiger TypeScript- und Worker-Check; ungenutzte Imports, Variablen und Hilfsfunktionen entfernt.
- `noUnusedLocals` und `noUnusedParameters` als dauerhafte Build-Prüfungen aktiviert.
- Versionsnummer zentral aus `package.json` synchronisiert (`src/version.ts`, `public/version.json`, Worker), um erneute Updater-Abweichungen zu verhindern.
- Überdimensioniertes Logo von 1672×941 auf 512×288 px reduziert; Darstellung bleibt bei maximal 42 px unverändert, Download- und Projektgröße sinken deutlich.
- Build-Abhängigkeit `@vitejs/plugin-react` korrekt in die Entwicklungsabhängigkeiten verschoben.
- Generierte lokale Build-Artefakte werden nicht mehr ausgeliefert. Keine Funktionsänderung am Worker.

## v0.7.40 – 2026-07-21

- Updater: lokale Laufzeitversion und veröffentlichte `version.json` werden wieder aus demselben Versionsstand erzeugt; die in v0.7.37 verbliebene interne Kennung v0.7.36 wurde korrigiert.
- Ensembles: P25–P75 besitzt in der Legende getrennte farbige Flächenfelder für Tmax und Tmin.

## v0.7.37 – 2026-07-21

- Ensembles: zusätzliches, etwas dunkleres P25–P75-Temperaturband für die Vorhersagetage 1–7; über die Legende ein- und ausblendbar.
- Ensemble-Aggregation liefert dafür gewichtete 25- und 75-Prozent-Quantile für Tagesminimum und Tagesmaximum.
- Kompositbild: aktive Layer (Niederschlag, 250-m-Radar, Satellit, Blitze und Modelllinienmodus) werden separat und dauerhaft im Browser gespeichert und beim nächsten Öffnen wiederhergestellt.
- Worker: keine funktionale Änderung; nur einheitliche Versionsanhebung.

# Changelog

## v0.7.37 — Meteogramm-Datenkonsistenz, exportfeste Linien und kompaktere Mobilkarten

- Fehlende API-Werte werden nicht mehr irrtümlich als `0` interpretiert; die Meteogrammzeitachse endet am letzten zusammenhängenden Boden- und Druckniveau-Datensatz.
- Best Match verwendet für das Druckniveau-Meteogramm eine durchgängige ECMWF-IFS-HRES-Zeitreihe, statt nach kurzer Regionalmodelllaufzeit leere Profilfelder zu erzeugen.
- Linien, Niederschlagsbalken, Schneehöhenkurve und Niederschlagsfarben werden im SVG direkt gesetzt und bleiben dadurch auch im iOS-PNG-Export sichtbar.
- QFF-Achsenwerte werden ohne Tausenderpunkt ausgegeben; die Schneehöhenachse entfällt vollständig, wenn keine messbare Schneehöhe vorliegt.
- Tagesbezeichnungen werden über dem jeweiligen Tagesabschnitt zentriert und überlappen am ersten unvollständigen Tag nicht mehr.
- Mobile 7-Tage-Kacheln enthalten unverändert alle Angaben, benötigen durch kleinere Abstände, kompaktere Typografie und eine flachere Temperaturzeile aber deutlich weniger Höhe.
- NOAA GFS für Druckniveauprofile auf die druckniveaugeeignete 0,25°-Variante vereinheitlicht.

## v0.7.35 — stabiler Meteogramm-Export, echte Tooltips und feste Satellitenstände

- Meteogramm-Export erzeugt nur noch eine PNG-Datei und sperrt Mehrfachauslösungen.
- Export verwendet `toBlob`, einen festen 1120-px-Arbeitsbereich, ein kompaktes Layout und blendet unsichtbare Interaktionsflächen aus.
- Diagramme besitzen sichtbare Hover-/Touch-Tooltips mit Zeit, Niveau und Messwerten.
- Modellabhängige Meteogramm-Laufzeiten werden bereits im Worker angefordert und im Frontend zusätzlich begrenzt.
- Satellitenraster werden während des Zoomens ausgeblendet und danach mit neuem Cache-Schlüssel vollständig geladen.

## v0.7.34 — Kompositkarte und Meteogramm-Feinschliff

- Aktivieren der Modelllinien verändert den Kartenausschnitt nicht mehr.
- Bodendruckzentren werden aus dem Modellfeld erkannt und als H beziehungsweise T mit Druckwert markiert.
- Satelliten-, Radar- und Blitzraster werden nach Zoomwechsel mit eindeutigem Layerstand neu aufgebaut; zeitlose Satellitenlayer werden, sofern möglich, auf den letzten exakten Produktzeitpunkt fixiert.
- Meteogramm-Isolinien dürfen wieder regulär am Diagrammrand oder an Datenlücken enden.
- Relative Feuchte farblich von trockenem Gelb bis feuchtem Grün abgestuft.
- Horizontale Hilfslinien auf sämtlichen Druckniveaus, Hauptflächen stärker hervorgehoben.
- Schneehöhenachse zeigt bei kleinen Werten passende Dezimalstellen statt gerundeter Doppelwerte.
- Worker funktional erweitert: Druckzentren und fixer letzter Satellitenzeitpunkt.

## v0.7.33 — Meteogramm-Konturen, Windfiedern und Download

- Unvollständige Isolinien an internen Datenlücken wurden verworfen; Konturen auf den Datenbereich begrenzt.
- Horizontale Hilfslinien auf ausgewählten Hauptdruckflächen.
- Relative Feuchte mit Isolinien im 20-Prozentpunkte-Raster.
- WMO-Windfiedern zur Herkunftsrichtung verlängert und Windstille als Kreis dargestellt.
- Tooltips für Profil-, Linien-, Niederschlags- und Risikodiagramme erweitert.
- Download mit „Speichern unter…“, System-Freigabe oder Browser-Fallback.
- Worker funktional unverändert; nur Versionsanhebung.


## v0.7.32 — Updater- und Modelllinien-Korrektur

- Zentrale Versionskonstante für App, Zusatzmodul und Meteogramm; der Updater vergleicht nicht mehr irrtümlich die aktuelle Veröffentlichung mit einer veralteten internen Versionsnummer.
- Modelllinien: ungültigen Parameter `elevation=nan` entfernt.
- Modelllinien-Raster weiterhin in kurzen Zeilenabfragen; maximal vier parallele Abrufe.
- Europa: ICON-EU bleibt erste Wahl, bei unvollständiger Modellabdeckung automatischer einheitlicher Fallback auf ICON Global.
- Nordamerika verwendet für Druckniveaukarten GFS 0,25° statt des Modells ohne benötigte Druckniveauvariablen.
- Upstream-Fehlermeldungen werden konkret ausgewertet statt nur als pauschales HTTP 400 angezeigt.

## 0.7.31

- Meteogrammprofile und optionale Risikoebenen vertikal gedreht: hohe Atmosphäre oben, Boden bzw. bodennahe Druckflächen unten
- Wind- und Böenachsen beginnen zwingend bei 0 kt; eingehende Windwerte werden defensiv auf nichtnegative Werte begrenzt
- Windpfeile für helle und dunkle Ansicht mit kontrastreicher Kontur neu gezeichnet
- Cloudflare Worker funktional unverändert, nur einheitliche Versionsanhebung

## 0.7.29

- Modelllinien auf großräumige, ortsabhängige Kartenausschnitte erweitert; für Standorte in Deutschland wird der europäische ICON-EU-Ausschnitt verwendet
- Konturen bilinear verdichtet, zu durchgehenden Pfaden verbunden und geglättet
- Isobarenabstand dynamisch auf 1, 2 oder 4 hPa nach dem Druckgradienten angepasst; Ziel ist eine auch bei schwachen Gradienten erkennbare Liniendichte von ungefähr 100 km
- 500-hPa-Isohypsen auf den meteorologischen Abstand von 8 gpdm umgestellt
- Konturbeschriftungen vergrößert, kontrastreicher gestaltet und entlang langer Linien wiederholt
- EuCom als DWD-Flugwetterprodukt geprüft; mangels öffentlicher, lizenzierter Abrufschnittstelle nicht in den öffentlichen Worker integriert

## v0.7.29

- neue, beim Start geschlossene Kachel „Meteogramm“ unmittelbar vor dem Widget-/PNG-Generator
- Modellauswahl mit Best Match sowie ausgewählten regionalen und globalen deterministischen Modellen
- siebentägiges beziehungsweise auf die verfügbare Modelllaufzeit begrenztes Vertikalprofil von Stationsniveau bis 300 hPa
- relative Feuchte als Höhen-Zeit-Querschnitt sowie kombinierte Temperatur-/Winddarstellung mit Richtungspfeilen
- zusätzliche Zeitreihen für 2-m- und 850-hPa-Temperatur, QFF, Wind/Böen sowie Niederschlag, Niederschlagsform und Schneehöhe
- optional einblendbare diagnostische Höhenbänder für Vereisung sowie Turbulenz/CAT; ausdrücklich nicht als amtliche Flugwetterprodukte gekennzeichnet
- Druckniveaus unterhalb des Geländes werden zeitabhängig ausgeblendet
- Meteogramm wird als eigener Lazy-Load-Chunk geladen; Modelldaten werden erst beim Öffnen der Kachel abgerufen und im Worker zwischengespeichert
- Cloudflare Worker um die Route `mode=meteogram` erweitert; Frontend und Worker einheitlich auf v0.7.29 angehoben

## v0.7.29

- Kompositfilm auf eine feste relative Achse von −1 Stunde bis +2 Stunden umgestellt; nicht vorhandene Layerstände werden weich ausgeblendet, reale benachbarte Frames überblendet.
- RainViewer-Metadaten über eine gecachte Workerroute angebunden; letzter realer Radarstand bleibt mit Zeitstempel sichtbar und wird ohne erfundene Zukunftsframes ausgefadet.
- Satelliten-Aktualitätsprüfung um einen Publikationspuffer erweitert; bis 150 Minuten Historie und verspätet veröffentlichte nominal ältere Bilder bleiben nutzbar.
- DWD-/MTG-LI-Blitzzeitachsen auf bis zu 130 Minuten Historie erweitert; Rasterfallback wird auch dann genutzt, wenn Punktdaten am ausgewählten historischen Zeitschritt fehlen.
- H-SAF-Satellitenniederschlagsrate als ergänzende Radarfläche integriert; automatischer MTG-H40B-Vorrang, sobald der Layer im öffentlichen EUMETView-WMS erscheint, mit MSG-H60B als aktuellem Fallback.
- Ortsabhängige Isobaren und 500-hPa-Isohypsen aus Open-Meteo Best Match ergänzt.
- Gemeinsame `CompositeTimeline`-Logik, Worker-Caching und Rendering von maximal zwei Blendframes reduzieren doppelte Berechnungen und Kartenlast.
- Frontend und funktional erweiterter Cloudflare Worker einheitlich auf v0.7.29 angehoben.

# Changelog

## v0.7.26

- 14-Tage-Ensemble: beide Diagramme verwenden nun dieselbe numerische Tagesachse; jeder Vorhersagetag besitzt in Temperatur- und Niederschlagsdiagramm exakt dieselbe x-Koordinate, unabhängig von Balken oder zweiter y-Achse.
- Widget-Export in „in Zwischenablage kopieren“ umbenannt.
- Hochauflösendes Radar: aktuelles nationales DWD-HX-Komposit mit 250-m-Raster als erste Wahl für Deutschland integriert; PX250 bleibt als Standort-Fallback erhalten.
- Große HX-HDF5-Raster werden speicherschonend und geräteabhängig gerendert, ohne die native Quellenauflösung falsch auszuweisen.
- Frontend und funktional erweiterter Cloudflare Worker einheitlich auf v0.7.26 angehoben.

## v0.7.25

- Niederschlag 1 km und Niederschlag 250 m als gegenseitig ausschließende Auswahl mit einheitlicher Benennung umgesetzt.
- Veraltete PX250-Metadaten und HDF5-Dateiverweise in Frontend und Worker doppelt abgesichert; PX250 beeinflusst keine fremde Kompositzeitachse mehr.
- Zeitvalidierung für Radar, Satellit und Blitz gegen eine plausible Worker-Serverzeit gehärtet und WMS-Abrufe außerhalb der zulässigen Live-/Nowcast-Fenster blockiert.
- Satellitenlayer werden je tatsächlichem Produktzeitpunkt neu geladen; Quellen ohne verlässliche Zeitdimension verwenden den echten neuesten Stand ohne erfundene Uhrzeit.
- Blitzringe auf eine Blitzortung-inspirierte Altersfarbskala in 20-Minuten-Stufen von Weiß bis Dunkelrot umgestellt; Blitzortung selbst wird wegen der Zugriffs- und Weitergabebedingungen nicht als Rohdatenquelle integriert.
- Frontend und funktional erweiterter Cloudflare Worker einheitlich auf v0.7.25 angehoben.

## v0.7.24

- Fehlerhafte Kompositzeiten behoben: Worker-Zeitwerte werden unabhängig davon korrekt verarbeitet, ob sie als ISO-Zeit, Unix-Sekunden oder Epoch-Millisekunden eintreffen; die bisherige Vermischung von Sekunden und Millisekunden kann keine Werte wie „−5555 min“ mehr erzeugen.
- Künstlich erzeugte Radarzeitpunkte entfernt. DWD-Radar, Satellit und Blitzraster werden nur noch mit Zeitstempeln abgefragt, die der konkrete Produktlayer tatsächlich in seinen WMS-Capabilities meldet.
- Leere Radar- und Satellitenkarten behoben: DWD- und EUMETSAT-WMS-Kacheln werden CORS-sicher über den Cloudflare Worker ausgeliefert; beim DWD bleibt der offizielle Ausfallserver als Rückfall aktiv.
- DWD-RV verwendet bevorzugt den expliziten 1-km-RV-Layer und stellt – soweit von der Quelle vorhanden – ausschließlich das reale Fenster von relativ −1 Stunde bis +2 Stunden bereit.
- Satellitenquelle wird anhand der aktuell wirklich verfügbaren Produktzeiten gewählt: bevorzugt hochaufgelöstes MTG-FCI, anschließend MSG-HRV/IR und zuletzt ein aktuelles DWD-Meteosat-Produkt. Bei einem fehlerhaften Tagesbild wechselt MID automatisch auf das IR-Produkt.
- Relative Zeitangabe bezieht sich jetzt auf die aktuelle Uhrzeit; Ortszeit und Prognosekennzeichnung stehen separat darunter. Produktzeiten außerhalb von −1 h bis +2 h werden verworfen.
- Worker-Antwort `composite-times` um reale DWD-Radarzeiten, verwendeten Radar-Layer und Serverzeit ergänzt; WMS-Proxy auf freigegebene Layer und valide Zeitstempel begrenzt.
- Frontend und funktional erweiterter Cloudflare Worker einheitlich auf v0.7.24 angehoben.

## v0.7.23

- Kompositbild um einen kleinen „Locate Me“-Button ergänzt, der die verschobene Karte animiert auf den gewählten Standort zurückführt, ohne Zoomstufe oder Layerauswahl zurückzusetzen.
- Höhenkonfiguration des Berg-/Skimodus auf direkt editierbare Meterfelder mit Mobil-Zifferntastatur, zuverlässigem Zwischenzustand und zusätzlichen ±50-m-Schaltflächen umgestellt.
- Tal- und Gipfelwerte weisen die verwendete Höhe nun ausdrücklich in m ü. NHN aus; aktuelle und zeitliche Gipfelprognosen zeigen Temperatur und gefühlte Temperatur gemeinsam.
- Bezeichnung „Schneegrenze“ im Berg-/Skimodus fachlich zu „Schneefallgrenze“ präzisiert.
- Auto-Standort in Schnellzugriff, Suche und Favoritenverwaltung einheitlich von „1. Standort“ zu „Standort“ umbenannt.
- Temperatur- und Niederschlagsdiagramm des 14-Tage-Ensemble-Trends verwenden identische feste Achsenreserven. Das Ein-/Ausblenden der Niederschlagswahrscheinlichkeit verändert damit nicht mehr die horizontale Position der Vorhersagetage.
- Frontend und funktional unveränderter Cloudflare Worker einheitlich auf v0.7.23 angehoben.

## v0.7.22

- Widget- und PNG-Generator um einen direkten PowerPoint-Export erweitert: hochauflösendes PNG wird per Clipboard API kopiert; bei fehlender Browserfreigabe erscheint ein kopierbares Rechtsklick-/Long-Press-Fallbackbild.
- Layerauswahl, Kartenbasis und individuelle Deckkräfte für Niederschlag, Satellit und Blitze dauerhaft gespeichert; Deckkraftregler dynamisch auf aktive Layer begrenzt.
- Gemeinsame Komposit-Zeitachse auf reale verfügbare Produktzeiten begrenzt und bis ungefähr ±1 Stunde erweitert, wo Radar-Nowcast beziehungsweise Historie dies erlauben; Übergänge zwischen Kartenframes geglättet.
- Ortsabhängige Auflösungspriorität dokumentiert und umgesetzt: PX250 250 m, DWD-RV 1 km, OPERA 2 km, anschließend RainViewer.
- Optionalen weltweiten Vaisala-Xweather-/GLD360-Blitzpunktabruf im Worker ergänzt; freie Fallbacks bleiben DWD und EUMETSAT MTG-LI. Blitzpunkte werden als alterscodierte, skalierte Ringe statt gefüllter Kreise dargestellt.
- Favoriten können nun direkt in der Schnellzugriffsleiste auf der Startebene per Maus sowie Touch/Pointer verschoben werden.
- Frontend und funktional erweiterter Cloudflare Worker einheitlich auf v0.7.22 angehoben.

## v0.7.21

- DWD-PX250-Abruf vom direkten Browserzugriff auf einen CORS-sicheren Worker-Proxy umgestellt; Verfügbarkeitsprüfung und HDF5-Datei werden über neue Worker-Modi bereitgestellt.
- Sichtbare Radarpriorität korrigiert: DWD-RV, danach EUMETNET OPERA/ORD als europäischer Erst-Fallback und erst anschließend RainViewer. OPERA erhält eine eigene Kartenvisualisierung als RATE-Punktraster.
- Kartenbasis um CARTO Positron und CARTO Dark Matter ergänzt; Auswahl wird je Browser gespeichert.
- DWD-Blitzgeometrien als zeitcodierte, mit zunehmendem Alter verblassende Kreise ergänzt; DWD-Blitzdichte und EUMETSAT MTG-LI bleiben als robuste Raster-Fallbacks erhalten.
- Kompositlegende verschlankt und dynamisch an die aktiven Radar-, Satelliten- und Blitzlayer angepasst.
- Favoritenreihenfolge über einen dedizierten Drag-&-Drop-Griff einschließlich Touch-/Pointer-Unterstützung änderbar; Pfeilnavigation bleibt erhalten.
- Frontend und funktional erweiterter Cloudflare Worker einheitlich auf v0.7.21 angehoben.

## v0.7.20.2

- Die bisherige Niederschlagsradarkachel heißt nun **Kompositbild** und besitzt getrennte Schalter für Niederschlag, natives DWD-PX250-Radar, hochaufgelöste MTG-FCI-Satellitenbilder und MTG-LI-Blitzaktivität.
- DWD-PX250 wird nur angeboten, wenn der gewählte Standort innerhalb der etwa 150-km-Reichweite eines passenden Radarstandorts liegt und eine aktuelle HDF5-Datei verfügbar ist. Die native Rasterweite beträgt 250 m; die Datei wird erst nach Aktivierung geladen und im Browser gerendert.
- Tagsüber verwendet die Satellitenebene den sichtbaren MTG-FCI-HRFI-Kanal VIS 0,6 mit nominal 0,5 km am Nadir; nachts wird automatisch IR 10,5 mit nominal 1 km verwendet. Bei einem nicht verfügbaren Tageslayer fällt MID auf IR zurück.
- Echtzeit-Blitzaktivität verwendet in Deutschland die DWD-NowCastMIX-Blitzdichte im 1-km-Raster mit 5-Minuten-Aktualisierung; außerhalb dient EUMETSAT MTG-LI AFA im 2-km-Raster als NRT-Fallback. Die Anzeige ist keine metergenaue Bodeneinschlagskarte.
- Radarfilm und Nowcast bleiben für DWD-RV beziehungsweise RainViewer erhalten; PX250 ist bewusst ein aktueller hochaufgelöster Einzelstand ohne künstliche Zukunftsframes.
- Frontend und Worker einheitlich auf v0.7.20.2 angehoben; der Worker erhält ausschließlich die neue Versionskennung und bleibt funktional unverändert. `jsfive` wird als eigener Lazy-Load-Chunk erst für PX250 geladen.

## v0.7.20.1

- Angaben zu Temperaturabweichungen, Temperaturunsicherheit und lokaler Modellkorrektur werden nun fachlich korrekt in Kelvin (K) statt in Grad Celsius ausgegeben.
- Absolute Temperaturen bleiben unverändert in Grad Celsius (°C).
- Frontend und kompatibler Cloudflare Worker auf v0.7.20.1 angehoben.

## v0.7.20

- Modellgestützte hyperlokale Analyse für aktuelle Temperatur, relative Feuchte, Taupunkt, QFF sowie Wind und Böen ergänzt.
- Offizielle DWD-Open-Data-Beobachtungen werden über Bright Sky an mehreren Suchpunkten gesammelt; dadurch stehen mehr DWD-Messpunkte als nur die nächste WMO-/METAR-Station zur Verfügung.
- openSenseMap-/senseBox-Außenmessungen als offene Citizen-Science-Zusatzquelle integriert; sie werden wegen uneinheitlicher Aufstellung nur mit geringer Gewichtung und nach strengen Aktualitäts-, Wertebereichs- und Ausreißerprüfungen verwendet.
- Synoptic Data nutzt nun die vollständige `synopticlabs`-QC-Suite mit grundlegenden und erweiterten Prüfungen.
- Stationswerte werden nicht direkt höhenkorrigiert gemittelt: MID ermittelt an jeder Station die Abweichung zum dortigen Open-Meteo-Best-Match-Hintergrund und interpoliert nur diese lokalen Restfelder zum Zielort.
- Gewichtung berücksichtigt Entfernung, Höhenunterschied, Messalter, Netzqualität, Stationsanzahl sowie Stadt-/Umland-/Land-Kompatibilität; private und Citizen-Science-Netze erhalten kürzere Reichweiten und strengere Altersgrenzen.
- Aktuelle-Wetter-Anzeige nennt nun effektiven Analyseradius, Temperaturunsicherheit, lokale Modellkorrektur und beteiligte Netze.
- Cloudflare Worker und Frontend auf v0.7.20 aktualisiert.

## v0.7.19

- Wassersportmodus als aktivierbares Favoritenprofil ergänzt.
- Open-Meteo Marine Best Match für Meeresoberflächentemperatur, Wellenhöhe/-richtung/-periode, Peak-Periode, Windsee, Dünung, Strömung und Wasserstand inklusive Tide integriert.
- modellierte Hoch-/Tiefpunkte, Wasserstandstendenz und 24-Stunden-Spanne ergänzt; nautische Einschränkungen werden deutlich ausgewiesen.
- Wetter-, Sicht-, UV-, Niederschlags- und Gewitterparameter mit konfigurierbaren Schwellen für Wellen, Böen und Kaltwasser kombiniert.
- See- und Flussprofile ersetzen fehlende Binnengewässerdaten nicht durch entfernte Meeresgitter.
- Wassersportmodul wird nur bei aktivem Profil und erst beim Scrollen geladen; Favoritenexport auf Schema-Version 4 angehoben.
- Frontend und kompatibler Worker auf v0.7.19 aktualisiert.


## v0.7.18

- Initiales Laden deutlich verkleinert: Leaflet/Radar und Recharts/Ensembletrend sind in eigene dynamische Chunks ausgelagert und werden erst bei Annäherung an den sichtbaren Bereich geladen.
- Widgetwerkzeuge bleiben bis zum Aufklappen inaktiv; `html-to-image` wird ausschließlich beim tatsächlichen PNG-Export nachgeladen. Der Berg-/Skimodus bleibt an ein aktiviertes Favoritenprofil gebunden.
- Datenabrufe priorisiert: Best Match wird zuerst angezeigt; Stationsdaten, Luftqualität, Radar, Warnungen und Modellstände folgen anschließend. Klimatologie und Ensembles starten erst beim Ensemblebereich.
- Detaildiagramm um eine markante dynamische Jetzt-Linie mit ortslokaler Uhrzeit ergänzt; Position und Beschriftung werden alle 30 Sekunden aktualisiert.
- GeoSphere/TAWES-Druckverarbeitung gehärtet: `PRED` und Stationsdruck `P` werden getrennt, QFF wird höhen- und differenzbezogen plausibilisiert und Werte wie 854 hPa in Sölden werden als Stationsdruck erkannt beziehungsweise verworfen.
- Fehlt ein plausibler TAWES-QFF-Wert, verwendet MID konsequent Open-Meteo `pressure_msl`; der Worker liefert den Rohdruck nur noch separat.
- Frontend und Worker auf v0.7.18 aktualisiert.

## v0.7.17

- Mobile Kopfzeile korrigiert: Die Ortssuche nutzt wieder die vollständige verfügbare Breite und kann nicht mehr auf ein schmales Symbolfeld zusammenschrumpfen.
- Favoriten stehen unmittelbar unter der Suchleiste wieder als einzelne horizontal scrollbarere Bubbles; der dynamische „1. Standort“ und die Verwaltungs-Schaltfläche bleiben integriert.
- Widget- und PNG-Generator ist beim Laden standardmäßig eingeklappt und lässt sich über eine kompakte Schaltfläche öffnen.
- Österreichische TAWES-Druckdaten werden ausschließlich über `PRED` (reduzierter Luftdruck) als Meereshöhendruck/QFF übernommen; der Stationsdruck `P` wird nicht mehr versehentlich angezeigt.
- METAR-QNH und nicht eindeutig reduzierte Stationsdrücke werden nicht als QFF ausgegeben; in diesem Fall fällt MID auf Open-Meteo `pressure_msl` zurück.
- Frontend und kompatibler Workerstand auf v0.7.17 aktualisiert.

## v0.7.16

- Optionale Standortverfolgung als **„1. Standort“** ergänzt: Bei jedem Öffnen wird die aktuelle Geräteposition neu bestimmt und als erster Schnellzugriff angeboten.
- Standardort und zuletzt verwendeter Ort bleiben als Fallback erhalten, falls die Browser-Ortung nicht verfügbar oder nicht erlaubt ist.
- Favoriten-Schnellzugriff direkt unter das Suchfeld verlegt und nach den frei vergebenen Favoritengruppen geordnet.
- Leeres Suchfeld zeigt den aktuellen Standort sowie gruppierte Favoriten ebenfalls in derselben Reihenfolge.
- Berg-/Skimodus wird nun ausschließlich pro Favorit in der Favoritenverwaltung aktiviert; Tal- und Gipfelhöhe werden dort konfiguriert.
- Die deaktivierte Berg-/Ski-Hinweiskarte und die Höhen-Eingabefelder im Dashboard wurden entfernt, sodass der Modus ohne Aktivierung keinen Platz beansprucht.
- Favoriten-JSON auf Schema-Version 3 erweitert; Standortverfolgung und Berg-/Ski-Konfiguration werden exportiert, importiert und aus älteren Einträgen migriert.
- Frontend und kompatibler Workerstand auf v0.7.16 aktualisiert.

## v0.7.15

- Favoriten Phase 2: eigene Anzeigenamen, Gruppen, sortierbare Reihenfolge, Standardort, horizontaler Schnellzugriff und lokale Regeln je Favorit.
- Favoriten lassen sich als versionierte JSON-Datei exportieren und wieder importieren; bestehende v0.7.14-Favoriten werden automatisch migriert.
- Neuer optionaler Berg- & Skimodus mit explizitem Tal-/Gipfel-Höhenvergleich über Open-Meteo, Nullgradgrenze, angenäherter Schneegrenze, Sicht, angenäherter Wolkenuntergrenze, Windchill, Gipfeltrend und Tageslicht-Orientierung.
- Amtliche Lawinenlage wird über den zuständigen europäischen Warndienst verlinkt; alle abgeleiteten Bergindikatoren sind klar als Orientierung gekennzeichnet.
- Beschreibung der Sonnenschein-/Bewölkungsbalken auf das Wesentliche gekürzt und „Tageslicht“ durch „Tagsüber“ ersetzt.
- DWD-Radarkarte wird nur noch dargestellt, wenn die Standortauswertung tatsächlich DWD-RV als Quelle bestätigt; ansonsten erscheint die RainViewer-Kartenebene mit OPERA-/RainViewer-Standortauswertung.
- DWD-Gebietserkennung des Workers an den aufgelösten Ländercode Deutschland gebunden; außerhalb davon werden OPERA/ORD beziehungsweise RainViewer verwendet.
- Frontend und Worker auf v0.7.15 aktualisiert.

## v0.7.14

- Erstes Farbschema orientiert sich ohne vorhandene Nutzereinstellung automatisch am Hell-/Dunkelmodus des Geräts (`prefers-color-scheme`); eine manuell gewählte MID-Einstellung bleibt gespeichert.
- Radarsteuerung auf ein überlaufsicheres Raster umgestellt; der Regler für die Radar-Deckkraft liegt auf Desktop und Mobil vollständig in einer eigenen Zeile.
- Favoriten-Grundfunktion ergänzt: Der aktuelle Ort oder POI kann über einen Stern gespeichert beziehungsweise entfernt werden.
- Gespeicherte Favoriten werden lokal im Browser abgelegt und beim Fokussieren des leeren Suchfelds direkt zur Auswahl angeboten.
- Frontend und kompatibler Workerstand auf v0.7.14 aktualisiert.

## v0.7.13

- Laufender Niederschlag erhält eine belastbare Endzeit aus dem ersten dauerhaft trockenen DWD-Nowcast-Zeitfenster; einzelne trockene Zwischenframes beenden ein Ereignis nicht vorschnell.
- Bleibt Niederschlag bis zum Ende des verfügbaren Radarhorizonts bestehen, kennzeichnet MID die Zeit als „mindestens bis …“ statt ein scheinbar exaktes Ende auszugeben.
- Ohne ausreichend zukünftige Radarframes wird transparent angezeigt, dass noch keine belastbare Endzeit ableitbar ist.
- „Regenradar“ in „Niederschlagsradar“ umbenannt.
- DWD-Zeitdimension robuster aus den WMS-Capabilities gelesen, einschließlich geerbter Zeitdimensionen übergeordneter Layer.
- Mobile Radarsteuerung neu aufgebaut: vorheriger/nächster Zeitschritt, Play/Pause, fortlaufende Radarfilm-Wiedergabe und klarer Frame-Zähler.
- Bei nur einem gelieferten DWD-Zeitpunkt wird die offizielle 5-Minuten-Zeitachse um den validierten Beobachtungszeitpunkt ergänzt, sodass die WMS-Animation mobil bedienbar bleibt.
- DWD-Legende kompakter, ruhiger und besser lesbar gestaltet; sie verdeckt auf kleinen Bildschirmen weniger Kartenfläche.
- Cloudflare Worker und Frontend auf v0.7.13 aktualisiert.

## v0.7.12

- DWD-Auswertung von einer reinen Raster-`GetFeatureInfo`-Abfrage auf eine robuste Kombination aus WMS-`GetMap`-Pixelanalyse und optionaler Punktwertverfeinerung umgestellt.
- Ein transparenter DWD-Kartenpixel wird als erfolgreicher trockener Radarwert (`0 mm/h`) gewertet; nur ein technisch fehlgeschlagener Kartenabruf löst einen Quellen-Fallback aus.
- WMS-Capabilities werden am allgemeinen DWD-Endpunkt geladen und die Zeitdimension gezielt aus dem Block des tatsächlich verwendeten Radarlayers gelesen.
- Der stabile Alias `dwd:Niederschlagsradar` wird vor dem konkreten RV-Layer verwendet; Primär- und Backup-Geoserver bleiben erhalten.
- Zentrum und Umgebung werden aus derselben Radar-PNG ausgewertet. Dadurch sinkt die Zahl externer Worker-Unterabfragen, während trockene und nasse Standorte zuverlässig unterscheidbar bleiben.
- Auffällige `GRAY_INDEX`-Werte werden mit dem sichtbaren Kartenpixel plausibilisiert und können nicht mehr allein als extreme Niederschlagsrate übernommen werden.
- DWD-Radarlegende als kompakte, kontrastreiche MID-Leseskala mit mm/h-Stufen und Intensitätsklassen neu gestaltet.
- Cloudflare Worker und Frontend auf v0.7.12 aktualisiert.

## v0.7.11

- DWD-Radarzeitachse wird aus der tatsächlichen WMS-Zeitdimension statt aus geratenen Fünf-Minuten-Zeitpunkten übernommen.
- DWD-GetFeatureInfo nutzt Primär- und Backup-Geoserver sowie den stabilen Alias `dwd:Niederschlagsradar` als Fallback.
- Radar-Unterabfragen wurden deutlich reduziert, damit Cloudflare-Subrequest-Limits nicht überschritten werden.
- Trockene Radarwerte (`0 mm/h`) gelten nun ausdrücklich als erfolgreiche DWD-Auswertung und nicht als fehlende Abdeckung.
- Die Radar-Karte übernimmt die exakten verfügbaren DWD-Zeitstempel aus der Standortanalyse.
- Bei einem temporären Quellenfehler wird zwischen vorhandener Radarabdeckung und tatsächlich fehlender Abdeckung unterschieden.

## 0.7.10

- DWD-RV-GetFeatureInfo strikt auf den tatsächlichen Niederschlagswert beschränkt; Zeitstempel und andere numerische Metadaten können nicht mehr als Radarintensität fehlinterpretiert werden.
- DWD-RV-Werte werden entsprechend der WMS-Einheit direkt als mm/h verwendet und nicht erneut heuristisch hochskaliert.
- Fehlwerte und unplausible Radarwerte oberhalb des technischen Plausibilitätsbereichs werden verworfen.
- Extremwerte werden ohne irreführende Zehntelgenauigkeit als extremes Radarecho bzw. > 50 mm/h gekennzeichnet; isolierte Spitzen erhalten einen Unsicherheitshinweis.
- Ankunfts-, Datenstands- und Endzeiten werden in der Ortszeitzone in Klammern ergänzt; der +120-Minuten-Horizont kann nicht mehr als 120–130 Minuten ausgegeben werden.
- RainViewer-Intensität aus der offiziellen Universal-Blue-Palette statt aus einer fehleranfälligen Alpha-Heuristik angenähert; Reflektivitäten unter 10 dBZ werden nicht als Niederschlag gewertet.
- Ein Echo in der Umgebung wird nicht mehr automatisch als sicherer Standorttreffer formuliert; Mittelpunkt und Umgebung werden getrennt bewertet.
- Radarlegende automatisch an die dargestellte Ebene angepasst: offizielle DWD-RV-Legende beziehungsweise RainViewer Universal Blue in dBZ.
- Cloudflare Worker auf v0.7.10 aktualisiert.

## 0.7.9

- Aktuelle Niederschlagswahrscheinlichkeit um eine standortbezogene Radar-Nowcast-Auswertung ergänzt.
- Quellenpriorität: DWD-RV in Deutschland, EUMETNET OPERA/ORD in Europa, RainViewer als globaler Fallback, anschließend Open-Meteo Best Match.
- DWD-Zukunftsframes bis +120 Minuten werden direkt ausgewertet; OPERA und RainViewer erhalten eine eigene räumlich-zeitliche Bewegungsnäherung aus zurückliegenden Frames.
- Dynamische Radar-/Modellgewichtung nach Vorlaufzeit und Datenqualität umgesetzt.
- Radarquellen, Qualitätsstufe, aktuelle Intensität sowie grobe Ankunfts- und Endzeit werden kompakt in der vorhandenen Niederschlagskachel angezeigt.
- OPERA-Kompositprodukte werden mit CC-BY-4.0-Hinweis verwendet; RainViewer bleibt ausdrücklich als best-effort Fallback gekennzeichnet.
- Cloudflare Worker auf v0.7.9 erweitert (`mode=radar-nowcast`).

## 0.7.8
- Standortbezogene Zeitzonenlogik für automatische Stundenwahl, Kurzfristniederschlag, Radar, amtliche Warnungen, Tagesdiagramm, Sonnenauf-/untergang und Widget.
- Stündliche und 15-minütige Open-Meteo-Zeitstempel werden mit der IANA-Zeitzone des Zielorts in echte Zeitpunkte überführt.
- Datumsbeschriftungen verwenden den lokalen Kalendertag des Vorhersageorts und können nicht mehr durch die Gerätezeitzone verschoben werden.
- Ortssuche um OpenStreetMap/Photon-POIs erweitert, einschließlich Berggipfeln, Hotels, Hütten und Sehenswürdigkeiten.
- POI-Typ und OpenStreetMap-Herkunft werden kompakt in den Suchtreffern gekennzeichnet.

## 0.7.7

- Nachtstunden im Tages-Detailansichtsdiagramm vor Sonnenaufgang und nach Sonnenuntergang dezent diagonal schraffiert
- orts- und tagesgenaue Sonnenauf- und Sonnenuntergangszeiten unmittelbar an den Übergängen im Diagramm eingeblendet
- Darstellung ohne zusätzliche Karten- oder Diagrammhöhe umgesetzt
- bestehende Sonnenschein-/Bewölkungsbalkenlogik für Tageslicht und Nacht unverändert beibehalten

## 0.7.6

- Ursache der falschen Jahresdarstellung „5026“ beseitigt: Versionsnummern werden nur noch in Texten mit vorangestelltem `v` ersetzt
- Datumsangaben bei „Aktualisiert“, im Widget und im Update-Hinweis gegen unbeabsichtigte Versionsersetzung abgesichert
- Nachtlogik der Sonnenschein-/Bewölkungsbalken überarbeitet: bei klarem Himmel kein Balken, bei Bewölkung ausschließlich Grau
- Tageslogik beibehalten und feiner skaliert: unter 50 % Bewölkung Gelb, ab 50 % Grau; Linienstärke jeweils proportional in vier Stufen
- Tag/Nacht weiterhin aus der stündlichen Open-Meteo-Angabe `is_day` abgeleitet

## 0.7.5

- platzsparende Modellstand-Information in den Titelzeilen der 7-Tage- und 14-Tage-Ansicht ergänzt
- Open-Meteo-Metadaten für Init- und Verfügbarkeitszeit geeigneter deterministischer und tatsächlich aktiver Ensemblemodelle eingebunden
- Best Match ehrlich als automatische, je Ort, Variable und Horizont wechselnde Modellkombination gekennzeichnet
- wahrscheinliche Quellenkette regionaler und globaler Modelle separat als Schätzung ausgewiesen
- Modellstände in einem aufklappbaren Popover dargestellt, sodass im geschlossenen Zustand nahezu kein zusätzlicher Platz benötigt wird

## 0.7.4

- Detaildiagramm am Desktop fokussierbar gemacht
- Navigation mit Pfeiltaste links und rechts nach einem Klick in die Diagrammfläche ergänzt
- bestehende Stundenlogik einschließlich automatischem Wechsel zum vorherigen oder nächsten Tag wiederverwendet
- Standard-Scrollverhalten nur bei aktivem Diagrammfokus und nur für die horizontalen Pfeiltasten unterdrückt
- visuellen Fokusrahmen für die Tastaturbedienung ergänzt

## 0.7.3

- flächigen Bewölkungsverlauf im Tagesdetail durch eine horizontale Balkenzeile direkt unter den Wetterpiktogrammen ersetzt
- sonnige beziehungsweise überwiegend klare Phasen gelb dargestellt; größere Linienstärke bedeutet klareren Himmel
- bewölkte Phasen grau dargestellt; größere Linienstärke bedeutet stärkere Gesamtbewölkung
- vier Linienstärken für beide Zustände ergänzt und gelbe Sonnenscheindarstellung auf Tagesstunden begrenzt
- kompakte Legende und Erläuterung der Balkenlogik ergänzt

## 0.7.2

- Verlauf der Gesamtbewölkung im Tagesdetail in einen eigenen oberen Diagrammbereich über der Temperaturkurve verschoben
- Temperatur- und Niederschlagsbereiche des Detaildiagramms für eine klare vertikale Trennung neu angeordnet
- `version.json` als cache-frei abgerufene Quelle für die veröffentlichte MID-Version ergänzt
- automatischer Versionsvergleich beim Start mit Hinweis „MID wurde aktualisiert – jetzt neu laden“
- optionale, lokal gespeicherte automatische Neuladung bei künftigen Updates ergänzt
- Versionsprüfung bei Rückkehr aus dem Hintergrund, bei `pageshow`, bei Fokus und regelmäßig während der Nutzung ergänzt
- Cache-Busting beim Neuladen verhindert, dass eine installierte iOS-Web-App erneut den alten Einstiegspunkt öffnet
- Koordinatensuche ergänzt die Geländehöhe über Open-Meteo; das Widget verwendet zusätzlich die Vorhersagehöhe als Rückfall und zeigt nicht mehr fälschlich 0 m an
- Widget-Auswahl für Tage, Layout, Wind, Niederschlag und Hazards wird direkt im React-Zustand aus dem lokalen Speicher wiederhergestellt und bei jeder Änderung gespeichert

## 0.7.1

- alle wesentlichen Reihen der 14-Tage-Temperatur- und Niederschlagsdiagramme lassen sich direkt über die Legende einzeln ein- und ausblenden; die Auswahl wird lokal gespeichert
- Tagesdetaildiagramm um einen kompakten stündlichen Verlauf der Gesamtbewölkung einschließlich Wert der gewählten Stunde ergänzt
- Abruf amtlicher Warnungen für Desktop-Browser durch CORS-sicheren Neuversuch, HTTPS-Normalisierung, Cache-Umgehung und verständlichere Fehlermeldung stabilisiert
- Ortssuche akzeptiert Dezimalkoordinaten, deutsche Dezimalkommas sowie N/S/E/W-Angaben und ergänzt den Ortsnamen per Reverse-Geocoding
- Widget-/PNG-Generator speichert Tage, Layout und sichtbare Parameter; angezeigter Ortsname und PNG-Dateiname können je Standort angepasst werden
- Fehler bei der GeoSphere-GeoJSON-Zuordnung behoben: `properties.station` wird nun als Stations-ID erkannt
- GeoSphere Austria/TAWES zusätzlich serverseitig in den gemeinsamen Cloudflare Worker integriert
- Worker nutzt bei nicht verfügbaren Detailparametern automatisch einen reduzierten TAWES-Parametersatz
- mehrere passende österreichische Stationen werden im Frontend robust und höhengewichtet zusammengeführt
- Windwerte aus dem direkten TAWES-Abruf werden vor der Stationsmittelung korrekt von m/s in kt umgerechnet
- METAR- und Stationszeitstempel aus ISO-Text, Unix-Sekunden oder Unix-Millisekunden werden einheitlich normalisiert
- Worker-Diagnose ergänzt GeoSphere Austria einschließlich `sourceRows` und möglicher Abruffehler

## 0.7.0

- optionale hyperlokale Stationsnetze Netatmo, Synoptic Data und Xweather zusätzlich zu Weather Underground integriert
- weiterhin nur ein gemeinsamer Cloudflare Worker für Stationsdaten und amtliche Warnungen erforderlich
- aktuelle Beobachtungen aus mehreren geeigneten Stationen werden entfernungs-, höhen-, aktualitäts-, QC- und anbietergewichtet zusammengeführt
- robuste Median-/Abweichungsfilter entfernen einzelne Stationsausreißer vor der Mittelung
- zirkuläre Mittelung der Windrichtung ergänzt
- Stationsanzeige nennt Anzahl und Quellen des lokalen Mittels sowie die Temperaturstreuung
- ENS-Mittel für Tmin/Tmax im 14-Tage-Diagramm über die Legende ein- und ausblendbar
- klimatologisches Tmin-/Tmax-Mittel 1991–2020 aus ERA5-Land ergänzt und über die Legende schaltbar
- Klimadaten werden kalendertagsbezogen verdichtet und 180 Tage lokal zwischengespeichert
- Worker-Gesundheitstest zeigt aktivierte optionale Datenanbieter ohne Offenlegung von Secrets

## 0.6.2

- weiterhin nur ein gemeinsamer Cloudflare Worker für weltweite METAR-Stationsdaten und amtliche Warnungen erforderlich
- weltweiten NOAA-AviationWeather-METAR-Abruf vom veralteten Parameter `hours` auf `hoursBeforeNow` umgestellt
- Stationsantwort um Diagnosewerte für Radius, Trefferzahl und Providerfehler ergänzt
- Länderbezeichnungen aus Suche und lokal gespeicherten Orten auf ISO-Zweibuchstabencodes normalisiert und alte Ortsdaten automatisch migriert
- Länderermittlung im Worker um Orts-/Regionsauswertung, BigDataCloud-Reverse-Geocoding und konservative geografische Rückfälle ergänzt
- Cagliari/Sardinien wird zuverlässig dem italienischen MeteoAlarm-Feed zugeordnet
- MeteoAlarm-Atom/CAP-Parser unterstützt nun eingebettete beziehungsweise XML-maskierte CAP-Meldungen, `content src` und relative CAP-Verknüpfungen
- Regionsbegriffe Sardegna, Sardinia und Sardinien für die örtliche Warnungszuordnung gleichgesetzt

## 0.6.1

- Abruf deutscher Warnungen auf den offiziellen DWD-WFS-Layer `dwd:Warnungen_Gemeinden` umgestellt
- exakte standortbezogene Filterung über die amtlichen Warnpolygone
- DWD-CAP-Atom-Feed als automatische Rückfallquelle beibehalten
- MeteoAlarm-Atom/CAP-Abruf nach Ort, Bezirk und Region priorisiert
- Zahl externer CAP-Unteranfragen begrenzt, damit der Cloudflare-Free-Worker nicht das Subrequest-Limit überschreitet
- Worker-Endpunkt `?mode=health` und Versions-/Zeitangaben zur Diagnose ergänzt
- GitHub-Actions-Workflow bindet `VITE_METAR_PROXY_URL` und `VITE_ALERT_PROXY_URL` aus Repository-Variablen ein
- Fehler aus dem Warnungsproxy werden im Dashboard nicht mehr als scheinbare Entwarnung behandelt

## 0.5.7

- kontinuierliche Farbskala für Prognosekonsistenz (0–100 %)
- Konsistenzpunkte farblich exakt nach Prozentwert interpoliert
- Schaltflächen für hohe/mittlere/geringe Konsistenz entfernt
- kompakte Farbverlaufslegende ergänzt

## 0.5.6

- Linie der gefühlten Temperatur im hellen Layout deutlich kontrastreicher dargestellt
- Legendenmuster für die gefühlte Temperatur an die neue Linienfarbe angepasst
- Warntexte und Warnflächen im hellen Layout für Gelb, Orange, Rot und Violett kontrastreich überarbeitet
- grüne Entwarnung im hellen Layout ebenfalls besser lesbar gestaltet

## 0.5.5

- Groß-/Kleinschreibung in sekundären Tageswetterhinweisen korrigiert, z. B. „leichter Sprühregen“ statt „leichter sprühregen“.
- 7-Tage-Tageszeilen in Hoch- und Querformat neu gerastert, um Überlappungen zwischen Wetterbeschreibung, Tmin/Tmax und Temperaturbalken zu verhindern.
- Wettertexte erhalten einen klar begrenzten, umbrechenden Bereich; der Temperaturbalken wird auf schmaleren Displays in einer eigenen Zeile dargestellt.

## 0.5.4

- Bewölkung in aktuellen Daten und Stunden-Tooltip auf n/8 umgestellt
- Tageswettercharakter auf eine gewichtete stündliche Auswertung umgestellt
- Niederschlagsereignisse werden nur bei ausreichender Dauer, Menge oder Wahrscheinlichkeit zum dominierenden Tagescharakter
- kurze Ereignisse mit geringer Wahrscheinlichkeit erscheinen nur als sekundärer zeitbezogener Hinweis

## 0.5.3

- Niederschlagsklassifikation zentral und strikt nach WMO-Wettercodes überarbeitet
- Sprühregen ausschließlich für WMO 51/53/55, gefrierender Sprühregen ausschließlich für 56/57
- normaler Regen für 61/63/65 und gefrierender Regen für 66/67 eindeutig getrennt
- Regenschauer 80/81/82, Schneefall 71/73/75, Schneegriesel 77 und Schneeschauer 85/86 eindeutig getrennt
- zusätzliche Unterstützung für WMO-Mischcodes 68/69 (Schneeregen) sowie 83/84 (Schneeregenschauer)
- Gewitterniederschlag und Gewitter mit Hagel getrennt
- gemischte Niederschlagsformen werden nur bei gleichzeitig messbaren flüssigen und festen Anteilen abgeleitet

## 0.5.2

- Niederschlagsarten anhand von WMO-Code, Regen-, Schauer- und Schneefallkomponenten neu klassifiziert
- Sprühregen wird nicht mehr als pauschaler Fallback verwendet
- Kurzfristkarte zeigt Niederschlagsart sowie voraussichtlichen Beginn und das Ende auf Basis der 15-Minuten-Best-Match-Daten
- Radarzeitleiste innerhalb der DWD-Radarabdeckung bis +60 Minuten erweitert; außerhalb werden optionale RainViewer-Nowcast-Frames verwendet

## 0.5.1

- Stunden-Navigation der Detailansicht springt an Tagesgrenzen automatisch zum angrenzenden Tag
- 23:00 Uhr → nächster Tag 00:00 Uhr; 00:00 Uhr → vorheriger Tag 23:00 Uhr
- Niederschlagsart Drizzle projektweit als „Sprühregen“ bezeichnet

## 0.5.0

- stündliche Kachelmatrix entfernt und durch dauerhaft sichtbare, kompakte Stunden-Detailanzeige am Diagramm ersetzt
- Stundenwahl erfolgt durch Klick ins Diagramm oder Vor-/Zurücknavigation im Tooltip
- UVI verwendet ausschließlich den tatsächlich erwarteten, bewölkungsberücksichtigten Open-Meteo-Wert; Klarhimmelvergleich und zusätzliche Eigenkorrektur entfernt
- Niederschlag aus dem Tooltip für Temperaturtrend und Prognoseunsicherheit entfernt
- Minor-Release wegen substanzieller Änderung der Bedienstruktur

## 0.4.9

- restriktives Versionsschema dokumentiert; diese Änderung bleibt ein Patch-Release
- 14-Tage-Tooltip klar in Best Match, ENS-Mittel, P10–P90, Niederschlag und Prognosekonsistenz gegliedert
- große stündliche Detailkarten entfernt und durch ein kompaktes Tooltip direkt am Tagesdiagramm ersetzt
- Tooltip erscheint beim Klick auf eine Stunde im Diagramm oder auf eine Stundenkachel
- UV-Logik korrigiert: tatsächlicher cloud-adjustierter Open-Meteo-UVI ist Primärwert; Klarhimmel-UVI wird nur als Vergleich/Fallback verwendet
- UV-Fallback um Wolkenschichten, Sichtweite, Wetterzustand und mögliche Cloud-Enhancement-Situationen erweitert

## 0.4.8

- Tooltip-Reihenfolge im 14-Tage-Temperaturtrend bestätigt und konsistent belassen
- UV-Index auf effektive Werte umgestellt: bewölkungs- und wetterkorrigierte Anzeige statt unkorrigierter Rohwerte
- UV-basierte Hazard-Logik und Tages-Hazards greifen nun auf die effektiven stündlichen UV-Werte zurück

## 0.4.7

- Tooltip im 14-Tage-Temperaturtrend angepasst: "Best Match Tmin/Tmax" statt Minimum/Maximum
- ENS-Mittel im Tooltip getrennt für Tmin und Tmax ausgewiesen

## 0.4.6

- Hazard-Schwellen überarbeitet: farbige Abstufung orientiert an DWD, Meteoalarm und NWS
- Niederschlagsformen in der 7-Tage-Detailansicht erweitert und vereinfacht benannt: Regen, Schauer, Schnee, Schneeschauer, Schneeregen und Schneeregenschauer
- dynamische Detail-Legende für Niederschlagsarten ergänzt
- Hochformat-/Mobil-Lesbarkeit bei langen Bezeichnungen verbessert

# Changelog

## 0.4.4

- Header bereinigt: neben dem Logo wird nur noch die Versionsangabe angezeigt
- Detailansicht um Niederschlagswahrscheinlichkeits-Linie und kompakte Legende erweitert
- Hazard-System auf vier Warnstufen (gelb, orange, rot, violett) erweitert
- zusätzliche Hazard-Prüfung für UV-Index sowie feinere Stufen für Böen, Starkregen, Hitze, Frost und Gewitter
- tägliche Hazard-Pills in 7-Tage-Ansicht und Widget entsprechend erweitert

## 0.4.3

- HTML-Seitentitel auf „MID - Meteorological Information Dashboard“ gesetzt
- MID-Logo in Header und als Favicon eingebunden
- Versionsnummer auch in der kompakten mobilen Kopfzeile sichtbar
- 14-Tage-Niederschlagsdiagramm zeigt die Best-Match-Niederschlagsmenge des Ortes statt des Ensemble-Mittels
- mobile Kopfzeile für Hochformat angepasst; Reload- und Lokalisierungs-Buttons sauber ausgerichtet
- README und Changelog aktualisiert

## 0.4.2

- Autolokalisierung benennt den Standort nach Geodatenbank und kennzeichnet dies deutlich
- helle Layout-Umschaltung auch im mobilen Layout sichtbar
- Niederschlagswahrscheinlichkeit im 14-Tage-Niederschlag per Legende ein-/ausblendbar
- Widgets nochmals kompakter gestaltet
- Tooltip im 14-Tage-Temperaturtrend zeigt für Best Match Min-/Max-Werte

## 0.4.1

- Changelog-Link im Footer
- leerer Erststart ohne Standardort; lokales Merken des zuletzt gewählten Ortes
- kombinierte Wind-/Windrichtungskachel bei den aktuellen Daten
- kompaktere mobile Kacheln
- Feinschliff der 14-Tage-Ensemble-Darstellung
- Niederschlagswahrscheinlichkeit in der 14-Tage-Übersicht und im Niederschlagstrend
- adaptive PNG-Abmessungen und kompakte nebeneinanderliegende Widget-Tage

## 0.4.0

- Suchfeld ist beim ersten Aufruf leer und dient nur der gezielten Orts-/Standortsuche
- stündliche Wetterpiktogramme in der Detailansicht ergänzt; aktuelle Stunde wird standardmäßig vorausgewählt
- stündliche Kacheln in der Detailansicht um Windrichtung und Wind erweitert
- Detaildiagramm größer und besser lesbar skaliert
- Widget-/PNG-Generator gestalterisch an das übrige MID-Design angepasst
- neue Option zum Ein-/Ausblenden von Hazards im Widget und PNG-Export

## 0.3.9

- Persistente 14-Tage-Ensemble-Übersicht
- korrigierte Open-Meteo-Ensemblemodell-IDs
- standortbezogene Modellwahl und Gewichtung
- robuster P10–P90-Ausreißerfilter und Ensemble-Mean-Fallback
- direkt anklickbares Tagesdiagramm mit separater Niederschlagswahrscheinlichkeit
- gefühlte Temperatur in Hitze-Hazards
- kompakteres responsives Layout
- erweiterter WMO-/METAR-Stationsabgleich

## 0.3.8

- 14-Tage-Ensemble-Kachelübersicht mit Konsistenzpunkten

## 0.9.39.10
- Installer erkennt leere, falsche oder CRC-beschädigte Release-ZIPs vor dem Entpacken und protokolliert Größe/SHA-256.

## 0.9.39.11
- Release-Prebuild verändert `.github/workflows` nicht mehr automatisch; damit blockiert GitHub den Release-Push nicht mehr wegen fehlender Workflow-Schreibberechtigung.
- Workflow-Synchronisierung bleibt ausschließlich als expliziter Maintainer-Befehl verfügbar.
- Kanonischer Installer schließt `.github/**` zusätzlich ausdrücklich aus automatischen Release-Commits aus.

## 0.9.40.8
- Kompositbild: „Stand“ der Satellitenebene nutzt bei DWD-Live-Snapshots jetzt den tatsächlichen Produktzeitstempel statt der aktuellen Gerätezeit.
- Niederschlagsart-Radar/Kompositphase robuster gemacht: leichte und grenzwertige Echos werden vorsichtig mitberücksichtigt, die Radar-/Modellfusion sampelt dichter und blendet Signale dadurch deutlich seltener fälschlich aus.
- Radar-Farbtabellen für 1-km-/250-m-Radar erweitert: zusätzliche professionelle Varianten (u. a. DWD Standard, DWD Starkregen, NEXRAD Classic, Canada 14-stufig, Europa Spektrum) mit Vorschau und Auswahl in den Einstellungen.

## 0.9.40.10
- CI-Fix für den v0.9.40.9-Release: die drei fehlgeschlagenen Regressionen für Komposit-Phasensicherheit, MapLibre-Niederschlagswahrscheinlichkeit und kompakte Wetterwerte sind wieder erfüllt.
- Niederschlagsart-Radar: Unsichere/„eingeschränkte“ Phasen bleiben transparent und das Modellraster bleibt ohne künstliche Unterteilung. Die Echoerkennung prüft stattdessen mehrere OPERA-Radarpunkte innerhalb jeder Modellzelle; bei starken Echos kann eine eindeutig warme bzw. kalte thermische Phase konservativ ergänzt werden.
- Niederschlagswahrscheinlichkeit: Ensemble-Tageswerte bleiben kompakt als 00–24 h sichtbar; der ausführliche Titel verwendet wieder die geschützte DWD-24-h-Terminologie und nennt 00–24 h explizit als Zeitraum.
- Best-Match-Fallback in engen Karten wieder auf die kurze Darstellung „bis x %“ zurückgeführt.

## 0.9.40.11
- CI-Fix für die app-weite Niederschlagswahrscheinlichkeit: der Ensemble-Tageswert trägt wieder exakt den geschützten Titel „DWD-Ereigniswahrscheinlichkeit · 00–24 h“.
- Der Best-Match-Stundenfallback ist wieder eindeutig als „max. Std.“ gekennzeichnet; damit wird ein Stundenmaximum nicht als 24-h-Ereigniswahrscheinlichkeit missverstanden.
- Die in v0.9.40.9/10 eingeführte app-weite 00–24-h-/6-h-Logik bleibt unverändert erhalten; ausschließlich die geschützte Semantik der Titel und Fallback-Kurztexte wurde repariert.

## 0.9.40.12
- Tagesübersichten vereinfacht: Niederschlagswahrscheinlichkeit zeigt entweder den 00–24-h-Wert oder – ausschließlich bei einem klar um mindestens 10 Prozentpunkte erhöhten 6-h-Fenster – nur dieses Zeitfenster. Keine Doppelanzeige mehr.
- Dieselbe exklusive 00–24-h-/6-h-Logik gilt in klassischer Prognose, Cockpit, Widget und Ensemble-Tagesübersichten.
- Niederschlagsdauer wird in Tagesübersichten auf ganze Stunden gerundet; Detailansichten behalten die feinere 15-Minuten-Auflösung.

## 0.9.40.13
- Kompositbild: DWD-Satelliten-Live-Snapshots erhalten ihren angezeigten Stand aus dem tatsächlichen DWD-OpenData-Satellitenquellzeitpunkt statt aus der Abfrage-/Gerätezeit; eine künstliche 3-Stunden-Abrundung entfällt.
- Radar-Farbtabellenwahl aus den Einstellungen entfernt. 1-km-WMS sowie lokal gerendertes 250-m-/OPERA-Radar verwenden wieder ihre fest vorgegebenen Standardfarben.
- Neue appweite Zeitbasis unter Einstellungen: Lokalzeit (Standard) oder Z-Zeit/UTC. Wetter-, Radar-, Warn-, Diagramm-, Wasser-, Berg-, Meteogramm- und technische Zeitangaben folgen der Auswahl; die Ortszeit im Standortkopf bleibt bewusst lokal.
- Niederschlagsart im Kompositbild auf ein semitransparentes Symboloverlay umgestellt: kleine Symbole markieren nur Mischphase, Schnee und gefrierenden Niederschlag auf dem jeweils aktiven Radarbild; reiner Regen erhält kein Zusatzsymbol. Die vorhandene Deckkraftregelung unter der Karte steuert die Symboltransparenz.

## 0.9.52.4
- CodeQL-Cleanup: letzter produktiver `Math.random()`-Fallback in der Favoriten-ID-Erzeugung durch Web-Crypto ersetzt.
- Neue Regression verhindert unsichere Zufallsquellen im Produktionscode.

## 0.9.53.34
- Abgelaufene Events appweit erkennbar, ortszeitzonengerecht sortiert und direkt entfernbar; automatische Wetteraktualisierung endet mit Event-Ende.
- Theme-gerechter Splashscreen mit deutlich größerem vollständigem MID-Logo und kurzer kanonischer Startdaten-Vorladung.

## 0.9.53.35
- Produktionsbuild-Fix für v0.9.53.34: unbenutzten `EventCenterRecord`-Typimport in `eventWeatherRefresh.ts` entfernt (`TS6133`).
- Event-Lifecycle und Splashscreen-Funktionen aus v0.9.53.34 bleiben unverändert erhalten.

## 0.9.53.37
- Hyperlokale 2-m-Temperatur um einen robusten, begrenzten direkten Messkonsens gegen fehlerhafte Zielpunktgradienten ergänzt; kein Einzelstations-/Flughafen-Zwang und kein pauschaler Nachtabschlag.
- Current-Diagnose zeigt tatsächliche Temperatur-Messpunkte, temperaturbezogenen Radius, Quellenintervalle und ggf. die zusätzliche Messkonsens-Rückführung.
- Verbindlicher Kosten-Governance-Vertrag: keine kostenpflichtigen MID-Schritte ohne vorherige transparente Kosteninformation und ausdrückliche Freigabe; Free/Open first.

## 0.9.53.39
- Current-Temperatur gegen Rücksprünge zwischen schnellem Beobachtungs- und nachgelagertem Hyperlokal-Full-Pass abgesichert; jüngere feldbezogene Temperaturbeobachtungen werden nicht mehr durch ältere, nur formal reichhaltigere Analysezustände verdrängt.
- Fast-/Full-Stationscaches übergeben frische Rohkandidaten kurzzeitig im Speicher und verwenden eine neue Stationsanalyse-Cachegeneration; `forceFresh` umgeht auch die transienten Stationsanalysecaches, ohne Quellen-TTLs oder periodischen Traffic zu erhöhen.
- Starker, frischer und räumlich kohärenter Mehrstationskonsens darf einen deutlichen Tages-Gradientenfehler stärker korrigieren; schwache/alte/weite oder widersprüchliche Evidenz sowie Einzelstationen bleiben konservativ begrenzt.
- Current-, 90-Minuten- und 24-Stunden-Temperaturpfad explizit vereinheitlicht und regressionsgeschützt. Die gefühlte Current-Temperatur folgt dem lokalen Temperaturversatz; temperaturbezogene Diagnosechips erscheinen nur bei tatsächlich frischem Temperaturanker.

## 0.9.53.41
- CI-Fix für v0.9.53.40: vier veraltete Regressionserwartungen mit dem einmaligen Current-/Hyperlokalpfad synchronisiert.
- 24-h-Wetterprofil verwendet wieder exakt 24 bereits finalisierte Stunden ab der aktuellen Stunde und wendet keinen zweiten synthetischen Current-/Stationsanker an.
- Current, 90-Minuten-Leiste, Kurzfrist und 24-h-Profil bleiben dadurch auf derselben kanonischen Temperaturreihe; Folgetag-Zeitkontext und Cockpit-Redundanzbereinigung aus v0.9.53.40 bleiben erhalten.

## 0.9.53.42
- Produktionsbuild-Fix: verwaisten `bridgeObservedTemperature`-Import aus `ForecastCockpit.tsx` entfernt; verhindert `TS6133` bei aktiviertem `noUnusedLocals`, ohne den kanonischen Current-/90-Minuten-Temperaturpfad zu verändern.
- Appweite Interaktionsstandardisierung ergänzt: konsistente mobile Textskalierung, Touch-/Tap-Verhalten, Disabled-Zustände, native Akzentfarbe sowie Reduced-Motion- und Forced-Colors-Unterstützung.
- Neue Required Regressionen schützen Build-Hygiene und die gemeinsamen UI-Grundregeln; keine zusätzlichen Wetterabrufe oder Worker-Funktionsänderungen.

## 0.9.53.43
- Appweites Designsystem mit zentralen Tokens für Abstände, Radien, dichte Typografie und semantische Statusfarben eingeführt.
- Wiederkehrende Pills/Badges geometrisch vereinheitlicht; Event-, Warn-, Modellquellen-, Wetterzwilling- und Push-Status auf gemeinsame Bedeutungsfarben abgebildet.
- Gemeinsames `MidDisclosure`-Primitiv eingeführt und für Analysewerkzeuge sowie Event-Detail-/Modellstandansichten verwendet; geschützte Spezial-Disclosures bleiben unverändert.
- Keine Wetterdaten-, Cache- oder Worker-Funktionsänderung und keine zusätzlichen Requests.
## 0.9.53.44
- Produktionsbuild-Fix für das gemeinsame `MidDisclosure`: `defaultOpen` wird nicht mehr als ungültiges DOM-Attribut an `<details>` weitergereicht.
- Initialer Öffnungszustand läuft über React-State; `open` und `onToggle` halten native Nutzerinteraktion und React-Zustand synchron.
- Neue Required Regression schützt den konkreten `TS2322`-Rückfall; keine Wetterdaten-, Cache- oder Worker-Funktionsänderung.


## 0.9.53.48
- Ortssuche priorisiert und gegen leere Zwischenzustände/verspätete Antworten gehärtet; Zwei-Zeichen-POI-Suche und Kurzzeitcache ergänzt.
- Netatmo-Verbindung liefert bei fehlender Worker-Konfiguration sofort sichtbares Setup-Feedback statt eines stumm deaktivierten Buttons.

## 0.9.53.50

- Netatmo OAuth-Start korrigiert: `response_type=code` wird nun explizit an den Autorisierungsendpunkt übergeben. Ohne diesen Parameter konnte die externe Netatmo-Freigabeseite übersprungen bzw. der Flow sofort zur App zurückgeführt werden.
- OAuth-Rückkehr wird app-weit erkannt: bei `mid_station` öffnet MID automatisch **Einstellungen → Lokaler Wetterzwilling**, damit Erfolgs-/Fehlermeldung und verbundene Station sichtbar sind, statt nur auf der Startseite zu landen.
- Quellenhinweis zur privaten Stationsintegration an den aktiven Stand angepasst.
- Neue Regression `test-netatmo-oauth-navigation-095350.mjs` sichert Authorization-Code-Parameter, externe Weiterleitung und Rückkehr in den Stationsbereich ab.

## 0.9.53.49
- CI-Fix: veraltete feste Debounce-Erwartung in `test-interactions.mjs` durch einen semantischen Responsivitätsvertrag ersetzt. Die produktive Ortssuche bleibt unverändert bei 35/60 ms.
- Keine Wetter-, Netatmo-, Lüftungs- oder Worker-Funktionsänderung.


## 0.9.60.3
- Kompositbild-Zeitpfeil dauerhaft sichtbar gemacht: Schaft, Querstriche und die Verbindung zu den Zeitlabels werden nicht mehr über ein Canvas-Overlay, sondern als robuste Karten-Polylinien gerendert.
- Zusätzlich erhält jedes Zeitlabel wieder eine klar sichtbare Verbindungsmarke zum Zeitpfeil, damit Linie/Strich auch im mobilen Kompositbild zuverlässig erkennbar bleibt.
- Die vorhandene Zielspitze am gewählten Ort, die wolkengewichtete Schwerpunktströmung und die reduzierte Zeitlabel-Logik bleiben unverändert erhalten.


## 0.9.60.4
- Kompositbild-Zeitpfeil erneut korrigiert: Zeiten beziehen sich jetzt auf den aktuell angezeigten Filmzeitpunkt statt auf eine potenziell abweichende Analysestempelzeit.
- Die Zeitlabels nutzen standardmäßig nachvollziehbare relative Zeiten (z. B. +30m, +1h), absolute Zeiten bleiben intern weiter unterstützt.
- Für langsame Verlagerungen wurde die Pfeilgeometrie auf zeitbasierte Lead-Zeiten umgestellt, damit keine unrealistischen Mehrstunden-Labels mehr entstehen.
- Pfeilschaft, Tick-Marken und Label-Verbindungen wurden farblich deutlich verstärkt und die Labels an echte Label-Anker verlegt, damit der Zeitpfeil im Kompositbild klar sichtbar bleibt.


## 0.9.60.5
- Kompositbild-Zeitpfeil erneut nachgeschärft: Die sichtbare Pfeillinie wird jetzt im regulären Overlay-Pane gerendert, damit der Schaft im Kartenbild zuverlässig tatsächlich sichtbar bleibt.
- Der Zeitpfeil-Schalter wurde auf einen Drei-Stufen-Zyklus umgestellt: erster Tap absolute Zeiten, nächster Tap relative Zeiten, dritter Tap Layer aus.
- Der gespeicherte Zeitmodus wird wieder korrekt als React-State geführt; damit funktionieren Persistenz und zyklisches Umschalten belastbar auch mobil.
- Die Button-Detailanzeige weist den aktiven Zeitmodus (absolut/relativ/aus) direkt aus.


## 0.9.60.7
- Regressionen des Komposit-Zeitpfeils auf den aktuellen sichtbaren Polyline-Vertrag migriert; alte Canvas-/Custom-Pane-Erwartungen entfernt.
- Flug-Korridor- und wolkengewichtete Schwerpunktströmungs-Regressionen auf denselben Zeitpfeil-Vertrag synchronisiert.
- Kanonische Worker-Teilquelle auf den aktuellen Release-Stand synchronisiert, damit `maintain:aggregates` den Worker nicht mehr auf v0.9.60.2 zurückstuft.
- Radar-Niederschlagsart- und Wetterkarten-Verträge bleiben funktional unverändert und bestehen wieder nach dem CI-Aggregat-Vorlauf.


## 0.9.60.8
- Standort-/Blickrichtungsmarker strikt getrennt: Der Richtungs-/Standortpfeil erscheint ausschließlich am echten Gerätestandort.
- Favoriten und manuell gewählte Orte verwenden im Kompositbild nur noch eine neutrale Ortsmarkierung ohne Sichtrichtungsanteil.
- Der meteorologische Zeitpfeil bleibt davon unabhängig und endet weiterhin am aktuell ausgewählten Ort.
- Neuer Pflichtvertrag `test-location-heading-favorites-09608.mjs` schützt die Trennung dauerhaft.


## 0.9.60.9
- Kompositbild-Zeitpfeil nach bestätigter Referenzvorlage von Grund auf als zusammenhängendes SVG-Symbol neu erstellt.
- Zeitlabels nur noch an den vier 15-min-Unterteilungen; keine Zeitmarke direkt am Standort/Favoritenort.
- Pfeilspitze endet am gewählten Ort, Anströmrichtung weiterhin primär aus der wolkengewichteten Vertikalprofil-Schwerpunktströmung.
- Neuer Pflichtvertrag `test-composite-time-axis-template-09609.mjs`.


## 0.9.60.10
- Kompositbild-Zeitpfeil zoomabhängig gemacht: die 60-min-Anströmungsstrecke besitzt nun eine feste geographische Länge aus Schwerpunktströmungs-Geschwindigkeit × 60 min und wird bei jedem Zoom neu in Bildschirmkoordinaten projiziert.
- Die Pfeilachse wächst beim Hineinzoomen und schrumpft beim Herauszoomen entsprechend der Karte; die bisherige feste Bildschirm-Länge wurde entfernt.
- +15/+30/+45/+60-min-Unterteilungen bleiben meteorologisch an derselben geographischen Zugstrecke verankert; Richtung und Geschwindigkeit stammen weiterhin primär aus der wolkengewichteten Vertikalprofil-Schwerpunktströmung.
- Neue Regression schützt ausdrücklich gegen einen Rückfall auf feste Pixel-Längen.


## 0.9.60.11
- EU-AQI-Einzelwertskalen korrigiert: Markerposition und aktiver Farbbereich verwenden nun denselben Open-Meteo-EU-AQI-Vertrag; die Fallback-Konzentrationsschwellen wurden auf den aktuellen Open-Meteo/CAMS-Stand synchronisiert.
- Zeitpfeil-Skala vollständig dynamisiert: runde Zeitstufen werden aus Schwerpunktströmungs-Geschwindigkeit, sichtbarer Strecke bis zum Kartenrand, Zoom, Kartenabmessungen und Displaydichte gewählt.
- Tickanzahl und Gesamtzeitfenster passen sich automatisch an; extreme Zoomstufen erzeugen weder übergroße Pfeile noch überlagerte 15/30/45/60-Minuten-Labels.
- Die Zeitachse bleibt auf maximal zwei Stunden begrenzt und verwendet nur runde Schritte (2/5/10/15/20/30/45/60 min).


## 0.9.60.13
- CI-Härtung: veraltete `geometry.trackMid`-Regressionen auf den aktuellen direkt am gewählten Ort verankerten Zeitpfeil-Vertrag migriert.
- Kanonische Worker-Teilquelle und Baseline versionsfest synchronisiert; neuer Aggregate-Versionstest verhindert Rückfälle durch `maintain:aggregates`.


## 0.9.60.14
- Komposit-Zeitpfeil-Rollback-Schutz: Das zoominstabile Komplett-DivIcon wurde entfernt. Schaft und Unterteilungen werden wieder als echte geographische MapLibre-Vektoren in einer eigenen Pane oberhalb der Referenzkarte gerendert; die Pfeilspitze bleibt als separater Marker exakt am gewählten Ort.
- Die dynamische runde Zeitskala aus Schwerpunktströmungs-Geschwindigkeit, Zoom, verfügbarer Kartenstrecke und Displaydichte bleibt erhalten.
- Standort-/Favoriten-Vertrag verschärft: Der Sichtrichtungspfeil wird nur noch über die tatsächlich aktive Geräteort-Auswahl (`locationSelectionSource === tracked`) freigegeben; ein manuell geöffneter Favorit kann ihn nicht mehr über ein historisches `autolocated`-Flag erben.
- Bestehende Zeitpfeil-/Zoom-/Flug-/Radar-Regressionen auf den geographischen Vektorvertrag migriert.


## 0.9.60.15
- Komposit-Zeitpfeil: Schaft, Ticks, Zeitlabels und Pfeilspitze werden nun gemeinsam in einem dynamisch aus Geo-Projektionen erzeugten DOM/SVG-Marker gerendert. Dadurch kann die Linie nicht mehr unabhängig von den sichtbaren Labels verschwinden.
- Das SVG wird bei Zoom/Move/Resize aus den aktuellen Kartenprojektionen neu aufgebaut; die Pfeilspitze bleibt exakt am ausgewählten Ort und Zeitlabels stehen ausschließlich an den Ticks.


## 0.9.61.0
- Wetterzwilling/Fusion konsolidiert: serverseitige Gewichte berücksichtigen Wetterlage, Horizont, Region, Auflösung, Laufaktualität und Latenz; die lokal gemessene Prognosegüte bleibt eine datensparsame Gerätestufe.
- Rapid-Cycle-Varianten derselben Modellfamilie teilen sich ein Unabhängigkeitsbudget und können die Fusion nicht durch Doppelgewichtung dominieren.
- Erweiterte Quellen-/Gewichtungsdiagnose weist Tagesfaktoren, Gruppenbudgets, lokale Skill-Gewichte und die nachgelagerte Nowcast-Stufe aus.
- Alle Wetteransichten bleiben an die kanonischen `displayHours`/`displayMinutes15` und daraus abgeglichene Tageswerte gebunden.


## 0.9.62.0
- Flugmeteorologie als textuelles Streckenbriefing erweitert: zwei bis acht Wegpunkte, Korridor, Flughöhe sowie Start-/Landezeit bilden einen gemeinsamen Routenvertrag.
- Hazard-Orte werden als größere Räume/Streckenabschnitte mit gerundeten Entfernungen und Eintritts-/Austrittsfenstern beschrieben.
- Neues vertikales Textbriefing für Bewölkung, Vereisung, Turbulenz/Windscherung, Konvektion und Wind; keine Rückkehr zur alten Cross-Section-Grafik.


## 0.9.63.0
- Große Flug-, Radar-/Komposit- und Wetterdiagnosepfade in eigene Fachmodule aufgeteilt; gemeinsame Cache- und Persistenzverträge eingeführt.
- Komposit-Layer-Zustand einschließlich Aktivierung, Kartenstil, Transparenzen und Bewegungszeitmodus bleibt unter dem bestehenden v3-Vertrag dauerhaft erhalten.
- Cloudflare-KV-Last reduziert: regelabhängige Kadenzen, metadata-only Scheduling, zustandsabhängige Writes und gedrosselte Heartbeats ohne Wegfall von Regeln oder Datenquellen.
- Regressionen prüfen die kanonische Prognose, das textuelle Flugbriefing, dauerhafte Nutzerzustände und das KV-Operationsbudget.

## 0.9.77.27
- Saison-/Langfristquellen vollständig neu auditiert und auf kanonische Modell-/Unabhängigkeits-IDs umgestellt.
- C3S führt die 10 aktuell operationellen Systeme getrennt; ECCC CanESM5.1p1bc und GEM5.2-NEMO sind eigenständige Systeme, Met Office GloSea6-GC5.1 System 610 und JMA CPS4 sind aktualisiert.
- NOAA NMME bleibt dynamisch und übernimmt jedes im neuesten ENSMEAN-Lauf tatsächlich verfügbare Modell; CFSv2/ECCC-Dubletten werden anbieterübergreifend nicht doppelt gewichtet.
- Poor-Man’s-Ensemble: eine gleichgewichtete Stimme je unabhängiger Modelllinie; aktuell bis zu 13 unabhängige Systeme bei vollständig aktivem C3S + NMME.
- NMME-Punktentnahme auf Header-Range + HTTP Multi-Range mit Volldownload-Fallback und begrenzter Parallelität umgestellt.
- Gemeinsames Einzelmodell-Diagramm bleibt auch bei >12 Linien eindeutig über Farbe + Linienmuster; keine zusätzlichen Katalog-/Hinweiskästchen.
- WMO LC-LRFMME, APCC, CanSIPS und DWD EPISODES geprüft und nur dort einbezogen, wo Zeitachse, Authentifizierung und Unabhängigkeit eine fachlich saubere numerische Vereinigung erlauben.

## 0.9.77.28
- 7-/14-Tage Tmin/Tmax: individuelle Abweichung zum jeweiligen Klimamittel 1991–2020 wieder direkt im blauen/roten Kästchen sichtbar.
- Klimatologie-Datenbedarf von der optionalen 7-Tage-Kurzinterpretation entkoppelt; aktive Tagesprognose lädt das Klimamittel zuverlässig auch bei deaktivierter Summary.
- Bereits kleine Abweichungen um ±0,5–1 K wirken wieder auf Badge-Text, Hintergrund und Rahmen; bei fehlendem Klimamittel steht sichtbar `Δ –`.
- Vorhandener Klimacache dient bei temporärem Archive-API-Fehler als Stale-Fallback.
## 0.9.81.1

- Radar-/Satellitenfilm läuft am Schleifenende ohne künstliche Zusatzpause weiter; bis zu zwölf bestätigte Satellitenstände bleiben für den nächsten Durchlauf vorgemerkt.
- KONRAD3D-Zellstände erhalten einen ausdrücklichen Zeitstatus. Ohne bestätigten Beobachtungszeitpunkt werden sie nicht als aktuell oder freigegeben bezeichnet.
- Der AGL-Vertrag des Flugbriefings wurde geprüft: Eingaben unter FL050 werden entlang der Strecke auf das jeweilige Geländeniveau aufgeschlagen; Druckflächen ab FL050 bleiben druckhöhenbezogen.
- Übergabestand v0.9.81.0 auf der gelieferten v0.9.80.7-Codebasis rekonstruiert und gegen einen erneuten Versionsrückfall abgesichert.

## 0.9.81.2

- Radar- und Satellitenstände werden erst nach vollständigem Laden umgeschaltet. Der vorherige Stand bleibt während eines echten 480-ms-Crossfades sichtbar; vorgeladene Bilder bleiben im Zwölf-Frame-Puffer.
- Kartenansicht, Radar-/Satelliten-/Blitz-/Zell-/Warn-/Synoptik-Layer, Deckkräfte, Kartenbasis, Bewegungszeitmodus und Wiedergabetempo werden gemeinsam dauerhaft wiederhergestellt. Ein gespeicherter 250-m-Modus wird nicht mehr vor Abschluss der Verfügbarkeitsprüfung verworfen.
- Isohypsen erhalten vor der begrenzten Chaikin-Kurvenglättung einen zweistufigen symmetrischen Binomialfilter; Isobaren bleiben bewusst etwas detailreicher. So werden Gittertreppen reduziert, ohne synoptische Strukturen Windy-artig zu überglätten.
- Das optionale Beta-Bedienkonzept zeigt weiterhin nur fünf Hauptziele. Seltenere Analyse-, Profil-, Profi- und Werkzeugbereiche liegen nun eingeklappt im Mehr-Menü und erscheinen erst nach Aufruf.