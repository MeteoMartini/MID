# MID Umsetzung v0.9.77.8

## Extremwetter: I/P-Schwellenintegrität

- Die vier MID-Intensitätsstufen I1–I4 bleiben für Regen, Sturm, Schnee, Eisregen und Gewitter zentral definiert.
- P1–P4 bleibt davon getrennt die Wahrscheinlichkeit, dass die jeweils dargestellte I-Stufe erreicht oder überschritten wird.
- In der UI werden Intensitätsschwelle und tatsächliches Modellsignal jetzt ausdrücklich nebeneinander gezeigt. Ein Wert wie 7,4 mm/6 h wird damit nicht mehr optisch als I4-Schwelle missverstanden; bei I4/6 h steht die Vergleichsschwelle 90 mm/6 h sichtbar daneben.
- Kontur-/Flächenstufen aktualisieren ihre Schwellenreferenz zusammen mit der dargestellten I-Stufe; dadurch können repräsentative Zellmetriken nicht mehr mit einer anderen Konturintensität verwechselt werden.
- Niederschlags- und Schneefenster dürfen nicht mehr in den vorherigen Auswertezeitraum zurückgreifen.

## ICON-D2-RUC über die vollständige Laufzeit

`rapid-extreme.json` wird auf Schema `mid.dwd.ruc.rapid-extreme.v3` erweitert:

- +0–6 h: native 5-/15-min-Niederschlags- und Konvektionsdiagnostik plus stündlicher Zustandskern,
- +6–12 h: stündlicher RUC-Zustandskern,
- +12–14 h: stündlicher RUC-Zustandskern als explizite Teilabdeckung des UI-Fensters +12–24 h,
- ab +14 h: keine RUC-Unterstellung; +24–48 h bleibt bei ICON-D2/ICON-D2-EPS.

RUC-Niederschlag stützt eine Intensitätsstufe nur noch, wenn die reale 1-h- bzw. bei vollständiger Abdeckung 6-h-Schwelle erreicht wird. Der frühere subthreshold-Pseudoprobabilitätsweg aus 5-min-Raten wurde entfernt. Wind wird analog an den höhenabhängigen Böenschwellen geprüft. Gewitter-RUC bleibt ingredient-basiert (CAPE/CIN plus Niederschlag/Organisation) und darf ohne passende Basis kein synthetisches Hochstufensignal erzeugen. Für Schnee/Eis liefern Temperatur, Feuchte, Nullgrad-/Schneefallgrenze und native Phasendaten diagnostische Stützung, ohne aus unzureichenden Parametern eine künstliche Intensitätswahrscheinlichkeit abzuleiten.

## PR-Housekeeping

PR #24, #25 und #26 sind im MID-Stand bereits umgesetzt. Der verbundene GitHub-Zugang verweigert das Schließen mit HTTP 403; die PRs sind daher lokal als erledigt/superseded dokumentiert. React-19-/plugin-react-6-PRs #6/#18/#20/#21 bleiben bewusst zurückgestellt.

## Regression

Neu: `scripts/test-extreme-threshold-ruc-horizon-09778.mjs` schützt I1–I4, P-Klassen, periodengrenzenfeste Rollfenster, subthreshold-sichere RUC-Unterstützung, Schema v3 und die echte +0–14-h-Abdeckung.
