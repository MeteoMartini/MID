# MID Dependency Upgrade Policy

Stand: MID 18.2.9 Wartungsreview 25.10.2026 / Ziel v0.9.85.332

Der Stable-Channel übernimmt Abhängigkeits- und Toolchain-Sprünge nur als zusammenhängend geprüfte Verträge. Für v0.9.85.332 gilt:

- React / React DOM / react-is: 19.2.8 – ausschließlich als gemeinsame React-19-Familie.
- `@types/react`: 19.2.18 und `@types/react-dom`: 19.2.5 passend zur React-19-Familie.
- Recharts: 3.10.1; Diagramm-, Tooltip-, Export- und Responsive-Verträge bleiben erhalten.
- TypeScript: 7.0.2; App- und Node-Typecheck bleiben artefaktfrei.
- TypeScript-Strada-Test-API: Alias `typescript-strada` auf 6.0.3, ausschließlich für bestehende Regressionen mit der von TypeScript 7 entfernten JavaScript-Compiler-API; niemals für App-/Node-Typecheck.
- esbuild: 0.28.2, ausschließlich als direkte Testabhängigkeit für isolierte TypeScript-Fachmodul-Regressionen; nicht als Vite-Minifier oder Produktionsbundler.
- Vite: 8.3.5.
- `@vitejs/plugin-react`: 6.1.2, nur zusammen mit Vite 8; dieser Vertrag koppelt @vitejs/plugin-react 6 ausdrücklich an Vite 8.
- Vite-8-Buildkern: Oxc für JavaScript-Minifizierung, Lightning CSS für CSS-Minifizierung und Rolldown `output.codeSplitting` für die auditierte React-/Charts-Vendor-Aufteilung. Der veraltete esbuild-Minify- und Rollup-`manualChunks`-Pfad ist nicht mehr Bestandteil des Stable-Vertrags.
- Lucide React: 1.40.0.
- MapLibre GL JS: 6.7.0.
- Capacitor Core / iOS / CLI: 8.5.3.
- Capacitor Core / iOS / CLI 8.5.3 ist seit .331 veröffentlicht; Core, CLI und iOS bleiben synchron.
- GitHub Actions: checkout 7.0.1 (`3d3c42e5aac5ba805825da76410c181273ba90b1`), setup-node 7.1.0 (`949feb2413d6458794dcd2491c4babbbce0c15c1`), setup-python 7.0.0 (`5fda3b95a4ea91299a34e894583c3862153e4b97`), upload-artifact 7.0.2 (`cf430e030ddbb5b0abf93d22962f4752f3646cd9`), download-artifact 8.0.1 (`3e5f45b2cfb9172054b4087a40e8e0b5a5461e7c`) und deploy-pages 5.0.1 (`368f82528645a54fb793d4d04e342629a3f51346`), jeweils SHA-gepinnt.
- CodeQL: 4.38.2 (`2892aa5e19bbd11bc0cff5427e3b750a04d9e3c2`), SHA-gepinnt und für `init`/`analyze` zwingend identisch.
- Workflow-Aktivierung: Der Release-Installer verändert `.github` nicht selbst. Die kanonischen Quellen unter `ci/github` und `workflow-patches` sowie `npm run sync:github-workflows` halten die administrativ zu aktivierenden Pins synchron.

## Kopplungsverträge

React 19 wird nicht paketweise übernommen: `react`, `react-dom`, `react-is` und die beiden React-Typepakete bleiben gemeinsam auf der qualifizierten 19.2-Reihe. Recharts 3.10.1 und die Redux-Helfer müssen React 19 weiterhin über ihre Peer-Verträge zulassen.

Vite 8 und `@vitejs/plugin-react` 6 bilden ebenfalls einen gemeinsamen Vertrag. Plugin-react 6 verlangt Vite 8; Vite 8 verwendet Rolldown/Oxc und Lightning CSS. MID nutzt deshalb keine deprecated `build.minify: 'esbuild'`, `build.cssMinify: 'esbuild'` oder `build.rollupOptions.output.manualChunks`-Konfiguration mehr.

TypeScript 7.0.2 bleibt von dieser Folgemigration fachlich unabhängig. Der historische TypeScript-7-Meilenstein wurde zunächst ohne React-/Vite-Major-Sprung qualifiziert; v0.9.83.0 ändert daran weder Compilerstand noch Strada-Alias. Das verhindert, dass ein Fehler des neuen Bundler-/React-Vertrags fälschlich als TypeScript-Migration kaschiert wird.

## Sicherheits- und Wartungsregeln

Sicherheits-Patches innerhalb kompatibler Transitivreihen werden im Stable-Channel angehoben, sobald Dependency-Audit und Regressionen grün bleiben. Mindestvertrag: `nanoid >=3.3.18` im 3.x-Pfad sowie `protocol-buffers-schema >=3.6.1`.

Recharts-Minor-/Patch-Upgrades bleiben an vollständigen Build sowie Ensemble-/Tooltip-/Export-/Responsive-Regressionen gebunden. Weitere React-, Vite- oder plugin-react-Majors benötigen erneut einen eigenen Kompatibilitätsmeilenstein; partielle Major-Migrationen sind unzulässig.

MapLibre GL JS 6.7.0 bleibt der qualifizierte Kartenstand. Die Karten-, Radar-, Komposit-, GeoJSON-, Worker- und Lazy-Load-Verträge dürfen durch Toolchain-Wartung nicht verändert werden.

## Vite-Qualifikation .332 und zurückgestellte Kandidaten

Ausgangsbasis ist der veröffentlichte Stable-Commit .331. Vite wird isoliert von 8.2.4 auf 8.3.5 aktualisiert; das kompatible plugin-react 6.1.2, React 19.2.8 und MapLibre 6.7.0 bleiben unverändert. React/React DOM/react-is 19.3.1 mit React-Typen 19.3.0 sowie MapLibre GL JS 6.15.0 wurden gemeinsam mit der vollständigen lokalen Regression geprüft, überschritten aber die bestehenden harten Feature-Chunk-Budgets. React 19.3.1 und MapLibre GL JS 6.15.0 bleiben deshalb zurückgestellt; die Budgets wurden nicht angehoben. Pako bleibt 2.2.0; PostCSS 8.5.31 und Capacitor 8.5.3 bleiben unverändert.

Die Installationswarnung `uuid@7.0.3` stammt ausschließlich aus dem Dev-/iOS-Werkzeugpfad `@capacitor/cli 8.5.3 -> xcode 3.0.1 -> uuid ^7.0.3`. MID erzwingt kein inkompatibles UUID-Override; der Pfad wird bei einem kompatiblen Upstream-Update erneut bewertet.


## Wartungsreview 23.09.2026

Der veröffentlichte Stable-Vertrag bleibt für diesen fachlichen Härtungsrelease bewusst reproduzierbar gepinnt. Aktuell geprüft wurden folgende Upstream-Kandidaten:

- MapLibre GL JS 6.11.1 statt 6.7.0: sinnvoller nächster isolierter Karten-/Radar-Meilenstein. Die Aktualisierung verändert transitive Kartenpakete und benötigt daher ein neu erzeugtes Lockfile sowie vollständige Worker-, GeoJSON-, Radar-, Komposit- und mobile Langzeittests.
- Capacitor Core / iOS / CLI 8.5.2 statt 8.5.1: sinnvoller isolierter iOS-Lifecycle-/Safe-Area-Patchkandidat. Er wird nur gemeinsam für Core, iOS und CLI übernommen.
- Vite 8.3.0 statt 8.2.2: sinnvoller nachgelagerter Build-Performance-Patchkandidat. Vite und plugin-react bleiben ein gekoppelter Buildvertrag.
- React 19.3.0 ist ein separater Kompatibilitätsmeilenstein und ausdrücklich **kein** Patch dieses Releases. React, React DOM, react-is, Typen und Recharts werden erst gemeinsam nach eigenem UI-/Tooltip-/Ref-/Responsive-Gate aktualisiert.

Für v0.9.85.95 gilt: keine package.json-only-Aktualisierung und kein manuell erfundener Lockfile-Hash. Ohne reproduzierbar neu erzeugtes npm-Lockfile bleibt der bereits grüne Stable-Pin bestehen. Damit hat Reproduzierbarkeit Vorrang vor einem nominell neueren Paketstand.


## Wartungsreview 30.09.2026 · v0.9.85.128

- `brace-expansion` wird innerhalb des von `minimatch` bereits erlaubten 5.x-Pfads ausschließlich im Lockfile von 5.0.9 auf 5.0.12 angehoben, um die aktuellen High-Severity-DoS-Advisories zu schließen. Der Produktions-Abhängigkeitsvertrag wird dadurch nicht erweitert.
- Der bekannte `uuid@7.0.3`-Befund bleibt auf den Dev-/iOS-Werkzeugpfad über `xcode` begrenzt. Ein inkompatibles Override oder `npm audit fix --force` bleibt unzulässig; der Pfad wird mit einem kompatiblen Capacitor-/xcode-Update qualifiziert.
- `actions/download-artifact` wird im bestehenden RUC-Publishpfad auf v8.0.1 und den vollständigen Commit-SHA gepinnt. Die strengere Digest-Prüfung bleibt aktiv; ein Hash-Mismatch soll den Workflow fail-closed stoppen.
- Der alte gruppierte Dependabot-PR für React/MapLibre/Vite/Capacitor wird nicht als Paket übernommen. Die in diesem Vertrag festgelegten isolierten Kompatibilitätsmeilensteine bleiben maßgeblich.

## Wartungsfreigabe 05.10.2026 · v0.9.85.169

Capacitor Core/iOS/CLI 8.5.2, Share 8.0.2 und jsfive 0.4.2 sind gemeinsam mit Lockfile und nativen Referenzen geprüft. Die früher gelistete Capacitor-Patch-Empfehlung ist damit umgesetzt. Framework-/Karten-Major- und größere Minorupdates bleiben eigenständige Prüfvorhaben. Produktionsaudit: 0 bekannte Befunde; drei moderate Dev-/iOS-Werkzeugbefunde bleiben upstream, ohne inkompatible Overrides.

## v0.9.85.170 · CSS-Aggregate-Parser

PostCSS 8.5.28 (bereits transitiv durch Vite vorhanden) wird direkt und exakt als Entwicklungsabhängigkeit für die auditierte CSS-Kaskadenkonsolidierung deklariert. Keine Änderung an Produktionsabhängigkeiten oder Framework-Versionen.

## v0.9.85.253 · Advisory-Verfügbarkeit explizit ausweisen

Der bestehende Sonderfall eines reinen externen Advisory-Doppel-Ausfalls bleibt deferred (Exit 0 nach validiertem installiertem Produktionsbaum); er ist **keine Sicherheitsfreigabe**. `artifacts/dependency-audit.json`, die maschinenlesbare Logzeile und die GitHub-Step-Zusammenfassung müssen `state: unknown`, Lockfile-SHA-256, Prüfzeit, beide Providerfehler und `recheckRequired: true` ausweisen. Bei erfolgreicher vollständiger Quelle ist der Zustand `checked`, bei HIGH/CRITICAL `blocked` mit Exit 1. Unvollständige oder ungültige Quellantworten zählen als Quellenfehler. Bestehende Upgrade-Policy, unabhängiger vollständiger `audit:all` und Release-Gates bleiben verbindlich; kein Advisory-Ausfall darf als nachgewiesene Befundfreiheit beschrieben werden. Nachprüfung über den bestehenden regelmäßigen Dependency-/Revisionsaudit; bei einer erfolglosen Nachprüfung bleibt die Sicherheitsbewertung offen.

### HIGH-Patch im CSS-Buildpfad

`postcss 8.5.28 -> source-map-js ^1.2.1` wird ohne Override und ohne PostCSS-/Vite-Migration auf den kompatiblen Lockfile-Patch **1.2.2** angehoben. GHSA-68fv-2mgg-jv7q / CVE-2026-93749 betrifft indexed source-map section offsets bis 1.2.1. Die Upgrade-Policy verbietet künftig betroffene source-map-js-Versionen im 1.x-Pfad. Vollständiger npm-Audit, Rebuild, CSS-Kaskaden-/Bundle-/Regressionen sind erforderlich. Die drei moderaten Capacitor/xcode/uuid-Dev-Befunde bleiben getrennt upstream; kein force-fix, kein Capacitor-Downgrade.

## Isolierte Qualifikation 25.10.2026 · PostCSS 8.5.31

Ausgangsbasis ist der veröffentlichte Stable-Stand .328 (`7b7d94447d584dc7b7ee4bad7549150ad19c916c`). PostCSS bleibt eine exakte direkte Entwicklungsabhängigkeit und wird separat auf 8.5.31 aktualisiert. Die verifizierte Registry-Metadaten-SRI für das Release stimmt mit dem Lockfile überein. PostCSS 8.5.31 verlangt `nanoid ^3.3.20` und `source-map-js ^1.2.2`; Lockfile-Auflösung ist `nanoid 3.3.20`, `source-map-js 1.2.2`. Keine Overrides, kein `npm audit fix --force`, keine React-/Vite-/plugin-react-/Capacitor-/MapLibre-/Pako-Änderung. Der freigegebene .328-Produktions-CSS-Hash ist die bytegenaue Vergleichsbasis; CSS-Kaskaden-, Theme-, Widget-, Export- und Bundleverträge bleiben bestehen.

## Sicherheitswartung 21.10.2026 · v0.9.85.306

Vite8.2.2 wird innerhalb derselben8.2-Reihe auf8.2.4 aktualisiert. Die offiziellen Advisories GHSA-587h-7wmj-h5pm (HIGH), GHSA-698v-4r3x-3vcv und GHSA-r825-w8mm-5pxw betreffen den gebündelten launch-editor bis2.14.1; für Vite8.2 ist8.2.4 als korrigierter Patch benannt. Kein Override/force-fix und kein Framework-/Bundler-Majorwechsel. plugin-react6.1.1, Node22.16 und bestehende Oxc-/Rolldown-/Lightning-CSS-Konfiguration bleiben. npm erzeugt das Lockfile aus dem Registry-Paket neu; keine manuell erdachten Integritätswerte. Der bekannte moderate Capacitor/xcode/uuid-Pfad bleibt separat und wird nicht inkompatibel überschrieben. Vollständiger Audit, Types, Build, CSS-/Karten-/Export-/iOS- und Release-Gates bleiben erforderlich.

## Native Plugin-Patchqualifikation 29.10.2026 · v0.9.85.362

Selektiver zusammenhängender Teil aus #474 auf freigegebenem Stable .361 `3b158eaf9634faa70c5c290da2171248dbf923bc`: App 8.1.2, Browser 8.0.5, Filesystem 8.1.5, Geolocation 8.2.4, Share 8.0.3, StatusBar 8.0.4. Exakte npm-Pins, regulär neu aufgelöstes Lockfile; keine Overrides. Die sechs Plugins akzeptieren Capacitor Core >=8.0.0; Core/iOS/CLI bleiben synchron auf 8.5.3, SplashScreen 8.0.2. Filesystem 8.1.4 enthält die Directory-Pfadbegrenzung, 8.1.5 die nachfolgende Temporary-Korrektur; MID teilt weiterhin ausschließlich eine bereinigte Datei unter Directory.Cache mit Cleanup. Native Plugin-APIs und SPM-Abhängigkeiten werden nach Sync geprüft; physisches Xcode-/WKWebView-/VoiceOver- und Android-Geräteverhalten ist kein aus Node- oder Webtests ableitbarer Nachweis.

React 19.3.1 und MapLibre GL JS 6.15.0 bleiben deshalb zurückgestellt; ihre bereits nachgewiesenen Budgetverletzungen werden nicht durch dieses Paket gelockert. Auch Lucide bleibt 1.40.0. #474 bleibt für diese offenen Kandidaten bestehen. Alle bestehenden Source-, Core-, Heavy-, Budget-, Audit-, Installer- und Worker/Pages-Gates bleiben erforderlich.


## Isolierte CodeQL-v4.39.1-QA · 11.11.2026 (noch kein Stable-Release)

- **CodeQL: 4.39.1**: Die bisherigen v4.38.2-Einträge im historischen .332-Vertrag oben bleiben als damals gültige Angaben erhalten. Der aktuelle QA-Draft #759 qualifiziert die gepinnten Actions `init` und `analyze` gemeinsam unter `9b3254085494b55a0f7c4c2b3d2d52cc712ce370` (offizielles, SHA-verifiziertes Ziel des annotierten Tags `v4.39.1`).
- Das bestehende explizite `scripts/sync-github-workflows.mjs` verwendet denselben Pin und dieselbe Versionskommentierung wie aktiver und kanonischer `mid-code-revision.yml`-Workflow; Core-Regressionsprüfungen überwachen die Synchronisierung, vollständigen SHA-Pins und das Ausbleiben unbeabsichtigter Installer- oder Privilegänderungen.
- Diese QA ist **keine Freigabe**, kein CI-/CodeQL-Alert-Nachweis für `main` und kein Update der X/Y/Z/W-Version. Selektiver Import erst nach vollständiger exact-HEAD-Regression, unabhängiger Review-Triage und über den etablierten versionierten MID-Source→Bot→ZIP→Installer→Worker/Pages→Stable-Pfad. Ohne verifizierten Release behalten produktive Stable-Pins ihren bisherigen Status.
