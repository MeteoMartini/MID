# MID v0.8.27.3 – Wartungsupdate

## Schwerpunkt
Gezielte Korrekturen für die Ensemble-Ansicht und den Favoriten-Schnellzugriff.

## Umgesetzt
1. **Ensemble-Tooltip stabilisiert**
   - Mobile Tooltips werden bei kompaktem Layout nun fest am oberen Diagrammbereich verankert.
   - Zusätzliche `z-index`-/Overflow-Korrekturen verhindern, dass der Tooltip vom nachfolgenden Diagramm überdeckt wird.
   - Meta-Zeilen im Tooltip wurden weiter gegen unerwünschte Umbrüche abgesichert.

2. **Bewölkungs-/Wetterkästchen präzisiert**
   - Zellengeometrie vereinheitlicht und innerhalb des Tagesrasters sauberer zentriert.
   - Clip-Bereich der Kästchen näher an den Rahmen gelegt, sodass Niederschlagssymbole die verfügbare Fläche besser nutzen.
   - Gewittersymbol vergrößert und kontrastreicher gestaltet.

3. **Favoriten-Schnellzugriff reaktionssicherer**
   - Pointer-Capture für Touch-Auswahl ergänzt, damit `pointerup` auch bei leichtem Verziehen zuverlässig ankommt.
   - Klick-Sperrfenster nach Touch-Auswahl verkürzt.
   - Touch-Aktion der Favoritenbuttons auf direkte Bedienung optimiert.

## Betroffene Dateien
- `src/EnsemblePanel.tsx`
- `src/App.tsx`
- `src/styles.css`
- Versionsdateien (`package.json`, `MID_BASELINE.json`, `public/version.json`, `public/sw.js`, `public/service-worker.js`, `src/version.ts`)

## Versionslogik
- Vorher: `0.8.27.2`
- Neu: `0.8.27.3`
- Begründung: reines Bugfix-/Wartungsupdate ohne Funktionssprung.

## Prüfung
- `npm run test:versioning` ✅
- Vollständiger `npm run build` konnte in der lokalen Arbeitsumgebung nicht abgeschlossen werden, da die Projektabhängigkeiten (`node_modules`) in der bereitgestellten CAAS-Arbeitskopie nicht installiert waren.
