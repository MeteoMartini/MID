import {useEffect,useState} from 'react';
import {ImageOverlay} from 'react-leaflet';
import type {LatLngBoundsExpression} from 'leaflet';
import type {Px250Meta} from './Px250Source';

type Status='idle'|'loading'|'ready'|'error';
type OverlayState={url:string;bounds:LatLngBoundsExpression};
type H5Node={value?:ArrayLike<number>|unknown;shape?:number[];attrs?:Record<string,unknown>};

function text(value:unknown):string{
 if(typeof value==='string')return value.replace(/\0/g,'').trim();
 if(value instanceof Uint8Array)return new TextDecoder().decode(value).replace(/\0/g,'').trim();
 if(ArrayBuffer.isView(value)){const view=value as unknown as ArrayLike<number>;return Array.from({length:view.length},(_,i)=>String.fromCharCode(Number(view[i])||0)).join('').replace(/\0/g,'').trim()}
 if(Array.isArray(value)&&value.every(x=>typeof x==='number'))return String.fromCharCode(...value).replace(/\0/g,'').trim();
 return String(value??'').replace(/\0/g,'').trim();
}
function scalar(value:unknown):number|undefined{
 if(ArrayBuffer.isView(value)){const v=value as unknown as ArrayLike<number>;value=v.length?v[0]:undefined}
 else if(Array.isArray(value))value=value[0];
 const n=Number(value);return Number.isFinite(n)?n:undefined;
}
function attr(node:H5Node|undefined,...names:string[]):unknown{
 const attrs=node?.attrs??{};for(const name of names){if(name in attrs)return attrs[name];const found=Object.keys(attrs).find(k=>k.toLowerCase()===name.toLowerCase());if(found)return attrs[found]}return undefined;
}
type RasterProjection={kind:'stere'|'laea';lat0:number;latTs:number;lon0:number;x0:number;y0:number;a:number};
function param(definition:string,name:string,fallback:number){const match=definition.match(new RegExp(`(?:^|\s)\+${name}=([^\s]+)`,'i')),value=match?Number(match[1]):NaN;return Number.isFinite(value)?value:fallback}
function projectionFrom(where:H5Node|undefined):RasterProjection|null{const definition=text(attr(where,'projdef','projection_definition','proj4'));if(!definition)return null;const kind=/\+proj=laea\b/i.test(definition)?'laea':/\+proj=stere\b/i.test(definition)?'stere':null;if(!kind)return null;return{kind,lat0:param(definition,'lat_0',kind==='stere'?90:52),latTs:param(definition,'lat_ts',60),lon0:param(definition,'lon_0',10),x0:param(definition,'x_0',kind==='stere'?0:4321000),y0:param(definition,'y_0',kind==='stere'?0:3210000),a:param(definition,'a',param(definition,'R',6370040))}}
function inverseProjected(x:number,y:number,projection:RasterProjection):[number,number]|null{const radians=Math.PI/180,dx=x-projection.x0,dy=y-projection.y0,rho=Math.hypot(dx,dy),lon0=projection.lon0*radians;if(projection.kind==='stere'){const scale=projection.a*(1+Math.sin(projection.latTs*radians)),phi=Math.PI/2-2*Math.atan2(rho,scale),lambda=lon0+Math.atan2(dx,-dy);return[phi/radians,((lambda/radians+540)%360)-180]}if(rho<1e-9)return[projection.lat0,projection.lon0];const phi0=projection.lat0*radians,c=2*Math.asin(Math.min(1,rho/(2*projection.a))),sinC=Math.sin(c),cosC=Math.cos(c),phi=Math.asin(cosC*Math.sin(phi0)+(dy*sinC*Math.cos(phi0))/rho),lambda=lon0+Math.atan2(dx*sinC,rho*Math.cos(phi0)*cosC-dy*Math.sin(phi0)*sinC);return[phi/radians,((lambda/radians+540)%360)-180]}
function projectedBounds(file:{get(path:string):H5Node},dataset:H5Node):LatLngBoundsExpression|null{const where=(()=>{for(const path of['where','dataset1/where','dataset1/data1/where','dataset1/data2/where','dataset2/where']){try{const node=file.get(path);if(node)return node}catch{}}return undefined})(),projection=projectionFrom(where),shape=dataset.shape??[],height=Number(shape[0]),width=Number(shape[1]);if(!projection||!width||!height)return null;const xScale=Math.abs(scalar(attr(where,'xscale','x_scale'))??250),yScale=Math.abs(scalar(attr(where,'yscale','y_scale'))??250),llX=scalar(attr(where,'LL_x','ll_x')),ulX=scalar(attr(where,'UL_x','ul_x')),urX=scalar(attr(where,'UR_x','ur_x')),llY=scalar(attr(where,'LL_y','ll_y')),ulY=scalar(attr(where,'UL_y','ul_y')),urY=scalar(attr(where,'UR_y','ur_y')),minX=llX??ulX??(urX!==undefined?urX-width*xScale:undefined),maxY=urY??ulY??(llY!==undefined?llY+height*yScale:undefined);if(minX===undefined||maxY===undefined)return null;const maxX=minX+width*xScale,minY=maxY-height*yScale,corners=[[minX,maxY],[maxX,maxY],[minX,minY],[maxX,minY]].map(([x,y])=>inverseProjected(x,y,projection)).filter((value):value is [number,number]=>Boolean(value&&Number.isFinite(value[0])&&Number.isFinite(value[1])));if(corners.length!==4)return null;const lats=corners.map(row=>row[0]),lons=corners.map(row=>row[1]),south=Math.min(...lats),north=Math.max(...lats),west=Math.min(...lons),east=Math.max(...lons);if(north-south<=0||east-west<=0||north-south>30||east-west>45)return null;return[[south,west],[north,east]]}
function colour(dbz:number):[number,number,number,number]{
 if(!Number.isFinite(dbz)||dbz<5)return[0,0,0,0];
 if(dbz<10)return[217,243,255,145];if(dbz<20)return[114,201,255,180];if(dbz<30)return[47,145,227,205];if(dbz<40)return[67,200,121,220];if(dbz<50)return[240,212,71,232];if(dbz<55)return[245,155,61,238];if(dbz<60)return[227,75,75,242];return[184,63,200,245];
}
function approximateBounds(lat:number,lon:number,rangeKm:number):LatLngBoundsExpression{
 if(!Number.isFinite(lat)||!Number.isFinite(lon))return[[46.55,4.2],[55.95,15.95]];
 const dy=rangeKm/111.32,dx=rangeKm/(111.32*Math.max(.25,Math.cos(lat*Math.PI/180)));return[[lat-dy,lon-dx],[lat+dy,lon+dx]];
}
function boundsFromFile(file:{get(path:string):H5Node},meta:Px250Meta,dataset:H5Node):LatLngBoundsExpression{
 const nodes=['where','dataset1/where','dataset1/data1/where','dataset1/data2/where','dataset2/where'].map(path=>{try{return file.get(path)}catch{return undefined}}).filter(Boolean) as H5Node[];
 const readBounds=(where:H5Node|undefined)=>{const llLat=scalar(attr(where,'LL_lat','ll_lat')),llLon=scalar(attr(where,'LL_lon','ll_lon')),urLat=scalar(attr(where,'UR_lat','ur_lat')),urLon=scalar(attr(where,'UR_lon','ur_lon')),ulLat=scalar(attr(where,'UL_lat','ul_lat')),ulLon=scalar(attr(where,'UL_lon','ul_lon')),lrLat=scalar(attr(where,'LR_lat','lr_lat')),lrLon=scalar(attr(where,'LR_lon','lr_lon')),south=scalar(attr(where,'south','min_lat','lat_min')),west=scalar(attr(where,'west','min_lon','lon_min')),north=scalar(attr(where,'north','max_lat','lat_max')),east=scalar(attr(where,'east','max_lon','lon_max'));
  if([llLat,llLon,urLat,urLon].every(Number.isFinite))return[[llLat!,llLon!],[urLat!,urLon!]] as LatLngBoundsExpression;
  if([ulLat,ulLon,lrLat,lrLon].every(Number.isFinite))return[[lrLat!,ulLon!],[ulLat!,lrLon!]] as LatLngBoundsExpression;
  if([south,west,north,east].every(Number.isFinite))return[[south!,west!],[north!,east!]] as LatLngBoundsExpression;
  return null;
 };
 for(const node of nodes){const candidate=readBounds(node);if(candidate)return candidate}
 const projected=projectedBounds(file,dataset);if(projected)return projected;
 if(meta.product==='hx')return[[46.2,3.6],[56.2,16.4]];
 return approximateBounds(Number(meta.radarLat),Number(meta.radarLon),Number(meta.rangeKm)||150);
}
function findDataset(file:{get(path:string):H5Node}):H5Node{
 for(const path of['dataset1/data1/data','dataset1/data2/data','dataset2/data1/data']){try{const node=file.get(path);if(node?.value&&node?.shape?.length===2)return node}catch{}}
 throw new Error('Kein unterstütztes Reflektivitätsraster im HDF5 gefunden.');
}
function renderDataset(file:{get(path:string):H5Node},dataset:H5Node):HTMLCanvasElement{
 const shape=dataset.shape??[],height=Number(shape[0]),width=Number(shape[1]),sourcePixels=width*height;if(!width||!height||sourcePixels>30_000_000)throw new Error('Ungültige 250-m-Rastergröße.');
 const what=(()=>{for(const path of['dataset1/data1/what','dataset1/data2/what','dataset2/data1/what']){try{const n=file.get(path);if(n)return n}catch{}}return undefined})(),gain=scalar(attr(what,'gain'))??0.5,offset=scalar(attr(what,'offset'))??-32.5,nodata=scalar(attr(what,'nodata'))??65535,undetect=scalar(attr(what,'undetect'))??0,quantity=text(attr(what,'quantity')).toUpperCase();
 const source=dataset.value as ArrayLike<number>;if(!source||source.length<width*height)throw new Error('PX250-Raster ist unvollständig.');
 const memory=Number((navigator as any).deviceMemory)||4,maxPixels=memory<=2?4_000_000:memory<=4?7_000_000:12_000_000,scale=Math.min(1,Math.sqrt(maxPixels/sourcePixels)),outWidth=Math.max(1,Math.round(width*scale)),outHeight=Math.max(1,Math.round(height*scale));
 const canvas=document.createElement('canvas');canvas.width=outWidth;canvas.height=outHeight;const context=canvas.getContext('2d',{alpha:true});if(!context)throw new Error('Canvas nicht verfügbar.');const image=context.createImageData(outWidth,outHeight),pixels=image.data;
 for(let y=0;y<outHeight;y++)for(let x=0;x<outWidth;x++){const sourceX=Math.min(width-1,Math.floor(x/scale)),sourceY=Math.min(height-1,Math.floor(y/scale)),raw=Number(source[sourceY*width+sourceX]);let rgba:[number,number,number,number];if(!Number.isFinite(raw)||raw===nodata||raw===undetect)rgba=[0,0,0,0];else{const value=raw*gain+offset;rgba=colour(quantity.includes('RATE')?10*Math.log10(Math.max(.01,value)*200):value)}const p=(y*outWidth+x)*4;pixels[p]=rgba[0];pixels[p+1]=rgba[1];pixels[p+2]=rgba[2];pixels[p+3]=rgba[3]}
 context.putImageData(image,0,0);return canvas;
}
export default function Px250Overlay({meta,opacity,onStatus}:{meta:Px250Meta;opacity:number;onStatus?:(status:Status,message?:string)=>void}){
 const[overlay,setOverlay]=useState<OverlayState|null>(null);
 useEffect(()=>{let alive=true,objectUrl='';setOverlay(null);onStatus?.('loading');(async()=>{if(!meta.fileUrl)throw new Error(meta.reason||'Keine 250-m-Radardatei verfügbar.');const response=await fetch(meta.fileUrl,{cache:'no-store'});if(!response.ok)throw new Error(`250-m-Radardatei HTTP ${response.status}`);const buffer=await response.arrayBuffer();const hdf5=await import('jsfive');const file=new hdf5.File(buffer,meta.fileUrl);const dataset=findDataset(file);const canvas=renderDataset(file,dataset);const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error('250-m-Radar-PNG konnte nicht erzeugt werden.')),'image/png'));if(!alive)return;objectUrl=URL.createObjectURL(blob);setOverlay({url:objectUrl,bounds:boundsFromFile(file,meta,dataset)});onStatus?.('ready')})().catch(error=>{if(alive)onStatus?.('error',error instanceof Error?error.message:String(error))});return()=>{alive=false;if(objectUrl)URL.revokeObjectURL(objectUrl)}},[meta.fileUrl,meta.reason,meta.radarLat,meta.radarLon,meta.rangeKm,onStatus]);
 return overlay?<ImageOverlay url={overlay.url} bounds={overlay.bounds} opacity={opacity} zIndex={390}/>:null;
}
