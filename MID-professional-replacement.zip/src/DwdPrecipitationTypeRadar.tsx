import {useEffect,useMemo,useRef,useState,type MouseEvent} from 'react';
import {ExternalLink,Info,RotateCcw,ZoomIn,ZoomOut} from 'lucide-react';
import {buildWorkerUrl,fetchWorkerJson,workerBaseCandidates} from './workerClient';
import type {Location} from './weather';
import {formatDisplayDateTime} from './timeDisplay';

const DWD_PRODUCT_PAGE='https://www.dwd.de/DE/leistungen/wolken_niederschlagsart/wolken_niederschlagsart.html';
const COVERAGE={west:5.45,east:15.55,south:47.0,north:55.2};
export const DWD_PRECIPITATION_TYPE_COVERAGE=COVERAGE;
export const DWD_PRECIPITATION_TYPE_LEGEND=[
 {label:'großer Hagel',color:'#b000d6'},{label:'kleiner Hagel',color:'#d000f5'},{label:'Graupel',color:'#ffd633'},{label:'gefrierender Regen',color:'#ff1c00'},{label:'gefr. Sprühregen',color:'#d80000'},{label:'Schnee',color:'#ff21d1'},{label:'Schneeregen',color:'#ff70df'},{label:'Regen',color:'#00c778'},{label:'Sprühregen',color:'#19dca4'},{label:'nicht klassifizierbar',color:'#7f7f7f'},{label:'kein Niederschlag',color:'#c9c9c9'}
] as const;

type RadarMeta={observedAt?:string;publishedAt?:string;radarAt?:string;satelliteAt?:string;componentTimeNote?:string};
type RadarPointInfo={error?:string;precipitationLabel:string;precipitationColor?:string;cloudLabel:string;confidence?:'high'|'medium'|'low';observedAt?:string;rgb?:[number,number,number];note?:string};
type PointInspection={loading:boolean;error?:string;info?:RadarPointInfo};

function countryCode(location:Location){return String(location.country_code||location.country||'').trim().toUpperCase()}
export function dwdPrecipitationTypeCoverage(location:Location){const latitude=Number(location.latitude),longitude=Number(location.longitude),code=countryCode(location),within=Number.isFinite(latitude)&&Number.isFinite(longitude)&&latitude>=COVERAGE.south&&latitude<=COVERAGE.north&&longitude>=COVERAGE.west&&longitude<=COVERAGE.east;if(code&&code!=='DE'&&code!=='DEU'&&code!=='GERMANY'&&code!=='DEUTSCHLAND')return false;return within}
function formatDwdSourceTimestamp(value:string|undefined){return value?formatDisplayDateTime(value,undefined,{hour:'2-digit',minute:'2-digit',hourCycle:'h23'}):'–'}
function exactProductUrls(slot:number){return workerBaseCandidates('radar').map(base=>buildWorkerUrl(base,'dwd-precipitation-type-image',{slot}).toString())}

export function DwdPrecipitationTypeRadar({location,enabled=true}:{location:Location;enabled?:boolean}){
 const covered=dwdPrecipitationTypeCoverage(location),[refreshSlot,setRefreshSlot]=useState(()=>Math.floor(Date.now()/300000)),[imageUrl,setImageUrl]=useState(''),[meta,setMeta]=useState<RadarMeta|null>(null),[loading,setLoading]=useState(false),[error,setError]=useState(''),[pointInfo,setPointInfo]=useState<PointInspection|null>(null),[zoom,setZoom]=useState(1),viewportRef=useRef<HTMLDivElement|null>(null),urls=useMemo(()=>exactProductUrls(refreshSlot),[refreshSlot]);
 useEffect(()=>{const timer=window.setInterval(()=>setRefreshSlot(Math.floor(Date.now()/300000)),60000);return()=>window.clearInterval(timer)},[]);
 useEffect(()=>{
  if(!enabled||!covered){setImageUrl('');setMeta(null);setLoading(false);setError('');return}
  let cancelled=false,objectUrl='';setLoading(true);setError('');setPointInfo(null);
  const load=async()=>{let lastError='';for(const url of urls){try{const response=await fetch(url,{cache:'no-store'});if(!response.ok)throw new Error(`DWD-Bild HTTP ${response.status}`);const type=String(response.headers.get('content-type')||'');if(!type.startsWith('image/'))throw new Error('DWD-Antwort ist kein Bild.');const blob=await response.blob();if(cancelled)return;objectUrl=URL.createObjectURL(blob);setImageUrl(objectUrl);setMeta({observedAt:response.headers.get('x-mid-observed-at')||undefined,publishedAt:response.headers.get('last-modified')||undefined,radarAt:response.headers.get('x-mid-radar-at')||undefined,satelliteAt:response.headers.get('x-mid-satellite-at')||undefined,componentTimeNote:'Radar- und Satellitenzeit stammen aus derselben Worker-Antwort wie das dargestellte amtliche DWD-Originalbild.'});setLoading(false);return}catch(nextError){lastError=nextError instanceof Error?nextError.message:String(nextError)}}if(cancelled)return;setImageUrl('');setMeta(null);setLoading(false);setError(lastError||'DWD-Originalprodukt derzeit nicht verfügbar.')};
  void load();return()=>{cancelled=true;if(objectUrl)URL.revokeObjectURL(objectUrl)}
 },[enabled,covered,urls]);
 if(!enabled||!covered)return null;
 const changeZoom=(next:number)=>{const viewport=viewportRef.current,previous=zoom,clamped=Math.max(1,Math.min(5,Math.round(next)));if(clamped===previous)return;const centerX=viewport?viewport.scrollLeft+viewport.clientWidth/2:0,centerY=viewport?viewport.scrollTop+viewport.clientHeight/2:0;setZoom(clamped);window.requestAnimationFrame(()=>{if(!viewport)return;const ratio=clamped/previous;viewport.scrollLeft=Math.max(0,centerX*ratio-viewport.clientWidth/2);viewport.scrollTop=Math.max(0,centerY*ratio-viewport.clientHeight/2)})};
 const resetZoom=()=>{setZoom(1);window.requestAnimationFrame(()=>{if(viewportRef.current){viewportRef.current.scrollLeft=0;viewportRef.current.scrollTop=0}})};
 const inspectPoint=async(event:MouseEvent<HTMLImageElement>)=>{if(!imageUrl||loading)return;const rect=event.currentTarget.getBoundingClientRect(),x=Math.min(1,Math.max(0,(event.clientX-rect.left)/Math.max(1,rect.width))),y=Math.min(1,Math.max(0,(event.clientY-rect.top)/Math.max(1,rect.height)));setPointInfo({loading:true});try{const info=await fetchWorkerJson<RadarPointInfo>('dwd-precipitation-type-info',{x:x.toFixed(6),y:y.toFixed(6),expected:meta?.observedAt||''},{purpose:'radar',timeoutMs:10000,maxAgeMs:2*60000,staleIfErrorMs:5*60000,cacheKey:`dwd-precip-info:${meta?.observedAt||refreshSlot}:${x.toFixed(3)}:${y.toFixed(3)}`});setPointInfo({loading:false,info})}catch(nextError){setPointInfo({loading:false,error:nextError instanceof Error?nextError.message:'Punktanalyse nicht verfügbar.'})}};
 return <section className="dwd-precip-type-radar" aria-label="DWD Wolken und Niederschlagsart"><header><span><small>DWD · amtliches Kombinationsprodukt</small><strong>Wolken + Niederschlagsart</strong><em>Originalbild · zoombar · {location.name||'gewählter Ort'}</em></span><div className="dwd-precip-type-radar__actions"><details className="dwd-precip-type-radar__info"><summary aria-label="Legende der Niederschlagsarten anzeigen" title="Legende"><Info size={16}/></summary><div className="dwd-precip-type-radar__legend" role="group" aria-label="DWD-Legende Niederschlagsarten"><strong>Niederschlagsart</strong>{DWD_PRECIPITATION_TYPE_LEGEND.map(item=><span key={item.label}><i style={{background:item.color}}/>{item.label}</span>)}</div></details><a href={DWD_PRODUCT_PAGE} target="_blank" rel="noreferrer" title="DWD-Originalprodukt öffnen"><ExternalLink size={16}/><span>DWD</span></a></div></header>
 <div className="dwd-precip-type-radar__timestamps"><span><b>Radar</b>{formatDwdSourceTimestamp(meta?.radarAt)}</span><span><b>Sat</b>{formatDwdSourceTimestamp(meta?.satelliteAt)}</span>{pointInfo?<span className="dwd-precip-type-radar__point-strip"><b>Bildpunkt</b>{pointInfo.loading?'wird ausgewertet …':pointInfo.error?pointInfo.error:pointInfo.info?`${pointInfo.info.precipitationLabel} · Wolken: ${pointInfo.info.cloudLabel}`:'–'}</span>:<span className="dwd-precip-type-radar__point-strip idle"><b>Bildpunkt</b>Antippen zur Auswertung</span>}<small title={meta?.componentTimeNote}>Zeitstände gehören zum angezeigten Originalprodukt</small></div>
 <div className="dwd-precip-type-radar__zoom-toolbar" aria-label="Bildzoom"><button type="button" onClick={()=>changeZoom(zoom-1)} disabled={zoom<=1} title="Verkleinern"><ZoomOut size={15}/></button><b>{Math.round(zoom*100)} %</b><button type="button" onClick={()=>changeZoom(zoom+1)} disabled={zoom>=5} title="Vergrößern"><ZoomIn size={15}/></button><button type="button" onClick={resetZoom} disabled={zoom===1} title="Ansicht zurücksetzen"><RotateCcw size={14}/><span>100 %</span></button></div>
 <div className="dwd-precip-type-radar__viewport-shell">
  {zoom>1?<button type="button" className="dwd-precip-type-radar__zoom-escape" onClick={resetZoom} aria-label="Zoom auf 100 Prozent zurücksetzen" title="Zur Gesamtansicht zurück"><RotateCcw size={14}/><span>100 %</span></button>:null}
  <div ref={viewportRef} className={`dwd-precip-type-radar__original-viewport${loading?' loading':''}${error?' failed':''}`}>
   {loading?<span className="dwd-precip-type-radar__status">DWD-Originalprodukt wird geladen …</span>:null}
   {!loading&&error?<span className="dwd-precip-type-radar__status">{error}</span>:null}
   {!loading&&!error&&imageUrl?<img className="dwd-precip-type-radar__original-image" src={imageUrl} alt="Amtliches DWD-Kombinationsbild aus Satellit und Radar-Niederschlagsart" style={{width:`${zoom*100}%`}} onClick={inspectPoint} draggable={false}/>:null}
  </div>
 </div><footer><span>Amtliches DWD-Originalbild ohne eigene Rekonstruktion. Zoomen verändert ausschließlich die Ansicht; Bildpunkt-Auswertung bleibt an den Originalpixel gebunden.</span><small>Quelle: Deutscher Wetterdienst</small></footer></section>;
}
