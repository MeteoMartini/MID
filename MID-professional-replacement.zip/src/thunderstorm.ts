import type {Hour,RadarNowcast,Station,ThunderstormNowcast} from './weather';

export type ThunderInfoLevel='yellow'|'orange'|'red'|'purple';
export type ThunderInfoDetail={label:string;value:string};
export type ThunderInfoFact={label:string;value:string};
export type ThunderInfo={level:ThunderInfoLevel;headline:string;summary:string;source:string;details?:ThunderInfoDetail[];quickFacts?:ThunderInfoFact[];detailLead?:string;advisory?:string};

const SEVERITY_LABELS=['schwach','moderat','stark','extrem'] as const;
function severityLevel(severity:number,hailFlag:number,heavyRainFlag:number):ThunderInfoLevel{const score=Math.max(Number(severity)||0,Number(hailFlag)||0,Number(heavyRainFlag)||0);return score>=3?'purple':score>=2?'red':score>=1?'orange':'yellow'}
function severityText(value:number){return SEVERITY_LABELS[Math.max(0,Math.min(3,Math.round(Number(value)||0)))]}
function trendText(value:number){return value>=2?'schnell anwachsend':value===1?'anwachsend':value<=-2?'schnell abschwächend':value===-1?'abschwächend':'stabil'}
function compassWord(value:number|undefined){if(!Number.isFinite(Number(value)))return'';const labels=['nördlich','nordöstlich','östlich','südöstlich','südlich','südwestlich','westlich','nordwestlich'];return labels[Math.round((((Number(value)%360)+360)%360)/45)%8]}
function compassShort(value:number|undefined){if(!Number.isFinite(Number(value)))return'–';const labels=['N','NO','O','SO','S','SW','W','NW'];return`${Math.round(Number(value))}° ${labels[Math.round((((Number(value)%360)+360)%360)/45)%8]}`}
function decimal(value:number|undefined,digits=1){return Number.isFinite(Number(value))?new Intl.NumberFormat('de-DE',{minimumFractionDigits:0,maximumFractionDigits:digits}).format(Number(value)):'–'}
function zulu(value?:string){if(!value)return'–';const date=new Date(value);return Number.isFinite(date.getTime())?`${date.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',timeZone:'UTC'})} ${date.toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit',timeZone:'UTC'})}Z`:'–'}
function coordinate(lat:number|undefined,lon:number|undefined){return Number.isFinite(Number(lat))&&Number.isFinite(Number(lon))?`${decimal(lat,3)}° N · ${decimal(lon,3)}° E`:'–'}
function flagText(value:number|undefined,none='kein Signal'){const number=Number(value);return Number.isFinite(number)&&number>0?`Stufe ${Math.round(number)}`:none}
function cellDetailsShort(cell:NonNullable<ThunderstormNowcast['nearest']>){const details=[`KONRAD3D ${severityText(cell.severity)}`,trendText(cell.trend)];if(cell.lightningRate>0)details.push(`${Math.round(cell.lightningRate)} Blitze/5 min`);if(cell.hailFlag>0||cell.areaHail>0)details.push(cell.hailFlag>=2||cell.areaLargeHail>0?'Großhagelsignal':'Hagelsignal');if(cell.heavyRainFlag>0)details.push(`Starkregenstufe ${cell.heavyRainFlag}`);if((cell.gustFlag??0)>0)details.push(`Böenstufe ${cell.gustFlag}`);return details.join(' · ')}
function stationRainText(station:Station|null){const rain=Number(station?.precipitation);if(!Number.isFinite(rain)||rain<.1)return'';return `${station?.provider?.includes('DWD')?'DWD-Station':'Station'} bestätigt Niederschlag`}
function gustSignalText(flag:number|undefined){const value=Math.round(Number(flag)||0);return value>=3?'teils über 100 km/h möglich':value===2?'bis etwa 90 km/h möglich':value===1?'bis etwa 75 km/h möglich':'kein markantes Böensignal'}
function hailSignalText(cell:NonNullable<ThunderstormNowcast['nearest']>){if(cell.areaLargeHail>0||cell.hailFlag>=2)return'größerer Hagel möglich';if(cell.areaHail>0||cell.hailFlag>=1)return'Hagel möglich';return'kein Hagelsignal'}
function heavyRainSignalText(flag:number|undefined){const value=Math.round(Number(flag)||0);return value>=3?'extremer Starkregen möglich':value===2?'heftiger Starkregen möglich':value===1?'Starkregen möglich':'kein Starkregensignal'}
function lightningActivityText(rate:number|undefined){const value=Number(rate);if(!Number.isFinite(value)||value<=0)return'keine Blitzaktivität im Zellobjekt';const activity=value>=30?'hoch':value>=15?'mäßig':'gering';return `${Math.round(value)} Blitze/5 min · Aktivität ${activity}`}
function locationFocusText(cell:NonNullable<ThunderstormNowcast['nearest']>,locationName:string,currentDistance:number,atSite:boolean){const direction=compassWord(cell.siteBearingDeg);return atSite?`unmittelbar bei ${locationName}`:Number.isFinite(currentDistance)?`${Math.max(1,Math.round(currentDistance))} km${direction?` ${direction}`:''} von ${locationName}`:`in der Nähe von ${locationName}`}
function arrivalWindowText(approaching:boolean,movingAway:boolean,arrival:number,forecastDistance:number){if(approaching&&Number.isFinite(arrival)&&arrival>0&&arrival<=90)return Number.isFinite(forecastDistance)?`in etwa ${Math.round(arrival)} min · ca. ${Math.max(0,Math.round(forecastDistance))} km`:`in etwa ${Math.round(arrival)} min`;if(movingAway&&Number.isFinite(forecastDistance))return`zieht voraussichtlich vorbei · danach ca. ${Math.round(forecastDistance)} km`;return'keine belastbare Annäherung'}
function threatHeadline(cell:NonNullable<ThunderstormNowcast['nearest']>,nearNow:boolean,atSite:boolean,approaching:boolean,movingAway:boolean){return atSite?'Gewitterzelle unmittelbar am Standort':nearNow?'Gewitterzelle nahe':approaching?'Gewitterzelle nähert sich':movingAway?'Gewitterzelle zieht voraussichtlich vorbei':'Gewitterzelle im Umfeld'}

export function combineThunderstormInformation(nowcast:ThunderstormNowcast|null,hours:Hour[],radar:RadarNowcast|null,station:Station|null,locationName='Standort'):ThunderInfo|null{
 const cell=nowcast?.nearest;
 if(nowcast?.available&&cell&&cell.relevanceDistanceKm<=80){
  const currentDistanceRaw=Number(cell.currentDistanceKm),currentDistance=Number.isFinite(currentDistanceRaw)?Math.max(0,currentDistanceRaw):Number.NaN,forecastDistance=Number(cell.forecastDistanceKm),effectiveDistance=Number(cell.forecastEffectiveDistanceKm),uncertainty=Number(cell.forecastUncertaintyKm),arrival=Number(cell.arrivalMinutes),nearNow=Number.isFinite(currentDistance)&&currentDistance<=25,atSite=Number.isFinite(currentDistance)&&currentDistance<1,centerGetsCloser=Number.isFinite(currentDistance)&&Number.isFinite(forecastDistance)&&forecastDistance+2<currentDistance,approaching=Boolean(!nearNow&&cell.isApproaching&&centerGetsCloser&&Number.isFinite(arrival)&&arrival>0&&arrival<=90),movingAway=Boolean(!nearNow&&Number.isFinite(currentDistance)&&Number.isFinite(forecastDistance)&&forecastDistance>currentDistance+2),direction=compassWord(cell.siteBearingDeg),headline=threatHeadline(cell,nearNow,atSite,approaching,movingAway);
  const positionText=atSite?`Aktuell unmittelbar bei ${locationName}`:Number.isFinite(currentDistance)?`Aktuell ${Math.max(1,Math.round(currentDistance))} km${direction?` ${direction}`:''} von ${locationName}`:`Aktuelle Entfernung zu ${locationName} nicht belastbar verfügbar`;
  const approachText=approaching&&Number.isFinite(forecastDistance)?`; größte berechnete Annäherung des Zellzentrums in etwa ${Math.round(arrival)} min auf ca. ${Math.max(0,Math.round(forecastDistance))} km`:approaching?`; mögliche Annäherung in etwa ${Math.round(arrival)} min`:movingAway&&Number.isFinite(forecastDistance)?`; Zellzentrum in der Prognose anschließend ca. ${Math.round(forecastDistance)} km entfernt und damit nicht näher`:'';
  const hazardParts=[heavyRainSignalText(cell.heavyRainFlag),hailSignalText(cell),gustSignalText(cell.gustFlag)].filter(part=>!part.startsWith('kein '));
  const summary=`${positionText}${approachText}. ${hazardParts.length?`${hazardParts.join(' · ')}. `:''}${cellDetailsShort(cell)}.`;
  const quickFacts:ThunderInfoFact[]=[
   {label:'Schwerpunkt aktuell',value:locationFocusText(cell,locationName,currentDistance,atSite)},
   {label:'Mögliche Annäherung',value:arrivalWindowText(approaching,movingAway,arrival,forecastDistance)},
   {label:'Mögliche Windböen',value:gustSignalText(cell.gustFlag)},
   {label:'Hagelsignal',value:hailSignalText(cell)},
   {label:'Zugrichtung',value:Number.isFinite(Number(cell.motionDirectionDeg))?compassShort(cell.motionDirectionDeg):'–'},
   {label:'Zuggeschwindigkeit',value:cell.speedKmh>0?`${Math.round(cell.speedKmh||0)} km/h`:'–'},
   {label:'Blitzaktivität',value:lightningActivityText(cell.lightningRate)},
   {label:'Starkregen',value:heavyRainSignalText(cell.heavyRainFlag)}
  ];
  const details:ThunderInfoDetail[]=[
   {label:'Bezugsort',value:locationName},
   {label:'Zellkennung',value:cell.id},
   {label:'Aktuelle Zellposition',value:coordinate(cell.latitude,cell.longitude)},
   {label:'Aktuelle Entfernung / Richtung',value:atSite?`unter 1 km · ${compassShort(cell.siteBearingDeg)}`:Number.isFinite(currentDistance)?`${decimal(currentDistance)} km · ${compassShort(cell.siteBearingDeg)}`:'–'},
   {label:'Zellstufe / Trend',value:`${severityText(cell.severity)} · ${trendText(cell.trend)}`},
   {label:'Zellverlagerung',value:Number.isFinite(Number(cell.motionDirectionDeg))||cell.speedKmh>0?`nach ${compassShort(cell.motionDirectionDeg)} · ${Math.round(cell.speedKmh||0)} km/h`:'nicht belastbar verfügbar'},
   {label:'Prognostizierte Position',value:coordinate(cell.forecastLatitude,cell.forecastLongitude)},
   {label:'Prognosezeit',value:zulu(cell.forecastTime)},
   {label:'Abstand der prognostizierten Position',value:Number.isFinite(forecastDistance)?`${decimal(forecastDistance)} km`:'–'},
   {label:'Wirksamer Mindestabstand',value:Number.isFinite(effectiveDistance)?`${decimal(effectiveDistance)} km${Number.isFinite(uncertainty)?` · Unsicherheitsradius ${decimal(uncertainty)} km`:''}`:'–'},
   {label:'Blitzaktivität',value:cell.lightningRate>0?`${Math.round(cell.lightningRate)} Blitze je 5 min`:'kein Blitzsignal im Zellobjekt'},
   {label:'Hagel',value:`${flagText(cell.hailFlag)}${cell.areaHail>0?` · Hagelfläche ${decimal(cell.areaHail)} km²`:''}${cell.areaLargeHail>0?` · Großhagelfläche ${decimal(cell.areaLargeHail)} km²`:''}`},
   {label:'Starkregen',value:flagText(cell.heavyRainFlag)},
   {label:'Böen',value:flagText(cell.gustFlag)},
   {label:'Datenstand',value:`${zulu(nowcast.observedAt)}${Number.isFinite(Number(nowcast.ageMinutes))?` · ${Math.max(0,Math.round(Number(nowcast.ageMinutes)))} min alt`:''}`},
   {label:'Erkannte Zellen',value:`${nowcast.cellsFound} insgesamt · ${nowcast.nearbyCells.length} im 80-km-Umfeld`}
  ];
  return{level:severityLevel(cell.severity,cell.hailFlag,cell.heavyRainFlag),headline,summary,source:`DWD KONRAD3D · 5-minütig${Number.isFinite(Number(nowcast.ageMinutes))?` · ${Math.max(0,Math.round(Number(nowcast.ageMinutes)))} min alt`:''} · keine amtliche Warnung`,quickFacts,detailLead:`Automatische Gewitteranalyse für ${locationName}. Direkt sichtbar sind die wichtigsten Kerndaten; per Info-Button stehen die vollständigen Zell- und Prognosedetails zur Verfügung.`,advisory:'Hinweis: Es handelt sich um eine automatische KONRAD3D-/Radar-/Modellanalyse und nicht um eine amtliche Warnung. Lokal können Intensität, Zugbahn und Auswirkungen kurzfristig abweichen.',details};
 }
 const now=Date.now(),next=hours.filter(hour=>hour.epoch>=now-30*60000&&hour.epoch<=now+3*3600000),thunder=next.find(hour=>[95,96,97,98,99].includes(Math.round(hour.code))),highCape=Math.max(0,...next.map(hour=>Number(hour.cape)||0)),radarRate=Number(radar?.currentRate||0),stationRain=stationRainText(station),combinedConvectiveSignal=radarRate>=8&&highCape>=750;
 if(!thunder&&!combinedConvectiveSignal)return null;
 const severe=Boolean(thunder&&[96,97,98,99].includes(Math.round(thunder.code)))||highCape>=1800||radarRate>=25,extra=[thunder?'Best Match signalisiert Gewitter':'starkes Radarecho mit erhöhter Konvektionsenergie',radarRate>=8?`Radarecho ${Math.round(radarRate)} mm/h`:'',highCape>=750?`CAPE ${Math.round(highCape)} J/kg`:'',stationRain].filter(Boolean).join(' · '),quickFacts:ThunderInfoFact[]=[{label:'Zeitraum',value:'nächste 3 Stunden'},{label:'Radarintensität',value:radarRate>=.05?`${decimal(radarRate)} mm/h`:'kein Standortecho'},{label:'Konvektionsenergie',value:highCape>0?`${Math.round(highCape)} J/kg`:'nicht verfügbar'},{label:'KONRAD3D',value:nowcast?.summary||'keine relevante aktuelle Zelle'}];return{level:severe?'orange':'yellow',headline:'Gewittersignal',summary:`In den kommenden drei Stunden bei ${locationName}: ${extra}.`,source:'Modell-, Radar- und Stationsabgleich · keine amtliche Warnung',quickFacts,detailLead:`Es liegt derzeit keine nah relevante KONRAD3D-Zelle vor. Die Information basiert daher vor allem auf Modell-, Radar- und gegebenenfalls Stationssignalen.`,advisory:'Hinweis: Es handelt sich um eine automatische Vorabinformation und nicht um eine amtliche Warnung.',details:[{label:'Bezugsort',value:locationName},{label:'Radarintensität',value:radarRate>=.05?`${decimal(radarRate)} mm/h`:'kein Standortecho'},{label:'Konvektionsenergie',value:highCape>0?`${Math.round(highCape)} J/kg`:'nicht verfügbar'},{label:'KONRAD3D',value:nowcast?.summary||'keine relevante aktuelle Zelle'}]};
}
