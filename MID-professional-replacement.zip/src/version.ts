export const MID_VERSION='0.9.9.0';
