export const MID_VERSION='0.7.90.2';
