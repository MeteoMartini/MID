export const MID_VERSION='0.8.9.0';
