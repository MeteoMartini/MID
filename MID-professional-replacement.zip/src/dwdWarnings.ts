export type DwdWarningLevel=1|2|3|4;
export type DwdWarningKind='wind'|'thunderstorm'|'heavyRain'|'continuousRain'|'snow'|'snowdrift'|'ice'|'frost'|'fog'|'heat';
export type DwdWarningSample={
 time?:string;
 epoch?:number;
 temperature?:number;
 apparent?:number;
 precipitation?:number;
 rain?:number;
 showers?:number;
 snowfall?:number;
 gust?:number;
 windDirection?:number;
 code?:number;
 visibility?:number;
 uvIndex?:number;
 isDay?:boolean;
};
export type DwdDisplayWindUnit='kn'|'kt'|'kmh'|'ms'|'mph';
export type DwdWarningSignal={kind:DwdWarningKind;level:DwdWarningLevel;title:string;symbol:string;detail:string;value:number;unit:string;windowHours?:number;secondaryValue?:number;secondaryUnit?:string;validFrom?:string;validTo?:string;windDirection?:number;windDirectionText?:string};

export const DWD_WARNING_COLORS:Record<DwdWarningLevel,string>={1:'#e6c229',2:'#ef8d32',3:'#e74a4a',4:'#9b59c6'};
export const DWD_WIND_THRESHOLDS_KMH=[
 {threshold:50,level:1 as const,label:'Windböen'},
 {threshold:65,level:2 as const,label:'Sturmböen'},
 {threshold:90,level:2 as const,label:'Schwere Sturmböen'},
 {threshold:105,level:3 as const,label:'Orkanartige Böen'},
 {threshold:120,level:3 as const,label:'Orkanböen'},
 {threshold:140,level:4 as const,label:'Extreme Orkanböen'}
];

const KMH_PER_KT=1.852;

const WIND_DIRECTION_ADJECTIVES=['nördlicher','nordöstlicher','östlicher','südöstlicher','südlicher','südwestlicher','westlicher','nordwestlicher'] as const;
function normaliseWindDirection(value:number){return((value%360)+360)%360}
function windDirectionAdjective(value:number){return WIND_DIRECTION_ADJECTIVES[Math.round(normaliseWindDirection(value)/45)%8]}
function circularMeanDirection(values:number[]){
 const finiteValues=values.filter(Number.isFinite).map(normaliseWindDirection);if(!finiteValues.length)return Number.NaN;
 const radians=finiteValues.map(value=>value*Math.PI/180),x=radians.reduce((sum,value)=>sum+Math.cos(value),0),y=radians.reduce((sum,value)=>sum+Math.sin(value),0);if(Math.abs(x)<1e-8&&Math.abs(y)<1e-8)return finiteValues[0];return normaliseWindDirection(Math.atan2(y,x)*180/Math.PI);
}
function directionDifference(a:number,b:number){const delta=Math.abs(normaliseWindDirection(a)-normaliseWindDirection(b));return Math.min(delta,360-delta)}
function warningWindDirectionText(occurrences:WarningOccurrence[]){
 const directions=occurrences.sort((a,b)=>a.start-b.start).map(item=>Number(item.signal.windDirection)).filter(Number.isFinite);if(!directions.length)return'';
 const groupSize=Math.max(1,Math.ceil(directions.length/3)),early=circularMeanDirection(directions.slice(0,groupSize)),late=circularMeanDirection(directions.slice(-groupSize)),overall=circularMeanDirection(directions);
 if(directions.length>=3&&Number.isFinite(early)&&Number.isFinite(late)&&directionDifference(early,late)>=67.5)return`Anfangs aus ${windDirectionAdjective(early)}, später aus ${windDirectionAdjective(late)} Richtung`;
 return Number.isFinite(overall)?`Aus ${windDirectionAdjective(overall)} Richtung`:'';
}
export function formatDwdWarningDirection(signal:DwdWarningSignal){if(signal.kind!=='wind'&&signal.kind!=='snowdrift')return'';if(signal.windDirectionText)return signal.windDirectionText;return Number.isFinite(signal.windDirection)?`Aus ${windDirectionAdjective(Number(signal.windDirection))} Richtung`:''}
export function formatDwdWarningDetailWithDirection(signal:DwdWarningSignal,unit:DwdDisplayWindUnit='kt'){
 const detail=formatDwdWarningDetail(signal,unit).trim().replace(/[.!?]+$/,'');
 const direction=formatDwdWarningDirection(signal).trim();if(!direction)return`${detail}.`;
 const inlineDirection=`${direction.charAt(0).toLocaleLowerCase('de-DE')}${direction.slice(1)}`;
 return direction.startsWith('Anfangs')?`${detail}; ${inlineDirection}.`:`${detail} ${inlineDirection}.`;
}

function rounded(value:number){return Math.round(value)}
export function beaufortFromKmh(kmh:number){const value=Math.max(0,finite(kmh));const limits=[1,6,12,20,29,39,50,62,75,89,103,118];const index=limits.findIndex(limit=>value<limit);return index<0?12:index}
export function formatDwdWindValue(kmh:number,unit:DwdDisplayWindUnit='kt'){
 const value=Math.max(0,finite(kmh)),primary=unit==='kmh'?`${rounded(value)} km/h`:unit==='ms'?`${rounded(value/3.6)} m/s`:unit==='mph'?`${rounded(value/1.609344)} mph`:`${rounded(value/KMH_PER_KT)} kt`;
 return unit==='kmh'?`${primary} (Bft ${beaufortFromKmh(value)})`:`${primary} (${rounded(value)} km/h)`;
}
export function formatDwdWarningCompactValue(signal:DwdWarningSignal,unit:DwdDisplayWindUnit='kt'){
 const windOnly=(kmh:number)=>{const value=Math.max(0,finite(kmh));return unit==='kmh'?`${rounded(value)} km/h`:unit==='ms'?`${rounded(value/3.6)} m/s`:unit==='mph'?`${rounded(value/1.609344)} mph`:`${rounded(value/KMH_PER_KT)} kt`};
 if(signal.kind==='wind'||signal.kind==='snowdrift')return windOnly(signal.value);
 if(signal.kind==='heavyRain'||signal.kind==='continuousRain')return`${rounded(signal.value)} mm`;
 if(signal.kind==='snow')return`${rounded(signal.value)} cm`;
 if(signal.kind==='fog')return`${Math.max(0,rounded(signal.value))} m`;
 if(signal.kind==='heat'||signal.kind==='frost'||signal.unit==='°C')return`${rounded(signal.value)} °C`;
 return'';
}
export function formatDwdWarningValue(signal:DwdWarningSignal,unit:DwdDisplayWindUnit='kt'){
 if(signal.kind==='wind')return formatDwdWindValue(signal.value,unit);
 if(signal.kind==='snowdrift'){const snow=Number.isFinite(signal.secondaryValue)?`${rounded(signal.secondaryValue!)} cm · `:'';return`${snow}${formatDwdWindValue(signal.value,unit)}`}
 if(signal.kind==='heavyRain'||signal.kind==='continuousRain')return`${rounded(signal.value)} mm${signal.windowHours?`/${signal.windowHours} h`:''}`;
 if(signal.kind==='snow')return`${rounded(signal.value)} cm${signal.windowHours?`/${signal.windowHours} h`:''}`;
 if(signal.kind==='fog')return`${Math.max(0,rounded(signal.value))} m`;
 if(signal.kind==='heat'||signal.kind==='frost'||signal.unit==='°C')return`${rounded(signal.value)} °C`;
 return'';
}
function withoutWarningStage(text:string){return text.replace(/\s*(?:[·(]\s*)?DWD-(?:Hitze)?Warnstufe\s*\d+\)?/gi,'').replace(/\s+([.,;:])/g,'$1').replace(/\.{2,}/g,'.').trim()}
export function formatDwdWarningDetail(signal:DwdWarningSignal,unit:DwdDisplayWindUnit='kt'){
 if(signal.kind==='wind')return`${signal.title} bis ${formatDwdWindValue(signal.value,unit)}.`;
 if(signal.kind==='snowdrift')return`${signal.title}: ${Number.isFinite(signal.secondaryValue)?`${rounded(signal.secondaryValue!)} cm Neuschnee und `:''}Böen bis ${formatDwdWindValue(signal.value,unit)}.`;
 if(signal.kind==='heavyRain'||signal.kind==='continuousRain')return`${signal.title}: ${rounded(signal.value)} mm in ${signal.windowHours??1} h.`;
 if(signal.kind==='snow')return`${signal.title}: ${rounded(signal.value)} cm Neuschnee in ${signal.windowHours??1} h.`;
 if(signal.kind==='fog')return`Sichtweite ${Math.max(0,rounded(signal.value))} m.`;
 if(signal.kind==='heat')return`Gefühlte Temperatur ${rounded(signal.value)} °C.`;
 if(signal.kind==='frost')return`${signal.title}: ${rounded(signal.value)} °C.`;
 if(signal.kind==='ice'&&signal.unit==='°C')return`Niederschlag bei ${rounded(signal.value)} °C: Glätte möglich.`;
 return withoutWarningStage(signal.detail.replace(/(-?\d+)[,.]\d+/g,'$1'));
}
function finite(value:unknown,fallback=0){const number=Number(value);return Number.isFinite(number)?number:fallback}
function forwardValues(samples:DwdWarningSample[],index:number,hours:number,selector:(sample:DwdWarningSample)=>number){const count=Math.max(1,Math.round(hours));return samples.slice(index,index+count).map(selector)}
function forwardSum(samples:DwdWarningSample[],index:number,hours:number,selector:(sample:DwdWarningSample)=>number){const values=forwardValues(samples,index,hours,selector);return values.length>=hours?values.reduce((sum,value)=>sum+Math.max(0,finite(value)),0):Number.NaN}
function forwardMax(samples:DwdWarningSample[],index:number,hours:number,selector:(sample:DwdWarningSample)=>number){const values=forwardValues(samples,index,hours,selector).filter(Number.isFinite);return values.length?Math.max(...values):Number.NaN}
function forwardMin(samples:DwdWarningSample[],index:number,hours:number,selector:(sample:DwdWarningSample)=>number){const values=forwardValues(samples,index,hours,selector).filter(Number.isFinite);return values.length>=hours?Math.min(...values):Number.NaN}
function forwardAllBelow(samples:DwdWarningSample[],index:number,hours:number,threshold:number){const values=forwardValues(samples,index,hours,sample=>finite(sample.temperature,Number.NaN)).filter(Number.isFinite);return values.length>=hours&&values.every(value=>value<threshold)}
function liquidPrecipitation(sample:DwdWarningSample){const explicit=Math.max(0,finite(sample.rain))+Math.max(0,finite(sample.showers));if(explicit>0)return explicit;const code=finite(sample.code,-1);return[51,53,55,56,57,61,63,65,66,67,80,81,82,95,96,97,99].includes(code)?Math.max(0,finite(sample.precipitation)):0}
function snowfall(sample:DwdWarningSample){return Math.max(0,finite(sample.snowfall))}
function levelFromThresholds(value:number,level2:number,level3:number,level4:number){if(!Number.isFinite(value))return null;if(value>level4)return 4 as const;if(value>=level3)return 3 as const;if(value>=level2)return 2 as const;return null}
function windClassification(kmh:number){if(kmh>140)return{level:4 as const,label:'Extreme Orkanböen'};if(kmh>=120)return{level:3 as const,label:'Orkanböen'};if(kmh>=105)return{level:3 as const,label:'Orkanartige Böen'};if(kmh>=90)return{level:2 as const,label:'Schwere Sturmböen'};if(kmh>=65)return{level:2 as const,label:'Sturmböen'};if(kmh>50)return{level:1 as const,label:'Windböen'};return null}
function rainWindowSignal(samples:DwdWarningSample[],index:number){
 const windows=[
  {hours:1,l2:15,l3:25,l4:40,kind:'heavyRain' as const,title:'Starkregen'},
  {hours:6,l2:20,l3:35,l4:60,kind:'heavyRain' as const,title:'Starkregen'},
  {hours:12,l2:25,l3:40,l4:70,kind:'continuousRain' as const,title:'Dauerregen'},
  {hours:24,l2:30,l3:50,l4:80,kind:'continuousRain' as const,title:'Dauerregen'},
  {hours:48,l2:40,l3:60,l4:90,kind:'continuousRain' as const,title:'Dauerregen'},
  {hours:72,l2:60,l3:90,l4:120,kind:'continuousRain' as const,title:'Dauerregen'}
 ];
 let best:DwdWarningSignal|null=null;
 for(const window of windows){const total=forwardSum(samples,index,window.hours,liquidPrecipitation),level=levelFromThresholds(total,window.l2,window.l3,window.l4);if(!level)continue;const candidate:DwdWarningSignal={kind:window.kind,level,title:window.title,symbol:window.kind==='heavyRain'?'☔':'🌧',detail:`${window.title}: ${Math.round(total)} mm in ${window.hours} h.`,value:total,unit:'mm',windowHours:window.hours};if(!best||candidate.level>best.level||candidate.level===best.level&&window.hours<(best.windowHours??999))best=candidate}
 return best;
}
function snowWindowSignal(samples:DwdWarningSample[],index:number,elevation:number){
 const mountain=Number.isFinite(elevation)&&elevation>800;
 const windows=mountain?[
  {hours:6,l2:5,l3:20,l4:30},{hours:12,l2:10,l3:30,l4:50},{hours:24,l2:15,l3:40,l4:60},{hours:48,l2:20,l3:50,l4:70},{hours:72,l2:20,l3:50,l4:70}
 ]:[
  {hours:6,l2:5,l3:10,l4:20},{hours:12,l2:10,l3:15,l4:25},{hours:24,l2:15,l3:30,l4:40},{hours:48,l2:20,l3:40,l4:50},{hours:72,l2:20,l3:40,l4:50}
 ];
 let best:DwdWarningSignal|null=null;
 for(const window of windows){const total=forwardSum(samples,index,window.hours,snowfall);if(!Number.isFinite(total)||total<.1)continue;const level=levelFromThresholds(total,window.l2,window.l3,window.l4)??1;const candidate:DwdWarningSignal={kind:'snow',level,title:level===4?'Extrem starker Schneefall':level===3?'Starker Schneefall':level===2?'Schneefall':'Leichter Schneefall',symbol:'❄',detail:`${Math.round(total)} cm Neuschnee in ${window.hours} h${mountain?' (Bergland)':''}.`,value:total,unit:'cm',windowHours:window.hours};if(!best||candidate.level>best.level||candidate.level===best.level&&window.hours<(best.windowHours??999))best=candidate}
 return best;
}
function snowdriftSignal(samples:DwdWarningSample[],index:number){const snow6=forwardSum(samples,index,6,snowfall),snow24=forwardSum(samples,index,24,snowfall),gust6=forwardMax(samples,index,6,sample=>finite(sample.gust)*KMH_PER_KT);if(snow24>25&&gust6>=65)return{kind:'snowdrift',level:4,title:'Extrem starke Schneeverwehung',symbol:'🌬',detail:`Über ${Math.round(snow24)} cm Neuschnee und Böen bis ${Math.round(gust6)} km/h.`,value:gust6,unit:'km/h',windowHours:24,secondaryValue:snow24,secondaryUnit:'cm'} satisfies DwdWarningSignal;if(snow6>10&&gust6>=65)return{kind:'snowdrift',level:3,title:'Starke Schneeverwehung',symbol:'🌬',detail:`Über ${Math.round(snow6)} cm Neuschnee und Böen bis ${Math.round(gust6)} km/h.`,value:gust6,unit:'km/h',windowHours:6,secondaryValue:snow6,secondaryUnit:'cm'} satisfies DwdWarningSignal;if(snow6>=5&&gust6>=39)return{kind:'snowdrift',level:2,title:'Schneeverwehung',symbol:'🌬',detail:`${Math.round(snow6)} cm Neuschnee und Böen bis ${Math.round(gust6)} km/h.`,value:gust6,unit:'km/h',windowHours:6,secondaryValue:snow6,secondaryUnit:'cm'} satisfies DwdWarningSignal;return null}
function iceSignal(sample:DwdWarningSample){const code=finite(sample.code,-1),temperature=finite(sample.temperature,Number.NaN);if(code===67)return{kind:'ice',level:3,title:'Glatteis',symbol:'🧊',detail:'Starker gefrierender Regen: Glatteisbildung möglich.',value:code,unit:'WMO'} satisfies DwdWarningSignal;if([48,56,57,66].includes(code))return{kind:'ice',level:2,title:'Markante Glätte',symbol:'🧊',detail:'Raueis, gefrierender Sprühregen oder leichter gefrierender Regen: markante Glätte möglich.',value:code,unit:'WMO'} satisfies DwdWarningSignal;const wet=liquidPrecipitation(sample)>0||snowfall(sample)>0;if(wet&&temperature<0)return{kind:'ice',level:1,title:'Glätte',symbol:'⚠️',detail:'Niederschlag bei Lufttemperatur unter 0 °C: Glätte möglich.',value:temperature,unit:'°C'} satisfies DwdWarningSignal;return null}
function thunderSignal(sample:DwdWarningSample,wind:DwdWarningSignal|null,rain:DwdWarningSignal|null){const code=finite(sample.code,-1);if(![95,96,97,99].includes(code))return null;const convectiveRain=rain?.kind==='heavyRain'?rain:null;let level:DwdWarningLevel=1;if(wind?.level===4||convectiveRain?.level===4)level=4;else if(wind?.level===3||convectiveRain?.level===3||code===99)level=3;else if(wind?.level===2||convectiveRain?.level===2||[96,97].includes(code))level=2;const companions=[wind&&wind.level>=2?wind.title:'',convectiveRain?convectiveRain.title:'',code===96||code===99?'Hagel':''].filter(Boolean).join(', ');return{kind:'thunderstorm',level,title:level===4?'Extremes Gewitter':level===3?'Schweres Gewitter':level===2?'Starkes Gewitter':'Gewitter',symbol:'⚡',detail:`${level===4?'Extremes Gewitter':level===3?'Schweres Gewitter':level===2?'Starkes Gewitter':'Gewitter'}${companions?` mit ${companions}`:''}.`,value:code,unit:'WMO'} satisfies DwdWarningSignal}
function fogSignal(sample:DwdWarningSample){const visibility=finite(sample.visibility,Number.NaN);if(Number.isFinite(visibility)&&visibility<150)return{kind:'fog',level:1,title:'Nebel',symbol:'🌫',detail:`Sichtweite ${Math.max(0,Math.round(visibility))} m.`,value:visibility,unit:'m'} satisfies DwdWarningSignal;return null}
function heatSignal(samples:DwdWarningSample[],index:number){const sample=samples[index],apparent=finite(sample?.apparent,finite(sample?.temperature,Number.NaN));if(apparent>38)return{kind:'heat',level:3,title:'Extreme Wärmebelastung',symbol:'☀',detail:`Gefühlte Temperatur ${Math.round(apparent)} °C.`,value:apparent,unit:'°C'} satisfies DwdWarningSignal;const minimum=forwardMin(samples,index,12,value=>finite(value.temperature,Number.NaN));if(apparent>32&&Number.isFinite(minimum)&&minimum>=20)return{kind:'heat',level:1,title:'Starke Wärmebelastung',symbol:'☀',detail:`Gefühlte Temperatur ${Math.round(apparent)} °C bei nur geringer modellierter Abkühlung.`,value:apparent,unit:'°C'} satisfies DwdWarningSignal;return null}

export function dwdWarningSignalsAt(samples:DwdWarningSample[],index:number,elevation=0){
 const sample=samples[index];if(!sample)return[] as DwdWarningSignal[];
 const signals:DwdWarningSignal[]=[];
 const gustKmh=finite(sample.gust)*KMH_PER_KT,windDirection=Number.isFinite(Number(sample.windDirection))?normaliseWindDirection(Number(sample.windDirection)):undefined,windClass=windClassification(gustKmh),wind=windClass?{kind:'wind',level:windClass.level,title:windClass.label,symbol:'💨',detail:`${windClass.label} bis ${Math.round(gustKmh)} km/h.`,value:gustKmh,unit:'km/h',windDirection} satisfies DwdWarningSignal:null;
 const rain=rainWindowSignal(samples,index),snow=snowWindowSignal(samples,index,elevation),drift=snowdriftSignal(samples,index),ice=iceSignal(sample),fog=fogSignal(sample),heat=heatSignal(samples,index);
 if(wind)signals.push(wind);if(rain)signals.push(rain);if(snow)signals.push(snow);if(drift)signals.push(drift);if(ice)signals.push(ice);if(fog)signals.push(fog);if(heat)signals.push(heat);
 const thunder=thunderSignal(sample,wind,rain);if(thunder)signals.push(thunder);
 const lowland=!Number.isFinite(elevation)||elevation<=800;
 if(lowland&&forwardAllBelow(samples,index,3,-10)){const minimum=Math.min(...forwardValues(samples,index,3,value=>finite(value.temperature,Number.NaN)).filter(Number.isFinite));signals.push({kind:'frost',level:2,title:'Strenger Frost',symbol:'🥶',detail:`Mindestens 3 Stunden unter −10 °C, Tiefstwert ${Math.round(minimum)} °C.`,value:minimum,unit:'°C',windowHours:3})}
 else if(lowland&&finite(sample.temperature,Number.NaN)<0){const temperature=finite(sample.temperature,Number.NaN);signals.push({kind:'frost',level:1,title:'Frost',symbol:'❄️',detail:`Lufttemperatur ${Math.round(temperature)} °C in einer Lage bis 800 m.`,value:temperature,unit:'°C'})}
 return signals.sort((a,b)=>b.level-a.level||a.kind.localeCompare(b.kind));
}

type WarningOccurrence={signal:DwdWarningSignal;index:number;start:number;end:number};
function warningSampleEpoch(sample:DwdWarningSample){const raw=Number(sample.epoch);if(Number.isFinite(raw))return raw<1e12?raw*1000:raw;const parsed=Date.parse(String(sample.time??''));return Number.isFinite(parsed)?parsed:Number.NaN}
function warningOccurrence(signal:DwdWarningSignal,index:number,sample:DwdWarningSample):WarningOccurrence{const start=warningSampleEpoch(sample),durationHours=Math.max(1,Math.round(Number(signal.windowHours)||1));return{signal,index,start,end:Number.isFinite(start)?start+durationHours*3600000:Number.NaN}}
function warningValidity(occurrences:WarningOccurrence[],selected:WarningOccurrence){
 const timed=occurrences.filter(item=>Number.isFinite(item.start)&&Number.isFinite(item.end)).sort((a,b)=>a.start-b.start);if(!timed.length||!Number.isFinite(selected.start))return{};
 const merged:{start:number;end:number;members:WarningOccurrence[]}[]=[];for(const item of timed){const current=merged.at(-1);if(current&&item.start<=current.end+5*60000){current.end=Math.max(current.end,item.end);current.members.push(item)}else merged.push({start:item.start,end:item.end,members:[item]})}
 const interval=merged.find(item=>item.members.includes(selected))??merged.find(item=>selected.start>=item.start&&selected.start<=item.end);return interval?{validFrom:new Date(interval.start).toISOString(),validTo:new Date(interval.end).toISOString(),windDirectionText:selected.signal.kind==='wind'?warningWindDirectionText(interval.members):undefined}:{};
}
export function summarizeDwdWarnings(samples:DwdWarningSample[],elevation=0,startLimit=samples.length){
 const byKind=new Map<DwdWarningKind,WarningOccurrence>(),occurrences=new Map<DwdWarningKind,WarningOccurrence[]>(),limit=Math.min(samples.length,Math.max(0,startLimit));
 for(let index=0;index<limit;index++)for(const signal of dwdWarningSignalsAt(samples,index,elevation)){const occurrence=warningOccurrence(signal,index,samples[index]),rows=occurrences.get(signal.kind)??[];rows.push(occurrence);occurrences.set(signal.kind,rows);const previous=byKind.get(signal.kind);if(!previous||signal.level>previous.signal.level||signal.level===previous.signal.level&&signal.value>previous.signal.value)byKind.set(signal.kind,occurrence)}
 return[...byKind.values()].map(selected=>({...selected.signal,...warningValidity(occurrences.get(selected.signal.kind)??[],selected)})).sort((a,b)=>b.level-a.level||a.kind.localeCompare(b.kind));
}

/**
 * Tagesbezogene Zusammenfassung mit vollständigem Vorwärtsfenster.
 * Die ersten `dayCount` Stunden gehören zum angezeigten Kalendertag; weitere
 * Stunden werden ausschließlich für 12-/24-/48-/72-h-Schwellen und die
 * nächtliche Abkühlung herangezogen. Dadurch bleibt der angezeigte Warnwert
 * beim Tagesmaximum (z. B. maximale gefühlte Temperatur) und wird nicht auf
 * einen früheren, technisch noch vollständig auswertbaren Stundenwert gekürzt.
 */
export function summarizeDwdWarningsForDay(samples:DwdWarningSample[],date:string,elevation=0){
 const start=samples.findIndex(sample=>String(sample.time||'').startsWith(date));
 if(start<0)return[] as DwdWarningSignal[];
 let dayCount=0;
 while(start+dayCount<samples.length&&String(samples[start+dayCount]?.time||'').startsWith(date))dayCount++;
 if(!dayCount)return[] as DwdWarningSignal[];
 const extended=samples.slice(start,start+dayCount+72);
 return summarizeDwdWarnings(extended,elevation,dayCount);
}
