import {useEffect,useState} from 'react';
import {Activity,BrainCircuit,CheckCircle2,CloudRain,ShieldCheck,SlidersHorizontal,Target} from 'lucide-react';
import {readWeatherTwinSettings,writeWeatherTwinSettings,type WeatherTwinSettings} from './forecastVerification';

export function WeatherTwinSettings(){
 const[settings,setSettings]=useState<WeatherTwinSettings>(()=>readWeatherTwinSettings());
 useEffect(()=>{const update=(event:Event)=>setSettings((event as CustomEvent<WeatherTwinSettings>).detail||readWeatherTwinSettings());window.addEventListener('mid:weather-twin-settings',update);return()=>window.removeEventListener('mid:weather-twin-settings',update)},[]);
 const patch=(change:Partial<WeatherTwinSettings>)=>setSettings(writeWeatherTwinSettings(change));
 const disabled=!settings.enabled;
 return <section className="weather-twin-settings"><header><BrainCircuit size={22}/><span><strong>Lokaler Wetterzwilling</strong><small>Unabhängiges Prognosearchiv, lokales Lernen, überprüfbare Gewichtung und persönliche Entscheidungshilfe.</small></span></header><div>
  <label className="settings-toggle-card"><input type="checkbox" checked={settings.enabled} onChange={event=>patch({enabled:event.target.checked})}/><Target size={21}/><span><strong>Wetterzwilling aktivieren</strong><small>Speichert Prognosestände, Rückblicke und lokale Güteprofile für jeden Standort.</small></span></label>
  <label className={`settings-toggle-card${disabled?' disabled':''}`}><input type="checkbox" disabled={disabled} checked={settings.useAsMainForecast} onChange={event=>patch({useAsMainForecast:event.target.checked})}/><SlidersHorizontal size={21}/><span><strong>Lokal gelernte Prognose als Hauptprognose</strong><small>Nur bei ausreichender Datenbasis; Best Match bleibt Kontrollgruppe und unverändert im Archiv.</small></span></label>
  <label className={`settings-toggle-card${disabled?' disabled':''}`}><input type="checkbox" disabled={disabled} checked={settings.nowcastAssimilation} onChange={event=>patch({nowcastAssimilation:event.target.checked})}/><CloudRain size={21}/><span><strong>Radar-/Nowcast-Assimilation</strong><small>Beobachtete Niederschlagssignale wirken ausschließlich auf die ersten Stunden der lokalen Prognose.</small></span></label>
  <label className={`settings-toggle-card${disabled?' disabled':''}`}><input type="checkbox" disabled={disabled} checked={settings.biasCorrection} onChange={event=>patch({biasCorrection:event.target.checked})}/><Activity size={21}/><span><strong>Lokale Bias-Korrektur</strong><small>Korrigiert erst bei ausreichender Historie wiederkehrende lokale Abweichungen je Modell, Wetterlage und Horizont.</small></span></label>
  <label className={`settings-toggle-card${disabled?' disabled':''}`}><input type="checkbox" disabled={disabled} checked={settings.probabilityCalibration} onChange={event=>patch({probabilityCalibration:event.target.checked})}/><ShieldCheck size={21}/><span><strong>Regenwahrscheinlichkeit kalibrieren</strong><small>Gleicht vorhergesagte Wahrscheinlichkeiten mit der örtlich beobachteten Trefferhäufigkeit ab.</small></span></label>
  <label className={`settings-toggle-card${disabled?' disabled':''}`}><input type="checkbox" disabled={disabled} checked={settings.personalRecommendations} onChange={event=>patch({personalRecommendations:event.target.checked})}/><CheckCircle2 size={21}/><span><strong>Persönliche Empfehlungen</strong><small>Aktiviert optimale Zeitfenster für die im Rückblickmodul ausgewählten Aktivitäten.</small></span></label>
 </div></section>
}
