import type {ReactNode} from 'react';

type MidDisclosureProps={
 className?:string;
 summary:ReactNode;
 children:ReactNode;
 defaultOpen?:boolean;
};

export function MidDisclosure({className='',summary,children,defaultOpen=false}:MidDisclosureProps){
 return <details className={className} defaultOpen={defaultOpen} data-mid-ui="disclosure"><summary>{summary}</summary>{children}</details>;
}
