import {createContext,useContext,useEffect,useMemo,useRef,useState,type ReactNode} from 'react';
import * as maplibregl from 'maplibre-gl';
import 'maplibre-gl/dist/maplibre-gl.css';
import maplibreWorkerUrl from 'maplibre-gl/dist/maplibre-gl-worker.mjs?worker&url';

// MapLibre GL JS 6 is ESM-only. Vite must emit its module worker as a
// self-contained asset; without this boundary raster/HTML layers can mount
// while worker-backed GeoJSON polygons silently remain empty in production.
maplibregl.setWorkerUrl(maplibreWorkerUrl);

export type MidMap=maplibregl.Map;
type MapContextValue={map:MidMap|null;loaded:boolean};
const MapContext=createContext<MapContextValue>({map:null,loaded:false});
export function useMidMap(){return useContext(MapContext).map}
export function useMidMapState(){return useContext(MapContext)}

const EMPTY_STYLE:maplibregl.StyleSpecification={version:8,sources:{},layers:[{id:'mid-map-background',type:'background',paint:{'background-color':'#dfe7ec'}}]};

export function MidMapLibre({center,zoom,minZoom=2,maxZoom=14,className,scrollZoom=false,interactive=true,attributionControl=true,navigationControl=false,onClick,onZoomStart,onZoomEnd,onMoveEnd,children}:{center:[number,number];zoom:number;minZoom?:number;maxZoom?:number;className?:string;scrollZoom?:boolean;interactive?:boolean;attributionControl?:boolean;navigationControl?:boolean;onClick?:(latitude:number,longitude:number)=>void;onZoomStart?:()=>void;onZoomEnd?:()=>void;onMoveEnd?:()=>void;children?:ReactNode}){
 const containerRef=useRef<HTMLDivElement|null>(null),mapRef=useRef<MidMap|null>(null),[loaded,setLoaded]=useState(false);
 useEffect(()=>{
  const container=containerRef.current;if(!container)return;
  const map=new maplibregl.Map({container,style:EMPTY_STYLE,center:[center[1],center[0]],zoom,minZoom,maxZoom,attributionControl:false,interactive,scrollZoom,dragRotate:false,pitchWithRotate:false,fadeDuration:0,validateStyle:false});
  mapRef.current=map;
  if(attributionControl)map.addControl(new maplibregl.AttributionControl({compact:true}),'bottom-right');
  if(navigationControl)map.addControl(new maplibregl.NavigationControl({showCompass:false,visualizePitch:false}),'top-right');
  const handleLoad=()=>setLoaded(true),handleClick=(event:maplibregl.MapMouseEvent)=>onClick?.(event.lngLat.lat,event.lngLat.lng);
  map.on('load',handleLoad);if(onClick)map.on('click',handleClick);if(onZoomStart)map.on('zoomstart',onZoomStart);if(onZoomEnd)map.on('zoomend',onZoomEnd);if(onMoveEnd)map.on('moveend',onMoveEnd);
  const resizeObserver=typeof ResizeObserver!=='undefined'?new ResizeObserver(()=>map.resize()):null;resizeObserver?.observe(container);
  return()=>{resizeObserver?.disconnect();setLoaded(false);mapRef.current=null;map.remove()};
 },[]);
 useEffect(()=>{const map=mapRef.current;if(!map)return;const current=map.getCenter();if(Math.abs(current.lat-center[0])>.00005||Math.abs(current.lng-center[1])>.00005)map.jumpTo({center:[center[1],center[0]]})},[center[0],center[1]]);
 useEffect(()=>{const map=mapRef.current;if(!map)return;if(scrollZoom)map.scrollZoom.enable();else map.scrollZoom.disable()},[scrollZoom]);
 const value=useMemo(()=>({map:mapRef.current,loaded}),[loaded]);
 return <MapContext.Provider value={value}><div ref={containerRef} className={className}/>{loaded?children:null}</MapContext.Provider>;
}

export function MapInteraction({enabled}:{enabled:boolean}){const map=useMidMap();useEffect(()=>{if(!map)return;const actions=[map.dragPan,map.touchZoomRotate,map.doubleClickZoom,map.boxZoom,map.keyboard];for(const action of actions)enabled?action.enable():action.disable();map.touchZoomRotate.disableRotation()},[map,enabled]);return null}
export function MapCenter({latitude,longitude,zoom,fly=false,revision=0}:{latitude:number;longitude:number;zoom?:number;fly?:boolean;revision?:number}){const map=useMidMap();useEffect(()=>{if(!map)return;const options={center:[longitude,latitude] as [number,number],...(zoom!==undefined?{zoom}:{})};if(fly)map.flyTo({...options,duration:650,essential:true});else map.jumpTo(options)},[map,latitude,longitude,zoom,fly,revision]);return null}
export function MapFitBounds({south,west,north,east,maxZoom,padding=22}:{south:number;west:number;north:number;east:number;maxZoom?:number;padding?:number}){const map=useMidMap();useEffect(()=>{if(!map)return;map.fitBounds([[west,south],[east,north]],{padding,maxZoom,duration:0})},[map,south,west,north,east,maxZoom,padding]);return null}

function safeId(value:string){return value.replace(/[^a-zA-Z0-9_-]/g,'_')}
const orderedLayers=new WeakMap<MidMap,Map<string,number>>();
function applyLayerOrder(map:MidMap){const registry=orderedLayers.get(map);if(!registry)return;const ordered=[...registry.entries()].filter(([id])=>Boolean(map.getLayer(id))).sort((a,b)=>a[1]-b[1]);for(const [id] of ordered){try{map.moveLayer(id)}catch{}}}
export function registerMapLayerOrder(map:MidMap,id:string,zIndex=0){let registry=orderedLayers.get(map);if(!registry){registry=new Map();orderedLayers.set(map,registry)}registry.set(id,zIndex);queueMicrotask(()=>applyLayerOrder(map))}
export function unregisterMapLayerOrder(map:MidMap,id:string){const registry=orderedLayers.get(map);registry?.delete(id);if(registry&&!registry.size)orderedLayers.delete(map)}
export function wmsTileUrl(base:string,params:Record<string,string|number|boolean|undefined>){
 const [path,query='']=base.split('?'),search=new URLSearchParams(query),version=String(params.version??'1.1.1');
 search.set('service','WMS');search.set('request','GetMap');search.set('version',version);search.set('layers',String(params.layers??''));search.set('styles',String(params.styles??''));search.set('format',String(params.format??'image/png'));search.set('transparent',String(params.transparent??true));search.set('width','256');search.set('height','256');search.set(version.startsWith('1.3')?'crs':'srs','EPSG:3857');search.set('bbox','{bbox-epsg-3857}');
 for(const [key,value] of Object.entries(params)){if(value===undefined||['version','layers','styles','format','transparent','tiled'].includes(key))continue;search.set(key,value===true?'true':value===false?'false':String(value))}
 return `${path}?${search.toString().replace('%7Bbbox-epsg-3857%7D','{bbox-epsg-3857}')}`;
}

export function RasterTileLayer({id,url,opacity=1,minZoom=0,maxZoom=22,tileSize=256,attribution,zIndex=0,onReady,onError}:{id:string;url:string;opacity?:number;minZoom?:number;maxZoom?:number;tileSize?:number;attribution?:string;zIndex?:number;onReady?:()=>void;onError?:(message?:string)=>void}){
 const map=useMidMap(),sourceId=`${safeId(id)}-source`,layerId=`${safeId(id)}-layer`;
 useEffect(()=>{if(!map||!url)return;let active=true,ready=false;const errorHandler=(event:maplibregl.ErrorEvent)=>{const source=(event as unknown as {sourceId?:string}).sourceId;if(source&&source!==sourceId)return;if(active)onError?.(event.error?.message)};const idleHandler=()=>{if(!active||ready||!map.getLayer(layerId))return;ready=true;onReady?.()};
  try{if(map.getLayer(layerId))map.removeLayer(layerId);if(map.getSource(sourceId))map.removeSource(sourceId);map.addSource(sourceId,{type:'raster',tiles:[url],tileSize,minzoom:minZoom,maxzoom:maxZoom,attribution});map.addLayer({id:layerId,type:'raster',source:sourceId,paint:{'raster-opacity':Math.max(0,Math.min(1,opacity)),'raster-fade-duration':0,'raster-resampling':'linear'}});registerMapLayerOrder(map,layerId,zIndex);map.on('error',errorHandler);map.on('idle',idleHandler)}catch(error){onError?.(error instanceof Error?error.message:String(error))}
  return()=>{active=false;map.off('error',errorHandler);map.off('idle',idleHandler);unregisterMapLayerOrder(map,layerId);try{if(map.getLayer(layerId))map.removeLayer(layerId);if(map.getSource(sourceId))map.removeSource(sourceId)}catch{}}
 },[map,id,url,minZoom,maxZoom,tileSize,attribution,zIndex]);
 useEffect(()=>{if(map?.getLayer(layerId))map.setPaintProperty(layerId,'raster-opacity',Math.max(0,Math.min(1,opacity)))},[map,layerId,opacity]);return null;
}
export function WmsTileLayer({id,baseUrl,params,opacity=1,attribution,zIndex=0,onReady,onError}:{id:string;baseUrl:string;params:Record<string,string|number|boolean|undefined>;opacity?:number;attribution?:string;zIndex?:number;onReady?:()=>void;onError?:(message?:string)=>void}){const url=useMemo(()=>wmsTileUrl(baseUrl,params),[baseUrl,JSON.stringify(params)]);return <RasterTileLayer id={id} url={url} opacity={opacity} attribution={attribution} zIndex={zIndex} onReady={onReady} onError={onError}/>}

export type MidGeoLayer={id:string;type:'line'|'fill'|'circle'|'symbol';paint?:Record<string,unknown>;layout?:Record<string,unknown>;filter?:unknown};
export function GeoJsonLayers({id,data,layers,hoverProperty,zIndex=0}:{id:string;data:any;layers:MidGeoLayer[];hoverProperty?:string;zIndex?:number}){const map=useMidMap(),sourceId=`${safeId(id)}-source`;
 useEffect(()=>{if(!map)return;const layerIds=layers.map(spec=>`${safeId(id)}-${safeId(spec.id)}`),popup=hoverProperty?new maplibregl.Popup({closeButton:false,closeOnClick:false,offset:8,maxWidth:'320px'}):null,moveHandlers:Array<(event:maplibregl.MapLayerMouseEvent)=>void>=[],leaveHandlers:Array<()=>void>=[];try{if(!map.getSource(sourceId))map.addSource(sourceId,{type:'geojson',data});else(map.getSource(sourceId) as maplibregl.GeoJSONSource).setData(data);for(const spec of layers){const layerId=`${safeId(id)}-${safeId(spec.id)}`;if(map.getLayer(layerId))map.removeLayer(layerId);map.addLayer({id:layerId,type:spec.type,source:sourceId,paint:spec.paint as any,layout:spec.layout as any,filter:spec.filter as any} as maplibregl.AddLayerObject);registerMapLayerOrder(map,layerId,zIndex+layers.indexOf(spec)/1000);if(popup){const move=(event:maplibregl.MapLayerMouseEvent)=>{const value=event.features?.[0]?.properties?.[hoverProperty!];if(value===undefined||value===null)return;map.getCanvas().style.cursor='pointer';popup.setLngLat(event.lngLat).setHTML(String(value)).addTo(map)},leave=()=>{map.getCanvas().style.cursor='';popup.remove()};map.on('mousemove',layerId,move);map.on('mouseleave',layerId,leave);moveHandlers.push(move);leaveHandlers.push(leave)}}}catch{}return()=>{popup?.remove();try{layerIds.forEach((layerId,index)=>{if(moveHandlers[index])map.off('mousemove',layerId,moveHandlers[index]);if(leaveHandlers[index])map.off('mouseleave',layerId,leaveHandlers[index]);unregisterMapLayerOrder(map,layerId);if(map.getLayer(layerId))map.removeLayer(layerId)});if(map.getSource(sourceId))map.removeSource(sourceId)}catch{}}},[map,id,sourceId,data,JSON.stringify(layers),hoverProperty,zIndex]);return null}

export function HtmlMarker({latitude,longitude,html,className='',anchor='bottom',offset=[0,0],popupHtml,onClick,zIndex}:{latitude:number;longitude:number;html:string;className?:string;anchor?:maplibregl.PositionAnchor;offset?:[number,number];popupHtml?:string;onClick?:()=>void;zIndex?:number}){const map=useMidMap();useEffect(()=>{if(!map)return;const el=document.createElement('div');el.className=className;el.innerHTML=html;if(zIndex!==undefined)el.style.zIndex=String(zIndex);if(onClick)el.addEventListener('click',onClick);const marker=new maplibregl.Marker({element:el,anchor,offset}).setLngLat([longitude,latitude]);if(popupHtml)marker.setPopup(new maplibregl.Popup({offset:12,maxWidth:'330px'}).setHTML(popupHtml));marker.addTo(map);return()=>{if(onClick)el.removeEventListener('click',onClick);marker.remove()}},[map,latitude,longitude,html,className,anchor,offset[0],offset[1],popupHtml,onClick,zIndex]);return null}

export function CanvasOverlay({id,opacity=1,zIndex=5,render,events=['moveend','zoomend','resize'] as const}:{id:string;opacity?:number;zIndex?:number;render:(map:MidMap,canvas:HTMLCanvasElement)=>void;events?:readonly ('moveend'|'zoomend'|'resize'|'render')[]}){const map=useMidMap();useEffect(()=>{if(!map)return;let raf=0;const canvas=document.createElement('canvas');canvas.className=`mid-maplibre-canvas ${safeId(id)}`;Object.assign(canvas.style,{position:'absolute',inset:'0',pointerEvents:'none',zIndex:String(zIndex),opacity:String(Math.max(0,Math.min(1,opacity)))});map.getCanvasContainer().appendChild(canvas);const redraw=()=>{cancelAnimationFrame(raf);raf=requestAnimationFrame(()=>render(map,canvas))};for(const event of events)map.on(event,redraw);redraw();return()=>{cancelAnimationFrame(raf);for(const event of events)map.off(event,redraw);canvas.remove()}},[map,id,zIndex,render,events.join('|')]);useEffect(()=>{if(!map)return;const canvas=map.getCanvasContainer().querySelector(`canvas.${safeId(id)}`) as HTMLCanvasElement|null;if(canvas)canvas.style.opacity=String(Math.max(0,Math.min(1,opacity)))},[map,id,opacity]);return null}

export function ImageQuadLayer({id,url,bounds,opacity=1,zIndex=0}:{id:string;url:string;bounds:[[number,number],[number,number]];opacity?:number;zIndex?:number}){const map=useMidMap(),sourceId=`${safeId(id)}-source`,layerId=`${safeId(id)}-layer`,south=bounds[0][0],west=bounds[0][1],north=bounds[1][0],east=bounds[1][1];useEffect(()=>{if(!map||!url)return;try{if(map.getLayer(layerId))map.removeLayer(layerId);if(map.getSource(sourceId))map.removeSource(sourceId);map.addSource(sourceId,{type:'image',url,coordinates:[[west,north],[east,north],[east,south],[west,south]]});map.addLayer({id:layerId,type:'raster',source:sourceId,paint:{'raster-opacity':Math.max(0,Math.min(1,opacity)),'raster-fade-duration':0,'raster-resampling':'linear'}});registerMapLayerOrder(map,layerId,zIndex)}catch{}return()=>{unregisterMapLayerOrder(map,layerId);try{if(map.getLayer(layerId))map.removeLayer(layerId);if(map.getSource(sourceId))map.removeSource(sourceId)}catch{}}},[map,id,url,south,west,north,east,zIndex]);useEffect(()=>{if(map?.getLayer(layerId))map.setPaintProperty(layerId,'raster-opacity',Math.max(0,Math.min(1,opacity)))},[map,layerId,opacity]);return null}
