import type {Day,EnsembleDay,Hour,Location,RadarNowcast,Station,ThunderstormNowcast} from './weather';
import {readWeatherTwinSettings,type TwinActivity} from './forecastVerification';
import {fetchWorkerJson} from './workerClient';

export type SynopticFrontType='cold'|'warm'|'occlusion'|'trough'|'convergence'|'none';
export type SynopticConfidence='high'|'medium'|'low';
export type SynopticLifecycle='detected'|'approaching'|'passage'|'departing'|'verified'|'dissipated';
export type SynopticPoint=[number,number];
export type SynopticSignalStatus='strong'|'supporting'|'weak'|'contradictory'|'missing';
export type SynopticSignal={
 key:string;
 label:string;
 value:number;
 unit:string;
 support:number;
 status?:SynopticSignalStatus;
 family?:'thermal'|'moisture'|'pressure'|'wind'|'precipitation'|'cloud';
 detail?:string;
 available?:boolean;
};
export type SynopticModelCandidate={
 modelId:string;
 modelLabel:string;
 type:SynopticFrontType;
 arrivalAt:string;
 score:number;
 confidence:SynopticConfidence;
 line:SynopticPoint[];
 approachBearingDeg?:number;
 motionDirectionDeg?:number;
 signals:SynopticSignal[];
 summary:string;
 runTime?:string;
 coherence?:number;
 supportingSignalCount?:number;
 availableSignalCount?:number;
 contradictionCount?:number;
 estimatedDistanceKm?:number;
 estimatedSpeedKmh?:number;
 cluster?:'dominant'|'alternative'|'isolated';
};
export type SynopticStationPlot={id:string;name:string;provider:string;lat:number;lon:number;distanceKm:number;observedAt?:string;temperature?:number;dewPoint?:number;pressure?:number;windSpeedKt?:number;windDirection?:number;precipitation?:number;phase?:'before'|'transition'|'after';quality?:number};
export type SynopticOfficialAnalysis={available:boolean;label:string;sourcePage:string;imageUrl?:string;nominalTime?:string;publishedAt?:string;checkedAt:string;license:string;error?:string};
export type SynopticAgreement={
 modelCount:number;
 supportingModels:number;
 type:SynopticFrontType;
 typeAgreement:number;
 medianArrivalAt?:string;
 windowStart?:string;
 windowEnd?:string;
 spreadHours?:number;
 meanScore:number;
 confidence:SynopticConfidence;
 summary:string;
 status?:'coherent'|'limited'|'conflict'|'none';
 dominantModelIds?:string[];
 alternativeModelIds?:string[];
 parameterCount?:number;
};
export type SynopticObservationCorridor={bearingDeg?:number;widthDeg:number;lengthKm:number;stations:SynopticStationPlot[];phaseSupport:number;summary:string};
export type SynopticTiming={modelMedianAt?:string;assimilatedAt?:string;windowStart?:string;windowEnd?:string;observationAdjustmentMinutes:number;radarAdjustmentMinutes:number;confidence:SynopticConfidence;reasons:string[]};
export type SynopticSource={label:string;kind:'official-analysis'|'model'|'observation'|'nowcast'|'local-archive';dataTime?:string;checkedAt?:string;detail:string};
export type SynopticWorkerResponse={officialAnalysis:SynopticOfficialAnalysis;candidates:SynopticModelCandidate[];agreement:SynopticAgreement;corridor:SynopticObservationCorridor;timing:SynopticTiming;sources:SynopticSource[];generatedAt:string;error?:string};
export type SynopticPhase={key:'before'|'during'|'after';title:string;period:string;temperature?:number;dewPoint?:number;pressure?:number;windKt?:number;gustKt?:number;windDirection?:number;rainProbability?:number;precipitation?:number;summary:string};
export type SynopticUncertaintyCause={key:'modelTiming'|'frontType'|'observations'|'sourceAge'|'analogues'|'nowcast';label:string;share:number;detail:string};
export type SynopticImpact={activity:TwinActivity|'general';label:string;level:'low'|'medium'|'high';summary:string;actions:string[]};
export type SynopticEventRecord={id:string;locationKey:string;type:SynopticFrontType;firstSeen:string;lastUpdated:string;predictedAt:string;windowStart:string;windowEnd:string;confidence:SynopticConfidence;lifecycle:SynopticLifecycle;modelArrivals:Record<string,string>;score:number;before?:SynopticPhase;after?:SynopticPhase;observedAt?:string;timingErrorMinutes?:number;impactSignature:string;verified:boolean};
export type SynopticAnalogue={id:string;date:string;type:SynopticFrontType;similarity:number;timingErrorMinutes?:number;summary:string};
export type SynopticIntelligence={event:SynopticEventRecord|null;phases:SynopticPhase[];evidence:SynopticSignal[];uncertainty:SynopticUncertaintyCause[];causalChain:string[];impacts:SynopticImpact[];analogues:SynopticAnalogue[];verification:{events:number;verified:number;meanAbsoluteTimingErrorMinutes?:number;summary:string};nextChangeSummary:string};

const ARCHIVE_PREFIX='mid:synoptic-events:v1:';
const SNAPSHOT_PREFIX='mid:synoptic-snapshot:v1:';
const clamp=(value:number,min:number,max:number)=>Math.min(max,Math.max(min,value));
const finite=(value:unknown,fallback=NaN)=>{const n=Number(value);return Number.isFinite(n)?n:fallback};
const circularDifference=(a:number,b:number)=>Math.abs(((a-b+540)%360)-180);
const signedCircularDifference=(from:number,to:number)=>(((to-from)+540)%360)-180;
const directionLabel=(value:number)=>{const labels=['N','NNO','NO','ONO','O','OSO','SO','SSO','S','SSW','SW','WSW','W','WNW','NW','NNW'];return labels[Math.round((((value%360)+360)%360)/22.5)%16]};
const signalStatus=(support:number,available=true,contradictory=false):SynopticSignalStatus=>!available?'missing':contradictory?'contradictory':support>=.7?'strong':support>=.38?'supporting':support>=.16?'weak':'weak';

export function describeSynopticWindChange(from?:number,to?:number){
 const start=finite(from),end=finite(to);
 if(!Number.isFinite(start)||!Number.isFinite(end))return{available:false,fromLabel:'–',toLabel:'–',shiftDeg:undefined as number|undefined,magnitudeDeg:undefined as number|undefined,turn:'unbekannt',level:'unknown' as const,summary:'Windrichtungsänderung noch nicht belastbar.'};
 const shift=signedCircularDifference(start,end),magnitude=Math.abs(shift),turn=magnitude<15?'nahezu gleichbleibend':shift>0?'rechtsdrehend':'rückdrehend',level=magnitude>=60?'marked':magnitude>=25?'noticeable':'slight';
 return{available:true,fromLabel:directionLabel(start),toLabel:directionLabel(end),shiftDeg:shift,magnitudeDeg:magnitude,turn,level,summary:`Wind ${directionLabel(start)} ${Math.round(start)}° → ${directionLabel(end)} ${Math.round(end)}° · ${magnitude<15?'kaum Richtungsänderung':`${Math.round(magnitude)}° ${turn}`}.`};
}
const frontLabel=(type:SynopticFrontType)=>({cold:'Kaltfront',warm:'Warmfront',occlusion:'Okklusion',trough:'Trogachse',convergence:'Konvergenzlinie',none:'Fronttyp noch nicht belastbar'} as const)[type];
export {frontLabel};

export async function loadSynopticAnalysis(location:Location,signal?:AbortSignal){
 return fetchWorkerJson<SynopticWorkerResponse>('synoptic-analysis',{lat:location.latitude,lon:location.longitude,country:location.country_code||location.country||''},{purpose:'radar',signal,timeoutMs:32000,maxAgeMs:20*60000,staleIfErrorMs:3*3600000,cacheKey:`${location.latitude.toFixed(3)}:${location.longitude.toFixed(3)}`});
}

function localDateTime(value:string|number,timeZone?:string){const date=new Date(value);if(!Number.isFinite(date.getTime()))return'–';return new Intl.DateTimeFormat('de-DE',{timeZone:timeZone||undefined,weekday:'short',day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}).format(date)}
function hourClosest(hours:Hour[],target:number){let best:Hour|undefined,bestDelta=Infinity;for(const hour of hours){const epoch=finite(hour.epoch,Date.parse(hour.time));const delta=Math.abs(epoch-target);if(delta<bestDelta){best=hour;bestDelta=delta}}return best}
function phaseFromHour(key:SynopticPhase['key'],title:string,target:number,hours:Hour[],timeZone:string|undefined,spanHours:number){
 const hour=hourClosest(hours,target),near=hours.filter(item=>Math.abs(finite(item.epoch,Date.parse(item.time))-target)<=spanHours*3600000),rain=near.reduce((sum,item)=>sum+Math.max(0,finite(item.precipitation,0)),0),probability=near.length?Math.max(...near.map(item=>finite(item.probability,0))):undefined;
 if(!hour)return{key,title,period:localDateTime(target,timeZone),summary:'Für diesen Zeitraum liegen noch keine vollständigen Stundenwerte vor.'};
 const wind=`Wind aus ${directionLabel(hour.direction)} (${Math.round(hour.direction)}°) mit ${Math.round(hour.wind)} kt`,summary=key==='before'?`Ausgangsluftmasse: ${Math.round(hour.temperature)} °C, Taupunkt ${Math.round(hour.dewPoint)} °C, ${Math.round(hour.pressure)} hPa und ${wind}.`:key==='during'?`${rain>=1?'Niederschlagsschwerpunkt':'Wetterwechsel'}; ${wind}, Böen bis ${Math.round(hour.gust)} kt und mögliche Drucktendenzänderung.`:`Nachfolgende Luftmasse: ${Math.round(hour.temperature)} °C, ${wind} und ${Math.round(hour.pressure)} hPa.`;
 return{key,title,period:localDateTime(target,timeZone),temperature:hour.temperature,dewPoint:hour.dewPoint,pressure:hour.pressure,windKt:hour.wind,gustKt:hour.gust,windDirection:hour.direction,rainProbability:probability,precipitation:rain,summary};
}
function destinationPoint(lat:number,lon:number,bearingDeg:number,distanceKm:number):SynopticPoint{const radius=6371,angular=distanceKm/radius,bearing=bearingDeg*Math.PI/180,lat1=lat*Math.PI/180,lon1=lon*Math.PI/180,lat2=Math.asin(Math.sin(lat1)*Math.cos(angular)+Math.cos(lat1)*Math.sin(angular)*Math.cos(bearing)),lon2=lon1+Math.atan2(Math.sin(bearing)*Math.sin(angular)*Math.cos(lat1),Math.cos(angular)-Math.sin(lat1)*Math.sin(lat2));return[lat2*180/Math.PI,((lon2*180/Math.PI+540)%360)-180]}

export function localFrontCandidate(hours:Hour[],location:Location):SynopticModelCandidate|null{
 const now=Date.now(),usable=hours.filter(hour=>finite(hour.epoch,Date.parse(hour.time))>=now-2*3600000&&finite(hour.epoch,Date.parse(hour.time))<=now+84*3600000);let best:{index:number;score:number;type:SynopticFrontType;signals:SynopticSignal[];coherence:number}|null=null;
 for(let index=3;index<usable.length-3;index++){
  const before=usable[index-3],current=usable[index],after=usable[index+3],temperatureChange=after.temperature-before.temperature,dewChange=after.dewPoint-before.dewPoint,humidityChange=finite(after.humidity)-finite(before.humidity),pressureTrough=Math.max(0,(before.pressure+after.pressure)/2-current.pressure),windShift=circularDifference(before.direction,after.direction),rain=usable.slice(Math.max(0,index-2),index+3).reduce((sum,item)=>sum+Math.max(0,item.precipitation),0),cloud=Math.max(current.cloud,after.cloud),gustChange=after.gust-before.gust;
  const type:SynopticFrontType=temperatureChange<=-1.6&&dewChange<=-.8&&windShift>=20?'cold':temperatureChange>=1.3&&dewChange>=.6&&windShift>=16?'warm':Math.abs(temperatureChange)<1.8&&Math.abs(dewChange)>=2&&rain>=1&&pressureTrough>=.7?'occlusion':windShift>=45&&rain>=.4&&pressureTrough<1.2?'convergence':'trough';
  const typeSign=type==='cold'?-1:type==='warm'?1:0,temperatureSupport=typeSign?clamp((typeSign*temperatureChange-.7)/3.3,0,1):clamp(Math.abs(temperatureChange)/3.5,0,1),moistureSupport=typeSign?clamp((typeSign*dewChange-.3)/3,0,1):clamp(Math.max(Math.abs(dewChange)/4,Math.abs(humidityChange)/25),0,1),pressureSupport=clamp(pressureTrough/3,0,1),windSupport=clamp(windShift/80,0,1),rainSupport=clamp(rain/5,0,1),cloudSupport=clamp((cloud-45)/50,0,1),gustSupport=clamp(Math.abs(gustChange)/22,0,1),supports=[temperatureSupport,moistureSupport,pressureSupport,windSupport,rainSupport,cloudSupport,gustSupport],coherence=supports.filter(value=>value>=.35).length/supports.length,score=clamp((supports.reduce((sum,value)=>sum+value,0)/supports.length)*86+coherence*14,0,96);
  const signals:SynopticSignal[]=[
   {key:'thermal-gradient',label:'Temperaturgradient',value:Number.NaN,unit:'räumlich',support:0,status:'missing',available:false,family:'thermal',detail:'Im lokalen Ersatzpfad fehlt das räumliche Modellfeld.'},
   {key:'moisture-gradient',label:'Taupunkt-/Feuchtegradient',value:Number(dewChange.toFixed(1)),unit:'K / 6 h',support:moistureSupport,status:signalStatus(moistureSupport,true,typeSign!==0&&typeSign*dewChange<0),family:'moisture'},
   {key:'pressure-trough',label:'Druckrinne',value:Number(pressureTrough.toFixed(1)),unit:'hPa',support:pressureSupport,status:signalStatus(pressureSupport),family:'pressure'},
   {key:'wind-shift',label:'Winddrehung',value:Math.round(windShift),unit:'°',support:windSupport,status:signalStatus(windSupport),family:'wind'},
   {key:'steering-flow',label:'850-hPa-Strömung',value:Number.NaN,unit:'nicht verfügbar',support:0,status:'missing',available:false,family:'wind'},
   {key:'precipitation',label:'Niederschlagsstützung',value:Number(rain.toFixed(1)),unit:'mm / 5 h',support:rainSupport,status:signalStatus(rainSupport),family:'precipitation'},
   {key:'cloud-band',label:'Wolkenband',value:Math.round(cloud),unit:'%',support:cloudSupport,status:signalStatus(cloudSupport),family:'cloud'},
   {key:'temperature-change',label:'Temperaturänderung',value:Number(temperatureChange.toFixed(1)),unit:'K / 6 h',support:temperatureSupport,status:signalStatus(temperatureSupport,true,typeSign!==0&&typeSign*temperatureChange<0),family:'thermal'},
   {key:'gust-change',label:'Böenänderung',value:Number(gustChange.toFixed(1)),unit:'kt / 6 h',support:gustSupport,status:signalStatus(gustSupport),family:'wind'}
  ];
  if(score>=38&&coherence>=.34&&(!best||score>best.score))best={index,score,type,signals,coherence};
 }
 if(!best)return null;
 const hour=usable[best.index],leadHours=Math.max(0,(finite(hour.epoch,Date.parse(hour.time))-Date.now())/3600000),speedKmh=clamp(Math.max(12,hour.wind*1.852*.65),12,65),distanceKm=clamp(leadHours*speedKmh,20,360),center=destinationPoint(location.latitude,location.longitude,hour.direction,distanceKm),angle=(hour.direction+90)%360,length=2.5,latScale=Math.cos(center[0]*Math.PI/180),dy=Math.cos(angle*Math.PI/180)*length,dx=Math.sin(angle*Math.PI/180)*length/Math.max(.35,latScale),line=[[center[0]-dy,center[1]-dx],[center[0]+dy,center[1]+dx]] as SynopticPoint[];
 return{modelId:'best-match-local',modelLabel:'Best Match · lokaler Stundenverlauf',type:best.type,arrivalAt:new Date(finite(hour.epoch,Date.parse(hour.time))).toISOString(),score:Math.round(best.score),confidence:best.score>=70?'high':best.score>=50?'medium':'low',line,approachBearingDeg:hour.direction,motionDirectionDeg:(hour.direction+180)%360,signals:best.signals,summary:`${frontLabel(best.type)} als lokaler Wetterwechselsignal-Kandidat aus Temperatur, Taupunkt/Feuchte, Druck, Wind, Niederschlag, Bewölkung und Böen.`,coherence:Number(best.coherence.toFixed(2)),supportingSignalCount:best.signals.filter(signal=>signal.support>=.35).length,availableSignalCount:best.signals.filter(signal=>signal.available!==false).length,contradictionCount:best.signals.filter(signal=>signal.status==='contradictory').length,estimatedDistanceKm:Math.round(distanceKm),estimatedSpeedKmh:Math.round(speedKmh),cluster:'isolated'};
}

function archiveKey(locationKey:string){return`${ARCHIVE_PREFIX}${locationKey}`}
function readArchive(locationKey:string):SynopticEventRecord[]{try{const rows=JSON.parse(localStorage.getItem(archiveKey(locationKey))||'[]');return Array.isArray(rows)?rows.filter(row=>row&&typeof row==='object').slice(-80):[]}catch{return[]}}
function writeArchive(locationKey:string,rows:SynopticEventRecord[]){try{localStorage.setItem(archiveKey(locationKey),JSON.stringify(rows.slice(-80)))}catch{}}
function eventId(locationKey:string,type:SynopticFrontType,predictedAt:string){const slot=Math.round(Date.parse(predictedAt)/(6*3600000));return`${locationKey}:${type}:${slot}`}
function lifecycle(predictedAt:string,verified:boolean){const hours=(Date.parse(predictedAt)-Date.now())/3600000;if(verified)return'verified';if(hours>18)return'detected';if(hours>2)return'approaching';if(hours>=-2)return'passage';if(hours>=-12)return'departing';return'dissipated'}
function observationPassage(station:Station|null|undefined,event:SynopticEventRecord,hours:Hour[]){if(!station?.timestamp)return undefined;const observed=Date.parse(station.timestamp),predicted=Date.parse(event.predictedAt);if(!Number.isFinite(observed)||Math.abs(observed-predicted)>8*3600000)return undefined;const model=hourClosest(hours,observed),temperatureDelta=model&&Number.isFinite(station.temperature)?Math.abs(Number(station.temperature)-model.temperature):0,pressureDelta=model&&Number.isFinite(station.pressure)?Math.abs(Number(station.pressure)-model.pressure):0,windDelta=model&&Number.isFinite(station.windDirection)?circularDifference(Number(station.windDirection),model.direction):0;if(temperatureDelta>=2||pressureDelta>=2||windDelta>=45)return observed;return undefined}
function updateEventArchive(locationKey:string,candidate:SynopticModelCandidate,agreement:SynopticAgreement,timing:SynopticTiming,phases:SynopticPhase[],station:Station|null|undefined,hours:Hour[]){
 const predictedAt=timing.assimilatedAt||agreement.medianArrivalAt||candidate.arrivalAt,spread=Math.max(90,Math.round((agreement.spreadHours||3)*60/2)),windowStart=timing.windowStart||new Date(Date.parse(predictedAt)-spread*60000).toISOString(),windowEnd=timing.windowEnd||new Date(Date.parse(predictedAt)+spread*60000).toISOString(),resolvedType=agreement.type==='none'?candidate.type:agreement.type,id=eventId(locationKey,resolvedType,predictedAt),rows=readArchive(locationKey),previous=rows.find(row=>row.id===id),modelArrivals={[candidate.modelId]:candidate.arrivalAt,...(previous?.modelArrivals||{})};
 const base:SynopticEventRecord={id,locationKey,type:resolvedType,firstSeen:previous?.firstSeen||new Date().toISOString(),lastUpdated:new Date().toISOString(),predictedAt,windowStart,windowEnd,confidence:timing.confidence||agreement.confidence,lifecycle:'detected',modelArrivals,score:Math.round((candidate.score+agreement.meanScore)/2),before:phases[0],after:phases[2],impactSignature:`${Math.round(phases[1]?.gustKt||0)}:${Math.round(phases[1]?.rainProbability||0)}:${Math.round((phases[2]?.temperature||0)-(phases[0]?.temperature||0))}:${Math.round(describeSynopticWindChange(phases[0]?.windDirection,phases[2]?.windDirection).magnitudeDeg||0)}`,verified:previous?.verified||false,observedAt:previous?.observedAt,timingErrorMinutes:previous?.timingErrorMinutes};
 const passage=observationPassage(station,base,hours);if(passage){base.verified=true;base.observedAt=new Date(passage).toISOString();base.timingErrorMinutes=Math.round((passage-Date.parse(predictedAt))/60000)}base.lifecycle=lifecycle(predictedAt,base.verified);const next=rows.filter(row=>row.id!==id);next.push(base);writeArchive(locationKey,next);return base;
}

function analogues(locationKey:string,event:SynopticEventRecord|null){if(!event)return[];const rows=readArchive(locationKey).filter(row=>row.id!==event.id&&row.type===event.type&&row.verified);return rows.map(row=>{const scoreDelta=Math.abs(row.score-event.score),signatureA=row.impactSignature.split(':').map(Number),signatureB=event.impactSignature.split(':').map(Number),impactDelta=signatureA.reduce((sum,value,index)=>sum+Math.abs(value-(signatureB[index]||0)),0),similarity=clamp(100-scoreDelta*.65-impactDelta*.8,0,99);return{id:row.id,date:row.observedAt||row.predictedAt,type:row.type,similarity:Math.round(similarity),timingErrorMinutes:row.timingErrorMinutes,summary:`${frontLabel(row.type)} · damaliger Timingfehler ${Number.isFinite(row.timingErrorMinutes)?`${Math.abs(Number(row.timingErrorMinutes))} min`:'noch ohne Wertung'}`}}).sort((a,b)=>b.similarity-a.similarity).slice(0,3)}
function verification(locationKey:string){const rows=readArchive(locationKey),verified=rows.filter(row=>row.verified&&Number.isFinite(row.timingErrorMinutes)),mae=verified.length?Math.round(verified.reduce((sum,row)=>sum+Math.abs(Number(row.timingErrorMinutes)),0)/verified.length):undefined;return{events:rows.length,verified:verified.length,meanAbsoluteTimingErrorMinutes:mae,summary:verified.length?`${verified.length} Ereignisse verifiziert · mittlerer absoluter Timingfehler ${mae} min.`:'Das Analogarchiv beginnt mit diesem Standort; verifizierbare Frontpassagen werden fortlaufend ergänzt.'}}

function buildUncertainty(response:SynopticWorkerResponse|undefined,analogCount:number,radar:RadarNowcast|null|undefined):SynopticUncertaintyCause[]{
 const agreement=response?.agreement,stations=response?.corridor?.stations.length||0,age=response?.generatedAt?Math.max(0,(Date.now()-Date.parse(response.generatedAt))/60000):180,conflict=agreement?.status==='conflict',raw=[
  {key:'modelTiming' as const,label:'Modell-Timing',weight:clamp((agreement?.spreadHours||10)/12,0.1,1),detail:`Zeitspanne der Modelle: ${Number.isFinite(agreement?.spreadHours)?`${Number(agreement?.spreadHours).toFixed(1)} h`:'noch nicht belastbar'}.`},
  {key:'frontType' as const,label:'Fronttyp / Stärke',weight:conflict?1:clamp(1-(agreement?.typeAgreement||0),.08,1),detail:conflict?'Die Modelle klassifizieren unterschiedliche Fronttypen; MID erzwingt keinen künstlichen Konsens.':`Typübereinstimmung ${Math.round((agreement?.typeAgreement||0)*100)} %.`},
  {key:'observations' as const,label:'Beobachtungskorridor',weight:clamp(1-stations/8,.08,1),detail:`${stations} verwertbare stromaufwärtige Stationsplots.`},
  {key:'sourceAge' as const,label:'Datenalter',weight:clamp(age/180,.05,1),detail:`Analyse vor rund ${Math.round(age)} min aktualisiert.`},
  {key:'analogues' as const,label:'Lokale Analogfälle',weight:clamp(1-analogCount/4,.08,1),detail:`${analogCount} ähnliche verifizierte lokale Fälle.`},
  {key:'nowcast' as const,label:'Radar-/Nowcast-Stützung',weight:radar?.coverage?clamp(1-(radar.quality==='high'?.85:radar.quality==='medium'?.62:.35),.08,1):.9,detail:radar?.coverage?`Radarqualität ${radar.quality}; Niederschlagsband wird separat assimiliert.`:'Keine belastbare Radarstützung für das Fronttiming.'}
 ],total=raw.reduce((sum,item)=>sum+item.weight,0);return raw.map(item=>({key:item.key,label:item.label,share:Math.round(item.weight/total*100),detail:item.detail})).sort((a,b)=>b.share-a.share);
}
function radarAdjustment(candidateAt:string,radar:RadarNowcast|null|undefined,agreement?:SynopticAgreement){if(agreement?.status==='conflict'||!radar?.coverage||!Number.isFinite(radar.arrivalMinutes))return{minutes:0,reason:agreement?.status==='conflict'?'Radar wird bei widersprüchlichem Fronttyp nicht zur Timingkorrektur verwendet.':''};const modelMinutes=(Date.parse(candidateAt)-Date.now())/60000;if(modelMinutes<0||modelMinutes>720)return{minutes:0,reason:''};const delta=clamp(Number(radar.arrivalMinutes)-modelMinutes,-120,120);return{minutes:Math.round(delta*.35),reason:`Radar-/Nowcast-Niederschlagsband verschiebt die Ereignismitte begrenzt um ${Math.round(delta*.35)} min.`}}
function impacts(phases:SynopticPhase[],type:SynopticFrontType):SynopticImpact[]{
 const settings=readWeatherTwinSettings(),before=phases[0],during=phases[1],after=phases[2],gust=Math.max(during?.gustKt||0,after?.gustKt||0),rain=during?.rainProbability||0,tempChange=(after?.temperature||0)-(before?.temperature||0),windChange=describeSynopticWindChange(before?.windDirection,after?.windDirection),directionConcern=windChange.available&&Number(windChange.magnitudeDeg)>=60&&gust>=18,baseLevel=gust>=35||rain>=80?'high':gust>=24||rain>=55||directionConcern?'medium':'low',base:SynopticImpact={activity:'general',label:'Allgemeine Auswirkungen',level:baseLevel,summary:`${frontLabel(type)}: ${tempChange<=-3?'deutlich kühler':tempChange>=3?'deutlich milder':'nur mäßige Temperaturänderung'}, ${windChange.summary} Böen bis etwa ${Math.round(gust)} kt und Regenwahrscheinlichkeit bis ${Math.round(rain)} % während des Übergangs.`,actions:[rain>=60?'Nasse Fahrbahn und zeitweise schlechtere Sicht einplanen.':'Kurzzeitige Wetterverschlechterung im Übergangsfenster beachten.',directionConcern?'Markante Winddrehung beachten: exponierte Bereiche können nach dem Frontdurchgang aus einer anderen Richtung belastet werden.':gust>=28?'Lose Gegenstände und empfindliche Außenanlagen sichern.':'Keine ausgeprägte Windwirkung aus Geschwindigkeit und Richtung ableitbar.']};
 const labels:Record<TwinActivity,string>={commute:'Berufsverkehr',outdoor:'Draußen',garden:'Garten',rowing:'Rudern',dog:'Hundespaziergang',ski:'Ski/Berg',heat:'Hitzebelastung'},items=[base];
 for(const activity of Object.keys(settings.activities) as TwinActivity[]){const profile=settings.activities[activity],directionSensitive=(activity==='rowing'||activity==='garden'||activity==='ski')&&directionConcern;if(!profile.enabled)continue;const high=rain>profile.maxRainProbability||gust>profile.maxGustKt||(during?.temperature??20)<profile.minTemperature||(during?.temperature??20)>profile.maxTemperature||(directionSensitive&&gust>=profile.maxGustKt*.75),level=high?'high':rain>.7*profile.maxRainProbability||gust>.7*profile.maxGustKt||directionSensitive?'medium':'low';items.push({activity,label:labels[activity],level,summary:level==='high'?`Das Frontfenster überschreitet mindestens einen persönlichen Schwellenwert für ${labels[activity]}; auch die Winddrehung wird berücksichtigt.`:`Die persönlichen Grenzwerte für ${labels[activity]} werden ${level==='medium'?'annähernd erreicht':'voraussichtlich eingehalten'}; Windrichtung ${windChange.fromLabel} → ${windChange.toLabel}.`,actions:[level==='high'?'Aktivität möglichst vor oder nach dem Übergangsfenster legen.':'Zeitfenster mit geringerem Regen- und Böenrisiko bevorzugen.',directionSensitive?`Ausrichtung und Rückweg wegen der Winddrehung ${windChange.fromLabel} → ${windChange.toLabel} neu bewerten.`:activity==='garden'&&gust>=25?'Markise, Abdeckung und leichte Gartenmöbel rechtzeitig sichern.':activity==='rowing'&&gust>=profile.maxGustKt?'Wassertraining im Frontfenster vermeiden.':'Lokale Kurzfristentwicklung vor Beginn erneut prüfen.']})}
 return items;
}
function aggregateEvidence(candidates:SynopticModelCandidate[],agreement?:SynopticAgreement){
 const dominantIds=new Set(agreement?.dominantModelIds||[]),selected=(dominantIds.size?candidates.filter(candidate=>dominantIds.has(candidate.modelId)):candidates).filter(Boolean),source=selected.length?selected:candidates;if(!source.length)return[];
 const order=['thermal-gradient','moisture-gradient','pressure-trough','wind-shift','steering-flow','precipitation','cloud-band','temperature-change','gust-change'];
 return order.map(key=>{const rows=source.map(candidate=>candidate.signals.find(signal=>signal.key===key)).filter((signal):signal is SynopticSignal=>Boolean(signal)),available=rows.filter(signal=>signal.available!==false&&Number.isFinite(signal.value)),support=rows.length?rows.reduce((sum,signal)=>sum+signal.support,0)/rows.length:0,value=available.length?available.reduce((sum,signal)=>sum+signal.value,0)/available.length:Number.NaN,base=rows[0];return base?{...base,value:Number.isFinite(value)?Number(value.toFixed(1)):Number.NaN,support:Number(support.toFixed(2)),available:available.length>0,status:rows.some(signal=>signal.status==='contradictory')?'contradictory':signalStatus(support,available.length>0)}:null}).filter((signal):signal is SynopticSignal=>Boolean(signal));
}
function causalChain(locationKey:string,candidate:SynopticModelCandidate,response:SynopticWorkerResponse|undefined,timing:SynopticTiming,radarReason:string){
 let previous:SynopticEventRecord|undefined;try{previous=JSON.parse(localStorage.getItem(`${SNAPSHOT_PREFIX}${locationKey}`)||'null')||undefined}catch{}
 const parameterText=`${candidate.supportingSignalCount??candidate.signals.filter(signal=>signal.support>=.35).length} von ${candidate.availableSignalCount??candidate.signals.filter(signal=>signal.available!==false).length} verfügbaren Parametern stützen die Einstufung`;const agreement=response?.agreement;
 const chain=[`${candidate.modelLabel} bewertet ${frontLabel(candidate.type)} mit ${candidate.score}/100 und ${Math.round((candidate.coherence??0)*100)} % Signalkohärenz; ${parameterText}.`,agreement?.status==='conflict'?`Die Modelle widersprechen sich beim Fronttyp (${response?.candidates.map(item=>`${item.modelLabel}: ${frontLabel(item.type)}`).join(' · ')}); MID erzwingt keinen gemeinsamen Fronttyp.`:agreement?.supportingModels?`${agreement.supportingModels} Modelle tragen den dominanten Ereigniscluster; Typübereinstimmung ${Math.round(agreement.typeAgreement*100)} %.`:'Der Best-Match-Stundenverlauf liefert derzeit die lokale Ersatzanalyse.',response?.corridor.stations.length?`${response.corridor.stations.length} stromaufwärtige Beobachtungen prüfen, ob die vorgelagerte beziehungsweise nachfolgende Luftmasse bereits messbar ist.`:'Der Beobachtungskorridor ist noch dünn besetzt.',...timing.reasons,radarReason].filter(Boolean) as string[];
 if(previous&&previous.type===candidate.type){const delta=Math.round((Date.parse(timing.assimilatedAt||candidate.arrivalAt)-Date.parse(previous.predictedAt))/60000);if(Math.abs(delta)>=15)chain.push(`Gegenüber der letzten MID-Bewertung verschiebt sich die Ereignismitte um ${Math.abs(delta)} min ${delta<0?'nach vorn':'nach hinten'}.`);else chain.push('Gegenüber der letzten MID-Bewertung bleibt das Fronttiming nahezu stabil.')}
 try{localStorage.setItem(`${SNAPSHOT_PREFIX}${locationKey}`,JSON.stringify({type:candidate.type,predictedAt:timing.assimilatedAt||candidate.arrivalAt,updatedAt:new Date().toISOString()}))}catch{}
 return chain;
}

export function buildSynopticIntelligence(input:{location:Location;locationKey:string;hours:Hour[];days:Day[];ensemble:EnsembleDay[];station?:Station|null;radar?:RadarNowcast|null;thunder?:ThunderstormNowcast|null;worker?:SynopticWorkerResponse|null}):SynopticIntelligence{
 const fallback=localFrontCandidate(input.hours,input.location),workerCandidates=input.worker?.candidates||[],dominantIds=new Set(input.worker?.agreement?.dominantModelIds||[]),primaryPool=dominantIds.size?workerCandidates.filter(candidate=>dominantIds.has(candidate.modelId)):workerCandidates,primary=primaryPool.slice().sort((a,b)=>b.score-a.score)[0]||workerCandidates.slice().sort((a,b)=>b.score-a.score)[0]||fallback;
 if(!primary)return{event:null,phases:[],evidence:[],uncertainty:[],causalChain:['In den nächsten 84 Stunden wird aus den verfügbaren Feldern kein ausreichend markanter, kohärenter Wetterwechsel erkannt.'],impacts:[],analogues:[],verification:verification(input.locationKey),nextChangeSummary:'Kein markanter Frontdurchgang in den nächsten 84 Stunden objektiviert.'};
 const response=input.worker||undefined,agreement=response?.agreement||{modelCount:1,supportingModels:1,type:primary.type,typeAgreement:1,medianArrivalAt:primary.arrivalAt,windowStart:new Date(Date.parse(primary.arrivalAt)-3*3600000).toISOString(),windowEnd:new Date(Date.parse(primary.arrivalAt)+3*3600000).toISOString(),spreadHours:6,meanScore:primary.score,confidence:primary.confidence,summary:'Lokale Ersatzanalyse aus Best Match.',status:'limited',dominantModelIds:[primary.modelId],alternativeModelIds:[],parameterCount:primary.availableSignalCount},radar=radarAdjustment(agreement.medianArrivalAt||primary.arrivalAt,input.radar,agreement),baseTiming=response?.timing||{modelMedianAt:agreement.medianArrivalAt,assimilatedAt:agreement.medianArrivalAt,windowStart:agreement.windowStart,windowEnd:agreement.windowEnd,observationAdjustmentMinutes:0,radarAdjustmentMinutes:0,confidence:agreement.confidence,reasons:[]},assimilatedBase=baseTiming.assimilatedAt||agreement.medianArrivalAt||primary.arrivalAt,assimilatedAt=new Date(Date.parse(assimilatedBase)+radar.minutes*60000).toISOString(),timing={...baseTiming,assimilatedAt,radarAdjustmentMinutes:radar.minutes,reasons:[...baseTiming.reasons,...(radar.reason?[radar.reason]:[])]},center=Date.parse(assimilatedAt),phases=[phaseFromHour('before','Vorher',center-9*3600000,input.hours,input.location.timezone,3),phaseFromHour('during','Während',center,input.hours,input.location.timezone,3),phaseFromHour('after','Nachher',center+9*3600000,input.hours,input.location.timezone,3)],event=updateEventArchive(input.locationKey,primary,agreement,timing,phases,input.station,input.hours),analogueRows=analogues(input.locationKey,event),uncertainty=buildUncertainty(response,analogueRows.length,input.radar),impactRows=impacts(phases,event.type),chain=causalChain(input.locationKey,primary,response,timing,radar.reason),evidence=aggregateEvidence(workerCandidates.length?workerCandidates:[primary],agreement),window=`${localDateTime(event.windowStart,input.location.timezone)} bis ${localDateTime(event.windowEnd,input.location.timezone)}`,strongest=evidence.slice().filter(signal=>signal.available!==false).sort((a,b)=>b.support-a.support)[0],conflict=agreement.status==='conflict';
 return{event,phases,evidence,uncertainty,causalChain:chain,impacts:impactRows,analogues:analogueRows,verification:verification(input.locationKey),nextChangeSummary:`${conflict?'Markanter Wetterwechsel, Fronttyp wegen widersprüchlicher Modellklassifikation noch nicht belastbar':`${frontLabel(event.type)} voraussichtlich ${window}`}. ${describeSynopticWindChange(phases[0]?.windDirection,phases[2]?.windDirection).summary} ${evidence.length?`${evidence.filter(signal=>signal.support>=.35).length} von ${evidence.filter(signal=>signal.available!==false).length} verfügbaren Diagnoseparametern stützen die Lage.`:''} Markantestes Signal: ${strongest?.label||'kombinierter Feldwechsel'}${strongest&&Number.isFinite(strongest.value)?` (${strongest.value} ${strongest.unit})`:''}.`};
}
