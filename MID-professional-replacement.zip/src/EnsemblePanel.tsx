import {useLayoutEffect,useRef,useState,type ReactNode} from 'react';
import {createPortal} from 'react-dom';
import {Info,RefreshCw} from 'lucide-react';
import {Area,Bar,CartesianGrid,ComposedChart,ErrorBar,Legend,Line,ReferenceArea,ReferenceDot,ResponsiveContainer,Scatter,Tooltip,XAxis,YAxis} from 'recharts';
import {dayWeatherCharacter,icon,type ClimateDay,type Day,type EnsembleDay,type Hour,type ModelRunMeta,type WindUnit} from './weather';
import {formatDecimal,formatDecimalFixed} from './format';
import {DWD_WARNING_COLORS,formatDwdWarningDetail,formatDwdWarningValue,summarizeDwdWarnings} from './dwdWarnings';
import {useDismissibleLayer} from './useDismissibleLayer';
import {clamp,niceTemperatureScale} from './chartMath';

function dateOnlyUtc(value:string){const match=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);return match?new Date(Date.UTC(Number(match[1]),Number(match[2])-1,Number(match[3]),12)):new Date(Number.NaN)}
function formatDateOnly(value:string,options:Intl.DateTimeFormatOptions){const date=dateOnlyUtc(value);return Number.isFinite(date.getTime())?new Intl.DateTimeFormat('de-DE',{...options,timeZone:'UTC'}).format(date):value}
function formatModelRunTime(value?:string){if(!value)return'–';const d=new Date(value);return Number.isFinite(d.getTime())?`${d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',timeZone:'UTC'})} ${String(d.getUTCHours()).padStart(2,'0')}Z`:'–'}
function formatAvailabilityTime(value?:string){if(!value)return'–';const d=new Date(value);if(!Number.isFinite(d.getTime()))return'–';const recent=Date.now()-d.getTime()<18*3600000;return recent?`${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}Z`:`${d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',timeZone:'UTC'})} ${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}Z`}
function ModelRunDetails({runs=[]}:{runs?:ModelRunMeta[]}){const ref=useRef<HTMLDetailsElement>(null),[open,setOpen]=useState(false);useDismissibleLayer(ref,open,()=>setOpen(false));return <details ref={ref} open={open} className="model-run-details"><summary title="Modellläufe und Datenstand anzeigen" onClick={event=>{event.preventDefault();setOpen(value=>!value)}}>ⓘ Modellstände</summary><div className="model-run-popover"><strong>Aktive Ensemble-Modelle</strong><p>Init- und Verfügbarkeitszeit der tatsächlich erfolgreich eingebundenen Modelle.</p>{runs.length?<div className="model-run-list">{runs.map(row=><div className="model-run-row" key={`${row.kind}:${row.id}`}><span>{row.label}</span><small>Init {formatModelRunTime(row.initialisationTime)} · verfügbar {formatAvailabilityTime(row.availabilityTime)}</small></div>)}</div>:<small className="model-run-empty">Modellstände werden geladen oder sind derzeit nicht verfügbar.</small>}</div></details>}
function InfoHint({children}:{children:ReactNode}){const ref=useRef<HTMLSpanElement>(null),[open,setOpen]=useState(false);useDismissibleLayer(ref,open,()=>setOpen(false));return <span ref={ref} className={`mode-info${open?' open':''}`}><button type="button" onClick={()=>setOpen(value=>!value)} aria-label="Erklärung anzeigen" aria-expanded={open}><Info size={14}/></button>{open&&<span className="mode-info-popover" role="tooltip">{children}</span>}</span>}
function ModeExplanation({advanced,summary,technical}:{advanced:boolean;summary:ReactNode;technical:ReactNode}){return <InfoHint>{advanced?technical:summary}</InfoHint>}
function Title({eye,title,children}:{eye:string;title:string;children?:ReactNode}){return <header className="title"><div><span>{eye}</span><h2>{title}</h2></div>{children&&<div className="title-tools">{children}</div>}</header>}
function niceRainScale(maxValue:number){
 const raw=Math.max(1,maxValue),steps=[1,2,5,10,20,50],target=raw/4;
 const step=steps.find(x=>x>=target)??Math.ceil(target/10)*10;
 const max=Math.ceil(raw/step)*step;
 return{max,ticks:Array.from({length:max/step+1},(_,i)=>i*step)};
}
function confidenceColor(v:number){
 const value=Math.max(0,Math.min(100,v));
 const stops=[
  {v:0,c:[232,54,54]},
  {v:25,c:[244,125,48]},
  {v:50,c:[242,201,76]},
  {v:70,c:[199,214,54]},
  {v:85,c:[100,190,65]},
  {v:100,c:[45,193,90]}
 ];
 let a=stops[0],b=stops[stops.length-1];
 for(let i=0;i<stops.length-1;i++){if(value>=stops[i].v&&value<=stops[i+1].v){a=stops[i];b=stops[i+1];break}}
 const t=(value-a.v)/Math.max(1,b.v-a.v);
 const rgb=a.c.map((x,i)=>Math.round(x+(b.c[i]-x)*t));
 return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`;
}
function localClockSeconds(value?:string){const match=String(value||'').match(/T(\d{2}):(\d{2})(?::(\d{2}))?/);return match?Number(match[1])*3600+Number(match[2])*60+Number(match[3]||0):Number.NaN}
function daylightSeconds(day:Day){const sunrise=localClockSeconds(day.sunrise),sunset=localClockSeconds(day.sunset);if(Number.isFinite(sunrise)&&Number.isFinite(sunset)){const duration=sunset>=sunrise?sunset-sunrise:sunset+86400-sunrise;if(duration>0)return duration}return 12*3600}
function sanitizeSunshineSeconds(day:Day,value:unknown,fallback=NaN){const number=Number(value);return Number.isFinite(number)?clamp(number,0,daylightSeconds(day)):fallback}
function sunshineShare(day:Day,value:unknown=day.sunshineDuration){const seconds=sanitizeSunshineSeconds(day,value,0);return clamp(seconds/Math.max(1,daylightSeconds(day)),0,1)}
function skyBandColor(sunShare:number){
 const value=clamp(sunShare,0,1),stops=[{v:0,c:[198,199,199]},{v:.2,c:[211,207,172]},{v:.45,c:[228,218,126]},{v:.7,c:[244,226,77]},{v:1,c:[255,230,24]}];
 let a=stops[0],b=stops[stops.length-1];for(let i=0;i<stops.length-1;i++){if(value>=stops[i].v&&value<=stops[i+1].v){a=stops[i];b=stops[i+1];break}}
 const t=(value-a.v)/Math.max(.001,b.v-a.v),rgb=a.c.map((channel,index)=>Math.round(channel+(b.c[index]-channel)*t));return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`;
}
function formatSunshineHours(value:unknown){const number=Number(value);return Number.isFinite(number)?sunshineHoursFormatter.format(number):'–'}
function SunshineScaleLegend(){return <div className="sunshine-scale-legend" aria-label="Farblegende der Sonnenscheindauer"><span aria-hidden="true">☀️</span><i><b>viel Sonne</b><em>wenig Sonne</em></i><span aria-hidden="true">☁️</span></div>}
type EnsembleHazardMarker={symbol:string;level:1|2|3|4;title:string;value?:string;detail?:string};
type ChartTooltipPayload<T>={payload?:T;value?:unknown};
type TrendRow=EnsembleDay&{
 x:number;
 climateMax?:number;
 climateMin?:number;
 label:string;
 weekday:string;
 dayLabel:string;
 bestMax:number;
 bestMin:number;
 bestPrecipitation:number;
 code:number;
 maxBand:number;
 minBand:number;
 maxQ25Plot:number|null;
 maxQBandPlot:number|null;
 minQ25Plot:number|null;
 minQBandPlot:number|null;
 confidence:number;
 bestSunshineHours:number;
 sunshineLowHours:number;
 sunshineHighHours:number;
 precipitationMidPlot?:number;
 precipitationErrorRange?:[number,number];
 hazards:EnsembleHazardMarker[];
 characterCode:number;
 characterLabel:string;
 sunshineShare:number;
 skyColor:string;
};
function tooltipRow<T>(payload?:ChartTooltipPayload<T>[]){return payload?.find(item=>item.payload)?.payload}
function isFiniteNumber(value:unknown):value is number{return typeof value==='number'&&Number.isFinite(value)}
const sunshineHoursFormatter=new Intl.NumberFormat('de-DE',{minimumFractionDigits:0,maximumFractionDigits:1});
function EnsembleHazardShape({cx,cy,hazards}:{cx?:number;cy?:number;hazards?:EnsembleHazardMarker[]}){if(!Number.isFinite(cx)||!Number.isFinite(cy)||!hazards?.length)return null;const visible=hazards.slice(0,2),offsets=visible.length===1?[0]:[-8,8];return <g className="ensemble-hazard-marker" pointerEvents="none">{visible.map((hazard,index)=><g key={`${hazard.title}-${index}`} transform={`translate(${Number(cx)+offsets[index]},${Number(cy)})`}><circle r="7" fill={DWD_WARNING_COLORS[hazard.level]} stroke="rgba(255,255,255,.88)" strokeWidth="1"/><text x="0" y=".5" textAnchor="middle" dominantBaseline="central" fontSize="9">{hazard.symbol}</text><title>{`${hazard.title}${hazard.value?`: ${hazard.value}`:''}${hazard.detail?` · ${hazard.detail}`:''}`}</title></g>)}</g>}
function ConsistencyControl({date,confidence,modelCount,memberCount,open,onOpen,onClose,onToggle}:{date:string;confidence:number;modelCount:number;memberCount:number;open:boolean;onOpen:()=>void;onClose:()=>void;onToggle:()=>void}){
 const buttonRef=useRef<HTMLButtonElement>(null),tooltipRef=useRef<HTMLDivElement>(null),[position,setPosition]=useState({left:8,top:8,width:230,above:false});
 const consistencyLabel=confidence>=85?'sehr hoch':confidence>=70?'hoch':confidence>=50?'mittel':confidence>=35?'gering':'sehr gering',tooltipId=`consistency-${date}`;
 useLayoutEffect(()=>{if(!open||typeof window==='undefined')return;let frame=0;const update=()=>{const anchor=buttonRef.current;if(!anchor)return;const rect=anchor.getBoundingClientRect(),width=Math.min(250,Math.max(210,window.innerWidth-16)),height=tooltipRef.current?.offsetHeight??92;let left=rect.left+rect.width/2-width/2;left=clamp(left,8,Math.max(8,window.innerWidth-width-8));let top=rect.bottom+8,above=false;if(top+height>window.innerHeight-8&&rect.top-height-8>=8){top=rect.top-height-8;above=true}else top=clamp(top,8,Math.max(8,window.innerHeight-height-8));setPosition({left,top,width,above})};frame=window.requestAnimationFrame(update);window.addEventListener('resize',update);window.addEventListener('scroll',update,true);return()=>{window.cancelAnimationFrame(frame);window.removeEventListener('resize',update);window.removeEventListener('scroll',update,true)}},[open]);
 const tooltip=open&&typeof document!=='undefined'?createPortal(<div ref={tooltipRef} id={tooltipId} className={`consistency-popover consistency-popover-portal${position.above?' above':''}`} role="tooltip" style={{left:position.left,top:position.top,width:position.width}}><strong>Prognosekonsistenz: {confidence} %</strong><span>{consistencyLabel} · {modelCount} Modelle{memberCount?` · ${memberCount} Mitglieder`:''}</span><small>{confidence>=70?'Die Modelllösungen liegen vergleichsweise eng zusammen.':confidence>=50?'Die Modelllösungen zeigen eine mittlere Streuung.':'Die Modelllösungen streuen deutlich; Änderungen sind wahrscheinlicher.'}</small></div>,document.body):null;
 const fineHover=()=>typeof window!=='undefined'&&window.matchMedia('(hover: hover) and (pointer: fine)').matches;
 return <div className={`consistency-trigger${open?' open':''}`} onMouseEnter={()=>{if(fineHover())onOpen()}} onMouseLeave={()=>{if(fineHover())onClose()}}><button ref={buttonRef} type="button" className="dot consistency-dot" style={{background:confidenceColor(confidence),boxShadow:`0 0 0 4px color-mix(in srgb, ${confidenceColor(confidence)} 18%, transparent)`}} aria-label={`Prognosekonsistenz ${confidence} Prozent`} aria-expanded={open} aria-describedby={open?tooltipId:undefined} onClick={event=>{event.preventDefault();event.stopPropagation();onToggle()}}/>{tooltip}</div>
}
function RainTooltip({active,payload,label}:{active?:boolean;payload?:ChartTooltipPayload<TrendRow>[];label?:string}){
 const row=tooltipRow(payload);
 if(!active||!row)return null;
 const value=(input:unknown)=>{const number=Number(input);return Number.isFinite(number)?number:null};
 const best=value(row.bestPrecipitation),low=value(row.precipitationLow),high=value(row.precipitationHigh),mean=value(row.precipitationMean),probability=value(row.precipitationProbability);
 return <div className="charttooltip rain-tooltip"><strong>{row.label??label}</strong><span>Best Match: {best===null?'–':formatDecimalFixed(best,1)} mm</span><span>P10–P90: {low===null?'–':formatDecimalFixed(low,1)} bis {high===null?'–':formatDecimalFixed(high,1)} mm</span><span>Ensemble-Mittel: {mean===null?'–':formatDecimalFixed(mean,1)} mm</span><span>Niederschlagswahrscheinlichkeit: {probability===null?'–':Math.round(probability)} %</span></div>
}
function tooltipTemperature(value:unknown){const number=Number(value);return Number.isFinite(number)?`${formatDecimalFixed(number,1)}°`:'–'}
function tooltipTemperatureRange(low:unknown,high:unknown){const a=Number(low),b=Number(high);return Number.isFinite(a)&&Number.isFinite(b)?`${formatDecimalFixed(a,1)}–${formatDecimalFixed(b,1)}°`:'–'}
function TrendTooltip({active,payload,label,showEnsMean,showClimatology,showQuartiles,coordinate,chartRef}:{active?:boolean;payload?:ChartTooltipPayload<TrendRow>[];label?:string;showEnsMean:boolean;showClimatology:boolean;showQuartiles:boolean;coordinate?:{x?:number;y?:number};chartRef:{current:HTMLDivElement|null}}){
 const row=tooltipRow(payload),tooltipRef=useRef<HTMLDivElement>(null),[position,setPosition]=useState({left:8,top:8,width:304,ready:false});
 useLayoutEffect(()=>{
  if(!active||!row||typeof window==='undefined'||typeof document==='undefined')return;
  let frame=0;
  const update=()=>{
   const chart=chartRef.current,tooltip=tooltipRef.current;
   if(!chart||!tooltip)return;
   const viewportWidth=window.visualViewport?.width??window.innerWidth,viewportHeight=window.visualViewport?.height??window.innerHeight,viewportLeft=window.visualViewport?.offsetLeft??0,viewportTop=window.visualViewport?.offsetTop??0,margin=8,gap=10;
   const width=Math.max(1,Math.min(326,viewportWidth-margin*2));
   tooltip.style.width=`${width}px`;
   tooltip.style.maxHeight=`${Math.max(1,viewportHeight-margin*2)}px`;
   const chartRect=chart.getBoundingClientRect(),height=Math.min(tooltip.scrollHeight,Math.max(1,viewportHeight-margin*2)),anchorX=chartRect.left+(Number.isFinite(coordinate?.x)?Number(coordinate?.x):chartRect.width/2),anchorY=chartRect.top+(Number.isFinite(coordinate?.y)?Number(coordinate?.y):chartRect.height/2);
   let left=viewportWidth<=560?viewportLeft+(viewportWidth-width)/2:anchorX+gap;
   if(left+width>viewportLeft+viewportWidth-margin)left=anchorX-width-gap;
   left=clamp(left,viewportLeft+margin,Math.max(viewportLeft+margin,viewportLeft+viewportWidth-width-margin));
   let top=anchorY+gap;
   if(top+height>viewportTop+viewportHeight-margin)top=anchorY-height-gap;
   top=clamp(top,viewportTop+margin,Math.max(viewportTop+margin,viewportTop+viewportHeight-height-margin));
   setPosition(current=>Math.abs(current.left-left)<.5&&Math.abs(current.top-top)<.5&&Math.abs(current.width-width)<.5&&current.ready?current:{left,top,width,ready:true});
  };
  frame=window.requestAnimationFrame(update);
  const viewport=window.visualViewport;
  window.addEventListener('resize',update);
  window.addEventListener('scroll',update,true);
  viewport?.addEventListener('resize',update);
  viewport?.addEventListener('scroll',update);
  return()=>{window.cancelAnimationFrame(frame);window.removeEventListener('resize',update);window.removeEventListener('scroll',update,true);viewport?.removeEventListener('resize',update);viewport?.removeEventListener('scroll',update)};
 },[active,row?.date,coordinate?.x,coordinate?.y,showEnsMean,showClimatology,showQuartiles,chartRef]);
 if(!active||!row||typeof document==='undefined')return null;
 const hasSunRange=Number.isFinite(row.sunshineLowHours)&&Number.isFinite(row.sunshineHighHours);
 return createPortal(<div ref={tooltipRef} className="charttooltip trend-tooltip compact-trend-tooltip trend-tooltip-portal" role="tooltip" aria-label={`Ensemblewerte für ${row.label??label}`} style={{left:position.left,top:position.top,width:position.width,visibility:position.ready?'visible':'hidden'}}>
  <strong className="trend-tooltip-date">{row.label??label}</strong>
  <div className="trend-tooltip-temperature-table" role="table" aria-label="Temperaturbereiche">
   <div className="trend-tooltip-table-row trend-tooltip-table-head" role="row"><span role="columnheader">Bereich</span><b role="columnheader">Tmin</b><b role="columnheader">Tmax</b></div>
   <div className="trend-tooltip-table-row" role="row"><b role="rowheader">Best Match</b><span role="cell">{tooltipTemperature(row.bestMin)}</span><span role="cell">{tooltipTemperature(row.bestMax)}</span></div>
   {showQuartiles&&row.x<7&&<div className="trend-tooltip-table-row" role="row"><b role="rowheader">P25–P75</b><span role="cell">{tooltipTemperatureRange(row.minQ25,row.minQ75)}</span><span role="cell">{tooltipTemperatureRange(row.maxQ25,row.maxQ75)}</span></div>}
   <div className="trend-tooltip-table-row" role="row"><b role="rowheader">P10–P90</b><span role="cell">{Number.isFinite(row.minLow)&&Number.isFinite(row.minHigh)?`${formatDecimalFixed(row.minLow,1)}–${formatDecimalFixed(row.minHigh,1)}°`:'–'}</span><span role="cell">{tooltipTemperatureRange(row.maxLow,row.maxHigh)}</span></div>
   {showEnsMean&&<div className="trend-tooltip-table-row" role="row"><b role="rowheader">ENS-Mittel</b><span role="cell">{tooltipTemperature(row.minMean)}</span><span role="cell">{tooltipTemperature(row.maxMean)}</span></div>}
   {showClimatology&&isFiniteNumber(row.climateMin)&&isFiniteNumber(row.climateMax)&&<div className="trend-tooltip-table-row" role="row"><b role="rowheader">Klima 1991–2020</b><span role="cell">{tooltipTemperature(row.climateMin)}</span><span role="cell">{tooltipTemperature(row.climateMax)}</span></div>}
  </div>
  <div className="tooltip-group tooltip-group-wide sunshine-tooltip-line trend-tooltip-meta-row"><b>Sonnenscheindauer</b><span className="trend-tooltip-values"><span><em>Best Match</em><strong>{formatSunshineHours(row.bestSunshineHours)} h</strong></span>{hasSunRange&&<span><em>P10–P90</em><strong>{formatSunshineHours(row.sunshineLowHours)} bis {formatSunshineHours(row.sunshineHighHours)} h</strong></span>}</span></div>
  {row.hazards.length>0&&<div className="trend-tooltip-meta-row trend-tooltip-hazards ensemble-hazard-tooltip"><b>Best-Match-Hazards</b><span>{row.hazards.map(hazard=><em key={`${hazard.level}:${hazard.title}:${hazard.value??''}`}>{hazard.symbol} {hazard.title}{hazard.value?`: ${hazard.value}`:''}</em>)}</span></div>}
  <div className="trend-tooltip-meta-row"><b>Prognosekonsistenz</b><span className="trend-tooltip-consistency"><strong>{Math.round(row.confidence)} %</strong><span>{row.modelCount} Modelle{row.memberCount?` · ${row.memberCount} Mitglieder`:''}</span></span></div>
 </div>,document.body);
}
function TemperatureLegend({showEnsMean,setShowEnsMean,showClimatology,setShowClimatology,showQuartiles,setShowQuartiles}:{showEnsMean:boolean;setShowEnsMean:(v:boolean)=>void;showClimatology:boolean;setShowClimatology:(v:boolean)=>void;showQuartiles:boolean;setShowQuartiles:(v:boolean)=>void}){return <div className="trend-legend"><span><i className="area max"/>ENS-Spanne Tmax</span><span><i className="area min"/>ENS-Spanne Tmin</span><button type="button" className={`quartile-toggle${showQuartiles?'':' inactive'}`} onClick={()=>setShowQuartiles(!showQuartiles)} aria-pressed={showQuartiles} title="P25–P75 für die ersten sieben Tage ein-/ausblenden"><span className="quartile-key"><i className="area quartile-max"/>P25–P75 Tmax</span><span className="quartile-key"><i className="area quartile-min"/>P25–P75 Tmin</span><small>Tage 1–7</small></button><span><i className="line best-max"/>Best Match Tmax</span><span><i className="line best-min"/>Best Match Tmin</span><button type="button" className={showEnsMean?'':'inactive'} onClick={()=>setShowEnsMean(!showEnsMean)} aria-pressed={showEnsMean}><i className="line ens-max"/>ENS-Mittel</button><button type="button" className={showClimatology?'':'inactive'} onClick={()=>setShowClimatology(!showClimatology)} aria-pressed={showClimatology}><i className="line climate"/>Klimamittel Tmin/Tmax</button></div>}
function CombinedTrendChart({data,showEnsMean,setShowEnsMean,showClimatology,setShowClimatology,showQuartiles,setShowQuartiles}:{data:TrendRow[];showEnsMean:boolean;setShowEnsMean:(v:boolean)=>void;showClimatology:boolean;setShowClimatology:(v:boolean)=>void;showQuartiles:boolean;setShowQuartiles:(v:boolean)=>void}){
 const chartRef=useRef<HTMLDivElement>(null);
 const values=data.flatMap(row=>[row.maxLow,row.maxHigh,row.minLow,row.minHigh,row.bestMax,row.bestMin,showEnsMean?row.maxMean:undefined,showEnsMean?row.minMean:undefined,showClimatology?row.climateMax:undefined,showClimatology?row.climateMin:undefined]),vals=values.filter(isFiniteNumber),fallbackValues=data.flatMap(row=>[row.bestMin,row.bestMax]).filter(isFiniteNumber),scaleValues=vals.length?vals:fallbackValues,temperatureScale=niceTemperatureScale(Math.min(...scaleValues)-1.5,Math.max(...scaleValues)+1.5,5),minV=temperatureScale.min,maxV=temperatureScale.max,ticks=temperatureScale.ticks;
 const maxDayIndex=Math.max(0,data.length-1);
 return <div ref={chartRef} className="chart trend-combined"><div className="trend-chart-toolbar"><TemperatureLegend showEnsMean={showEnsMean} setShowEnsMean={setShowEnsMean} showClimatology={showClimatology} setShowClimatology={setShowClimatology} showQuartiles={showQuartiles} setShowQuartiles={setShowQuartiles}/><SunshineScaleLegend/></div><ResponsiveContainer width="100%" height="100%"><ComposedChart data={data} margin={{top:14,right:18,left:12,bottom:36}}><CartesianGrid strokeDasharray="3 3" opacity={.22}/><XAxis dataKey="x" type="number" scale="linear" domain={[-.5,Math.max(.5,maxDayIndex+.5)]} ticks={data.map(row=>row.x)} allowDecimals={false} tick={{fontSize:11}} tickMargin={10} interval={0} tickFormatter={value=>data[Math.round(Number(value))]?.label??''} label={{value:'Vorhersagetag',position:'insideBottom',offset:-22}}/><YAxis yAxisId="t" domain={[minV,maxV]} ticks={ticks} tick={{fontSize:11}} width={68} tickFormatter={value=>`${formatDecimal(Number(value),1)}°C`} label={{value:'Temperatur (°C)',angle:-90,position:'insideLeft',offset:4}}/><YAxis yAxisId="sky" hide width={0} domain={[0,100]} axisLine={false} tickLine={false} tick={false}/><YAxis yAxisId="right-reserve" orientation="right" domain={[0,1]} width={58} tick={false} axisLine={false} tickLine={false}/><Tooltip content={<TrendTooltip chartRef={chartRef} showEnsMean={showEnsMean} showClimatology={showClimatology} showQuartiles={showQuartiles}/>} offset={12} allowEscapeViewBox={{x:true,y:true}} wrapperStyle={{zIndex:0,pointerEvents:'none'}}/>{data.map(row=><ReferenceArea key={`sky-${row.date}`} className="ensemble-sky-strip" yAxisId="sky" x1={row.x-.46} x2={row.x+.46} y1={0} y2={6.5} fill={row.skyColor} fillOpacity={.96} stroke="rgba(120,132,142,.38)" strokeWidth={1}/>) }<Area yAxisId="t" stackId="max" type="monotone" dataKey="maxLow" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="max" type="monotone" dataKey="maxBand" stroke="none" fill="#ff845f" fillOpacity={0.22} legendType="none"/><Area yAxisId="t" stackId="min" type="monotone" dataKey="minLow" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="min" type="monotone" dataKey="minBand" stroke="none" fill="#53a9ff" fillOpacity={0.22} legendType="none"/><Area yAxisId="t" stackId="maxQ" type="monotone" dataKey="maxQ25Plot" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="maxQ" type="monotone" dataKey="maxQBandPlot" stroke="none" fill="#e85f35" fillOpacity={0.34} legendType="none"/><Area yAxisId="t" stackId="minQ" type="monotone" dataKey="minQ25Plot" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="minQ" type="monotone" dataKey="minQBandPlot" stroke="none" fill="#267fc9" fillOpacity={0.34} legendType="none"/><Line yAxisId="t" hide={!showEnsMean} type="monotone" dataKey="maxMean" stroke="#ffb07b" strokeWidth={1.7} strokeDasharray="5 4" dot={false} legendType="none"/><Line yAxisId="t" hide={!showEnsMean} type="monotone" dataKey="minMean" stroke="#92cfff" strokeWidth={1.7} strokeDasharray="5 4" dot={false} legendType="none"/><Line yAxisId="t" hide={!showClimatology} type="monotone" dataKey="climateMax" stroke="#a86d16" strokeWidth={2.1} strokeDasharray="2 4" dot={false} connectNulls legendType="none"/><Line yAxisId="t" hide={!showClimatology} type="monotone" dataKey="climateMin" stroke="#6c61a8" strokeWidth={2.1} strokeDasharray="2 4" dot={false} connectNulls legendType="none"/><Line yAxisId="t" type="monotone" dataKey="bestMax" stroke="#ff6a37" strokeWidth={3.1} dot={{r:2.4}} connectNulls legendType="none"/><Line yAxisId="t" type="monotone" dataKey="bestMin" stroke="#248dff" strokeWidth={3.1} dot={{r:2.4}} connectNulls legendType="none"/>{data.filter(row=>Array.isArray(row.hazards)&&row.hazards.length>0).map(row=><ReferenceDot key={`hazard-${row.date}`} yAxisId="sky" x={row.x} y={11} r={0} isFront shape={(props:{cx?:number;cy?:number})=><EnsembleHazardShape {...props} hazards={row.hazards}/>}/>)}</ComposedChart></ResponsiveContainer></div>
}

function RainLegend({showProbability,onToggle}:{showProbability:boolean;onToggle:()=>void}){return <div className="rain-legend"><span><i className="bar"/>Best Match</span><span><i className="errorbar"/>P10–P90</span><button type="button" className={showProbability?'':'inactive'} onClick={onToggle} aria-pressed={showProbability} title="Niederschlagswahrscheinlichkeit ein-/ausblenden"><i className="line probability"/>Niederschlagswahrscheinlichkeit</button></div>}
export default function EnsemblePanel({data,models,runs,days,hours,elevation,unit,climate,climateLoading,climateError,loading,error,advancedMode}:{data:EnsembleDay[];models:string[];runs:ModelRunMeta[];days:Day[];hours:Hour[];elevation:number;unit:WindUnit;climate:ClimateDay[];climateLoading:boolean;climateError:string;loading:boolean;error:string;advancedMode:boolean}){
 const[showRainProbability,setShowRainProbability]=useState(true),[showEnsMean,setShowEnsMean]=useState(true),[showClimatology,setShowClimatology]=useState(true),[showQuartiles,setShowQuartiles]=useState(true),[selectedConsistency,setSelectedConsistency]=useState<string|null>(null);
 const climateMap=new Map(climate.map(x=>[x.date,x]));
 const best=new Map(days.map(x=>[x.date,x]));
 const maxModels=Math.max(1,models.length);
 const d:TrendRow[]=data.filter(x=>best.has(x.date)).slice(0,14).map((x,index)=>{
  const day=best.get(x.date)!;
  const bestMax=day.max,bestMin=day.min,bestPrecipitation=day.precipitation,maxLow=x.maxLow,maxHigh=x.maxHigh,minLow=x.minLow,minHigh=x.minHigh;
  const spread=Math.max(0,((maxHigh-maxLow)+(minHigh-minLow))/2);
  const scoreSpread=clamp(100-spread*7.5,25,97),scoreLead=clamp(100-index*3.7,45,100),scoreModels=clamp(55+(x.modelCount/maxModels)*45,55,100);
  const confidence=Math.round(clamp(scoreSpread*.48+scoreLead*.22+scoreModels*.30,25,97));
  const climateDay=climateMap.get(x.date),bestSunshineSeconds=sanitizeSunshineSeconds(day,day.sunshineDuration,0),sunShare=sunshineShare(day,bestSunshineSeconds),rawSunLow=sanitizeSunshineSeconds(day,x.sunshineDurationLow),rawSunHigh=sanitizeSunshineSeconds(day,x.sunshineDurationHigh),sunshineLowSeconds=Number.isFinite(rawSunLow)&&Number.isFinite(rawSunHigh)?Math.min(rawSunLow,rawSunHigh):NaN,sunshineHighSeconds=Number.isFinite(rawSunLow)&&Number.isFinite(rawSunHigh)?Math.max(rawSunLow,rawSunHigh):NaN,dayHours=hours.filter(hour=>hour.time.startsWith(x.date)),character=dayWeatherCharacter(day,dayHours),hazards=summarizeDwdWarnings(dayHours,elevation).filter(signal=>signal.level>=2).slice(0,2).map(signal=>({symbol:signal.symbol,level:signal.level,title:signal.title,value:formatDwdWarningValue(signal,unit),detail:formatDwdWarningDetail(signal,unit)}));return{...x,x:index,climateMax:climateDay?.maxMean,climateMin:climateDay?.minMean,label:formatDateOnly(x.date,{weekday:'short',day:'2-digit'}),weekday:formatDateOnly(x.date,{weekday:'short'}),dayLabel:formatDateOnly(x.date,{day:'2-digit',month:'2-digit'}),bestMax,bestMin,bestPrecipitation,code:day.code,characterCode:character.code,characterLabel:character.label,maxBand:Math.max(.2,maxHigh-maxLow),minBand:Math.max(.2,minHigh-minLow),maxQ25Plot:index<7&&showQuartiles?x.maxQ25:null,maxQBandPlot:index<7&&showQuartiles?Math.max(.1,x.maxQ75-x.maxQ25):null,minQ25Plot:index<7&&showQuartiles?x.minQ25:null,minQBandPlot:index<7&&showQuartiles?Math.max(.1,x.minQ75-x.minQ25):null,confidence,bestSunshineHours:bestSunshineSeconds/3600,sunshineLowHours:Number.isFinite(sunshineLowSeconds)?sunshineLowSeconds/3600:NaN,sunshineHighHours:Number.isFinite(sunshineHighSeconds)?sunshineHighSeconds/3600:NaN,precipitationMidPlot:bestPrecipitation>=.1?(Math.max(0,Math.min(x.precipitationLow,x.precipitationHigh))+Math.max(0,Math.max(x.precipitationLow,x.precipitationHigh)))/2:undefined,precipitationErrorRange:bestPrecipitation>=.1?(()=>{const low=Math.max(0,Math.min(x.precipitationLow,x.precipitationHigh)),high=Math.max(0,Math.max(x.precipitationLow,x.precipitationHigh)),mid=(low+high)/2;return[mid-low,high-mid] as [number,number]})():undefined,hazards,sunshineShare:sunShare,skyColor:skyBandColor(sunShare)}
 });
 const fallback=days.slice(0,14),fallbackMin=Math.min(...fallback.map(x=>x.min)),fallbackMax=Math.max(...fallback.map(x=>x.max)),fallbackRange=Math.max(1,fallbackMax-fallbackMin);
 if(!d.length)return <section className="card ensemble"><Title eye={loading?'ENS-Modelle werden geladen':'ENS-Datenstatus'} title="14-Tage-Ensemble-Trend"><ModelRunDetails runs={runs}/></Title><div className={`ensemble-status ${loading?'loading':''}`}><RefreshCw className={loading?'spin':''}/><div><strong>{loading?'Ensemble-Daten werden berechnet …':'Ensemble-Auswertung derzeit nicht vollständig verfügbar'}</strong><span>{loading?'Die 14-Tage-Übersicht wird automatisch ergänzt, sobald genügend Modellläufe vorliegen.':error||'Best Match bleibt als vorläufige Referenz sichtbar.'}</span></div></div><div className="charthead"><h3>14-Tage-Übersicht</h3><ModeExplanation advanced={advancedMode} summary={<>Die Best-Match-Spanne bleibt sichtbar, während Ensemble-Daten geladen werden.</>} technical={<>Vorläufige Best-Match-Spanne; Konsistenzpunkte erscheinen erst nach erfolgreicher und ausreichend vollständiger Ensemble-Auswertung.</>}/></div><div className="ens-overview-grid fallback">{fallback.map(x=>{const left=((x.min-fallbackMin)/fallbackRange)*100,width=((x.max-x.min)/fallbackRange)*100,character=dayWeatherCharacter(x,hours.filter(hour=>hour.time.startsWith(x.date)));return <article className="ens-card" key={x.date}><header><div><strong>{formatDateOnly(x.date,{weekday:'short'})}</strong><small>{formatDateOnly(x.date,{day:'2-digit',month:'2-digit'})}</small></div><span className="dot pending"/></header><div className="wx">{icon(character.code,true)}</div><div className="barzone"><div className="barbg"><div className="bestrange" style={{left:`${left}%`,width:`${Math.max(8,width)}%`}}/></div></div><div className="temps"><b>{Math.round(x.min)}°</b><strong>{Math.round(x.max)}°</strong></div><small>{character.label}</small></article>})}</div></section>;
 const rainScale=niceRainScale(Math.max(...d.map(x=>Math.max(x.bestPrecipitation,x.precipitationHigh)),1));
 const overallMin=Math.floor((Math.min(...d.map(x=>Math.min(x.minLow,x.bestMin)))-2)/2)*2,overallMax=Math.ceil((Math.max(...d.map(x=>Math.max(x.maxHigh,x.bestMax)))+2)/2)*2,range=Math.max(1,overallMax-overallMin);
 const hasMembers=d.some(x=>x.memberCount>0),summaryMembers=Math.round(d.reduce((s,x)=>s+x.memberCount,0)/d.length);
 return <section className="card ensemble"><Title eye={`${models.length} verfügbare ENS-Modelle`} title="14-Tage-Ensemble-Trend"><ModelRunDetails runs={runs}/></Title>
  <div className="chips">{models.map(x=><span key={x}>{x}</span>)}</div>
  <div className="charthead"><h3>14-Tage-Ensemble-Übersicht</h3><ModeExplanation advanced={advancedMode} summary={<>Die Spanne zeigt den wahrscheinlichen Temperaturbereich; der Farbpunkt bewertet die Übereinstimmung der Modelle.</>} technical={<>Best Match, gewichtetes P10–P90-Intervall und farbiger Konsistenzpunkt pro Tag. Die Konsistenz kombiniert Streuung, Vorhersagehorizont und verfügbare Modellfamilien.</>}/></div>
  <div className="ens-summary">{hasMembers?<span><b>{summaryMembers}</b> Ensemble-Mitglieder pro Tag im Mittel</span>:<span><b>{models.length}</b> verfügbare Modellmittel</span>}<span><b>{models.length}</b> Modellfamilien aktiv</span></div>
  <div className="consistency-legend" aria-label="Legende der Prognosekonsistenz"><span>gering</span><i/><span>hoch</span><small>0&nbsp;%</small><small>25&nbsp;%</small><small>50&nbsp;%</small><small>75&nbsp;%</small><small>100&nbsp;%</small></div>
  <div className="ens-overview-grid">{d.map(x=>{const ensLeft=((x.minLow-overallMin)/range)*100,ensWidth=((x.maxHigh-x.minLow)/range)*100,bestLeft=((x.bestMin-overallMin)/range)*100,bestWidth=((x.bestMax-x.bestMin)/range)*100,openConsistency=selectedConsistency===x.date;return <article key={x.date} className={`ens-card${openConsistency?' consistency-open':''}`}><header><div><strong>{x.weekday}</strong><small>{x.dayLabel}</small></div><ConsistencyControl date={x.date} confidence={x.confidence} modelCount={x.modelCount} memberCount={x.memberCount} open={openConsistency} onOpen={()=>setSelectedConsistency(x.date)} onClose={()=>setSelectedConsistency(current=>current===x.date?null:current)} onToggle={()=>setSelectedConsistency(current=>current===x.date?null:x.date)}/></header><div className="wx">{icon(x.characterCode,true)}</div><div className="barzone"><div className="barbg"><div className="ensspread" style={{left:`${Math.max(0,ensLeft)}%`,width:`${Math.max(6,ensWidth)}%`}}/><div className="bestrange" style={{left:`${Math.max(0,bestLeft)}%`,width:`${Math.max(8,bestWidth)}%`}}/></div></div><div className="temps"><b>{Math.round(x.bestMin)}°</b><strong>{Math.round(x.bestMax)}°</strong></div><small>{x.characterLabel}</small><span className="ens-rainprob">💧 {Math.round(x.precipitationProbability)} %</span></article>})}</div>
  <div className="enslegend"><span><i className="swatch ensemble"/> P10–P90-Temperaturbereich</span><span><i className="swatch best"/> Best-Match Min–Max</span></div>
  <div className="charthead"><h3>Temperaturtrend und Prognoseunsicherheit</h3><ModeExplanation advanced={advancedMode} summary={<>Die farbigen Flächen zeigen die Prognoseunsicherheit. Das schmale Band an der Zeitachse steht für die erwartete Sonnenscheindauer.</>} technical={<>Best Match, P10–P90, optionales ENS-Mittel und klimatologisches Tagesmittel 1991–2020. Das Band direkt oberhalb der Zeitachse zeigt die Best-Match-Sonnenscheindauer von Grau (wenig Sonne) bis Gelb (viel Sonne); der Tooltip ergänzt P10–P90.{climateLoading?' Klimadaten werden geladen …':climateError?' Klimamittel derzeit nicht verfügbar.':''}</>}/></div><CombinedTrendChart data={d} showEnsMean={showEnsMean} setShowEnsMean={setShowEnsMean} showClimatology={showClimatology&&climate.length>0} setShowClimatology={setShowClimatology} showQuartiles={showQuartiles} setShowQuartiles={setShowQuartiles}/>
  <div className="charthead"><h3>Niederschlag</h3><ModeExplanation advanced={advancedMode} summary={<>Blaue Balken zeigen den Best-Match-Niederschlag; graue Fehlerbalken markieren die Ensemble-Spanne.</>} technical={<>Täglicher Best-Match-Niederschlag für den Ort, ergänzt um einen gewichteten P10–P90-Fehlerbalken und die Niederschlagswahrscheinlichkeit. Der Fehlerbalken wird nur an Tagen mit Best-Match-Niederschlag dargestellt.</>}/></div><div className="chart rain"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={d} margin={{top:16,right:18,left:12,bottom:36}}><CartesianGrid strokeDasharray="3 3" opacity={.22}/><XAxis dataKey="x" type="number" scale="linear" domain={[-.5,Math.max(.5,d.length-.5)]} ticks={d.map(row=>row.x)} allowDecimals={false} tick={{fontSize:11}} tickMargin={10} interval={0} tickFormatter={value=>d[Math.round(Number(value))]?.label??''} label={{value:'Vorhersagetag',position:'insideBottom',offset:-22}}/><YAxis yAxisId="mm" domain={[0,rainScale.max]} ticks={rainScale.ticks} tick={{fontSize:11}} width={68} tickFormatter={(v)=>`${formatDecimal(Number(v),1)} mm`} label={{value:'Niederschlag (mm)',angle:-90,position:'insideLeft',offset:4}}/><YAxis yAxisId="prob" orientation="right" domain={[0,100]} ticks={[0,25,50,75,100]} tick={showRainProbability?{fontSize:11}:false} axisLine={showRainProbability} tickLine={showRainProbability} width={58} tickFormatter={(v)=>`${v} %`} label={showRainProbability?{value:'Wahrscheinlichkeit',angle:90,position:'insideRight',offset:4}:undefined}/><Tooltip content={<RainTooltip/>}/><Legend verticalAlign="top" height={44} content={<RainLegend showProbability={showRainProbability} onToggle={()=>setShowRainProbability(v=>!v)}/>}/><Bar yAxisId="mm" dataKey="bestPrecipitation" name="bestPrecipitation" fill="#2688ff" barSize={Math.max(8,Math.min(28,420/Math.max(1,d.length)))} radius={[5,5,0,0]}/><Scatter yAxisId="mm" dataKey="precipitationMidPlot" name="precipitationMidPlot" fill="#666" fillOpacity={0} line={false} isAnimationActive={false}><ErrorBar dataKey="precipitationErrorRange" direction="y" width={10} stroke="#666" strokeWidth={3}/></Scatter><Line yAxisId="prob" hide={!showRainProbability} type="monotone" dataKey="precipitationProbability" name="precipitationProbability" stroke="#48d3ff" strokeWidth={2.4} dot={{r:2.4}}/></ComposedChart></ResponsiveContainer></div></section>
}
