import {useEffect,useMemo,useRef,useState} from 'react';
import {AlertTriangle,BadgeCheck,Cloud,Download,Droplets,Gauge,LocateFixed,Moon,Navigation,RefreshCw,Search,Settings2,Sun,ThermometerSun,Umbrella,Wind,X} from 'lucide-react';
import {Area,AreaChart,Bar,CartesianGrid,ComposedChart,Legend,Line,ResponsiveContainer,Tooltip,XAxis,YAxis} from 'recharts';
import {CircleMarker,MapContainer,Popup,TileLayer,useMap} from 'react-leaflet';
import {toPng} from 'html-to-image';
import {airQuality,currentIndex,ensembles,forecast,hazards,icon,label,mapDays,mapHours,searchLocations,station,wind,type Day,type EnsembleDay,type Hour,type Location,type Station,type Weather,type WindUnit} from './weather';

const VERSION='0.3.8';
const DEFAULT:Location={id:1,name:'Rheidt',latitude:50.8069,longitude:7.0415,elevation:58,country:'Deutschland',country_code:'DE',admin1:'Nordrhein-Westfalen'};

type Radar={host:string;radar:{past:{time:number;path:string}[]}};

export default function App(){
 const[loc,setLoc]=useState<Location>(DEFAULT),[w,setW]=useState<Weather|null>(null),[air,setAir]=useState<any>(null),[ens,setEns]=useState<EnsembleDay[]>([]),[models,setModels]=useState<string[]>([]),[st,setSt]=useState<Station|null>(null),[stationLoading,setStationLoading]=useState(false),[loading,setLoading]=useState(true),[error,setError]=useState(''),[dark,setDark]=useState(()=>localStorage.getItem('theme')!=='light'),[unit,setUnit]=useState<WindUnit>(()=>(localStorage.getItem('windUnit') as WindUnit)||'kn'),[selected,setSelected]=useState('');
 const seq=useRef(0);
 useEffect(()=>{document.documentElement.dataset.theme=dark?'dark':'light';localStorage.setItem('theme',dark?'dark':'light')},[dark]);
 useEffect(()=>localStorage.setItem('windUnit',unit),[unit]);
 async function load(){const id=++seq.current,c=new AbortController();setLoading(true);setError('');setSt(null);setStationLoading(true);try{const[fw,aq]=await Promise.all([forecast(loc.latitude,loc.longitude,c.signal),airQuality(loc.latitude,loc.longitude,c.signal).catch(()=>null)]);if(id!==seq.current)return;setW(fw);setAir(aq);setSelected(String(fw.daily.time[0]));setLoading(false);station(loc.latitude,loc.longitude,loc.country_code,loc.elevation??fw.elevation,c.signal).then(x=>id===seq.current&&setSt(x)).finally(()=>id===seq.current&&setStationLoading(false));ensembles(loc.latitude,loc.longitude,c.signal).then(x=>{if(id===seq.current){setEns(x.days);setModels(x.models)}}).catch(()=>{if(id===seq.current){setEns([]);setModels([])}})}catch(e){if(id===seq.current){setLoading(false);setStationLoading(false);setError(e instanceof Error?e.message:'Laden fehlgeschlagen')}}}
 useEffect(()=>{void load()},[loc.id,loc.latitude,loc.longitude]);
 function locate(){if(!navigator.geolocation){setError('Standortermittlung nicht unterstützt.');return}setLoading(true);navigator.geolocation.getCurrentPosition(p=>setLoc({id:Date.now(),name:'Aktueller Standort',latitude:p.coords.latitude,longitude:p.coords.longitude,elevation:p.coords.altitude??undefined,country_code:p.coords.latitude>=47&&p.coords.latitude<=55.2&&p.coords.longitude>=5.5&&p.coords.longitude<=15.6?'DE':undefined}),()=>{setLoading(false);setError('Standort konnte nicht ermittelt werden.')},{enableHighAccuracy:true,timeout:15000,maximumAge:300000})}
 const hours=useMemo(()=>w?mapHours(w):[],[w]),days=useMemo(()=>w?mapDays(w):[],[w]),hz=useMemo(()=>hazards(hours),[hours]),risk=hours[currentIndex(hours)]?.probability??0;
 return <div className="app"><Header loc={loc} setLoc={setLoc} locate={locate} loading={loading} dark={dark} setDark={setDark} unit={unit} setUnit={setUnit} reload={load}/><main><section className="place"><div><span>{loc.admin1??loc.country??'Standort'}</span><h1>{loc.name}</h1><p>{loc.latitude.toFixed(2)}°N, {loc.longitude.toFixed(2)}°E · {Math.round(loc.elevation??w?.elevation??0)} m ü. NHN</p></div><aside><small>Aktuelles Regenrisiko</small><strong>{Math.round(risk)} %</strong></aside></section>{error&&<div className="error">{error}</div>}{loading&&!w?<div className="loading"><RefreshCw className="spin"/><strong>Wettermodelle werden geladen …</strong><span>Best Match, Luftqualität und Ensembles</span></div>:w&&<><Current loc={loc} w={w} air={air} st={st} stationLoading={stationLoading} unit={unit}/><Hazards data={hz}/><div className="split"><Forecast days={days} hours={hours} selected={selected} setSelected={setSelected} unit={unit}/><Radar lat={loc.latitude} lon={loc.longitude}/></div>{ens.length>0&&<Ensembles data={ens} models={models} days={days}/>}<Widget loc={loc} days={days} unit={unit}/></>}</main><footer><span>MID v{VERSION} · Wetter: Open-Meteo · Radar: RainViewer · Stationen: Bright Sky / WMO / optionale METAR-Proxy-Quellen</span><span>Aktualisiert: {new Date().toLocaleString('de-DE')}</span></footer></div>
}

function Header({loc,setLoc,locate,loading,dark,setDark,unit,setUnit,reload}:{loc:Location;setLoc:(x:Location)=>void;locate:()=>void;loading:boolean;dark:boolean;setDark:(x:boolean)=>void;unit:WindUnit;setUnit:(x:WindUnit)=>void;reload:()=>void}){const[q,setQ]=useState(loc.name),[results,setResults]=useState<Location[]>([]),[open,setOpen]=useState(false);useEffect(()=>setQ(loc.name),[loc.name]);useEffect(()=>{if(q.trim().length<2||q===loc.name){setResults([]);return}const c=new AbortController(),t=setTimeout(()=>searchLocations(q,c.signal).then(x=>{setResults(x);setOpen(true)}).catch(()=>setResults([])),250);return()=>{clearTimeout(t);c.abort()}},[q,loc.name]);return <header className="top"><div className="brand"><b>M</b><span><strong>MID</strong><small>Meteorological Information Dashboard · v{VERSION}</small></span></div><div className="search"><div><Search size={18}/><input value={q} onChange={e=>setQ(e.target.value)} placeholder="Stadt oder Postleitzahl suchen"/>{q&&<button onClick={()=>setQ('')}><X size={16}/></button>}</div><button className="secondary locate" onClick={locate}><LocateFixed size={17}/>Standort</button>{open&&results.length>0&&<section>{results.map(r=><button key={r.id} onClick={()=>{setLoc(r);setQ(r.name);setOpen(false)}}><strong>{r.name}{r.postcodes?.[0]?` ${r.postcodes[0]}`:''}</strong><small>{[r.admin1,r.country].filter(Boolean).join(', ')}{Number.isFinite(r.elevation)?` · ${Math.round(r.elevation!)} m`:''}</small></button>)}</section>}</div><div className="actions"><label><Settings2 size={15}/><select value={unit} onChange={e=>setUnit(e.target.value as WindUnit)}><option value="kn">kt</option><option value="kmh">km/h</option><option value="ms">m/s</option><option value="mph">mph</option></select></label><button onClick={()=>setDark(!dark)}>{dark?<Sun size={19}/>:<Moon size={19}/>}</button><button onClick={reload} disabled={loading}><RefreshCw size={19} className={loading?'spin':''}/></button></div></header>}

function Current({loc,w,air,st,stationLoading,unit}:{loc:Location;w:Weather;air:any;st:Station|null;stationLoading:boolean;unit:WindUnit}){
 const c=w.current,fresh=!!st&&(!st.timestamp||Date.now()-new Date(st.timestamp).getTime()<150*60000),stationInfo=fresh?`${st!.name} · ${Number.isFinite(st!.height)?`${Math.round(st!.height!)} m`:'Höhe unbekannt'} · ${Number.isFinite(st!.distance)?`${(st!.distance!/1000).toFixed(1).replace('.',',')} km`:'Entfernung unbekannt'}`:'';
 const observed=(v:number|undefined,fallback:number)=>fresh&&Number.isFinite(v)?Number(v):fallback;
 const temp=observed(st?.temperature,Number(c.temperature_2m)),hum=observed(st?.humidity,Number(c.relative_humidity_2m)),dew=observed(st?.dewPoint,Number(c.dew_point_2m)),pressure=observed(st?.pressure,Number(c.pressure_msl)),windSpeed=observed(st?.windSpeed!=null?st.windSpeed/1.852:undefined,Number(c.wind_speed_10m)),windGust=observed(st?.windGust!=null?st.windGust/1.852:undefined,Number(c.wind_gusts_10m)),windDirection=observed(st?.windDirection,Number(c.wind_direction_10m)),cloud=observed(st?.cloudCover,Number(c.cloud_cover)),precip=observed(st?.precipitation,Number(c.precipitation));
 const source=(available:boolean,defaultText:string)=>available&&fresh?`${st!.provider??'Stationsmessung'} · ${st!.name}`:defaultText;
 const cards=[
  {icon:'💧',label:'Taupunkt',value:`${Math.round(dew)} °C`,detail:`Relative Feuchte ${Math.round(hum)} % · ${source(Number.isFinite(st?.dewPoint),'Best Match')}`,checked:fresh&&Number.isFinite(st?.dewPoint)},
  {icon:'🌬️',label:'Wind',value:wind(windSpeed,unit),detail:`Böen ${wind(windGust,unit)} · ${source(Number.isFinite(st?.windSpeed),'Best Match')}`,checked:fresh&&Number.isFinite(st?.windSpeed)},
  {icon:'🧭',label:'Windrichtung',value:`${Math.round(windDirection)}°`,detail:`meteorologische Herkunftsrichtung · ${source(Number.isFinite(st?.windDirection),'Best Match')}`,checked:fresh&&Number.isFinite(st?.windDirection)},
  {icon:'🌧️',label:'Niederschlag',value:`${precip.toFixed(1)} mm`,detail:source(Number.isFinite(st?.precipitation),'aktueller Modellzeitraum'),checked:fresh&&Number.isFinite(st?.precipitation)},
  {icon:'☁️',label:'Bewölkung',value:`${Math.round(cloud)} %`,detail:source(Number.isFinite(st?.cloudCover),'Best Match'),checked:fresh&&Number.isFinite(st?.cloudCover)},
  {icon:'⏱️',label:'Luftdruck',value:`${Math.round(pressure)} hPa`,detail:`auf Meereshöhe · ${source(Number.isFinite(st?.pressure),'Best Match')}`,checked:fresh&&Number.isFinite(st?.pressure)},
  {icon:'☀️',label:'UV-Index',value:air?.current?Number(air.current.uv_index).toFixed(1):'–',detail:'Open-Meteo Luftqualitätsmodell',checked:false},
  {icon:'🏭',label:'Luftqualität',value:air?.current?`${Math.round(Number(air.current.european_aqi))} AQI`:'–',detail:air?.current?`PM2,5 ${Number(air.current.pm2_5).toFixed(1)} µg/m³`:'Open-Meteo',checked:false},
  {icon:'🏔️',label:'Höhe',value:`${Math.round(loc.elevation??w.elevation)} m`,detail:'ü. NHN',checked:false}
 ];
 return <><section className="hero"><div>{icon(Number(c.weather_code),Number(c.is_day)===1)}</div><article><span>Aktuelles Wetter</span><strong>{Math.round(temp)}°</strong><b>{label(Number(c.weather_code))}</b><small>Gefühlt {Math.round(Number(c.apparent_temperature))} °C{fresh?' · Temperatur stationsgeprüft':''}</small></article><aside className={fresh?'ok':''}><i/><span><b>{fresh?'Nächstgeeignete Messstation':stationLoading?'Prüfung läuft':'Best Match'}</b><small>{fresh?stationInfo:stationLoading?'Stationsdaten werden im Hintergrund geprüft.':'Keine ausreichend aktuelle DWD-Station verfügbar – Fallback auf Best Match'}</small></span></aside></section><section className="metrics">{cards.map(x=><article key={x.label}><header><span>{x.icon}</span><small>{x.label}</small>{x.checked&&<i title="Mit aktueller Stationsmessung abgeglichen"/>}</header><strong>{x.value}</strong><small>{x.detail}</small></article>)}</section></>
}
function Hazards({data}:{data:ReturnType<typeof hazards>}){if(!data.length)return <section className="hazard clear"><BadgeCheck/><div><strong>Keine markanten Gefahrenindikatoren</strong><span>Die automatische Auswertung der nächsten 24 Stunden zeigt keine auffälligen Signale.</span></div></section>;return <section className="hazards">{data.map(x=><article className={x.level} key={x.title}><AlertTriangle/><div><strong>{x.title}</strong><span>{x.text}</span></div></article>)}<small>Automatisch berechnete Indikatoren – keine amtlichen Warnungen.</small></section>}

function MoveMap({lat,lon}:{lat:number;lon:number}){const map=useMap();useEffect(()=>{map.setView([lat,lon],7,{animate:true})},[lat,lon,map]);return null}
function Radar({lat,lon}:{lat:number;lon:number}){const[frames,setFrames]=useState<{host:string;items:{time:number;path:string}[]} | null>(null),[index,setIndex]=useState(0),[opacity,setOpacity]=useState(82);useEffect(()=>{let alive=true;fetch('https://api.rainviewer.com/public/weather-maps.json',{cache:'no-store'}).then(r=>r.json()).then((d:Radar)=>{if(!alive)return;const items=(d.radar?.past??[]).slice(-12);setFrames({host:d.host,items});setIndex(Math.max(0,items.length-1))}).catch(()=>setFrames(null));return()=>{alive=false}},[lat,lon]);const frame=frames?.items[index];const url=frame?`${frames!.host}${frame.path}/256/{z}/{x}/{y}/2/1_1.png`:'';return <section className="card"><Title eye="Open source Radar" title="Regenradar"/><div className="radarmap"><MapContainer center={[lat,lon]} zoom={7} className="leafletmap" scrollWheelZoom={false}><MoveMap lat={lat} lon={lon}/><TileLayer attribution='&copy; OpenStreetMap-Mitwirkende' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>{url&&<TileLayer attribution='Radar &copy; RainViewer' url={url} opacity={opacity/100}/>}<CircleMarker center={[lat,lon]} radius={7} pathOptions={{color:'#fff',weight:2,fillColor:'#1f8cff',fillOpacity:0.95}}><Popup>Gewählter Standort</Popup></CircleMarker></MapContainer><div className="radarlegend"><strong>Radarintensität</strong><small>OpenStreetMap als Basiskarte, RainViewer als frei verfügbare Radar-Ebene.</small><span className="scale"/></div></div><div className="radarcontrols"><button className="secondary" disabled={!frames||index<=0} onClick={()=>setIndex(i=>Math.max(0,i-1))}>◀</button><div className="range"><small>Zeitschritt</small><input type="range" min={0} max={Math.max(0,(frames?.items.length??1)-1)} value={index} onChange={e=>setIndex(Number(e.target.value))}/></div><time>{frame?new Date(frame.time*1000).toLocaleTimeString('de-DE',{hour:'2-digit',minute:'2-digit'}):'–:–'}</time><div className="range opacity"><small>Radar-Deckkraft</small><input type="range" min={25} max={100} value={opacity} onChange={e=>setOpacity(Number(e.target.value))}/></div></div><small className="source">Karte: OpenStreetMap · Radar: RainViewer</small></section>}


function dailyHazards(day:Day){
 const items:{label:string;level:'yellow'|'red'}[]=[];
 if(day.gust>=40)items.push({label:`Böen ${Math.round(day.gust)} kt`,level:day.gust>=55?'red':'yellow'});
 if(day.precipitation>=12||day.probability>=80)items.push({label:day.precipitation>=8?`${day.precipitation.toFixed(1)} mm`:`${Math.round(day.probability)} % Regen`,level:day.precipitation>=20?'red':'yellow'});
 if(day.max>=32)items.push({label:`Hitze ${Math.round(day.max)}°`,level:day.max>=37?'red':'yellow'});
 if([95,96,99].includes(day.code))items.push({label:'Gewitter',level:'red'});
 return items.slice(0,2);
}
function dirArrow(deg:number){const to=((deg+180)%360+360)%360;const arrows=['↑','↗','→','↘','↓','↙','←','↖'];return arrows[Math.round(to/45)%8]}
function Forecast({days,hours,selected,setSelected,unit}:{days:Day[];hours:Hour[];selected:string;setSelected:(x:string)=>void;unit:WindUnit}){
 const [selectedHour,setSelectedHour]=useState(0);
 const allMin=Math.min(...days.slice(0,7).map(x=>x.min)),allMax=Math.max(...days.slice(0,7).map(x=>x.max)),range=Math.max(1,allMax-allMin);
 const p=hours.filter(x=>x.time.startsWith(selected)).slice(0,24);
 useEffect(()=>{setSelectedHour(Math.min(6,Math.max(0,p.length-1)))},[selected]);
 if(!p.length)return null;
 const currentHour=p[Math.min(selectedHour,p.length-1)]??p[0];
 const tMin=Math.floor((Math.min(...p.map(x=>x.temperature))-2)/2)*2,tMax=Math.ceil((Math.max(...p.map(x=>x.temperature))+2)/2)*2,tempRange=Math.max(6,tMax-tMin);
 const rainMax=Math.max(1,...p.map(x=>x.precipitation));
 const W=180,H=112,left=11,right=4,plotW=W-left-right,tempTop=16,tempBottom=55,rainTop=68,rainBottom=90;
 const xAt=(i:number)=>left+(i/Math.max(1,p.length-1))*plotW;
 const yTemp=(v:number)=>tempBottom-((v-tMin)/tempRange)*(tempBottom-tempTop);
 const yRain=(v:number)=>rainBottom-(v/rainMax)*(rainBottom-rainTop);
 const tempPath=p.map((x,i)=>`${i?'L':'M'} ${xAt(i)} ${yTemp(x.temperature)}`).join(' ');
 const areaPath=`${tempPath} L ${xAt(p.length-1)} ${tempBottom} L ${xAt(0)} ${tempBottom} Z`;
 const iconIndices=[0,3,6,9,12,15,18,21,23].filter(i=>i<p.length);
 const timeIndices=[0,3,6,9,12,15,18,21,23].filter(i=>i<p.length);
 const maxIdx=p.reduce((b,x,i)=>x.temperature>p[b].temperature?i:b,0),minIdx=p.reduce((b,x,i)=>x.temperature<p[b].temperature?i:b,0);
 const totalRain=p.reduce((a,b)=>a+b.precipitation,0),maxProb=Math.max(...p.map(x=>x.probability)),gustMax=Math.max(...p.map(x=>x.gust)),windMax=Math.max(...p.map(x=>x.wind));
 const selectedDay=days.find(x=>x.date===selected)??days[0];
 return <section className="card"><Title eye="Best Match · seamless" title="7-Tage-Vorhersage"/>
   <div className="forecastrows">{days.slice(0,7).map(d=>{const dt=new Date(`${d.date}T12:00:00`);const leftPct=((d.min-allMin)/range)*100;const widthPct=(Math.max(1,d.max-d.min)/range)*100;const hz=dailyHazards(d);return <button className={`forecastrow ${selected===d.date?'active':''}`} key={d.date} onClick={()=>setSelected(d.date)}>
      <div className="forecast-date"><strong>{dt.toLocaleDateString('de-DE',{weekday:'short'})}</strong><small>{dt.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})}</small></div>
      <div className="forecast-icon"><span>{icon(d.code)}</span><small>{label(d.code)}</small></div>
      <div className="forecast-meta"><span>💧 {d.precipitation.toFixed(1)} mm · {Math.round(d.probability)} %</span><span>🌬️ {dirArrow(d.direction)} {wind(d.wind,unit)} · Böen {wind(d.gust,unit)}</span></div>
      <div className="forecast-barwrap"><b>{Math.round(d.min)}°</b><div className="forecast-barbg"><div className="forecast-bar" style={{left:`${leftPct}%`,width:`${Math.max(8,widthPct)}%`}}/></div><strong>{Math.round(d.max)}°</strong></div>
      <div className="forecast-hazards">{hz.length?hz.map((h,i)=><span key={i} className={h.level}>{h.label}</span>):<span className="none">keine markanten Hazards</span>}</div>
   </button>})}</div>
   <div className="hourdetail meteogram-day">
     <div className="detailhead"><strong>{new Date(`${selectedDay.date}T12:00:00`).toLocaleDateString('de-DE',{weekday:'long',day:'2-digit',month:'2-digit'})} · Detailansicht</strong><small>Stündliche Entwicklung mit Temperatur, Wetter, Niederschlag, Wind und Böen. Stunde antippen für Detailwerte.</small></div>
     <div className="quickfacts"><span>{icon(selectedDay.code)} <b>{label(selectedDay.code)}</b></span><span>Σ Niederschlag <b>{totalRain.toFixed(1)} mm</b></span><span>max. Regenrisiko <b>{Math.round(maxProb)} %</b></span><span>max. Wind / Böen <b>{wind(windMax,unit)} · {wind(gustMax,unit)}</b></span></div>
     <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" className="meteogramsvg">
       <defs><linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ff9b55" stopOpacity="0.42"/><stop offset="100%" stopColor="#ff9b55" stopOpacity="0.04"/></linearGradient><linearGradient id="rainFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4db8ff" stopOpacity="0.95"/><stop offset="100%" stopColor="#4db8ff" stopOpacity="0.35"/></linearGradient></defs>
       {[0,1,2,3,4].map(i=>{const y=tempTop+i*(tempBottom-tempTop)/4,val=(tMax-(tempRange/4)*i);return <g key={i}><line x1={left} x2={W-right} y1={y} y2={y} stroke="currentColor" opacity="0.12"/><text x="1.2" y={y+1.3} fontSize="3.2" fill="currentColor" opacity="0.8">{Math.round(val)}°C</text></g>})}
       {[0,1,2].map(i=>{const y=rainTop+i*(rainBottom-rainTop)/2,val=(rainMax/2)*(2-i);return <g key={i}><line x1={left} x2={W-right} y1={y} y2={y} stroke="currentColor" opacity="0.09"/><text x="1.2" y={y+1.2} fontSize="2.9" fill="currentColor" opacity="0.65">{val===0?0:val.toFixed(1)} mm</text></g>})}
       {timeIndices.map(i=><line key={i} x1={xAt(i)} x2={xAt(i)} y1={tempTop} y2={rainBottom} stroke="currentColor" opacity="0.08" strokeDasharray="2 2"/>)}
       {p.map((x,i)=>{const x0=xAt(i),w=Math.max(1.9,plotW/24-0.8);return <g key={x.time}><rect x={Math.max(left,x0-w/2)} y={yRain(x.precipitation)} width={w} height={Math.max(.5,rainBottom-yRain(x.precipitation))} rx="0.6" fill="url(#rainFill)" opacity={Math.max(.18,.32+x.probability/170)}/></g>})}
       <path d={areaPath} fill="url(#tempFill)"/>
       <path d={tempPath} fill="none" stroke="#ff7a37" strokeWidth="1.2" vectorEffect="non-scaling-stroke"/>
       {iconIndices.map(i=><g key={i}><text x={xAt(i)} y="10" textAnchor="middle" fontSize="4.0">{icon(p[i].code,p[i].isDay)}</text></g>)}
       {timeIndices.map(i=><g key={i}><text x={xAt(i)} y="96" textAnchor="middle" fontSize="3.1" fill="currentColor" opacity="0.86">{p[i].time.slice(11,13)} h</text></g>)}
       {[minIdx,maxIdx].map(i=><g key={i}><circle cx={xAt(i)} cy={yTemp(p[i].temperature)} r="1.15" fill="#fff" stroke="#ff7a37" strokeWidth="0.8"/><text x={xAt(i)} y={yTemp(p[i].temperature)-2.3} textAnchor="middle" fontSize="3.4" fill="#ffb37a">{Math.round(p[i].temperature)}°</text></g>)}
       <line x1={xAt(selectedHour)} x2={xAt(selectedHour)} y1={tempTop} y2={rainBottom} stroke="#9ad0ff" opacity="0.85" strokeWidth="0.8"/>
       <circle cx={xAt(selectedHour)} cy={yTemp(currentHour.temperature)} r="1.4" fill="#fff" stroke="#9ad0ff" strokeWidth="0.8"/>
     </svg>
     <div className="hour-pills">{p.map((x,i)=><button key={x.time} className={i===selectedHour?'active':''} onClick={()=>setSelectedHour(i)}><small>{x.time.slice(11,13)}:00</small><span>{icon(x.code,x.isDay)}</span><b>{Math.round(x.temperature)}°</b></button>)}</div>
     <div className="hour-inspector">
        <div><small>Stunde</small><strong>{currentHour.time.slice(11,16)} Uhr</strong></div>
        <div><small>Wetter</small><strong>{icon(currentHour.code,currentHour.isDay)} {label(currentHour.code)}</strong></div>
        <div><small>Temperatur</small><strong>{Math.round(currentHour.temperature)} °C</strong></div>
        <div><small>Gefühlt</small><strong>{Math.round(currentHour.apparent)} °C</strong></div>
        <div><small>Niederschlag</small><strong>{currentHour.precipitation.toFixed(1)} mm · {Math.round(currentHour.probability)} %</strong></div>
        <div><small>Wind / Böen</small><strong>{dirArrow(currentHour.direction)} {wind(currentHour.wind,unit)} · {wind(currentHour.gust,unit)}</strong></div>
        <div><small>Feuchte / Taupunkt</small><strong>{Math.round(currentHour.humidity)} % · {Math.round(currentHour.dewPoint)} °C</strong></div>
        <div><small>Bewölkung</small><strong>{Math.round(currentHour.cloud)} %</strong></div>
     </div>
   </div>
 </section>}

function niceRainScale(maxValue:number){
 const raw=Math.max(1,maxValue),steps=[1,2,5,10,20,50],target=raw/4;
 const step=steps.find(x=>x>=target)??Math.ceil(target/10)*10;
 const max=Math.ceil(raw/step)*step;
 return{max,ticks:Array.from({length:max/step+1},(_,i)=>i*step)};
}
function clamp(v:number,min:number,max:number){return Math.min(max,Math.max(min,v))}
function confidenceColor(v:number){if(v>=85)return'#45c86b';if(v>=70)return'#92cc45';if(v>=55)return'#f2c94c';if(v>=40)return'#f2994a';return'#eb5757'}
function TrendTooltip({active,payload,label}:{active?:boolean;payload?:any[];label?:string}){if(!active||!payload?.length)return null;const row=payload[0]?.payload;return <div className="charttooltip"><strong>{label}</strong><span>Best Match: {row.bestMin?.toFixed(1)??'–'} bis {row.bestMax?.toFixed(1)??'–'} °C</span><span>ENS-Mittel: {row.minMean.toFixed(1)} bis {row.maxMean.toFixed(1)} °C</span><span>P10–P90 Tmin: {row.minLow.toFixed(1)} bis {row.minHigh.toFixed(1)} °C</span><span>P10–P90 Tmax: {row.maxLow.toFixed(1)} bis {row.maxHigh.toFixed(1)} °C</span><span>Niederschlag: {row.precipitationMean.toFixed(1)} mm (Spanne {row.precipitationLow.toFixed(1)}–{row.precipitationHigh.toFixed(1)} mm)</span><span>Modellübereinstimmung: {Math.round(row.confidence)} % ({row.modelCount} Modelle · {row.memberCount} Mitglieder)</span></div>}
function CombinedTrendChart({data}:{data:any[]}){const vals=data.flatMap(r=>[r.maxLow,r.maxHigh,r.minLow,r.minHigh,r.bestMax,r.bestMin]).filter((v:number)=>Number.isFinite(v));const minV=Math.floor((Math.min(...vals)-2)/2)*2,maxV=Math.ceil((Math.max(...vals)+2)/2)*2;const ticks=[] as number[];for(let v=minV;v<=maxV;v+=2)ticks.push(v);return <div className="chart trend-combined"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={data} margin={{top:14,right:18,left:10,bottom:34}}><CartesianGrid strokeDasharray="3 3" opacity={.22}/><XAxis dataKey="label" tick={{fontSize:11}} interval={0} label={{value:'Vorhersagetag',position:'insideBottom',offset:-22}}/><YAxis yAxisId="t" domain={[minV,maxV]} ticks={ticks} tick={{fontSize:11}} width={66} tickFormatter={(v)=>`${v}°C`} label={{value:'Temperatur (°C)',angle:-90,position:'insideLeft',offset:4}}/><Tooltip content={<TrendTooltip/>}/><Legend verticalAlign="top" height={42} formatter={(v)=>({maxBand:'ENS-Spanne Tmax',minBand:'ENS-Spanne Tmin',bestMax:'Best Match Tmax',bestMin:'Best Match Tmin',maxMean:'ENS-Mittel Tmax',minMean:'ENS-Mittel Tmin'} as any)[String(v)]??String(v)}/><Area yAxisId="t" stackId="max" type="monotone" dataKey="maxLow" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="max" type="monotone" dataKey="maxBand" name="maxBand" stroke="none" fill="#ff845f" fillOpacity={0.22}/><Area yAxisId="t" stackId="min" type="monotone" dataKey="minLow" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="min" type="monotone" dataKey="minBand" name="minBand" stroke="none" fill="#53a9ff" fillOpacity={0.22}/><Line yAxisId="t" type="monotone" dataKey="maxMean" name="maxMean" stroke="#ffb07b" strokeWidth={1.7} strokeDasharray="5 4" dot={false}/><Line yAxisId="t" type="monotone" dataKey="minMean" name="minMean" stroke="#92cfff" strokeWidth={1.7} strokeDasharray="5 4" dot={false}/><Line yAxisId="t" type="monotone" dataKey="bestMax" name="bestMax" stroke="#ff6a37" strokeWidth={3.1} dot={{r:2.4}} connectNulls/><Line yAxisId="t" type="monotone" dataKey="bestMin" name="bestMin" stroke="#248dff" strokeWidth={3.1} dot={{r:2.4}} connectNulls/></ComposedChart></ResponsiveContainer></div>}
function Ensembles({data,models,days}:{data:EnsembleDay[];models:string[];days:Day[]}){
 const best=new Map(days.map(x=>[x.date,x]));
 const overlap=data.filter(x=>best.has(x.date)).slice(0,14);
 const maxModels=Math.max(1,models.length);
 const d=overlap.map((x,index)=>{
  const day=best.get(x.date);
  const bestMax=Number.isFinite(day?.max)?day!.max:x.maxMean, bestMin=Number.isFinite(day?.min)?day!.min:x.minMean;
  const maxLow=x.maxLow,maxHigh=x.maxHigh,minLow=x.minLow,minHigh=x.minHigh;
  const combinedSpread=Math.max(0,((maxHigh-maxLow)+(minHigh-minLow))/2);
  const scoreSpread=clamp(100-combinedSpread*7.5,28,96);
  const scoreLead=clamp(100-index*3.8,46,100);
  const scoreModels=clamp(60+(x.modelCount/maxModels)*40,60,100);
  const confidence=Math.round(clamp(scoreSpread*0.46+scoreLead*0.24+scoreModels*0.30,28,96));
  return{
   ...x,
   label:new Date(`${x.date}T12:00:00`).toLocaleDateString('de-DE',{weekday:'short',day:'2-digit'}),
   weekday:new Date(`${x.date}T12:00:00`).toLocaleDateString('de-DE',{weekday:'short'}),
   dayLabel:new Date(`${x.date}T12:00:00`).toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'}),
   bestMax,bestMin,code:day?.code??3,maxLow,maxHigh,minLow,minHigh,
   maxBand:Math.max(0.2,maxHigh-maxLow),minBand:Math.max(0.2,minHigh-minLow),confidence
  }
 });
 if(!d.length)return <section className="card ensemble"><Title eye="ENS-Daten werden validiert" title="14-Tage-Ensemble-Trend"/><p className="emptyhint">Für den gewählten Ort liegen momentan keine ausreichend konsistenten Ensemble-Daten vor.</p></section>;
 const rainScale=niceRainScale(Math.max(...d.map(x=>x.precipitationHigh),1));
 const overallMin=Math.floor((Math.min(...d.map(x=>Math.min(x.minLow,x.bestMin)))-2)/2)*2;
 const overallMax=Math.ceil((Math.max(...d.map(x=>Math.max(x.maxHigh,x.bestMax)))+2)/2)*2;
 const range=Math.max(1,overallMax-overallMin);
 const summaryMembers=Math.round(d.reduce((s,x)=>s+x.memberCount,0)/d.length);
 return <section className="card ensemble"><Title eye={`${models.length} verfügbare ENS-Modelle`} title="14-Tage-Ensemble-Trend"/>
   <div className="chips">{models.map(x=><span key={x}>{x.replaceAll('_ensemble_mean','').replaceAll('_',' ')}</span>)}</div>
   <div className="charthead"><h3>14-Tage-Ensemble-Übersicht</h3><p>Best Match, gewichtete Ensemble-Spanne und Prognosekonsistenz pro Tag.</p></div>
   <div className="ens-summary"><span><b>{summaryMembers}</b> Mitgliedersignale pro Tag im Mittel</span><span><b>{models.length}</b> Modellfamilien aktiv</span><span><i className="dot demo" style={{background:'#45c86b'}}/> hohe Konsistenz</span><span><i className="dot demo" style={{background:'#f2c94c'}}/> mittlere Konsistenz</span><span><i className="dot demo" style={{background:'#eb5757'}}/> geringe Konsistenz</span></div>
   <div className="ens-overview-grid">{d.map(x=>{
      const ensLeft=((x.minLow-overallMin)/range)*100,ensWidth=((x.maxHigh-x.minLow)/range)*100,bestLeft=((x.bestMin-overallMin)/range)*100,bestWidth=((x.bestMax-x.bestMin)/range)*100;
      return <article key={x.date} className="ens-card" title={`Modellkonsistenz ${Math.round(x.confidence)} % · ${x.modelCount} Modelle · ${x.memberCount} Mitglieder`}><header><div><strong>{x.weekday}</strong><small>{x.dayLabel}</small></div><span className="dot" style={{background:confidenceColor(x.confidence)}}/></header><div className="wx">{icon(x.code,true)}</div><div className="barzone"><div className="barbg"><div className="ensspread" style={{left:`${Math.max(0,ensLeft)}%`,width:`${Math.max(6,ensWidth)}%`}}/><div className="bestrange" style={{left:`${Math.max(0,bestLeft)}%`,width:`${Math.max(8,bestWidth)}%`}}/></div></div><div className="temps"><b>{Math.round(x.bestMin)}°</b><strong>{Math.round(x.bestMax)}°</strong></div><small>{label(x.code)}</small></article>
   })}</div>
   <div className="enslegend"><span><i className="swatch ensemble"/> Ensemble-Spanne P10–P90</span><span><i className="swatch best"/> Best-Match Min–Max</span></div>
   <div className="charthead"><h3>Temperaturtrend und Prognoseunsicherheit</h3><p>Best Match als Referenz, dazu die gewichteten P10–P90-Intervalle der verfügbaren Ensemble-Mitglieder.</p></div>
   <CombinedTrendChart data={d}/>
   <div className="charthead"><h3>Niederschlag</h3><p>Tägliches ENS-Modellmittel und zentrales Modellintervall mit gerader Achsenskalierung.</p></div>
   <div className="chart rain"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={d} margin={{top:16,right:28,left:12,bottom:36}}><CartesianGrid strokeDasharray="3 3" opacity={.22}/><XAxis dataKey="label" tick={{fontSize:11}} interval={0} label={{value:'Vorhersagetag',position:'insideBottom',offset:-24}}/><YAxis domain={[0,rainScale.max]} ticks={rainScale.ticks} tick={{fontSize:11}} width={68} tickFormatter={(v)=>`${v} mm`} label={{value:'Niederschlag (mm)',angle:-90,position:'insideLeft',offset:4}}/><Tooltip formatter={(v:number,n:string)=>[`${Number(v).toFixed(1)} mm`,n==='precipitationMean'?'ENS-Modellmittel':n==='precipitationLow'?'Untere Modellgrenze':'Obere Modellgrenze']}/><Legend verticalAlign="top" height={38} formatter={(v)=>v==='precipitationMean'?'ENS-Modellmittel':v==='precipitationLow'?'Untere Modellgrenze':'Obere Modellgrenze'}/><Bar dataKey="precipitationMean" name="precipitationMean" fill="#2688ff" radius={[5,5,0,0]}/><Line type="monotone" dataKey="precipitationLow" name="precipitationLow" stroke="#7d8aa0" strokeWidth={1.5} strokeDasharray="4 4" dot={false}/><Line type="monotone" dataKey="precipitationHigh" name="precipitationHigh" stroke="#c4d0df" strokeWidth={2.2} dot={{r:2}}/></ComposedChart></ResponsiveContainer></div></section>
}


function Widget({loc,days,unit}:{loc:Location;days:Day[];unit:WindUnit}){const[n,setN]=useState(4),[dark,setDark]=useState(false),[showWind,setShowWind]=useState(true),[showRain,setShowRain]=useState(true),ref=useRef<HTMLDivElement>(null);async function png(){if(!ref.current)return;const u=await toPng(ref.current,{pixelRatio:2,cacheBust:true,backgroundColor:dark?'#07111f':'#fff'}),a=document.createElement('a');a.download=`wetter-widget-${loc.name.toLowerCase().replace(/[^a-z0-9]+/gi,'-')}.png`;a.href=u;a.click()}return <section className="card widget"><Title eye="Konfigurierbar und exportierbar" title="Widget-Generator"/><div className="widgetlayout"><aside><label>Tage<select value={n} onChange={e=>setN(Number(e.target.value))}>{[3,4,5,6,7].map(x=><option key={x}>{x}</option>)}</select></label><label><input type="checkbox" checked={dark} onChange={e=>setDark(e.target.checked)}/>Dunkles Widget</label><label><input type="checkbox" checked={showWind} onChange={e=>setShowWind(e.target.checked)}/>Wind</label><label><input type="checkbox" checked={showRain} onChange={e=>setShowRain(e.target.checked)}/>Niederschlag</label><button className="primary" onClick={png}><Download size={17}/>PNG erstellen</button></aside><div className="preview"><div ref={ref} className={`weatherwidget ${dark?'dark':''}`}><header><strong>{loc.name}</strong><small>{loc.latitude.toFixed(2)}°N, {loc.longitude.toFixed(2)}°E · {Math.round(loc.elevation??0)} m ü. NHN</small></header><div style={{gridTemplateColumns:`repeat(${n},minmax(0,1fr))`}}>{days.slice(0,n).map(d=>{const dt=new Date(`${d.date}T12:00:00`);return <article key={d.date}><b>{dt.toLocaleDateString('de-DE',{weekday:'short'})}</b><small>{dt.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit'})}</small><i>{icon(d.code)}</i><strong>{Math.round(d.max)}°</strong><em>{Math.round(d.min)}°</em>{showWind&&<span>{wind(d.wind,unit)}</span>}{showRain&&<span>💧 {d.precipitation.toFixed(1)} mm</span>}<span>{Math.round(d.probability)} %</span></article>})}</div></div></div></div></section>}
function Title({eye,title}:{eye:string;title:string}){return <header className="title"><div><span>{eye}</span><h2>{title}</h2></div></header>}
