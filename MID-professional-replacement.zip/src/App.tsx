import {useEffect,useMemo,useRef,useState,type KeyboardEvent as ReactKeyboardEvent,type ReactNode} from 'react';
import {AlertTriangle,BadgeCheck,Cloud,Download,Droplets,Gauge,LocateFixed,Moon,Navigation,Pause,Play,RefreshCw,Search,Settings2,SkipBack,SkipForward,Star,Sun,ThermometerSun,Umbrella,Wind,X} from 'lucide-react';
import {Area,AreaChart,Bar,CartesianGrid,ComposedChart,Legend,Line,ResponsiveContainer,Tooltip,XAxis,YAxis} from 'recharts';
import {CircleMarker,MapContainer,Popup,TileLayer,WMSTileLayer,useMap} from 'react-leaflet';
import {toPng} from 'html-to-image';
import {airQuality,bestMatchModelInfo,climatology,cloudOktas,countryCodeFromLocation,cloudOktasText,currentIndex,dayEffectiveUvMax,dayWeatherCharacter,ensembles,forecast,hazards,icon,label,mapDays,mapHours,mapMinutely15,officialWarnings,radarNowcast,searchLocations,reverseLocation,station,wind,type BestMatchModelInfo,type ClimateDay,type Day,type EnsembleDay,type Hour,type Location,type Minute15,type ModelRunMeta,type OfficialAlert,type RadarNowcast,type Station,type Weather,type WindUnit} from './weather';

const VERSION='0.7.14';
const LOGO_PATH='./mid-logo.png';
const LOCATION_STORAGE_KEY='mid:lastLocation';
const FAVORITES_STORAGE_KEY='mid:favorites';
const THEME_STORAGE_KEY='theme';
function normalizeLocation(loc:Location):Location{const country_code=countryCodeFromLocation(loc.country_code)||countryCodeFromLocation(loc.country)||undefined;return{...loc,country_code}}
function storedLocation():Location|null{try{const raw=localStorage.getItem(LOCATION_STORAGE_KEY);if(!raw)return null;const loc=JSON.parse(raw) as Location;if(!Number.isFinite(loc.latitude)||!Number.isFinite(loc.longitude))return null;const normalized=normalizeLocation(loc);localStorage.setItem(LOCATION_STORAGE_KEY,JSON.stringify(normalized));return normalized}catch{return null}}
function favoriteKey(loc:Location){return`${Number(loc.latitude).toFixed(5)}:${Number(loc.longitude).toFixed(5)}`}
function storedFavorites():Location[]{try{const raw=localStorage.getItem(FAVORITES_STORAGE_KEY);if(!raw)return[];const values=JSON.parse(raw) as Location[],seen=new Set<string>();return(Array.isArray(values)?values:[]).filter(x=>Number.isFinite(x?.latitude)&&Number.isFinite(x?.longitude)).map(normalizeLocation).filter(x=>{const key=favoriteKey(x);if(seen.has(key))return false;seen.add(key);return true}).slice(0,20)}catch{return[]}}
function initialDarkTheme(){try{const stored=localStorage.getItem(THEME_STORAGE_KEY);if(stored==='dark')return true;if(stored==='light')return false;return window.matchMedia?.('(prefers-color-scheme: dark)').matches??false}catch{return false}}

function dateOnlyUtc(value:string){const match=String(value||'').match(/^(\d{4})-(\d{2})-(\d{2})$/);return match?new Date(Date.UTC(Number(match[1]),Number(match[2])-1,Number(match[3]),12)):new Date(Number.NaN)}
function formatDateOnly(value:string,options:Intl.DateTimeFormatOptions){const date=dateOnlyUtc(value);return Number.isFinite(date.getTime())?new Intl.DateTimeFormat('de-DE',{...options,timeZone:'UTC'}).format(date):value}
function formatInZone(value:Date|number,timeZone:string|undefined,options:Intl.DateTimeFormatOptions){const date=typeof value==='number'?new Date(value):value;try{return new Intl.DateTimeFormat('de-DE',{...options,timeZone:timeZone||undefined}).format(date)}catch{return new Intl.DateTimeFormat('de-DE',options).format(date)}}
function localDateInZone(timeZone?:string){try{const parts=new Intl.DateTimeFormat('en-CA',{timeZone:timeZone||undefined,year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date()),get=(type:string)=>parts.find(x=>x.type===type)?.value;return`${get('year')}-${get('month')}-${get('day')}`}catch{return new Date().toISOString().slice(0,10)}}
function zoneCaption(timeZone?:string,abbreviation?:string){return abbreviation?`${abbreviation} · ${timeZone||'Ortszeit'}`:timeZone||'Ortszeit'}

type RadarFrame={time:number;path?:string;future?:boolean};
type Radar={host:string;radar:{past:RadarFrame[];nowcast?:RadarFrame[]}};

export default function App(){
 const[loc,setLocState]=useState<Location|null>(()=>storedLocation()),[w,setW]=useState<Weather|null>(null),[air,setAir]=useState<any>(null),[bestMatchInfo,setBestMatchInfo]=useState<BestMatchModelInfo|null>(null),[ens,setEns]=useState<EnsembleDay[]>([]),[models,setModels]=useState<string[]>([]),[ensembleRuns,setEnsembleRuns]=useState<ModelRunMeta[]>([]),[climate,setClimate]=useState<ClimateDay[]>([]),[climateLoading,setClimateLoading]=useState(false),[climateError,setClimateError]=useState(''),[ensLoading,setEnsLoading]=useState(false),[ensError,setEnsError]=useState(''),[st,setSt]=useState<Station|null>(null),[stationLoading,setStationLoading]=useState(false),[official,setOfficial]=useState<OfficialAlert[]>([]),[officialLoading,setOfficialLoading]=useState(false),[officialError,setOfficialError]=useState(''),[officialProvider,setOfficialProvider]=useState(''),[radarAnalysis,setRadarAnalysis]=useState<RadarNowcast|null>(null),[radarAnalysisLoading,setRadarAnalysisLoading]=useState(false),[radarAnalysisError,setRadarAnalysisError]=useState(''),[loading,setLoading]=useState(false),[error,setError]=useState(''),[dark,setDark]=useState(initialDarkTheme),[unit,setUnit]=useState<WindUnit>(()=>(localStorage.getItem('windUnit') as WindUnit)||'kn'),[selected,setSelected]=useState('');
 const[favorites,setFavorites]=useState<Location[]>(storedFavorites);
 const seq=useRef(0);
 useEffect(()=>{document.documentElement.dataset.theme=dark?'dark':'light';document.querySelector<HTMLMetaElement>('meta[name=\"theme-color\"]')?.setAttribute('content',dark?'#07111f':'#edf3f8');localStorage.setItem(THEME_STORAGE_KEY,dark?'dark':'light')},[dark]);
 useEffect(()=>localStorage.setItem('windUnit',unit),[unit]);
 useEffect(()=>localStorage.setItem(FAVORITES_STORAGE_KEY,JSON.stringify(favorites)),[favorites]);
 useEffect(()=>{document.title='MID - Meteorological Information Dashboard'},[]);
 function setLoc(next:Location){const normalized=normalizeLocation(next);localStorage.setItem(LOCATION_STORAGE_KEY,JSON.stringify(normalized));setLocState(normalized);setW(null);setAir(null);setBestMatchInfo(null);setEns([]);setModels([]);setEnsembleRuns([]);setClimate([]);setClimateError('');setOfficial([]);setOfficialError('');setOfficialProvider('');setRadarAnalysis(null);setRadarAnalysisError('');setSelected('')}
 function toggleFavorite(target:Location){const normalized=normalizeLocation(target),key=favoriteKey(normalized);setFavorites(current=>current.some(x=>favoriteKey(x)===key)?current.filter(x=>favoriteKey(x)!==key):[normalized,...current].slice(0,20))}
 async function load(){if(!loc)return;const id=++seq.current,c=new AbortController();setLoading(true);setError('');setEnsLoading(true);setEnsError('');setEns([]);setModels([]);setEnsembleRuns([]);setBestMatchInfo(null);setClimate([]);setClimateError('');setClimateLoading(true);setSt(null);setStationLoading(true);setOfficial([]);setOfficialError('');setOfficialProvider('');setOfficialLoading(true);setRadarAnalysis(null);setRadarAnalysisError('');setRadarAnalysisLoading(true);radarNowcast(loc.latitude,loc.longitude,loc.country_code||loc.country,c.signal).then(x=>{if(id===seq.current)setRadarAnalysis(x)}).catch(e=>{if(id===seq.current)setRadarAnalysisError(e instanceof Error?e.message:'Radarauswertung nicht verfügbar.')} ).finally(()=>id===seq.current&&setRadarAnalysisLoading(false));officialWarnings(loc.latitude,loc.longitude,loc.country_code||loc.country,loc.name,loc.admin1,loc.admin2,c.signal).then(x=>{if(id===seq.current){setOfficial(x.alerts);setOfficialProvider(x.provider||x.coverage||'CAP')}}).catch(e=>{if(id===seq.current)setOfficialError(e instanceof Error?e.message:'Amtliche Warnungen konnten nicht geladen werden.')} ).finally(()=>id===seq.current&&setOfficialLoading(false));try{const[fw,aq]=await Promise.all([forecast(loc.latitude,loc.longitude,c.signal),airQuality(loc.latitude,loc.longitude,c.signal).catch(()=>null)]);if(id!==seq.current)return;setW(fw);setAir(aq);const resolvedLocation={...loc,timezone:fw.timezone,elevation:Number.isFinite(loc.elevation)?loc.elevation:fw.elevation};localStorage.setItem(LOCATION_STORAGE_KEY,JSON.stringify(resolvedLocation));setLocState(current=>current&&current.id===loc.id?resolvedLocation:current);setSelected(String(fw.daily.time[0]));setLoading(false);bestMatchModelInfo(loc.latitude,loc.longitude,loc.country_code||loc.country,c.signal).then(x=>{if(id===seq.current)setBestMatchInfo(x)}).catch(()=>{if(id===seq.current)setBestMatchInfo(null)});station(loc.latitude,loc.longitude,loc.country_code||loc.country,loc.elevation??fw.elevation,c.signal).then(x=>id===seq.current&&setSt(x)).finally(()=>id===seq.current&&setStationLoading(false));climatology(loc.latitude,loc.longitude,loc.elevation??fw.elevation,(fw.daily.time as string[]).slice(0,14),c.signal).then(x=>{if(id===seq.current)setClimate(x)}).catch(e=>{if(id===seq.current)setClimateError(e instanceof Error?e.message:'Klimatologisches Mittel konnte nicht geladen werden.')} ).finally(()=>id===seq.current&&setClimateLoading(false));ensembles(loc.latitude,loc.longitude,c.signal).then(x=>{if(id===seq.current){setEns(x.days);setModels(x.models);setEnsembleRuns(x.runs??[]);setEnsError(x.days.length?'':'Keine ausreichend vollständigen Ensemble-Daten erhalten.')}}).catch(e=>{if(id===seq.current){setEns([]);setModels([]);setEnsembleRuns([]);setEnsError(e instanceof Error?e.message:'Ensemble-Daten konnten nicht geladen werden.')}}).finally(()=>id===seq.current&&setEnsLoading(false))}catch(e){if(id===seq.current){setLoading(false);setEnsLoading(false);setClimateLoading(false);setStationLoading(false);setError(e instanceof Error?e.message:'Laden fehlgeschlagen')}}}
 useEffect(()=>{if(loc)void load()},[loc?.id,loc?.latitude,loc?.longitude]);
 function locate(){if(!navigator.geolocation){setError('Standortermittlung nicht unterstützt.');return}setLoading(true);setError('');navigator.geolocation.getCurrentPosition(async p=>{try{const resolved=await reverseLocation(p.coords.latitude,p.coords.longitude,p.coords.altitude??undefined);setLoc(resolved)}catch{setLoc({id:Date.now(),name:`${p.coords.latitude.toFixed(2)}°, ${p.coords.longitude.toFixed(2)}°`,latitude:p.coords.latitude,longitude:p.coords.longitude,elevation:p.coords.altitude??undefined,autolocated:true})}},()=>{setLoading(false);setError('Standort konnte nicht ermittelt werden.')},{enableHighAccuracy:true,timeout:15000,maximumAge:300000})}
 const hours=useMemo(()=>w?mapHours(w):[],[w]),minutes15=useMemo(()=>w?mapMinutely15(w):[],[w]),days=useMemo(()=>w?mapDays(w):[],[w]),hz=useMemo(()=>hazards(hours,hours[currentIndex(hours)]?.uvIndex),[hours]),precipModel=useMemo(()=>precipitationNowSummary(minutes15,hours,w?.timezone),[minutes15,hours,w?.timezone]),precipNow=useMemo(()=>combineRadarAndModel(precipModel,radarAnalysis,radarAnalysisLoading,radarAnalysisError,w?.timezone),[precipModel,radarAnalysis,radarAnalysisLoading,radarAnalysisError,w?.timezone]),risk=precipNow.probability??hours[currentIndex(hours)]?.probability??0,locationIsFavorite=!!loc&&favorites.some(x=>favoriteKey(x)===favoriteKey(loc));
 return <div className="app"><Header setLoc={setLoc} favorites={favorites} locate={locate} loading={loading} dark={dark} setDark={setDark} unit={unit} setUnit={setUnit} reload={load} hasLocation={!!loc}/><main>{!loc?<section className="empty-start"><Search size={30}/><div><strong>Ort oder Standort auswählen</strong><span>Beim ersten Aufruf bleibt MID leer. Der zuletzt gewählte Ort wird anschließend lokal gespeichert und beim nächsten Besuch automatisch geladen.</span></div></section>:<><section className="place"><div><span>{loc.autolocated?'Automatisch lokalisiert · ':''}{loc.admin1??loc.country??'Standort'}</span><div className="place-title-row"><h1>{loc.name}</h1><button className={`favorite-toggle${locationIsFavorite?' active':''}`} onClick={()=>toggleFavorite(loc)} title={locationIsFavorite?'Aus Favoriten entfernen':'Zu Favoriten hinzufügen'} aria-label={locationIsFavorite?'Aus Favoriten entfernen':'Zu Favoriten hinzufügen'} aria-pressed={locationIsFavorite}><Star size={21} fill={locationIsFavorite?'currentColor':'none'}/></button></div><p>{loc.latitude.toFixed(2)}°N, {loc.longitude.toFixed(2)}°E · {Math.round(loc.elevation??w?.elevation??0)} m ü. NHN{w?.timezone&&<> · Ortszeit <span className="local-timezone">{w.timezone_abbreviation||w.timezone}</span></>}{loc.autolocated?' · Ortsname aus Geodatenbank':''}</p></div><aside className="precip-now"><small>Aktuelle Niederschlagswahrscheinlichkeit</small><strong>{Math.round(risk)} %</strong><span>{precipNow.summary}</span><em>{precipNow.source}</em></aside></section>{error&&<div className="error">{error}</div>}{loading&&!w?<div className="loading"><RefreshCw className="spin"/><strong>Wettermodelle werden geladen …</strong><span>Best Match, Luftqualität und Ensembles</span></div>:w&&<><Current loc={loc} w={w} air={air} st={st} stationLoading={stationLoading} unit={unit}/><Hazards data={hz}/><OfficialWarnings alerts={official} loading={officialLoading} error={officialError} provider={officialProvider} timezone={w.timezone}/><div className="split"><Forecast days={days} hours={hours} selected={selected} setSelected={setSelected} unit={unit} modelInfo={bestMatchInfo} timezone={w.timezone} timezoneAbbreviation={w.timezone_abbreviation}/><Radar lat={loc.latitude} lon={loc.longitude} timezone={w.timezone} analysis={radarAnalysis}/></div><Ensembles data={ens} models={models} runs={ensembleRuns} days={days} climate={climate} climateLoading={climateLoading} climateError={climateError} loading={ensLoading} error={ensError}/><Widget loc={loc} days={days} hours={hours} unit={unit} elevation={loc.elevation??w.elevation} timezone={w.timezone} timezoneAbbreviation={w.timezone_abbreviation}/></>}</>}</main><footer><span>MID v{VERSION} · <a href="https://github.com/MeteoMartini/MID/blob/main/CHANGELOG.md" target="_blank" rel="noreferrer">Changelog</a></span><span>Aktualisiert: {new Date().toLocaleString('de-DE',{day:'2-digit',month:'2-digit',year:'numeric',hour:'2-digit',minute:'2-digit',second:'2-digit'})}</span><small className="data-disclaimer">Datenquellen: Open-Meteo (Vorhersage, Luftqualität, Orts-/PLZ-Geocoding und ERA5-Land-Klimatologie 1991–2020), OpenStreetMap/Photon (POI-Suche), GeoSphere Austria/TAWES, Bright Sky/DWD-WMO, NOAA AviationWeather/METAR sowie optional qualitätsgeprüfte Messpunkte von Weather Underground, Netatmo Weathermap, Synoptic Data/MesoWest-MADIS und Xweather über jeweils autorisierte API-Zugänge. Hyperlokale Messwerte werden höhen-, entfernungs- und aktualitätsgewichtet sowie robust gegen Ausreißer gemittelt. Amtliche Warnungen: DWD-WFS auf Gemeindeebene mit DWD-CAP-Fallback für Deutschland, MeteoAlarm-Atom/CAP der nationalen europäischen Wetterdienste und NOAA/NWS für die USA. Radar/Nowcast: Deutscher Wetterdienst (DWD-RV), EUMETNET OPERA/ORD (CC BY 4.0) sowie RainViewer-Fallback; Kartenbasis: OpenStreetMap; Reverse-Geocoding: BigDataCloud. Automatische Hazards und Radardarstellungen sind keine amtlichen Warnungen.</small></footer></div>
}

function Header({setLoc,favorites,locate,loading,dark,setDark,unit,setUnit,reload,hasLocation}:{setLoc:(x:Location)=>void;favorites:Location[];locate:()=>void;loading:boolean;dark:boolean;setDark:(x:boolean)=>void;unit:WindUnit;setUnit:(x:WindUnit)=>void;reload:()=>void;hasLocation:boolean}){
 const[q,setQ]=useState(''),[results,setResults]=useState<Location[]>([]),[open,setOpen]=useState(false),term=q.trim();
 useEffect(()=>{if(term.length<2){setResults([]);if(term.length>0)setOpen(false);return}const c=new AbortController(),t=setTimeout(()=>searchLocations(term,c.signal).then(x=>{setResults(x);setOpen(true)}).catch(()=>{setResults([]);setOpen(false)}),420);return()=>{clearTimeout(t);c.abort()}},[term]);
 const visibleResults=term.length>=2?results:term.length===0?favorites:[],favoritesMode=term.length===0&&favorites.length>0;
 const choose=(location:Location)=>{setLoc(location);setQ('');setOpen(false)};
 return <header className="top"><div className="brand"><img src={LOGO_PATH} alt="MID Logo" className="brand-logo"/><span><strong><small className="brand-version">v{VERSION}</small></strong><small>Meteorological Information Dashboard</small></span></div><div className="search"><div><Search size={18}/><input value={q} onFocus={()=>visibleResults.length&&setOpen(true)} onChange={e=>{const next=e.target.value;setQ(next);if(next.trim()==='')setOpen(favorites.length>0)}} placeholder="Ort, PLZ, POI oder Koordinaten suchen" aria-label="Ort oder Favorit suchen"/>{q&&<button onClick={()=>{setQ('');setOpen(favorites.length>0)}} title="Suche leeren" aria-label="Suche leeren"><X size={16}/></button>}</div><button className="secondary locate" onClick={locate} title="Standort automatisch bestimmen" aria-label="Standort automatisch bestimmen"><LocateFixed size={17}/><span>Standort</span></button>{open&&visibleResults.length>0&&<section>{favoritesMode&&<div className="search-section-label"><Star size={13} fill="currentColor"/>Favoriten</div>}{visibleResults.map(r=><button key={`${r.id}:${favoriteKey(r)}`} onClick={()=>choose(r)}><strong>{favoritesMode&&<Star className="favorite-result-star" size={13} fill="currentColor"/>}{r.name}{r.postcodes?.[0]?` ${r.postcodes[0]}`:''}{r.poiCategory&&r.poiCategory!=='Ort'&&<em className="poi-kind">{r.poiCategory}</em>}</strong><small>{[r.admin2,r.admin1,r.country].filter((value,index,array)=>value&&array.indexOf(value)===index).join(', ')}{Number.isFinite(r.elevation)?` · ${Math.round(r.elevation!)} m`:''}{r.source==='OpenStreetMap/Photon'?' · OpenStreetMap':''}</small></button>)}</section>}</div><div className="actions"><label><Settings2 size={15}/><select value={unit} onChange={e=>setUnit(e.target.value as WindUnit)}><option value="kn">kt</option><option value="kmh">km/h</option><option value="ms">m/s</option><option value="mph">mph</option></select></label><button className="theme-toggle" title={dark?'Helles Layout':'Dunkles Layout'} aria-label={dark?'Helles Layout':'Dunkles Layout'} onClick={()=>setDark(!dark)}>{dark?<Sun size={19}/>:<Moon size={19}/>}<span>{dark?'Hell':'Dunkel'}</span></button><button className="reload-button" title="Wetterdaten neu laden" aria-label="Wetterdaten neu laden" onClick={reload} disabled={loading||!hasLocation}><RefreshCw size={19} className={loading?'spin':''}/></button></div></header>
}

function Current({loc,w,air,st,stationLoading,unit}:{loc:Location;w:Weather;air:any;st:Station|null;stationLoading:boolean;unit:WindUnit}){
 const c=w.current,fresh=!!st&&(!st.timestamp||Date.now()-new Date(st.timestamp).getTime()<150*60000),providerSummary=st?.sourceProviders?.slice(0,3).map(x=>x.replace(/ \(.*?\)$/,'')).join(', '),stationInfo=fresh?(st!.blended?`${st!.stationCount??2} geeignete Messstationen · ${providerSummary||'mehrere Netze'} · mittlere Entfernung ${Number.isFinite(st!.distance)?`${(st!.distance!/1000).toFixed(1).replace('.',',')} km`:'unbekannt'}${Number.isFinite(st!.temperatureSpread)?` · Temperaturstreuung ${st!.temperatureSpread!.toFixed(1).replace('.',',')} °C`:''}`:`${st!.provider??'WMO/METAR'} · ${st!.name} · ${Number.isFinite(st!.height)?`${Math.round(st!.height!)} m`:'Höhe unbekannt'} · ${Number.isFinite(st!.distance)?`${(st!.distance!/1000).toFixed(1).replace('.',',')} km`:'Entfernung unbekannt'}`):'';
 const observed=(v:number|undefined,fallback:number)=>fresh&&Number.isFinite(v)?Number(v):fallback;
 const temp=observed(st?.temperature,Number(c.temperature_2m)),hum=observed(st?.humidity,Number(c.relative_humidity_2m)),dew=observed(st?.dewPoint,Number(c.dew_point_2m)),pressure=observed(st?.pressure,Number(c.pressure_msl)),windSpeed=observed(st?.windSpeed!=null?(st.windUnit==='kt'?st.windSpeed:st.windSpeed/1.852):undefined,Number(c.wind_speed_10m)),windGust=observed(st?.windGust!=null?(st.windUnit==='kt'?st.windGust:st.windGust/1.852):undefined,Number(c.wind_gusts_10m)),windDirection=observed(st?.windDirection,Number(c.wind_direction_10m)),cloud=observed(st?.cloudCover,Number(c.cloud_cover)),precip=observed(st?.precipitation,Number(c.precipitation));
 const mappedHours=mapHours(w);
 const forecastHour=mappedHours[currentIndex(mappedHours)]??null;
 const airCurrentUv=air?.current?Number(air.current.uv_index):Number.NaN;
 const actualCurrentUv=forecastHour&&Number.isFinite(forecastHour.uvIndex)?forecastHour.uvIndex:(Number.isFinite(airCurrentUv)?airCurrentUv:Number.NaN);
 const source=(available:boolean,defaultText:string)=>available&&fresh?(st!.blended?`robustes Mittel aus ${st!.stationCount??2} Stationen`:`${st!.provider??'Stationsmessung'} · ${st!.name}`):defaultText;
 const cards=[
  {icon:'💧',label:'Taupunkt',value:`${Math.round(dew)} °C`,detail:`Relative Feuchte ${Math.round(hum)} % · ${source(Number.isFinite(st?.dewPoint),'Best Match')}`,checked:fresh&&Number.isFinite(st?.dewPoint)},
  {icon:'🌬️',label:'Wind',value:`${dirArrow(windDirection)} ${wind(windSpeed,unit)}`,detail:`aus ${Math.round(windDirection)}° · Böen ${wind(windGust,unit)} · ${source(Number.isFinite(st?.windSpeed)||Number.isFinite(st?.windDirection),'Best Match')}`,checked:fresh&&(Number.isFinite(st?.windSpeed)||Number.isFinite(st?.windDirection))},
  {icon:'🌧️',label:'Niederschlag',value:`${precip.toFixed(1)} mm`,detail:source(Number.isFinite(st?.precipitation),'aktueller Modellzeitraum'),checked:fresh&&Number.isFinite(st?.precipitation)},
  {icon:'☁️',label:'Bewölkung',value:`${cloudOktas(cloud)}/8`,detail:`${cloudOktasText(cloud).split(' · ')[1]} · ${source(Number.isFinite(st?.cloudCover),'Best Match')}`,checked:fresh&&Number.isFinite(st?.cloudCover)},
  {icon:'⏱️',label:'Luftdruck',value:`${Math.round(pressure)} hPa`,detail:`auf Meereshöhe · ${source(Number.isFinite(st?.pressure),'Best Match')}`,checked:fresh&&Number.isFinite(st?.pressure)},
  {icon:'☀️',label:'UV-Index',value:Number.isFinite(actualCurrentUv)?actualCurrentUv.toFixed(1):'–',detail:'tatsächlich erwarteter, bewölkungsberücksichtigter UVI',checked:false},
  {icon:'🏭',label:'Luftqualität',value:air?.current?`${Math.round(Number(air.current.european_aqi))} AQI`:'–',detail:air?.current?`PM2,5 ${Number(air.current.pm2_5).toFixed(1)} µg/m³`:'Open-Meteo',checked:false},
  {icon:'🏔️',label:'Höhe',value:`${Math.round(loc.elevation??w.elevation)} m`,detail:'ü. NHN',checked:false}
 ];
 return <><section className="hero"><div>{icon(Number(c.weather_code),Number(c.is_day)===1)}</div><article><span>Aktuelles Wetter</span><strong>{Math.round(temp)}°</strong><b>{label(Number(c.weather_code))}</b><small>Gefühlt {Math.round(Number(c.apparent_temperature))} °C{fresh?(st?.blended?' · Temperatur robust lokal gemittelt':' · Temperatur stationsgeprüft'):''}</small></article><aside className={fresh?'ok':''}><i/><span><b>{fresh?(st?.blended?'Lokales Stationsmittel':'Nächstgeeignete Messstation'):stationLoading?'Prüfung läuft':'Best Match'}</b><small>{fresh?stationInfo:stationLoading?'Stationsdaten werden im Hintergrund geprüft.':'Keine ausreichend aktuelle amtliche oder hyperlokale Messstation verfügbar – Fallback auf Best Match'}</small></span></aside></section><section className="metrics">{cards.map(x=><article key={x.label}><header><span>{x.icon}</span><small>{x.label}</small>{x.checked&&<i title="Mit aktueller Stationsmessung abgeglichen"/>}</header><strong>{x.value}</strong><small>{x.detail}</small></article>)}</section></>
}
function Hazards({data}:{data:ReturnType<typeof hazards>}){if(!data.length)return <section className="hazard clear"><BadgeCheck/><div><strong>Keine markanten Gefahrenindikatoren</strong><span>Die automatische Auswertung der nächsten 24 Stunden zeigt keine auffälligen Signale.</span></div></section>;return <section className="hazards">{data.map(x=><article className={x.level} key={x.title}><AlertTriangle/><div><strong>{x.title}</strong><span>{x.text}</span></div></article>)}<small>Automatisch berechnete Indikatoren – Schwellen orientiert an DWD, Meteoalarm und NWS; keine amtlichen Warnungen.</small></section>}

function alertTime(value:string|undefined,timezone?:string){if(!value)return'';const d=new Date(value);return Number.isFinite(d.getTime())?formatInZone(d,timezone,{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}):''}
function OfficialWarnings({alerts,loading,error,provider,timezone}:{alerts:OfficialAlert[];loading:boolean;error:string;provider:string;timezone?:string}){
 const[open,setOpen]=useState<string>('');
 if(loading)return <section className="official-warnings compact"><header><AlertTriangle/><div><strong>Amtliche Wetterwarnungen</strong><small>CAP-Meldungen werden geladen …</small></div></header></section>;
 if(error)return <section className="official-warnings compact unavailable"><header><AlertTriangle/><div><strong>Amtliche Wetterwarnungen</strong><small>{error}</small></div></header></section>;
 if(!alerts.length)return <section className="official-warnings compact clear"><header><BadgeCheck/><div><strong>Keine amtlichen Wetterwarnungen</strong><small>{provider||'Für den gewählten Standort liegt derzeit keine aktive CAP-Warnung vor.'}</small></div></header></section>;
 return <section className="official-warnings"><header><AlertTriangle/><div><strong>Amtliche Wetterwarnungen</strong><small>{provider||'Common Alerting Protocol (CAP)'}</small></div></header><div className="official-list">{alerts.map(a=>{const expanded=open===a.id;return <article key={a.id} className={`official-alert ${a.level} ${expanded?'open':''}`}><button type="button" onClick={()=>setOpen(expanded?'':a.id)} aria-expanded={expanded}><i/><span>{a.headline}</span><b>{expanded?'−':'+'}</b></button>{expanded&&<div className="official-message"><p>{a.description}</p>{a.instruction&&<p className="instruction">{a.instruction}</p>}<small>{[a.source,a.area,a.onset?`ab ${alertTime(a.onset,timezone)}`:a.effective?`ab ${alertTime(a.effective,timezone)}`:'',a.expires?`bis ${alertTime(a.expires,timezone)}`:''].filter(Boolean).join(' · ')}</small></div>}</article>})}</div></section>
}

function MoveMap({lat,lon}:{lat:number;lon:number}){const map=useMap();useEffect(()=>{map.setView([lat,lon],7,{animate:true})},[lat,lon,map]);return null}
const DWD_RATE_LEGEND=[
 {value:'0,1',color:'#d9f3ff'},{value:'0,5',color:'#72c9ff'},{value:'1',color:'#2f91e3'},{value:'2,5',color:'#43c879'},
 {value:'5',color:'#f0d447'},{value:'10',color:'#f59b3d'},{value:'20',color:'#e34b4b'},{value:'50＋',color:'#b83fc8'}
];
const RAINVIEWER_LEGEND=[{dbz:10,color:'#d2c48b'},{dbz:20,color:'#00a3e0'},{dbz:30,color:'#005588'},{dbz:40,color:'#ffaa00'},{dbz:50,color:'#c10000'},{dbz:60,color:'#ff62ff'}];
function RadarColourLegend({source}:{source:'dwd'|'rainviewer'}){
 return source==='dwd'?<div className="radar-colour-legend dwd">
  <div className="radar-legend-head"><span><Droplets size={11}/>Niederschlagsrate</span><b>mm/h</b></div>
  <div className="dwd-rate-scale" aria-hidden="true">{DWD_RATE_LEGEND.map(item=><i key={item.value} style={{background:item.color}}/>)}</div>
  <div className="dwd-rate-ticks">{DWD_RATE_LEGEND.map(item=><span key={item.value}>{item.value}</span>)}</div>
  <div className="dwd-rate-classes"><span>leicht</span><span>mäßig</span><span>stark</span><span>sehr stark</span></div>
  <small>DWD-RV · vereinfachte MID-Leseskala</small>
 </div>:<div className="radar-colour-legend rainviewer">
  <div>{RAINVIEWER_LEGEND.map(item=><i key={item.dbz} style={{background:item.color}} title={`${item.dbz} dBZ`}/>)}</div>
  <p>{RAINVIEWER_LEGEND.map(item=><span key={item.dbz}>{item.dbz}{item.dbz===60?'＋':''}</span>)}</p>
  <small>RainViewer Universal Blue · dBZ</small>
 </div>
}
function Radar({lat,lon,timezone,analysis}:{lat:number;lon:number;timezone?:string;analysis?:RadarNowcast|null}){
 const inDwdCoverage=lon>=1.4&&lon<=18.8&&lat>=45.6&&lat<=56.5;
 const[frames,setFrames]=useState<RadarFrame[]>([]),[host,setHost]=useState(''),[index,setIndex]=useState(0),[opacity,setOpacity]=useState(82),[latestObserved,setLatestObserved]=useState(0),[source,setSource]=useState<'dwd'|'rainviewer'>(inDwdCoverage?'dwd':'rainviewer'),[playing,setPlaying]=useState(false);
 useEffect(()=>{let alive=true;setPlaying(false);if(inDwdCoverage){
  const supplied=(analysis?.source==='dwd'&&Array.isArray(analysis.timeline)?analysis.timeline:[]).map(value=>Math.floor(new Date(value).getTime()/1000)).filter(Number.isFinite).sort((a,b)=>a-b);
  const observedAt=analysis?.source==='dwd'&&analysis.observedAt?Math.floor(new Date(analysis.observedAt).getTime()/1000):0,anchor=observedAt||Math.floor(Date.now()/300000)*300;
  // Falls die WMS-Capabilities nur den Default-Frame ausweisen, bleibt die
  // mobile Zeitleiste anhand der offiziellen 5-Minuten-Auflösung nutzbar.
  const fallback=Array.from({length:37},(_,i)=>anchor+(i-12)*300),timeline=supplied.length>1?supplied:fallback;
  const items=[...new Set(timeline)].sort((a,b)=>a-b).map(time=>({time,future:time>anchor}));
  const currentIndex=Math.max(0,items.reduce((best,x,i)=>x.time<=anchor?i:best,0));setFrames(items);setIndex(currentIndex);setLatestObserved(anchor);setSource('dwd');return()=>{alive=false}
 }
 fetch('https://api.rainviewer.com/public/weather-maps.json',{cache:'no-store'}).then(r=>r.json()).then((d:Radar)=>{if(!alive)return;const past=(d.radar?.past??[]).slice(-12),last=past.at(-1)?.time??0,nowcast=(d.radar?.nowcast??[]).filter(x=>x.time<=last+3600).map(x=>({...x,future:true})),items=[...past,...nowcast];setHost(d.host);setFrames(items);setLatestObserved(last);setIndex(Math.max(0,past.length-1));setSource('rainviewer')}).catch(()=>{setFrames([]);setHost('')});return()=>{alive=false}
 },[lat,lon,inDwdCoverage,analysis?.source,analysis?.observedAt,analysis?.timeline?.join('|')]);
 useEffect(()=>{if(!playing||frames.length<2)return;const timer=window.setInterval(()=>setIndex(current=>current>=frames.length-1?0:current+1),850);return()=>window.clearInterval(timer)},[playing,frames.length]);
 const frame=frames[index],future=!!frame&&frame.time>latestObserved,minutesAhead=future?Math.max(0,Math.round((frame.time-latestObserved)/60)):0,dwdLayer=analysis?.source==='dwd'&&analysis.radarLayer?analysis.radarLayer:'dwd:Niederschlagsradar';
 const rainViewerUrl=frame?.path&&host?`${host}${frame.path}/256/{z}/{x}/{y}/2/1_1.png`:'';
 const dwdTime=frame?new Date(frame.time*1000).toISOString():'';
 const hasFuture=frames.some(x=>x.time>latestObserved),canAnimate=frames.length>1;
 const step=(amount:number)=>{setPlaying(false);setIndex(current=>Math.max(0,Math.min(frames.length-1,current+amount)))};
 const togglePlay=()=>{if(!canAnimate)return;if(!playing&&index>=frames.length-1)setIndex(0);setPlaying(value=>!value)};
 return <section className="card"><Title eye="Open Source Radar" title="Niederschlagsradar"/><div className="radarmap"><MapContainer center={[lat,lon]} zoom={7} className="leafletmap" scrollWheelZoom={false}><MoveMap lat={lat} lon={lon}/><TileLayer attribution='&copy; OpenStreetMap-Mitwirkende' url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"/>{source==='dwd'&&frame&&<WMSTileLayer key={`${dwdLayer}:${dwdTime}`} url="https://maps.dwd.de/geoserver/wms" opacity={opacity/100} params={({layers:dwdLayer,styles:'',format:'image/png',transparent:true,version:'1.3.0',time:dwdTime} as any)} attribution='Radar und Nowcast &copy; DWD'/>}{source==='rainviewer'&&rainViewerUrl&&<TileLayer attribution='Radar &copy; RainViewer' url={rainViewerUrl} opacity={opacity/100}/>}<CircleMarker center={[lat,lon]} radius={7} pathOptions={{color:'#fff',weight:2,fillColor:'#1f8cff',fillOpacity:0.95}}><Popup>Gewählter Standort</Popup></CircleMarker></MapContainer><div className="radarlegend"><div className="radarlegend-head"><strong>{future?`Nowcast +${minutesAhead} min`:'Radarintensität'}</strong><span>{source==='dwd'?'DWD-RV':'RainViewer'}</span></div><small>{source==='dwd'?'Beobachtung und offene 0–2-h-Vorhersage':'Radarhistorie; Standort-Nowcast separat'}{analysis&&analysis.source!=='model'?` · ${analysis.provider}`:''}</small><RadarColourLegend source={source}/></div></div>
  <div className="radarcontrols">
   <div className="radar-playback-buttons"><button className="secondary" disabled={!canAnimate||index<=0} onClick={()=>step(-1)} title="Vorheriger Radarzeitschritt" aria-label="Vorheriger Radarzeitschritt"><SkipBack size={17}/></button><button className="secondary play" disabled={!canAnimate} onClick={togglePlay} title={playing?'Animation pausieren':'Radarfilm abspielen'} aria-label={playing?'Animation pausieren':'Radarfilm abspielen'}>{playing?<Pause size={18}/>:<Play size={18}/>}</button><button className="secondary" disabled={!canAnimate||index>=frames.length-1} onClick={()=>step(1)} title="Nächster Radarzeitschritt" aria-label="Nächster Radarzeitschritt"><SkipForward size={17}/></button></div>
   <div className="range timeline"><small>Zeitschritt {frames.length?`${index+1}/${frames.length}`:''}{future?` · +${minutesAhead} min`:''}</small><input type="range" min={0} max={Math.max(0,frames.length-1)} value={index} disabled={!canAnimate} onChange={e=>{setPlaying(false);setIndex(Number(e.target.value))}}/></div>
   <time className={future?'future':''}>{frame?formatInZone(frame.time*1000,timezone,{hour:'2-digit',minute:'2-digit'}):'–:–'}{future?' Prognose':''}</time>
   <div className="range opacity"><small>Radar-Deckkraft</small><input type="range" min={25} max={100} value={opacity} onChange={e=>setOpacity(Number(e.target.value))}/></div>
  </div>
  {!canAnimate&&<small className="source warning">Aktuell ist nur ein Radarzeitschritt abrufbar; die Animation startet automatisch, sobald weitere Frames verfügbar sind.</small>}{!hasFuture&&source==='rainviewer'&&<small className="source warning">RainViewer stellt keine öffentlichen Zukunftsframes bereit; die Standortprognose ist eine gekennzeichnete Bewegungsnäherung aus der Radarhistorie.</small>}<small className="source">Kartenbasis: OpenStreetMap · Kartenebene: {source==='dwd'?'Deutscher Wetterdienst (DWD-RV-Produkt)':'RainViewer Universal Blue'}{analysis&&analysis.source!=='model'?` · Standortauswertung: ${analysis.provider}`:''} · Darstellung kann zeitverzögert oder unvollständig sein; keine amtliche Warnung.</small>
 </section>
}

function severityRank(level:'yellow'|'orange'|'red'|'purple'){return({yellow:1,orange:2,red:3,purple:4} as const)[level]}
type HazardBadgeLevel='yellow'|'orange'|'red'|'purple';
type PrecipType='none'|'drizzle'|'freezingDrizzle'|'rain'|'freezingRain'|'showers'|'snow'|'snowGrains'|'snowShowers'|'sleet'|'sleetShowers'|'thunderstorm'|'thunderstormHail';
type PrecipSample={time?:string;epoch?:number;timezone?:string;precipitation:number;rain:number;showers:number;snowfall:number;probability:number;code:number};
const KMH_PER_KT=1.852;
const precipMeta:Record<Exclude<PrecipType,'none'>,{label:string;legendClass:string;fill:string}>={
 drizzle:{label:'Sprühregen',legendClass:'drizzle',fill:'url(#drizzleFill)'},
 freezingDrizzle:{label:'Gefrierender Sprühregen',legendClass:'freezing-drizzle',fill:'url(#freezingDrizzlePattern)'},
 rain:{label:'Regen',legendClass:'rain',fill:'url(#rainFill)'},
 freezingRain:{label:'Gefrierender Regen',legendClass:'freezing-rain',fill:'url(#freezingRainPattern)'},
 showers:{label:'Regenschauer',legendClass:'showers',fill:'url(#showersPattern)'},
 snow:{label:'Schneefall',legendClass:'snow',fill:'url(#snowPattern)'},
 snowGrains:{label:'Schneegriesel',legendClass:'snow-grains',fill:'url(#snowGrainsPattern)'},
 snowShowers:{label:'Schneeschauer',legendClass:'snow-showers',fill:'url(#snowShowersPattern)'},
 sleet:{label:'Schneeregen',legendClass:'sleet',fill:'url(#sleetPattern)'},
 sleetShowers:{label:'Schneeregenschauer',legendClass:'sleet-showers',fill:'url(#sleetShowersPattern)'},
 thunderstorm:{label:'Gewitterniederschlag',legendClass:'thunderstorm',fill:'url(#thunderstormPattern)'},
 thunderstormHail:{label:'Gewitter mit Hagel',legendClass:'thunderstorm-hail',fill:'url(#thunderstormHailPattern)'}
};
function gustLevelKt(v:number):HazardBadgeLevel|null{const kmh=v*KMH_PER_KT;if(kmh>=103)return'purple';if(kmh>=89)return'red';if(kmh>=75)return'orange';if(kmh>=50)return'yellow';return null}
function rainLevelMm(v:number):HazardBadgeLevel|null{if(v>=60)return'purple';if(v>=40)return'red';if(v>=25)return'orange';if(v>=15)return'yellow';return null}
function heatLevelC(v:number):HazardBadgeLevel|null{if(v>=46)return'purple';if(v>=41)return'red';if(v>=38)return'orange';if(v>=32)return'yellow';return null}
function uvLevel(v:number):HazardBadgeLevel|null{if(v>=11)return'red';if(v>=8)return'orange';if(v>=6)return'yellow';return null}
function snowLevelCm(v:number):HazardBadgeLevel|null{if(v>=20)return'purple';if(v>=10)return'red';if(v>=5)return'orange';if(v>=1)return'yellow';return null}
function dailyHazards(day:Day,hours:Hour[]){
 const items:{label:string;level:HazardBadgeLevel}[]=[];
 const apparent=hours.length?Math.max(...hours.map(x=>x.apparent).filter(Number.isFinite)):day.max;
 const heat=Math.max(day.max,apparent);
 const uvMax=dayEffectiveUvMax(day,hours);
 const snowSum=hours.reduce((s,x)=>s+Math.max(0,x.snowfall||0),0);
 const gust=day.gust;
 const gustLvl=gustLevelKt(gust); if(gustLvl)items.push({label:`Böen ${Math.round(gust)} kt`,level:gustLvl});
 const rainLvl=rainLevelMm(day.precipitation); if(rainLvl)items.push({label:`${day.precipitation.toFixed(1)} mm`,level:rainLvl});
 const snowLvl=snowLevelCm(snowSum); if(snowLvl)items.push({label:`Schnee ${Math.round(snowSum)} cm`,level:snowLvl});
 const heatLvl=heatLevelC(heat); if(heatLvl)items.push({label:`Gefühlt ${Math.round(heat)}°`,level:heatLvl});
 const uvLvl=uvLevel(uvMax); if(uvLvl)items.push({label:`UV ${Math.round(uvMax)}`,level:uvLvl});
 if([95,96,99].includes(day.code))items.push({label:'Gewitter',level:day.code===99?'red':day.code===96?'orange':'yellow'});
 return items.sort((a,b)=>severityRank(b.level)-severityRank(a.level)).slice(0,3);
}
function dirArrow(deg:number){const to=((deg+180)%360+360)%360;const arrows=['↑','↗','→','↘','↓','↙','←','↖'];return arrows[Math.round(to/45)%8]}
const WMO_PRECIP_TYPE:Partial<Record<number,PrecipType>>={
 51:'drizzle',53:'drizzle',55:'drizzle',
 56:'freezingDrizzle',57:'freezingDrizzle',
 61:'rain',63:'rain',65:'rain',
 66:'freezingRain',67:'freezingRain',
 68:'sleet',69:'sleet',
 71:'snow',73:'snow',75:'snow',77:'snowGrains',
 80:'showers',81:'showers',82:'showers',
 83:'sleetShowers',84:'sleetShowers',
 85:'snowShowers',86:'snowShowers',
 95:'thunderstorm',97:'thunderstorm',
 96:'thunderstormHail',99:'thunderstormHail'
};
function precipitationParts(h:PrecipSample){
 const total=Math.max(0,h.precipitation||0),rainValue=Math.max(0,h.rain||0),showerValue=Math.max(0,h.showers||0),snowCm=Math.max(0,h.snowfall||0),code=Math.round(h.code||0);
 const measurable=total>=.01||rainValue>=.01||showerValue>=.01||snowCm>=.01;
 if(!measurable)return{total,type:'none' as PrecipType,label:'kein Niederschlag',code};
 const baseType=WMO_PRECIP_TYPE[code];
 const hasRain=rainValue>=.05;
 const hasShowers=showerValue>=.05;
 const hasSnow=snowCm>=.05;
 let type:PrecipType;
 // Eindeutige WMO-Kategorien haben Vorrang. Gemischte Formen werden nur
 // bei gleichzeitig messbaren flüssigen und festen Anteilen abgeleitet.
 if(baseType==='thunderstormHail'||baseType==='thunderstorm'||baseType==='freezingDrizzle'||baseType==='freezingRain')type=baseType;
 else if(hasSnow&&(hasShowers||baseType==='showers'||baseType==='snowShowers'||baseType==='sleetShowers'))type='sleetShowers';
 else if(hasSnow&&(hasRain||baseType==='rain'||baseType==='drizzle'||baseType==='snow'||baseType==='sleet'))type='sleet';
 else if(baseType)type=baseType;
 else if(hasShowers)type='showers';
 else if(hasRain||total>=.01)type='rain';
 else if(hasSnow)type='snow';
 else type='none';
 if(type==='none')return{total,type,label:'kein Niederschlag',code};
 const meta=precipMeta[type];
 const amount=type==='snow'||type==='snowShowers'||type==='snowGrains'?`${snowCm.toFixed(1)} cm`:type==='sleet'||type==='sleetShowers'?`${total.toFixed(1)} mm · ${snowCm.toFixed(1)} cm`:`${total.toFixed(1)} mm`;
 return{total,type,label:`${meta.label} ${amount}`,code};
}
function presentPrecipTypes(series:{type:PrecipType}[]){const order:PrecipType[]=['drizzle','freezingDrizzle','rain','freezingRain','showers','sleet','sleetShowers','snow','snowGrains','snowShowers','thunderstorm','thunderstormHail'];return order.filter(t=>series.some(x=>x.type===t)) as Exclude<PrecipType,'none'>[]}
function localTimeLabel(value:number,timezone?:string){return formatInZone(value,timezone,{hour:'2-digit',minute:'2-digit'})}
function clockMinutes(value?:string){const match=String(value||'').match(/T(\d{2}):(\d{2})/);if(!match)return null;const hours=Number(match[1]),minutes=Number(match[2]);return Number.isFinite(hours)&&Number.isFinite(minutes)?hours*60+minutes:null}
function clockLabel(value?:string){const match=String(value||'').match(/T(\d{2}):(\d{2})/);return match?`${match[1]}:${match[2]}`:''}
function precipitationNowSummary(minutes:Minute15[],hours:Hour[],timezone?:string){
 const now=Date.now();
 const source=minutes.length?'15-Minuten-Best-Match':'stündlicher Best Match';
 const samples:PrecipSample[]=minutes.length?minutes:hours.slice(currentIndex(hours),currentIndex(hours)+7);
 if(!samples.length)return{probability:0,summary:'Keine Kurzfristdaten verfügbar.',source};
 const timed=samples.map(x=>({...x,ts:Number.isFinite(x.epoch)?Number(x.epoch):Date.parse(`${String(x.time)}Z`)})).filter(x=>Number.isFinite(x.ts)).sort((a,b)=>a.ts-b.ts);
 const nearest=timed.reduce((best,x)=>Math.abs(x.ts-now)<Math.abs(best.ts-now)?x:best,timed[0]);
 const stepMs=minutes.length?15*60000:60*60000;
 const horizonEnd=now+6*3600000;
 const relevant=timed.filter(x=>x.ts>=now-stepMs&&x.ts<=horizonEnd);
 const wet=(x:typeof relevant[number])=>{const p=precipitationParts(x);return p.type!=='none'&&(p.total>=.01||x.snowfall>=.01)};
 const groups:{items:typeof relevant}[]=[];
 for(const item of relevant){if(!wet(item))continue;const last=groups.at(-1);if(last&&item.ts-last.items.at(-1)!.ts<=stepMs*1.6)last.items.push(item);else groups.push({items:[item]})}
 const active=groups.find(g=>g.items[0].ts-stepMs<=now&&g.items.at(-1)!.ts>=now);
 const event=active??groups.find(g=>g.items[0].ts>=now);
 if(!event){const maxProb=Math.max(...relevant.map(x=>Number(x.probability)||0),0);return{probability:Number(nearest.probability)||0,summary:maxProb>=30?`Bis zu ${Math.round(maxProb)} % Risiko in den nächsten 6 Stunden; noch kein messbarer Niederschlag im Best Match.`:'Kein messbarer Niederschlag in den nächsten 6 Stunden erwartet.',source}}
 const start=event.items[0].ts-stepMs,end=event.items.at(-1)!.ts;
 const types=[...new Set(event.items.map(x=>precipitationParts(x).type).filter(t=>t!=='none'))] as Exclude<PrecipType,'none'>[];
 const typeText=types.map(t=>precipMeta[t].label).join(' → ');
 const summary=active?`Aktuell ${typeText}; voraussichtlich bis ${localTimeLabel(end,timezone)} Uhr.`:`${typeText} voraussichtlich ab ${localTimeLabel(start,timezone)} bis ${localTimeLabel(end,timezone)} Uhr.`;
 return{probability:Number(nearest.probability)||0,summary,source};
}

type PrecipNowResult={probability:number;summary:string;source:string};
function radarClock(value:string|undefined,timezone?:string){if(!value)return'';const time=new Date(value).getTime();return Number.isFinite(time)?formatInZone(time,timezone,{hour:'2-digit',minute:'2-digit'}):''}
function radarClockRange(start:string|undefined,end:string|undefined,timezone?:string){const a=radarClock(start,timezone),b=radarClock(end,timezone);if(!a)return'';return b&&b!==a?`${a}–${b} Uhr`:`${a} Uhr`}
function radarRateText(rate:number|undefined,approximate=false,uncertain=false){const value=Number(rate);if(!Number.isFinite(value)||value<.05)return'';const prefix=approximate?'geschätzt ':'';if(value>=50)return`${prefix}> 50 mm/h${uncertain?' (lokal/unsicher)':''}`;if(value>=20)return`${prefix}${Math.round(value)} mm/h`;return`${prefix}${value.toFixed(1).replace('.',',')} mm/h`}
function radarIntensity(rate:number|undefined){const value=Number(rate);if(value>=50)return'extremes Radarecho';if(value>=20)return'sehr stark';if(value>=8)return'stark';if(value>=2.5)return'mäßig';if(value>=.5)return'leicht';if(value>=.1)return'sehr leicht';return''}
function radarSummary(radar:RadarNowcast,timezone?:string){
 const observed=radarClock(radar.observedAt,timezone),current=Number(radar.currentRate||0),peak=Number(radar.peakRate||0),rate=current>=.05?current:peak,intensity=radarIntensity(rate),rateText=radarRateText(rate,!!radar.rateApproximate,!!radar.rateUncertain),arrival=radarClockRange(radar.arrivalStartAt,radar.arrivalEndAt,timezone),end=radarClock(radar.endAt,timezone);
 if(current>=.05){const ending=end?(radar.endOpenEnded?` Voraussichtlich mindestens bis ${end} Uhr; das Ende liegt außerhalb des Radarhorizonts.`:` Voraussichtlich bis etwa ${end} Uhr${radar.endUncertain?' (noch unsicher)':''}.`):(radar.source==='dwd'?' Eine belastbare Endzeit ist im aktuellen DWD-Nowcast noch nicht erkennbar.':' Eine belastbare Endzeit lässt sich aus den verfügbaren Radarframes noch nicht ableiten.');return`Niederschlag am Standort erkannt${observed?` (${observed} Uhr)`:''}: ${intensity}${rateText?` · ${rateText}`:''}.${ending}`}
 if(radar.arrivalStartAt||Number.isFinite(radar.arrivalMinutes as number)){const minutes=Math.max(0,Math.round(Number(radar.arrivalMinutes)||0)),endMinutes=radar.arrivalEndAt&&radar.arrivalStartAt?Math.max(minutes,Math.round((new Date(radar.arrivalEndAt).getTime()-new Date(radar.observedAt||radar.arrivalStartAt).getTime())/60000)):minutes;const minuteText=endMinutes>minutes?`${minutes}–${endMinutes}`:`${minutes}`,nearby=radar.arrivalKind==='nearby'||radar.arrivalKind==='approximate';return`${nearby?'Radarecho nähert sich der Standortumgebung; Standorttreffer unsicher':'Radarecho erreicht den Standort voraussichtlich'} in ${minuteText} Minuten${arrival?` (${arrival})`:''}${intensity?` · ${intensity}`:''}${rateText?` · ${rateText}`:''}${end&&!nearby&&end!==radarClock(radar.arrivalEndAt,timezone)?` · voraussichtlich bis ${end} Uhr`:''}.`}
 if(observed&&radar.summary)return`${radar.summary.replace(/\.$/,'')} (Datenstand ${observed} Uhr).`;
 return radar.summary;
}
function combineRadarAndModel(model:PrecipNowResult,radar:RadarNowcast|null,loading:boolean,error:string,timezone?:string):PrecipNowResult{
 if(!radar){return{...model,source:loading?`${model.source} · Radarauswertung läuft …`:error?`${model.source} · Radar-Fallback`:model.source}}
 if(radar.source==='model'||radar.coverage===false){if(radar.temporaryUnavailable||radar.coverageExpected)return{...model,source:`${model.source} · ${radar.expectedSource||'Radar'} vorübergehend nicht auswertbar`};return{...model,source:`${model.source} · keine verwertbare Radarabdeckung`}};
 const arrival=Number.isFinite(radar.arrivalMinutes as number)?Number(radar.arrivalMinutes):(Number(radar.currentRate||0)>=.05?0:120);
 const horizonWeight=arrival<=30?.85:arrival<=60?.70:.55;
 const qualityFactor=radar.quality==='high'?1:radar.quality==='medium'?.82:.65;
 const radarWeight=Math.max(.25,Math.min(.85,horizonWeight*qualityFactor));
 const modelProbability=Math.max(0,Math.min(100,Number(model.probability)||0));
 const radarProbability=Math.max(0,Math.min(100,Number(radar.radarProbability)||0));
 let probability=Math.round(radarWeight*radarProbability+(1-radarWeight)*modelProbability);
 if(Number(radar.currentRate||0)>=.05)probability=Math.max(probability,90);
 const quality=radar.quality==='high'?'hoch':radar.quality==='medium'?'mittel':'eingeschränkt',observed=radarClock(radar.observedAt,timezone);
 return{probability,summary:radarSummary(radar,timezone)||model.summary,source:`${radar.provider}${observed?` · Stand ${observed} Uhr`:''} · Qualität ${quality} · ${Math.round(radarWeight*100)} % Radar / ${Math.round((1-radarWeight)*100)} % Modell`};
}

function Forecast({days,hours,selected,setSelected,unit,modelInfo,timezone,timezoneAbbreviation}:{days:Day[];hours:Hour[];selected:string;setSelected:(x:string)=>void;unit:WindUnit;modelInfo:BestMatchModelInfo|null;timezone:string;timezoneAbbreviation?:string}){
 const [selectedHour,setSelectedHour]=useState(0);
 const boundaryHourRef=useRef<number|null>(null);
 const detailChartRef=useRef<HTMLDivElement>(null);
 const forecastDays=days.slice(0,7);
 const allMin=Math.min(...forecastDays.map(x=>x.min)),allMax=Math.max(...forecastDays.map(x=>x.max)),range=Math.max(1,allMax-allMin);
 const p=hours.filter(x=>x.time.startsWith(selected));
 useEffect(()=>{if(!p.length)return;if(boundaryHourRef.current!==null){const requested=boundaryHourRef.current;setSelectedHour(requested===23?p.length-1:Math.min(Math.max(0,requested),p.length-1));boundaryHourRef.current=null;return}const isToday=selected===localDateInZone(timezone);const middayIndex=p.findIndex(x=>x.time.slice(11,13)==='12');const fallback=middayIndex>=0?middayIndex:Math.min(6,Math.max(0,p.length-1));setSelectedHour(isToday?currentIndex(p):fallback)},[selected,p.length,timezone]);
 function moveHour(delta:-1|1){
  const nextIndex=selectedHour+delta;
  if(nextIndex>=0&&nextIndex<p.length){setSelectedHour(nextIndex);return}
  const dayIndex=forecastDays.findIndex(x=>x.date===selected);
  const targetDay=forecastDays[dayIndex+delta];
  if(!targetDay||!hours.some(x=>x.time.startsWith(targetDay.date)))return;
  boundaryHourRef.current=delta>0?0:23;
  setSelected(targetDay.date);
 }
 function handleDetailChartKeyDown(event:ReactKeyboardEvent<HTMLDivElement>){
  if(typeof window==='undefined'||!window.matchMedia('(min-width: 851px)').matches)return;
  if(event.key!=='ArrowLeft'&&event.key!=='ArrowRight')return;
  event.preventDefault();
  moveHour(event.key==='ArrowLeft'?-1:1);
 }
 if(!p.length)return null;
 const precipSeries=p.map(precipitationParts);
 const currentHour=p[Math.min(selectedHour,p.length-1)]??p[0],currentPrecip=precipSeries[Math.min(selectedHour,p.length-1)]??precipitationParts(currentHour);
 const precipLegendTypes=presentPrecipTypes(precipSeries);
 const tMin=Math.floor((Math.min(...p.map(x=>Math.min(x.temperature,x.apparent)))-2)/2)*2,tMax=Math.ceil((Math.max(...p.map(x=>Math.max(x.temperature,x.apparent)))+2)/2)*2,tempRange=Math.max(6,tMax-tMin);
 const rainMax=Math.max(1,...p.map(x=>x.precipitation));
 const W=240,H=166,left=18,right=18,plotW=W-left-right,cloudTop=18,tempTop=39,tempBottom=94,rainTop=111,rainBottom=145,nightBottom=153;
 const xAt=(i:number)=>left+(i/Math.max(1,p.length-1))*plotW;
 const yTemp=(v:number)=>tempBottom-((v-tMin)/tempRange)*(tempBottom-tempTop);
 const yRain=(v:number)=>rainBottom-(v/rainMax)*(rainBottom-rainTop);
 const yProb=(v:number)=>rainBottom-(Math.max(0,Math.min(100,v))/100)*(rainBottom-rainTop);
 const tempPath=p.map((x,i)=>`${i?'L':'M'} ${xAt(i)} ${yTemp(x.temperature)}`).join(' ');
 const apparentPath=p.map((x,i)=>`${i?'L':'M'} ${xAt(i)} ${yTemp(x.apparent)}`).join(' ');
 const probabilityPath=p.map((x,i)=>`${i?'L':'M'} ${xAt(i)} ${yProb(x.probability)}`).join(' ');
 const areaPath=`${tempPath} L ${xAt(p.length-1)} ${tempBottom} L ${xAt(0)} ${tempBottom} Z`;
 const iconStep=typeof window!=='undefined'&&window.innerWidth<640?3:2;
 const iconIndices=p.map((_,i)=>i).filter(i=>i===0||i===p.length-1||i%iconStep===0);
 const timeStep=typeof window!=='undefined'&&window.innerWidth<640?4:3;
 const timeIndices=p.map((_,i)=>i).filter(i=>i===0||i===p.length-1||i%timeStep===0);
 const maxIdx=p.reduce((b,x,i)=>x.temperature>p[b].temperature?i:b,0),minIdx=p.reduce((b,x,i)=>x.temperature<p[b].temperature?i:b,0);
 const totalRain=p.reduce((a,b)=>a+b.precipitation,0),maxProb=Math.max(...p.map(x=>x.probability)),gustMax=Math.max(...p.map(x=>x.gust)),windMax=Math.max(...p.map(x=>x.wind));
 const selectedDay=days.find(x=>x.date===selected)??days[0];
 const sunriseMinutes=clockMinutes(selectedDay.sunrise),sunsetMinutes=clockMinutes(selectedDay.sunset);
 const sunriseLabel=clockLabel(selectedDay.sunrise),sunsetLabel=clockLabel(selectedDay.sunset);
 const xClock=(minutes:number)=>left+(clamp(minutes,0,23*60)/(23*60))*plotW;
 const sunriseX=sunriseMinutes===null?null:xClock(sunriseMinutes),sunsetX=sunsetMinutes===null?null:xClock(sunsetMinutes);
 const selectedCharacter=dayWeatherCharacter(selectedDay,p);
 return <section className="card"><Title eye="Best Match · automatische Modellkombination" title="7-Tage-Vorhersage"><ModelRunDetails kind="best" info={modelInfo}/></Title>
   <div className="forecastrows">{forecastDays.map(d=>{const leftPct=((d.min-allMin)/range)*100;const widthPct=(Math.max(1,d.max-d.min)/range)*100;const dayHours=hours.filter(x=>x.time.startsWith(d.date)),character=dayWeatherCharacter(d,dayHours),hz=dailyHazards(d,dayHours);return <button className={`forecastrow ${selected===d.date?'active':''}`} key={d.date} onClick={()=>setSelected(d.date)}>
      <div className="forecast-date"><strong>{formatDateOnly(d.date,{weekday:'short'})}</strong><small>{formatDateOnly(d.date,{day:'2-digit',month:'2-digit'})}</small></div>
      <div className="forecast-icon"><span>{icon(character.code)}</span><small>{character.label}</small>{character.secondary&&<em>{character.secondary}</em>}</div>
      <div className="forecast-meta"><span>💧 {d.precipitation.toFixed(1)} mm · {Math.round(d.probability)} %</span><span>🌬️ {dirArrow(d.direction)} {wind(d.wind,unit)} · Böen {wind(d.gust,unit)}</span></div>
      <div className="forecast-barwrap"><b>{Math.round(d.min)}°</b><div className="forecast-barbg"><div className="forecast-bar" style={{left:`${leftPct}%`,width:`${Math.max(8,widthPct)}%`}}/></div><strong>{Math.round(d.max)}°</strong></div>
      <div className="forecast-hazards">{hz.length?hz.map((h,i)=><span key={i} className={h.level}>{h.label}</span>):<span className="none">keine markanten Hazards</span>}</div>
   </button>})}</div>
   <div className="hourdetail meteogram-day">
     <div className="detailhead"><strong>{formatDateOnly(selectedDay.date,{weekday:'long',day:'2-digit',month:'2-digit'})} · Detailansicht</strong><small>Aktuelle Stunde am gewählten Ort ist vorausgewählt · Ortszeit {zoneCaption(timezone,timezoneAbbreviation)}. Das Diagramm ist stündlich anklickbar; am Desktop mit ← und → navigierbar.</small></div>
     <div className="quickfacts"><span>{icon(selectedCharacter.code)} <b>{selectedCharacter.label}</b>{selectedCharacter.secondary&&<small>{selectedCharacter.secondary}</small>}</span><span>Σ Niederschlag <b>{totalRain.toFixed(1)} mm</b></span><span>max. Niederschlagswahrscheinlichkeit <b>{Math.round(maxProb)} %</b></span><span>max. Wind / Böen <b>{wind(windMax,unit)} · {wind(gustMax,unit)}</b></span></div>
     <div className="detaillegend"><span><i className="temp"/> Temperatur</span><span><i className="apparent"/> Gefühlt</span>{precipLegendTypes.map(type=><span key={type}><i className={precipMeta[type].legendClass}/>{precipMeta[type].label}</span>)}<span><i className="probability"/> Niederschlagswahrscheinlichkeit</span></div>
     <div ref={detailChartRef} className="meteogram-stage" tabIndex={0} onClick={()=>detailChartRef.current?.focus({preventScroll:true})} onKeyDown={handleDetailChartKeyDown} aria-label="Stündliches Wetterdiagramm. Nach einem Klick mit den Pfeiltasten links und rechts zwischen den Stunden wechseln.">
     <svg viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMid meet" className="meteogramsvg">
       <defs>
        <linearGradient id="tempFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#ff9b55" stopOpacity="0.42"/><stop offset="100%" stopColor="#ff9b55" stopOpacity="0.04"/></linearGradient>
        <pattern id="nightHatch" width="5" height="5" patternUnits="userSpaceOnUse" patternTransform="rotate(32)"><rect width="5" height="5" fill="#71809b" opacity="0.055"/><line x1="0" y1="0" x2="0" y2="5" stroke="#71809b" strokeWidth="0.7" opacity="0.18"/></pattern>
        <linearGradient id="rainFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#4aa3ff" stopOpacity="0.96"/><stop offset="100%" stopColor="#235f9c" stopOpacity="0.72"/></linearGradient>
        <linearGradient id="drizzleFill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" stopColor="#86c9ff" stopOpacity="0.92"/><stop offset="100%" stopColor="#4e8ec7" stopOpacity="0.55"/></linearGradient>
        <pattern id="freezingDrizzlePattern" width="5" height="5" patternUnits="userSpaceOnUse"><rect width="5" height="5" fill="#75c9ff"/><path d="M0 5L5 0" stroke="#e9fbff" strokeWidth="1"/><circle cx="1.2" cy="1.2" r=".55" fill="#fff"/></pattern>
        <pattern id="freezingRainPattern" width="5" height="5" patternUnits="userSpaceOnUse"><rect width="5" height="5" fill="#357fd1"/><path d="M0 5L5 0" stroke="#d9f5ff" strokeWidth="1.2"/><circle cx="3.8" cy="3.8" r=".65" fill="#fff"/></pattern>
        <pattern id="showersPattern" width="4" height="4" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="4" height="4" fill="#26c6f7"/><rect width="1.3" height="4" fill="#087ba6" opacity="0.85"/></pattern>
        <pattern id="snowPattern" width="5" height="5" patternUnits="userSpaceOnUse"><rect width="5" height="5" fill="#c8dcff" opacity="0.88"/><circle cx="1.2" cy="1.2" r="0.65" fill="#ffffff"/><circle cx="3.8" cy="3.6" r="0.65" fill="#ffffff"/></pattern>
        <pattern id="snowGrainsPattern" width="5" height="5" patternUnits="userSpaceOnUse"><rect width="5" height="5" fill="#dce9ff"/><rect x="1" y="1" width="1.2" height="1.2" rx=".2" fill="#fff"/><rect x="3.2" y="3.1" width="1.2" height="1.2" rx=".2" fill="#fff"/></pattern>
        <pattern id="snowShowersPattern" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="6" height="6" fill="#d7e8ff"/><rect width="1.3" height="6" fill="#3bc6f3" opacity="0.72"/><circle cx="4.8" cy="1.6" r="0.7" fill="#ffffff"/><circle cx="2.4" cy="4.6" r="0.7" fill="#ffffff"/></pattern>
        <pattern id="sleetPattern" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(35)"><rect width="6" height="6" fill="#7eb7ff" opacity="0.9"/><rect width="1.4" height="6" fill="#f4f7ff" opacity="0.95"/></pattern>
        <pattern id="sleetShowersPattern" width="6" height="6" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="#90c4ff" opacity="0.9"/><rect width="1.3" height="6" fill="#2ec9f5" opacity="0.85"/><circle cx="4.8" cy="1.6" r="0.7" fill="#ffffff"/><circle cx="2.3" cy="4.3" r="0.7" fill="#ffffff"/></pattern>
        <pattern id="thunderstormPattern" width="6" height="6" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="#5865d8"/><path d="M1 0L3 2H2L4 6" stroke="#ffe56b" strokeWidth="1" fill="none"/></pattern>
        <pattern id="thunderstormHailPattern" width="6" height="6" patternUnits="userSpaceOnUse"><rect width="6" height="6" fill="#6147a8"/><path d="M1 0L3 2H2L4 6" stroke="#ffe56b" strokeWidth="1" fill="none"/><circle cx="5" cy="1.2" r=".7" fill="#fff"/></pattern>
       </defs>
       {sunriseX!==null&&sunriseX>left&&<rect x={left} y="0" width={Math.max(0,sunriseX-left)} height={nightBottom} fill="url(#nightHatch)" pointerEvents="none"/>}
       {sunsetX!==null&&sunsetX<W-right&&<rect x={sunsetX} y="0" width={Math.max(0,W-right-sunsetX)} height={nightBottom} fill="url(#nightHatch)" pointerEvents="none"/>}
       {sunriseX!==null&&<g pointerEvents="none"><line x1={sunriseX} x2={sunriseX} y1="0" y2={nightBottom} stroke="#7f91ad" strokeWidth="0.55" opacity="0.42" strokeDasharray="2 2"/><text x={sunriseX+1.4} y="150.4" textAnchor="start" fontSize="3.45" fill="currentColor" opacity="0.68">↗ {sunriseLabel}</text></g>}
       {sunsetX!==null&&<g pointerEvents="none"><line x1={sunsetX} x2={sunsetX} y1="0" y2={nightBottom} stroke="#7f91ad" strokeWidth="0.55" opacity="0.42" strokeDasharray="2 2"/><text x={sunsetX-1.4} y="150.4" textAnchor="end" fontSize="3.45" fill="currentColor" opacity="0.68">{sunsetLabel} ↘</text></g>}
       {[0,1,2,3,4].map(i=>{const y=tempTop+i*(tempBottom-tempTop)/4,val=(tMax-(tempRange/4)*i);return <g key={i}><line x1={left} x2={W-right} y1={y} y2={y} stroke="currentColor" opacity="0.12"/><text x="3.5" y={y+1.8} fontSize="4.0" fill="currentColor" opacity="0.82">{Math.round(val)}°C</text></g>})}
       {[0,1,2].map(i=>{const y=rainTop+i*(rainBottom-rainTop)/2,val=(rainMax/2)*(2-i),prob=(2-i)*50;return <g key={i}><line x1={left} x2={W-right} y1={y} y2={y} stroke="currentColor" opacity="0.09"/><text x="3.5" y={y+1.6} fontSize="3.6" fill="currentColor" opacity="0.68">{val===0?0:val.toFixed(1)} mm</text><text x={W-0.5} y={y+1.6} textAnchor="end" fontSize="3.6" fill="#56d7ff" opacity="0.82">{prob} %</text></g>})}
       {timeIndices.map(i=><line key={i} x1={xAt(i)} x2={xAt(i)} y1={cloudTop} y2={rainBottom} stroke="currentColor" opacity="0.08" strokeDasharray="2 2"/>)}
       {p.map((x,i)=>{const x0=xAt(i),w=Math.max(2.8,plotW/24-1.2),parts=precipSeries[i],totalTop=yRain(parts.total),fill=parts.type!=='none'?precipMeta[parts.type].fill:'';return <g key={x.time}>{parts.total>.001&&parts.type!=='none'&&<rect x={Math.max(left,x0-w/2)} y={totalTop} width={w} height={Math.max(.45,rainBottom-totalTop)} rx="0.7" fill={fill}/>}</g>})}
       <path d={areaPath} fill="url(#tempFill)"/>
       <path d={apparentPath} fill="none" stroke="var(--apparent-line)" opacity="0.96" strokeDasharray="5 4" strokeWidth="1.8" vectorEffect="non-scaling-stroke"/>
       <path d={tempPath} fill="none" stroke="#ff7a37" strokeWidth="1.8" vectorEffect="non-scaling-stroke"/><path d={probabilityPath} fill="none" stroke="#56d7ff" strokeWidth="1.5" strokeDasharray="3 3" vectorEffect="non-scaling-stroke"/>
       {iconIndices.map(i=><g key={i}><text x={xAt(i)} y="13" textAnchor="middle" fontSize="5.2">{icon(p[i].code,p[i].isDay)}</text></g>)}
       {timeIndices.map(i=><g key={i}><text x={xAt(i)} y="157" textAnchor="middle" fontSize="3.8" fill="currentColor" opacity="0.86">{p[i].time.slice(11,13)}:00</text></g>)}
       {[minIdx,maxIdx].map(i=><g key={i}><circle cx={xAt(i)} cy={yTemp(p[i].temperature)} r="1.7" fill="#fff" stroke="#ff7a37" strokeWidth="1"/><text x={xAt(i)} y={yTemp(p[i].temperature)-3.5} textAnchor="middle" fontSize="4.2" fill="#ffb37a">{Math.round(p[i].temperature)}°</text></g>)}
       {p.map((x,i)=>{const x0=i===0?left:(xAt(i-1)+xAt(i))/2,x1=i===p.length-1?W-right:(xAt(i)+xAt(i+1))/2;return <rect key={`hit${x.time}`} x={x0} y="0" width={Math.max(1,x1-x0)} height={H} fill="transparent" className="hour-hit" onClick={()=>setSelectedHour(i)}><title>{`${x.time.slice(11,16)} · ${Math.round(x.temperature)} °C · ${Math.round(x.probability)} % Niederschlagswahrscheinlichkeit · ${wind(x.wind,unit)}, Böen ${wind(x.gust,unit)}`}</title></rect>})}
       <line x1={xAt(selectedHour)} x2={xAt(selectedHour)} y1={cloudTop} y2={rainBottom} stroke="#9ad0ff" opacity="0.85" strokeWidth="1.2"/>
       <circle cx={xAt(selectedHour)} cy={yTemp(currentHour.temperature)} r="2.1" fill="#fff" stroke="#9ad0ff" strokeWidth="1.1"/><circle cx={xAt(selectedHour)} cy={yProb(currentHour.probability)} r="1.7" fill="#56d7ff" stroke="#ffffff" strokeWidth="0.7"/>
     </svg>
     <div className="hour-chart-tooltip persistent" role="status" aria-live="polite" aria-label={`Details für ${currentHour.time.slice(11,16)} Uhr`}>
       <header><button type="button" onClick={()=>moveHour(-1)} aria-label="Vorherige Stunde">‹</button><div><small>{currentHour.time.slice(11,16)} Uhr</small><strong>{icon(currentHour.code,currentHour.isDay)} {label(currentHour.code)}</strong></div><button type="button" onClick={()=>moveHour(1)} aria-label="Nächste Stunde">›</button></header>
       <div className="hour-tooltip-grid compact"><span><small>Temperatur / gefühlt</small><b>{Math.round(currentHour.temperature)}° / {Math.round(currentHour.apparent)}°</b></span><span><small>Niederschlag</small><b>{currentHour.precipitation.toFixed(1)} mm · {Math.round(currentHour.probability)} %</b><em>{currentPrecip.label}</em></span><span><small>Wind / Böen</small><b>{dirArrow(currentHour.direction)} {wind(currentHour.wind,unit)} · {wind(currentHour.gust,unit)}</b></span><span><small>Feuchte / Taupunkt</small><b>{Math.round(currentHour.humidity)} % · {Math.round(currentHour.dewPoint)}°</b></span><span><small>Bewölkung</small><b>{cloudOktas(currentHour.cloud)}/8</b><em>{cloudOktasText(currentHour.cloud).split(' · ')[1]}</em></span><span><small>UV-Index</small><b>{currentHour.uvIndex.toFixed(1)}</b></span></div>
     </div>
     </div>
   </div>
 </section>}

function niceRainScale(maxValue:number){
 const raw=Math.max(1,maxValue),steps=[1,2,5,10,20,50],target=raw/4;
 const step=steps.find(x=>x>=target)??Math.ceil(target/10)*10;
 const max=Math.ceil(raw/step)*step;
 return{max,ticks:Array.from({length:max/step+1},(_,i)=>i*step)};
}
function clamp(v:number,min:number,max:number){return Math.min(max,Math.max(min,v))}
function confidenceColor(v:number){
 const value=Math.max(0,Math.min(100,v));
 const stops=[
  {v:0,c:[232,54,54]},
  {v:25,c:[244,125,48]},
  {v:50,c:[242,201,76]},
  {v:70,c:[199,214,54]},
  {v:85,c:[100,190,65]},
  {v:100,c:[45,193,90]}
 ];
 let a=stops[0],b=stops[stops.length-1];
 for(let i=0;i<stops.length-1;i++){if(value>=stops[i].v&&value<=stops[i+1].v){a=stops[i];b=stops[i+1];break}}
 const t=(value-a.v)/Math.max(1,b.v-a.v);
 const rgb=a.c.map((x,i)=>Math.round(x+(b.c[i]-x)*t));
 return `rgb(${rgb[0]}, ${rgb[1]}, ${rgb[2]})`;
}
function TrendTooltip({active,payload,label,showEnsMean,showClimatology}:{active?:boolean;payload?:any[];label?:string;showEnsMean:boolean;showClimatology:boolean}){if(!active||!payload?.length)return null;const row=payload[0]?.payload;return <div className="charttooltip trend-tooltip"><strong>{label}</strong><div className="tooltip-group"><b>Best Match</b><span>Tmin: {row.bestMin?.toFixed(1)??'–'} °C</span><span>Tmax: {row.bestMax?.toFixed(1)??'–'} °C</span></div>{showEnsMean&&<div className="tooltip-group"><b>ENS-Mittel</b><span>Tmin: {row.minMean.toFixed(1)} °C</span><span>Tmax: {row.maxMean.toFixed(1)} °C</span></div>}{showClimatology&&Number.isFinite(row.climateMin)&&<div className="tooltip-group"><b>Klimatologisches Mittel 1991–2020</b><span>Tmin: {row.climateMin.toFixed(1)} °C</span><span>Tmax: {row.climateMax.toFixed(1)} °C</span></div>}<div className="tooltip-group"><b>P10–P90</b><span>Tmin: {row.minLow.toFixed(1)} bis {row.minHigh.toFixed(1)} °C</span><span>Tmax: {row.maxLow.toFixed(1)} bis {row.maxHigh.toFixed(1)} °C</span></div><div className="tooltip-group compact"><span><b>Prognosekonsistenz:</b> {Math.round(row.confidence)} % ({row.modelCount} Modelle{row.memberCount?` · ${row.memberCount} Mitglieder`:''})</span></div></div>}
function TemperatureLegend({showEnsMean,setShowEnsMean,showClimatology,setShowClimatology}:{showEnsMean:boolean;setShowEnsMean:(v:boolean)=>void;showClimatology:boolean;setShowClimatology:(v:boolean)=>void}){return <div className="trend-legend"><span><i className="area max"/>ENS-Spanne Tmax</span><span><i className="area min"/>ENS-Spanne Tmin</span><span><i className="line best-max"/>Best Match Tmax</span><span><i className="line best-min"/>Best Match Tmin</span><button type="button" className={showEnsMean?'':'inactive'} onClick={()=>setShowEnsMean(!showEnsMean)} aria-pressed={showEnsMean}><i className="line ens-max"/>ENS-Mittel</button><button type="button" className={showClimatology?'':'inactive'} onClick={()=>setShowClimatology(!showClimatology)} aria-pressed={showClimatology}><i className="line climate"/>Klimamittel Tmin/Tmax</button></div>}
function CombinedTrendChart({data,showEnsMean,setShowEnsMean,showClimatology,setShowClimatology}:{data:any[];showEnsMean:boolean;setShowEnsMean:(v:boolean)=>void;showClimatology:boolean;setShowClimatology:(v:boolean)=>void}){const vals=data.flatMap(r=>[r.maxLow,r.maxHigh,r.minLow,r.minHigh,r.bestMax,r.bestMin,showEnsMean?r.maxMean:NaN,showEnsMean?r.minMean:NaN,showClimatology?r.climateMax:NaN,showClimatology?r.climateMin:NaN]).filter((v:number)=>Number.isFinite(v));const minV=Math.floor((Math.min(...vals)-2)/2)*2,maxV=Math.ceil((Math.max(...vals)+2)/2)*2;const ticks=[] as number[];for(let v=minV;v<=maxV;v+=2)ticks.push(v);return <div className="chart trend-combined"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={data} margin={{top:14,right:18,left:10,bottom:34}}><CartesianGrid strokeDasharray="3 3" opacity={.22}/><XAxis dataKey="label" tick={{fontSize:11}} interval={0} label={{value:'Vorhersagetag',position:'insideBottom',offset:-22}}/><YAxis yAxisId="t" domain={[minV,maxV]} ticks={ticks} tick={{fontSize:11}} width={66} tickFormatter={(v)=>`${v}°C`} label={{value:'Temperatur (°C)',angle:-90,position:'insideLeft',offset:4}}/><Tooltip content={<TrendTooltip showEnsMean={showEnsMean} showClimatology={showClimatology}/>}/><Legend verticalAlign="top" height={70} content={<TemperatureLegend showEnsMean={showEnsMean} setShowEnsMean={setShowEnsMean} showClimatology={showClimatology} setShowClimatology={setShowClimatology}/>}/><Area yAxisId="t" stackId="max" type="monotone" dataKey="maxLow" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="max" type="monotone" dataKey="maxBand" stroke="none" fill="#ff845f" fillOpacity={0.22} legendType="none"/><Area yAxisId="t" stackId="min" type="monotone" dataKey="minLow" stroke="none" fill="transparent" legendType="none"/><Area yAxisId="t" stackId="min" type="monotone" dataKey="minBand" stroke="none" fill="#53a9ff" fillOpacity={0.22} legendType="none"/><Line yAxisId="t" hide={!showEnsMean} type="monotone" dataKey="maxMean" stroke="#ffb07b" strokeWidth={1.7} strokeDasharray="5 4" dot={false} legendType="none"/><Line yAxisId="t" hide={!showEnsMean} type="monotone" dataKey="minMean" stroke="#92cfff" strokeWidth={1.7} strokeDasharray="5 4" dot={false} legendType="none"/><Line yAxisId="t" hide={!showClimatology} type="monotone" dataKey="climateMax" stroke="#a86d16" strokeWidth={2.1} strokeDasharray="2 4" dot={false} connectNulls legendType="none"/><Line yAxisId="t" hide={!showClimatology} type="monotone" dataKey="climateMin" stroke="#6c61a8" strokeWidth={2.1} strokeDasharray="2 4" dot={false} connectNulls legendType="none"/><Line yAxisId="t" type="monotone" dataKey="bestMax" stroke="#ff6a37" strokeWidth={3.1} dot={{r:2.4}} connectNulls legendType="none"/><Line yAxisId="t" type="monotone" dataKey="bestMin" stroke="#248dff" strokeWidth={3.1} dot={{r:2.4}} connectNulls legendType="none"/></ComposedChart></ResponsiveContainer></div>}

function RainTooltip({active,payload,label}:{active?:boolean;payload?:any[];label?:string}){if(!active||!payload?.length)return null;const row=payload[0]?.payload;return <div className="charttooltip"><strong>{label}</strong><span>Best Match: {Number(row.bestPrecipitation).toFixed(1)} mm</span><span>P10–P90: {Number(row.precipitationLow).toFixed(1)} bis {Number(row.precipitationHigh).toFixed(1)} mm</span><span>Ensemble-Mittel: {Number(row.precipitationMean).toFixed(1)} mm</span><span>Niederschlagswahrscheinlichkeit: {Math.round(Number(row.precipitationProbability))} %</span></div>}
function RainLegend({showProbability,onToggle}:{showProbability:boolean;onToggle:()=>void}){return <div className="rain-legend"><span><i className="bar"/>Best Match</span><span><i className="line low"/>P10</span><span><i className="line high"/>P90</span><button type="button" className={showProbability?'':'inactive'} onClick={onToggle} aria-pressed={showProbability} title="Niederschlagswahrscheinlichkeit ein-/ausblenden"><i className="line probability"/>Niederschlagswahrscheinlichkeit</button></div>}
function Ensembles({data,models,runs,days,climate,climateLoading,climateError,loading,error}:{data:EnsembleDay[];models:string[];runs:ModelRunMeta[];days:Day[];climate:ClimateDay[];climateLoading:boolean;climateError:string;loading:boolean;error:string}){
 const[showRainProbability,setShowRainProbability]=useState(true),[showEnsMean,setShowEnsMean]=useState(true),[showClimatology,setShowClimatology]=useState(true);
 const climateMap=new Map(climate.map(x=>[x.date,x]));
 const best=new Map(days.map(x=>[x.date,x]));
 const maxModels=Math.max(1,models.length);
 const d=data.filter(x=>best.has(x.date)).slice(0,14).map((x,index)=>{
  const day=best.get(x.date)!;
  const bestMax=day.max,bestMin=day.min,bestPrecipitation=day.precipitation,maxLow=x.maxLow,maxHigh=x.maxHigh,minLow=x.minLow,minHigh=x.minHigh;
  const spread=Math.max(0,((maxHigh-maxLow)+(minHigh-minLow))/2);
  const scoreSpread=clamp(100-spread*7.5,25,97),scoreLead=clamp(100-index*3.7,45,100),scoreModels=clamp(55+(x.modelCount/maxModels)*45,55,100);
  const confidence=Math.round(clamp(scoreSpread*.48+scoreLead*.22+scoreModels*.30,25,97));
  const climateDay=climateMap.get(x.date);return{...x,climateMax:climateDay?.maxMean,climateMin:climateDay?.minMean,label:formatDateOnly(x.date,{weekday:'short',day:'2-digit'}),weekday:formatDateOnly(x.date,{weekday:'short'}),dayLabel:formatDateOnly(x.date,{day:'2-digit',month:'2-digit'}),bestMax,bestMin,bestPrecipitation,code:day.code,maxBand:Math.max(.2,maxHigh-maxLow),minBand:Math.max(.2,minHigh-minLow),confidence}
 });
 const fallback=days.slice(0,14),fallbackMin=Math.min(...fallback.map(x=>x.min)),fallbackMax=Math.max(...fallback.map(x=>x.max)),fallbackRange=Math.max(1,fallbackMax-fallbackMin);
 if(!d.length)return <section className="card ensemble"><Title eye={loading?'ENS-Modelle werden geladen':'ENS-Datenstatus'} title="14-Tage-Ensemble-Trend"><ModelRunDetails kind="ensemble" runs={runs}/></Title><div className={`ensemble-status ${loading?'loading':''}`}><RefreshCw className={loading?'spin':''}/><div><strong>{loading?'Ensemble-Daten werden berechnet …':'Ensemble-Auswertung derzeit nicht vollständig verfügbar'}</strong><span>{loading?'Die 14-Tage-Übersicht wird automatisch ergänzt, sobald genügend Modellläufe vorliegen.':error||'Best Match bleibt als vorläufige Referenz sichtbar.'}</span></div></div><div className="charthead"><h3>14-Tage-Übersicht</h3><p>Vorläufige Best-Match-Spanne; Konsistenzpunkte erscheinen nach erfolgreicher Ensemble-Auswertung.</p></div><div className="ens-overview-grid fallback">{fallback.map(x=>{const left=((x.min-fallbackMin)/fallbackRange)*100,width=((x.max-x.min)/fallbackRange)*100;return <article className="ens-card" key={x.date}><header><div><strong>{formatDateOnly(x.date,{weekday:'short'})}</strong><small>{formatDateOnly(x.date,{day:'2-digit',month:'2-digit'})}</small></div><span className="dot pending"/></header><div className="wx">{icon(x.code,true)}</div><div className="barzone"><div className="barbg"><div className="bestrange" style={{left:`${left}%`,width:`${Math.max(8,width)}%`}}/></div></div><div className="temps"><b>{Math.round(x.min)}°</b><strong>{Math.round(x.max)}°</strong></div><small>{label(x.code)}</small></article>})}</div></section>;
 const rainScale=niceRainScale(Math.max(...d.map(x=>Math.max(x.bestPrecipitation,x.precipitationHigh)),1));
 const overallMin=Math.floor((Math.min(...d.map(x=>Math.min(x.minLow,x.bestMin)))-2)/2)*2,overallMax=Math.ceil((Math.max(...d.map(x=>Math.max(x.maxHigh,x.bestMax)))+2)/2)*2,range=Math.max(1,overallMax-overallMin);
 const hasMembers=d.some(x=>x.memberCount>0),summaryMembers=Math.round(d.reduce((s,x)=>s+x.memberCount,0)/d.length);
 return <section className="card ensemble"><Title eye={`${models.length} verfügbare ENS-Modelle`} title="14-Tage-Ensemble-Trend"><ModelRunDetails kind="ensemble" runs={runs}/></Title>
  <div className="chips">{models.map(x=><span key={x}>{x}</span>)}</div>
  <div className="charthead"><h3>14-Tage-Ensemble-Übersicht</h3><p>Best Match, gewichtetes P10–P90-Intervall und farbiger Konsistenzpunkt pro Tag.</p></div>
  <div className="ens-summary">{hasMembers?<span><b>{summaryMembers}</b> Ensemble-Mitglieder pro Tag im Mittel</span>:<span><b>{models.length}</b> verfügbare Modellmittel</span>}<span><b>{models.length}</b> Modellfamilien aktiv</span></div>
  <div className="consistency-legend" aria-label="Legende der Prognosekonsistenz"><span>gering</span><i/><span>hoch</span><small>0&nbsp;%</small><small>25&nbsp;%</small><small>50&nbsp;%</small><small>75&nbsp;%</small><small>100&nbsp;%</small></div>
  <div className="ens-overview-grid">{d.map(x=>{const ensLeft=((x.minLow-overallMin)/range)*100,ensWidth=((x.maxHigh-x.minLow)/range)*100,bestLeft=((x.bestMin-overallMin)/range)*100,bestWidth=((x.bestMax-x.bestMin)/range)*100;return <article key={x.date} className="ens-card" title={`Prognosekonsistenz ${x.confidence} % · Niederschlagswahrscheinlichkeit ${Math.round(x.precipitationProbability)} % · ${x.modelCount} Modelle${x.memberCount?` · ${x.memberCount} Mitglieder`:''}`}><header><div><strong>{x.weekday}</strong><small>{x.dayLabel}</small></div><span className="dot" style={{background:confidenceColor(x.confidence),boxShadow:`0 0 0 4px color-mix(in srgb, ${confidenceColor(x.confidence)} 18%, transparent)`}} aria-label={`Prognosekonsistenz ${x.confidence} Prozent`}/></header><div className="wx">{icon(x.code,true)}</div><div className="barzone"><div className="barbg"><div className="ensspread" style={{left:`${Math.max(0,ensLeft)}%`,width:`${Math.max(6,ensWidth)}%`}}/><div className="bestrange" style={{left:`${Math.max(0,bestLeft)}%`,width:`${Math.max(8,bestWidth)}%`}}/></div></div><div className="temps"><b>{Math.round(x.bestMin)}°</b><strong>{Math.round(x.bestMax)}°</strong></div><small>{label(x.code)}</small><span className="ens-rainprob">💧 {Math.round(x.precipitationProbability)} %</span></article>})}</div>
  <div className="enslegend"><span><i className="swatch ensemble"/> P10–P90-Temperaturbereich</span><span><i className="swatch best"/> Best-Match Min–Max</span></div>
  <div className="charthead"><h3>Temperaturtrend und Prognoseunsicherheit</h3><p>Best Match, P10–P90, optionales ENS-Mittel und klimatologisches Tagesmittel 1991–2020.{climateLoading?' Klimadaten werden geladen …':climateError?' Klimamittel derzeit nicht verfügbar.':''}</p></div><CombinedTrendChart data={d} showEnsMean={showEnsMean} setShowEnsMean={setShowEnsMean} showClimatology={showClimatology&&climate.length>0} setShowClimatology={setShowClimatology}/>
  <div className="charthead"><h3>Niederschlag</h3><p>Täglicher Best-Match-Niederschlag für den Ort, ergänzt um gewichtetes P10–P90-Intervall und Niederschlagswahrscheinlichkeit.</p></div><div className="chart rain"><ResponsiveContainer width="100%" height="100%"><ComposedChart data={d} margin={{top:16,right:18,left:12,bottom:36}}><CartesianGrid strokeDasharray="3 3" opacity={.22}/><XAxis dataKey="label" tick={{fontSize:11}} interval={0} label={{value:'Vorhersagetag',position:'insideBottom',offset:-24}}/><YAxis yAxisId="mm" domain={[0,rainScale.max]} ticks={rainScale.ticks} tick={{fontSize:11}} width={68} tickFormatter={(v)=>`${v} mm`} label={{value:'Niederschlag (mm)',angle:-90,position:'insideLeft',offset:4}}/><YAxis yAxisId="prob" orientation="right" hide={!showRainProbability} domain={[0,100]} ticks={[0,25,50,75,100]} tick={{fontSize:11}} width={showRainProbability?58:0} tickFormatter={(v)=>`${v} %`} label={{value:'Wahrscheinlichkeit',angle:90,position:'insideRight',offset:4}}/><Tooltip content={<RainTooltip/>}/><Legend verticalAlign="top" height={44} content={<RainLegend showProbability={showRainProbability} onToggle={()=>setShowRainProbability(v=>!v)}/>}/><Bar yAxisId="mm" dataKey="bestPrecipitation" name="bestPrecipitation" fill="#2688ff" radius={[5,5,0,0]}/><Line yAxisId="mm" type="monotone" dataKey="precipitationLow" name="precipitationLow" stroke="#7d8aa0" strokeWidth={1.5} strokeDasharray="4 4" dot={false}/><Line yAxisId="mm" type="monotone" dataKey="precipitationHigh" name="precipitationHigh" stroke="#c4d0df" strokeWidth={2.2} dot={{r:2}}/><Line yAxisId="prob" hide={!showRainProbability} type="monotone" dataKey="precipitationProbability" name="precipitationProbability" stroke="#48d3ff" strokeWidth={2.4} dot={{r:2.4}}/></ComposedChart></ResponsiveContainer></div></section>
}


type WidgetStoredSettings={days:number;dark:boolean;showWind:boolean;showRain:boolean;showHazards:boolean};
const WIDGET_SETTINGS_STORAGE_KEY='mid:0.7.1:widget-settings';
function storedWidgetSettings():WidgetStoredSettings{const defaults={days:4,dark:true,showWind:true,showRain:true,showHazards:true};try{const parsed=JSON.parse(localStorage.getItem(WIDGET_SETTINGS_STORAGE_KEY)||'{}') as Partial<WidgetStoredSettings>,days=Number(parsed.days);return{days:[3,4,5,6,7].includes(days)?days:defaults.days,dark:typeof parsed.dark==='boolean'?parsed.dark:defaults.dark,showWind:typeof parsed.showWind==='boolean'?parsed.showWind:defaults.showWind,showRain:typeof parsed.showRain==='boolean'?parsed.showRain:defaults.showRain,showHazards:typeof parsed.showHazards==='boolean'?parsed.showHazards:defaults.showHazards}}catch{return defaults}}
function Widget({loc,days,hours,unit,elevation,timezone,timezoneAbbreviation}:{loc:Location;days:Day[];hours:Hour[];unit:WindUnit;elevation?:number;timezone:string;timezoneAbbreviation?:string}){
 const initial=useMemo(storedWidgetSettings,[]),[n,setN]=useState(initial.days),[dark,setDark]=useState(initial.dark),[showWind,setShowWind]=useState(initial.showWind),[showRain,setShowRain]=useState(initial.showRain),[showHazards,setShowHazards]=useState(initial.showHazards),ref=useRef<HTMLDivElement>(null);
 useEffect(()=>{try{localStorage.setItem(WIDGET_SETTINGS_STORAGE_KEY,JSON.stringify({days:n,dark,showWind,showRain,showHazards} satisfies WidgetStoredSettings))}catch{}},[n,dark,showWind,showRain,showHazards]);
 const previewDays=days.slice(0,n).map(d=>{const dayHours=hours.filter(x=>x.time.startsWith(d.date));return{...d,hz:dailyHazards(d,dayHours),character:dayWeatherCharacter(d,dayHours)}});
 const widgetWidth=Math.max(360,112+n*82);
 async function png(){if(!ref.current)return;const u=await toPng(ref.current,{pixelRatio:2,cacheBust:true,backgroundColor:dark?'#07111f':'#f7fbff',width:ref.current.scrollWidth,height:ref.current.scrollHeight}),a=document.createElement('a');a.download=`wetter-widget-${loc.name.toLowerCase().replace(/[^a-z0-9]+/gi,'-')}-${n}tage.png`;a.href=u;a.click()}
 return <section className="card widget"><Title eye="Konfigurierbar und exportierbar" title="Widget- und PNG-Generator"/><div className="widgetlayout"><aside className="widget-controls"><label>Tage<select value={n} onChange={e=>setN(Number(e.target.value))}>{[3,4,5,6,7].map(x=><option key={x}>{x}</option>)}</select></label><label><input type="checkbox" checked={dark} onChange={e=>setDark(e.target.checked)}/>Dunkles Widget</label><label><input type="checkbox" checked={showWind} onChange={e=>setShowWind(e.target.checked)}/>Wind</label><label><input type="checkbox" checked={showRain} onChange={e=>setShowRain(e.target.checked)}/>Niederschlag</label><label><input type="checkbox" checked={showHazards} onChange={e=>setShowHazards(e.target.checked)}/>Hazards anzeigen</label><small>Die PNG-Größe passt sich automatisch an Anzahl und Inhalt an. Die Tage bleiben kompakt nebeneinander.</small><button className="primary" onClick={png}><Download size={17}/>PNG erstellen</button></aside><div className="preview widget-preview"><div ref={ref} style={{width:`${widgetWidth}px`}} className={`weatherwidget modern compact ${dark?'dark':'light'} ${showHazards?'hazards-on':'hazards-off'}`}><header><div><span>MID Widget</span><strong>{loc.name}</strong><small>{loc.latitude.toFixed(2)}°N, {loc.longitude.toFixed(2)}°E · {Math.round(elevation??0)} m ü. NHN · Ortszeit {timezoneAbbreviation||timezone}</small></div><b>{n}-Tage-Ausblick</b></header><div className={`widgetgrid days-${n}`}>{previewDays.map(d=>{return <article key={d.date} className="widgetday"><div className="widgetday-head"><strong>{formatDateOnly(d.date,{weekday:'short'})}</strong><small>{formatDateOnly(d.date,{day:'2-digit',month:'2-digit'})}</small></div><div className="widgeticon">{icon(d.character.code)}</div><b className="widgetlabel">{d.character.label}</b><div className="widgettemps"><strong>{Math.round(d.max)}°</strong><em>{Math.round(d.min)}°</em></div><div className="widgetmeta">{showRain&&<span>💧 {d.precipitation.toFixed(1)} mm · {Math.round(d.probability)} %</span>}{showWind&&<span>🌬️ {dirArrow(d.direction)} {wind(d.wind,unit)} · Böen {wind(d.gust,unit)}</span>}</div>{showHazards&&<div className="widgethazards">{d.hz.length?d.hz.map((h,i)=><span key={i} className={h.level}>{h.label}</span>):<span className="ok">keine Hazards</span>}</div>}</article>})}</div><footer><span>Open-Meteo · MID v{VERSION}</span><span>{formatInZone(new Date(),timezone,{day:'2-digit',month:'2-digit',year:'numeric'})}</span></footer></div></div></div></section>
}
function formatModelRunTime(value?:string){if(!value)return'–';const d=new Date(value);return Number.isFinite(d.getTime())?`${d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',timeZone:'UTC'})} ${String(d.getUTCHours()).padStart(2,'0')}Z`:'–'}
function formatAvailabilityTime(value?:string){if(!value)return'–';const d=new Date(value);if(!Number.isFinite(d.getTime()))return'–';const recent=Date.now()-d.getTime()<18*3600000;return recent?`${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}Z`:`${d.toLocaleDateString('de-DE',{day:'2-digit',month:'2-digit',timeZone:'UTC'})} ${String(d.getUTCHours()).padStart(2,'0')}:${String(d.getUTCMinutes()).padStart(2,'0')}Z`}
function ModelRunDetails({kind,info,runs=[]}:{kind:'best'|'ensemble';info?:BestMatchModelInfo|null;runs?:ModelRunMeta[]}){const rows=kind==='best'?(info?.runs??[]):runs;return <details className="model-run-details"><summary title="Modellläufe und Datenstand anzeigen">ⓘ Modellstände</summary><div className="model-run-popover">{kind==='best'?<><strong>Best Match</strong><p>{info?.summary??'Modellinformationen werden geladen …'}</p>{info?.likelyChain&&<p className="model-run-chain"><b>Wahrscheinliche Kette:</b> {info.likelyChain}</p>}</>:<><strong>Aktive Ensemble-Modelle</strong><p>Init- und Verfügbarkeitszeit der tatsächlich erfolgreich eingebundenen Modelle.</p></>}{rows.length?<div className="model-run-list">{rows.map(row=><div className="model-run-row" key={`${row.kind}:${row.id}`}><span>{row.label}</span><small>Init {formatModelRunTime(row.initialisationTime)} · verfügbar {formatAvailabilityTime(row.availabilityTime)}</small></div>)}</div>:<small className="model-run-empty">Modellstände werden geladen oder sind derzeit nicht verfügbar.</small>}</div></details>}
function Title({eye,title,children}:{eye:string;title:string;children?:ReactNode}){return <header className="title"><div><span>{eye}</span><h2>{title}</h2></div>{children&&<div className="title-tools">{children}</div>}</header>}
