#!/usr/bin/env python3
"""Build compact MID ICON-D2-RUC / RUC-EPS point assets.
GRIB decoding runs only in CI/preprocessing, never in Cloudflare Workers.
The builder is fail-closed: mixed grids, missing hourly targets, missing EPS members,
or spatially implausible lookups abort publication before latest.json exists.
"""
from __future__ import annotations
import argparse,bz2,hashlib,json,math,re
from datetime import datetime,timedelta,timezone
from pathlib import Path
import numpy as np
from ruc_pack import DEFAULT_FIELDS,EPS_SUMMARY_FIELDS,pack_cell_major,pack_eps_members,write_meta,UINT32_NODATA

PARAM_MAP={'T_2M':'temperature_2m','TD_2M':'dew_point_2m','RELHUM_2M':'relative_humidity_2m','PMSL':'pressure_msl','U_10M':'u10','V_10M':'v10','VMAX_10M':'wind_gusts_10m','TOT_PREC':'precipitation_acc','CLCT':'cloud_cover','CLCL':'cloud_cover_low','CAPE_ML':'cape','CIN_ML':'convective_inhibition'}
RUC_BBOX=(-3.85,43.18,20.22,58.05)

def read_messages(path:Path,ensemble=False):
    try: from eccodes import codes_grib_new_from_file,codes_get,codes_get_array,codes_release
    except Exception as e: raise SystemExit('eccodes Python package required for production GRIB ingestion') from e
    opener=bz2.open if path.suffix=='.bz2' else open
    with opener(path,'rb') as f:
      while True:
        gid=codes_grib_new_from_file(f)
        if gid is None: break
        try:
          vals=np.asarray(codes_get_array(gid,'values'),dtype=np.float32)
          valid=datetime.strptime(f"{int(codes_get(gid,'validityDate')):08d}{int(codes_get(gid,'validityTime')):04d}",'%Y%m%d%H%M').replace(tzinfo=timezone.utc)
          member=0
          if ensemble:
            for key in ('perturbationNumber','number'):
              try: member=int(codes_get(gid,key));break
              except Exception: pass
          try:units=str(codes_get(gid,'units'))
          except Exception:units=''
          yield valid,member,vals,units
        finally:codes_release(gid)

def read_first_values(path:Path):
    try: from eccodes import codes_grib_new_from_file,codes_get_array,codes_release
    except Exception as e: raise SystemExit('eccodes Python package required for production GRIB ingestion') from e
    opener=bz2.open if path.suffix=='.bz2' else open
    with opener(path,'rb') as f:
      gid=codes_grib_new_from_file(f)
      if gid is None:raise SystemExit(f'empty coordinate GRIB: {path}')
      try:return np.asarray(codes_get_array(gid,'values'),dtype=np.float32)
      finally:codes_release(gid)

def load_native_grid(staging:Path,expected_points:int):
    coord={}
    for param in ('CLAT','CLON'):
      files=sorted((staging/'grid'/param).glob('**/*.grib2*'))
      if not files:raise SystemExit(f'missing staged native-grid coordinate {param}')
      coord[param]=read_first_values(files[0])
      if len(coord[param])!=expected_points:raise SystemExit(f'{param}: coordinate point count differs from forecast grid')
    lats=coord['CLAT'].astype(np.float64);lons=coord['CLON'].astype(np.float64)
    # ICON CLAT/CLON are commonly encoded in radians; accept degrees as a future-safe form.
    if np.nanmax(np.abs(lats))<=math.pi/2+.05 and np.nanmax(np.abs(lons))<=math.pi+.05:
      lats=np.degrees(lats);lons=np.degrees(lons)
    if not np.all(np.isfinite(lats)) or not np.all(np.isfinite(lons)):raise SystemExit('CLAT/CLON contain non-finite native-grid coordinates')
    if np.nanmin(lats)<-90 or np.nanmax(lats)>90 or np.nanmin(lons)<-180 or np.nanmax(lons)>180:raise SystemExit('CLAT/CLON outside geographic coordinate bounds')
    return lats.astype(np.float32),lons.astype(np.float32)

def normalize(name,values,units):
    v=values.astype(np.float32,copy=True);u=units.lower()
    if name in {'temperature_2m','dew_point_2m'} and (u=='k' or 'kelvin' in u or np.nanmedian(v)>100):v-=273.15
    if name=='pressure_msl' and (u=='pa' or np.nanmedian(v)>2000):v/=100
    if name in {'cloud_cover','cloud_cover_low','relative_humidity_2m'} and np.nanmax(v)<=1.2:v*=100
    if name=='convective_inhibition':v=np.abs(v)
    return v

def run_time(value:str):return datetime.fromisoformat(value.replace('Z','+00:00')).astimezone(timezone.utc)
def hybrid_targets(run:str,hours:int,rapid_hours:int=6):
    base=run_time(run)
    horizon_minutes=max(0,int(hours))*60
    rapid_limit=min(horizon_minutes,max(0,int(rapid_hours))*60)
    det_targets=[base+timedelta(minutes=minute) for minute in range(0,rapid_limit+1,15)]
    if rapid_limit<horizon_minutes:
        det_targets.extend(base+timedelta(minutes=minute) for minute in range(rapid_limit+60,horizon_minutes+1,60))
    eps_targets=[base+timedelta(hours=h) for h in range(hours+1)]
    return {'deterministic':det_targets,'eps':eps_targets}

def collect_parameter(files,name,targets,expected_points=None):
    rows={}
    for file in files:
      for valid,_member,vals,units in read_messages(file):
        if valid not in targets:continue
        if expected_points is not None and len(vals)!=expected_points:raise SystemExit(f'{name}: native point count differs from deterministic reference')
        rows[valid]=normalize(name,vals,units)
    missing=[t for t in targets if t not in rows]
    if missing:raise SystemExit(f'{name}: missing hourly targets: '+','.join(t.isoformat() for t in missing[:4]))
    return rows

def build_lookup(lats,lons,output:Path,step=.025,max_distance_km=5.0):
    try: from scipy.spatial import cKDTree
    except Exception as e: raise SystemExit('scipy required to build verified geographic lookup') from e
    lon_min,lat_min,lon_max,lat_max=RUC_BBOX
    xs=np.arange(lon_min,lon_max+step*.5,step,dtype=np.float64);ys=np.arange(lat_min,lat_max+step*.5,step,dtype=np.float64)
    def xyz(lat,lon):
      p=np.radians(lat);l=np.radians(lon);c=np.cos(p);return np.column_stack((c*np.cos(l),c*np.sin(l),np.sin(p)))
    native=xyz(np.asarray(lats,dtype=np.float64),np.asarray(lons,dtype=np.float64));tree=cKDTree(native)
    out=np.full((len(ys),len(xs)),UINT32_NODATA,dtype='<u4')
    batch=32
    for start in range(0,len(ys),batch):
      yb=ys[start:start+batch];lon_grid,lat_grid=np.meshgrid(xs,yb);query=xyz(lat_grid.ravel(),lon_grid.ravel());distance,index=tree.query(query,k=1,workers=-1)
      # chord distance on unit sphere -> great-circle km
      km=2*6371.0088*np.arcsin(np.minimum(1,distance/2));indices=index.astype(np.uint32);indices[km>max_distance_km]=UINT32_NODATA
      out[start:start+len(yb)]=indices.reshape(len(yb),len(xs))
    if np.count_nonzero(out!=UINT32_NODATA)<out.size*.85:raise SystemExit('lookup coverage unexpectedly low')
    (output/'lookup.bin').write_bytes(out.tobytes(order='C'))
    return {'lonMin':float(xs[0]),'latMin':float(ys[0]),'dx':float(step),'dy':float(step),'nx':int(len(xs)),'ny':int(len(ys)),'maxNearestKm':float(max_distance_km),'nativePointCount':int(len(lats)),'bbox':list(RUC_BBOX)}

def collect_eps(files,targets,expected_points):
    rows={t:{} for t in targets}
    for file in files:
      for valid,member,vals,units in read_messages(file,ensemble=True):
        if valid not in rows:continue
        if len(vals)!=expected_points:raise SystemExit('RUC-EPS native point count differs from deterministic RUC grid')
        rows[valid][member]=normalize('precipitation_acc',vals,units)
    members=sorted(set.intersection(*(set(rows[t]) for t in targets))) if targets else []
    if len(members)<10:raise SystemExit(f'RUC-EPS has only {len(members)} common members')
    cube=np.stack([np.stack([rows[t][m] for m in members],axis=0) for t in targets],axis=0)
    interval=np.maximum(0,np.diff(cube,axis=0,prepend=cube[:1]))
    return interval,members


def eps_summary(interval):
    valid=np.isfinite(interval)
    member_count=np.sum(valid,axis=1)
    safe=np.where(valid,interval,np.nan)
    with np.errstate(invalid='ignore'):
      mean=np.nanmean(safe,axis=1)
      q25=np.nanquantile(safe,.25,axis=1)
      q50=np.nanquantile(safe,.50,axis=1)
      q75=np.nanquantile(safe,.75,axis=1)
    wet=np.where(member_count>0,100*np.sum(valid&(interval>.2),axis=1)/np.maximum(member_count,1),np.nan)
    significant=np.where(member_count>0,100*np.sum(valid&(interval>5.0),axis=1)/np.maximum(member_count,1),np.nan)
    return {
      'precipitation_probability':wet,
      'precipitation_probability_significant':significant,
      'precipitation_mean':mean,
      'precipitation_q25':q25,
      'precipitation_q50':q50,
      'precipitation_q75':q75,
    }

def file_info(path:Path):
    digest=hashlib.sha256()
    with path.open('rb') as handle:
      for chunk in iter(lambda:handle.read(1024*1024),b''):digest.update(chunk)
    return {'bytes':path.stat().st_size,'sha256':digest.hexdigest()}

def main():
 p=argparse.ArgumentParser();p.add_argument('--staging',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('--run',required=True);p.add_argument('--hours',type=int,default=14);p.add_argument('--lookup-step',type=float,default=.025);a=p.parse_args();a.output.mkdir(parents=True,exist_ok=True)
 schedule=hybrid_targets(a.run,a.hours)
 det_times=schedule['deterministic'];eps_times=schedule['eps'];all_targets=sorted({*det_times,*eps_times});series={};point_count=None
 for param,name in PARAM_MAP.items():
  files=sorted((a.staging/'deterministic'/param).glob('**/*.grib2*'))
  if not files:raise SystemExit(f'missing staged parameter {param}')
  rows=collect_parameter(files,name,all_targets,point_count)
  if point_count is None:point_count=len(rows[det_times[0]])
  series[name]=rows
 base_grid=load_native_grid(a.staging,point_count)
 det_acc=np.stack([series['precipitation_acc'][t] for t in det_times]);prec=np.maximum(0,np.diff(det_acc,axis=0,prepend=det_acc[:1]))
 u=np.stack([series['u10'][t] for t in det_times]);v=np.stack([series['v10'][t] for t in det_times]);speed=np.hypot(u,v)*1.94384449;direction=(np.degrees(np.arctan2(-u,-v))+360)%360
 fields={}
 for spec in DEFAULT_FIELDS:
  n=spec.name
  if n=='wind_speed_10m':fields[n]=speed
  elif n=='wind_direction_10m':fields[n]=direction
  elif n=='wind_gusts_10m':fields[n]=np.stack([series[n][t] for t in det_times])*1.94384449
  elif n=='precipitation':fields[n]=prec
  else:fields[n]=np.stack([series[n][t] for t in det_times])
 det=a.output/'deterministic.bin';det.write_bytes(pack_cell_major(fields,DEFAULT_FIELDS))
 grid=build_lookup(base_grid[0],base_grid[1],a.output,a.lookup_step)
 eps_files=sorted((a.staging/'eps'/'TOT_PREC').glob('**/*.grib2*'))
 if not eps_files:raise SystemExit('missing staged RUC-EPS TOT_PREC')
 eps,members=collect_eps(eps_files,eps_times,point_count);eps_path=a.output/'eps-members.bin';eps_path.write_bytes(pack_eps_members(eps,.01))
 summary_path=a.output/'eps-summary.bin';summary_path.write_bytes(pack_cell_major(eps_summary(eps),EPS_SUMMARY_FIELDS))
 run_key=re.sub(r'[^0-9A-Za-z_-]','',a.run);lookup_path=a.output/'lookup.bin'
 object_paths={'deterministic.bin':det,'eps-summary.bin':summary_path,'eps-members.bin':eps_path,'lookup.bin':lookup_path}
 objects={name:file_info(path) for name,path in object_paths.items()}
 det_serialized=[t.strftime('%Y-%m-%dT%H:%M') for t in det_times];eps_serialized=[t.strftime('%Y-%m-%dT%H:%M') for t in eps_times]
 write_meta(a.output/'latest.json',run=a.run,times=det_serialized,point_count=point_count,specs=DEFAULT_FIELDS,grid=grid,deterministic_key=f'runs/{run_key}/deterministic.bin',eps_key=f'runs/{run_key}/eps-members.bin',eps_summary_key=f'runs/{run_key}/eps-summary.bin',lookup_key=f'runs/{run_key}/lookup.bin',member_count=len(members),eps_scale=.01,objects=objects,deterministic_times=det_serialized,eps_summary_times=eps_serialized,eps_times=eps_serialized)
 print(json.dumps({'run':a.run,'deterministicTimes':len(det_times),'epsTimes':len(eps_times),'points':point_count,'members':len(members),'detBytes':det.stat().st_size,'epsSummaryBytes':summary_path.stat().st_size,'epsBytes':eps_path.stat().st_size,'lookupBytes':lookup_path.stat().st_size}))
if __name__=='__main__':main()
