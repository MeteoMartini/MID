import {defineConfig} from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins:[react()],
  base:'./',
  build:{
    target:'es2020',
    cssCodeSplit:true,
    sourcemap:false,
    reportCompressedSize:false,
    chunkSizeWarningLimit:750,
    rollupOptions:{
      output:{
        manualChunks(id){
          if(!id.includes('node_modules'))return;
          if(id.includes('recharts')||id.includes('d3-'))return 'charts';
          if(id.includes('leaflet'))return 'maps';
          if(id.includes('html-to-image'))return 'export';
          if(id.includes('jsfive'))return 'hdf5';
          if(id.includes('react-dom')||id.includes('/react/'))return 'react-vendor';
          if(id.includes('lucide-react'))return 'icons';
          return 'vendor';
        }
      }
    }
  }
});
