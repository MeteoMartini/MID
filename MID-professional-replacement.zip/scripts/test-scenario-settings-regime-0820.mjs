import {readFile} from 'node:fs/promises';
const [weather,ensemble,styles,verification,twinSettings,panel,app]=await Promise.all([
 readFile(new URL('../src/weather.ts',import.meta.url),'utf8'),
 readFile(new URL('../src/EnsemblePanel.tsx',import.meta.url),'utf8'),
 readFile(new URL('../src/styles.css',import.meta.url),'utf8'),
 readFile(new URL('../src/forecastVerification.ts',import.meta.url),'utf8'),
 readFile(new URL('../src/WeatherTwinSettings.tsx',import.meta.url),'utf8'),
 readFile(new URL('../src/ForecastVerificationPanel.tsx',import.meta.url),'utf8'),
 readFile(new URL('../src/App.tsx',import.meta.url),'utf8')
]);
const failures=[];
const need=(label,text,token)=>{if(!text.includes(token))failures.push(`${label}: ${token}`)};
const reject=(label,text,token)=>{if(text.includes(token))failures.push(`${label} enthält weiterhin: ${token}`)};
for(const token of ['filterScenarioTrajectories(','trajectoryRainTotal(','baselineRain*7+60','item.modelLabels.length>=2','precipitationTotal:number','gustDelta?:number'])need('Robuste Szenariocluster',weather,token);
for(const token of ['className={index===0?\'dominant\':\'\'}','Tagesniederschlag','Balkenhöhe = mittlere Menge in mm','Temperatur- und Windunterschiede','gegen A'])need('Szenariodarstellung',ensemble,token);
reject('Szenariodarstellung',ensemble,"className={index===0?'primary':''}");
for(const token of ['.ensemble-scenarios article.dominant{','.ensemble-scenario-metrics{','.ensemble-scenario-strip-label{'])need('Szenario-Kontrast/CSS',styles,token);
for(const token of ['Lokale Bias-Korrektur','Regenwahrscheinlichkeit kalibrieren','Persönliche Empfehlungen'])need('Wetterzwilling-Einstellungen',twinSettings,token);
reject('Rückblickmodul',panel,'checked={settings.personalRecommendations}');
for(const token of ["'regen'","regen:'Regenlage'",'function hourlyRainEvidence(','longestWetHours>=8&&wetHours>=10','max12hPrecipitation>=25',"return wind>=12?'front':'regen'"])need('Dauerregen-Plausibilisierung',verification,token);
reject('Dauerregen-Plausibilisierung',verification,"if(precipitation>=5||[63,65].includes(code))return'dauerregen'");
need('Stündliche Regimeauswertung',app,'recordForecastCapture(favoriteKey(loc),days,ens,loc,hours)');
if(failures.length){console.error('Szenario-/Einstellungs-/Dauerregen-Prüfung fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('Szenariocluster geprüft: kontrastreich, ausreißergeschützt und mit klaren Niederschlags-/Temperatur-/Böenkennzahlen; Wetterzwilling-Optionen zentralisiert und Dauerregen nur mit Dauerbeleg klassifiziert.');
