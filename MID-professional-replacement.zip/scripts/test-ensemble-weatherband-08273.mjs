import {readFileSync} from 'node:fs';
const fail=[];
const panel=readFileSync(new URL('../src/EnsemblePanel.tsx',import.meta.url),'utf8');
const css=readFileSync(new URL('../src/styles.css',import.meta.url),'utf8');
const pkg=JSON.parse(readFileSync(new URL('../package.json',import.meta.url),'utf8'));
const baseline=JSON.parse(readFileSync(new URL('../MID_BASELINE.json',import.meta.url),'utf8'));
if(pkg.version!=='0.8.27.3')fail.push(`package.json: ${pkg.version}`);
if(baseline.releaseVersion!=='0.8.27.3')fail.push(`MID_BASELINE.json: ${baseline.releaseVersion}`);
if(!panel.includes('cellWidth=Math.max(10,Math.min(dayWidth*.88,dayWidth-2))'))fail.push('Tageskästchen-Zentrierung fehlt.');
if(!panel.includes("wrapperStyle={{zIndex:140,maxWidth:'calc(100vw - 16px)'}}"))fail.push('Tooltip-Z-Index-Anhebung fehlt.');
if(!panel.includes('fill="#ffd84a"'))fail.push('Neues Gewittersymbol fehlt.');
if(!css.includes('MID v0.8.27.3 · stabil sichtbare Ensemble-Tooltips'))fail.push('CSS-Anpassungen fehlen.');
if(fail.length){
  console.error('MID v0.8.27.3 Regression fehlgeschlagen:\n- '+fail.join('\n- '));
  process.exit(1);
}
console.log('MID v0.8.27.3 Tooltip-/Wetterband-Regression bestanden.');
