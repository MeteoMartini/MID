import {readFile} from 'node:fs/promises';
const [radar,dwdMap,hymec,maps,data,worker,styles,pkg,baseline]=await Promise.all([
 readFile(new URL('../src/DwdPrecipitationTypeRadar.tsx',import.meta.url),'utf8'),readFile(new URL('../src/DwdPrecipitationMap.tsx',import.meta.url),'utf8'),readFile(new URL('../src/HymecNgSource.ts',import.meta.url),'utf8'),readFile(new URL('../src/WeatherMapsPanel.tsx',import.meta.url),'utf8'),readFile(new URL('../src/WeatherMapsData.ts',import.meta.url),'utf8'),readFile(new URL('../worker/metar-proxy.js',import.meta.url),'utf8'),readFile(new URL('../src/styles.css',import.meta.url),'utf8'),readFile(new URL('../package.json',import.meta.url),'utf8'),readFile(new URL('../MID_BASELINE.json',import.meta.url),'utf8')
]);
const failures=[];const need=(label,text,token)=>{if(!text.includes(token))failures.push(`${label}: ${token}`)};const reject=(label,text,token)=>{if(text.includes(token))failures.push(`${label} sollte fehlen: ${token}`)};
for(const token of ['dwd-precipitation-type-meta','loadHymecNgMetadata','sampleHymecNg','markerVisible','dwd-precip-type-radar__point-strip','Wolken + Niederschlagsart','<b>Radar</b>','<b>Sat</b>'])need('Radar',radar,token);
for(const token of ['Marker position={[latitude,longitude]}','<HymecNgOverlay','WMSTileLayer'])need('DWD-Karte',dwdMap,token);
for(const token of ['projectWgs84(latitude,longitude,raster.projection)','hymecNgSourceIndex'])need('HymecNG',hymec,token);
for(const token of ['dwd-hymecng-meta','dwd-hymecng-file','wmsLayerNameMatches','dwd:Icon_reg025_fd_pl_OMEGA','dwd:Icon-eps_reg025_fd_sl_VMAX10M12H','dwd:Gewitterzellen','dwd:NCEW_EU','dwd:Icon-d2_reg002_fd_sl_WW','...WEATHER_MAP_LAYER_CONFIG.keys()'])need('Worker',worker,token);
for(const token of ['Zeitschritt</span>','times.map((value,index)','aktueller Dienststand','Bei leerer Karte liegt im sichtbaren Ausschnitt','SIGWX-/Wettercode-Karten der ICON-Serie'])need('Wetterkarten UI',maps,token);
for(const token of ["WeatherMapModelId='icon-d2'|'icon-eu'|'icon'|'icon-eps'|'aicon'|'nowcastmix'",'Icon-d2_reg002_fd_sl_QFF','Icon-d2_reg002_fd_sl_WW','Icon-eu_reg00625_fd_sl_WW','Icon_reg025_fd_sl_WW','Aicon_reg025_fd_sl_WW','SIGWX / Wettercode','Signifikantes Wetter'])need('Wetterkartendaten',data,token);
for(const token of ['DWD_SOURCE_RASTER_GRID','RasterPolynomial','radarCropWindow','dwdPrecipitationTypeImagePosition'])reject('Alte PNG-Verortung',radar,token);
for(const token of ['.dwd-precip-type-radar__map-shell','.mid-dwd-location-pin','dwd-precip-type-radar__point-strip'])need('CSS',styles,token);
const pv=JSON.parse(pkg).version,bv=JSON.parse(baseline).releaseVersion,wv=worker.match(/const WORKER_VERSION='([^']+)'/)?.[1];if(pv!==bv||pv!==wv)failures.push(`Versionsabweichung: ${pv}/${bv}/${wv}`);if(!baseline.includes('scripts/test-radar-weather-maps-interaction-09220.mjs'))failures.push('Baseline-Test fehlt');
if(failures.length){console.error('Radar-/Wetterkarten-Upgrade fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('Native DWD-WGS84-Radarinteraktion und erweiterte Modellkarten inkl. ICON-D2/SIGWX erfolgreich geprüft.');
