import {readFile} from 'node:fs/promises';
const [runner,pkgText,baselineText,workflow,workflowSource]=await Promise.all([
 readFile(new URL('./run-regressions.mjs',import.meta.url),'utf8'),
 readFile(new URL('../package.json',import.meta.url),'utf8'),
 readFile(new URL('../MID_BASELINE.json',import.meta.url),'utf8'),
 readFile(new URL('../.github/workflows/dependency-audit.yml',import.meta.url),'utf8'),
 readFile(new URL('../ci/github/workflows/dependency-audit.yml',import.meta.url),'utf8')
]);
const pkg=JSON.parse(pkgText),baseline=JSON.parse(baselineText),failures=[];
const need=(label,text,token)=>{if(!text.includes(token))failures.push(`${label}: ${token}`)};
for(const token of [
 "const localBin=path.join(root,'node_modules','.bin')",
 "PATH:[localBin,process.env.PATH??''].filter(Boolean).join(path.delimiter)",
 'env:childEnv'
])need('Regression-Runner',runner,token);
if(pkg.scripts?.['test:regressions']!=='node scripts/run-regressions.mjs')failures.push('package.json: test:regressions fehlt oder ist falsch.');
for(const [label,text] of [['GitHub-Workflow',workflow],['Workflow-Quelle',workflowSource]]){
 need(label,text,'npm run test:regressions');
 if(text.includes('          node scripts/run-regressions.mjs'))failures.push(`${label}: direkter Runner-Aufruf umgeht weiterhin npm-PATH.`);
}
if(pkg.version!==baseline.releaseVersion)failures.push(`Version/Baseline nicht synchron: ${pkg.version}/${baseline.releaseVersion}`);
if(!baseline.regressionTests?.includes('scripts/test-regression-runner-local-bin-09365.mjs'))failures.push('Baseline registriert den Runner-Schutztest nicht.');
if(failures.length){console.error(`MID Regression-Runner-PATH-Schutz fehlgeschlagen:\n- ${failures.join('\n- ')}`);process.exit(1)}
console.log('MID: Regression-Runner priorisiert projektlokale node_modules/.bin-Werkzeuge und Dependency-Audit startet die Suite über npm.');
