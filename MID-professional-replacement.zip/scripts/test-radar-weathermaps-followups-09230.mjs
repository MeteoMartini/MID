import {readFile} from 'node:fs/promises';
const [radar,dwdMap,hymec,cockpit,data,worker]=await Promise.all([
 readFile(new URL('../src/DwdPrecipitationTypeRadar.tsx',import.meta.url),'utf8'),readFile(new URL('../src/DwdPrecipitationMap.tsx',import.meta.url),'utf8'),readFile(new URL('../src/HymecNgSource.ts',import.meta.url),'utf8'),readFile(new URL('../src/ForecastCockpit.tsx',import.meta.url),'utf8'),readFile(new URL('../src/WeatherMapsData.ts',import.meta.url),'utf8'),readFile(new URL('../worker/metar-proxy.js',import.meta.url),'utf8')
]);
const failures=[];const need=(label,text,token)=>{if(!text.includes(token))failures.push(`${label}: ${token}`)};
for(const token of ['Wolken + Niederschlagsart','<b>Radar</b>','<b>Sat</b>',"buildWorkerUrl(base,'dwd-precipitation-type-image'",'dwd-precip-type-radar__source-image'])need('Radar',radar,token);
for(const token of ['center={[latitude,longitude]} zoom={8}','Marker position={[latitude,longitude]}','<HymecNgOverlay'])need('WGS84-Karte',dwdMap,token);
for(const token of ['projectWgs84(latitude,longitude,raster.projection)','loadHymecNgRaster'])need('HymecNG',hymec,token);
for(const token of ['chartViewportRef','chartViewportWidth','ResizeObserver','chartWidth=Math.max(1040,chartViewportWidth)'])need('24h-Meteogramm',cockpit,token);
for(const token of ['icon-d2-pressure-thetae','icon-d2-pressure-sigwx','icon-d2-pressure-precip','icon-eu-sigwx','icon-sigwx','aicon-sigwx'])need('Wetterkarten-Daten',data,token);
for(const token of ["mode==='weather-map-grid'","modelCandidates=['dwd_icon_d2','icon_d2']","['dwd:Icon-eu_reg00625_fd_sl_WW',{forecast:true}]","['dwd:Icon_reg025_fd_sl_WW',{forecast:true}]","['dwd:Aicon_reg025_fd_sl_WW',{forecast:true}]","...WEATHER_MAP_LAYER_CONFIG.keys()",'dwd-hymecng-meta','dwd-hymecng-file'])need('Worker-Layer',worker,token);
if(failures.length){console.error('Radar-/Karten-Folgefixes fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('Radar-/Karten-Folgefixes: amtliches DWD-Originalprodukt, Desktop-Meteogramm und SIGWX-Angebot erfolgreich geprüft.');
