import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import {fileURLToPath,pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=name=>fs.readFileSync(path.join(root,name),'utf8');
const workerSource=read('worker/metar-proxy.js');
const panel=read('src/SynopticPanel.tsx');
const synoptic=read('src/synoptic.ts');
const styles=read('src/styles.css');

const requiredFields=[
 'temperature_2m','relative_humidity_2m','dew_point_2m','pressure_msl',
 'wind_speed_10m','wind_direction_10m','wind_gusts_10m','precipitation',
 'cloud_cover','cloud_cover_low','cloud_cover_mid','cloud_cover_high',
 'temperature_850hPa','relative_humidity_850hPa','wind_speed_850hPa','wind_direction_850hPa',
 'temperature_700hPa','relative_humidity_700hPa','geopotential_height_500hPa'
];
for(const field of requiredFields)assert.ok(workerSource.includes(`'${field}'`),`Synoptikfeld fehlt: ${field}`);

const requiredSignals=[
 ['thermal-gradient','Temperaturgradient'],
 ['moisture-gradient','Taupunkt-/Feuchtegradient'],
 ['pressure-trough','Druckrinne'],
 ['wind-shift','Winddrehung'],
 ['steering-flow','850-hPa-Strömung'],
 ['precipitation','Niederschlagsstützung'],
 ['cloud-band','Wolkenband'],
 ['temperature-change','Temperaturänderung'],
 ['gust-change','Böenänderung']
];
for(const [key,label] of requiredSignals){assert.ok(workerSource.includes(`'${key}'`),`Diagnosesignal fehlt: ${key}`);assert.ok(workerSource.includes(`'${label}'`),`Diagnosebezeichnung fehlt: ${label}`)}
for(const token of ['FrontEvidenceGraphic','Multiparametrische Frontprüfung','kein Fronttyp allein aus einer Einzelgröße','Fronttyp-Konflikt','Keine Fronttiming-Assimilation'])assert.ok(panel.includes(token),`Multiparametrische UI fehlt: ${token}`);
for(const token of ['synoptic-evidence-grid','synoptic-agreement-banner','synoptic-timing-conflict','grid-template-columns:repeat(3,minmax(0,1fr))','@media(max-width:360px)'])assert.ok(styles.includes(token),`Responsive Diagnostikgestaltung fehlt: ${token}`);

// Station vectors must originate at the station core, extend north at 0°, and rotate to the flow direction.
assert.ok(panel.includes('const windToDirection=(from:number)=>normalizeDirection(from+180)'), 'Meteorologische Herkunftsrichtung wird nicht in Strömungsrichtung umgerechnet');
assert.ok(panel.includes('--wind-angle:${to}deg'), 'Stationsvektor verwendet nicht die Strömungsrichtung');
assert.ok(styles.includes('top:calc(21px - var(--wind-length))'), 'Stationsvektor erstreckt sich bei 0° nicht nach Norden');
assert.ok(styles.includes('transform-origin:1px var(--wind-length)'), 'Stationsvektor dreht nicht um den Stationskern');
assert.ok(styles.includes('.synoptic-station-plot .wind:before'), 'Stationsvektor besitzt keine eindeutige Pfeilspitze');

const require=createRequire(import.meta.url);let ts;try{ts=require('typescript')}catch{ts=require('/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript')}
for(const [file,code,jsx] of [['SynopticPanel.tsx',panel,true],['synoptic.ts',synoptic,false]]){
 const compilerOptions={target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext};if(jsx)compilerOptions.jsx=ts.JsxEmit.ReactJSX;const result=ts.transpileModule(code,{compilerOptions,fileName:file,reportDiagnostics:true});
 const errors=(result.diagnostics||[]).filter(item=>item.category===ts.DiagnosticCategory.Error);
 assert.equal(errors.length,0,errors.map(item=>ts.flattenDiagnosticMessageText(item.messageText,' ')).join('\n'));
}

const temp=path.join(os.tmpdir(),`mid-worker-synoptic-0910-${Date.now()}.mjs`);fs.writeFileSync(temp,workerSource);
try{
 const worker=await import(`${pathToFileURL(temp).href}?v=${Date.now()}`);
 const baseSignals=requiredSignals.map(([key,label])=>({key,label,value:1,unit:'',support:.75,status:'strong',available:true}));
 const candidate=(modelId,type,arrivalAt,score=78)=>({modelId,modelLabel:modelId,type,arrivalAt,score,confidence:'high',line:[[50,7],[52,9]],signals:baseSignals,summary:'',coherence:.76,supportingSignalCount:9,availableSignalCount:9,contradictionCount:0,approachBearingDeg:285,motionDirectionDeg:105});
 const conflict=worker.synopticAgreement([candidate('icon','warm','2026-08-03T09:00:00Z'),candidate('ecmwf','cold','2026-08-03T18:00:00Z')]);
 assert.equal(conflict.status,'conflict','Gleich starke Warm-/Kaltfrontsignale müssen als Fronttyp-Konflikt ausgewiesen werden');
 assert.equal(conflict.type,'none','Bei Fronttyp-Konflikt darf kein künstlicher Fronttyp entstehen');
 assert.deepEqual(conflict.dominantModelIds,[],'Bei Fronttyp-Konflikt darf kein Modell als dominanter Frontcluster behauptet werden');
 const coherent=worker.synopticAgreement([candidate('icon','cold','2026-08-03T14:00:00Z'),candidate('ecmwf','cold','2026-08-03T16:00:00Z'),candidate('gfs','warm','2026-08-03T21:00:00Z',52)]);
 assert.equal(coherent.type,'cold','Mehrheitlich kohärenter Kaltfrontcluster wird nicht erkannt');
 assert.ok(coherent.dominantModelIds.includes('icon')&&coherent.dominantModelIds.includes('ecmwf'),'Dominanter Modellcluster unvollständig');
 assert.ok(coherent.parameterCount>=9,'Anzahl genutzter Diagnoseparameter wird nicht ausgewiesen');
 const crossing=worker.synopticFlowCrossing({available:true,magnitude:2,dLat:1,dLon:0},270,30);
 assert.equal(crossing.available,true,'850-hPa-Strömung wird nicht als Frontquerung bewertet');
 assert.ok(crossing.support>=0&&crossing.support<=1,'Strömungsstützung außerhalb 0–1');
}finally{fs.rmSync(temp,{force:true})}

console.log('MID-Synoptik v0.9.1.0 geprüft: neun Diagnosefelder, konfliktfeste Multimodellklassifikation, vollständige Evidenzanzeige und eindeutig ausgerichtete Windvektoren.');
