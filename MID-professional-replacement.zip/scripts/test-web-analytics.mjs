import {readFile} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const read=relative=>readFile(path.join(root,relative),'utf8');
const [vite,main,module,app,styles,env,install,deploy]=await Promise.all([read('vite.config.ts'),read('src/main.tsx'),read('src/webAnalytics.ts'),read('src/App.tsx'),read('src/styles.css'),read('.env.example'),read('.github/workflows/install-mid.yml'),read('.github/workflows/deploy.yml')]);
const failures=[];
for(const token of ['static.cloudflareinsights.com/beacon.min.js','VITE_CLOUDFLARE_WEB_ANALYTICS_TOKEN',"'data-cf-beacon':JSON.stringify({token,spa:true})", "type:'module'"])if(!vite.includes(token))failures.push(`Vite-Beacon-Injektion fehlt: ${token}`);
for(const token of ["import {startWebAnalyticsDiagnostics} from './webAnalytics';",'startWebAnalyticsDiagnostics();'])if(!main.includes(token))failures.push(`Analytics-Start fehlt: ${token}`);
for(const token of ['missing-token','missing-snippet','blocked','mid:web-analytics-status','performance.getEntriesByName'])if(!module.includes(token))failures.push(`Analytics-Diagnose fehlt: ${token}`);
for(const token of ['Cloudflare Web Analytics','system-analytics-card','Beacon aktiv','Token fehlt','Beacon blockiert'])if(!app.includes(token))failures.push(`Analytics-Systemstatus fehlt: ${token}`);
if(!styles.includes('.system-analytics-card'))failures.push('Analytics-Systemstatus-CSS fehlt.');
if(!env.includes('VITE_CLOUDFLARE_WEB_ANALYTICS_TOKEN'))failures.push('Analytics-Variable fehlt in .env.example.');
for(const [name,text] of [['install-mid.yml',install],['deploy.yml',deploy]])if(!text.includes('VITE_CLOUDFLARE_WEB_ANALYTICS_TOKEN: ${{ vars.VITE_CLOUDFLARE_WEB_ANALYTICS_TOKEN }}'))failures.push(`${name}: Analytics-Buildvariable fehlt.`);
if(failures.length){console.error('Cloudflare-Web-Analytics-Prüfung fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('Cloudflare Web Analytics geprüft: manueller Beacon für GitHub Pages, SPA-Modus, Buildvariable und sichtbare Laufzeitdiagnose sind vorhanden.');
