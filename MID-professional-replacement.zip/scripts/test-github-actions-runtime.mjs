import {readFile,readdir} from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const workflowsDir=path.join(root,'.github','workflows');
const workflowNames=(await readdir(workflowsDir)).filter(name=>/\.ya?ml$/i.test(name));
const workflows=Object.fromEntries(await Promise.all(workflowNames.map(async name=>[name,await readFile(path.join(workflowsDir,name),'utf8')])));
const all=Object.values(workflows).join('\n');
const lock=JSON.parse(await readFile(path.join(root,'package-lock.json'),'utf8'));
const failures=[];
const action=(name,major)=>new RegExp(`uses:\\s*${name.replace('/','\\/')}@[0-9a-f]{40}\\s*#\\s*v${major}(?:\\.|\\b)`);

for(const [name,source] of Object.entries(workflows)){
  for(const line of source.match(/^\s*uses:\s*[^\s]+/gm)??[])if(!/@[0-9a-f]{40}$/.test(line.trim()))failures.push(`${name}: Action ist nicht auf einen vollständigen Commit-SHA festgeschrieben: ${line.trim()}`);
  if(source.includes('rm -f package-lock.json'))failures.push(`${name}: package-lock.json wird weiterhin gelöscht`);
  if(source.includes('fetch-retry-maxtimeout 120000'))failures.push(`${name}: veraltete zweiminütige npm-Retry-Wartezeit gefunden`);
}

for(const [name,major] of [['actions/checkout',6],['actions/setup-node',6],['actions/configure-pages',6],['actions/upload-pages-artifact',5],['actions/deploy-pages',5]]){
  if(!action(name,major).test(all))failures.push(`${name} v${major} mit vollständigem SHA fehlt`);
}

const install=workflows['install-mid.yml']||'';
const deploy=workflows['deploy.yml']||'';
for(const token of ['MID-professional-replacement.zip','npm run verify','npm run audit:dependencies','git push origin HEAD:main','Geprüfte MID-Workflows aktualisieren'])if(!install.includes(token))failures.push(`install-mid.yml: ${token} fehlt`);
if(!deploy.includes('paths-ignore:')||!deploy.includes('MID-professional-replacement.zip'))failures.push('deploy.yml: reiner ZIP-Upload wird nicht vom vorzeitigen Parallel-Deployment ausgeschlossen');
if(!workflows['dependency-audit.yml']?.includes('npm run audit:all'))failures.push('dependency-audit.yml: vollständiger regelmäßiger npm-Audit fehlt');

for(const [name,entry] of Object.entries(lock.packages??{})){
  const resolved=entry&&typeof entry==='object'?entry.resolved:undefined;
  if(typeof resolved==='string'&&/internal\.api\.openai\.org|applied-caas-gateway|localhost|127\.0\.0\.1/i.test(resolved))failures.push(`package-lock.json: nicht öffentliche Paketquelle bei ${name||'(root)'}`);
}

if(failures.length){console.error('GitHub-Actions-/Release-Pipeline-Prüfung fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('Release-Pipeline geprüft: öffentliche npm-URLs, SHA-fixierte Actions, Least-Privilege-Jobs, Abhängigkeitsaudit und direkte ZIP-Installation.');
