import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('../src/App.tsx', import.meta.url),'utf8');
const css=readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
const pkg=JSON.parse(readFileSync(new URL('../package.json', import.meta.url),'utf8'));
const fails=[];
if(pkg.version!=='0.8.27.5')fails.push(`package.json: ${pkg.version}`);
if(!app.includes('UVI max.'))fails.push('UVI-Pille fehlt.');
if(!app.includes('maxUvi=uviValues.length?Math.max(...uviValues):Number.NaN'))fails.push('Max-UVI-Berechnung fehlt.');
if(!css.includes('MID v0.8.27.5 · kompaktere Tagesdetail-Pillen mit UVI-Maximum'))fails.push('Quickfacts-CSS-Anpassung fehlt.');
if(fails.length){
  console.error('Regression fehlgeschlagen:\n- '+fails.join('\n- '));
  process.exit(1);
}
console.log('MID v0.8.27.5 Detail-Pillen-Regression bestanden.');
