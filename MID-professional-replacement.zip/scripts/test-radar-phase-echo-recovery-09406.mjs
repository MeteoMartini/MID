import {readFile} from 'node:fs/promises';
import assert from 'node:assert/strict';

const phase=await readFile(new URL('../src/RadarModelPrecipTypeOverlay.tsx',import.meta.url),'utf8');
assert.match(phase,/function cellEchoSummary\(/,'radar/model phase overlay must sample echo coverage per cell');
assert.match(phase,/subdivisions=2/,'phase overlay should sample each model cell more densely');
assert.match(phase,/minimumDbzFor\(phase\)/,'phase overlay should use dedicated, lighter echo thresholds');
assert.match(phase,/phase\.phase==='uncertain'&&!phase\.modelEvidence\)continue/,'only fully unsupported uncertain cells may be skipped');
assert.doesNotMatch(phase,/phase\.phase==='uncertain'\|\|phase\.confidence==='eingeschränkt'\)continue/,'restricted-confidence fields must no longer be dropped wholesale');
console.log('ok - precipitation-type echo recovery safeguards verified');
