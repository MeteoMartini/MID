import {readFile} from 'node:fs/promises';
const [radar,hymec,worker,pkg,baseline]=await Promise.all([
 readFile(new URL('../src/DwdPrecipitationTypeRadar.tsx',import.meta.url),'utf8'),readFile(new URL('../src/HymecNgSource.ts',import.meta.url),'utf8'),readFile(new URL('../worker/metar-proxy.js',import.meta.url),'utf8'),readFile(new URL('../package.json',import.meta.url),'utf8'),readFile(new URL('../MID_BASELINE.json',import.meta.url),'utf8')
]);
const failures=[];const need=(label,text,token)=>{if(!text.includes(token))failures.push(`${label}: ${token}`)};
for(const token of ['type RadarMeta={error?:string;','type PointInspection={loading:boolean;','loadHymecNgMetadata(source.radarAt)','sampleHymecNg(hymecMeta,pointLat,pointLon)'])need('Frontend-Payload',radar,token);
for(const token of ['export type HymecNgMeta={','export type HymecNgSample={',"fetchWorkerJson<HymecNgMeta>('dwd-hymecng-meta'"])need('HymecNG-Payload',hymec,token);
for(const token of ["mode==='dwd-hymecng-file'","mode==='dwd-hymecng-meta'",'async function dwdHymecNgMetadata(request)','async function dwdHymecNgFileResponse(request)'])need('Worker-Payload',worker,token);
need('Package-Test',pkg,'test:dwd-radar-worker-payload-buildfix');need('Baseline-Test',baseline,'scripts/test-dwd-radar-worker-payload-buildfix-09221.mjs');
const pv=JSON.parse(pkg).version,bv=JSON.parse(baseline).releaseVersion;if(pv!==bv)failures.push(`Versionen nicht synchron: package ${pv}, baseline ${bv}`);
if(failures.length){console.error('DWD HymecNG WorkerPayload Buildfix fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('DWD HymecNG Metadata-/Datei-Payload und Frontend-Typen erfolgreich geprüft.');
