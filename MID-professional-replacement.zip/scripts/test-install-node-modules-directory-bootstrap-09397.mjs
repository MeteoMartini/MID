import {mkdtemp,mkdir,writeFile,rm,stat,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const root=path.resolve(new URL('..',import.meta.url).pathname);
const bootstrap=path.join(root,'node_modules');
const s=await stat(bootstrap);
if(!s.isDirectory())throw new Error('Release-Bootstrap node_modules muss ein echtes Verzeichnis sein.');
const bootstrapEntries=await readdir(bootstrap);
if(bootstrapEntries.length!==1||bootstrapEntries[0]!=='minimist')throw new Error('Release-Bootstrap node_modules darf nur das minimist-Uebergangsverzeichnis enthalten.');
const minimistBootstrap=path.join(bootstrap,'minimist');
if(!(await stat(minimistBootstrap)).isDirectory())throw new Error('node_modules/minimist muss ein echtes Verzeichnis sein.');
if((await readdir(minimistBootstrap)).length!==0)throw new Error('node_modules/minimist muss im Release leer sein.');

const temp=await mkdtemp(path.join(tmpdir(),'mid-09397-'));
const source=path.join(temp,'source');
const target=path.join(temp,'target');
await mkdir(path.join(source,'node_modules','minimist'),{recursive:true});
await writeFile(path.join(source,'package.json'),'{}\n');
await writeFile(path.join(target,'package.json'),'\n').catch(()=>{});
await mkdir(path.join(target,'node_modules','minimist','.git'),{recursive:true});
await writeFile(path.join(target,'node_modules','minimist','.git','config'),'protected git residue\n');
await writeFile(path.join(target,'node_modules','minimist','legacy.js'),'legacy\n');

const rsync=spawnSync('rsync',['-a','--delete','--checksum','--itemize-changes',"--exclude=.git/",source+'/',target+'/'],{encoding:'utf8'});
if(rsync.status!==0)throw new Error(`Alter Installer-rsync scheitert weiterhin (${rsync.status}): ${rsync.stdout}${rsync.stderr}`);
const diff=spawnSync('diff',['-qr',"--exclude=.git",source+'/',target+'/'],{encoding:'utf8'});
if(diff.status!==0)throw new Error(`Alter Installer-diff scheitert weiterhin (${diff.status}): ${diff.stdout}${diff.stderr}`);
const remaining=await readdir(path.join(target,'node_modules','minimist'));
if(remaining.some(name=>name!=='.git'))throw new Error(`Nicht geschuetzte minimist-Altdateien blieben uebrig: ${remaining.join(', ')}`);
await rm(temp,{recursive:true,force:true});
console.log('v0.9.39.8: alter rsync/diff-Installer akzeptiert leeres minimist-Uebergangsverzeichnis trotz geschuetztem .git-Rest.');
