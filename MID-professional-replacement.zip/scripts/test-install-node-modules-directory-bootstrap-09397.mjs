import {mkdtemp,mkdir,writeFile,rm,stat,readdir} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {spawnSync} from 'node:child_process';

const root=path.resolve(new URL('..',import.meta.url).pathname);
const bootstrap=path.join(root,'node_modules');
const s=await stat(bootstrap);
if(!s.isDirectory())throw new Error('Release-Bootstrap node_modules muss ein echtes Verzeichnis sein.');
if((await readdir(bootstrap)).length!==0)throw new Error('Release-Bootstrap node_modules muss leer sein.');

const temp=await mkdtemp(path.join(tmpdir(),'mid-09397-'));
const source=path.join(temp,'source');
const target=path.join(temp,'target');
await mkdir(source,{recursive:true});
await mkdir(target,{recursive:true});
await writeFile(path.join(source,'package.json'),'{}\n');
await mkdir(path.join(source,'node_modules'),{recursive:true});
await writeFile(path.join(target,'package.json'),'{"old":true}\n');
await mkdir(path.join(target,'node_modules','legacy'),{recursive:true});
await writeFile(path.join(target,'node_modules','legacy','tracked.txt'),'legacy\n');

const rsync=spawnSync('rsync',['-a','--delete','--checksum','--itemize-changes',source+'/',target+'/'],{encoding:'utf8'});
if(rsync.status!==0)throw new Error(`Alter Installer-rsync scheitert weiterhin (${rsync.status}): ${rsync.stdout}${rsync.stderr}`);
const diff=spawnSync('diff',['-qr',source+'/',target+'/'],{encoding:'utf8'});
if(diff.status!==0)throw new Error(`Alter Installer-diff scheitert weiterhin (${diff.status}): ${diff.stdout}${diff.stderr}`);
if((await readdir(path.join(target,'node_modules'))).length!==0)throw new Error('Alter node_modules-Inhalt wurde nicht durch das leere Release-Verzeichnis bereinigt.');
await rm(temp,{recursive:true,force:true});
console.log('v0.9.39.7: alter rsync/diff-Installer akzeptiert leeres node_modules-Verzeichnis und entfernt Altinhalt.');
