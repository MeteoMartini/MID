import {readFile,writeFile,mkdtemp,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
import {createRequire} from 'node:module';
const require=createRequire(import.meta.url);const ts=require('typescript-strada')
const [app,worker,pkg,baseline]=await Promise.all([readFile(new URL('../src/App.tsx',import.meta.url),'utf8'),readFile(new URL('../worker/metar-proxy.js',import.meta.url),'utf8'),readFile(new URL('../package.json',import.meta.url),'utf8'),readFile(new URL('../MID_BASELINE.json',import.meta.url),'utf8')]);
const failures=[],need=(area,text,token)=>{if(!text.includes(token))failures.push(`${area}: ${token}`)};
for(const token of ['nach kurzer Unterbrechung erneut','mit Unterbrechungen bis','im direkten DWD-RV-Punkt-Nowcast'])need('Radartext',app,token);
for(const token of ['function radarSiteIntervals(frames,wet)','siteIntervals','interruptionMinutes'])need('Worker-Ereignisse',worker,token);
need('Package-Test',pkg,'test:radar-period-wording');need('Baseline-Test',baseline,'scripts/test-radar-period-wording-08222.mjs');
const dir=await mkdtemp(join(tmpdir(),'mid-08222-'));
try{
 const workerFile=join(dir,'worker.mjs');await writeFile(workerFile,`${worker}\nexport {radarResultFromFrames};\n`);const workerModule=await import(`${pathToFileURL(workerFile).href}?v=${Date.now()}`);
 const observed=Date.parse('2026-07-30T19:10:00Z'),frames=[{time:observed,center:0,nearby:0,future:false},{time:Date.parse('2026-07-30T19:50:00Z'),center:7,nearby:7,future:true},{time:Date.parse('2026-07-30T20:00:00Z'),center:5,nearby:5,future:true},{time:Date.parse('2026-07-30T20:10:00Z'),center:0,nearby:0,future:true},{time:Date.parse('2026-07-30T20:20:00Z'),center:4,nearby:4,future:true},{time:Date.parse('2026-07-30T20:25:00Z'),center:0,nearby:0,future:true}];
 const result=workerModule.radarResultFromFrames('dwd','DWD-RV','high',frames,'DWD',{latitude:50.8,echoProfile:{mode:'summer-filter',label:'Sommer',siteThreshold:.06,nearbyThreshold:.2}});
 if(result.siteIntervals?.length!==2)failures.push(`Worker: zwei Phasen erwartet, erhalten ${result.siteIntervals?.length}`);if(!result.interrupted)failures.push('Worker: Unterbrechung fehlt');if(result.endAt!=='2026-07-30T20:25:00.000Z')failures.push(`Worker: letztes Ende 20:25 erwartet, erhalten ${result.endAt}`);
 const start=app.indexOf('function radarSummary('),finish=app.indexOf('\nfunction combineRadarAndModel',start);if(start<0||finish<0)throw new Error('radarSummary konnte nicht extrahiert werden');const functionSource=app.slice(start,finish),stub=`type RadarNowcast=any;const radarClock=(value?:string)=>value?String(value).slice(11,16):'';const radarSiteThreshold=(radar:any)=>Number(radar.siteEchoThreshold)||.05;const radarNearbyThreshold=(radar:any)=>Number(radar.nearbyEchoThreshold)||.18;const radarIntensity=(rate:number)=>rate>=5?'mäßig':'leicht';const radarRateText=(rate:number)=>rate>0?rate.toFixed(1).replace('.',',')+' mm/h':'';const formatDecimalFixed=(value:number,digits:number)=>value.toFixed(digits).replace('.',',');${functionSource} export {radarSummary};`;
 const compiled=ts.transpileModule(stub,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022},fileName:'radarSummary.ts'}).outputText,appFile=join(dir,'radarSummary.mjs');await writeFile(appFile,compiled);const appModule=await import(`${pathToFileURL(appFile).href}?v=${Date.now()}`),siteText=appModule.radarSummary({...result,currentRate:0,peakRate:7,rateApproximate:false,rateUncertain:false},'UTC');if(!siteText.includes('nach kurzer Unterbrechung erneut von 20:20 bis 20:25 Uhr'))failures.push(`Unterbrechungstext: ${siteText}`);
 const nearbyText=appModule.radarSummary({currentRate:0,peakRate:0,siteEchoThreshold:.06,nearbyEchoThreshold:.2,nearestWetKm:4.2,nowcastSeries:[{time:'2026-07-30T20:00:00Z',rate:0,nearbyRate:2,future:true}],summary:'Umfeldsignal'},'UTC');if(!nearbyText.includes('4,2 km entfernt')||!nearbyText.includes('kein Standorttreffer'))failures.push(`Nahbereichstext: ${nearbyText}`);
}finally{await rm(dir,{recursive:true,force:true})}
if(failures.length){console.error('Radar-Zeitraumprüfung fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}console.log('Mehrphasiger Radar-Niederschlagszeitraum und klare Trennung von Nahbereichsechos geprüft.');
