import {spawnSync} from 'node:child_process';
import {syncGithubConfiguration} from './sync-github-workflows.mjs';

const updated=await syncGithubConfiguration();
if(updated.length)console.log(`MID-GitHub-Konfiguration synchronisiert: ${updated.join(', ')}`);

if(process.env.GITHUB_ACTIONS==='true'){
 const result=spawnSync('git',['rm','-r','-q','--cached','--ignore-unmatch','node_modules'],{stdio:'inherit'});
 if(result.error)throw result.error;
 if(result.status!==0)throw new Error(`Versioniertes node_modules konnte nicht aus dem Git-Index entfernt werden (Exit ${result.status}).`);
 console.log('Repository-Hygiene: node_modules ist aus dem Git-Index entfernt und bleibt über .gitignore lokal.');
}
