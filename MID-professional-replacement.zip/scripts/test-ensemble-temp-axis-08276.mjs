import {readFileSync} from 'node:fs';
const app=readFileSync(new URL('../src/EnsemblePanel.tsx', import.meta.url),'utf8');
const css=readFileSync(new URL('../src/styles.css', import.meta.url),'utf8');
const pkg=JSON.parse(readFileSync(new URL('../package.json', import.meta.url),'utf8'));
const fails=[];
if(pkg.version!=='0.8.27.6')fails.push(`package.json: ${pkg.version}`);
if(!app.includes('xAxisHeight=compact?64:68'))fails.push('Erhöhte Temperatur-X-Achsenhöhe fehlt.');
if(!app.includes('cellLift=xAxisHeight>=60?Math.max(12,cellHeight*.7):Math.max(10,cellHeight*.65)'))fails.push('Anhebung der Wetterkacheln fehlt.');
if(!app.includes('height={exporting?296:326}'))fails.push('Erhöhte Temperatur-Chart-Höhe fehlt.');
if(!css.includes('MID v0.8.27.6 · sichtbare Temperatur-Tagesachse und präziser zentrierte Wetterkacheln'))fails.push('CSS-Fix für Temperaturachse fehlt.');
if(fails.length){
  console.error('Regression fehlgeschlagen:\n- '+fails.join('\n- '));
  process.exit(1);
}
console.log('MID v0.8.27.6 Ensemble-Temperaturachsen-Regression bestanden.');
