import {readFile} from 'node:fs/promises';
import ts from '/opt/nvm/versions/node/v22.16.0/lib/node_modules/typescript/lib/typescript.js';

const source=await readFile(new URL('../src/ForecastCockpit.tsx',import.meta.url),'utf8');
const failures=[];
if(source.includes('chartTickValues[1]??chartTickValues[0]||0'))failures.push('ungültige Mischung von ?? und || weiterhin vorhanden');
if(!source.includes('chartTickValues[1]??chartTickValues[0]??0'))failures.push('geklammerte/nullish-only Fallback-Kette fehlt');
const result=ts.transpileModule(source,{compilerOptions:{jsx:ts.JsxEmit.ReactJSX,target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext},reportDiagnostics:true,fileName:'src/ForecastCockpit.tsx'});
const diagnostics=(result.diagnostics??[]).filter(item=>item.category===ts.DiagnosticCategory.Error);
for(const diagnostic of diagnostics){failures.push(`TS${diagnostic.code}: ${ts.flattenDiagnosticMessageText(diagnostic.messageText,' ')}`)}
if(failures.length){console.error('TS5076-Buildfix fehlgeschlagen:\n- '+failures.join('\n- '));process.exit(1)}
console.log('TS5076-Buildfix für Kurzfrist-Meteogramm erfolgreich geprüft.');
