## MID v0.9.85.520 · 2026-11-24 · Robustere Release-Metadaten und isolierte QA-Werkzeuge

- #901: explizite HTTP-Statusauswertung statt stderr-Muster, maximal eine Wiederholung bestätigter temporärer GET-Fehler 502/503/504 ohne Retry-After, keine POST-Wiederholung, weiterhin unveränderte Tag-/Release-/SHA-/Job-Gates.
- #1013: exakt vorqualifizierte drei Dateien für Ergebnisvalidierung und Akteur-/Inhalts-/Kommentar-Readback. Kein Live-Transport, kein dauerhaft atomarer Speicher, keine neuen Secrets oder Berechtigungen.
- #991: exakt vorqualifizierte zwei rein lesende DWD-Diagnosedateien. Keine GRIB-Zulassung, kein aktiver Publisher, keine Wetterdaten-Freshness-Behauptung. #1007 und #1014 Live-Abnahme bleiben separat offen.

## MID v0.9.85.519 · 2026-11-24 · RUC-Pages-Provenienz nach isoliertem Katalogfehler

- Konsolidierung des gezielten #1012-Katalogfixes für ein SHA-verifiziertes Ersatz-ZIP und der Pages-Baseline-Reparatur; unveränderte fachliche Release-, Worker-, Pages- und Stable-Gates.
- Nur für den exakt bekannten Installer-Workflow darf ein ausschließlich nach Stable-Promotion fehlgeschlagener Katalogjob bei vollständiger Original-Job-, Commit-, Akteur-, Artefakt- und Deployment-Provenienz als gültige Pages-Baseline qualifiziert werden. Kein allgemeiner Erfolg eines fehlgeschlagenen Installers und keine rückwirkende Tag-Autorisierung.
- Zusätzliche Python-Regressionen für die eng begrenzte Baseline-Ausnahme. Kein eigenständiger Logicc-Upload, kein geänderter Wetter-Worker und keine zusätzlichen Kosten oder Rechte.

## MID v0.9.85.518 · 2026-11-24 · Isolierte Logicc-Governance und zuverlässiger Dependency-Audit

- Selektive Übernahme #1007 @ b77d801eabf6bcae03178a3385b3a6c1f4a480ad und #998 @ e7491a7b7c240df04d563cbce659630783658901. Produktions-Wetter-Worker unverändert; isolierter Logicc-Qualifikationsworker und seine Originaldiagnostik byteidentisch aus #1007 übernommen.
- Dependency-Audit: ubuntu-24.04 in .github/workflows/dependency-audit.yml und ci/github/workflows/dependency-audit.yml; bestehende Audit- und Regressionspflichten unverändert.
- Ergänzte Pages-Timeout-Assertion und Einbindung der unveränderten Logicc-Diagnostik in vorhandenen verpflichtenden Runner-Regressionstest. Normative Owner-/Plugin-Trennung; keine Gateway-Aktivierung. #1000 bleibt separat.

## MID v0.9.85.517 · 2026-11-24 · Robusterer Pages-Archivabgleich

- Selektive Übernahme aus #1006 @ fc644eab9b8b0dd2a792abc585b09f572d748bf8.
- Anhaltende HTTP- und Inhaltsabweichungen melden den betroffenen Prüfpfad. Version und Changelogs werden über den bestehenden Prebuild synchronisiert.

## MID v0.9.85.516 · 2026-11-24 · Wiederaufnahme der Pages-Veröffentlichung

- Ausgangspunkt ist das installierte main ab96ac712fd4f3ba9be5af2cb546febf9ee13329 bei produktivem Stable 331fffff081303e1c597badddfa4ae41c4b4e0f0.
- GitHub-Installer 45256731707, Versuch 1, brach vor der Pages-Veröffentlichung ab. Der getrennte Runner-Nachweis 45362112280 bestätigte den Abgleich mit dem Originalarchiv.
- Versionsziel für den vorhandenen Prebuild-Schritt. Veröffentlichung setzt erfolgreiche Source-, Installer-, Worker-, Pages- und Stable-Gates voraus.

## MID v0.9.85.515 · 2026-11-23 · P0 Mountain-Visual-Recovery und .514-Reise-/WMS-Originalquellen

- Recovery-Parent: Stable .513 331fffff081303e1c597badddfa4ae41c4b4e0f0, .514 Source Merge 294bf1b4181d25f9c8868de175e1ecb4cf2bb3b8, fehlgeschlagener Main-ZIP-only f6b4856ed1e2de8d659aa15383a2e06aac526bc0. Keine Ref-Mutation auf main/stable.
- Original-Installer #45195086142 Attempt 1 fehlgeschlagen an heavy-mountain-visual; 11 success/1 failure/10 skipped. Alte ZIP-Bytes bleiben im geschützten Main erhalten.
- Bestehender offizieller audit-failed-release / Source-PR-Reviewguard prüft die ursprüngliche GitHub-Installer-Historie; kein Blind-Retry oder Review-/Source-Gate-Bypass.
- Lokal neuer Node22 RED→GREEN-Fall: 3 identische Core-GETs vor Fix, 1 danach. Weitere 12 Mountain-Nodechecks PASS; zwei Pakete offline fehlend, vollständiger TS-Typecheck/Browsertest/Ios/Source/Installer noch offen.
- Komplette Quelle aus unveröffentlichtem .514 Source Merge einschließlich #988/#992/#995 bleibt erhalten; keine Aufnahme anderer parallel entwickelter QA-Drafts.
- Full original Source/Core4/Heavy6, Review/Cubic, Bot server ZIP, Installer/Core4/Heavy6, Worker/Pages, Stable-Promotion und GitHub-Releases/latest noch als NOT VERIFIED zu führen.

## MID v0.9.85.515 · P0 Recovery: Bergwetter Saisonprofil und .514-Source-Erhalt (Kandidat)

- .513 Stable SHA 331fffff081303e1c597badddfa4ae41c4b4e0f0 → unveröffentlichter .514 Source-Merge 294bf1b4181d25f9c8868de175e1ecb4cf2bb3b8 → .514 Installer #45195086142 fehlgeschlagen; originaler ZIP-only-Commit f6b4856ed1e2de8d659aa15383a2e06aac526bc0 auf main bleibt unverändert.
- Meteorologischer Core-Cache jetzt saisonunabhängig; nichtmutierende Saisonprojektionen für Cached-/Fresh-/Enrichment-Pfade; Node22 Negativ-/Positivtest und 12 domänenspezifische Regressionen. Original-CDP-Wait 60 s, ARIA-/Core-Negativprobe hinzugefügt, Browser/Installer noch ausstehend.
- Vollständiger Release ausschließlich nach audit-failed-release, Source-PR-/Review-Guard, Core4+Heavy6, autorisiertem ZIP-Bot, Installer Core4+Heavy6, Worker/Pages, Stable-Promotion. Keine QA-Bypässe.

## MID v0.9.85.514 · 2026-11-23 · LC 1.34 – Originalzeitintervalle im Reiseplaner, WMS-Kartenaudit und dynamisches Plugin-Routing

- **Verifizierte Ausgangsbasis:** `main=mid-stable=331fffff081303e1c597badddfa4ae41c4b4e0f0` / v0.9.85.513, Release [v0.9.85.513](https://github.com/MeteoMartini/MID/releases/tag/v0.9.85.513) nach erfolgreichem Installer #45169135490; fünf aktive Rulesets.
- **Präziser Original-Intake:** Die voneinander unabhängigen QA-Branches #995 (6 Governance-Pfade), #992 (5 EC46-/GEFS-Reise-Pfade), #988 (4 read-only WMS-Audit-Pfade inkl. zweifacher MID_BASELINE-Testregistrierung) werden SHA-/Blob-gebunden selektiv übernommen; kein historischer Branch-Merge, kein Überschreiben von Spezialistenarbeiten.
- **Meteorologische Korrekturen:** GEFS UTC-Temperatur-Momentanwerte und endgestempelte 1h-Niederschlagsintervalle werden getrennt auf vollständige 24-Stunden-Tage geprüft; Missing bleibt Missing, echte 0 mm bleibt 0, unplausible Originalextreme werden nicht automatisch geglättet. EC46-Wochensignal nur bei echter 7/7-Wochenabdeckung und feldgerechter Tagesanwendbarkeit.
- **Sicheres Kartenaudit:** WMS-Modelllauf, Valid Time, Akkumulationsintervall und komplette PNG-Transportintegrität werden lesend geprüft, ohne aus gültigen Bytes fiktive meteorologische Deckung oder echte WebGL-Pixelqualität zu folgern.
- **Governance/Scope:** Dynamisches Plugin-Routing ohne neue Agentenrechte, Abos, Watcher-Aktivierungen, Secrets oder Regelausnahmen. #937 Umfeldkarte, #993 27h-RUC-Shadow und #991 natives 27h-Inventar bleiben separate QA-Drafts; P0-RUC/EPS-Quellenlücke #541 bleibt offen.
- **Status als Source-Draft:** Erst die tatsächlich auf dem kombinierten HEAD durchlaufenden vollständigen Source-/Review-/Core-/Heavy-/ZIP-/Installer-/Worker-/Pages-/Stable-/GitHub-Katalog-Nachweise autorisieren Veröffentlichung. Keine echten iOS-Gerätetests behauptet.

## MID v0.9.85.513 · 2026-11-23 · LC 1.34 – Release-Katalog-Skip und kanonische 14-Tage-Ensemble-Grafik

- **Verifizierte Basis:** `main=mid-stable=3195012b1b72b4cc3bbd762c2fbd859a924aadc7` / v0.9.85.512; Installer #45150996794 vollständig erfolgreich, Worker/Pages/Stable grün. Die nachgelagerte Katalogstufe war im Originalrun `skipped`, `releases/latest` zeigte weiterhin v0.9.85.119 (#901).
- **Release-Katalog-Fix:** In den drei byteidentischen bestehenden Installer-Workflowspiegeln erhält ausschließlich `catalog_release.if` den expliziten Status-Guard `!cancelled()` mit unveränderten Bedingungen `github.event_name == 'workflow_dispatch'`, `needs.install_build.result == 'success'` und `needs.finalize_release.result == 'success'`. Der Publisher, Tokenumfang, atomare Tag-Reservierung, ZIP-only-/Stable-Lineage-, Core-/Heavy-/Pages-/Worker-/Readback- und Fail-closed-Verträge bleiben unverändert. Verpflichtende Regression im bestehenden Testskript ergänzt; tatsächlicher Live-Katalogbeleg erst nach .513-Gates.
- **Design-Intake:** Selektiv neun unveränderte Original-Git-Blobs des QA-Drafts #990 HEAD `bc10fa3104808d9e00635f67a56685a4690c6ffa` auf die identische .512-Stable-Ausgangsbasis portiert. Die vorhandene Ensemble-/Unsicherheitsgrafik rückt unmittelbar vor die Wochenleisten; doppelte Sichtbarkeit entfällt, Best-Match-Fallback bleibt ausdrücklich. Bestehende UI-/Browser-/Unit-Regressionen werden mitgenommen, ohne zweite Prognoselogik.
- **Parallelabgrenzung:** GEFS/EC46 #989 nicht blind übernommen, da neuer Spezialbranch `chatgpt/v0.9.85.513-audit14-travel-horizon-supersedes989` bereits zusätzliche Änderungen enthält und noch nicht als aktueller verifizierter Source-PR vorliegt. Karten #988, RUC #541/#991 und historische Karten #937 bleiben unabhängige Kandidaten. Kein neuer Provider, Cloudflare-Speicher, Secret, kostenpflichtiger Dienst oder Regel-Bypass.
- **Status am Source-Cut:** Noch kein .513-Release. Vollständige Source-/Review-/Core-/Heavy-/ZIP-/Installer-/Worker-/Pages-/Stable-/GitHub-Release-Katalog-Nachweise weiterhin zwingend; keine echte iOS-Geräteabnahme behauptet.

## MID v0.9.85.512 · 2026-11-23 · SHA-geprüfter GitHub-Release-Katalog nach Stable-Promotion

- **Basis:** `main=mid-stable=c5faca33885f8df4cc645be89ecc6befe93c55c0` / veröffentlichte .511. Aus historischem QA-Draft [#956](https://github.com/MeteoMartini/MID/pull/956) @ `cb80824ca54967903a4d7885b6380b8ea02c599e` ausschließlich Original-Katalog-Prüfkern, negative Unit-Tests und QA-Dokumentation selektiv integriert, nicht den alten .497-Branch gemergt.
- Der bestehende Installer erhält ausschließlich einen nachgelagerten Katalog-Job nach erfolgreichem `finalize_release` für `workflow_dispatch`, serialisiert mit dem bestehenden Source-Bot. **Nur der Katalog-Token** der vorhandenen Release App fordert `Actions:read` und `Contents:write` an; andere vorhandene Release-App-Nutzungen bleiben unverändert. Keine neuen Secrets, bezahlten Dienste oder Änderungen an Repository-Permissions/Rulesets.
- Realer Installer der v0.9.85.511 [#45117904421](https://github.com/MeteoMartini/MID/actions/runs/45117904421): ZIP, Core, Heavy, Worker, Pages-Versuch 2 und Stable-Promotion SUCCESS; optionaler Pages-Artefakt-Prep-Jobs SKIPPED. Das Katalog-Gate berücksichtigt einen solchen Skip **nur** mit genau einem tatsächlich erfolgreichen Pages-Deployment und vollständigen Core/Heavy-/Stable-/Run-/SHA-Belegen. Nicht abgeschlossene oder fehlgeschlagene Pfade bleiben gesperrt.
- Veröffentlicht werden ausschließlich neue, nachprüfbar zugeordnete GitHub-Tag-/Metadaten samt Original-Run-ID; der exakte Tag wird per atomarem GitHub-Ref-POST vor dem Release-POST reserviert. Tag-/Release-Races, fremde Tags, unverified Assets, fehlender `latest`-/Branch-Readback und mehrdeutige API-Antworten bleiben fail-closed; ein dabei verwaister Tag bedarf einer gesonderten Operatorprüfung, niemals eines automatischen Retags/Deletes. Supersedierte **frühere** fehlgeschlagene Pages-Versuche sind nur bei eindeutig erfolgreichem späteren Deployment und grünem Finalizer zulässig.
- GitHub-Run-Pfad exakt `.github/workflows/install-mid.yml` geprüft. Der bestehende Installer kennzeichnet unveränderte Wiederholung explizit mit `release_noop=true`; dann ist **ausschließlich** der erfolgreiche Readback eines bereits bestehenden aktuellen Tag-/Releases inklusive Original-Installerbeleg zulässig, keinerlei nachträgliche Tag-/Metadaten-Neuerstellung.
- P0 RUC/EPS #541, 14-Tage-Design #975, Umfeldkarte #937, Queue #981 und fehlende historische Releaseeinträge bleiben eigenständig.
- **Status am Source-Cut:** QA-Kandidat, **kein .512-Release**. Vollständige Source-/Review-/Core-/Heavy-/Installer-/Worker-/Pages-/Stable- und echte GitHub-`releases/latest`-Gates stehen aus.

## MID v0.9.85.511 · Installer-Abbruchprovenienz und echte GDPS-Recovery-QA

- Geprüfte Source-Basis: `main=mid-stable=35e904ec4e87ce725237e214141d9b640fd04692` / veröffentlichte v0.9.85.510, Issue #983 und #422. Der neue Integrationskandidat bleibt bis zu vollständigen Source-/Review-/Installer-/Worker-/Pages-/Stable-Gates **QA-Draft, kein Release**.
- Self-Heal prüft das vollständige GitHub-Jobinventar **fehlgeschlagener Installerläufe** vor dem `--log-failed`-Inhalt und identifiziert darin abgebrochene Pflichtjobs separat. Fehlende extern gesicherte Cancellation-Provenienz wird weiterhin strikt nicht als Auto-Retry freigegeben; die GitHub-Actions-Summary nennt **in diesem Pfad** Originalrun und erforderliche Operatorprüfung. Ein insgesamt als `cancelled` abgeschlossener Workflow löst den bestehenden Self-Heal-Job nicht aus. Kein Permission-/Ruleset-/Secret-/Retry-Limit-Bypass.
- Unified-Map-ECCC-GDPS-502-Browsertest akzeptiert bei vorzeitiger Entfernung des Retry-Buttons ausschließlich einen neuen tatsächlich beobachteten Original-GetMap und nachgewiesenen gültigen INIT-Zustand. Ohne diese Belege bleiben die bestehenden Assertions und reale Browserfälle blockierend. Keine `force:true`-Klicks, entfernten Testfälle oder künstlich erhöhten Budgets.
- Negative Tests decken zweifach `cancelled`, fehlende und täuschende Logs, vollständige Jobinventare und Attempt 2 ab. Releaseversprechen gelten erst nach tatsächlichen Gate-Ergebnissen; RUC-Vollstand/EPS #541 sowie Karten-/14d-Design #975 bleiben getrennt offen.

## MID v0.9.85.510 · Leit-Integration – kontrollierter DWD-Fast-Nachholpfad

- Basis: am 22.11.2026 auf `main=mid-stable=73f64f833ecb0e48666834e9c44588e05cea1e31` erfolgreich veröffentlichte v0.9.85.509. Originaler Spezialchat-QA-Draft PR #980, HEAD `226c03d3938b7e18848194b040eab97e65abc7af`; drei ursprüngliche Workflow-/Sync-Vertragsblobs selektiv übernommen und nach Cubic-Review hinsichtlich Stable-SHA, jüngstem Publisher, Nachholzeitfenster und verpflichtendem Recovery-Cron gezielt gehärtet. Frühere .508-Draft-Basis ersetzt, ohne fremde Änderungen zu verlieren.
- :28/:58-UTC-Nachholslots nach den bestehenden :13/:43-Fast-Lane-Slots; zuvor lesende SHA-gebundene GitHub-Runs-/Job-Klassifikation im 90-Minuten-Fenster; nur der jüngste tatsächlich qualifizierende Fast-Lauf zählt: bei laufender Verarbeitung oder bei erfolgreich innerhalb der letzten 25 Minuten abgeschlossenem Publisher kein Duplikat, bei neuestem Fehlschlag oder nur altem Erfolg gezielte Nachholung. Der 90-Minuten-Zeitraum dient ausschließlich der Abdeckung länger laufender Jobs. API-Verlaufslücken führen vor DWD-Downloads zum Abbruch. Volle DWD-/EPS-Läufe, NoData, Warnungen, Originaltime und RUC-Integrität bleiben unangetastet. Keine neuen externen Dienste oder Abos.
- Workflows gespiegelt und sechs Regressionstests für Cron-/SHA-/Zeitfenster-/Reihenfolge-Gates ergänzt; MID-Release-/Worker-/Cache-Stand .510 synchronisiert. iOS: `CURRENT_PROJECT_VERSION=511` für alle Targets, `MARKETING_VERSION=0.9.85` unverändert; die MID-Release-Zuordnung `0.9.85.510` und der zugehörige Statuszeitstempel sind separat in `MID_IOS_STATUS.json` gespeichert. Source/Core/Heavy/GitHub-Review-/Installer-/Pages-/Worker-/Stable-Gates sind am Source-Cut noch **nicht ausgeführt**; dieser Commit ist nur ein Gate-Kandidat, keine Produktivfreigabe. Produktionsqualität und RUC-Full-E2E werden separat verifiziert. Offene P0-Design-Issues #952/#975 und GitHub-Katalog #901 nicht als erledigt behaupten.

## MID v0.9.85.509 · LC 1.30 · UV-Intervallsemantik und Canvas-Budget

- Grundlage v0.9.85.508 auf `363815e328443805595f9adf8a978c7f609202bb`; originale SHA-verifizierte Pfade aus QA-Drafts #967 und #908, disjunkt zu laufendem RUC-Daten-/14d-Design-Handoff.
- UVI in Stunden-/Tagesprognosen: finite nichtnegative Provider-Number, Stundenendzeitpunkt ist Intervallende, Tagesmaximum und UTCI/Provider-Fallback nicht mit erfundener 0 füllen. Andere Aktuell- und Widget-Pfade sind nicht von diesem Fix erfasst. Keine amtliche Warnlogik verändert.
- Canvas: sichtbarkeitsgerechter redraw scheduler, reduzierte Bewegung/Data Saver und tatsächliche Device-Pixel-Dimensionen für 1-Mi-Pixel-Crossfade-Gate; keine Vorhersagewerte geändert.
- Original-QA: #967 und #908 jeweils gezielte Regression und Vitest bestanden. **Final-HEAD-Full-Gates, Geräte- und E2E-Abnahmen noch offen.** RUC-Freshness/Worker bleibt eigenständiges P0.


## MID v0.9.85.508 · Worker-Abruf der Fast-Signaturschlüssel

- Live-Diagnose .507: Der Pages-Beleg wird gelesen. Der GitHub-Schlüsselabruf endet vor einem HTTP-Status. Der Worker behandelt einen Redirect als HTTP-Antwort und lehnt ihn vor der Verwendung von Schlüsseln ab. Produktionsnachweis ausstehend.

## MID v0.9.85.507 · Abruf des Fast-Lane-Belegs

- Live-Diagnose von .506: proof-request ohne HTTP-Status. Der signierte Beleg nutzt jetzt den erfolgreichen Pages-Einstieg des regulären RUC-Index mit abweichender Cache-Behandlung für den veränderlichen Beleg. Produktionsnachweis ausstehend.

## MID v0.9.85.506 · Fast-Lane-Vertrauensprüfung im Worker

- Basis c710c691a5b56ef79c26325d1b167c0af073d550. Der produktive .505-Worker meldet für den vorhandenen signierten Fast-Snapshot trusted=false. Die Diagnose unterscheidet Dokument-, Schlüssel- und Verifikationsfehler. Produktionsnachweis ausstehend.

## MID v0.9.85.505 · Fast-Lane-Workerabruf

- Die Veröffentlichung des .504-Fast-Snapshots auf Pages ist in Actions 45022455410 protokolliert. Der produktive Worker übernahm den Lauf bei der ersten Prüfung nicht. Lokal reproduzierter Manifest-Abruf oberhalb von 3,2 s. Der überarbeitete Abruf behält Größen-, Signatur- und Frischegrenzen. Produktionsabnahme steht aus.

## MID v0.9.85.504 · Native Open-Meteo-Phasenzellen

- Nachweis der neuen API-ID mit tatsächlichen Viertelstundenwerten für Bonn. Regressionen prüfen Reihenfolge, Zellherkunft, Feldzeit und Requestbudget. Basis: 44edbf5365763f98d68c2814c038d222728859d7. Initialer Prüfcommit: 2d55d2102813f0ad24fefe03840c01a75fbb3ce0. Fünf gezielte Radar-/Phasentests und 134 Fast-Tests lokal bestanden. Bonn-Produktionsprobe nach Stable-Promotion.

## MID v0.9.85.503 · RUC-Pages-Deployment des eigenen Jobs erkennen

- Recovery des geprüften .502-Installationsstands 390421d54f6d0482e2007a488cb38ad4c68aef04 auf Basis von Stable c6e5aa75d18b810b066f685f30ff6b0b35e030df.
- GitHub Actions 44995889909 belegt die Kollision zwischen Fast-Datenerhalt und dem automatisch erzeugten Pages-Deployment-Eintrag. Regressionen sichern Installer, Fast- und Vollpublisher sowie die Ablehnung fremder Jobs ab.
- Produktivabnahme folgt nach Stable-Promotion.

## MID v0.9.85.502 · 2026-11-22 · RUC-Fast-Lane: volle Deploymentliste zulassen

- Basis c6e5aa75d18b810b066f685f30ff6b0b35e030df. Beleg für den Fehler: GitHub Actions 44993474635.
- Der Resolver hat 24 Tests bestanden und das aktuelle Pages-Artefakt 14727993173 live identifiziert. Produktivabnahme nach Stable-Promotion.

## MID v0.9.85.502 · RUC Fast Pages-Deploymenthistorie

- Basis `c6e5aa75d18b810b066f685f30ff6b0b35e030df`, Fehlernachweis Actions `44993474635`.
- Resolver akzeptiert die vollständige erste Seite mit 30 Einträgen. Ohne nachgewiesenes erfolgreiches Deployment bleibt die Veröffentlichung gesperrt. 24 Resolver-Tests bestanden. Der Live-Readback identifizierte das Stable-Artefakt `14727993173`.

## MID v0.9.85.501 · 2026-11-21 · Kostenfreie RUC-Fast-Lane: GitHub-signierter Originaldatenbeleg

- Source-Basis main=mid-stable=9756419d5af4933e9ff023aed568e42de500e97b, Version 0.9.85.500; ref-freier Originalcode 1b791cbd4f46e6fb95109fda8b6081cf3da65325 (14 geänderte Pfade, Parent identisch mit Stable).
- Github OIDC SHA-audience issuer JWKS, protected workflow/ref/repo/run/run-attempt, HTTPS-Readback und native Chunk-Prüfungen ohne R2; bestehende Pages-Rollback-Gates bleiben.
- Neues Versionspaket und Verträge/Versionsspiegel nach vorhandener Sync-Semantik. Kein Source-PR, keine CI, keine Build-, DWD-Original-, Worker-/Pages- oder iOS-Abnahme dieses Version-HEADs.
- Basis 9756419d → OIDC 1b791cbd → Version 8e984426 → geprüfter Source-PR-Stand f8fa9f2130031369481fe3640707e3bb00e0ca00 (signierter Pages-Beleg vor optionalem R2-Altpfad).
- Exakte Freigabe ausschließlich über den bestehenden MID Source-PR-Gate, Bot-Merge, ZIP, install-mid.yml, Worker/Pages und mid-stable; für den Betriebsabschluss von #541 stehen zwei verschiedene DWD-Fast-E2E-Runs noch aus.

## MID v0.9.85.501 · 2026-11-21 · GitHub-OIDC-Fast-Provenienz ohne R2 (Source-Kandidat)

Basis `9756419d` → OIDC `1b791cbd` → Version `8e984426` → geprüfter Source-PR-Stand `f8fa9f2130031369481fe3640707e3bb00e0ca00` (signierter Pages-Beleg vor optionalem R2-Altpfad).

- Basis v0.9.85.500, `main=mid-stable=9756419d5af4933e9ff023aed568e42de500e97b`; Originalcommithandoff `1b791cbd4f46e6fb95109fda8b6081cf3da65325` (ein Commit voraus, 14 Pfade, keine veröffentlichten Writes).
- Original RUC-Preprocessing-Workflowpaare, GitHub-OIDC-SHA/JWKS-Nachweise, Pages-Preserve/Readback, native Worker-Spiegel und fachspezifische Tests aus diesem Kandidaten übernommen; frühere #946-Sourceänderungen sind bereits ab v0.9.85.498 enthalten und werden nicht erneut dupliziert.
- Versionsspiegel/Lock/Service Worker/iOS/Vertragsregister und Nutzer-/Technik-Changelog für v0.9.85.501 vorbereitet. Keine R2-Aktivierung, keine Paid-Fallbacks, keine Ruleset-/Review-/Secret-Änderung.
- Reviewer-, CI-, Source-Core/Heavy, echte DWD-GRIB2, signierte OIDC-Token, Worker-/Pages-Live- und MID-Fusion-E2E-Nachweise sowie erfolgreicher ZIP/Installer/Stable-Release sind weiterhin ausdrücklich offen. Kein Release oder Nullkosten-Echtbetriebsnachweis wird behauptet.

## MID v0.9.85.500 · 2026-11-21 · Bedarfsgesteuerte Einstellungen und zugängliche Dashboard-Reihenfolge

- Ausgangspunkt: veröffentlichte v0.9.85.499, main=mid-stable 43759c68d001e5c8e6409f6ef2916a6610bbbad4.
- Originale QA-Spezial-Drafts: #959 HEAD deee1e570b90b1a31d87039d3a2337187dfc9e81 und #963 HEAD f5ec03a6f39207b9887f3e645cfe2a08d78d0f7c.
- SettingsManager ist zwischen früherer #959-Basis und .499 Stable byte-identisch; ausschließlich das geprüfte 301-Zeichen-Settings-Hunk wurde in den neueren App-Blob eingetragen; .499 Spatial-Cache-Hinweis unverändert erhalten.
- DashboardModuleSettings.tsx und zugehörige Regressionen auf der jeweils unveränderten Stable-Basis, ohne App-/RUC-/Worker-Fachlogikänderungen.
- Vor einer tatsächlichen Veröffentlichung sind Review, vollständiger aktueller Source-PR-Gate, Core/Heavy, Browser/iOS-Build, Installer, Worker/Pages (soweit betroffen) und Stable-Promotion weiterhin nachzuweisen.

## MID v0.9.85.499 · 2026-11-20 · Ortsrichtiger Cache, Ensemble-Geometrie und WMS-Kartenschutz

- Stable-Basis 1592963e12688af4b2f8c74f933033235849dcb7 / v0.9.85.498.
- Verifizierte Originalheads: #953 62f3c7554daeb1fe3b823353fc9e93b835a24c15, #957 a4d558a5e729dceb2308c4d0f483a44e418ca67e, #955 cbb159525f6ae0edd8994437a49f17a396fbb07d, #958 bad89812662a45487638604e3b46e9345c733332.
- Quellcode allein ist noch kein erfolgreicher Build, kein Release und keine produktive RUC-Datenfrische-Freigabe.

## MID v0.9.85.499 · 20.11.2026 · Leit-Integrationskandidat (Source, noch kein Release)

- Verifizierter Stable-Ausgangspunkt `1592963e12688af4b2f8c74f933033235849dcb7` / v0.9.85.498, vier geprüfte Originalquellen #953, #957, #955 und #958.
- Originalblob-konsistente Quellintegration; Worker-Bundles nach genau einer WMS-Originalhunk-Übernahme aus aktuell veröffentlichter RUC-Fast-Lane erzeugt; Version/Lockfile/Verträge/Web-/iOS-Mirrors synchronisiert.
- Erst die vollständigen Source-, Build-, Regression-, Review-, Installer-, Worker-/Pages- und Stable-Nachweise dürfen einen tatsächlichen Release bestätigen. Dieser Kandidaten-Commit behauptet keinen dieser Erfolge.

## MID v0.9.85.498 · 2026-11-20 · DWD-RUC 0–6h-Fast-Lane – geprüfte unabhängige Veröffentlichung und Punkt-Consumer

- Quellbasis main=mid-stable v0.9.85.497 @ 9fd872a789f4b158bc691d085589616c2c04f776.
- Die getrennte, ref-freie Ausgangsvorlage 089cb6a34d3837620d5a3ecd5ad1b93a61730e7e integriert RUC-#946-Code und den SHA-/NoData-sicheren Fast-Worker-Adapter.
- Original-DWD-Test 19.11. 21Z: 188/188 GRIB-Dateien ecCodes-Dekodierung, 542040 native Punkte, sieben stündliche/73 fünfminütige/25 fünfzehnminütige Termine, SHA-gebundener Pages-Punkt-Readback offline.
- Ref-freier Versionskandidat: KEIN produzierter Release, KEIN echter Pages-/Worker-Deploy oder produktiver Fast-Schalter, keine aktuelle Live-Frischebehauptung.
- Vor realem Release: vorhandener Source-Gate/Review, signierter Merge via MID-Bot, Installer, betroffene Worker-/Pages-Prüfungen, Stable-Promotion und unabhängiger Manifest-Digest-Transport zum Worker.

## MID v0.9.85.498 · 2026-11-20 · DWD ICON-D2-RUC eigenständige 0–6h-Fast-Lane (Source-Kandidat, kein Release)

- Geprüfte Ausgangsbasis: Stable .497 = `9fd872a789f4b158bc691d085589616c2c04f776`, fünf aktive Rulesets. Verifizierter ref-freier 0–6h-Quellstand `089cb6a34d3837620d5a3ecd5ad1b93a61730e7e`, parent exakt Stable.
- Release-Version und gemeinsame Mirror-Pfade werden für .498 synchronisiert; neue Node-Worker-Fast-Regression in bestehenden Baseline-/Pflichtregressionen registriert. Keine alten Komponenten vollständig überschrieben.
- Reale Original-GRIB-Daten/Offline-Producer vom 19.11. 21Z mit 188 dekodierten Einzeldateien, 7/73/25 nativen Terminen und SHA-gesiegelten Pages-Chunks auf #946 dokumentiert. Kein Vergleich mit einem angeblich aktuell frischen EPS20-Lauf und keine fiktiven Ensemble-Werte.
- Aktueller Worker-Fast-Pfad bleibt bis zum authentisierten externen Digest-Transport deaktiviert; #955 verändert Worker-Bundles parallel und ist **nicht** ohne generierten Shard-Rebuild integrierbar. #947 ist ausschließlich Restore-only-Source-Optimierung, keine Fast-Freigabe.
- Status: ref-frei; neue Vitest-/Core-/Heavy-/Browser-/Review-/Source-/ZIP-/Installer-/Worker-/Pages-/Stable-Ergebnisse noch nicht ausgeführt. Release erst über vorhandenen MID-Releasebot und alle wirklich anwendbaren Prüfungen.

- Der zusätzlich vorbereitete geschützte Fast-Publisher→Worker-Digest-Transport speichert nach positivem Pages-Readback einen unabhängigen SHA-/Run-Beleg im bereits vorhandenen RUC-R2-Bucket; der Worker kann entweder den von einem geschützten Publisher gesicherten R2-Beleg oder eine ausdrücklich administrativ gesetzte SHA-Bindung verwenden; niemals den öffentlichen Pages-Manifest-SHA als eigenen Vertrauensanker. Bei Schreib-/Readback-Fehlern greift der Pages-Rollback. Details und zehn Worker-/zwei Receipt-Tests in `docs/implementation/MID_RUC_FAST_TRUST_RELAY_2026_11_20.md`. Diese neue Schicht ist noch **ref-frei und nicht produktiv geprüft**.

## MID v0.9.85.497 · 2026-11-19 · Responsive Lade- und Ensemble-Anzeigen mit Tageslicht-Kontrast

- Ausgangs-Stable v0.9.85.496 SHA 256aabe286f7daa00dc0e320815dd8dacb7b4706; #948 QA-HEAD 5aa3a2cf768311fbd71977365b1bc92bcfc3baf7.
- Exakte Spezialblobs aus #934 (11) und #942 (2), korrigierter exportfähiger SVG-Nachtband-Fallback ohne Testaufweichung.
- Neue Source-/Core-/Heavy-/Review-/Browser-/iOS-/ZIP-/Installer-/Worker-/Pages-/Stable-Gates auf finalem Release-Head weiterhin notwendig.
- RUC #541/#946 und Release-Gate #947 ausdrücklich nicht enthalten; Pilot-Scanner-Befunde separat prüfen.

## MID v0.9.85.497 · 2026-11-19 · Responsive Ladehinweise, Ensemble-Reflow und 7-Tage-Tageslichtkontrast

- Kanonischer Ausgangsstand v0.9.85.496, SHA `256aabe286f7daa00dc0e320815dd8dacb7b4706`; fünf aktive GitHub-Rulesets, drei primäre Versionsspiegel identisch. QA-Intake #948 HEAD `5aa3a2cf768311fbd71977365b1bc92bcfc3baf7`.
- Spezial-Provenienz: #934 HEAD `f977cf30077a84791a4c212df93466199f295fd4` elf Original-Git-Blobs; #942 HEAD `4b274322383b580e8794482bb255698230c5e199` zwei Original-Git-Blobs. Der Widget-SVG-Export behält explizite Paint-Fallbacks; keine Regression absichtlich gelockert.
- Historisches Changelog byteidentisch bewahrt, release-spezifische Versionsspiegel synchronisiert. Kein RUC-Fast-Pages-Transfer (#541/#946), keine Source-Gate-Aufweichung (#947), keine Radar-/Karten-/Settings-Aufnahme (#929/#937/#920). Diese parallelen QA-Owner bleiben unabhängig.
- Draft-Checks #44477061382: gezielte Regressionen SUCCESS und Vitest/Coverage SUCCESS; P1-Scanner-Pilot meldete dennoch `PILOT_FINDINGS_OR_FAILURE` und braucht fachliche Triage. Source-/Review-/Heavy-/Browser-/iOS-/Installer-/Worker-/Pages-/Stable-Nachweise auf diesem Version-HEAD stehen aus.

## MID v0.9.85.496 · 2026-11-18 · Automatische PR-Eingangsprüfung, belegte Stationswerte und sichere RUC-Wiederherstellung

- Original Stable v0.9.85.495 SHA 8382ff3461ae21a385636e8261104b99bb8fccd0. Exakt 16 ausgewählte Original-Git-Blobs: #941 HEAD 710d3b7e06fb6dac860e313ea79164b4504a078a (7), #940 HEAD 4e568721389eb260f90c5ff1a3a78fcf75947070 (7), #939 HEAD 025595b1d0b70fb880005fb6eb435ca0fa2fdb2e (2).
- Zwei workflow YAML-Mirrors identisch, unprivilegierte pull_request-/Stable-only-Prüfung. Vier Original-weather.ts-Fragmente bleiben gegenüber generierter Datei bytegleich. RUC-Restore-Originalbasisblob von Stable .494 bis .495 unverändert.
- QA-Vortests der Original-Drafts: #941 Run 44411135343 (458 passed/3 skipped), #940 Run 44397398591 SUCCESS, #939 Run 44392686616 SUCCESS. Kein kombinierter Source-/Review-/Core-/Heavy-/Installer-/Worker-/Pages-/Stable-Nachweis.
- Nach erfolgreicher Promotion ist ein neues echtes PR-Ereignis mit aktiviertem Cleaner-intake-Job zu prüfen; erfolgreiches stable_ready mit intake=SKIPPED ist keine Abnahme.

## MID v0.9.85.496 · 2026-11-18 · PR-Cleaner, Stationsprovenienz und RUC-Restore

- Ausgangs-Stable v0.9.85.495 auf 8382ff3461ae21a385636e8261104b99bb8fccd0; fünf aktive Branch-Rulesets. Alle Original-Git-Blobs aus drei parallel geprüften QA-Drafts auf unverändertem Stable geprüft.
- Selektive 16 Dateien: Cleaner #941 (HEAD 710d3b7e06fb6dac860e313ea79164b4504a078a, sieben Dateien), Stationsprovenienz #940 (HEAD 4e568721389eb260f90c5ff1a3a78fcf75947070, sieben Dateien), RUC-Restore #939 (HEAD 025595b1d0b70fb880005fb6eb435ca0fa2fdb2e, zwei Dateien). Ursprüngliche Draft-Branches unverändert; #939-Basisblobs .494 und .495 identisch.
- Unprivilegierter GitHub-pull_request-Intake mit ausschließlicher Stable-Checkout-Ausführung und read-only SHA-/Blob-/Peer-Vergleichen; keinerlei Schließ-, Merge- oder Freigabeberechtigung. Ein grünes stable_ready ohne ausgeführten intake ist kein Cleaner-PASS.
- Stationsdaten: originale UTC-Messzeit und Missing/Null getrennt, neue Quellenhelper und vollständige unveränderte 4-Fragment-Aggregation von src/weather.ts. RUC: doppelte oder nichtkanonische Restore-Manifest-Schlüssel vor jedem parallelen Download/Write ausschließen, Originalwerte unverändert.
- Vorqualifizierte Einzel-CI: #941 44411135343 (458 passed, 3 skipped), #940 44397398591 SUCCESS, #939 44392686616 SUCCESS. Vollständige kombinierte Source-/Review-/Core-/Heavy-/ZIP-/Installer-/Worker-/Pages-/Stable-Gates bleiben auf diesem HEAD separat erforderlich, ebenso nach Stable-Promotion ein tatsächlicher neuer PR-Event mit intake-Job SUCCESS. Dokumentation erteilt keine Freigabe.

## MID v0.9.85.495 · 2026-11-18 · Ensemble- und Stations-Niederschlagsdaten ohne falsche Nullwerte

- Ausgangs-Stable v0.9.85.494 auf eee0bb0ac351115f5e85b7625825cc8d1376594f. Exakte ursprüngliche Git-Produkt- und Testblobs aus QA-Draft #919 (HEAD d3a0f9b6cb8f893d01dccf56bb30a0f0708493d6) sowie #936 (HEAD e802d2aae99c661d48d27a179d74446082a74439), auf aktuellem Stable konfliktfrei. Isolierte Vor-CI: #44272385899 (919) und #44386911744 (936), jeweils SUCCESS, nicht als kombiniertes Gate werten.
- Native Ensemble-Tagesfolgen müssen eindeutig, endlich, nichtnegativ und tatsächlich vollständig akkumuliert sein. Echte extreme Niederschläge und valide Nullwerte bleiben erhalten; künstliche Best-Match-PoP oder amtliche Warnstatus werden nicht daraus abgeleitet. Die sourceQuality-Änderung betrifft Stationsrelevanz und negative Beobachtungsakkumulation, nicht RUC/EPS-GRIB.
- Zusätzlicher Qualitätsguard aus dem historischen PR #925: kein neuer Timer, Netzwerkrequest, Listener, React-State-Owner oder localStorage in SelectedPlaceBar; bestehender gerenderter Status-Test bleibt zusätzlich erhalten.
- Vollständiges Source-PR-Gate, unabhängige Core-/Heavy-Matrix, relevante Review-/Browser-/iOS- und Installer-/Pages-/Worker-/Stable-Gates sind auf dem finalen kombinierten HEAD gesondert zu qualifizieren. Diese Release-Notiz ist keine Freigabe.

## MID v0.9.85.495 · 2026-11-18 · Vollständige Ensemble-Niederschläge und Stationsdaten-Provenienz

Ausgangsbasis: erfolgreich veröffentlichtes MID v0.9.85.494, `eee0bb0ac351115f5e85b7625825cc8d1376594f` ([Installer #44387133357](https://github.com/MeteoMartini/MID/actions/runs/44387133357)). SHA-verifizierte, auf dieser Basis konfliktfreie Original-Produkt-/Testblobs aus QA-Drafts #919 (HEAD `d3a0f9b6cb8f893d01dccf56bb30a0f0708493d6`) und #936 (HEAD `e802d2aae99c661d48d27a179d74446082a74439`). Isolierte frühere QA: [#44272385899](https://github.com/MeteoMartini/MID/actions/runs/44272385899) und [#44386911744](https://github.com/MeteoMartini/MID/actions/runs/44386911744) SUCCESS, ausdrücklich keine Abnahme dieses kombinierten HEAD.

Fachlogik: kumulierte Ensemble-Mitgliedsniederschläge ausschließlich aus lückenlosen, eindeutigen und als vollständig gekennzeichneten Quelltagen; NoData niemals 0, echte 0 und Extreme erhalten, 23-/25-h-Lokaltage separat abgesichert. Stationsbeobachtungen mit NaN-Alter/-Distanz/-Höhendifferenz werden nicht als räumlich und zeitlich exakte Anker zugelassen. Negative Quell-Niederschlagswerte bleiben Missing. Der historische Seiteneffekt-Testguard der SelectedPlaceBar aus #925 wird ergänzend zu den tatsächlich gerenderten Status-Assertions wiederhergestellt.

Nicht Bestandteil: laufendes RUC-Problem #541, Forecast-Cache-Provenienz #935, amtliche Warnungen, Worker-Netzwerklogik, produktive Release-Governance. Der endgültige Source-PR benötigt die neue kombinierte Core-/Heavy-/Browser-/iOS-/Review-Abnahme und den unveränderten SHA-gebundenen Releasepfad; dieser Absatz behauptet keine neue Veröffentlichung.

## MID v0.9.85.494 · 2026-11-18 · Lesbare Ortsnamen und zugängliche Wetterinfos

Basis: MID v0.9.85.492, `040402cf8ecd40c10a3fe3389d15a1c4f96c2826` nach erfolgreicher Stable-Promotion [Installer #44362133124](https://github.com/MeteoMartini/MID/actions/runs/44362133124). Git-Blob-identische UI-Quellen aus #925 (HEAD `1e67e76ec0bf54204968c477ba64a3282a0158fc`) und #927 (HEAD `aaf69ac3ee5d7042d5520292ec57a2495f5f6de7`) wurden ursprünglich in #933 HEAD `450a01aaf7bb34659fe3dc0d8c58f4604f3824d4`, Reviewkorrekturen bis `ad3c59dabb3c5aa001aaab3dc52810a944d7914d`, qualifiziert. Getrennte frühere Draft-CI: #925 [44304449418](https://github.com/MeteoMartini/MID/actions/runs/44304449418), #927 [44336876164](https://github.com/MeteoMartini/MID/actions/runs/44336876164), #933 [Source #44360390192](https://github.com/MeteoMartini/MID/actions/runs/44360390192) und [Vitest #44360390008](https://github.com/MeteoMartini/MID/actions/runs/44360390008). Die isolierte, echte Chromium-React-Fixture aus #927 umfasst acht Viewport/Themen-Kontexte, ist aber kein nativer iOS-/VoiceOver-Vollappnachweis.

Die `.494`-Version wurde auf aktueller `.492`-Stable-Quelle mit erhaltener `.492`-Historie und unveränderten originalen UI-/QA-Git-Blobs zusammengeführt. Der ursprüngliche #933-HEAD ist als Eltern-Commit gesichert. Die neuen Source-/Review-/Core-/Heavy-/Installer-/Worker-/Pages-/Stable-Gates sind auf dem **neuen** integrierten PR-HEAD erneut vollständig erforderlich; frühere .491-Source-Gates qualifizieren diesen Merge-Tree nicht. Zwei zuvor offene Cubic-P3-Reviewhinweise (SHA-/CI-Nachweis; source-text-only ARIA-Test) müssen auf aktuellem HEAD in GitHub nachvollziehbar triagiert werden. Kein Release oder neuer Worker-Rollout durch dieses Changelog.

## MID v0.9.85.492 · 2026-11-18 · Frischeprüfung für RUC-Niederschlagsdaten

Basis: MID v0.9.85.491, `3f9c5e24dc55fa5154732a1ba73961ba76c29788`. Drei unveränderte Originalblobs aus #541, QA-HEAD `70cc07b881dd18e780e0c4e5d08c5759fbe60305`. Vorgesehen für das vollständige MID Source-Gate und den regulären Release-Train. Fast-Lane und RUC-Veröffentlichungsvorgaben bleiben unverändert.

## MID v0.9.85.491 · 2026-11-18 · Ensemble-Skalierung, Kartenlegende und vollständige Wochenwerte

Basis: MID v0.9.85.490, `42c188f44606f511826d2b6665b764c36b23412c`. Zwölf Originalblobs aus #913 (`f99b5e5ebc31fdaa923a6919d36de172ffbd5e4d`), #916 (`e5d4702ca88979c35e213ec2b6622de95cd13e2b`), #917 (`c9a7247a9426fe877616bb02ddd467af05205f48`) wurden mit Stable abgeglichen.

## MID v0.9.85.490 · 2026-11-18 · Touch-Sortierung und Wetterzwilling-Messlücken

Basis: MID v0.9.85.489, `5fe79b03852a7464b4a510813920c1965d8ee0d0`. Quell- und Testdateien aus #900 (`d44d8dddbb63f4f31136dd518895ed51a27c0b61`) und #907 (`ca7d3ce048d48801879c14fbfc1ab874a6f64c7f`) wurden mit Stable abgeglichen und blob-identisch übernommen. Die kombinierte Abnahme erfolgt über den Release-Train.

## MID v0.9.85.489 · 2026-11-17 · Archiv-Vorlauf und Changelog-Integrität

- Ausgangs-Stable main=mid-stable=9fe4dfbcdfd5a1f8fec55efa868e22110a612953 / v0.9.85.488, fünf unveränderte aktive Rulesets.
- Audit #899 original HEAD 115012fce035b4d7dfc6eb937654bcda93ce8fb5: sechs SHA-identische Dateien, Einzel-CI 44135776780 completed/success; Validierung ISO-Zeit/Offset, Zielmittag und DST-23-/25h-Tage ohne Kalender-Normalisierung.
- Leitwork-Karten-Quell-Draft #868 original HEAD dd9a9cc6eaca641785b095bf79862a4b1ba051cd: nur drei SHA-identische, disjunkte Changelog-Korrekturblobs, nicht die 213 unfreigegebenen Karten-/CSS-/GPU-Pfade.
- Historische CHANGELOG.md und public/CHANGELOG.md Git-Originalbytes 1:1 erhalten, ausschließlich .489-Abschnitt vorangestellt; idempotentes sync-version geschützt durch neuen Test.
- GitHub Releases/Tags weiterhin extern separater Issue #901; keine neuen Rechte, Worker-Pipelines, ZIP- oder Release-Workflowänderungen; #839/#740 in Security-Spezialarbeit. Vollständige Source-/Review-/Core-/Heavy-/Installer-/Pages-/Worker-/Stable-Gates auf finalem SHA erforderlich.

- Security-Only-Fix #903: genau zwei Git-Commits nach LC-Draft c094a971 (34560bd7 Dependency-Alias/Lockfile, 771b6a5a bestehende Pflichtregression); npm SHA512-gepinnter, signaturgeprüfter Scoped-Fork @ryotsu/picomatch@4.0.7-a, 42 bounded CVE-2026-112366-Testfälle. Isolierte Node22/npm10 npm ci, audit:all (0 HIGH/CRITICAL), audit:dependencies, npm audit signatures sowie Vite8/React19-Smoke bestanden. Kein echter MID Source-/Installer-/Stable-Beleg; kein automatischer Security-/Release-Bypass. #839/#740 kein pauschaler Blocker.

## MID v0.9.85.488 · 2026-11-17 · Wetterzwilling-Messwerte und mobile Navigation

- Verifizierte Ausgangsbasis main=mid-stable=ee70a92ae6ed83d3fa46445f4941e3db8b8675d4 (v0.9.85.487), fünf aktive Rulesets.
- Wetterzwilling-Originalquellen #897 HEAD e5830085739252d2bc7e4a40b88d2abe39e883df: fünf Git-Blobs unverändert übernommen; Einzel-Vitest und gezielte Regressionen #44114471352 completed/success.
- Design-Originalquellen #893 HEAD c25c205844c29d1fb1bb2074be660332de2db10a: vier Git-Blobs unverändert übernommen; bestehende geänderte Quellpfade seit v0.9.85.486 identisch, Einzel-Vitest und gezielte Regressionen #44102613813 completed/success.
- Source-Integration erst durch kombinierten SHA-/CI-Readback zu validieren; kein Produktiv-Release, bevor Source-Gate, kontrollierter Merge, ZIP, Installer, Worker/Pages und Stable-Promotion nachgewiesen sind. #839/#740 bleiben getrennt.

## MID v0.9.85.487 · 2026-11-17 · Wetterzwilling und Modellfrische

- Basis: Stable `a78465b655d25cafc9ecc0390080694cb7aca957`. Auditkorrekturen aus #884, #885, #886 und #890, geprüft in #868 auf `dd9a9cc6eaca641785b095bf79862a4b1ba051cd`. Veröffentlichung über Source-PR-Gate, Release-Bot, Installer und Stable-Promotion.

## MID v0.9.85.487 · Audit-Teilrelease

Basis: Stable `a78465b655d25cafc9ecc0390080694cb7aca957`. Auditkorrekturen aus #884, #885, #886 und #890, geprüft in #868 auf `dd9a9cc6eaca641785b095bf79862a4b1ba051cd`. Veröffentlichung über Source-PR-Gate, Release-Bot, Installer und Stable-Promotion.

## MID v0.9.85.486 · 2026-11-16 · Karten-Home-End und 14-Tage-Responsive-QA

- Additional QA source: #846 HEAD e70b5aa36a1832aba6a1c081add4f839c629dc5a, exactly two original Git blobs; MapTimelineControls + associated unit file already identical with #842 and therefore not imported again. Deferred-ACK Home/End is tested in real React/Chromium by mandatory map heavy regression; no skip or timeout dilution.
- Stable-Source ccd1c0f60d67925aa01dd8d946b490fde4142709 (v0.9.85.485); n=11 selektive (9 Produkt-/QA + 2 echte React-Browser-QA), SHA-identische Dateiübernahmen aus #842 HEAD 3d9a1bb489bb8bc0b7d15699957b6289398dfd07 (2) und #844 HEAD 7d7422ab868dc0cda3094f24b97ad21e7a8f88f7 (7), disjunkte Pfade.
- Vorherige Draft-Gates: #842 Vitest #43862446558 SUCCESS; #844 Vitest #43865229772 SUCCESS mit 32 Chromium-Fixtures. Kein PASS des neuen kombinierten Heads ohne eigene Gates.
- Die am .485-Source-Gate einmal beobachtete 1440px-Index-Race (select 0→1) ist NICHT durch diesen Home-/End-Fix allein als behoben nachgewiesen; Map-Heavy-Gates vollständig wiederholen und Fehler separat triagieren.
- Keine Änderung an WMO/DWD-Warnungen, meteorologischen Quellen, Modelllauf, Akkumulation, Missing-Data-Semantik oder Worker-Laufzeitlogik. Issue #740/#839 bleibt beim Sicherheits-Spezialchat.
- Freigabe nur nach full Source-PR-Gate → kontrolliertem SHA-Merge → serverseitigem ZIP → install-mid.yml → Worker/Pages → Stable. Kein Vorziehen von übersprungenen Checks.

## MID v0.9.85.485 · 2026-11-16 · 14-Tage-Lesbarkeit und CSS-Eigentümerprüfung

- Quellbasis mid-stable/main 8f4c950c3d0311f33ed3f9b89d0101d6cd556113 / v0.9.85.484; Spezial-Draft #840 head dd90d5b64f6aeb4ac0f517bc0aa64329e26ee722 (4 Dateien), #841 head d327e6154dc26d696c74379f6dec994ccf57631b (8 Dateien), QA-Intake #843 head 3418396a29e7b8c5682aeef6addfa1ab61c9cf55.
- Alle zwölf Git-Blobs unverändert übernommen; vorherige Stable-Quellblobs identisch oder jeweilige Datei neu. Unabhängiger kombinierter Vitest/Regression Pilot #43862957994 SUCCESS (volle Source/Core/Heavy/Installer/Worker/Pages-Gates separat erforderlich).
- 14-Tage-Regressionsmatrix: CSS-Textfluss, CSS-Kaskade/Quellfingerprint und reale React/Chromium-Viewport-Checks aus Spezial-Draft; native iOS-/WebKit-/VoiceOver-/Dynamic-Type-Abnahme nicht vorgetäuscht.
- Kein CSS-Lazy-Split und keine neuen Wetter-/WMO-/DWD-/NoData-/Warnungsänderungen. #740 Native-Review-/ZIP-Cutover ausschließlich in Spezial-Chat Release Konzept 1.4, dort weiterhin offen. Keine neuen Anbieter/Abos.

## MID v0.9.85.485 · 2026-11-16 · LC 1.9 14-Tage-Wettertexte / CSS-Ownership (SOURCE-KANDIDAT, NO RELEASE)

- Source of truth am Start `main=mid-stable=8f4c950c3d0311f33ed3f9b89d0101d6cd556113` / v0.9.85.484; fünf Rulesets aktiv. PR #843 erhält exakt 4 originale Git-Blobs aus QA-Draft #840 head dd90d5b64f6aeb4ac0f517bc0aa64329e26ee722 und 8 aus Design-Draft #841 head d327e6154dc26d696c74379f6dec994ccf57631b; Quellpfade gegenüber altem Stable entweder unverändert oder neu. Integrationstree 4b9c4d9d6d669989e4dbd4fbffd0b237eef191ad, QA-HEAD 3418396a29e7b8c5682aeef6addfa1ab61c9cf55.
- QA-HEAD-Draft-Pilot GitHub Run 43862957994 completed/success (gezielte Regressionen und Vitest/Coverage); keine vollständigen Source-/Heavy-/Release-Gates. Versionsspiegel werden für .485 vorbereitet, ein neuer Source-HEAD benötigt unabhängige vollständige CI und SHA-gebundene Reviewprüfung.
- Fachlich: 14-Tage-Wetterbeschreibung ohne ellipsis, lesbarere Metadaten und 390px-Header-Layout; CSS-Cross-Owner-Guard ist eine Lesesicherung, kein CSS-Split. Originaltext, Wetterwerte, NoData, WMO-/DWD-Warnsemantik, RUC und iOS-native Implementierung unverändert. Browsermatrix aus Spezial-Draft (24 Chromium-Fälle) ist keine physische iOS-/VoiceOver-/WebKit-Abnahme. 200%-Text-Stress bleibt separat zu prüfen.
- Keine doppelte Übernahme der in .484 integrierten Umfeld-/Radar-/Lüftungs-/Offline-Hilfsdateien. Sicherheits-Issue #740 verbleibt im Spezialchat; vorhandene GitHub-Protection-/Review-/Installer-Gates dürfen nicht abgeschwächt oder übergangen werden. Kein Release, bis Source-Gate, SHA-Bot, ZIP, Installer, Worker, Pages und Stable nachweislich erfolgreich sind.

## MID v0.9.85.484 · 2026-11-15 · Karten-Zeitqualität, Umfeldwetter und sichere Codeprüfung

- Quell-SHAs PR #825 11a2c028c5a966094b7d15711b7c65bca4ffe58a; #824 f82c01b0a4fb7a23a1ea9c681ebfcf0b62381c3a; #826 b741bf461c0e439611f3254b3544d43fb3ea5e57; #827 92fefc860d0caf64fc23fbe377dbc9a6bc334a0d; Main/Stable c9fadfcd0969e949a92f414b321627dd3d4fb0cc.
- 33 SHA-identische Source-/QA-Diff-Pfade und sämtliche Versionsspiegel 0.9.85.484, kein externes AI/IR10.8-Raster.
- Vollständige Source-/Core-/Heavy-/Installer-/Worker-/Pages- und Security-Gates erst auf finale Kombination anwenden; kein automatisches PASS.
- PR #830 SHA 98387916d0dd3a2e93ac01d0a424c560fa603dc4: 4 disjunkte MapLibre-Layer-/QA-/Dokumentationsdateien, keine gemessene Laufzeitersparnis, kein eigener .485-Build.
- Issue #829: bestandswahrender API-Quotencircuit je exakter Origin, Pflicht-HTTP-429/NoData bleibt BLOCKED und nicht als Schema-PASS klassifiziert.
- LC 1.7: #832 @ aa727db59e18020068edfe762d6491eaeae3bd82 selektiv mit #828 zusammengeführt; identische CloudScheduler/TemperaturDisplay-Git-Blobs nicht dupliziert, 828-aria-valuetext gezielt erhalten; vollständiger Viertelstunden-Cloud/SigWx-Originaldatensatz nicht freigegeben.
- LC 1.7: fünf langlebige CSS-CDP-/Browser-/Unit-/Doku-Git-Blobs #831 @ bc9d356e0d3806a59f3d113fce75ba98cd4f85ba importiert, temporäre #831 unit-coverage-Workflowspiegel ausdrücklich ausgeschlossen; QA-Erfolge des Herkunftsbranches übertragen sich nicht auf kombinierten Commit.
- LC 1.7 QA-Nachtrag: #832 HEAD 9731f02c44367764093f4485f2cbcd1a54e2c72c; SHA-gebundene Radar-URL/Art/Zeit-Identität und synchrone Cloud-Zeit-/Ort-Identität. Zwei Python-IR10.8-Offline-/Stage-Tools sowie erweiterte IR-Testlauf-Datei bleiben ohne unabhängige Datenqualifikation bewusst im Quell-Draft, nicht in der Releasekombination.
- CSS-Owner QA #826 HEAD 537ae9b697a78dc338155f58b2b642cdf75dff32: kanonisches Manifest strikt relativ zum Skript statt cwd, Missing immer Fehler auch außerhalb CI; gezielter foreign-cwd Vitest. Keine CSS-Löschung, keine CSS-Budget-Schwächung.
- LC 1.7 #832 HEAD 5d045f4b6e587a50efcc5d704ee7798b50bdcdfc: OPERA original source requestKey and 45min/90sec freshness limits; exact source blobs for radar helper and expanded regression; narrow CurrentSurroundings merge preserving aria-valuetext from #833. No IR10.8 staging or spectral model publication.
- LC 1.7 #834 HEAD cc46de12729f2f2d63898c12755c18f75d32ee4e: five lasting original blobs (App.tsx, vite.config.ts, on-demand Vitest, strict ventilation regression and QA document) adopted. Temporary unit-coverage workflow mirrors excluded. Historical source run 43765507092 had a stale eager-JSX string assertion, corrected by the specialist's newer source SHA: exact-head targeted regression, Vitest and TS check SUCCESS. Actual final combined Vite bundle/Browser/Offline E2E remains independently unverified.
- LC1.7 #835 QA-Draft SHA a82440de4ef2e4f88f281c9a6d5f0622ca8993f2: 5 exakte Git-Blobs für kodierte Dot-Segment-URL-Inventar-Fail-Closed (JS/CSS) und bestehende registrierte positive/negative Budgettests. Quelle auf Stable c9fadfcd0969e949a92f414b321627dd3d4fb0cc, 0 Pfadüberschneidungen, Vitest und gezielte Draft-Regressionschecks auf Spezial-HEAD SUCCESS; Integration am neuen kombinierten SHA separat neu prüfen. Keine Änderung an Budgetgrenzen, Browser-/Network-Zahlen oder Wetter-/Worker-Verhalten.
- LC17 #836 latest source HEAD e69b6831ab775e6cb9792b73f232a28ce5f77791, Stable base c9fadfcd0969e949a92f414b321627dd3d4fb0cc: 4 aktuelle originale Git-Blobs, kein Pfadkonflikt; SHA-gebundenes offlineShell-Assetinventar additiv zu scripts/measure-startup-assets-0985482.mjs, formatgetrennte raw/gzip/Brotli- und HTML-Start-vs-Offline-Metriken. Die nachträgliche Quellhärtung verweigert Browser-Preload-/modulepreload-/prefetch-/stylesheet-Mischlinks; zusätzlich synthetischer kompletter Dist-Identitäts-/Mess-Smoketest. Beide gezielten GitHub-Draft-Jobs am exakten Spezial-HEAD SUCCESS. Keine Änderung an Startup-Budgets, der Produktions-Vite-Konfiguration, Meteorologie, Workflows oder Stable. Finaler integrierter SHA und echtes Production-dist/Browsertest stehen aus.
- LC1.7 / DWD-D2 #446: gezielte konservative Python-Evidenzregression für originale +47/+48h CCSDS-Skalenfaktoren und winzige ungleichnullige ecCodes-referenceValue. Der Test reproduziert 1 negative Zelle um -0.001953125 mm im synthetischen 4er-Feld, prüft Originalwerte unverändert, NoData-Preservation und weiterhin productionApproved:false. Keine Änderung an assess_original_packing, Native-Admitter, Rundungstoleranz, D2-Herkunft, Renderer oder Produktionsfreigabe; neues Original-GRIB/Signer/E2E-Gate weiterhin separat rot/unbewiesen.
- MID LC 1.8: Nicht produktionsreife Issue-#740-Review-/ZIP-/Cutover-QA ist bewusst aus dieser .484-Produktfassung herausgenommen und wird ausschließlich im Spezialchat MID Release Konzept 1.3/QA-Draft #839 weiterbearbeitet. Kein #740-Sicherheitsabschluss und keine Änderung der bestehenden produktiven Schutzregeln. Bei jedem Release bleiben kritische Befunde und sämtliche unveränderten Source-/Review-/Installer-/Worker-/Pages-/Stable-Gates verbindlich.

## MID v0.9.85.484 · MID LC 1.6 – vier SHA-verifizierte Spezial-Drafts konsolidiert (SOURCE-KANDIDAT, NO RELEASE)

**LC 1.6 zusätzlicher Trust-Boundary-Pilot:** Beide privilegierten workflow_run-Folgeworkflows erhalten job-level Same-Repo-/Ereignis-/Branch-Filter und behalten ihre bisherige SHA-/Review-/stable-Classifier-/Token-Trennung. Self-Heal prüft vor Retry zusätzlich die tatsächliche Installer-REST-Metadaten-Identität gegen aktuellen main-HEAD und isoliert die Logdateien mit mktemp/umask 077. Vier YAML-Dateien bleiben in zwei exakten Paaren synchron; neue ausführende jq-Positiv-/14-Negativtests. Keine Permission-, ZIP-, Ruleset-, Bot-Transport- oder Gate-Abschwächung und ausdrücklich KEINE Entwarnung für #740 oder die zwei zizmor-High-Signaturen. Technischer Nachweis docs/implementation/MID_LC16_WORKFLOW_RUN_TRUST_HARDENING_2026_11_15.md. Kandidat bleibt Draft.

**Additive MID LC 1.6 QA-Fortsetzung:** #829 rate-limit-aware Live-API-Vertragscheck (gleiche Origin nach bestätigtem 429 nicht erneut belasten, erforderliche Schema-Prüfungen bleiben rot), sowie #830 @ `98387916d0dd3a2e93ac01d0a424c560fa603dc4` (vier disjunkte MapLibre-/QA-Dateien, davon drei unveränderte Code-/Test-Git-Blobs; dokumentarische Integrationsnotiz separat). Der MapLibre-Scheduler fasst synchrone Registrierungen pro Karteninstanz zusammen und entfernt `essential:true` aus optionalen Kameraflügen; keine neue Wetterquelle, Schwellwertänderung, Dateninterpolation oder amtliche Warnungssemantik. Original-Fachprüfungen und alle Source-/Installer-/Worker-/Pages-/Stable-Gates noch unabhängig erforderlich. **Keine reale GPU-/iOS-Leistungsmessung aus den Unit-Drafts ableiten.**

**Quellbasis:** `main=mid-stable=c9fadfcd0969e949a92f414b321627dd3d4fb0cc` / v0.9.85.483; fünf aktive Rulesets. Neue QA-/Source-Kandidatur aus #825 @ `11a2c028c5a966094b7d15711b7c65bca4ffe58a` (12 Karten-/Zeit-/Temperatur-Dateien), #824 @ `f82c01b0a4fb7a23a1ea9c681ebfcf0b62381c3a` (4 Scanner-Evidenzdateien), #826 @ `b741bf461c0e439611f3254b3544d43fb3ea5e57` (6 CSS-Ownership-/Baseline-Dateien) und #827 @ `92fefc860d0caf64fc23fbe377dbc9a6bc334a0d` (11 GitHub-Workflow-/Security-QA-Dateien). Die vier Quell-Diff-Mengen sind disjunkt; exakt die bestehenden Git-Blobs übernommen, danach nur der gemeinsame Versionssatz 0.9.85.484, Nutzer-Changelogs und die technische Integrationsdokumentation. Keine Hauptbranch-, Ruleset- oder Production-Writes aus diesem QA-Schritt.

**Fachlichkeit:** Viertelstunden-Zeitachsen mit tatsächlichem INIT/VALID und Screenreader-Phase; orts-, termin-, koordinaten- und interpolationsgebundene Temperaturdarstellung statt stale Werten; 150-ms-Scrub-Koaleszenz vor Originalfeld-Fetch. WMO-4677-SigWx nie interpolieren; Source-Original, NoData, Warnungsamtlichkeit und RUC-Integrität unverändert. IR10.8-Live-Raster weiterhin NICHT freigegeben; kein AI-Router- oder externer Modell-Dispatch.

**Sicherheit und Audit:** Zizmor-Fundstellen vollständiger read-only Ledger, dessen Unvollständigkeit nicht als PASS gilt; 13 checkout-credential-Persistenzen aus vier Workflowspiegel-Paaren per `persist-credentials:false` beseitigt; zusätzliche CSS-Eigentümer-/Kaskadenprüfung in verpflichtendem Regression-Shard aufgenommen. Die zwei High-`dangerous-triggers` und die unabhängige native Review-Merge-Race-Problematik (#740/#775) sind dadurch nicht automatisch gelöst; Reviewstatus am finalen Integrations-HEAD ausdrücklich prüfen.

**Keine vorweggenommene Freigabe:** CI für **kombinierten** HEAD, npm ci, TS/Build, Version-Mirror-Freeze (19 Pfade), Source-Core 4/4 + Heavy 6/6, wissenschaftliche Checks, DWD-RUC-/Worker-/Pages-Verträge, Browser-/Touch-/WCAG-Audits, aktueller Cubic-/Review-Readback und Source→SHA-Bot→server ZIP→Installer→Worker/Pages→Stable stehen als unabhängig notwendige Gates an. Browserprüfungen sind keine physische iOS-/VoiceOver-Abnahme. Keine Prüfung ohne tatsächlichen Run als PASS melden.

## MID v0.9.85.483 · LC Source-Gate Core 2/4 + 4/4 echte Fehlerbehebung (NO RELEASE)

**Quellstand:** `c965679c364d0b77a6c869b9e330bdf2a6ae05bf`, Source-Run [43732194107](https://github.com/MeteoMartini/MID/actions/runs/43732194107), Ergebnis failure (aggregator korrekt rot). Vor diesem Fix: Source-Kern, sechs Heavy-Shards, Core 1/4 + 3/4 und echte DWD-Originalaufnahme erfolgreich. **Core 2/4:** `test-budget-file-evidence-0985426.mjs:14` hielt an einer unvollständigen statischen Testfixture ohne HTML-`type=module` fest, obwohl die neue Startup-JS-Provenienz ein tatsächliches Modul verlangt. Ein einziges gültiges, kleines Modul wird ergänzt und explizit `initialJsFileCount=1` geprüft. Das fehlende Modul wird zusätzlich als zwingend abzuweisender Negativfall nachgewiesen. Alle Roh-/gzip-/SHA-/Obergrenzen, einschließlich absichtlich überschrittener Medienbudgets, bleiben identisch. **Core 4/4:** `test-current-surroundings-temperature-0985476.mjs` ruft die zehn IR10.8-Manifest-Testfälle auf; in der absichtlich ungültigen Duplicate-URL-Probe wurde bereits ein synthetisches `.bz2`-Objekt dekodiert, bevor später stehende fehlerhafte Manifesteinträge abgewiesen waren (`OSError: Invalid data stream`). Der Auditor prüft jetzt **alle** URL-/Run-/Duplikat-/Symlink-/SHA-/Dateigrößenbedingungen vollständig und fail-closed vor dem ersten GRIB-Decode; direkt vor jedem Decode werden Dateityp und SHA noch einmal geprüft. Aktivierung bleibt unconditionally `false`; die IR/WV-Quelle wird weiterhin nicht publiziert, Missing/Extreme nicht geglättet.

**Pflicht:** Kombinierter Source-/Core-/Heavy-/Browser-/RUC-/Security-/Review-Gate erneut auf dem neuen unveränderlichen HEAD; nach bestandenem Bot-Merge nur etablierte Installer-/Worker-/Pages-/Stable-Gates. Kein Abschwächen eines Limits oder gültiger Regression, keine neue Wetterebene, kein zusätzlicher Dienst.

## MID v0.9.85.483 · LC 1.5 Source-Gate-Unified-Map-Zeittest korrigiert (QA-Fix, NO RELEASE)

**Reproduzierbar rot:** Source-Gate [43731887536](https://github.com/MeteoMartini/MID/actions/runs/43731887536) auf `bfd1e9987ce725c856441d67331ad2a4f22840eb`; die Heavy-Unified-Map-Shards 1/3 und 2/3 wiederholten die identische Assertion in `scripts/verify-unified-map-browser-0985167.mjs:613`: `Relative time is visible in a single clock`. Der bisherige Test erwartete `+15/+30/…/+120 min` nach 1–8 Klicks, obwohl die bereits fachlich geprüfte neue UTC-Viertelstundenachse `surroundingsQuarterHourTarget(now,step)` die verbleibenden echten Minuten ab der aktuellen Uhrzeit ausweist; 9 Schritte garantieren erst +120 min bei beliebiger Phase innerhalb einer Viertelstunde. Das ist ein **veralteter Browser-Testvertrag**, kein gemessener Fehler des Modellfelds. Genau die vorhandene Teststelle wurde dem beabsichtigten Produktvertrag angepasst: strikt inkrementierte 15-min-Zielschritte 1–9, echte verbleibende Minuten pro Slot im physikalisch gültigen Fenster `((step-1)*15,step*15]`, übereinstimmendes Accessibility-Label, absolute Zeit im selben Output, Endgrenze bei 9 und Rückschritt auf 8. Frühere 44px-/Overflow-/Cloud-/Radar-/NoData-Assertions bleiben unangetastet. Kein Schwächen einer fachlich gültigen Prüfung, keine Produkt-/Quellen-/Warnungs-/Versionsänderung. Erfordert vollständig neue gemeinsame Draft-/Source-/Core-/Heavy-/Browser-/Release-Gates am Folgesha; alte Source-Fehler bleiben echte rote Historie.

## MID v0.9.85.483 · MID LC 1.5 – SHA-verifizierter Performance-/Umfeld-Handoff (QA)

Geprüfte Provenienz: Stable f9c0b182b0e11278651e2afa13039015e1aa0f0b, Performance #819 dcba04bfeb58ef4a3fa007922ec35faaddbc991f, Karten #820 2e1465456f46e33dd03f89ed2bfe1ba62c8cfbaf. SHA-identische Produkt-/Test-Dateien aus aktuellen Spezial-Drafts; keine Doppelübernahme von #815/#817 und kein externes AI-Router-Deployment. IR10.8-Offline-Auditor bleibt `activationAuthorized: false` wegen IR/WV-Zuordnung und fehlendem echten Originaldaten-/Renderer-Nachweis. Aktuell nur QA-Kandidat; vollständige Source-/Core-/Heavy-/Browser-/Review-/Installer-/Worker-/Pages-/Stable-Gates am finalen Kombinations-SHA stehen aus. Details `docs/implementation/MID_LC15_RELEASE_TRAIN_483_2026_11_15.md`.

## MID v0.9.85.483 · CSS-/JS-Performance, Regressionsvorbeugung und kontrollierte Integrationsbasis (QA-Kandidat)

**Basis und Provenienz:** verifizierter `mid-stable=f9c0b182b0e11278651e2afa13039015e1aa0f0b`, v0.9.85.482. Die 16 ausgewählten, ursprünglichen QA-Git-Blobs des unabhängigen Performance-PR #815 (Head `8022f1d744c5226c829de93fc0167e4863fbec69`) sind SHA-identisch selektiv übernommen; die .482-API-Fehlerdiagnostik bleibt als Stable-Grundlage erhalten. Keine Rebase- oder Force-Push-Operation, keine Direktänderung von `main` oder `mid-stable`. Versionsspiegel auf v0.9.85.483 synchronisiert; vier neue Regressionen vollständig registriert, vorhandene Core-Shard-Positionen beibehalten.

**Inhalt:** `PushSettingsPanel`, `ICloudBackupSettings`, `WeatherTwinSettings` und `DataConnectionDiagnostics` werden nur in ihren auf Anfrage geöffneten Einstellungen mit React.lazy geladen, mit typisierter Props-Weitergabe und barrierefreiem Lade-Status. Die kritische Geräte-Synchronisation bleibt unverändert. Der neue, unabhängige Performance-Draft-Diagnosebuild misst initial direkt referenzierte CSS-/JS-Dateien (Rohgröße, gzip-9, CSS Brotli-6) und prüft eine vollständige Dist-SHA-Provenienz. Zusätzliche Initial-JS-Schwellen `2.400.000 B` Rohgröße und `750.000 B` gzip-9, ohne alte Budgets zu erhöhen. CSS-Kaskadenkonflikte sind dokumentiert, keine CSS-Regeln blind verschoben.

**Neue unabhängige Messung gegen erfolgreich veröffentlichte .482:** Installer [43719514309](https://github.com/MeteoMartini/MID/actions/runs/43719514309), Originalartefakt `mid-built-43719514309-1` und vollständiges 4040-Datei-SHA256-Manifest. Stable .482 initiales JS 2.277.626 B roh / 688.078 B gzip-9, .483-Diagnosebuild bei vier optionalen Lazy-UIs [43723225593](https://github.com/MeteoMartini/MID/actions/runs/43723225593) 2.230.496 B roh / 676.369 B gzip-9 (−47.130/−11.709 B). Hauptindex-JS 1.484.986→1.438.554 B; CSS initial 1.755.595 B roh, 249.104 B gzip-9 unverändert. Keine Messung von Netztransfer, realem RAM oder CWV.

**20-Zyklen-Post-GC-Stable-Referenz:** Der offizielle .482-Installerjob `Release-Heavy · heavy-unified-map · 1/3` (Job-ID `132828291005`) meldete H0 35.755.240 B und H20 36.368.824 B Used Heap (+613.584 B / +1,72 %) nach zwei Warmups, mit `nodes 1102→1102`, `listeners 485→485`, `documents 4→4`. Synthetische Software-GPU-MapLibre-Fixture, kein Leck- oder iOS-Gerätenachweis. Kandidaten-GC-Profil, reale responsive Bedienung und vollständige Source-/Release-Gates offen.

**Messstand:** Das alte .481-Diagnosepaar ergab bei gleichem Source-Umfeld 2.277.626 → 2.262.106 B initiales JS roh und 688.085 → 684.029 B gzip, bei unverändertem initialem CSS. Diese Messung ist **kein** validierter Vergleich mit v0.9.85.483 oder neuem v0.9.85.482-Stable. Der exakte SHA-Kandidatenbuild, vollständige Source-Gates, Browser-/iOS- und GC-Speicherprüfung müssen separat erfolgreich nachgewiesen werden. Offen bleibende Prüfungen verhindern Release-Behauptungen.
## MID v0.9.85.482 · API-Datenqualitätsdiagnose differenziert und fail-closed (Source-Kandidat)

**Verifizierte Ausgangsbasis:** `main=mid-stable=19a8af8f5d0c47784acde7628746fa9020ef4f62`, v0.9.85.481; fünf aktive Rulesets. Selektive fachliche Integration aus [QA-Draft #816](https://github.com/MeteoMartini/MID/pull/816), exakter Source-Head `2fdf9f3f865ab34697f44e7de39ac98f6a66401b`; unveränderte Git-Blobs für `scripts/api-contract-request.mjs`, `scripts/check-api-contracts.mjs`, `scripts/test-api-contract-retry-0985111.mjs` und `scripts/test-api-contract-nodata-0985291.mjs`. Aktiver CSS-/JS-Design-Draft #815 ist ausdrücklich **nicht** Bestandteil und wird nicht verändert.

**Befund zu #814:** Der vorherige Revisionslauf auf .480 scheiterte beim echten Best-Match-/Mond-Abruf mit `fetch failed` nach drei Versuchen. Kein tatsächlicher API-Schemawechsel, kein wiederholter Live-Providerfehler und kein meteorologischer Fehler sind daraus belegt. Ziel ist nicht, den Provider als verfügbar zu erklären, sondern den tatsächlichen Ursprung künftiger Ausfälle prüfbar zu unterscheiden.

**Änderungsumfang:** Nur API-Vertragsdiagnostik und bestehende Negativtests. Strukturierte `Error.cause`-Fehlercodes werden mit begrenzter Tiefensuche zu DNS/TLS/Timeout/Abort/Connectivity/Unclassified kategorisiert, ohne beliebige Meldungen, Tokens oder Querystrings auszugeben. Provider-HTTP-Fehler (`!response.ok`) werden nicht mit HTTP-200-Schemafehlern verwechselt; kritische Datenpfade bleiben bei beiden roten Fällen `exit 1`. Unveränderte Retry-Grenzen, kein Missing→0, kein neuer Fallback, kein Worker-/Wetter-/iOS-UI-Feature. Existing `NoData`-Test startet echte CLI-Negativprozesse für DNS, HTTP 503, fehlendes 200er-Schema und prüft die Fehlermeldungen.

**Zusätzliche Browserregression:** Das erste vollständige Source-Gate [#43718013536](https://github.com/MeteoMartini/MID/actions/runs/43718013536) meldete eine intermittierende Assertion `verify-unified-map-browser-0985167.mjs:184`: Nach `selectOption('0')` war die DOM-Select-Wahl bereits 0, Reacts vorherige-Schritt-`disabled`-Eigenschaft aber noch nicht nachgezogen. Der Test wartet begrenzt auf **beide** tatsächlichen Produktzustände und führt danach dieselbe strenge Assertion erneut aus. Bei Timeout fail-closed mit Diagnose, keine Prüfumgehung oder Änderung der Produktkarte. Der neue HEAD benötigt die vollständige Source-QA erneut.

**QA-/Release-Stand bei Quellenübergabe:** [Draft-QA #43715901184](https://github.com/MeteoMartini/MID/actions/runs/43715901184) auf `2fdf9f3f865ab34697f44e7de39ac98f6a66401b` `completed/success`; vollständige Source-, Installer-, Worker-/Pages- und Stable-Gates des neuen Integrationscommits sind noch auszuführen. Keine reale Open-Meteo-Liveabnahme und keine unabhängige iOS-/VoiceOver-Gerätefreigabe behauptet. Die vollständigen MID-Release- und Sicherheitsverträge gelten unverändert.

## MID v0.9.85.481 · Umfeld 15-Minuten-Steuerung, konsistente Originaldaten und besser lesbare Temperaturmarker (Source-Kandidat)

**Quelle:** GitHub-Stable `11d5793546f15e384bb36d7b7111818f41904bae`, v0.9.85.480; isolierter `chatgpt/v0.9.85.481-surroundings-15min`-Integrationsbranch. Bestehende Legacy-Drafts werden nicht pauschal gemergt. Keine Änderungen auf geschützten Branches.

**Fachliche Trennung:** `src/currentSurroundingsCloudImage.ts` wählt Originalwolken/SigWx aus SHA-geprüften Synoptik- und nativen DWD-Quellen; nur bei gleichwertigem Modelllauf, Raster, Ort, höchstens 60 Minuten Abstand und zwei validen Feldern interpoliert die Darstellungsfunktion die kontinuierliche Wolkendecke. WMO-4677-Codes bleiben exakt aus dem zeitnächsten Original; Änderung der Wetterkategorie und Wolkensprünge >40 Prozentpunkte verhindern lokale Glättung. Fehlende Werte bleiben fehlend. Ohne belastbares Paar gilt der eindeutig ausgewiesene Originalmodelltermin, kein erfundener 15-Minuten-Feldstand.

**Temperaturen/UI:** `src/currentSurroundingsTemperature.ts` nutzt den vorhandenen Best-Match-Hourly-Datenpfad, flüchtigen 2-Minuten-Antwortcache und nur bei vollständigem Stundenpaar und Änderungen ≤8 °C/h eine lineare 15-Minuten-Darstellung. Standortwerte im Zukunftsmodus sind echte Forecast-Punktdaten und niemals als weitergeschriebene aktuelle Temperatur ausgegeben. `src/CurrentSurroundings.tsx` bietet 0…120 Minuten in echten 15-Minuten-Bedienpositionen, die sichtbare Zielzeit, passgenauen Karten-Handoff; keine doppelten Ortnamen neben den vorhandenen Vector-Basemap-Ortslabels. `src/CurrentSurroundings.css` erhöht Ziffernklarheit ohne deckende Kästen, bewahrt Mindesttouchflächen/Fokus.

**Tests:** Erweiterte deterministische Pflichtregression `scripts/test-current-surroundings-temperature-0985476.mjs` deckt Zeitstufen, Datenlücken, WMO-Kategorie, Extremwechsel, Run-/Raster-Gleichheit, Ortsnamen und Temperaturquellen ab; echte Chromium-Fixture `scripts/verify-unified-map-browser-0985167.mjs` prüft mobile Interaktion und Radar-On-Demand. Vor Release sind Source-Kern, vier Core-, sechs Heavy-, Original-DWD-/RUC-, Installer-/Pages-/Worker-/Stable-Gates vollständig und SHA-identisch nachzuweisen. Ein Browserlauf ersetzt keine physische iOS-/VoiceOver-Abnahme.


## MID v0.9.85.480 · schnelle Umfeldkarte und eindeutige Kartenzeit (Source-Kandidat)

**Leitchat-Qualitätserweiterung:** Der Kartenbereich wurde aus dem Spezialbranch exakt über die beiden SHA-gebundenen Snapshots `d254115d01cde7fb452e96720a83b708304dd6c4` und `3e764d51fda43e9af05e9a1a4fe4fdc088c3d854` übernommen. Zusätzlich wurden aus QA-Draft #810 exakt `bec98d65e9c03f074b12788e9d7199a10bb564a5` vier nicht überlappende Widget-Dateien integriert. Die isolierte [GitHub-QA #43650809071](https://github.com/MeteoMartini/MID/actions/runs/43650809071) für Widget-Automationsregression und Unit/Coverage bestand. Private gleiche-Dateisystem-Stagingverzeichnisse, wx/0600, atomarer Rename sowie Negativtests für fehlgeschlagenen Rename, 24 parallele Ersetzungen, Symlink-Zielschutz und Cleanup verhindern das Löschen der letzten gültigen PNG.

**Fachlicher Negativtest:** `src/currentSurroundingsCloudImage.ts` versucht bei fehlender Ortsabdeckung des zeitlich gültigen ICON-D2-Felds nach Priorität ein weiteres SHA- und zeitgeprüftes Modell (D2-RUC/ICON-EU/global). Eine deterministische asynchrone Modulprobe mit Ort außerhalb D2 und innerhalb EU prüft die tatsächliche Folgeauswahl. Fehlt überall ein Feld, bleibt NoData. Die echte veröffentlichte zwölf-Widget-Matrix, Browser-/iPhone-/VoiceOver- und komplette Source-/Installer-/Stable-Gates sind noch nicht nachgewiesen: Integrationskandidat, keine Produktionsfreigabe.

Verifizierte Stable-Basis v0.9.85.479, `main=mid-stable=26e023f01662a5bf00f7543bcb02031634a101b9`. Änderungsumfang: auf dem autorisierten ChatGPT-Integrationsbranch, keine parallele produktive Branchänderung. Bestehende 5 Rulesets, Warn-, Release- und Wetterverträge bleiben erhalten.

**Umfeldwetter:** Standard ist eine zweckgebundene wiederverwendete Wolken-/SigWx-Modellkarte aus dem bestehenden SHA-geprüften Synoptik-Index `loadSynopticIndex` und `loadCloudWeatherField` bzw. `loadSynopticField`, mit zusätzlichem validiertem ICON-D2-Paar `loadNativeIndex` + `nativeCloudWeatherPair`. Der gemeinsame Kartenrenderer `cloudWeatherRaster` verwendet nur echte Wetterkategorien und transparente Wolken, keine geglätteten Extremwerte oder künstliches Satellitenbild. Zulässig sind nur zeitlich passende, frische Läufe und echte Rasterwerte am Standort; NoData bleibt unbekannt. Initiales `loadCompositeTimes`, WMS-Radar-/Sat-Bild und OPERA-Raster sind auf explizite Radar-/Satellit-Auswahl begrenzt. Keine zusätzliche kostenpflichtige Quelle und kein neuer Worker-Endpunkt. Klare „Modell“-, INIT- und Gültigkeitszeitkennzeichnung. Die Temperaturen sind weiterhin separate Open-Meteo-Best-Match-2-m-Ortsprognosen, zeitlich validiert und ausdrücklich ohne vorgetäuschten gemeinsamen ECMWF-Modelllauf. Nur deren **Darstellung** verwendet die bereits vereinbarte ECMWF-orientierte, wertbasierte MID-Farbskala `ecmwfTemperatureColor`. Originale Temperaturwerte, Celsius und Vorhersagezeit werden nicht verändert. Der ausgewählte Standort erhält eine eigene kleine Markierung und Wert; Temperaturmarkierungen besitzen keine Farbplatten.

**Kartenbereich:** relative und absolute Terminangabe nur zusammen an der bereits vorhandenen `MapTimelineControls`-Zeitleiste; die eingeklappte Legende enthält ausschließlich Legendeninformationen statt duplizierter Uhr. Auf schmalen Displays wird ein redundantes Direktauswahlfeld ausgeblendet, während Touch-Slider, Play/Schritt-Buttons und Jetzt funktionsfähig bleiben. Responsives Layout und fortlaufende ARIA-Angaben an Zeit-Slider. Längere Metadaten bleiben im Quellen-/Layerstatus und werden nicht als weitere Pille auf die Karte gelegt.

Gezielte und bestehende Regressionen: `scripts/test-current-surroundings-temperature-0985476.mjs` und `scripts/test-c14-map-workspace-098534.mjs`; vollständige Type-/Build-/Core-/Heavy-/Browser-, Light/Dark-, 320/390/430/834-px-, WebGL-/iPhone-Abnahmen und echtes Source-/Installer-/Worker-/Pages-/Stable-Gate werden erst am finalen unveränderlichen SHA unabhängig bewertet. Keine CI-, visuelle oder Releasefreigabe vor deren Nachweisen. Die neue Modellkarte darf amtliche Warnungen, echte Radar-/Satellitenmessungen oder deren Aktualität nicht ersetzen.

## MID v0.9.85.479 · Changelog-Rückweg und dokumentierte P1-Prüfqualität (Source-Kandidat)

Kanonische Ausgangsbasis: main=mid-stable SHA `c5e9d9e5a8af760a8c2b78ae456ef4abffc81442`, v0.9.85.478; Installer #43639610471 PASS mit 4 Core/6 Heavy, Worker/Pages und Stable-Promotion. Fünf GitHub-Rulesets aktiv, keine Direktänderung an geschützten Branches oder Pflichtgates.

SHA-verifiziert und ohne Quellpfad-Überschneidung selektiv integriert: QA-Draft #808 HEAD `fdabe864505530faefb74d6e984bf5fa8e09b7ed` (6 Dateien), QA-Draft #807 HEAD `b0f46cf2190341b240519232d541b82fec20803f` (3 Dateien). Beide Drafts bestanden Unit/Coverage und gezielte Regressionen auf ihren exakten QA-SHAs. Der Unterschied der alten .477-Basis zur veröffentlichten .478 wurde vor der Integration gegen diese neun Pfade geprüft. QA-Piloten allein legitimieren keinen Merge oder Release.

Das Footer-Changelog öffnet die gebündelte aktuelle CHANGELOG.md per React-Klick und Lazy-Import in einem HTML-Dialog im bestehenden App-Dokument. Der alte 10-Sekunden-MutationObserver und externe Tab entfallen. „Zurück zu MID“, Escape, Fokus-Wiederherstellung, sichere Textdarstellung von Markdown, nachgeladene historische Einträge, Ladefehler und responsive Light/Dark-/Safe-Area-Unterstützung bleiben verbindlich. Browser-Simulation ersetzt keine reale iOS-/VoiceOver-Abnahme.

Die Erweiterung des bereits registrierten MID_CHATGPT_GITHUB_CONTRACT.md erfasst betriebliche P1-Codeprüfung und original dokumentierte Findings mit korrekter Tool-/Version-/SHA-Provenienz. Die Prüfwerkzeuge actionlint, zizmor, Biome und axe bleiben optional und nicht blockierende Diagnosen, bestehende CodeQL-Pins und Workflow-Spiegel verbindlich; unbekannte und hohe Befunde sind nicht pauschal entwarnt. Es wurden weder neue Secrets, Rechte, AutoFix-/Merge-Privilegien noch neue bezahlte Dienste hinzugefügt.

Die Version v0.9.85.479 wird über Paket/Lockfile, Baseline, Contract-Registry, iOS-Projekt, Worker, PWA und Changelogs synchronisiert. Kein Wetterdaten-/WMO-/DWD-Warnvertrag geändert. Veröffentlichung nur über Source-PR Gate, kontrollierten SHA-Merge, serverseitiges Release-ZIP, install-mid.yml, Worker-/Pages-Gates und Stable-Promotion.

## MID v0.9.85.478 · identische MID-Kartenbasis und ortsgebundene Umfeldtemperaturen (Source-Kandidat)

Basis Stable v0.9.85.477 `4f6c167cc41ab588dfeb2e512ad17a8683a99096` (inkl. erfolgreichem Installer `43629614852`). Selektiv SHA-/Blob-identisch übernommener Spezialchat-Kandidat `b9e3515b1cd785534612764f5a80dcc179d67c00`, dessen vier Quelldateien vor Änderungen gegen die neue Stable-Basis geprüft wurden; keine Überschneidung mit dem Security-Release .477.

Umfeldwetter verwendet die offiziellen, schon im MID-Kartenbereich gebundenen Komponenten `UnifiedVectorBasemap`, `compositeReferenceLayers`, `MapContainer`, `ImageQuadLayer`, `HtmlMarker`. Damit entfallen handgezeichnete Natural-Earth-SVG-Grenzen und künstliche georeferenzierte Rasterkanten; die Radar-/Satellitenfelder bleiben zeitlich eindeutig und geografisch projiziert. Der Hintergrund führt OpenFreeMap/OSM-Vektorkacheln und dieselben Grenz-/Orts-/Gewässerstile wie der MID-Kartenbereich. Kein zusätzliches kostenpflichtiges Kartenprodukt.

Neue deterministische Ortsauswahl `src/surroundingsCitySelection.ts`: bis vier geografisch registrierte Städte/Orte aus Natural Earth und tatsächlich geladenen OpenFreeMap-Kacheln, Priorität nach realer Bevölkerungsangabe beziehungsweise kartografischer Klasse/Rang, Mindestabständen und Begrenzung von Überschneidungen. Die vorhandene Open-Meteo-Best-Match-Mehrpunkt-Temperaturquelle wird nur für ausgewählte Ortschaften angefragt, ihre Celsius-Einheiten, UTC-Gültigkeit, Koordinaten und NoData-/Plausibilitätsgrenzen bleiben geschützt. Eine fehlende Stadt ist kein synthetischer Temperaturpunkt; ein fehlender Wert ist nicht 0. Der gewählte Ort behält seinen vorhandenen eigenen aktuellen Wert. Prognosewerte sind nicht amtliche Beobachtungen/Warnungen; einzelne Modellläufe sind aus Best Match nicht sicher ableitbar.

Tests: `scripts/test-current-surroundings-temperature-0985476.mjs` mit Herkunfts-, Orts-, Distanz-, Kollision-, Negativ- und Fallback-Prüfungen ergänzt. Bestehende Rendering-/Responsive-/Modul-/Fachtests sowie Browser-/GPU-Kaltstart und iOS/VoiceOver sind über den finalen SHA in allen bestehenden Source-/PR-/Installer-/Worker-/Pages-/Stable-Gates unabhängig zu prüfen; dieser Dokumentenstand selbst behauptet keine Veröffentlichung oder erfolgreiches Release.

## MID v0.9.85.477 · Official actions/download-artifact v8.0.2 maintenance (Source-Kandidat)

* Basis: Stable `8547d4a8420c648e0c28685ea7a5c3bb4b62baa7`, v0.9.85.476, 5 aktive Rulesets.
* Upstream-verifizierter SHA `9000827ccba6bdab643e8b6fd33ac0654aef8333`, offizieller GitHub-Tag v8.0.2; Verbesserung des Retry-After-Verhaltens bei HTTP 429.
* Aus unverändertem aktuellem Stable-Quellstand neu aufgebaut, nicht mit altem Draft #773 überschrieben: genau 10 aktive/kanonische Workflowpaare, workflow-patches-Installer, Sync-Pin und 3 existierende Regressionen; alte SHA nur als explizite negative Regression.
* Vollständige Versionierung Web/Worker/PWA/iOS/Registry/Changelogs synchronisiert. Eingriffsfläche ausschließlich CI-Leseaktion, keine Änderung der Download-Hashes/Digest-Mismatch-Vorgaben, Bot-Identitäten, Warn-/Wetter- oder RUC-Aggregationslogik.
* QA und Release zum Zeitpunkt der Quellautorisierung **ausstehend**. Bestehender Source→SHA-Bot→ZIP→Installer→Worker/Pages→Stable-Pfad bleibt vollständig erforderlich.


## MID v0.9.85.476 · Vier echte Umfeldtemperaturen und sichere P1-Codequalitäts-Piloten (Source-Kandidat)


Gebündelte Freigabekandidatur: #803, Quell-SHA `d313c8da02b823afd7e801ebdb11002ecf250c35`. Extremwetter-Ausblick: Kurz- und Mittelfrist können mit einer validierten lokalen Vorschau sofort geöffnet werden. Kürzere begrenzte zentrale Abruffristen und kontrollierter serieller Direkt-Fallback vermeiden doppelte Datenanforderungen; fehlende Modelllauf-Metadaten und unvollständige Gefahrenfelder bleiben ausdrücklich gekennzeichnet. Eigene MID-Diagnostik ist keine amtliche Warnung.
Die ursprünglichen fünf Dateien (3 Quellmodule, 2 vollständige Regressionstests) wurden blob-identisch in #804 übernommen; die beiden Drafts werden nicht unabhängig unter .476 veröffentlicht. Dieser SHA-bestehende Handoff ersetzt noch keine neuen Source- und Browser-Gates.

Stable-Basis `b598bf457461e0dfa838180a6fd7dfddb22a1487` / v0.9.85.475. Unabhängige Open-Meteo-Best-Match-Mehrpunktprognose für vier georeferenzierte Umfeldtemperaturen zusätzlich zum gewählten Favoriten; gemeinsamer echter Stunden-Gültigkeitszeitpunkt, Celsius-/Koordinaten- und physikalische Plausibilitätsprüfung, kein Missing→0, keine fiktive per-Punkt-Modelllaufprovenienz. Bestehender Draft #801 selektiv übernommen. Kartenlabels auf hellem/dunklem Hintergrund kontrastgesichert; UI-/Live-/iOS-Abnahme weiterhin gesondert.

P1-QA-Piloten aus #760 und dem vorhandenen MID-Check-Pfad: actionlint v1.7.12, zizmor v1.32.0 und Biome v2.6.7 aus SHA256-verifizierten, vor dem Start geprüften offiziellen Releases, ohne GitHub-Token, nur diagnostisch. axe-core/Playwright v4.14.0 als optionaler, von bestehenden Pflichtchecks getrennter Revisionsschritt. Kein neuer Dienst, keine bezahlten Credits, keine automatischen Fix-Commits oder Freigabeumgehung. Vollständiger Source-PR-/Bot-/ZIP-/Installer-/Worker-/Pages-/Stable-Pfad bleibt bindend. Quellkandidat ist noch nicht veröffentlicht.

## MID v0.9.85.475 · CodeQL v4.39.3 und regenerationsfeste Actions-Pins (Source-PR-Kandidat)

Base `34b4871b8512b9301d4a60906db2e2feaa4afcd5` (.474 Stable). Bündelung der unabhängigen Dependabot-PRs #609 (analyze) und #610 (init): offizieller signierter Tagname v4.39.3 per GitHub Tag-Objekt auf Commit `33d7b85da1a04171e211befe2c739303b9a4c066` aufgelöst. Beide CodeQL-Aufrufe `init`/`analyze` in `ci/github/workflows/mid-code-revision.yml` und dem installierten Spiegel `.github/workflows/mid-code-revision.yml` werden ausschließlich auf diesen unveränderlichen Commit aktualisiert. Die vorhandenen CodeQL-Abfrageparameter, Scope, Job-Permissions, Trigger und Gates bleiben unangetastet. `scripts/sync-github-workflows.mjs` verwendet dieselbe Version, damit `prepare:release-repository` den Pin nicht wieder auf 4.39.1 zurücksetzt. Der neue obligatorische Test `scripts/test-codeql-4393-pin-0985475.mjs` prüft beide SHA-Pins, bytegleichen Spiegel, Generator und unveränderten Security-Extended-Vertrag mit Negativprüfung des alten SHA; beide Baseline-Inventare synchron.

Freigabe ausschließlich nach SHA-gebundenem MID-Source-Gate, CodeQL-Revision, vollständigen Core-/Heavy-/Browser-/Dependency-Checks, stabilem Worker/Pages-Vertrag und Installer-Promotion. Kein generisches Dependabot-Merge, keine Schutzregeln- oder Secretänderung, kein bezahlter Dienst. Reale iOS-/VoiceOver-Abnahme weiterhin getrennt.

## MID v0.9.85.474 · Geschützter Release-Wiederanlauf

Der Release-Bot verwendet den vorhandenen lesenden Installer-Nachweis vor dem regulären SHA-gebundenen Merge. Unklare Historie, aktive Läufe oder begonnene Deployments führen zur Sperre.

## MID v0.9.85.473 · Kandidat zur Wiederaufnahme des Releases

- Quellbasis: gemergter PR #797, Commit `4c5ad000d946a4d4924a451a2b7e51610fce26e0`. Der Installer für das Paket `987fd2913351a8dc90bdb3325bac174efac22794` meldete 1.500.120 Byte Start-JavaScript bei einem Limit von 1.500.000 Byte.
- Systemstatus und Diagnose-Einstellungen werden aus dem Startmodul in eine verzögert geladene Komponente verschoben. Die drei Source- und drei Installer-Buildschritte lösen Vite-Eingaben gemeinsam auf und protokollieren einen Eingabe-Fingerabdruck. Beide Gates bauen und prüfen das Bundle-Budget eigenständig. Der lesende Prüfer für fehlgeschlagene Installer qualifiziert ausschließlich vollständige Evidenz vor dem Deployment für die weitere Prüfung. Er wird nicht vom Merge-Guard aufgerufen.

## MID v0.9.85.472 · Wetter im Umfeld (QA-Kandidat)

Stable-Basis `987841ec2e077daa5a7bd07e861e5d9a76dc3ed7`. #795/#797: Lazy-Vorschau für Aktuell mit DWD-RV, OPERA-Ersatzquelle und separat datierter Satellitenbeobachtung. Der angezeigte Radarzeitpunkt wird an die Detailkarte übergeben. Die vollständige Fach-, Browser- und Live-Abnahme steht aus.

## MID v0.9.85.471 · OPERA-Echophasenflächen und RUC-Snapshot-Transport

Stable-Basis: `820ca417f0467a0bdede5d48da7a646d700efbd4` / v0.9.85.470. Übernahme aus Spezial-Draft #794 @ `051fdccbb08ccec39b78b1687a66dec3c5356681` exakt in den zwei unüberlappten Quellpfaden `src/RadarModelPrecipTypeOverlay.tsx` und `src/RadarPanel.tsx`; die Dateiblobs sind gegenüber dessen ursprünglicher .469-Basis unverändert auf .470 übertragbar. Keine anderen Karten- oder Workerfachänderungen. Nur bei echtem OPERA-Echo und passend zeitgestützter Modellphase werden Flächen eingefärbt; Unsicherheiten bleiben als solche erkennbar. Vorhersagephasen werden nicht aus Beobachtungen extrapoliert. DWD-WMS bleibt separat.

Die kostenlose RUC-Pages-Snapshot-Sicherung behandelt einen vom Gateway gelieferten HTTP 520 als begrenzt wiederholbaren Transportfehler. Das objektweise Manifest-, Bytes- und SHA-256-Gate bleibt unverändert und blockiert bei erschöpften Retries. Kein Missing→0, keine gelockerte EPS-Laufvollständigkeit. Regressionsprüfungen: `scripts/test-radar-phase-areas-0985471.mjs`, `scripts/test-ruc-restore-http520-0985471.mjs`, bestehende Phasen-/RUC-Verträge. Browser-/Live-Pixelprüfung, responsive 320/390/430/834 px, Light/Dark sowie vollständige Source-/Installer-Gates ausdrücklich vor Produktion nachzuweisen.

## MID v0.9.85.470 · DWD-RV-Zeitkatalog direkt abrufen

Basis .469: `14a98ce740d4463e9ae44d28006fc7deb535af00`. #782: Live-Proben Köln/Münster ohne Radarzeiten. Vollständiges DWD-Dienstverzeichnis ca. 1,9 MB, Primärabruf 16 s. Die produktspezifischen offiziellen WMS-1.1.1-Endpunkte lieferten 49.883 und 36.715 Bytes mit RV-Terminen. Der Worker akzeptiert einen Spiegel erst mit frischem Beobachtungstermin. Der Parser verarbeitet selbstschließende Dimension-Deklarationen vor den WMS-1.1.1-Extent-Blöcken. Lokales Replay mit amtlichem Original: 16 Beobachtungs- und 22 Nowcast-Termine. Gezielte Tests decken die WMS-Route, Quellenzeiten und sichere Fehlertexte ab.

## MID v0.9.85.469 · DWD-Radar-Nowcast in der Kartenzeitachse

Basis: `4fcca5dd8b458e3fc45577beeadc228adcc5bb83` (.468), zu #782. Am 13.11.2026 lieferten DWD und MID für 16:15 UTC byteidentische RV-GetMap-PNGs. Der bisherige Katalog verwarf Zukunftstermine, die geprüfte WMS-1.3.0-Antwort listete nur Beobachtungen, und der serielle Katalogabruf lief bei Köln in Timeouts. Der RV-Katalog verwendet beide offiziellen DWD-Workspace-Endpunkte parallel mit WMS 1.1.1. Nur bestätigte RV-Termine bis +2 h werden separat gemeldet und als RV-Kacheln angefordert. Lokal: Typprüfung, WMS-Katalog-/Karten-/OPERA-Regression und Versionsprüfung bestanden. Produktivabnahme nach Release.

## MID v0.9.85.468 · OPERA-Weiterleitungsmodus

- Basis: `eaa1cc3870974a08122a9dcbb6b363ed5a17fbd1` (.467), Issue #782. Drei aktuelle OPERA-Frames über MID mit HTTP 502, identische Originalobjekte am ECMWF-Spiegel mit HTTP 200 und HDF5-Signatur.
- Worker: Cloudflare-kompatibles `redirect: 'manual'`; Antworten mit Umleitung werden verworfen. Der bestehende Test prüft beide offiziellen Spiegel, die Laufzeitbeschränkung und die Ablehnung einer Weiterleitung zu einem fremden Host.
- Lokal bestanden: TypeScript, Produktionsbuild, Worker-Syntax, OPERA-Regression und Diffprüfung. Source-/Installer-Gates und Produktionsabruf sind im Release-Train zu belegen.

## MID v0.9.85.467 · OPERA-Abruf im Wetter-Worker

Stable-Basis `74579ca5de14aa903269060768ae4f7a3f9b1af5` (.466). Live-Probe #782: drei OPERA-Dateiabrufe via MID lieferten 502/Transport auf beiden Spiegeln, das identische jüngste ECMWF-Objekt war direkt als HDF5 abrufbar. Der Kandidat vermeidet die kompatibilitätsabhängige Fetch-Option.

## MID v0.9.85.466 · Beobachtungsquellen nach Kartenausschnitt

Stable-Basis: `ec0fd4c122eefb6e26ab882d7eccc5cfe353c64d` (.465). Übernahme aus #786 @ `8ebf094368c288f63a04b84d7f6c058b3d90e3e3` über #789. Frische und Provenienz der OPERA-Aufnahmen bleiben erforderlich. Weltweite Quellenabdeckung bleibt in #782 offen.

## MID v0.9.85.465 · 13.11.2026 · Wolken- und Wetterlayer an bestätigten Modelltermin binden

- #787: Beobachtung und Nowcast behalten ihre Zeitachse. Der Modellstatus bietet einen Sprung auf einen bestätigten Modelltermin; der GDPS-Kacheltimer läuft nur bei ausgewählter Prognose. Die Browserregression verlangt tatsächliche GetMap-Anfragen vor und nach Retry.

## MID v0.9.85.464 · 13.11.2026 · SHA-sicherer Installer-Wiederanlauf ohne Git-Checkout

- Verifizierte Basis: main=mid-stable `8754f589c7c998a6da6f459f0a33235153704dd8` / v0.9.85.463; Installer #43390443252 completed/success einschließlich Source-Gate, Core/Heavy, Worker, Pages und Stable-Promotion. Fünf Branch-Rulesets aktiv und unverändert.
- Spezial-Draft #784, HEAD `e9d5934dc0bc860a6071672c8bd208cd84abe59e`, für zwei Release-Workflowspiegel und zwei bestehende Regressionstests selektiv wiederverwendet. Keine ungesicherte Cherry-Pick-Übernahme des alten .462-Drafts.
- Fehler #783: `gh workflow run install-mid.yml` konnte im erlaubten Recovery-Job ohne Checkout kein Git-Repository ermitteln. Explizites `--repo "$GITHUB_REPOSITORY"` sichert den bekannten Zielpfad auch bei checkoutlosem Wiederanlauf.
- SHA-Fence, genau ein GitHub-ZIP-Commit, Bot-/PR-Provenienz und No-Duplicate-Installer-Gates bleiben im Quelltext unverändert. Version v0.9.85.464 in Package/Lock/Baseline/Vertragsregister, PWA, Worker, Changelog und iOS-Build 465 synchronisiert.
- Bestehende Vitest-/Node-Regressionsprüfungen auf das neue Recovery-Kommando ergänzt. Keine neuen Wetterdaten, Kosten, Rechte oder Produktions-Governance; keine Livekarte/realen iOS-Gerätetest vorgetäuscht.
- Source-/Release-Kandidat; kein behaupteter Release vor vollständig grünem Source-PR → Bot → ZIP → Installer → Worker/Pages → Stable-Promotion.

## MID v0.9.85.463 · 13.11.2026 · Original-OPERA-Objektfallback und RUC-Signer-Ablaufisolation

- Verifizierte Stable-Basis: main=mid-stable `1d492743f1d2c38028dae9a01be24e65643537e7`, v0.9.85.462, Installer #43381596669 SUCCESS; fünf Rulesets unverändert.
- Vorhandener OPERA-Handoff #779 @ e7b303c57ab31fa06c1a9ab78698e4354b6017f2 ohne Versionsrückfall übernommen: offizielle Primär-/Ersatzquelle gleicher HDF5-DBZH-Objektschlüssel, 5,5-s-Deadline, NoData/HTTP502 bei beidseitigem Fehler, keine Fehlercache-Veröffentlichung, Quellenheader.
- Wiederhergestellte Versionierung 0.9.85.463 (Web/PWA/Worker/Contracts/Changelog/Package/Lock/Status/iOS-Metadaten Build 464). Kanonische Worker-Module und beide generierten Worker bleiben bytegleich; Release-ZIP ausschließlich serverseitig.
- RUC-Fehlerquelle: Signer-Ablauf in Produktiv-Run 43378017097, keine DWD-Pipeline-/Codec-Integritätsfreigabe. Zulassung darf überalterte *automatisch selektierte* D2-Karten nach bereits geprüfter SHA/Inventarprovenienz optional auslassen; Zukunftszeit, Explizit-Run, SLSA-/NoData-/Vertragsfehler bleiben fatal. 27h-Kern/Originalsnapshot bleibt unverändert. Beide Workflowspiegel synchron.
- Tests: bestehender OPERA-End-to-End-Regressionstest für primär 500, Backup, beidseitigen 502; drei neue RUC-Python-Negativfälle zusätzlich zu bisherigen Gating-/SLSA-Tests. Keine 168h-Wartefrist als allgemeines Release-Gate.
- Noch kein Release-PASS: vollständiges Source-/Core-/Heavy-/Browser-/RUC-/Worker-/Pages-/Stable-Gate und tatsächlicher öffentlicher Original-D2/Sölden-Readback bleiben ausstehend.

## MID v0.9.85.462 · 13.11.2026 · DWD-konforme Taupunkt-/Feuchte-Kohärenz und lokaler Prognoseanker

- Live Source of Truth vor Umsetzung: main=mid-stable `91d8eff4126a928d601dede75c121d8b284b790d`, veröffentlichte v0.9.85.461; fünf aktive GitHub-Rulesets. Installer #43328314344 `completed/success` mit Core/Heavy/Pages/Worker/Stable.
- Reproduktion: Rheidt am 13.11.2026, Bildschirm Aktuell −1 °C, Taupunkt +1 °C, rel. Feuchte 95 %. Fehlendes gemeinsames Gating bei unabhängiger Station-/Modell-Auswahl und stationärer Einzelparametergewichtung identifiziert.
- DWD-Fachquelle: Band Tech v4.0, 6.3, S. 43, Sättigungsdampfdruck C1=6,10780, warme/kalte c2/c3-Werte und Kalt-Inversionssonderfall. Kein erfundener Messwert, keine Rundungs-/NoData-Manipulation.
- Neuer reiner Integritätsalgorithmus im Current-/ForecastLocalAnchor-Pfad: 5 Prozentpunkte RH-Toleranz, originäre Quellenpaar-Prüfung, zeitlicher Versatz ≤30 min sofern bekannt, echte 0 % RH als definierte RH ohne endlichen Taupunkt; keine Änderung der zugrundeliegenden Originaldaten.
- Neue Vitest-Matrix plus neuer verbindlicher Core-Regressionstest `test-current-moisture-0985462.mjs`, synchronisiertes MID_BASELINE-Register und alle Versionsspiegel. iOS Build 463; keine Änderungen an Warn- oder Release-Gates.
- Parallel-PRs #774/#776 bereits via .461 publiziert, keine redundante erneute Integration. #775 und #773 weiterhin qualifikationspflichtige Spezial-Drafts; kein blindes Mergen.
- Erst nach vollem Source-/Core-/Heavy-/Browser-/Release-/Worker-/Pages-Gate als veröffentlicht melden.
## MID v0.9.85.461 · 12.11.2026 · OPERA-Radar-Fallback und RUC-Pages-Artefaktsichtbarkeit

- Basis: main=mid-stable `e84d2d2418cc9f1c190fd95539fb8335960c9d93`, veröffentlicht v0.9.85.460; fünf aktive Rulesets.
- Quellimporte: Radar-PR #774 `d98e9b0516614bbe9f7e5c7fc714440bf5e60d9f` (7 Dateien); RUC-Pages-PR #776 `b49d09a06677f1b42e1935f2a40e567aef7d2299` (5 Dateien), ursprünglich SHA-exakte Git-Blobs.
- EUMETNET-OPERA-Komposit (MeteoGate/ECMWF Backup) CC BY 4.0 mit Lizenz- und Umrechnungsangabe im Karten-Detail; freier, bekannter Host und strikte DBZH-Schlüssel. Keine RainViewer-Proxy-Freigabe.
- GitHub-RUC-Pages-Indexrace (RUC-Run 43315778438): endlich begrenzter zweiwertiger Current-Run-Artefakt-Readback nach Upload, danach Main-/Stable-Gate, keine Neuberechnung der Original-Daten; raw rollback separat geschützt.
- #773 Action-Upgrade wegen unabhängig nicht grüner Paritäts-/27h-Gates nicht integriert; #775 bleibt eigenständiger Review-Ruleset-Pilot und verändert hier keine GitHub-Schutzregeln.
- D2-native FullDomain #446 weiterhin unfreigegeben, solange echter Signer/SLSA/73 Dateien/Browser-/Ortsreadback fehlt.
- Diese Build-/Release-Dokumentation ist ein Kandidaten-Nachweis. Quelle→Bot→ZIP→Installer→Worker/Pages→Stable und Review-/Browser-/RUC-/Security-Gates sind weiterhin verpflichtend.

## MID v0.9.85.460 · 12.11.2026 · RUC P4 Recovery und zuverlässige Release-Diagnose

- Ausgangsbasis: main=mid-stable 30b0be2b95f7b59119fa524c339ab43443c62186 (v0.9.85.459), fünf aktive GitHub-Rulesets.
- Quellpakete: #750 a6ee0904fc3869b88070231eace82e77279b1ee2 (16 RUC-Dateien und Tests) plus #771 01253a0f1f8b49291cc56e30abef50278ae95667 (3 QA-/Dokumentdateien).
- Etablierte RUC-/D2-Signer-Integration bleibt in beiden Workflowspiegeln erhalten; nur P4-Freshness, ecCodes-Nativprobe und atomarer Pages-/SHA-Drift-Schutz ergänzt. Keine ungetestete Direktintegration aus alten Draft-Branchheads.
- Release-Laufzeitdiagnose: begrenzte GET-only 502/503/504-Retries sowie negative 401/403/404/429-Kontrollen; keine neue Releasefreigabeberechtigung.
- Neue Releaseversion erst nach kombiniertem GitHub Source-Gate, regulärem SHA-Bot, ZIP, Installer, Worker/Pages und Stable; bisher nur Source-Kandidat.
- Originaldaten-E2E von #446 mit 72 Feldern, 73 Objekten und NoData-Readback ist hiervon ausdrücklich getrennt und noch offen.
## MID v0.9.85.459 · 2026-11-12 · DWD ICON-D2-Vollgebiet, alpine Radarbeobachtungen und RUC-Sicherheit, GeoSphere-INCA-Punktnowcast

- Published base ef585fdbbfe475146d68868a6b671057f8b52e0d, v0.9.85.458
- PR #765 559d0507e6a63f7f8fa2d73e669b43e2ec5bf08e
- PR #766 6382c1d9553269ec920d73221771ea0f5a1321ef
- PR #767 4f33379666e1b1c0721d5e7e053bd92386020db8
- PR #768 d0f20ba6a27a21089ca4261a8c89d62a1d9a4b94
- Exact #766 Bash-injection hardening merged in both #767 original-signature pipeline workflow mirrors.
- PR #750 RUC-P4 recovery remains excluded; PR #769 INCA point forecast selected with mandatory baseline registry correction; RainViewer access remains disabled without operator approval.
- Required: combined QA, reviews, Source-Gate, bot ZIP, installer, Worker/Pages, Stable and real signed public DWD index/73-object/Client readback.
- Input PR #769: 62eaf652bc571726a766d11da5ce3f2f98f86f7a (7 original paths; four additive Worker fragments merged with #768, source/test files SHA-preserved).

## MID v0.9.85.459 · 2026-11-12 · ICON-D2-Vollgebiet und Alpen-Radar-/RUC-Sicherheit

- GitHub-Basis v0.9.85.458 main=mid-stable ef585fdbbfe475146d68868a6b671057f8b52e0d; SHA-geprüfte Original-Drafts: #765 559d0507e6a63f7f8fa2d73e669b43e2ec5bf08e; #766 6382c1d9553269ec920d73221771ea0f5a1321ef; #767 4f33379666e1b1c0721d5e7e053bd92386020db8; #768 d0f20ba6a27a21089ca4261a8c89d62a1d9a4b94.
- #766-Dispatch-Env-Absicherung hunkgenau in beide RUC-Workflowspiegel von #767 integriert, ohne Source-/SLSA-/Pages-Originalfreigabe zu schwächen. #750 bleibt mit weiterem P4-Recovery-Nachweis getrennt.
- Für 542.040 Zellen, 72 Felder, 73 SHA-bilanzierte Objekte und signierten Originalindex fehlen noch authentischer Signer-Produktivlauf und echte Live-Kartenabnahme. NoData wird nicht interpoliert und der alte 8×9-Crop nicht als Vollgebiet etikettiert.
- #765 frische Produktquellen und Sölden VIS/IR-Fallback; #768 RainViewer ohne Betreiberfreigabe standardmäßig gesperrt. Gemeinsame Browser- und Worker-Tests stehen aus.
- 19 Version-/iOS-/Web-/Worker-/Changelog-Spiegel auf 0.9.85.459 synchronisiert. Release-Dossier und Nutzerhinweise ergänzt; kein Source-/Installer-/Stable-PASS behauptet.
- INCA-Ergänzung (#769 @ 62eaf652bc571726a766d11da5ce3f2f98f86f7a): Der zuvor identifizierte Baseline-Regressioninventarfehler #43246828346 wird durch explizite Registrierung `scripts/test-geosphere-inca-nowcast.mjs` korrigiert. Sölden-Punktforecast als GeoSphere-CC-BY-4.0-Nowcast, kein Radar-Layer, keine amtliche Warnung. Worker-/Aggregate-Hunks mit RainViewer-Sperre aus #768 kontrolliert kombiniert. Kombinierte CI/Review/#740 und alle Produktionsgates müssen am neuen Gesamt-HEAD erneut laufen.

## MID v0.9.85.458 · 2026-11-12 · CodeQL-Sicherheitsanalyse und Release-Provenienz

- Baseline: published main=mid-stable d8ffd44f0cc2f2c9ec1025d28d813fb2fa6d051a (v0.9.85.457), source PR #762 merged, bot #43210338178 success, installer #43210420801 success, active protected rulesets unchanged.
- Input: isolated QA-Draft PR #759 @ 42078f60dda467a88f52556477078c120e97e5b9 (8 paths) selected after exact GitHub diff proved none of those paths changed from parent v0.9.85.455 to published v0.9.85.457.
- Vendor: annotated tag github/codeql-action v4.39.1 resolves to verified commit 9b3254085494b55a0f7c4c2b3d2d52cc712ce370. init/analyze workflow mirror byte-identical; sync script and existing regression expectations updated together. Vendor also has newer tags, intentionally not silently selected.
- QA evidence of isolated input: #43091134402 completed success, including real CodeQL JavaScript/TypeScript and full revision shards. This alone does not authorize integrated .458 release.
- Project review: the read-only quality pilot #760 contains optional actionlint/zizmor findings in its actual CI run #43113814578, despite green outer job via continue-on-error. It is explicitly excluded pending independent findings disposition and scope QA; no weakening of release reviews.
- Provenance correction: previous v0.9.85.457 MID_SOURCE_OF_TRUTH.md retained historical 'unpublished candidate' wording after full promotion. Correct that heading and first preface, preserve historical original SHA details in clearly marked history. No meteorological algorithms, warnings, RUC fields, worker behavior or UI code altered.
- New candidate: v0.9.85.458 with 19 synchronized version mirrors, technical & user-facing notes; must pass full version/Build/regression/security/native review gates before controlled bot merge, ZIP, installer and Stable promotion.

## MID v0.9.85.458 · 2026-11-12 · CodeQL v4.39.1 und korrigierte Release-Provenienz

- Quelle: v0.9.85.457 main=mid-stable `d8ffd44f0cc2f2c9ec1025d28d813fb2fa6d051a`, Merge #762 via Bot #43210338178, Installer #43210420801 vollständig erfolgreich inklusive Worker/Pages. Kein ungesicherter Arbeitsstand übernommen.
- Acht unveränderte Git-Blobs aus QA-PR #759 @ `42078f60dda467a88f52556477078c120e97e5b9`; kein einziger dieser Pfade zwischen Baseline .455 und Stable .457 verändert. GitHub-CodeQL-Tag v4.39.1 verweist nachweislich auf Commit `9b3254085494b55a0f7c4c2b3d2d52cc712ce370`. Beide CodeQL-Skripts (init/analyze), Pin-Synchronisation und vier registrierte Regressionen atomar.
- Input-QA: MID Revision/CodeQL #43091134402 completed/success. Auf neuem .458-HEAD alle Source-/Review-/Ruleset-/ZIP-/Installer-/Worker-/Pages-/Stable-Gates erneut erforderlich; alter Input-Erfolg keine Releasefreigabe.
- Das .457-Dossier enthielt noch den vor der Veröffentlichung gültigen Status 'unveröffentlichter Kandidat'; diese Passage ist nun klar als historischer Stand vor ihrer tatsächlichen Promotion abgegrenzt.
- QA-PR #760 bleibt wegen nachweisbarer Scanner-Findings aus dem optionalen actionlint/zizmor-Pilot #43113814578 ausgenommen. Grüner Outer-Job ist kein grüner Security-Scanner. Kein Rule-Bypass und keine neuen Required-Checks.
- Alle 19 Versionsspiegel einschließlich iOS-Build, PWA/Worker-Cacheversionen und Changelogs synchronisiert. Keine Wettermodelle, amtlichen Warnungen, RUC-Felder, Rendering oder Produktionslogik verändert.

## MID v0.9.85.457 · 2026-11-12 · Karten-Popup, Modellwahl und beratende Review-Konvergenz (Release-Train-Kandidat)

- Nach vollständig grünem Source-PR-Gate #43197076142 stoppte der reale SHA-gebundene Bot #43200353617 korrekt vor Merge: `MID_REVIEW_OPEN_THREAD` (sechs nachträglich eingetroffene Reviewthreads; fünf P2, ein P3). Kein Source-/Installer-/Stable-Bypass und kein manueller Merge.
- Gezielte Revision der sechs fachlich geprüften Reviewbefunde: (1) AGENTS.md verlangt Behebung der Ursache statt Abschwächung eines Regressionstests; (2) Backlog-Dokumentation attestiert keine GitHub-Pfadprovenienz aus bloßem Aufruferinput; (3) der selektive Draft-Lauf installiert bestehende Python-/ecCodes-Abhängigkeiten auch für `test-ruc-map-pipeline-0985305.mjs`; (4) diagnostisch kollidierende, aber nicht ausgewählte PR-Pfade blockieren keine späteren disjunkten Batchkandidaten; (5) `tools/ci/*` wird in den registrierten Referenztests mit durchsucht; (6) numeric `Infinity` bleibt in der Kartenwertprobe NoData, nie Null. Neue adversariale Regressionen zu diesen Fällen; kein neuer Required-Check.
- Alle Originaldaten-, meteorologischen, amtlichen Warn-, Reviewschutz-, Signatur-, Ruleset-, Source-Bot-, ZIP-, Installer- und Stable-Gates unverändert verbindlich. Der nachfolgende exakte Test-/Release-SHA ist getrennt zu belegen; keine vorgreifende Releasebehauptung.

- Verifizierte Ausgangsbasis: main=mid-stable v0.9.85.456 @ 78409f80bfea5112700ff4a119b7c8bd46090c22. Der neue Integrationsbranch ist nicht selbst veröffentlicht.
- SHA-exakte, nicht überlappende Quellübernahme: #761 @ 3652fa42b4da27a01cdf414d457c8a896e72b56a (4 Dateien); #755 @ 6e8258de19ab06f1fab1b33024bbc3703b7e2ae4 (9 Dateien); #757 @ 3d5a2a4e334afc1eb3c2d34dc4c49d6f50c34ab6 (5 Dateien). Die betroffenen bestehenden Quellpfade wurden zwischen .455 und .456 nicht verändert.
- #757: eine statt zweier überlappender Karten-Popups, getrennte Originalwerte von Niederschlag und Begleitfeld für denselben Klick, einheitliche Einheit/Quelle/NoData/0-Darstellung, Abort/Revision-Schutz und fokussierbarer Dialog.
- #755: Modellfamilien und belegte Rasterinformationen; keine zusätzliche Datenquelle, keine modellübergreifende Wetterwert-Fusion, keine spekulativen Länder-/Auflösungskennzeichnungen.
- #761: ausschließlich lesende beratende Zustandsmaschine (keine Erzwingung) mit maximal zwei empfohlenen automatischen Review-Korrekturrunden sowie SHA-/Dateipfad-basierte PR-Backlog-Planung. Bestehende native GitHub-Reviews/Source-/Bot-/ZIP-/Installer-/Pages-/Stable-Gates bleiben unberührt.
- #763 (dringende Nutzerpriorität): vier SHA-geprüfte Vorprüfungs-Tests + zwei unveränderte gespiegelt geführte Unit-Coverage-Workflows und AGENTS.md aus HEAD 0a236d57d60de5132802a5361fd2ae59ad35310c in denselben QA-Train übernommen. Read-only, nur für Drafts von vertrauenswürdigen same-repo chatgpt/*/codex/*; vollständiges Source-Gate, Reviews, Installer, Worker und Stable weiter verbindlich. Einzel-Draft-Coverage-/Preflight-Run #43192194022 erfolgreich, kombinierte Prüfung ausstehend.
- Kombinierte Draft-Vorprüfung SHA `8fc323a2f8b43412a951c8e3cf87a2f1f58d93da` / Actions #43194453557: 37 vorgeschriebene gezielte Quelltests wurden ausgewählt; `test-ruc-composites-horizons-0985308.mjs` scheiterte allein an fehlendem `eccodes` im frischen Runner. Der Draft-Workflow installiert ab jetzt ausschließlich bei explizit ausgewählter RUC-/GRIB-Testfamilie die bestehenden Python-3.12-/`tools/ruc/requirements-pages.txt`-Abhängigkeiten. Keine Tests entfernt, kein Gate abgekürzt; neue Draft-QA ist auf dem neuen SHA erneut zu belegen.
- Browser-/Accessibility-Korrektur nach roten 320px-Classic-Hit-Tests: Mittelpunkt-Schaltfläche wird unter der gemessenen Forecast-Statushöhe platziert (ResizeObserver, Layoutwechsel, Hit-Test), nicht über fest angenommene Pixel. Während Animation zeigt NativeMap einen fokussierbaren aria-disabled 44px-Button ohne aktives Sampling. Vollständige Classic/Next-, Hell/Dunkel-, Keyboard-, 2-Wert-/NoData- und Responsive-Requalifikation nötig.
- Individuelle GitHub-Vorqualifikation: #761 Vitest/Coverage #43169666982 success, #755 #43064440788 success, #757 #43080896179 success; **kombinierte Source-, Core-, Heavy-, Browser- und Installergates ausstehend**. Einzel-PR-Ergebnisse sind keine Releasefreigabe.
- Version W+1 = 0.9.85.457; synchronisierte Client-, Worker-, iOS-, Web-/PWA- und Vertragsspiegel nach unverändertem versionsgebundenem MID-Verfahren. Neue JSON-Release-Notizen in docs/releases/MID_RELEASE_NOTES_0.9.85.457.json.
- Bewusst ausgelassen: RUC #750/#541, AI Router #728, ICON-EU-Originaldaten #748, CI-Vendor-Upgrades #759/#760 und alte überschneidende Drafts. Fachliche DWD-/WMO- und Original-/NoData-Semantik unverändert. Reale iOS-/VoiceOver-Abnahme nicht behauptet.

## MID v0.9.85.456 · 2026-11-11 · DWD-Pollen-NoData, allgemeine Qualitätsregressionen und Release-Train-Diagnostik

- Ausgangsbasis: veröffentlichter main=mid-stable SHA 7272a54ef9a9bd02fa1b6523f0cbf352b9412963 · v0.9.85.455; allgemeiner Integrations-Draft #754 ursprünglicher geprüfter HEAD 88f8c7bb810c1a1bad4af4c3e6de113acc351000, ohne Direktübernahme alter #745-Quellen.
- DWD PollenForecast: 3-Tage-Header berücksichtigt forecastHasMissing auch bei relevanten belasteten Pollenarten. Seven-case Regression für vollständige, teilweise fehlende und gültige Nullwerte. Originalwerte, DWD-WFS und Warnungen bleiben unverändert.
- Registrierte Tests erweitern die Solar-Epoch-Guard-Kopplung, die DWD-Pollen-Beschriftung und den optionalen React-Lazy-Import um Side-Effect-Import-Gegenbeispiele. Keine testseitige Abschwächung oder neue Spezial-Workflows.
- Release-Train-Preflight bleibt strikt read-only und fail-closed; der blockierte JSON-Befund wird vor exit !=0 als Job-Summary ausgegeben und seine Ursachen in stderr sichtbar. Aktive/kanonische Workflowspiegel sind identisch.
- Der unzutreffende .455-Changelog-Satz über einen angeblich aktivierten SHA-Reviewthread-Premerge-Schutz ist in den historischen Textspiegeln korrigiert; PostHog-Dokumentation nennt ausdrücklich die ephemere, sitzungsbezogene distinct_id bei gültiger Web/PWA-Einwilligung.
- Version X.Y.Z.W = 0.9.85.456, W+1 Wartung ohne Major-/Generations-/Feature-Freigabe. package.json, lock, Baseline, Contract-Registry, PWA-Shell/Cache, Clientversion, drei Worker-Versionen, iOS-Spiegel und Xcode-Buildnummer sind in diesem Kandidaten zusammengeführt.
- Vorversions-HEAD Vitest #42980840302 war SUCCESS, keine Behauptung einer erfolgreichen QA auf dem neuen .456-HEAD. Source-/Core-/Heavy-/Browser-/Installer-/Worker-/Pages-/Stable-Gates müssen SHA-genau grün sein; reale iOS- und VoiceOver-Geräteabnahme separat.
- Offene Sicherheitsqualifikation #740/#749 und 16 nicht erledigte Reviewthreads zum gemergten PR #752 sowie RUC-/Karten-Fachbefunde bleiben eigenständige Prüfgegenstände. Dieser Draft erlaubt keine unmittelbare Produktivfreigabe.
- SHA-gebundene Sammelintegration #754 @ c819433afb2569789259c07379d3660ee75f5497 aus Stable 7272a54ef9a9bd02fa1b6523f0cbf352b9412963; RUC-Diagnose NoData-Entkopplung #754 Commit 44fed25f0d6e355887b321cfe6b19d98474cbe3d mit fünf nativen Unit-Negativtests.
- Fünf konfliktfreie Release-Self-Heal-Dateien aus #753 @ da315c9f31486781ba44d6faa1c8e1606bb12e4f, fünf Version-/Cubic-QA-Dateien aus #756 @ a8b9610ce602b12fd975c6fee2a1a0e391811709 und fünf Reviewguard-Dateien aus #758 @ d1b2f0dd54dbc80fdeffa89b96a1fe0b13583cc2 wurden SHA-gebunden in #754 gesichert.
- Review-Readback-Code ist in diesem Draft nur Kandidat. protected.enabled=true beweist die exakten GitHub-Review-/Conversation-Settings nicht. Ein unprivilegierter Snapshot ersetzt kein echtes merge-zeitliches serverseitiges Gate; keine Release-Autorisierung.
- Aktueller gesamter Vor-Dokumentations-HEAD c819433afb2569789259c07379d3660ee75f5497: GitHub Vitest/Coverage #43056493761 completed/success, 28 Testdateien bestanden, 1 Skip, 221 Node-Tests ohne Fehler; source-PR-Gate skipped wegen Draft, vollständige Heavy-/Browser-/iOS-/ZIP-/Installer-/Worker-/Pages-/Stable-Abnahme noch erforderlich.
- Version 0.9.85.456 bleibt ein Wartungskandidat ohne eigenständige neue Karten-/Router-Funktion. Neues #755 Modellfamilien-/Flaggen-UI und #728 externer Router sind wegen eigener Fach-, Kosten- und Release-Gates nicht Teil dieses Kandidaten.
- Korrektur nach aktueller fachlicher Review: RUC-Gewitterdiagnosescore ist kein kalibrierter Niederschlags-PoP und ändert bei fehlendem nativen Akkumulationswert die Niederschlagswahrscheinlichkeit nicht. Menschlich nachprüfbare Wetter-/Review-/Workflow-Regressionen sind bindend.
- Production Branch Guard #23963851 enthält die Ausnahme-Integration #5059236; deren tatsächliche Bot-Identität, Schutzwirkung und ZIP-Folgeschreibbarkeit sind auf dem Release-Aktor noch nicht positiv und negativ belegt. Keine Bypässe und keine stillschweigende Rechteausweitung.
- Self-Heal bootstrap vor erstmaliger v0.9.85.456 Stable-Promotion: wenn der trusted classifier in mid-stable noch fehlt, bleibt retry=false (nie untrusted main/PR-Ausführung). Das ist keine Stable-/Installer-Freigabe.

## MID v0.9.85.456 · 2026-11-11 · Allgemeine DWD-Pollenintegrität und Release-Train-Diagnostik

- Ausgangsbasis: veröffentlichter main=mid-stable SHA 7272a54ef9a9bd02fa1b6523f0cbf352b9412963 · v0.9.85.455; allgemeiner Integrations-Draft #754 ursprünglicher geprüfter HEAD 88f8c7bb810c1a1bad4af4c3e6de113acc351000, ohne Direktübernahme alter #745-Quellen.
- DWD PollenForecast: 3-Tage-Header berücksichtigt forecastHasMissing auch bei relevanten belasteten Pollenarten. Seven-case Regression für vollständige, teilweise fehlende und gültige Nullwerte. Originalwerte, DWD-WFS und Warnungen bleiben unverändert.
- Registrierte Tests erweitern die Solar-Epoch-Guard-Kopplung, die DWD-Pollen-Beschriftung und den optionalen React-Lazy-Import um Side-Effect-Import-Gegenbeispiele. Keine testseitige Abschwächung oder neue Spezial-Workflows.
- Release-Train-Preflight bleibt strikt read-only und fail-closed; der blockierte JSON-Befund wird vor exit !=0 als Job-Summary ausgegeben und seine Ursachen in stderr sichtbar. Aktive/kanonische Workflowspiegel sind identisch.
- Der unzutreffende .455-Changelog-Satz über einen angeblich aktivierten SHA-Reviewthread-Premerge-Schutz ist in den historischen Textspiegeln korrigiert; PostHog-Dokumentation nennt ausdrücklich die ephemere, sitzungsbezogene distinct_id bei gültiger Web/PWA-Einwilligung.
- Version X.Y.Z.W = 0.9.85.456, W+1 Wartung ohne Major-/Generations-/Feature-Freigabe. package.json, lock, Baseline, Contract-Registry, PWA-Shell/Cache, Clientversion, drei Worker-Versionen, iOS-Spiegel und Xcode-Buildnummer sind in diesem Kandidaten zusammengeführt.
- Vorversions-HEAD Vitest #42980840302 war SUCCESS, keine Behauptung einer erfolgreichen QA auf dem neuen .456-HEAD. Source-/Core-/Heavy-/Browser-/Installer-/Worker-/Pages-/Stable-Gates müssen SHA-genau grün sein; reale iOS- und VoiceOver-Geräteabnahme separat.
- Offene Sicherheitsqualifikation #740/#749 und 16 nicht erledigte Reviewthreads zum gemergten PR #752 sowie RUC-/Karten-Fachbefunde bleiben eigenständige Prüfgegenstände. Dieser Draft erlaubt keine unmittelbare Produktivfreigabe.
- **Leit-Integration der zusätzlichen QA-Pakete (11.11.2026):** #753 Self-Heal Commit da315c9f31486781ba44d6faa1c8e1606bb12e4f (fünf geprüfte Dateipfade), #756 Versionsfreeze/Cubic-Disposition Commit a8b9610ce602b12fd975c6fee2a1a0e391811709 (fünf disjunkte Pfade), #758 Review-SHA-Readback Commit d1b2f0dd54dbc80fdeffa89b96a1fe0b13583cc2 (fünf disjunkte Pfade) wurden auf bestehendem #754 integriert; #758 unabhängiger Unit/Coverage-Lauf 43056105991 SUCCESS, kombinierter HEAD c819433afb2569789259c07379d3660ee75f5497 Unit/Coverage 43056493761 SUCCESS, RUC-zensierte Evidenz 43056493717 SUCCESS. Dadurch kein zusätzlicher Workflowname und keine bestehende Release-Gate-Umgehung.
- **Fachkorrektur Viertelstunde:** RUC CAPE/CIN/Reflektivität/Peak können gültig sein, obwohl der native Mengenwert fehlend ist. Mengenkonsens und Niederschlagsphase dürfen dann nicht verändert werden; konvektive Diagnose und MID-eigene Prognosewahrscheinlichkeit können unabhängig einfließen. Fünf neue Tests PASS im Original-Head 44fed25f0d6e355887b321cfe6b19d98474cbe3d; keine DWD-Amtswarnung.
- **Native Review-Absicherung, getrennter Wirksamkeitsnachweis:** Nach Owner-Konfiguration von klassischem main-Branchschutz meldet /branches/main protection.enabled=true, doch Administration:read bleibt 403 und weder ein später offener Inline-Thread noch der ZIP-Direktpush mit echtem Releasebot ist bisher am neuen Regelstand als Positiv-/Negativtest belegt. Neuer Premerge-Scanner läuft erst ab erfolgreicher Promotion des neuen Botcodes; erster Merge weiterhin unter altem Stable-Workflow, daher native Regel als unverzichtbare Voraussetzung. Kein Cubic-Required-Gate, keine eigene Approval-Selbstvergabe.
- **Releasestatus:** 0.9.85.456 weiterhin QA-Draft und kein tatsächlicher Build; ohne aktuelle Source/Core/Heavy/Browser-/Security-/iOS-/Server-ZIP-/Installer-/Worker-/Pages-/Stable-Gates keine Promotion. Karten #755, Router #728, RUC-P4 #750 getrennte Spezialzuständigkeit, keine unqualifizierte automatische Übernahme.
- **Review-Qualifikation November 2026:** 19 neu eingegangene GitHub-Cubic-Inlinefindings auf #754 führten zu Draft-Stop statt ungedecktem Ready; bestätigte P1/P2-Meteorologie-/Premerge-/Version-/Self-Heal-/CSS-/CI-Diagnosefehler wurden auf separaten SHA-gebundenen Commits behoben und negativen Tests unterzogen. Ein erfolgreicher KI-Check allein ist keine fachliche Freigabe.
- **RUC-PoP-Integrität:** Unkalibrierte CAPE-/Gewitter-Signalstärke darf keine Niederschlagswahrscheinlichkeit erzeugen, solange der native 15-min-Akkumulationswert fehlt. Eigenständige WMO-Code-Diagnose (kein Amtswarnsystem) und valide kanonische Menge bleiben separat.
- **Release-Bootstrap und Sicherheit:** Klassische GitHub-Conversationsregel main ownerseitig aktiviert, Production-Branch-Guard-Update-Sperre im bestehenden Ruleset #23963851 lesend belegt. Zusätzlicher GraphQL-Premerge-Botguard gilt erst nach Stable-Promotion. Ein zuvor unpromovierter Self-Heal-Classifier wird auf dem ersten Installationsversuch nicht ersatzweise aus nicht vertrauenswürdigem Kandidatencode geladen.

- **Source Heavy Unified Map – Laufzeitbalancing ohne Ausnahmen (11.11.2026):** Pflicht-Source-Gate [#43074212691](https://github.com/MeteoMartini/MID/actions/runs/43074212691) beendete 11/12 Pflichtshards erfolgreich; 2/3 hatte sieben reale und ungekürzte Kartenfälle bestanden, dann erreichte die separate 20-Zyklen-Speicherprobe das unveränderte 13-Minuten-GitHub-Step-Limit. Keine Karten-, Browser-, DWD-/PoP- oder Testbehauptung wird deshalb grün gerechnet. Die exakt einmalige Speicherprobe wird innerhalb der vorhandenen drei Pflichtshards auf das tatsächlich schnellere 1/3 verlagert, zusätzlich genau ein vollständiger 1024px-Light-Next-Fall aus 2/3 zu 1/3 umverteilt. 24/24 Breite-/Theme-/Designfälle sowie 20/20 GC-/Modellwechselzyklen und beide bestehenden Source-/Installer-Regressionen bleiben Pflicht; 13-Minuten-Step-Limit, Browserassertions, RUC- und Sicherheitsgates unverändert. Ausgangs-SHA c49f92331d826f6d610380fe9def4f6ba89ec242; vollständige neue SHA-/CI-/Originalbrowser-Abnahme erforderlich.

## MID v0.9.85.455 · 2026-11-10 · Datenintegrität, Pollenflug, Meteogramm, DWD-Saisonkarten und bewährter Releasepfad

- Verified Stable base v0.9.85.454 ee7a55b5ece4d3d3687202a95caeb6c5ff615055; 25 blob-identical files from Draft #742 HEAD da7c4509a6c6c6e604bb528051dbdb937ff1d8da and 8 blob-identical files from Review Draft #743 HEAD f782f4585ec631836e57728ee4ea0fc49fa3ea9b; initial integrated commit 1f0f0511d8ec83fa19e048fa816749e85ff43036.
- No conflicting files with RUC v0.9.85.454. Existing mandatory meteorological regressions, Source-/Installer-/Worker-/Pages-/Stable gates are not changed or bypassed.
- Isolated previous Draft Vitest and real CSS production pilot were successful; full current combined Source/Installer and browser/device tests are separately mandatory, not inferred from old candidates.
- Security correction 2026-11-11: the unqualified #740/#745 review GraphQL premerge attachment is excluded from combined release PR #752; both canonical/active source-release workflows preserve the exact released Stable bot SHA blob 8ce47e9135d98d809a4ba9f091028edfb756aabd. No new rulesets, tokens, or merge paths; original issue/review evidence remains separately under open #745/#749. Mandatory Source/Installer/Worker/Pages/Stable gates unchanged.
- User release notes/technical history and all version mirrors must remain complete. No pricing, model providers, Cloudflare plan, permissions or branch-rule changes.
- Die zehn fachlichen Karten-/QA-/Dokublobs wurden unverändert aus dem geprüften Karten-Draft #741 HEAD aee8204e5703a71a7fc77c2f8e4314a0ed8388e7 in den allgemeinen v0.9.85.455-Integrations-PR #745 übernommen. Jedes der zehn Originalblobs war gegenüber Stable ee7a55b5ece4d3d3687202a95caeb6c5ff615055 und dem bisherigen #745-Tree konfliktfrei; #741 bleibt als unveränderte Originalquelle gesichert.
- Isolierte Karten-QA #42829498836 PASS: 111 Vitest PASS/1 SKIP, vier echte Chrome/MapLibre-Geräte-/Theme-Piloten PASS, SVG/PNG-Download und Decode PASS, 194/194 CI-Subtests PASS. Diese isolierte QA ersetzt nicht die neue vollständige Source-/Heavy-/Core-/DWD-/Browser-/iOS- und Installerqualifikation.
- Der allgemeine Source-Gate-Lauf #42831676020 ist auf älterem #745-HEAD wegen Core-Regressionen fehlgeschlagen; 21 Cubic-Threads einschließlich P1-Merge-Evidenz sind nicht fachlich abgeschlossen. Bis zur unabhängigen Review-Triage bleibt das Bündel Draft/NO RELEASE; niemals nach einem nur synthetisch grünen Review-Gate veröffentlichen.
- Bundled workflow/version QA from #751 retained in the read-only preflight; obsolete PR-#701/#685 Draft workflows retired; old #745-only workflow pair excluded. All release claims require current SHA-bound Source and Installer gates.

## MID v0.9.85.455 · General MID Quality + bewährter SHA-Releasepfad

- **Source:** veröffentlichte Stable v0.9.85.454 `ee7a55b5ece4d3d3687202a95caeb6c5ff615055`; initiale selektive Git-Blob-Übernahme aus PR #742 `da7c4509a6c6c6e604bb528051dbdb937ff1d8da` (25 Pfade) und PR #743 `f782f4585ec631836e57728ee4ea0fc49fa3ea9b` (8 Pfade), zunächst Integrationscommit `1f0f0511d8ec83fa19e048fa816749e85ff43036`. Der vollständige SHA-verifizierte Git-Tree auf `fa63a3cd5d97fa28807dd298b1b5ab9f962fb79c` zeigt nach späteren Folgekorrekturen nur noch **12/25** beziehungsweise **0/8** unveränderte Originalblobs; 21 abweichende Pfade benötigen unabhängige Diff-/Reviewzuordnung und dürfen nicht als ungeändert ausgewiesen werden.
- **RUC-NoData-Integrität (QA-Kandidat):** Fehlende oder negative native ICON-D2-RUC-15-Minutenwerte dürfen weder zu trockenen 0 werden noch Niederschlag/PoP der Leitprognose verringern. Echte 0 bleibt verwendbar; 5-Minuten-Peaks nur bei kompletter Zeitabdeckung, Initialisierung T0 nicht als abgeschlossenes Intervall, Phasen nur bei vollständigen Regen-/Schneewasseräquivalenten. Drei Worker-Spiegel und Forecastfusion synchronisiert. Fast-P5 und Release ohne Originaldaten-/CI-Gates gesperrt.
- **Fachverträge:** DWD Pollen -1 != 0, Teilgebiets-/Tages-NoData, volle lokale 3h-Intervalle inkl. DST, UTCI-Provenienz, Skybar ungültige Epochen, Meteogramm Ortswechsel/Persistenz. Offizielle DWD-Warnungsvorgaben unverändert.
- **UI/Performance:** Optional-Pollen-Split mit Offline-Shell, exakte CSS-Kaskade, Produktionsbudgets 1.500.000 B JS / 1.760.000 B CSS unverändert. Ursprünglicher isolierter QA-Run #42819990890: 117 Vitest PASS, ein Skip, 194/194 technische Subtests PASS; **nicht als neuer Release-Gate gezählt**.
- **Security / Releasepfad (aktualisiert 11.11.2026):** Der neue Review-GraphQL-Premerge-Entwurf aus #743/#745 wurde nach dem offenen TOCTOU-Befund bewusst **nicht** in den kombinierten Quellrelease übernommen. Beide `agent-source-release.yml`-Spiegel entsprechen bytegenau dem unveränderten Stable-Bot-Workflow (Blob `8ce47e9135d98d809a4ba9f091028edfb756aabd`). Keine neuen Rulesets, neuen Tokenrechte oder eigenständigen Mergewege. Der Befund bleibt in den Spezial-Drafts #745/#749 offen; originale Review-Threads und lokale Negativtests erhalten. Die bestehenden SHA-, Source-, Installer- und Worker-/Pages-/Stable-Schutzgates bleiben vollständig obligatorisch. GitHub Unit-/Coverage- und RUC-Draft-QA allein ersetzen keine Source-/Installer-Abnahme.
- **Release-Gates:** keine Änderung der etablierten Source→Bot→ZIP→Installer→Worker/Pages→Stable-Kette. Neues v0.9.85.455 Release erst nach vollständiger SHA-/Verspiegelungs-/Regression-/Browser-/Originaldaten-/Securityprüfung als veröffentlicht kennzeichnen. Gegenwärtiges Dokument ist Kandidateninformation, keine Erfolgsmeldung.
- Die zehn fachlichen Karten-/QA-/Dokublobs wurden zunächst aus dem Karten-Draft #741 HEAD aee8204e5703a71a7fc77c2f8e4314a0ed8388e7 in den allgemeinen v0.9.85.455-Integrations-PR #745 übernommen; der aktuelle Vergleich enthält noch **9/10** unveränderte Blobs, der eigene zusätzliche Branch-/Karten-QA-Test wurde später bewusst angepasst. Jedes der zehn Originalblobs war gegenüber Stable ee7a55b5ece4d3d3687202a95caeb6c5ff615055 und dem bisherigen #745-Tree konfliktfrei; #741 bleibt als unveränderte Originalquelle gesichert.
- Isolierte Karten-QA #42829498836 PASS: 111 Vitest PASS/1 SKIP, vier echte Chrome/MapLibre-Geräte-/Theme-Piloten PASS, SVG/PNG-Download und Decode PASS, 194/194 CI-Subtests PASS. Diese isolierte QA ersetzt nicht die neue vollständige Source-/Heavy-/Core-/DWD-/Browser-/iOS- und Installerqualifikation.
- Der allgemeine Source-Gate-Lauf #42831676020 ist auf älterem #745-HEAD wegen Core-Regressionen fehlgeschlagen; 21 Cubic-Threads einschließlich P1-Merge-Evidenz sind nicht fachlich abgeschlossen. Bis zur unabhängigen Review-Triage bleibt das Bündel Draft/NO RELEASE; niemals nach einem nur synthetisch grünen Review-Gate veröffentlichen.

## MID v0.9.85.454 · 2026-11-10 · RUC Pages-/Worker-Diagnose und sichere Provenienz

- Source of Truth: v0.9.85.453 main=mid-stable=ba4901932c33e584167c31c310fb11601e77b6df; integrator copies precisely four files from verified QA PR #732 HEAD e2fe7d832b1514d29f29b110df6d01f40eb24e38.
- Original #732 exact-head Python 13/13 PASS in Actions #42808191010 and complete MID CI core/heavy/CodeQL PASS in Actions #42808190991 attempt 2.
- Observed Pages UTC run and pages-lossless-v1/pages-free-v1/pages-codec-staging-v1 are strict-sanitized; no HTTP request URLs, auth tokens or arbitrary response bodies in diagnostic journal.
- Die .454-Source-PR enthält synchronisierte Paket-/Lock-/Baseline-/Vertrag-/Worker-/PWA-/HTML-/iOS-/Changelog-Spiegel; direkte Versionstests müssen idempotent und ohne Versionssprung sein. Keine MID_RELEASE_TARGET.json oder ungetestete Workflow-Änderung.
- Source PR gate, signed reviewed SHA-bound bot merge, server ZIP, install-mid.yml, Worker/Pages and Stable promotion are mandatory; no gate bypass. The full P1–P5 RUC program remains separately blocked.

## MID v0.9.85.453 · 2026-11-10 · WXCharts-inspirierte DWD-Saisonkarten [Source-Kandidat]

- **SHA-genaue Herkunft:** verifizierte Basis `main=mid-stable=d8852f672a40d26348d214dc85e9a3a1b9d79c1f` (v0.9.85.451); Integrationsbranch `chatgpt/v0.9.85.453-spatial-manifest-qualification`, PR #729, Issue #724. Paralleler .452-AI-Router-Draft und RUC-Spezialbranches unangetastet.
- **Fachumfang:** Im bestehenden Unified-Map-Parameterselektor sind DWD ICON-D2 1-h-Gesamtniederschlag + 2-m-Temperatur sowie 1-h-Gesamtniederschlag + maximales Böenfeld integriert. Paarung nur gleicher Run/ValidTime/Grid/Unit und per bestehenden SHA-Checks nach originalem Modellkatalog; fehlende Werte transparent und gemeinsamer SVG-/PNG-Export mit genau denselben Feldpaaren, Ortswerten und Legenden. Keine künstlichen Schnee-, CAPE-, Blitz- oder amtlichen Warnprodukte.
- **Lizenzen/Quellen:** DWD Open Data CC BY 4.0; WXCharts/MetDesk-Lizenzen schließen die Übernahme von WXCharts-Karten/automatischem Bild-Embedding aus. Keine fremden WXCharts- oder GPL-Code-/Rasterinhalte. Feldmatrix: `docs/implementation/MID_WXCHARTS_SEASONAL_MAP_MATRIX_2026_11_10.md`.
- **Draft-Tests vor Version:** exakt auf Karten-Head `852aae7807a37e7666e0279140eb3741ef59197a` Vitest-/Typprüfungs-Run #42766980983 SUCCESS. Diese Prüfung deckt keinen vollständigen Produktionsbuild, Bundle-/CSS-Budgets, alle Core-/Heavy-Regressionen, Browser-/iOS-Shell, Source-Gate, Installer, Worker-/Pages-/Stable-Gates ab. Für den exakten Versions-HEAD neu prüfen.
- **Ausschließlicher Freigabeweg:** Ready for review nach fachlicher Qualifikation → Source-Gate vollständige Jobmatrix → geschützter SHA-Bot-Merge → Server-ZIP → Installer mit erneuten Vollgates → Stable. Kein manuelles Direkt-Merge/Deploy/Version-Fake.

## MID v0.9.85.451 · 2026-11-09 · Fail-closed Installer-JS-Budget-Reparatur [Sourcekandidat]

- **Unveränderte Basis/Provenienz:** stable v0.9.85.449 `a7c4f432b3b21c24a876527a585fe423a55dcdbe`; das gesicherte unpromovierte Main .450 von PR #722 ist Bot-Source-Commit `ebca121d88088fbaf5240a8ebb6d795fb9f9be89`, `main` ZIP-Commit `ba4669b5d7b1cd7fdd87648df66e0f68749b1098`. Die fehlgeschlagene Installerprüfung #42570011322 (Core 3/4) meldete Main-JS 1.500.098/1.500.000 B (+98 B), CSS 1.759.965/1.760.000 B. Stable .449 unverändert, kein Rollback oder Force-Push.
- **Reparatur:** 48 gleiche JSX-Attributstrings in `src/App.tsx` für 10 Loading-Placeholder-Klassen, 8 Metrik-Icon-Klassen, 17 SVG-Patterneinheiten sowie 13 SVG-Stroke-/Fill-Farbwerte als vier konstante, identische Literale wiederverwenden. Keine sichtbaren Klassen, SVG-Werte, Produkteigenschaften, Wetterberechnungen, Datenquellen, Zeitzonen, Warnfarben, Navigations-/Ladezustände oder Fehlerbehandlungslogik ändern. Unveränderte CSS-/Worker-Sourcen, sämtliche Budgetgrenzen, Tests, CI, Regeln und andere Original-Drafts.
- **Lokale Vorqualifikation:** Ausgangs-`src/App.tsx` SHA1-Git-Blob `4c20c1ac151c31d4eac75614d24392108c3ce280` gegen GitHub-.450 verifiziert; inverse Rücktransformation der 48 JSX-Literale und 4 Konstanten ergibt vollständig byteidentisches Original; TypeScript JSX-Transpilation ohne Syntaxdiagnostik, gezielte Quelltests PASS. Node22-Source-Only-Gate darf ohne gebautes `dist` ausdrücklich nicht als Bundlebudget-PASS interpretiert werden. Vollständige 1084 Core / 6 Heavy, tatsächliches JS-Rohbudget, iOS-/Web-Build und Release-Installer für exakt diesen neuen HEAD noch **NOT VERIFIED**.
- **Verbindliche Freigabe:** Einziger Weg bleibt Source-PR-Gate → geschützter SHA-Bot-Merge → serverseitiges ZIP → `install-mid.yml` → ggf. Worker-/Pages-Gates → non-force Stable-Promotion. Bei erneutem Budgetfehler wieder FAIL CLOSED; keine manuelle Veröffentlichung oder Test-/Grenzwertlockerung.

- **Source-Gate-Laufzeitkorrektur (selber unreleaster .451-Kandidat):** Der erste .451-Gate-Lauf #42575431920 scheiterte nach erfolgreicher JS-Budget-Abnahme durch zwei Browser-Fixture-Scope-Regressionen und einen dritten Browser-Timeout. Drei Original-`currentColor`-JSX-Literale wurden in den von Tests separat extrahierten Komponenten wiederhergestellt; auf HEAD `2ba2f209b1c42c5d5cbc1722d6cc9849b839aea0` bestanden danach Core 1/4 und 3/4 samt Rohbudget, alle sechs Heavy inklusive Favoriten-/Browser- und CSS-Parität. Der zweite Source-Gate-Lauf #42579877193 scheiterte ausschließlich am **13-minütigen Step-Limit von Core 2/4**, 200/270 Tests ohne Fehler bis zum Timeout; zuvor auf #42568701822 Core 2/4 nur 776,3 s unter dem unveränderten 780-s-Limit, andere Core-Jobs 85,5–146,7 s. Deshalb werden durch drei **beidseitige, SHA-genau aus dem Runner-Log begründete Test-Tausche** die vollständigen langsamen Tests `test-compact-profile-location-0985235.mjs` (169,2 s), `test-favorites-profile-0985242.mjs` (147,7 s) und `test-module-css-consolidation-0985170.mjs` (108,0 s) auf die wenig belasteten Core 1/4, 3/4 bzw. 4/4 verteilt. Im Gegenzug drei bestehende reine Quellvertragsregressionen in Core 2/4. Inventar 1084/1084, vier unveränderte Core-Gates, alle sechs Heavy, Umfang 270/270/269/269, Testcode und Testanforderungen sowie sämtliche CI-/Workflow-Timeouts unverändert. Der genaue Allokationsvertrag wird nun durch `test-core-regression-isolated-matrix-0985354.mjs` unabhängig geprüft. **Neue Source-/Installer-Gates noch NOT VERIFIED; keine Tests übersprungen, keine Budgetanhebung oder Stable-Freigabe.**

## MID v0.9.85.450 · 2026-11-09 · Modellpräferenz und Bergwetter-Rohzeitintegrität (integrierter Source-Kandidat)

- **Basis:** verifizierte Stable v0.9.85.449 `a7c4f432b3b21c24a876527a585fe423a55dcdbe`, geschützte `main=mid-stable`, fünf aktive Rulesets. Die Änderungen aus den unabhängig gesicherten Drafts #718 HEAD `f07832eb763baca36757ff65b7ba134087f2c999` (#508) und #719 HEAD `b24ffc16e86b685ac828a564ef044880766b12f4` (#428) sind dateipfad-disjunkt und exakt Git-blobidentisch integriert. Beide Original-Drafts bleiben unverändert.
- **Langfrist 14d+:** Nutzerpräferenz `mid:subseasonal-trend:view` unverändert und synchron/dauerhaft gespeichert. Bei fehlender Familie wird die sichtbare Auswahl nur temporär auf Multi-Modell zurückgeführt, explizit mit Statushinweis, ohne die persistente Wahl zu überschreiben. Wiederverfügbarkeit restauriert die ursprüngliche Anzeige. Bestehende Metric-/Anomaly-/Quellenlogik unverändert.
- **Bergwetter:** `mountainTimeEpoch` validiert lokale Original-ISO-Zeitstempel und vom Anbieter explizit gelieferte feste Sekundenoffsets. Keine Null-Auffüllung fehlender UTC-Offsets, fehlerhafter Kalendertage, Suffixe, doppelter oder rückläufiger Zeitachsen; bei vollständig unvalidierbaren Stunden kein synthetischer erster Stundenwert und keine scheinbar vollständigen Tageswerte. Echte bekannte Offset-0-Werte bleiben gültig; keine unbewiesene IANA-Neuinterpretation von Anbieterzeiten. Schneefallgrenzen-UTC/NoData aus .449 bleibt erhalten.
- **Getestet vor Integration:** unveränderter, manifest-/SHA256-verifizierter 3645-Dateien-Originalquellstand aus Installer `42522992648`; vier Dateiblobs gegen GitHub Drafts exakt, vollständiger Node22-Trend-Pflichttest (33 Checks) und Bergwetter-DST-/NoData-Pflichttest sowie mehrere angrenzende ohne Fremdabhängigkeiten ausführbare Regressionen PASS. Lokales `npm ci --offline` aufgrund fehlender gecachter Pakete (u.a. `yauzl`) blockiert; vollständige Node-/Type-/Vite-/Core-/Heavy-/Browser-/Provider-/iOS-/Installer-/Stable-Gates **noch nicht belegt**.
- **Release ausschließlich nach Source-Gate:** bestehender Draft→Ready→SHA-Source-Prüfung→geschützter Bot-Merge→serverseitiges ZIP→`install-mid.yml`→Worker-/Pages-Gates→Stable-Promotion. Keine RUC-/Worker-Fachlogik, CSS, Warn-/DWD-Originaldaten, Rulesets, CI-Gates oder Performancegrenzen verändert. Verfügbarkeits-/Provenienz-Negativfälle bleiben nach tatsächlicher Live-Abnahme getrennt prüfbar.

## MID v0.9.85.449 · 2026-11-08 · Bergwetter: korrekte Zeitachsen und transparente Modellunsicherheit

- #428/#523: selektiver Bergwetter-Code aus QA-Draft #703; validierte Open-Meteo-UTC-Unixzeiten und ganzzahlige Forecast-Horizonte.
- HTTP200 ohne meteorologisch nutzbare Mittelwerte löst nächsten dokumentierten Variablen-Tier aus; vollständige NoData-Arrays bleiben NoData.
- Unveränderte 1084-er-Pflichtregressionen-/Source-/Installer- und Security-Gates erforderlich; neue reale Provider-Stichproben und QA-Abgrenzungen dokumentiert.

## MID v0.9.85.449 · 2026-11-08 · Alpine UTC-Zeit, echte NoData-Grenzen und ehrliche Modellspanne

- **Freigegebene Basis vor Änderung:** `main=mid-stable=fd1fb594bc2b82913156ef0f8e82e22089379164` / v0.9.85.448, [Installer #42498549995](https://github.com/MeteoMartini/MID/actions/runs/42498549995) abgeschlossen erfolgreich. Diese Quelländerung überträgt ausschließlich den fachlichen Teil des unveröffentlichten Drafts #703 HEAD `730280066f766adf171070fa6abe7fd66589d437` auf einen autorisierten `chatgpt/*`-Branch, Original-Draft unangetastet.
- **UTC:** Ensemble-Mean-Abruf `timeformat=unixtime`, numerische monoton steigende Unix-Sekunden, keine hypothetische UTC+0-Interpretation fehlender Fixoffsets. Feld-/Zeit-Längen prüfen und ungültige Modellpunkte konsequent als NoData belassen.
- **Provider-Horizonte:** Open-Meteo verbietet gebrochene `forecast_days`-Werte; MeteoSwiss CH1/CH2 senden ganzzahlige `forecast_hours=34/12`, andere Modelle ganzzahlige Tageshorizonte. Unplausible Horizonte fail-closed.
- **Echte Stichproben:** CH1 34 UTC-Zeiten / 30 gültige Schneefallgrenzen / 4 null, CH2 12/12 gültige; DWD ICON-EPS Mean bot bei einer Prüfung 24 UTC-Zeiten, aber 8×24 null-Felder trotz HTTP 200. Neu: `snowLineHasUsableMean` nimmt keinen vollständigen NoData-Body an, sondern probiert bei solchen Antworten die bereits vorhandenen engeren Variablentiers. Kein Beleg für allgemeinen DWD-Ausfall und keine synthetische Werteauffüllung.
- **Unsicherheit:** Unsichere/missing Spread-Felder bleiben missing. SVG verbindet keine getrennten Datenlücken zu scheinbaren Konfidenzbändern; echter Median bleibt erhalten. Bisher aus Modell-Mittelwerten und angenommenen Streuungen erzeugte Pseudoquantile sind keine echten Einzelmember-Perzentile. UI beschriftet diese deshalb `Modellspanne (Näherung)`, nicht mehr als „10–90 %“.
- **Tests:** Die Pflichtregression `scripts/test-mountain-snowline-dst-nodata-0985415.mjs` ist in allen Inventaren ergänzt (1083 → 1084). Isolierte UTC/DST-, Horizont-/Spread-, NoData- und Quantilprüfungen wurden ausgeführt, einschließlich 19/19 Tests mit exakt aus GitHub entnommenen Helperausdrücken (nicht vollständiger TS-/App-Test). Drei tatsächliche Originalanbieter-Readbacks, aber **keine vollständige Verfügbarkeits- oder iOS-Geräteprüfung**. Relevante Originaldaten-/IANA- und UX-Statusgrenzen in `docs/implementation/MID_C449_MOUNTAIN_UTC_NO_DATA_QA_DRAFT.md`.
- **Freigabe:** Dieser Nachweis ist keine Releasefreigabe. Vollständiges Source-PR-Gate auf exaktem HEAD, Security/Buildbudget, vier Core-/sechs Heavy-Gruppen inklusive Browsertests, iOS-Shell, kontrollierter SHA-Bot-Merge, serverseitiges ZIP, Installer, Worker-/Pages-Gates und Stable-Promotion zwingend. Keine Worker-/DWD-/RUC-Fachlogik, Warn-Schwellen, Tests oder Regeln entfernt; Versionierung folgt dem normalen Buildvertrag. Parallel-RUC bleibt eigenes Work.

## MID v0.9.85.448 · 2026-11-08 · RUC: veraltete vorbereitete Datenpakete früher erkennen

- WE RUC 1.5 / #704 / #541 / PR #707: Authentifizierter negativer SHA256-Vertragsvorfilter aus versiegeltem Prepare-Job unter exklusivem mid-pages-Publish-Lock. Reuse ohne frühe authentifizierte Evidenz bleibt beim vollständigen admit().
- Nachgelagerte GitHub-Artefakt-ID/Digest-, Byte-/Originaldaten-/27h-/EPS-/Bitmap-/NoData-/Codec-/JS-/Worker-/Pages-/Rollback- und Stable-Guards bleiben obligatorisch; Hash-Match ist keine Positivzulassung.
- Isolierte Python-PR-QA #42495706947 auf Vorversions-HEAD: 9 neue Negativtests, 12 Snapshot- und 6 Shared-Pages-Regressionsfälle PASS. Vollständiger .448-Source-/Installer-/Live-P5-Nachweis vor Veröffentlichung separat erforderlich.

## MID v0.9.85.447 · 2026-11-08 · Verbindlicher Releaseprozess und effiziente Agenten-Zusammenarbeit

- SHA-selektive Zusammenführung der Governance-Drafts #702 und #687 auf Stable .446.
- Konfliktfreie normative Ergänzungen; getrennte Source-/Bot-/Installer-/Worker-/Pages-/Stable-Gates weiterhin zwingend.

## MID v0.9.85.447 · 2026-11-08 · Verbindlicher Source-Release-Einstieg und ressourcenschonendes Agenten-Routing

- **Quelle:** released Stable .446 `5e25ab60b365950a54a7d113483e8bf519911113`; authorisierte neue Integration `chatgpt/v0.9.85.447-governance-702-687`. Original Governance-Drafts #702 HEAD `092371c27b3d852b1865e2a6d800a22a34c4d54b` und #687 HEAD `091fc4cce44d72b22651196674bb27cebd004a32`; nur SHA-verifizierte additiv kompatible Quellteile importiert.
- **Releasevertrag #702:** tatsächlicher Draft→Ready→vollständiger Source-PR-Gate→SHA-Bot→serverseitiger ZIP→Installer→Worker/Pages→Stable. CODEOWNERS/Reviews gelten ausschließlich nach den wirksamen Schutzregeln; keine künstlichen externen Approvals oder Umgehungen. RUC-168h-SLO ist getrennt vom vollständig zwingenden Release-Gate.
- **Routing #687:** begrenzte Nutzeraufträge, GitHub als einzige Codequelle, Copilot-Issue→untrusted Draft, Kilo GitHub nur read-only, Kilo-Code über bestehenden ref-freien Handoff, Replit nur UI-Handoff; Verfügbarkeit, Kosten und Rechte prüfen; keine autonomen weiteren Aufträge, Monitoring oder Produktion.
- **Dateivertrag:** Normdateien `AGENTS.md`, `MID_CHATGPT_GITHUB_CONTRACT.md`, `.github/copilot-instructions.md`, `.kilo/skills/mid-handoff/SKILL.md`, `README.md` rein additiv; vier Originaldokumente plus versionierter Bundle-Nachweis. Keine Source-/WMO-/DWD-/Warn-/Wetterdaten-/Fachlogik- oder CI-Workflowänderung. Worker-/PWA-/iOS-Versionen nur synchron gespiegelt, keine Laufzeit-Funktionsänderung.
- **Qualität:** Beide Ausgangs-Draft-SHAs und neue Git-Blobs, aktuelle GitHub-Schutzregeln und Parallel-PRs geprüft; vollständige Source-Core-/Heavy-/Browser-/Security-, Installer-, Worker-/Pages- und Stable-Gates auf **finalem** .447 Source-Head sind bis zur tatsächlichen GitHub-Prüfung **NOT VERIFIED**. Kein extra abgekürzter Dokumentationsrelease; keine Freigabe allein aus diesem Changelog. Parallel Bergwetter-Draft #703 getrennt.

## MID v0.9.85.446 · 2026-11-07 · Gebündelte RUC-/Modellkarten-Korrekturen (Integrationskandidat)

- **Basis** main=mid-stable v0.9.85.445 SHA b6526e7c5c24035bd1a75b87b77e7bb8e821c334; fünffache Git-Blob-Übernahme auf unabhängigem chatgpt/*-Integrationsbranch aus Drafts #700, #684, #695, #698, #685 (exakte Heads in docs/implementation/MID_446_BUNDLED_INTEGRATION_REVIEW.md).
- RUC-P0: EPS20-H00-Index-Verfügbarkeit 20×28, fail-open bei nicht interpretierbarer Quelle/Timer/NoData, nur negative Readiness; 4 begrenzte parallel laufende Member-Index-Abrufe, 14s Hard-Limit, 240min Pages-Maximalalter und nur exakt +1h Laufabstand. Reale 22Z-Teilveröffentlichung zuvor getrennt belegt (96/171/284/427 von 560); nicht als GRIB-Feldwertnachweis missverstehen.
- Originaldaten: drei DWD-RUC-Runs und drei D2-Zyklen mit 3×72-Feld-Auswahl wurden ausschließlich lesend qualifiziert. Keine P95-/CAS-Publisher-/FullDomain-/Client-Abnahme hierdurch.
- RUC-P4: Healthgate-Fehlersicherheit gegen HTTP200-Nonobjects und CLI/Pages/Worker-Konvergenz; kein verteiltes Fencing durch diesen Kandidaten nachgewiesen.
- Karte: zell- und gültigkeitszeitbezogene Phasenpriorität RUC → D2 → EU → global, UTC-Endstempel-/NoData- und Provenienzkorrekturen. Keine Wetterwerte synthetisch zu 0; RUC/D2 15-min Originalfelder nicht mit stündlichen EU/global-Feldern gleichsetzen. WMO/DWD, amtliche Warnungen unverändert.
- Alle Versionsspiegel, Benutzerhinweise und technischen Nachweise müssen auf demselben exakten Integrations-SHA geprüft werden; Source/Core 4/4, Heavy 6/6, Responsive/Web/iOS-Shell/Widgets, Worker/Pages, unabhängiger Review und normale Installer-/Stable-Gates bleiben bis zum tatsächlichen PASS **NOT VERIFIED**.
- Kein direkter Merge, kein manuelles ZIP, kein Force-Push. Erst offizielle Releasekette darf v0.9.85.446 als veröffentlicht melden.

## MID v0.9.85.443 · 2026-11-06 · Sichere Copilot-Zusammenarbeit

- Original PR673 selektiv und ohne neue Rechte integriert; vollständige normale Releasegates zwingend.

## MID v0.9.85.442 · 2026-11-06 · Temperaturreferenz und Diagnoseauswahl

- Keine meteorologischen Daten oder PostHog-Sendegrenzen verändert.

## MID v0.9.85.441 · 2026-11-06 · Wolken- und Modellwetterkarten ohne weiße Ladebilder

- MapLibre ImageQuadLayer: staging mit 0,1 % Deckkraft; Freigabe der 350-ms-Überblendung erst nach erfolgreichem Bildladen, MapLibre-Renderdurchlauf und isSourceLoaded der neuen Bildquelle.
- Letztes geprüftes Kartenbild bleibt auch bei langem Textur-/Source-Ladevorgang erhalten; Fehler und superseded Zeitschritte räumen ausschließlich noch nicht dargestellte Kandidaten ab. Überblendung wartet auf vorausgehende Animation.
- Bestehende Pflichtregression scripts/test-map-components-0985428.mjs um verzögerte GPU-Bereitschaft, leere Erstansicht, Lade-/MapLibre-Fehler, rasche Auswahl, Reduced Motion und Listener-/Source-Cleanup erweitert.
- Keine Änderung an DWD-/ECMWF-/ECCC-Feldern, WMO-Wettercodes, SYNOP-Symbolen, Run-/Zeitsemantik, amtlichen Warnungen, RUC-Daten oder normalen MapLibre Layer-Prioritäten.
- Vollständige Source-/Installer-/Worker-/Pages-/Stable-Gates und reale Browser-/Responsive-Prüfung erforderlich; das Prüfergebnis ist im Quellstand vor erfolgreicher CI nicht behauptet.

## MID v0.9.85.440 · 2026-11-06 · Zuverlässige automatische Browserrevision

- Vier browserabhängige Revisionsjobs auf Ubuntu 24.04 gepinnt; Playwright 1.56.1 kann Chromium und WebKit mit unverändertem Prüfumfang installieren.
- Kanonische und gespiegelte Revision-Workflows SHA-gleich; neue negative Runner-Regression erhöht das Pflichtinventar auf 1082.
- RUC Preprocessing, Wetterdaten, Worker-/Pages-Release und amtliche Warnungen bleiben unverändert.

## MID v0.9.85.440 · 2026-11-06 · Browserkompatibilität der MID-Revision

- Vier browserabhängige MID-Revisionsjobs auf GitHub Ubuntu 24.04 gepinnt (Playwright 1.56.1); drei browserunabhängige Runner unverändert.
- Kanonischer Workflow und aktiver Spiegel identisch; alle zehn Shards, Browser-/WebKit-Installation und fail-closed Abschlussprüfung unverändert.
- Neue Runner-Negativregression; Pflichtinventar 1081 → 1082. RUC-Produktion/Worker-Verhalten unverändert, separat read-only überwacht.
- Vollständiger Source-Gate/Installer/Worker/Pages/Stable-Pfad bleibt zwingend.

## MID v0.9.85.439 · 2026-11-06 · Gleichmäßige Kartenübergänge und markante Gefrierpunktachsen

- Same-Model-Frame-Retention für Wolken/SIGWX während eines Laufwechsels; Renderer-Identität bleibt über Lauf- und Zeitschrittwechsel stabil. Modellwechsel behalten die bisherige strikte Trennung.
- Angezeigter Vorhersage-Vorlauf folgt während des Ladens dem tatsächlich sichtbaren Frame.
- Gefrierpunktlinie und Nullgrad-Achsenlabel in Stunden-, 7-Tage-, Horizont- und Ensemble-Temperaturdiagrammen hervorgehoben; gemeinsame 7-Tage-Kurve erhält Widget-Parität.
- Keine Änderung an Wetterdaten, Modellwahl, Warnungen oder RUC-Pipeline.

# MID v0.9.85.435 · evidenzgebundene Kurzfristaussagen

Basis: vollständig promotierter Stable .434 `994ea3bcf1ab20e7036f50a92b7033b44b538804`. Geprüfter Original-PR #668 @6245531ac82a6fb083d7110ddc725ba8cef93e67. Uneingeschränkte24h-Negativaussage nur bei lücken-/überlappungsfreier absoluter Zeitdeckung, maximal stündlichen finalen Buckets und endlichen nichtnegativen Mengen UND Böen in allen Buckets. Teilabdeckung ausdrücklich markiert, echte Signale bleiben priorisiert. Bestehende Originalregression um unabhängige Grenz-/Negativfälle verstärkt; vollständige Source-/Installer-/Worker-/Pages-/Stable-Gates bleiben zwingend. Keine amtliche Entwarnung und keine Änderung an Warnungen, Datenbezug oder Meteorologiefarben. Weitere7d-/Nowcard-/Nebel-/PoP-Auditpunkte sind nicht durch diesen begrenzten Fix erledigt.

# MID v0.9.85.434 · UI-Ergonomie, ruhige Ladeflächen und vollständiges Webbudget

Verifizierte Basis main=mid-stable .433 `5a12f7204b8b2a9305be0a9adefa3862648a3101`, vollständiger Installer42065087192 success. Parallele PostHog-Integration und Konfigurationsneubau #666/#667 erhalten. #663/#664/#665 integriert: 44px-Griffe mit passender Gridspalte, Pfeile und gemeinsame kompakte/Coarse-Pointer-Ziele; Pointer-Abbruch-/Unmount-Bereinigung, Positionsstatus, eindeutiges Mehr-aria-current und neutrale Ladeflächen einschließlich reservierter Kartenhöhe. Historischer CSS-Golden unverändert, zehn exakt geprüfte autorisierte Änderungen. Ausschließlich zwei unreferenzierte native Masterkopien entfallen aus generiertem Web-Dist; Quellen/iOS/PWA-Icons unverändert. Vollständiges Budget ohne angehobene Grenzen grün, 125 beibehaltene Dateien im A/B-Build bytegleich. 1079 Pflichtprüfungen, davon lokal1070 unterschiedliche Core erfolgreich und drei Chromiumfälle umgebungsbedingt blockiert. Sämtliche regulären Source-/Installer-/Worker-/Pages-/Finalize-Gates auf endgültigem SHA bleiben zwingend. Nachweis: `docs/implementation/MID_C55_UI_434_QA.md`.

# MID v0.9.85.432 · UI-Ergonomie und geprüfter Kilo-Handoff (Kandidat, nicht veröffentlicht)

Basis Stable .431 `77de0e326d586274d5f42f0ea63827a887d1b147`; #663/#664/#665 integriert. Korrekte 44px-Gridspalten und Pfeile, Pointer-/RAF-Abbruchbereinigung, Screenreader-Positionsstatus, eindeutige Mehr-Semantik und neutrale Ladeflächen. 1077 Pflichtinventar, Node22-Types/Vite und gezielte Interaktions-/Golden-Prüfungen erfolgreich. Gesamtbudget und reale Browser-/Installerabnahme weiterhin blockiert; keine Stable-/Veröffentlichungsbehauptung. Vollständige Evidenz/Prüfzähler und Grenzen: `docs/implementation/MID_C55_UI_432_QA.md`.

# MID v0.9.85.431 · Open-Meteo-Watch als begrenzte Betriebskorrektur

Stable .430 `e9b798a42d7e0e55e07d83858c92a6eaa04a96a9`. Sämtliche aktiven GeoSphere-AROME-Einstiege vor HTTP gesperrt, historische Kennungen erhalten. Browser-/Worker-Quoten: plausible absolute Minuten-/Stunden-/Tagesresets, gewichtete Header, erfolgreicher Body, Queued-Release-Rennen, lange Wartezeiten, Abbruchbereinigung und bestehendes Retry-After geschützt. 53 neue deterministische Fälle, aktive Retirement-Selektoren und vorhandene Zeit-/Feld-/Fallbacktests. Reale fünf heutige kleine Originalantworten aus #658 unverändert wiederverwendet; keine DWD-Massenläufe. Vorhandene Source-Classifier-/Ruleset-/Budget-/URL-Allowlist unverändert. Source-/Heavy-/Chromium-/Installer-/tatsächlicher Worker-.431-/Pages-/Stable-Nachweis noch erforderlich; C-LAEF/RRFS bleiben gesperrt. #658 ist als geprüfte passive Utility mit14 isolierten Transport-/Drift-/Objekt-/Issue-/Autorchecks mitgeführt; erste vollständige Kilo-Live-Nutzungsabnahme gesondert offen.

# MID v0.9.85.430 · UI-P0 und Cache-QA-Release-Recovery

Stable .428 6f08117ed0862c1573fec5c48844136b83e22bd5; fehlgeschlagener .429-Installer41926760038, verifizierter main bb3407178d225fe8e8143048438446b1b6c92543 (zwei Commits ahead, kein Verlust). Vorhandene UI-P0-Quellen vollständig erhalten. Node22.16.0 reproduziert den originalen Fehler actual1/expected0; instrumentierter CacheStorage-Mock zeigt Response.clone Body consumed. Neue bytebasierte Fixture besteht12 Wiederholungen mit22 Fällen; Löschfehler, genau ein isoliertes Cache-Drop und leeres Ergebnis weiterhin zwingend. Keine produktive Cache-/Fachlogik, kein Budget/Timeout geändert. Nur vollständiger Source-/Bot-/ZIP-/Installer-/Worker-/Pages-/Stable-Pfad erlaubt Freigabe. #658 bleibt getrennt.

## MID v0.9.85.429 · 2026-11-04 · Kilo UI-P0

Verifizierte Stable-Basis `6f08117ed0862c1573fec5c48844136b83e22bd5`, Ursprung aus Kilo-Commit `c68a7778a6a785ed34e8a3dc7da89159d7260c04`, Draft-Handoff #657. Bottom-Tabs, Favoriten/Warnungen, Touchziele, Fokus, mobile Legenden und Safe-Areas; kanonische CSS-Quelle statt direkter Editierung generierter Datei. Eigenen Test `scripts/test-kilo-ui-p0-0985429.mjs` in beiden verpflichtenden Regressioninventaren ergänzt. Keine amtliche Warn- oder Modelllogik geändert. Keine Releasefreigabe ohne vollständige Source-/Installer-/Worker-/Pages-/Stable-Gates.

## MID v0.9.85.428 · 2026-11-04 · Kartenbausteine

SHA-gesicherte Integration der drei MID18.2.73-Bausteine. RAM/Disk 24MiB, 20min TTL ohne Zukunftszeiten; bounded field streams, gleicher URL/SHA/Byte-Vertrag dedupliziert, unabhängige Abbrüche. Pointer bleibt no-store; Feldvalidatoren und Decoder unverändert. Originalpatch-Exportanker und Nullzugriff korrigiert. Gleiche Modell-/Run-/Time-Konturen und Cross-Panel-Raw-Preferences; schematische ww4677-Modellzeichen mit gemeinsamen SVG-/PNG-Legenden. Primärquellen-Fußnote bei96/99 berücksichtigt. Keine neue Quelle/Produktionsdatenfreigabe. CI/Source/Installer erforderlich.

# MID v0.9.85.427 · PWA-Marken und Budget-Dateinachweise (Releasekandidat)

Verifizierte Stable-Basis .425 / 7e998730daaa4a409cd3e15d4f4cf0f70efaaeda. Selektive Sammelintegration #652 @ 999aa5601d06431b5c4f568d97afa86080f2efe4 und #653 @ 11f63707d4d231ac7626ca006b2b5e1362636307. Reale Registrierungsupdate-Abnahme .425→.427 einschließlich Waiting/Activate/Controllerchange/Healthy, Offline-Alias-/Theme-Decodes, Rollback und beschädigtem Update bestanden. Reproduzierten Aktivierungsdeadlock behoben: Client-Navigation wird vor Abschluss des activate-Events beauftragt, ihre Antwort jedoch nicht innerhalb dieses Events abgewartet. Budget-Dateireport und CI-Artefakte erhalten; keine Budgetgrenze verändert. Nachweis: docs/implementation/MID_PWA_BUDGET_INTEGRATION_0.9.85.427.md. Erst reguläre Source-/Bot-/Installer-/Worker-/Pages-/Finalize-/Stable-Gates erlauben eine Veröffentlichungsbehauptung.

# MID v0.9.85.425 · Niederschlagsintervalle konsistent dargestellt

Skybar und Profildetails verwenden dieselben tatsächlichen Akkumulationsintervalle. Beispielsweise werden 0,2 mm in 15 Minuten in beiden Ansichten mit 0,8 mm/h ausgewertet. Der Release enthält außerdem die Zielzeitzonen-Korrektur der Regionalensembles aus .424.

# MID v0.9.85.424 · Ortszeit für Regionalensembles

Regionalensemble-Prognosen werden nach dem verifizierten Kalender des Zielorts ausgewertet. Die Tagesmengen berücksichtigen Zeitumstellungen mit 23 bzw. 25 Stunden. Die ursprünglichen UTC-Zeitpunkte und die Datenherkunft bleiben nachvollziehbar. Abgeleitete Caches berücksichtigen die Zielzeitzone.

# MID v0.9.85.423 – Karten und 7-Tage-Vergleich

Kartenexporte werden erst bei Bedarf geladen. Die Karte hält beim Laden ihren Platz. Der 7-Tage-Vergleich lässt sich per Tastatur horizontal scrollen.

## MID v0.9.85.417 · 2026-11-03 · meteorologische Schnee-Hinweis-Integrität + Skybar-Vierstufen

- Ausgangspunkt live SHA-verifiziert `main=mid-stable` v0.9.85.416 `2f9806fe1349e9b35001f8aa313e127f888dee91`, fünf aktive GitHub-Rulesets, 38 Normverträge und 1.064 Pflichttests. Parallele Draft-Änderung #634 (Skybar) bleibt unabhängig und wird weder ungeprüft gemergt noch auf Hauptbranches geschrieben.
- `src/weather-src/30-ensemble-climate-hazards.tsfrag` und daraus bestehender Aggregate-Spiegel `src/weather.ts`: Ende des veröffentlichten 168h-Hinweiszeitraums als echter Epochengrenzwert; zusätzliche +72h nur als zeitlicher Prognosekontext, NICHT zum Qualifizieren von MID-Warnschwellen außerhalb des Warnhorizonts. Vollständige Niederschlagssummen und Warnklassen werden ausschließlich innerhalb der ersten 168h geprüft; adversarielle Gegenprobe 0,2cm Tag7 + 25cm Tag10 darf keine 25cm/72h-MID-Warnung erzeugen. Keine MID-Warnung mit Ereignisanfang an/außerhalb der Grenze. Kein pauschales „Tag 6–7“; dynamischer Prognosetag aus Ereignisbeginn, 48h/120h Unsicherheitscharakter weiter klar. Für eigene leichte Schneesignale ab +120h: <1cm bei 6/12h, <3cm bei 24/48/72h lediglich in regulärer Prognose (eigener nichtamtlicher MID-Relevanzfilter). Sub-1cm-Mengen als solche etikettieren; ab 1cm höchstens zum nächsten Zentimeter aufrunden statt der bisherigen Pauschalspreizung. `src/dwdWarnings.ts` Kurz- und Narrativwerte für Spuren repariert, analytische DWD-artige Schwellen und Originalwarnungen unverändert.
- `src/detailSkyBar.ts` klassifiziert bekannten Gesamtwolkenanteil Cloud>=50 grau bzw. <50 tagsüber Wolkenlücken gelb, 45% cloud/100% unabhängige sunshineDuration führt zu Stufe 1/4. Bei fehlenden Wolken weiterhin echte Sonnenminuten als gekennzeichnete Ersatzquelle. Vier Klassen 50/62.5/75/87.5 %, Stroke 2.4/3.6/4.8/6 SVG; Overlay und Tageslichtclip unverändert. Einstellungen, Overlay-Provenienz und 90min-SVG-Titel angepasst.
- Bestehende sechs relevante Skybar-Regressionen semantisch angepasst, nicht abgeschaltet. Neu `scripts/test-warning-snow-horizon-coherence-0985417.mjs` inkl. Fällen Tag10, 0,4cm/4cm im Prognosehorizont, +120h, korrektem Modellbetrag/„unter 1cm“, dynamischem Lead, 45%/100%-Konflikt. Baseline-Pflichttests 1.065, Versionsspiegel v0.9.85.417, iOS Build 418.
- Verbindliche präzisierte Verträge `MID_WARNING_HYBRID_CONTRACT.md` und `MID_24H_PROFILE_STORY_AXIS_CONTRACT.md`. Release nur per Source-PR-Gate auf genauem HEAD, SHA-gebundenem Bot, serverseitigem ZIP, `install-mid.yml` Core/Heavy Worker/Pages Finalize → Stable; Belege abzuwarten. Keine DWD-/RUC-/Fast-Vollgebietsdaten-Aktivierung.

## MID v0.9.85.416 · 2026-11-03 · Abgleich der Originalbilder und Core-Changelog-Reparatur

- Vorgänger-Commit von PR #641 hatte die historischen CHANGELOG-Spiegel gelöscht und dadurch historische Regressionstests in allen Core-Shards verletzt. Beide Changelogs werden vollständig und bytegleich aus dem originalen `.415`-Stable wiederhergestellt, mit `.416`-Eintrag ergänzt; Tests unverändert streng.
- Originalbilder 02.11.2026: echte HTML/DOM-Reihenfolge 14d Temperatur/Unsicherheit → Wochenstreifen → Phasen; 7d-Kompaktkarten als horizontale Zeilen; 7d/14d-Diagramme gestapelt und mobile Tabellen bleiben horizontale Matrizen. Meteorologische Werte, Unsicherheiten, Warnungen, RUC/D2, 38 Verträge und Gates unverändert. Visuelle Browser- und reale iOS-Abnahme sind weiterhin getrennt.

## MID v0.9.85.416 · 03.11.2026 · Typografie-/Konsistenzkorrektur 7d/14d

- Exakter Quellausgangspunkt: veröffentlichtes `main=mid-stable` v0.9.85.415 SHA `c96c35531e44a868a71705f9244c6be83ff45213`; autorisierter Integrationsbranch `chatgpt/v0.9.85.416-forecast-design-coherence`. Keine auf ältere Entwurfsbranches zurückgesetzte Arbeit.
- Neue 7d- und 14d-Bausteine nutzen die vorhandenen MID-Inter/System-Schriften, `--mid18-text-*`- und `--mid-surface-*`-Tokens. Schalter, Karten, Tabellen und Diagramme wurden hinsichtlich Schriftgröße, Gewicht, Abständen, Rahmen und Schatten vereinheitlicht, 44px-Touchziele und Fokuszustände erhalten.
- Drei klar benannte Ansichten: „Übersicht“, „Diagramme“, „Tabelle“. Sichtbare Entwicklungskennungen A/B/C entfernt, interne `standard|charts|table` bzw. `compact|charts|days`-Persistenzschlüssel und alle Originaldaten-/Detailfunktionen unverändert.
- Source-Regressionen aktualisiert und um konkrete Terminologie-/MID-Token-Kontrakte erweitert; keine Prüfmatrix oder Sicherheitsfreigabe abgeschwächt. 1.064 vorgeschriebene Regressionen, 38 Vertragsregistereinträge und fünf aktive Branch-Rulesets unverändert.
- Versionierung: alle Release-Spiegel v0.9.85.416, iOS Buildnummer 417, zwei SW- und zwei Worker-Mirror synchron. Kein Modell-/RUC-/WARN-/Quellenalgorithmus geändert; Worker nur Versionsstempel.
- Freigabe nur nach vollständigem exakt SHA-gebundenen Source-PR-Gate, kontrolliertem Release-Bot-Merge, serverseitigem ZIP, `install-mid.yml` mit Core/Heavy/Worker/Pages/Finalize und Stable-Readback. Realer iOS-/VoiceOver-Hardwaretest ist separat zu belegen.

## MID v0.9.85.415 · 2026-11-03 · Design-WE 7d/14d Sichtbarkeit und echte A-Kompaktheit

- Design-WE-1.2-Sammelergänzung statt eigenständigem unveröffentlichten .416-Zwischenbuild: 7d A eigenständige 7 kompakte Tageskarten mit Originalicons, Temperatur, Niederschlag/PoP, Wind/Böen und Sonne/UVI; Originaldarstellung einschließlich Tages-Skybar, vollständigen Ensembles und Stundenprofil wird ausschließlich für den aktiv gewählten Tag **inline** direkt darunter gemountet, kein Legacy-Duplikat für die übrigen Tage. B/C Visual-/Tabelle-Hierarchie optimiert, A-Toggle und C→A als getrennte Bedienpfade.
- 14d A um drei Phasen, zwei horizontal/Keyboard-zugängliche Wochenstreifen, 14 Piktogramm-/Datenkarten, Ensembletemperaturkurve erweitert; B vier getrennte Grafiken, C echte 14-Tage-Tabelle; Original-Tagesdetails in bestehendem Panel und aufrufbar mit adaptivem scroll/focus nach Nutzeraktion, keine erzwungene Bewegung bei prefers-reduced-motion.
- Die bestehenden verpflichtenden Responsive- und Browser-QA-Verträge wurden nicht gelöscht: H-Regression prüft explizit nur einen kanonischen Tag plus Stunden-Missing-Fallback, `verify-forecast-views-browser-0985145.mjs` behält 96 viewport/theme/unit-Kombinationen und testet zusätzlich 7/14 neue A-Karten, tatsächliches Öffnen, originale Tagesinfos, Temperatur-/Trace-/Ensemble-/Overflow-Verträge; Browser-Harness lädt die ausgelagerten CSS-Quellen. Prüfergebnisse nur nach neuem CI-HEAD als bestanden melden.

- Grundlage: vollständig veröffentlichtes v0.9.85.414 `main=mid-stable b2b9bb3c3eab78fac117bd0b0d2110b1ce127b66` und erfolgreicher Installer #41584352470. Fünf Rulesets, 38 normative MID-Verträge, bestehende 1.063 Pflichtregressionen unverändert erhalten.
- Reproduzierte Produktionslage mit realer Browser-DOM-Messung, Testort Berlin 390×844: 7d A/B/C erst bei y≈803, Standardkarte je ≈264px wegen ≈98px immer sichtbarer Ensemble-Einordnung; vorausgewählte Tagesansicht umfasst zusätzliche ≈911px Stundenprofil. 14d Diagramme erst ab y≈849 wegen vorgeschaltetem großem Prognose-Kompass. Das war reale Informationshierarchie-/Erstbildschirm-Drift trotz veröffentlichter .414-Chunks; kein Versionskonflikt.
- `ForecastCockpit.tsx`: 7d-A/B/C als **eine** Toolbar oberhalb `SevenDayCurveOverview`, die unverändert bleibt; tatsächlicher Inhalt darunter. Default A gerätelokal persistiert. Details/ForecastRangeGuide in gezielt antippbare Tages-Accordions ausgelagert, mit unabhängigem offen/geschlossen-Zustand und `aria-expanded/aria-controls`; Tischansicht C öffnet denselben vollständigen Datensatz. Keine Bild-/Datenentfernung. 14d `FourteenDayDevelopment` vor `CockpitForecastGuide` gerendert, einschl. bisheriger Source-/Quantilhinweise und vollständiger 14-Tage-Karten. Gewählte Windeinheit wird übergeben.
- `SevenDayDesignModes.tsx`: kontrolliertes `showModeSwitch=false` nur im echten Cockpit, damit keine doppelten Schalter unter der Skybar erscheinen; standalone-SSR-/Unit-Nutzung mit Default true erhalten. `midDesignWeSeven.css` hebt den frühen Schalter hochwertig und kontrastbewusst hervor.
- Regression: neue `scripts/test-forecast-design-visibility-0985415.mjs` als 1.064. Pflichtprüfung mit strikter Reihenfolge, NoData, vollständigem Guide nur nach Opt-in, ARIA, Touch/Fokus. Ergänzter direkter SSR-/Unit-Test in `tests/unit/designWeSevenModes.test.ts`. Build/CI/Browserpixel, Core/Heavy, Worker/Pages/Installer müssen am .415-HEAD vollständig neu grün nachgewiesen werden; keine Testabschaltung oder Schutzschwellenabsenkung.
- Versionsspiegel: package/lock, Baseline, Vertragsregister, Web, Worker (3), SW (2), iOS Build 416, Changelogs, Source of Truth. Für vollständige Freigabe MID Source-PR Gate → kontrollierter SHA-Bot → serverseitiges ZIP → `install-mid.yml` Core/Heavy/Worker/Pages/Finalize → Stable; danach echte Live-Sichtbarkeit 320/390/768/1440 plus Bedienung B/C und C→Stunden prüfen.
- Grenzen: keine neue DWD-Originalsignatur/Fast-Lane-Aktivierung. Eine echte iOS-/VoiceOver-Hardware- oder vollständige WCAG-AA-Zertifizierung ist erst nach separatem belegtem Gerätetest zulässig.

## MID v0.9.85.414 · 2026-11-03 · gebündelte Forecast-UX A/B/C und geschützte DWD-D2-Signer-Härtung

- Verifizierter, bereits veröffentlichter Stable-Basispunkt: v0.9.85.413 `2052dc426c972bcfae8527001ce2082fab82c869`; ursprüngliche 13 Quell-/Unit-Test-Dateien aus Draft #629 @ `d52a0996d0fdc707135edc4426a20860c19c0dff` plus drei DWD-Signer-/Testdateien aus Draft #630 @ `836fc92b22604ffe21052b8ce341319b005ddaa9`, exakt per Blob-SHA auf neuen Sammelbranch übernommen.
- Nutzerinteraktionen: 90-Minuten-Werte erneut einklappbar; Heute-Parameterfokus auf Temperatur/Niederschlag/Wind; 7d durchgehende Skybar + Ansichten A Standard/B fünf Parametercharts/C Tagesmatrix; 14d A Übersicht/B Diagramme/C Tagesdetails; 44-px-Fokus-/Touchziele, responsive CSS, unveränderte Ensemble-/NoData-/UTC-/DWD-Warnsemantik.
- Sicherheitsintegration: geschützter DWD-Originaldaten-Signer prüft exakt gleiche `main`-/`mid-stable`-Commitidentität vor und nach der SLSA-Attestation, authentifiziert den signierten Index; keinerlei automatisches Pages-/Worker-/Fast-Produktiv-Grant.
- Eine neue verbindliche Regression `scripts/test-design-we-forecast-modes-0985414.mjs` erweitert das vollständige Pflichtinventar auf 1.063; 38 normative Verträge, 5 Rulesets und geschützter regulärer Releaseweg bleiben unverändert.
- Zur Veröffentlichung ist eine neue vollständige Source-Gate-/SHA-Bot-/serverseitige ZIP-/Installer-Core-/Heavy-/Worker-/Pages-/Finalize-/Stable-Promotion am exakten .414-HEAD zwingend. Diese Eintragung ist kein Freigabebeleg für ungeprüfte echte D2-/RUC-Fast-Livedaten, 168h-Frische oder Hardware-VoiceOver.

## MID v0.9.85.413 · 2026-11-02 · D2/RUC/Fast-Source-Port nach Design-WE-Stable

- Ausgangsbasis: vollständig promotierter v0.9.85.412-Stable `8349fa89e9a66d09d320d1774c86dda4d14a4d4a`, Installer #41515302726 success. Original-Source-PR #625 @ `bf07de77eca4816516cf96281da1d970daebc71b`, Source-Gate #41513667882 success ausschließlich für alten .412-HEAD.
- 103 nicht überlappende D2/RUC/Fast-Quell-, Workflow- und Testdateien SHA-identisch übernommen; 18 überlappende Design-/Versionsdateien auf .413 fachlich zusammengeführt. Die 1.062 Design-Stable-Pflichtregressionen und 38 Normverträge bleiben erhalten.
- Release nur über neuen vollständigen Source-PR-Gate, SHA-gebundenen Bot, Server-ZIP und install-mid.yml Core/Heavy/Worker/Pages/Finalize → Stable. Signierte DWD-Originaldaten, globales Publisher-Fencing/Rollback, echte Endkunden-/Gerätefrische bleiben separat gesperrt.

## MID v0.9.85.412 · 2026-11-02 · Design-WE 1.1: Heute/24h-Wetterprofil

- Verifizierte Basis: `main=mid-stable` v0.9.85.411 / `9bf44c3354f98937fa058aac5d6dceb5895d29e5`; fünf unveränderte Rulesets. Separater RUC-/D2-Draft #623 bleibt unveröffentlicht und ist kein Teil dieser Version.
- `src/ForecastCockpit.tsx`: fokussierbare Parameterbahnen (reine optische Betonung), selektierte 24h-Stunde, gerätelokal persistierte vollständige Einzeldaten mit gültiger `aria-controls`-Zielregion; mobile Viertelstundendetails für Niederschlagsmenge/PoP/Wind/Böen mit Missing ≠ 0.
- `src/midDesignWeToday.css` (dynamisch aus `ForecastCockpit.tsx` importiert): responsive Darstellung über kanonische `src/styles-src/presentation-order.json`, C27-Max-Content-Toolbar-Fix mit byte-identischer Eager-CSS-Kaskade und separat geladenem Today-CSS, Light/Dark-Surfacevariablen, 44px-Touchziele und Reduced Motion. Skybar und Bewölkung liegen oberhalb der Temperatur; alle gemeinsamen 24h-Zeitachsen bleiben unverändert.
- Test-Nachweise vor Release: Vitest inkl. direkt ausgeführter Pflichtregression und TSX-/PostCSS-Parsing #41509136061 sowie unabhängige RUC-Read-only-QA #41509136110 erfolgreich auf unveröffentlichtem Design-HEAD `a797962dadead35e702d2005eedaa8fdad78d73b`. Der versionierte HEAD muss den vollständigen eigenen Source-PR-Gate und Installer bestehen.
- Versionsspiegel: package/lock, Baseline und Verträge, Web- und Worker-Mirrors, Cache, iOS `CURRENT_PROJECT_VERSION=413`, Release Notes und Changelogs. Unveränderte 1.760.000-Byte-CSS-Hauptbudget-Grenze und 320px-Classic-Touchziele über eigenen Source-Gate geprüft. Kein vorgezogener Erfolg für echte iOS-Geräte/VoiceOver, vollständige WCAG-AA- und Widgets/Export-Abnahme.
- Freigabe ausschließlich über SHA-gebundenen Source-PR-Bot und `install-mid.yml` Core/Heavy/Worker/Pages/Finalize → `mid-stable`; bei Prüfungsausfall keine Stable-Promotion.

## MID v0.9.85.408 · 2026-11-01 · Audit 1.9: durchgehende NoData-Integrität und mobile Scrollachse

- SHA-verifizierte letzte Stable: MID .407 `main=mid-stable` `bcf75d001f8973f54203fccb24d94353226d2de7`, Source-PR #604 kontrolliert gemergt, Installer #41358613904 completed/success inklusive 1059 Pflichtregressionen, Heavy, Worker, Pages, Finalize. Fünf aktive Rulesets, 38 normative Verträge. Keine direkten Hauptbranch-Mutationen.
- Vollwertiger Audit-Integrationsumfang aus Nutzeranlage und intern gesichertem elfteiligen P1-Satz: `ShortTermForecast.tsx`, `ForecastCockpit.tsx`, `EventPlannerPanel.tsx`, `MountainWeather.tsx`, README und fünf zugehörige bestehende Pflichtregressionen; Git-Originalblobs des Vor-Release-Basis-Snapshots waren nach Vergleich .406→.407 unverändert.
- **A1-01 P0:** In `precipitationNowSummary` nur tatsächliche `nearestProb` verwenden. Kein `maxProb<=5?0` für gültige 1–5 %; weiterhin `null` bei Missing, echte 0 bleibt 0. Der zuvor auf 1–5→0 ausgelegte *obligatorische* Source-Negativtest wurde mit einer fachlichen, ausführbaren 0/1/4/5/9/100-Matrix statt abgeschalteter Prüfung korrigiert.
- **A5-01 P0:** Event-Center-Metrik mit Einheiten nur bei vorhandenem endlichem Wert; fehlende Temperatur/PoP/Menge = „nicht verfügbar“ statt „–°/–%/–mm“. Reale 0°/0%/0mm erhalten. Original-Event-Funktionstest erweitert.
- **A2 P1:** Kurzfrist-PoP durch echte Quellen-/Postprocessing-Validitätsmaske statt `Number(NaN)||0`, im UI „nicht verfügbar“; bei fehlendem Stunde-Originalwind/Böe/Richtung explizit `NaN` und „–“ statt Windstille/Nord. UTC-/Intervall-, Originalradar- und Phasenlogik bleibt unverändert.
- **A5/A6 P1:** Eventplaner/Wasser-/Berg-/Schneefallgrenzen zeigen fehlende Wettercodes und Zeit-/Niederschlagoriginale nicht als klare/trockene Wetterlage. Nicht verfügbare Mengen-/PoP-Felder im Schneelinien-Chart werden explizit als solche markiert; echter Nullwert bleibt zulässig, keine Extremwertglättung.
- **A0-01 P1:** Smartphone-Prognose besitzt eine natürliche vertikale Dokumentachse, kein `max-height`-gekappter `overflow-y:auto/contain`-Nested-Scroll bei 320–850px Porträt. Seitliche Zeitachsen `overflow-x:auto` und bestehende Safe Area/Bottom-Bar-Reserve bleiben. Vorhandene C9-Pflichtregression dem fachlich veränderten UX-Kontrakt angepasst und um negative Scrolltrap-Assertions erweitert; keine bloße Testabschaltung. Reale iOS-/VoiceOver-/Dynamic-Type-Abnahme und Pixelverifikation offen.
- **DA19-16 P2:** Den unbewiesenen Theme-Claim „Hoher Kontrast (WCAG AA)“ zu „Hoher Kontrast“ korrigiert; bestehendes C9-Quell-Gate prüft die Abwesenheit der Zertifizierungsaussage. Vollständige quantitative AA- und Screenreader-Abnahme ausdrücklich offen.
- **DA19-01/Golden:** DA19-01: `test-module-css-consolidation-0985170.mjs` prüft zusätzlich die **exakt freigegebene mobile Scrollregel** und stellt allein für die historische Vergleichskopie die originale .407-Regel wieder her; der unveränderte .169-Cascade-Hash ist weiter zwingend. Kein Entfernen von Golden-Assertions, kein Umbenennen von Shards.
- **A0-03 P2:** Statische README-Version durch `https://www.midwx.app/version.json` ersetzt, in bestehender Versioning-Regression geschützt.
- 1059 Pflichtregressionen und 38 Vertragsinhalte bleiben im Release unverändert. Version vollständig in package, lock, MID_BASELINE, contract registry, Web/meta/PWA/SW, Worker-Spiegeln, iOS/Xcode Build 409, Nutzer-/Technik-Changelog und strukturierten Release Notes synchronisiert.
- **Nicht eingeschlossen / nicht grün:** D2/RUC-Vollgebiet #446, PR #600 +3h originaler TOT_PREC-Reset/Packungsfehler, RUC P1–P5 #541, appweite A0–A6-Kontrast-/Zeiten-/WMS-Pixel-/Widgets-/Endgeräte-/iOS-VoiceOver-Qualifikation. Separate fachliche Zulassung erforderlich.
- MID-Pfad nur non-Draft Source-PR und 1059+ Core/Heavy/Browser auf finalem SHA → controlled SHA-bound Merge → Server ZIP → install-mid.yml Core/Heavy/Worker/Pages/Finalize → Stable-Promotion. Keine Voraus-Freigabe aus dieser Dokumentation.

## MID v0.9.85.407 · 2026-11-01 · Designaudit 1.9 – PoP-NoData, Favoriten/Event-Center, ARIA und sichere Trockenheitsklassifizierung

- Verifizierte Startbasis: v0.9.85.406, `main=mid-stable` SHA `5ebac2e7d62efb92dfdebb406d4125964057a1ba`, vollständiger Installer #41354077136 `completed/success` (Attempt 2), 5 aktive Rulesets, 1059 Pflichtregressionen, 38 Verträge.
- Quellherkunft: fünf SHA-verifizierte Fach-/Test-/Auditdateien aus Designaudit-Draft #603 Head `83ac75fe1f964b7c31ff0081133897786fb98618`; alle bestehenden angefassten Dateien auf .405 und .406 zuvor Git-blobidentisch. Drei unveränderte Source-/Test-/Auditblobs; `src/App.tsx` und bestehender Niederschlagspflichttest mit weiterem konkretem `null<10`-Trockenheits-Fix ergänzt.
- Fachlich: fehlende aktuelle PoP wird `null`, Anzeige `–`; visuelle Trockenklasse nur bei tatsächlich vorhandenem endlichem PoP 0 bis unter 10, niemals durch JS-Null-Koerzierung. Radar-Modell-Mix ohne erfundene Prozentwerte; Favoritenregeln nur für gültige endlich belegte PoP/Böen/Temperaturen und unter Beachtung `enabled:false`.
- Event-Center und Wasserprofile: `Number(null)===0` und Boolean/Leerstring Legacy-Werte nicht als echte Wettermessung/Schwellen; defaults bei Missing, echte Null und definierte Clamp-Grenzen erhalten. Mehr-Drawer hat ARIA-Heading-Level-2; Fokus-/Dialog-/Escape-Verhalten unverändert.
- Drei **bestehende** obligatorische JS-Regrressionstests um tatsächliche TypeScript-Quellfunktionsausführung erweitert, besonders null/undefined/NaN/Infinity, echte 0, Radar-Timeline/Provenienz, Mixed Hours, Wasserprofil, Trockenklasse. Keine Tests entfernt; 1059 registrierte Pflichtregressionen verbindlich.
- Meteorologische und Release-Restgrenzen: D2-Original-TOT_PREC-Zellabweichung in Draft #600, Vollgebiet #446, RUC P1–P5 #541, WCAG/physisches iOS/VoiceOver, echte Live-P95 bleiben offen. WMO/DWD/amtliche Warnungen und alle RUC/PAGES-Budgets unverändert.
- Ausschließlich vollständige Source-PR-Gates am exakten finalen SHA → MID-SHA-Bot → Server-ZIP → `install-mid.yml` Core/Heavy/Worker/Pages/Finalize → Stable; dieser Kandidat ist vorher nicht veröffentlicht.

## MID v0.9.85.406 · 2026-11-01 · RUC Datenintegrität, 168h Originalarchiv und SHA-gebundener Pages-Single-Writer

- Live Stable-Basis: MID .405 SHA 6410cf049f097b1d0518beac601e1baa08583f4a, Installer #41346300018 vollständig grün; fünf aktive Rulesets, 1059 Pflichtregressionen.
- Exakt 8 SHA-geprüfte original Code-/Test-/Doku-Blobs aus PR #596 HEAD 9273db1392ece8f2a76102b7c46711bdce6dfa98 und PR #598 HEAD c227db8d13910d91828e86eb0e81422756421070 in PR #601 integriert. Kein Überschneiden mit .405.
- Snapshot-Neu-Fingerprints nehmen nur Test-/Read-only-P3-Log-Auditor aus Runtime-Hash aus; unveränderliche Datenreceipts, tatsächliche RUC-Module, Worker-Decoder, canonical Workflow/Lockfile, Original SHA und Ancestry bleiben hart geprüft. Alte versiegelte Receipts nicht rückwirkend zulassen.
- 168h-Originale-Archiv: paginierter Repository-Scan bis 6400, danach authentifizierte exakte Run-ID/Attempt-Artefaktlisten, vollständige Seiten, Parent-/SHA-/Duplikatkontrolle, fehlende Daten zensiert statt interpoliert.
- P4 adversarieller Test sichert existing mid-pages Single-Flight für App-Retries+Finalize, RUC-Publish+Rollback, Source-Guard und immutable Digest auf BEIDEN Artefakten. Cross-Provider Global CAS/Fencing bleibt ausdrücklich offen.
- Quell-Preflight: Snapshot/P4 #41351487477, P1/P5 #41351487543 und Vitest #41351487586 jeweils completed/success auf vorherigem Head 4cb9bd3813926ff2983467352ca2a5a8237d5dde; Source-PR Core+Heavy auf FINALEN versionierten Head erneut erforderlich.
- P1 Echt-DWD 168h+ Original GRIB/Werte EPS20; P2 selbständiger echter 0–6h-Provider- und Clientpfad; P3 identische Originaldateien A/B CPU/RAM/Bytes/900MB; P4 globale CAS-Fencing und P5 echte Web/Widget/Export Adoption/60min-P95 weiterhin OPEN (#541).
- Parallele D2-Vollgebiets-Drafts #600/#602 bleiben unangetastet und sind nicht Teil dieser Freigabe. Nach erfolgreichem .406-Stable nur auf neuem SHA in nächster Version qualifizieren.
- Synchronisiert: package.json, package-lock, MID_BASELINE, contracts/index, src/version, web/meta, PWA Cache, Worker-Spiegel, iOS Build 407, Changelogs und strukturierte Release-Notiz.
- Nur SHA-gebundener MID Source-PR Gate → kontrollierter Bot-Merge → serverseitiges ZIP → install-mid.yml einschließlich Core/Heavy/Worker/Pages/Finalize → Stable; niemals direkte Hauptbranchmutation.

## MID v0.9.85.405 · 2026-11-01 · Designaudit 1.8: Tag-3–7-Extremwetter, robuste Datenbeschaffung und Zustandsintegrität

- **Freigabebasis verifiziert:** v0.9.85.404 `main=mid-stable` SHA `8cf0c99ecc0a4c6502c188a9ca108466b53bb128`; `install-mid.yml` #41339459410 success mit sämtlichen Core-/Heavy-/Worker-/Pages-/Finalize-Jobs; 5 aktive Rulesets, 1059 verpflichtende Regressionen und 38 normative Verträge.
- **Original-Source-Sicherung:** selektive Fach-/Test-/CSS-/Doku-Blobs aus Draft #595 SHA `5385616d01a59790b4a793cd042c55bb1c6eab82` nach exaktem Blobvergleich mit .403 und .404; `src/ExtremeWeatherOutlookPanel.tsx` nur patchweise übertragen, damit die in .404 veröffentlichte interaktive `role="region"`-ARIA-Karte erhalten bleibt. `worker.js` und `worker/metar-proxy.js` ausschließlich aus .404 mit unveränderten Quellenanteilen und exakt einem aktualisierten kanonischen `worker-src/25-dach-extreme-outlook.js`-Segment erzeugt. Beide Worker-Spiegel blobidentisch; generierter Browser-Direktfallback enthält denselben Fachquelltext, nur in request-lokaler Cache-Bindung.
- **Kaltstart:** längere serielle Upstream-Batches mit maximal zwei parallelen 16-Punkte-Request-Streams (keine unkontrollierte Fanout-Erhöhung). Identisches Open-Meteo-Variablenbudget und bisherige EPS-Mitgliedszahl, keine neuen Modelle, Worker-Rechte oder Daten-Schemaparameter.
- **Verfügbarkeitssemantik:** durchgehend stündliche, gemeinsame UTC-Laufachse; inkonsistente Starts und zu kurze Memberlisten scheitern am vorhandenen 65-%-Admission-Gate. Bei vorhandenen gültigen 24-h-Originalperioden nicht vorhandene Hazardfelder ausdrücklich unbewertet lassen und Teilhorizonte nach ursprünglichen Zeitstempeln präsentieren. Keine Missing→0-Umetikettierung.
- **Fallback und UI:** Gesicherten 3–24 h alten Cache als eindeutig veraltet anzeigen und im geöffneten Modul revalidieren; Modellzeit `checkedAt` statt Cache-Schreibzeit als Frischemaßstab; manuelles Refresh darf sichtbare geprüfte Daten bei Netzwerkfehler nicht löschen. Visuell mobile Meldung, Retry und 44-px-Touchbereich geschützt; Short-Range und amtliche DWD-Warnungen bleiben unverändert.
- **Erweiterte bestehende Pflichtregressionen:** `scripts/test-extreme-outlook-extended-resilience-0985154.mjs` (Source-/Generated-Semantik, 2er-Parallelitätsprobe, Cache-Staleness, Retry) und `scripts/test-extreme-outlook-real-members-0985155.mjs` (Original-40-EPS, 24-h-Missing, differierende Laufachsen, kürzere Zeitserien, korrekte Teilhorizonte) behalten ihre bisherigen Prüfungen. Vollständige Core-/Heavy-/Browser-/Installer-Gates auf finalem SHA sind zwingend.
- **Versionsspiegel:** `0.9.85.405` in Paket, Lock, Baseline, Contract-Registry, Web/PWA/SW, Workers, iOS-Status, Xcode CURRENT_PROJECT_VERSION 406; neuer Nutzer-/Build-Changelog und strukturierte Release Notes.
- **Noch nicht belegt:** tatsächliche Endgeräte-Ladezeit/P95, CDN-API-429-Wirkung, reguläre Smartphone-/Tablet-/Desktop-Matrix, echtes iOS/VoiceOver, A0–A5-Restaudit, D2-RUC-Vollgebiet; keine Erfolgsmeldung ohne separaten Nachweis.
- **Release-Reihenfolge:** vollständig grüner nicht-Draft Source-PR HEAD → kontrollierter SHA-gebundener MID-Bot-Merge → serverseitiges ZIP → unabhängiges vollständiges `install-mid.yml` → Worker/Pages/Finalize → Stable SHA-Promotion. Keine CI-Abkürzung und kein Hauptbranch-Write.

## MID v0.9.85.404 · 01.11.2026 · Karten-Idle-Preload, einpassige Extremwetterabdeckung, read-only RUC-P3-Log-Audit

- **Verifizierte Stable-Provenienz:** v0.9.85.403, `main=mid-stable` SHA `e908b767a9db09df6f07afef86e471978807b5bb`; Installer [#41331015688](https://github.com/MeteoMartini/MID/actions/runs/41331015688) einschließlich aller Core-, Heavy-, Worker-, Pages-/Finalize-Jobs erfolgreich. Fünf aktive GitHub-Rulesets, 1059 registrierte Pflichtregressionen. Releasebasis frisch verifizieren, bevor dieser Quellkandidat gemergt wird.
- **Design-/Karten-Batch aus #590:** Sieben Fach-/Test-/Audit-Blobs wurden exakt vom verifizierten SHA `d9aecda53fba39d722b517f6c4db62ef98d52337` auf neuer `.403`-Stable-Basis übernommen. Darin enthalten ist der vorherige reine Kartenfeature-Head aus Draft #589; dessen ältere `.403`-Versionsspiegel wurden NICHT übertragen. Die Audit-Dokumentation erhält einen klar markierten neuen .404-Integrationskopf, bleibt historische Prüfchronik.
- **JS-Modul-Vorladen:** `src/mapIdlePreload.ts`, `src/App.tsx` und die registrierte `scripts/test-c14-map-workspace-098534.mjs` prüfen optionale, kündbare `requestIdleCallback`-Importe der bestehenden MapWorkspace-/Radar-/UnifiedWeatherMap-Module ohne Datenabrufe. DataSaver, 2G/slow-2g, Offline, Hidden, Search/Drawer und aktive Karte sperren den Idle-Pfad.
- **Karten-UX aus dem parallelen Draft #594:** Vier SHA-identische UI-/CSS-Blobs aus `95d097434c6980b77e5bbf82d3190169f0e3d4fb` für `RadarPanel.tsx`, `UnifiedWeatherMap.tsx`, `MapWorkspace.css`, `UnifiedWeatherMap.css`; C14-Pflichtregression wurde **additiv** um die Source-Assertions des Drafts erweitert, ohne Idle-Preload-Regressionsfälle zu entfernen. Eine gemeinsame absolute lokale + relative Framezeit samt Prognose-/Messphase wird in der vorhandenen einklappbaren Legende gezeigt; das zweite absolute Overlay entfällt. Karten-Surface vor Zeit-Details; genau ein Beobachtungs-Master; eine sekundäre Einstellung statt doppelter Offenlegung; min. 44px Fokus-/Touchziele. Alle Quellen-/Parameter-/Persistenzmöglichkeiten bleiben in der bestehenden Komponente. Keine 10s→X-Latenzbehauptung ohne E2E-Befund.
- **Unveränderte zugängliche Bedienungsidentität:** Source-Gate #41335101804 zeigte, dass alle drei MapLibre-Heavy-Shards bei unverändert strengem Playwright-Test auf den historisch stabilen Schalternamen `Modell / Messraster` warteten. Die kompakte sichtbare Bezeichnung `Modell an/aus` bleibt; `src/UnifiedWeatherMap.tsx` führt `aria-label="Modell / Messraster"` für den echten, weiter `aria-pressed`-gesteuerten Schalter ein. Ein zusätzlicher C14-Pflichttest sichert die Screenreader-/Automatisierungsidentität; Browserprüfung bleibt unangetastet. Vollständiges Source-Gate auf neuem SHA zwingend; keine CI-Erfolgsbehauptung.
- **Extremwetter-Kosten/Missing:** `src/extremeOutlookAssessment.ts` und `src/ExtremeWeatherOutlookPanel.tsx` ersetzen wiederholte Zellraster-Durchläufe durch ein memoisiertes Assessment und verhindern Kontur-/Geometriearbeit bei fehlender 65%-Langfristabdeckung. Die bereits obligatorische `scripts/test-extreme-outlook-modelled-areas-096618.mjs` prüft esbuild-kompilierte echte TS-Logik, Null-vs-Missing, 50%/75% Grenzen, je-Gefahr-Abdeckung und leere Gitter. Warnungen, Schwellen, Modellwerte, Einheit/Glättung, RUC-Codec und Source-Lücken unverändert.
- **Zusätzliche Integrität/A11y aus isoliertem Designaudit-Draft #592:** Exakte SHA-identische stärkere Quellen-/Testblobs vom Head `a21e20d3e1dec1469d26ef20c629c5a4391522fb` für `src/extremeOutlookAssessment.ts`, `src/ExtremeWeatherOutlookPanel.tsx` und zwei bestehende Pflichttests. Nur vollständige, finite, numerische vierstufige Wahrscheinlichkeitsvektoren im Intervall 0–100 gelten als belegte Daten. Null ist gültig, fehlend/null/NaN/Infinity/negative/zu große/falsche Länge sind Missing. Der Interaktionscontainer ist `role="region"` mit dynamischer Beschriftung anstelle des semantisch undurchdringlichen `role="img"`; Tastatur-/Screenreader-Regressionsassertions bleiben erhalten. Eine vollständige physische VoiceOver-/WCAG-Abnahme ist damit nicht bewiesen.
- **RUC-P3 QA aus #591:** Fünf SHA-identische Dateien aus `702f0947ad89125d84f382ac9f78dd49eb3c4f68` ergänzen lesende Original-Logphasen-Parser/Negativtests und bytegleiche CI-Workflow-Spiegel. Kein DWD-GRIB-Inhalt oder 168-h-Verfügbarkeitsdatensatz behauptet; keine neuen Worker-/Producer-/Cloudflare-Rechte und keine P2-/P3-Produktivaktivierung. Vorhandene P1/P5-, 27h-/EPS20-/900MB-/Missing-/Rollback-Anforderungen bleiben bestehen.
- **Versionsspiegel:** v0.9.85.404 in Paket/Lock, Baseline, Vertragsregistry, Web, Worker, Service Worker, iOS-Projekt und Status, iOS-Buildnummer 405 sowie Release Notes und Nutzer-/Technik-Changelog. Kein transportiertes ZIP.
- **Abnahme-/Releasegrenze:** Vollständige Source-/Core-/Heavy-Gates und SHA-gebundenes Review auf dem FINALEN Integrations-Head sind erst nach tatsächlich erfolgreichem CI als bestanden zu melden. Dann ausschließlich MID Agent Source Release Bot → kontrollierter SHA-Merge → serverseitiges ZIP → `install-mid.yml` mit Worker/Pages/Finalize → Stable-Promotion. Web-Simulator ersetzt keine physische iOS-/VoiceOver-Abnahme, keine belegte E2E-Karten-Speedup- oder 168h-RUC-SLO-Aussage.

## MID v0.9.85.403 · 2026-11-01 · RUC P1/P3-Sammelrelease

- **Freigabebasis:** verifizierte v0.9.85.402 auf `main=mid-stable` SHA `1888cb97149855aa8d63f74fecad9c4f245ee02d`, Source-Gate #41324209698 erfolgreich und Installer #41325206572 vollständig erfolgreich mit Core, Heavy, Worker, Pages und Finalize. Fünf aktive Rulesets und 1059 registrierte Pflichtregressionen.
- **Originales P1-Quellmaterial:** Draft PR #586, Head `2a89bd2c7f1f20dad07c1bfd487af8886ed8ec4e`, exakt 3 Fach-/Test-/Workflow-Dateien blobidentisch und auf unveränderter .402-Dateibasis. Der ausschließlich lesende Observer akzeptiert erfolgreiches Watchdog-upstream-`schedule` oder `workflow_run`, fordert weiter `head_branch=main`, Herkunft aus demselben Repository, `conclusion=success`, vorhandenes Pipeline-Flag und Stable/Main/Checkout-SHA-Konsens. Keine Produktionsschreibrechte.
- **Originales P3-Quellmaterial:** Draft PR #587, Head `d764d949710faf4e9ec84b0e1aab9fda25b03ad3`, exakt 4 Fach-/Test-/Workflow-Dateien blobidentisch und disjunkt zu #586. Unveränderter EPS-Writer mit getrennter `time.perf_counter`-Messung für Mitglieder-Packing, `eps_summary` und Summary-Packing; neue AST-/Originalpacker-Testfälle einschließlich Missing, echter 0, Chunk-Grenzen und exakt gleicher Ausgabebytes. Beide kanonischen/aktiven CI-Workflow-Spiegel jeweils bytegleich.
- **Bereits erfolgreiche Fach-QA:** #586 P1/P5-QA #41322736069 und Telemetrie #41322736116, #587 EPS20-Quell-/Produktionspacker-Byteparität #41323676614 und Vitest #41323676702. Diese isolierten Tests sind KEIN Ersatz für die vollständigen neuen SHA-gebundenen Source-PR- und Installer-Gates.
- **Unveränderte Meteorologie:** stündlicher deterministischer +0…+27-h-Kern/20 EPS, native 5-/15-min-Quellen, originales Raster, GRIB2-Bitmap-/Units-/Lead-/Akkumulations-/Missing-Gates, ungeschmälertes Extremwetter- und NoData-Verhalten, unter 900.000.000 Byte Pages-Budget, vorhandener Rollback und amtliche DWD-Warnungen. Keine Aktivierung eines zweiten Producers, der Fast-Lane, alternativer EPS-Quantile oder neuer Worker-/Client-Realtime-Pfade.
- **Offen nach #541:** P1 mindestens 168 h originale, zensierte DWD-Erstverfügbarkeitsdaten; P2 unabhängige +0…+6-h-Fast-Lane samt vollständiger Echtdatenadmission; P3 SHA-identischer 27-h-/EPS20-/542040-Punkte-GRIB-A/B mit CPU-/RAM-/Budgetbelegen; P4 globales CAS-/Fencing-Single-Writer für jede zusätzliche Publikation; P5 tatsächliche Endgeräte-/Widget-/Export-Adoption und 60-Minuten-P95. Weiter `publicationAuthorized=false`, `productionEnabled=false` für Fast-Staging.
- **Versionsspiegel:** v0.9.85.403 in Paket/Lock, MID_BASELINE (1059 Pflichtregressionen unverändert), Vertragsregister, Web-/Service-Worker-/Worker-/iOS-Status, Xcode CURRENT_PROJECT_VERSION 404, Nutzer- und technischem Changelog sowie Releasehinweisen.
- **Release-Grenze:** Dieser Integrationsquellstand ist bis zum Abschluss der Pflichtgates nur ein Kandidat. Freigabe ausschließlich nach Source-PR-Gate auf exaktem Head → kontrollierter SHA-gebundener MID-Bot-Merge → serverseitiges ZIP → `install-mid.yml` mit Worker/Pages/Finalize → erfolgreiche Stable-Promotion. Niemals PR-Completion-Generic-Merge, Direktwrite nach main/mid-stable oder Gate-Umgehung.

## MID v0.9.85.402 · 2026-11-01 · Sammelrelease Designaudit 1.7 + Kartenworkflow

- **Verifizierte Basis:** Stable `v0.9.85.401` @ `00639856b5c1598cbccb837a3b63fbe57cc5d566`, Installer `41319782471` completed/success; fünf aktive Rulesets, 1059 obligatorische Regressionen.
- **SHA-gebundene Quellen:** Audit-Draft PR #580 Head `edda2b400f1dc581da3c443bb3e968381527cab4` (vier Produktions-/Testdateien) und Karten-UX-Draft PR #583 Head `e359aa18dce94f1f4c98816539bc5e01edd43d4c` (vier UI-Dateien). Für alle acht Dateien identische Git-Blob-SHAs übernommen, gegen unveränderte Stable-Dateiblobs geprüft. Historische Drafts unberührt.
- **Fachlich:** `src/dwdWarnings.ts`: fail-closed Aggregation ohne Null-Missing-Verwechslung; zeitkontinuierliche mehrstündige Frost-/Wärme-/Schnee-/Böensignale, echte Nordrichtung vs. Missing. Keine amtliche CAP-/DWD-Warnung geändert. Gezielte Tests im obligatorischen `scripts/test-dwd-warning-markers.mjs` erweitert, nicht verkürzt.
- **Zustandsintegrität:** `src/mapWorkspaceState.ts` schützt unbekannte/kaputte Legacy-JSON-Werte bei `totals→models`-Migration; `scripts/test-c14-map-workspace-098534.mjs` um ausführbare TypeScript-/Storage-Gegenprobe erweitert.
- **Karten/UI:** `App.tsx` viewportabhängiges Vorwärmen, `RadarPanel.tsx` lokale absolute Gültigkeitszeit zusätzlich zur relativen, `UnifiedWeatherMap.tsx` und `MapWorkspace.css` kompakte fachlich vollständige Disclosures, Touch-/Fokusregeln. Keine neuen Daten-/Warn-/RUC-Provider, keine produktiven Workeränderungen außer Versionsspiegel.
- **Extremwetter-Renderkosten (#585):** Originalblobs von Draft-HEAD `8eb408100e24e96c4645e9652b389339c134a088` für `src/extremeOutlookModelledAreas.ts` und den verbindlichen ausführbaren `scripts/test-extreme-outlook-area-rendering-09662.mjs` wurden SHA-identisch integriert. Wiederverwendung nur bei gleicher Datenobjektidentität, Gefahr und Zeitraum; keine veränderte Fachlogik.
- **Karten-CI ohne Testverlust:** Source-Run `41322391419` belegt acht bestandene Heavy-2/3-Browserfälle, unmittelbar darauf 13-min-Timeout. Die vollständigen 24 Fälle werden unverändert auf 9/7/8 Pflicht-Shards neu verteilt, weiterhin mit 20 Zyklen Speicherprobe. Der bestehende verbindliche Sharding-Test prüft Mengenidentität und Disjunktheit. Keine Gates, Tests, Workflow-Timeouts oder Budgets aufgeweicht.
- **Versionskonsistenz:** Paket/Lock, Baseline, Vertragsregister, Web/Worker/SW, iOS-Status, Xcode Build 403, Changelog, Release Notes und Source-of-Truth auf `.402`. 1059 Pflichtprüfungen unverändert.
- **Release-Gates:** Dieser Quell-PR ist bis zum erfolgreichen vollständigen Source-PR-Gate ein Kandidat. Veröffentlichung ausschließlich SHA-Bot-Merge, serverseitiges ZIP, `install-mid.yml`, Worker/Pages/Finalize und erfolgreiche Stable-Promotion. Reale 10s→X-Ladezeit, flächendeckende Provider-GetCapabilities, echte iOS-/VoiceOver-Abnahme und globale WCAG-2.2-AA-Konformität werden nicht beansprucht.
## MID v0.9.85.401 · 2026-11-01 · RUC Data 1.4: authentifizierte Beobachtungsarchivierung und P3-Quantilqualifikation

- **Quelle:** vollständig veröffentlichte Stable v0.9.85.400, main=mid-stable SHA `a6c644fef9762ffad1f4f48a8ddfdf77d4fe2fe7`; Installer #41311115993 erfolgreich inklusive Core/Heavy, Worker, Pages, Finalize. 5 aktive Rulesets, unverändert 1059 Pflichtregressionen. Paralleler ICON-D2-PR #578 bleibt separat, keine Dateien aus diesem PR übernommen.
- **P1/P5:** Zunächst SHA-identische Originale der GitHub-Observer-ZIP-/Run-/Attempt-Verifikatoren und des 168h-Zensur-Collectors aus PR #577 Head `b4f8ca34dd4b432978d661ca7b6ace864d5d97d4` exakt per Git-Blob übernommen; anschließend GitHub-Original-Sammler gegen den 1000-Requests/h-GITHUB_TOKEN-Engpass und den 15-Minuten-Doppeltrigger gehärtet: einmalig paginierte Repo-Artefaktübersicht statt pro Run, Ereignis/Success-priorisierte und ausdrücklich gezählte Duplikatunterdrückung, fehlende/inkonsistente Pagination fail-closed, Downloadbudget <=800, adversarielle End-to-End-Tests. Neue, ausschließlich lesende tägliche Archivierung; read-only Beobachtungs-Fallback ausschließlich nach successful schedule-Event des vertrauenswürdigen Watchdogs auf main. GitHub Run-Success allein ist kein DWD-GRIB-/EPS20-Beweis, fehlende Proben sind keine Nullwerte. Keine Produktiv-SLO-Freigabe.
- **P3:** Inaktiver EPS20/NumPy-2.x-Vektorquantil-Kandidat aus PR #581 Head `2fc42bb84b168b478cb82c88e319c9b042abd7eb` exakt SHA-geprüft übernommen. CI vergleicht gegen die echte Produktionsfunktion `eps_summary` aus dem GitHub-Checkout inklusive byteidentischem `ruc_pack.pack_cell_major` bei synthetischen 1–20 EPS-Mitglieder-Verfügbarkeiten, fehlenden und extremen Werten. `build_ruc_bundle.py` bleibt unverändert; keine reale GRIB-/Full-grid-/CPU-RAM-A/B- oder Endgerätevalidierung erfolgt.
- **Schreibgrenzen:** Unverändertes produktives 27h/20EPS, kein aktiver 0–6h-Publisher oder Consumer, kein neues globales Single-Writer-/CAS-/Fencing, keine Änderung der Worker-/Pages-Meteorologielogik außer synchronen Buildversionsspiegeln. P1 echte 168h-Messung, P2 echte 0–6h-Original-GRIB-Qualifikation, P3 vollständiges DWD-A/B, P4 atomarer Cross-Provider-Writer, P5 DWD→App/Widget/Export P95 sind weiterhin offen. Kein Missing=0, kein offizieller Warn-Ersatz.
- **Release-Gates:** Dieser Text beschreibt den zu prüfenden Quellkandidaten, nicht vorweg eine Stable-Promotion. Nur vollständig grüne Source-PR-Gates am letzten SHA, SHA-gebundener Releasebot, serverseitiges ZIP, install-mid.yml Core/Heavy/Worker/Pages/Finalize und nachgewiesene Stable-Promotion erlauben die Kennzeichnung als veröffentlicht.

## MID v0.9.85.400 · 2026-11-01 · Designaudit 1.6: Forecast-Persistenz, NoData-Visualisierung, Saisonprovenienz

- **Provenienz:** Vorherige Stable v0.9.85.399, `main=mid-stable` SHA `bba6006f50b5c279aebc0c5a40a812dc21c5d500`; #575 Source-PR erfolgreich kontrolliert gemergt, Installer #41305710537 `completed/success` (Core/Heavy, Worker, Pages, Finalize). Fünf Schutzrulesets, 1059 Pflichtregressionen, 38 Vertragsregistereinträge. Neuen Branch `chatgpt/v0.9.85.400-audit16-horizon-nodata` ausschließlich auf dieser Basis eröffnet; parallele RUC/ICON-D2/alte Design-Drafts unangetastet.
- **State-Integrity:** Bislang schrieb `ForecastCockpit.tsx` die gerade gerenderte Ausweichansicht über `useEffect` dauerhaft in `mid:forecastCockpit:activeHorizon`, sobald 14-/7-Tage-Daten ausfielen. Jetzt wird die Nutzerwahl nur bei explizitem Horizontwechsel gespeichert; automatische Ersatzansichten ändern den gespeicherten Wunsch nicht. `restorableForecastHorizon` reaktiviert ihn bei vollständiger Verfügbarkeit, außer eine aktuell gültige externe Navigation hat Vorrang. Gegen Storage-Denial und veraltete/ungültige Keys abgesichert.
- **Meteorologische Linienintegrität:** Beide MiniRibbon-Temperaturkurven verwenden `miniRibbonTemperaturePath` mit getrennten Segmenten bei NaN/Infinity/Missing; keine lineare Überbrückung oder erfundene Temperatur. Achsen nur aus tatsächlich endlichen Werten; fehlende Marker weggelassen, Tooltip „Temperatur nicht verfügbar“. Niederschlagsbalken und physikalische Originalwerte unverändert; es handelt sich um Darstellungslogik, keine Prognosemodifikation.
- **Modellprovenienz:** `LongRangeModelComparison` unterscheidet explizite `ensembleMembers > 1`, exakt `1 Member` und nicht ausgewiesene Memberzahlen, statt bei 0 unbekannten Mitgliedern „Ensemble-Mittel“ zu behaupten. Ensemblegewichtung/Fusion unverändert.
- **Tests und Grenzen:** Bestehender Pflichtregression `test-display-return-states-0985364.mjs` echte esbuild-transpilierte TypeScript-Helfer-Tests hinzugefügt: persistierter Wunsch, verweigerter Speicher, fehlende/wieder verfügbare Horizonte, externe Navigation, fehlende Temperaturwerte, Lückensegmente, korrekte Beschriftungen und Quellverdrahtung. Bestehende 1059 Testeinträge bleiben erhalten. Release erst nach dem vollständigen SHA-gebundenen Source-Bot→ZIP→Installer→Worker/Pages/Finalize→Stable-Pfad; keine behauptete physische iOS-/VoiceOver-Abnahme.
- **Weiterhin offen:** A0–A5 gesamte Browser-/iOS-Geräte-/WCAG-Matrix, WMS Provider-Readbacks, appweite NoData-/Akkumulations-/Farbtokens-/Persistenzprüfung und internationale Zeitzonen-/DST-Grenzen. Issue #523/#508 bleiben offen.

## MID v0.9.85.399 · 2026-11-01 · Designaudit 1.6: Wasserintervall, Modelllinien und Speicherresilienz

- **Provenienz:** verifizierte Stable v0.9.85.398, `main=mid-stable` SHA `adf2a832bd7d66a9bb7c16ec6d9f4dcdedeff855`, vollständiger Installer #41300031208 (`completed/success`); fünf aktive Rulesets und 1059 bestehende obligatorische Regressionstests. Original-Quellblobs `WaterSportsPanel.tsx`, `LongRangeModelComparison.tsx`, `App.tsx` SHA-geprüft. Änderungen nur autorisierter Branch `chatgpt/v0.9.85.399-audit16-data-lines-storage`, Draft PR #575 bis Freigabekriterien erfüllt sind.
- **Meteorologie:** `src/waterPrecipitationAggregation.ts` akzeptiert nur exakt die verlangten 1 bzw. 3 Stunden, äquidistante Unix-Epochzeiten, endliche nichtnegative Zahlen und explizit verfügbare Komponenten. Jede vollständige echte Nullfolge bleibt 0. Fehlende/negative Werte, fehlende Slots, unvollständige oder zeitlich versetzte Gruppen und Überlauf ergeben NaN, der bestehende Mengenrenderer zeigt Missing als „–“. Vier Pfade Niederschlag/Regen/Schauer/Schnee im Wasserwetter nutzen denselben Guard, ohne Wetterwarnungen, Nowcast oder Modellzeitsemantik zu ändern.
- **Visualisierung:** `LongRangeModelComparison.tsx` rendert alle vier Modellsignaturen (`MODEL_DASH_CYCLES`) auch im SVG-Legendensymbol; keine allein farbliche Kurvenzuordnung. `forecastDetailStorage.ts` schützt den alten Tagesdetail-Storage-Read vor Browser-Exceptions, erhält Legacy-Key und die permanent geöffnete Stunden-Detaildarstellung. Der initiale Layoutmodus und das Lesen der Favoritenreihenfolge sind ebenfalls gegen verweigerten Browser-Speicher geschützt, einschließlich Test des echten transpilierbaren Quellcodes.
- **Regression und Grenzen:** Bestehende Pflicht-Tests `scripts/test-water-tide-matrix-081815.mjs` und `scripts/test-display-return-states-0985364.mjs` führen die transpilierte reale TS-Helferlogik mit adversariellen Fällen aus und prüfen die UI-Verdrahtung; kein Inventareintrag entfernt. Lokale isolierte Vorprüfung 32+7 Fälle, **keine** behauptete vollständige Source-/Browser-/Geräte-/iOS-/VoiceOver-Abnahme. Jedes Release benötigt zunächst auf dem endgültigen SHA alle Source-Gate-Checks, dann den kontrollierten MID-Bot, serverseitiges ZIP, `install-mid.yml`, Worker/Pages/Finalize und Stable-Promotion. Bei neuer paralleler Version Konfliktprüfung und fail-closed.

- **RUC-Workflow-Kompatibilitätskorrektur:** Der zusätzliche P1–P5-Evidenzjob war in beiden kanonischen/aktiven Workflow-Spiegeln versehentlich auf **exakt** v0.9.85.398 fest verdrahtet. Der positive Versionsvertrag akzeptiert nun nur eine vierteilige Version **ab** .398, weiterhin mit unveränderter Baseline-/Contract-Version-Synchronität, ≥1059 Pflichtregressionen, byteidentischen Workflow-Spiegeln, unveränderten Native-RUC-Negativtests und dem unveränderten `git diff --exit-code`/sauberem Arbeitsbaum. Keine Abkürzung von SHA-, Veröffentlichungs- oder Datenqualitätsgates; aktuelle PR-Checks müssen auf dem finalen SHA neu erfolgreich sein.

- **Ausdrücklich weiterhin offen:** vollständige A0–A5-Geräte-/Kontrast-/Tastatur-/Screenreader-Matrix, numerische Originalklassen der WMS-Provider, echte Provider-Readbacks, appweite Parameter-/Legendenpersistenz sowie umfassende meteorologische NoData-Parität. Keine pauschale Erledigung von #523 oder #508.

## MID v0.9.85.398 · 2026-11-01 · RUC P1–P5: explizite Messstatus-Evidenz und inaktive native DWD-Fast-Qualifikation

- Ausgangsbasis: vollständige v0.9.85.397 Stable-Promotion main=mid-stable `9627f7a6fc1d71a4ca328f7c3f257c0fac7d0362` nach Installer #41296481176 (Core/Heavy/Worker/Pages/Finalize success), fünf aktive Rulesets und 1059 Pflichtregressionen.
- SHA-gebundene selektive Übernahme von genau 22 RUC-Fach-/Test-/Workflow-Dateien aus gesichertem Draft PR #571 Head `ab327404f6f38aa12629242a4001c39fb2263386`, Git-Blob-Abgleich einzeln erfolgreich. .397-NoData-Korrektur aus PR #572 einschließlich `src/extremeEvidenceNumeric.ts` exakt erhalten.
- P1: Beobachter erfasst unabhängig von grünem CI-Status tatsächliche DWD-Verzeichnisbeobachtungen, Pages-/Worker-Poll und Release-Drift-Skips. Bei älterem Stable-Checkout funktioniert ein konservativer Null-Evidenz-Fallback ohne das noch unveröffentlichte neue Python-Modul; missing bleibt unbekannt. Zusätzlich 168h links-/rechts-/intervallzensierter Stichproben-Audit.
- P2: ausschließliche manuelle, inaktive EPS-unabhängige native +0…+6h-DWD-Original-GRIB-Qualifikation (12 Stundenfelder, native 5-Minuten-TOT_PREC und 15-Minuten-CAPE/CIN, Gitter, Bitmaps, Zeiten, Einheiten, Accumulationsfenster, SHA und Site-Budget). Lokales Pointer-Staging ist `publicationAuthorized=false`, `productionEnabled=false`, `realtimeConsumerEnabled=false`. Kein Remote-Publisher/Pages/R2/Worker-/App-Switch.
- P3: Wall-/Job-/Stage-Zeiten bleiben unabhängig nachvollziehbar; nicht zugeordnete Verzögerungen werden nicht als Dekodier- oder Downloadkosten behauptet. Identische Original-GRIB-SHA-A/B-Probe mit CPU/RAM fehlt.
- P4: Pure Shadow-Qualifikation sperrt Release-Drift, doppelte, ältere und aktiv konkurrierende DWD-Produzenten sowie falsche Inventar-Hashes. Ein produktiver gemeinsamer, authentifizierter Single-Flight/CAS/Fencing-Publisher ist bewusst nicht enthalten.
- P5: zensierte Lesemessungen und echte fehlende Samples, aber kein tatsächlicher DWD-Erstpublikationszeitstempel, keine nachgewiesene Endgeräte-Adoption und kein 168h-P95≤60min-SLO.
- Offline-RUC-P1–P5-QA: auf PR-Head `128bce9527cb46885e17b60803317bf46699f652` 112 von 112 Python-Tests fachlich erfolgreich, Vitest success. Die bisherigen Gesamt-QA-Läufe scheiterten ausschließlich korrekt an noch fehlenden .398-Changelog-Spiegeln; vollständige Source-PR-/Installer-/Production-Gates sind daher noch erforderlich. Keine amtlichen Warnungen, meteorologische Originalwerte oder 27h-/EPS20-Pipeline geändert.

## MID v0.9.85.397 · 2026-11-01 · MID-Designaudit #523 P0: Extreme-Datenlücken in RUC/EPS-Beleganzeige

- Ausgangsbasis v0.9.85.396, `main=mid-stable` SHA `d32201fbb541f4c5189e549c1250de0964bd61d1`; vollständiger Installer #41292437081 erfolgreich. Fünf aktive Rulesets, andere D2-/RUC-/ECMWF-/Design-Drafts unverändert.
- Schwere Darstellungsursache: `Number(metric.foo)||0` sowie `Number.isFinite(Number(null))` verwandelten fehlende RUC-/EPS-/Extremwetterwerte in künstliche 0 (Böen/Schnee/Eis/CAPE/CIN/Niederschlagsakkumulation/Geländehöhen). `terrainLabel` behandelte unbekannte Klassifikation pauschal als Tiefland. Unbekannte Zeitfenster wurden als 1/6h etikettiert.
- `src/extremeEvidenceNumeric.ts` stellt reine fachliche Guards bereit: endliche numerische Werte, echte 0, signiertes CIN, nichtnegative physikalische Mengen, positive Akkumulationszeit und null-/bool-/blank-/NaN-/Infinity-Fail-Closed. Die gesamte Metrikenanzeige in `src/ExtremeWeatherOutlookPanel.tsx` verwendet den Guard; RUC-EPS-Evidenz ohne reale Eingabe wird nicht mehr als Nullfeld ausgegeben. Keine Modell-/Warnungslogik verändert, keine Extremglättung, keine Fake-Zeitscheiben.
- Die bestehende Pflichtregression `scripts/test-extreme-outlook-startup-format-09661.mjs` transpiliert die neue reale Helperquelle und prüft adversariell Missing/0, Altschemata, CIN, -1 mm, RUC-6h/15min sowie unbekannte Akkumulationsdauer. Inventar 1059/1059 unverändert, 38 Fachverträge.
- Synchronisierte neue Version v0.9.85.397 inklusive package/lockfile/baseline, source-of-truth, Vertrag-/SW-/Worker-/Public-Version, iOS Build 398, Nutzer-/Technikchangelog. Vollständige Source-/Core-/Heavy-/Build-/Worker-/Pages-/Finalize-/Stable-Gates verpflichtend; kein reales iOS-/VoiceOver-Geräteergebnis allein durch CI.

## MID v0.9.85.396 · 2026-11-01 · Designaudit A3/A4: echter WMS-Kartenexport und dauerhafte Widget-/Karteneinstellungen

- Quellbasis: vollständig veröffentlichtes v0.9.85.395 `main=mid-stable` SHA `bda6e60d37f2cac31b36e9993f5d6c045355d6ed`, PR #564, Installer #41288744774 erfolgreich, fünf aktive Rulesets. Neun Fach-/Testdateien aus gesichertem Draft PR #566 Head `1fa4e35ff970c7bb0dc68c737aec3123c2330932` selektiv als originale Git-Blob-SHAs übernommen; alle sechs schon existierenden Dateien sind zwischen .394-Draftbasis und .395 Stable SHA-identisch; keine Rebase-/Force-Push-/Reset-Operation.
- A3: Original-GetMap (WMS 1.1.1, EPSG:3857, identische Layer-/Style-/Run-/Time-/Elevation-Semantik wie gerenderte Kacheln) für realen MapLibre-Viewport. Original-GetLegendGraphic zwingend, PNG mit Originalanbieterbild und Metadaten. Auf DWD/GeoMet-allowlist-geschützten Worker begrenzt. 1100x900 bzw. 990000 Providerpixel, 12 MB/Image, 15 Sekunden Timeout, ungültige Bildgröße/Projektion/Termin/Stil/fehlende Legende fail closed. Keine numerischen Schätzungen, Warnmontage, Basiskarte, Radar, Satellit oder erfundenes SVG. Missing ist nicht Null.
- A4 Widgetgenerator: zehn echten Nutzeraktionen schreiben Legacy-v5-Store sofort, kein Mount-/Unmount-Effect mit stale Defaults. Cross-Tab/Same-Tab-Sync, false/0/Migration, blockierter Storage und URL-only-Export geschützt. Aktuelle Widgetdaten und Renderer unverändert.
- A3 klassisches Kartenpanel: Modell, Produkt, Druck-/Höhenlevel, Deckkraft und Kartenbasis aus bestehendem v2-Store bei wirklicher Nutzeraktion sofort dauerhaft; kein überschreibender Mount-Effect, Cross-Tab-Event. Nur wirklich numerisches Level gültig, null/missing niemals 0.
- Bereits obligatorische Tests `scripts/test-unified-map-layers-0985167.mjs` (dynamisches WMS-BBOX-/Style-/Time-/Provider-/Fehler- und Classic-Storage-Verfahren) und `scripts/test-widget-ensemble-selector-098414.mjs` (echte Legacy-v5-Funktionen in VM mit Migration/false/Storage-Denial/Cross-Tab) adversariell erweitert. 1059/1059 ursprüngliche Pflichtregressionen, 38 Vertragsregistereinträge ungekürzt. iOS-Build 397.
- Auf diesem SHA erforderliche Freigabe: Source-Gate inklusive kompletter Core/Heavy/Browser/Native/Build/Tests → SHA-Bot-Merge → serverseitiges Release-ZIP → `install-mid.yml` mit Worker/Pages/Finalize → Stable-Promotion. Kein fremdes PR Completion Landing, kein direkter Hauptbranch-Schreibzugriff.
- Fachlich **noch separat**: echte datierte DWD/ECCC-GetMap-/Legend-Readbacks pro Layer/Stil, numerisch barrierefreie Originalklassentabellen, 320–1920px Light/Dark und reale iOS-/VoiceOver-Gerätematrix, A1/A2/A5 übergreifende Vollprüfung. CI-Browserprüfungen sind nicht iOS-/VoiceOver-Abnahme.
- Parallele ICON-D2-/RUC-/INCA-/ECMWF-, Schnee- und KNMI-Entwicklung sowie meteorologische Modell-/Warnzeit- und Datenpipeline nicht verändert.

# MID v0.9.85.395 – Einstellungen bewahren, alte Wartungspfade sicher entfernen

- Im Klimabereich bleibt die Wahl für die Verwendung des Favoritennamens beim Ortswechsel erhalten. Bereits ausdrücklich ausgeschaltete Optionen werden nicht versehentlich wieder aktiviert.
- Der Saisonmodellvergleich speichert die Auswahl von Temperatur oder Niederschlag unmittelbar; verschiedene Ansichten und Browser-Tabs sehen konsistente Einstellungen.
- Routenwetter-Modi und Saisonparameter kennzeichnen ihre Auswahl für Tastatur und Screenreader eindeutiger.
- Veraltete, eigenständig schreibende Analytics-/Installationsworkflows und reine KNMI-Experiment-/Diagnoseworkflows werden aus dem aktiven Repository entfernt. Die genutzten KNMI-Prognosewege bleiben bestehen.
- Die Branch-Bereinigung prüft Schutzstatus vor weiteren Aktionen; ungesicherte oder nicht eindeutig freigegebene Branches werden nicht gelöscht.
- RUC-Vollgebiet, Vorhersagedaten, amtliche Warnungen und Modellläufe werden durch diesen Build nicht verändert.

Technischer Nachweis/Scope: 33 SHA-übertragene Cleanup-/UI-/Testdateien aus PR #543/#563. Neue Version .395 inklusive App, iOS-Build 396, Worker-/Service-Worker-/Registry-Spiegel. Rollout ausschließlich über vollständige MID Source-PR-/Installer-Gates. Keine Freigabe der RUC-Vollgebietskarten ohne unabhängige DWD-Originaldatenqualifikation.

## MID v0.9.85.394 · 2026-11-01 · RUC P3 Production Pipeline / #541

- Frische Source-of-Truth vor Vorbereitung: v0.9.85.393, main=mid-stable SHA `43cb36c07531b8d93418061aa1f075df5f6ac0fc`, fünf aktive Rulesets, vorherige .393-Source und Installer nachweislich erfolgreich. Parallele RUC-Drafts #542/#551/#554/#560/#561 bleiben unverändert; aus dem bereits gesicherten isolierten P3-Entwicklungsstand #557 nur fachlich relevante Code/Test-/QA-Blobs übernommen.
- `tools/ruc/fetch_and_build_ruc.py`: EPS20-Vorprüfung, 12 deterministische Kernfelder, erforderliche 5-/15-min-Rapid-Felder und 27h-Builder weiterhin mit originalem vollständigem WMO-/DWD-Header-, ValidTime-, Bitmap-, Gitter-, Akkumulations- und Realwertvertrag. Nur unabhängige optionale Feldverzeichnisse mit bis zu zwei selbstständigen Sessions parallel; N bisherige Gesamt-Downloadslots bleibt N, pro Gruppe höchstens floor(N/2). Fehlerhaftes optionales Staging vollständig löschen.
- Pro GRIB-Downloadthread eigene Requests.Session mit HTTP-Keep-Alive, keine Session-Weitergabe in andere Threads. `download_one` außerhalb des Pools unverändert möglich; Worker-Verbindungen auch beim Fehler schließen. Keine zusätzlichen DWD-Abfragen, Cron-/Cloudflare-Trigger, fremden Services oder Secrets.
- `RUC_OPTIONAL_STAGE` und `RUC_P3_PHASES`: getrennte reale Messpunkte; Download-/Stage-, Native-Builder- und Gesamtdauer nicht als identisch darstellen. Optionaler P3-Benchmark braucht echte identische DWD-Inputs, CPU/RAM/Byte-SHA-Zeugen vor behaupteter messbarer Verbesserung.
- In bereits bestehende RUC-Python-QA und verbindlichen JS-Native-Cadence-Test eingebundene adversarielle Unit-/Thread-/HTTP-/Partial-GRIB-/Cadence-Regressionen. Frühere CI-Ergebnisse vom alten #557 SHA gelten nicht für diesen Source-Head. Vollständiger 1.059-Test-Source-Gate + Installer/Core/Heavy/Worker/Pages/Finalize/Stable zwingend.
- Nicht durch diesen Release aktiviert: isolierte 0–6h-Fast-Lane mit Consumer-Parität, 168h-P1-Statistik, single-flight P4 oder garantierte 60min-P95. Dazu Issue #541.

## MID v0.9.85.392 · 2026-11-01 · Designaudit #523: WMS-Legenden und transparentes Exportverhalten

- Verifizierte Ausgangsbasis: veröffentlicht v0.9.85.391, `main=mid-stable` SHA `79b3a8cb995f780c863d6f4b1762155f80e09a15`, fünf aktive Rulesets; Source-Gate #41275254803 und Installer #41276158578 erfolgreich.
- Beiden Kartenansichten gemeinsam genutzte `WmsProviderLegend` erweitert um Originalbild-Link mit 44px-Touchziel, Tastaturfokus und `target=_blank rel=noopener noreferrer`; ausschließlich zuvor allowlist-geprüfte Proxy-URL.
- Provider-Bildfehler an die konkrete Bild-URL gebunden, nicht an globale Fail-Flags; andere Produkt-/Stilbilder werden nicht durch alte Fehler blockiert.
- Kennzeichnung der Bitmap als nicht vollständig numerisch barrierefrei und der weiterhin fehlenden qualifizierten WMS-PNG-/SVG-Kartenexporte. Native Raster-/Cloudexporte bleiben unverändert, keine aus Bildpixeln geschätzten Klassen oder amtlichen Warnfarben.
- Fachlich geprüft: Der bereits bestehende Worker übersetzt `layers/styles` aus der allowlist-geprüften MID-Proxyroute bei `GetLegendGraphic` zu singulärem `layer/style` für DWD/ECCC. Die ECCC-GeoMet-Dokumentation verlangt explizit `STYLE` im Singular. Die bestehende Pflichtregression `test-unified-map-layers-0985167.mjs` erhält positive Schutzassertionen; keine Änderung am produktiven Workerrouting außer erforderlichem Versionsspiegel.
- Alle 1059 Testeinträge in beiden Baselineinventaren, 38 Contract-Indexeinträge und die ursprüngliche Source-Historie bleiben erhalten. iOS-Build 393; vollständige Source-/Installer-/Worker-/Pages-/Finalize-/Stable-Gates erforderlich.
- **Nicht abgenommen:** Live-Provider-Readbacks je Layer/Stil, GetMap-basierte WMS-Exportparität, numerische Accessible-Tabellen, echte Browser-/iOS-/VoiceOver-/Viewport-Prüfungen. RUC-Full-Domain-Draft #555 nicht verändert.

## MID v0.9.85.391 · 2026-11-01 · A3 Originalfarblegenden für Wetterkarten beider Ansichten

### CI-Korrektur zum .391-Source-Gate

- Source-PR #553, erster Head `3dcde596b5cf8c34fb6244bcc2d157194afd9f56`: Heavy-Native-Map #41274814990 scheiterte reproduzierbar beim esbuild-Browsercheck (`No matching export in WmsProviderLegend.tsx for import wmsProviderLegendUrl`). Ursache waren zwei Module, deren Namen sich allein durch Groß-/Kleinschreibung unterschieden. Fehler ist **nicht** meteorologisch und wurde nicht durch reduzierte Tests verdeckt.
- Helfer in eindeutig benanntes `src/wmsLegendUrl.ts` verschoben; veraltete nur-Case-unterschiedliche Datei aus dem Tree gelöscht, beide UI-Importe und bereits verpflichtenden Regressionstest aktualisiert. Der Test verankert ausdrücklich den eindeutigen Importpfad. Erneute Source-/Browser-/Installer-Abnahme auf neuem Head ist zwingend; alle 1059 Pflichtregressionen bleiben erhalten.

- Shared WMS-Legenden-Styles liegen nun direkt an der gemeinsamen Komponente statt im nur bei UnifiedWeatherMap geladenen Stylesheet; dadurch auch im klassischen Karten-Entrypoint zuverlässig verfügbar und per Pflichtregression geprüft.
- Live-Stable v0.9.85.390 @ `8a886b3695ca0ae6ae94e7c18b1bfeb790ddb0a2`, PR #550, Source-Gate #41244176018 und Installer #41245171750 vollständig success (Core, Heavy, Worker, Pages, Stable). Fünf Repository-Rulesets weiterhin aktiv.
- Entkoppelte Migration der fachlichen Draft-Arbeit aus #552 @ `5cbfa528680fbd0a23e07d63d039df4e80f7eecc` auf aktuellen veröffentlichten Code; .390-ValidTime-/INIT-/Level-Gate und Tests bleiben unverändert erhalten. Alte Draft-Branchhistorie bleibt gesichert.
- WMS-`GetLegendGraphic` über vorhandene allowlist-geschützte DWD-/ECCC-Proxyroute; kein fremder Proxy, kein neuer Dienst, keine künstlichen Grenzwerte. Responsives 44px-Disclosure, lazy Bild, expliziter Fehlerstatus, Light/Dark und keine Warnstufenverwechslung.
- Unified und Legacy Wetterkarten prüfen dieselbe Modell-/Stil-/Kartendatenidentität; Legende erscheint erst nach bestätigten Tiles und wird beim Kontextwechsel ausgeblendet.
- Bestehender verpflichtender Regressionstest mit echter URL-Builder-Ausführung und negativen Layer-/Provider-/Stylefällen erweitert. Beide vollständigen Inventare bleiben bei **1059**; vollständige Source-/Installer-Browser-/Worker-/Pages-Gates weiterhin erforderlich. Reale iOS-/VoiceOver-/Provider-Readbacks separat offen.

## MID v0.9.85.390 · 2026-10-31 · Designaudit A3: einheitliche WMS-Run/ValidTime/Level-Integrität

- Veröffentlichte Stable-Basis: v0.9.85.389 `main=mid-stable` @ `6e449be3baf13e9c33ec206864189dd4b580d482`; erfolgreicher Source-PR #549, Installer #41240348162 mit vollständigen Core-/Heavy-/Worker-/Pages-/Finalisierungs-Gates.
- Vergleich mit Legacy `weatherMapFrameReady` zeigt, dass Unified WMS bisher unzureichend auf Katalogfehler, Lauf-/Zeitverfügbarkeit und verfügbare Druckflächen prüfte. Identische kanonische Validierung nun im zentralen `wmsActive`-Pfad; kein unerlaubter Rückfall auf anderes Modell.
- Bereits verpflichtender Test `scripts/test-unified-map-layers-0985167.mjs` um tatsächliche transpilierte Negativfälle und Renderverkabelung ergänzt. Keine Pflichtregression entfernt: 1059/1059.
- RUC, DWD/WMO-Warnungen, Zeit-/Niederschlags-/Quellenverträge, Worker-Produktivcode und Releasekonfiguration fachlich unverändert; sämtliche Versionsspiegel werden synchronisiert.
- Freigabe nur nach unverändertem Source-PR-Gate → SHA-Bot → ZIP → Installer → Worker/Pages → Stable. Browser-/Geräte-/VoiceOver-Checks separat evidenzpflichtig.

## MID v0.9.85.389 · 2026-10-31 · Designaudit #523: Karten-Navigationszustand bewahren

- Nach vollständig freigegebener v0.9.85.388 @ `11c56661b371bf9c0da49d0836fcb548d46bf46f` mit Installer #41236833866 werden die zwei fachlichen Blobs aus Draft #547 @ `a73b9009172e0f778604314ecca7ea8bed53d8f1` auf tatsächlich aktuelle Stable neu verankert; keine Rebase-/Branchlöschung der Parallelvorhaben.
- Der historische Wetterkarten-Einstieg darf nicht mehr implizit `icon-d2-precipitation-totals` auswählen. Ausdrücklicher Summeneinstieg und Legacy-Migration bleiben erhalten, bestehende Modell-/Parameterpräferenzen sind vorrangig.
- Bereits verpflichtender Regressionstest erhält ausgeführte TS-Handler-/State-Negativfälle. Beide Pflichtlisten bleiben vollständig bei 1059/1059; keine Tests entfernt oder abgeschwächt.
- WMO-/DWD-Warnungen, Datenlücken, RUC 27h/20-EPS und Produktions-Workflows unverändert. Echte Browser-/iOS-/VoiceOver-Abnahme weiterhin getrennt zu dokumentieren; nur bestehender SHA-gebundener Releasepfad.

## MID v0.9.85.388 · 2026-10-31 · RUC-Verfügbarkeit und Pages-/Worker-Readback beobachten

- Gesicherte Releasebasis: v0.9.85.387 main=mid-stable SHA 83d5c1d9e7c0ce082242e71aec855d8319340169; Installer #41232575766 success, fünf aktive Rulesets.
- Ein ausschließlich lesender DWD-/Pages-/Worker-Beobachtungsworkflow mit 15-min-Best-Effort-Schedule, identischen CI- und aktiven YAML-Blobs und 14-tägigen, eindeutigen Artefakten wird versioniert installiert.
- 12 Datei-Blobs mit DWD-Directory-Observer, Readback, 168h-Auswertung, Shadow-Gates und fünf Python-Negativtests sind byteidentisch vom geprüften PR #542 SHA a75716f567e4cf321cfc648de7ba1c8375ea3368 übernommen; keine Übernahme der unveröffentlichten Fast-Publisher-Sourcen oder unautorisierten P4-Testdatei.
- Beobachtete Verfügbarkeit ist intervallzensiert; fehlende Daten bleiben unbekannt. Das neue Diagnoserelease beweist weder vollständige DWD-GRIB-/EPS20-Verfügbarkeit noch 0–6h-Fast-Lane, App-/Widget-/Export-Refresh, GH/Cloudflare-Single-Flight oder ≤60-min-P95.
- Nur das etablierte Source-PR-Gate→SHA-Bot→serverseitiges Release-ZIP→Installer→Worker/Pages→Stable darf veröffentlichen. Bestehender 27h/20-EPS-Lauf und DWD-Warnungen bleiben geschützt.

## MID v0.9.85.387 – Designaudit A3: 3h-/Tagesdaten und PoP-NoData

- Basis: verifizierte v0.9.85.386, main=mid-stable @ b6eba7bea8a42bc78841955b3eeac8a392510d12, Installer #41218322192 erfolgreich. RUC-Draft #542 (.387) und KNMI-/Cleanup-Draft #543 bleiben unangetastet; vor ihrer eigenen Integration muss die dann neue Stable-/Versionseinordnung geprüft werden.
- A3-Tagesdetail: 3h-Niederschlagsmengen und -PoP nicht als 0 bei fehlenden Beiträgen; getrennte SVG-Wahrscheinlichkeitssegmente, nur gültige Punkte und geprüfte Stunden-/Tageslabels.
- `completePrecipitationWindowCoverage` qualifiziert bei der Ersatz-Tagesaggregation echte lokale Zeitfenster mit vollständigen Epochengrenzen, einschließlich 23-/25h-Zeitumstellung. Tageswerte aus dem kanonischen Produkt haben Vorrang.
- Neuer Pflichttest `scripts/test-design-a3-precipitation-integrity-0985387.mjs` mit adversariellen NoData-/Intervall-/DST- und Consumer-Checks. Beide bestehende Regressionsinventare unverändert erhalten und von 1058 auf 1059 erweitert.
- WMO/DWD-Piktogramme, amtliche Warnungen, Modelle/RUC, Layout- und Nutzerzustand, Karten und bestehende Release- und Sicherheitsgates unverändert. Browser-/iOS-/VoiceOver-Abnahme und Issue #523 bleiben offen; Veröffentlichung nur nach vollständiger realer SHA-Gatekette.

## MID v0.9.85.386 – Niederschlags-NoData-Integrität und konsolidierter Designaudit A1/A2

- Verifizierte Stable-Quelle v0.9.85.385 SHA `1ade69f46b9bf77e9adaa360353ffacc7a0b967c` und Source-PR #540. Parallele Drafts #538, #542 und #543 erhalten; keine Fremdänderungen übernommen.
- Kurzfrist-/24h-Profil, 7d-Stundenkurve und kompakte 14d-Ensemblevisualisierung führen nicht verfügbare Niederschlagsmengen/PoP als explizite Missing-Zustände statt synthetische Nullen. 24h-Aggregation verlangt lückenlose, nicht überlappende Originalintervalle. SVG-Wahrscheinlichkeitskurven überbrücken fehlende Werte nicht.
- Gemeinsamer typisierter `src/precipitationAvailability.ts`-Pfad und neue Regression `scripts/test-precipitation-availability-0985386.mjs` inklusive null/NaN/Infinity, Nullwert, PoP-Grenzen, Zeitlücken/Overlap und UI-Markierung.
- `MID_BASELINE.json`: ursprüngliche 1057 erforderlichen Tests aus .385 verlustfrei + 1 neuer = 1058 Einträge in beiden verpflichtenden Inventaren. `scripts/test-revision-parallel-matrix-0985385.mjs` und alle 10 isolierten Revisionsjobs bleiben erhalten.
- Versionsspiegel `package*.json`, `MID_IOS_STATUS.json`, `contracts/index.json`, `index.html`, `src/version.ts`, `public/version.json`, PWA-Caches, Worker-Dateien und iOS-Xcode-Buildversion synchron auf .386 aktualisiert. Alter Source-of-Truth-/Changelog-Verlauf bleibt vollständig im Anhang.
- Vollständige Browser-/iOS-Abnahme und die regulären Source-/Installer-/Stable-Gates sind releasepflichtig; automatisierte Testresultate werden ausschließlich nach echten GitHub-Checks als bestanden vermerkt.

## MID v0.9.85.383 – Modellgenauer RUC-Pages-/Worker-Abgleich statt Mindestzahlen

- Grundlage: verifizierte MID v0.9.85.382, `main=mid-stable` @ `e539d4b0db4e84587af3aeef4fbc5c32e160142c`, Source #535 und Installer 41174796571 success. Fünf Rulesets aktiv.
- Bisher kontrollierte `check_ruc_health.py` nur timeCount >=4, pointCount >=1 und epsMemberCount >=2 trotz vollständigerer SHA-gebundener Metadaten; auch der Pages-Pointer prüfte keine identische Raster-/Member-/Zeitachse. Die bisherigen Decode-/Codec-/SHA-Pflichtprüfungen waren und bleiben zusätzlich vorhanden.
- Neu: typisierter, vollständiger, UTC-stündlicher 0..+27h-Manifestvertrag in allen vier Zeitachsen, exakt 20 Ensemblemitglieder, positive Punktzahl und identische native Grid-Dimension. Öffentlicher Pages-Readback gleicht zusätzlich die gesamte Gittermetadatenstruktur ab; Worker-Health muss exakte int-Werte statt bloßer Mindestzahlen liefern. Bestehende CDN/Worker-Recovery-Retries bleiben begrenzt, falsche Inhalte fail-closed.
- Adversarielle Tests für fehlende/duplizierte/verschobene Prognoseschritte, 19/21 Mitglieder, Geometriedrift, Bool/Strings statt ints, fremden Lauf, dauerhaft kaputte Pages/Worker und erst nach Retry konvergierte Werte im bestehenden `tools/ruc/test_ruc_health_check.py`.
- Die bisherigen normalen Source-Gates und beide RUC-Workflow-Spiegel nehmen diesen Test als Pflicht vor Publikation auf. Keine neuen Secrets, keine Änderungen an Wetterwerten, keine Überschreibung amtlicher Warnungen.
- Technischer Nachweis `docs/implementation/MID_RUC_HEALTH_MANIFEST_PARITY_383.md`. Änderung erst nach vollständiger Source-PR-Gate → Bot → Server-ZIP → Installer → Worker/Pages → Stable vollständig veröffentlicht; bis dahin nur Kandidat.

## MID v0.9.85.382 – Echtformatprüfung des EPS-Inventars vor großen RUC-Downloads

- Ausgangsbasis v0.9.85.381, `main=mid-stable` @ `f91696cb3468730a4b4473c5ff1cc86b0ab57869`, fünf aktive GitHub-Rulesets und vollständiger Vorgängerinstaller.
- RUC-Lauf 41171508327: DWD 04Z am 31.10.2026 unvollständig (EPS +19h ohne zehn Member), MID fiel auf 03Z zurück. Dies belegt die Lücke, nicht die generelle Ursache jedes Versorgungsproblems.
- `fetch_and_build_ruc.py` staged EPS zuerst und validiert native ecCodes-Header (Modell-Lauf/Parameter/ValidTime/Member 1..20 für 0..27h), bevor deterministische, schnelle und optionale Felder heruntergeladen werden. Vollständiger nachgelagerter EPS-/Det-/Bitmap-/Grid-/NoData-/Codec-Prüfpfad bleibt bestehen.
- `test_fetch_resilience.py` ergänzt Negativtests, die fehlende Member, Duplikate, fremde IDs und die frühzeitige Ablehnung prüfen. Die bisherige frühe Deterministikprüfung bleibt erhalten. Keine künstlichen Werte oder unsicheren Fallbacks.
- Nachweis `docs/implementation/MID_RUC_EPS_EARLY_PREFLIGHT_382.md`. Zeitgewinn, DWD-Verfügbarkeit und produktive Frische sind erst nach echten Runs messbar; bis Source-PR-Gate, Bot, ZIP, Installer, Worker, Pages und Stable-Promotion nur unveröffentlichter Kandidat.
- Andere Phasen von Issue #526 – geschützter produktiver Signaturlauf und echte A/B-Gleichwertigkeit – werden hier nicht frei- oder kurzgeschaltet.

## MID v0.9.85.381 – Phase 1/4: parallelisierungsbewusste CI-Messung

- Vollständig freigegebene Ausgangsbasis v0.9.85.380: `main=mid-stable` @ `e6d70e1104bee5980ac5153fc99f59775756014e`, Installer 41123191600 success, alle Core-/Heavy-, Worker-/Pages-/Stable-Gates und fünf aktive Rulesets bestätigt.
- `tools/ci/release-phase-observation.mjs` ist ein neuer reiner Diagnoseadapter für tatsächliche GitHub-Job-/Stepintervalle. Selektive, konservative Klassen: Queue, Setup, npm, Build, Core, Heavy, SHA-Bot, Paket, Worker, Pages, Stable. Kein fingiertes Zeitintervall für ausgelassene, rückwärts laufende oder unbekannte Zeitstempel. Namenänderungen führen zu „nicht beobachtet“ statt zu unkontrolliertem Raten.
- Überlappende Jobintervalle werden für **Wall-Time vereinigt**, Runnerzeit separat summiert, die reine Spannweite inklusive Lücken als dritte Größe geführt. Retry-Dubletten anhand derselben Identität/Start-/Endzeit nur einmal erfasst; echte frühere Versuche bleiben sichtbar. Core/Heavy enthalten jeweils ihre Setup-/Buildzeit: Phasensummen sind keine End-to-End-Releasezeit.
- `tools/ci/release-timing.mjs` behält sämtliche bisherigen per-Workflow- und per-Run-Messungen und ergänzt eine nicht freigabewirksame phasenweise P50/P95-Auswertung einschließlich gezählter gültiger, fehlender und unbeobachteter Stichproben pro Workflow. JSON-Report enthält die neue `phaseDiagnostics`-Sektion.
- `tools/ci/release-phase-observation.test.mjs` liefert adversarielle Unit-/Semantiktests zu Parallelität, ungültigen/fehlenden Zeitstempeln, Skips, Retry-Dubletten, echtem 0-s-Intervall, unterschiedlichen Jobkategorien, unvollständiger Stichprobe und Autorisierungsfreiheit. Alle Tests werden über die bestehende Pflichtregression `scripts/test-release-timing-0985376.mjs` ausgeführt, die bereits im normalen MID-Regressionensatz registriert ist.
- Keine aktiven Workflow-/CI-/Release-, Token-, Cloudflare- oder Branchenrechte geändert. Versionen/Lock, Baseline, Vertragsregister, Web/PWA, Worker und iOS-Build 382 konsistent. Weiterhin keine A/B-Produktionsgleichwertigkeitsfreigabe für Artefakt-Reuse; Issue #526 bleibt offen. `docs/implementation/MID_CICD_PHASE_OBSERVATION_381.md` enthält die Prüfkriterien.
- Veröffentlichung ausschließlich durch Source-PR-Gate → kontrollierten SHA-Bot → Server-ZIP → `install-mid.yml` → Worker/Pages → Stable, keine Sonder- oder Direktintegration.

## MID v0.9.85.380 – Independent protected Source-Signature verification

- Basis: vollständig freigegebenes `main=mid-stable` v0.9.85.379 @ `c4fd1c79d0b7272b7998c79cd88d445b5681e81d`, Source PR #532, Installer 41118131439 mit allen Core/Heavy, Worker, Pages und Stable erfolgreich.
- `ci/github/workflows/attested-source-qualification.yml` und synchroner `.github`-Mirror erhalten nach dem minimal privilegierten geschützten Signierer einen zweiten **nur lesenden** Verifier-Job. Er besitzt `contents:read`, `actions:read`, `attestations:read`, `pull-requests:read`; ausschließlich der ursprüngliche Signierer erhält `id-token:write`/`attestations:write`.
- Neues `tools/ci/verify-protected-source-pilot.mjs`: SHA-/Run-/Attempt-gebundener GitHub-Artefaktdownload aus demselben geschützten Workflow, einziges kanonisches JSON-Subject, echtes `gh attestation verify` mit Repo/Signer/Commit/Ref und `--deny-self-hosted-runners` ohne akzeptiertes Fremdbundle; Sigstore-Zertifikat, SLSA-Subject, Original-SHA256 und frische Source-PR-/Run-/Job-/Stable-Gegenprobe müssen übereinstimmen. Bei Fehler oder Drift stets fail-closed.
- `tools/ci/verify-protected-source-pilot.test.mjs` adversariell über den weiterhin verpflichtenden Einstieg `scripts/test-build-parity-0985377.mjs` importiert; keine bestehende Prüfung entfernt oder abgeschwächt.
- Vollständige `v0.9.85.380`-Spiegel für Paket/Lock, Baseline/Vertragsregister, HTML/PWA/SW, Webversion, Worker, iOS-Build 381, Nutzer-/Technik-Changelog und Release Notes. Keine meteorologische Produktlogik verändert.
- Signierte Beobachtung ist **kein** attestierter Build und darf niemals `releaseAuthorized` oder `reuseAuthorized` freigeben. Reale manuelle geschützte Producer-/Verifier-Läufe und identische-Source-Tree-A/B-Produktionsäquivalenz noch offen, Issue #526 bleibt offen. Vollständige Beleg- und Negativgrenzen: `docs/implementation/MID_PROTECTED_SIGNATURE_VERIFICATION_380.md`.
- Veröffentlichung ausschließlich über vollständigen MID Source-PR-Gate → SHA-Bot → Server-ZIP → Installer → Worker/Pages → Stable. Bis zu erfolgreich bestandenen Gates Kandidat, keine Releasebehauptung.

## MID v0.9.85.379 – Protected Source-Attestation Pilot (qualifizierte CI-Ausweitung)

- Freigegebene Ausgangsbasis `main=mid-stable` v0.9.85.378 @ `745ee5945fd90a11614400016efb78965da08d71`; Installer 41106636347 success mit kompletter Worker/Pages/Stable-Abnahme.
- Selektive SHA-gesicherte Integration der neun qualifizierten Dateien aus Draft #530 @ `b043b9348171f0b2af2cbbd6b6f5bc4f963a8881`, mit unverändertem Original-Draft und neuem autorisierten `chatgpt/*`-Sourcebranch.
- `tools/ci/attested-reuse-policy.mjs`, `source-run-observation.mjs` und neue `protected-source-attestation.mjs` trennen unverbindliche signierte Claims von unabhängig authentifizierten GitHub-Fakten; Source-PR-Nummer, ursprüngliche Base- und Head-SHA, Run-/Attempt und alle zwölf Pflicht-Gatejobs werden erneut geprüft. Optionales Gate darf nur bei explizitem Ergebnis fehlen.
- Neue rein manuell auf dem geschützten `main` startbare Workflowquelle `attested-source-qualification.yml` einschließlich exakt gespiegelt gepinntem Actions/attest v4.2.2; isolierte Job-Berechtigungen `contents:read`, `id-token:write`, `attestations:write`, keine Release-Credentials, kein PR-Checkout und kein Produktiv-Reuse.
- Eigene Schutztests im obligatorischen vorhandenen Paritätsregressionseinstieg, unabhängiger Doppelbuild, SHA- und Konfigurationsnachweis; vollständiger Source-PR-/Installer-/Worker-/Pages-/Stable-Gate bleibt Pflicht. Kein Signaturbeleg als Ersatz für ein Quell-/Produktivgate.
- Ergebnisgrenze: Das Beobachtungsschema `mid.protected-source-observation.v1` ist **nicht** das vollqualifizierte `mid.attested-source-evidence.v1`. Ohne reale Sigstore-Verifikation und identische Byte-/Environment-/Gate-A/B-Abnahme sind `releaseAuthorized`/`reuseAuthorized` immer `false`. Issue #526 bleibt offen.
- Release-Status: Sourcekandidat bis vollständige verpflichtende CI/Installer/Stable-Kette; vor Erfolg nicht als veröffentlicht ausgeben.

## MID v0.9.85.378 – Diagramm-, Farb- und NoData-Konsolidierung

- Verifizierte Ausgangsbasis `main=mid-stable` v0.9.85.377 @ `44f5d02b0374b275e423e43233addff91d4eeb82`. Exakte Blob-SHAs der acht vorhandenen Fach-/CSS-/Vertragsdateien sind gegenüber dem Ausgangspunkt von Draft PR #524 (.373) unverändert. Keine Übernahme alter Versions-/Release-Spiegel, kein Rebase/Reset von #524.
- Selektive fachliche Integration aus PR #524: `src/App.tsx`, `src/ForecastCockpit.tsx`, `src/EnsemblePanel.tsx`, `src/ensembleCumulativeDisplay.ts`, `src/parameterLineStyle.ts`, `src/styles-src/00-foundation.css`, `src/styles-src/30-modern.css` sowie zentraler Farb-/Linienvertrag.
- 24h und 7d: zentral definierte, farbunabhängig unterscheidbare Linienmuster; bestehende konkurrierende SVG-Präsentationsattribute beseitigt; Legenden-/Tooltipmarker und tatsächliche Diagrammfarben verbunden. Dynamische Temperaturfarbe erhält Vorrang gegenüber generischem Inline-Stroke.
- 14d: keine Null-Fälschung aus Missing/NaN im kumulierten Niederschlag; unabhängige Ensemble-Quartile/Mittel und tatsächlicher Niederschlagswert gesondert; fehlende Wind/Klima/Best-Match-Werte nicht quer über Lücken verbunden.
- Zwei neue obligatorische Regressionen: `scripts/test-appwide-line-semantics-0985374.mjs`, `scripts/test-ensemble-cumulative-gaps-0985374.mjs`; bestehende Farbregression aktualisiert statt abgeschwächt. Gemeinsamer Vertrag `MID_PARAMETER_COLOR_CONTRACT.md` ergänzt.
- Versionspiegel v0.9.85.378: Web, PWA, Worker/Worker-Mirror, iOS Build 379, Lockfile, Baseline, Registry, Benutzer- und technischer Changelog. Kein anderer meteorologischer Daten- oder API-Vertrag, keine amtlichen Warnungen, keine RUC-Kompression/Modelle geändert.
- Parallel-Drafts #530 (Attestierung, read-only) und #524 (Original-Design-Draft) bleiben unangetastet. Source-PR nicht als Release melden, solange nicht SHA-Bot, serverseitiges ZIP, Installer mit Core/Heavy und Worker-/Pages-/Stable-Gates vollständig success sind. Nachweis: `docs/design/MID_PARAMETER_LINE_AUDIT_0.9.85.378.md`.

## MID v0.9.85.377 · 30.10.2026 · Buildparität und Retry-Diagnose

- Zwei getrennt gesicherte Kandidaten #527/#528 auf freigegebener .376-Basis zu einem vollständig neu geprüften Quellbaum integrieren; eine Version, keine doppelte Veröffentlichung.
- Source: optionale Remote-npm-Cache-Abhängigkeit nach belegtem 605–606s-Account-Egress-Stall explizit deaktiviert; Node/Lockfile/npm ci/Build/Audits/alle Gates unverändert.
- Zwei unabhängige, exakt SHA-gebundene npm-Installationen/Builds; vollständige Ausgabeinventare und Fingerprints; keine neuen Deployment- oder Attestierungsrechte, keine automatische Artefaktübernahme.
- Read-only-Timing mit allen Versuchen, ausgeführten Runnersekunden, Abbruch-/Timeoutzählung, Schutz vor gemischten Rerun-Beobachtungen und automatischem Audit nach erfolgreichem Installer.
- Source-Bot queue:max bei unverändertem SHA-Merge-/ZIP-/Installerpfad. Bestehende Installer-Supersession bewusst unverändert; P0 darf keine unnötige Queue abwarten.
- Vollständige Tests/GitHub-Abnahme für den kombinierten Head separat nachweisen. Echtmessreihe, signierte Attestierung und unabhängige A/B-Freigabe in #526 weiterhin offen.

## MID v0.9.85.376 · 30.10.2026 · Vollständiger Installer-Core parallel und sichere Draft-Bündelplanung

- Sourcekandidat von bestätigtem main=mid-stable `.373` @ `05798c4134431a5fb0455ef5f71441b4a7051e38`; unabhängiger Design-Draft #524 bleibt erhalten. .375-Branch beim Abgleich identisch mit Stable. Kein ZIP im Source-PR.
- Vier disjunkte vollständige Installer-Core-Shards auf demselben event-/SHA-/Manifest-/Byte-gebundenen Snapshot; Build/Audit/Worker-Syntax/iOS und sechs Heavy-Gruppen bleiben unverändert Pflicht. Aggregator verlangt alle vier Verifikationsgruppen erfolgreich. Normativer ergänzter Vertrag `MID_CHATGPT_GITHUB_CONTRACT.md`.
- Read-only-Planung ausdrücklich für Draft-Kandidaten, ohne Ready-/Merge-Aktion: autorisierte Branchfamilie, exakte Basis/Head, vollständige Dateiliste einschließlich Rename-Quelle, erneute Metadaten-/Ref-Prüfung. Provenienzpilot bindet jeden Job an ID, Head und Run-Attempt und prüft nach dem Lesen erneut. Keine produktive Testergebnis- oder Buildartefaktwiederverwendung.
- Fokussierte CI-/Diagnose-/Provenienztests lokal 33/33; reproduzierbare npm-Installation, Types/Produktionsbuild und Installer-/Security-/RUC-/Workflow-Sentinels erfolgreich. Vollständige lokale Core-/GitHub-Source-/Installer-/Pages-/Worker-/Stable-Abnahme separat nachweisen. Keine Laufzeitgarantie aus dem bisherigen Core-Pilot abgeleitet; Issue #526 bleibt bis attestierter A/B-Qualifikation offen.

## MID v0.9.85.373 · 30.10.2026 · Source-SHA-gebundene RUC-Wiederverwendung

- **Aktuelle freigegebene Basis**: main=mid-stable=v0.9.85.372 @ `e8e8c60ecc36447dbd21cde239fac06d58314a7d`; #521 vollständig gemergt; Installer [41037391196](https://github.com/MeteoMartini/MID/actions/runs/41037391196) einschließlich Core, Heavy, Worker, Pages und Stable erfolgreich. Fünf Rulesets aktiv; offene Parallel-Drafts #425/#449/#480/#513 und Dependabot #474 nicht überschrieben.
- **Tatsächlich aufgedeckter RUC-Produktionsfehler**: Preprocessing #41040092625 erhielt `reuse_run_id=41036330432` (alter Event-SHA .371 `76fef22a9f10af06faa0566a01a93df150f2cdf9`). `prepared_snapshot.admit` lehnte korrekt ab: `prepared data contract incompatible with current Stable`. .372 veränderte WMS-Layercode in `worker-src/20-composite-models.js`, einer expliziten Eingabedatei des unveränderten RUC-Kompatibilitätshashs. Kein unqualifizierter Snapshot veröffentlicht.
- **Quellenfix**: `tools/release/ruc_resume_preflight.py` prüft bei durch Workflow und Artifact-Proof authentifiziertem Wiederverwendungskandidaten SHA-Identität, Git-Ancestry, vollständige relevante Quelldifferenz und die beiden ausdrücklich erlaubten Versionsnormalisierungen (Worker-Version im `00-core-observations.js`, Root-Versionsfelder im npm-Lockfile). Die Pfadmatrix entspricht dem unveränderten `tools/ruc/prepared_snapshot.py:compatibility`; jede sonstige Worker-/RUC-/ForecastFusion-/Pipeline-/Dependency-Änderung blockiert die Wiederverwendung konservativ. Git-/Netz-/Provenienzunsicherheit bedeutet **keine** Wiederverwendung und reguläre Neuaufbereitung, nicht Datenfreigabe.
- `tools/release/select_ruc_resume.py` ruft die Prüfung **vor einem Replay-Dispatch** auf; ein bestätigter inkompatibler neuer Kandidat sperrt ältere Produzenten und löst durch leeren `reuse_run_id` den bestehenden regulären Rebuild aus. Bestehende Limitierungen (10 Kandidaten,90min,18min Cooldown, SHA, Provenienz, Immutable Artifact, tatsächlicher Freshness-/900-MB-/Codec-/Pages-/Worker-/Stable-Zulasser) unverändert.
- Negative und positive isolierte Git-Historienprüfungen in `test_select_ruc_resume.py`; Source-/Workflow-Regression `test-ruc-resume-watchdog-0985370.mjs` ergänzt. Kein Test abgeschwächt, beide Baselineinventare mit 1050 Core-Fällen unverändert. Repräsentativer lokaler SHA-/Git-Normalisierungs-Negativtest bestanden; vollständige GitHub Source-/Installer-Gates weiterhin erforderlich.
- Version `v0.9.85.373`, Worker-/PWA-/iOS-Build 374, Registry, Baseline sowie externer/interner Changelog synchron; kein automatischer Ausweis einer echten RUC-Publikation ohne separaten datenbezogenen Betriebsnachweis. Keine fachliche Gewichtung, Warnung, Modelldatenberechnung, Decoder-, Radar- oder Publikationsregel geändert.

## MID v0.9.85.372 · 30.10.2026 · echte WMS-Kartenverfügbarkeit und sichere Kombinationen

- Verifizierte Stable-Basis .371 `76fef22a9f10af06faa0566a01a93df150f2cdf9`; offene PRs #513/#474/#480/#449/#425 berücksichtigt.
- Worker-Katalog-Endpunkt `weather-map-catalog`: exakt ein DWD- und ein ECCC-GetCapabilities-Read je Antwort; feste WEATHER_MAP_LAYER_CONFIG-Allowlist; Status `listed`/`absent`, numerische Zeit-, Lauf- und Ebenenanzahlen, geprüfte Anbieterprovenienz; Provider-/Netzfehler bleiben `unchecked`, dabei wird ein unvollständiger Status vollständig verworfen.
- Beide Kartenmodelle `WeatherMapsPanel` und `UnifiedWeatherMap` nutzen dieselbe veröffentlichte Capabilities-Matrix. Eine confirmed-absent- oder ohne bestätigten Zeit-/Run-/Höhenwert unbrauchbare WMS-Kombination wird bei neuen Wahlen herausgenommen, ohne bestehende gespeicherte Auswahl/andere native Raster zu vernichten. Synoptik- und Wolkenkombinationen nur bei geladenen Originalkatalogen anbieten.
- `weatherMapFrameReady` verhindert WMS-GetMap ohne Layer+Zeit+Lauf+Ebenenbindung. Zeitabhängiger NowCastELEC benötigt den echten valid-time-Schritt, aber keine fiktive deterministische INIT. Statische Gewitter-/Warnpolygone bleiben ohne Wetterereignis legitim leer. Worker-Routen, Aggregat und Alias bytegleich; GeoMet-Attribution korrigiert.
- Neuer reproduzierbarer Production-Worker-Contract `test-map-combination-availability-0985372.mjs` mit isolierten Original-GetCapabilities-Mocks: positive/negative Layer, unbekannte Anbieterfehler, valid/invalid Time/Run/Elevation, 2 UI-Matrizen, Native-/Preferences-Schutz. Beide vollständigen Inventare jetzt 1050 Tests. `scripts/audit-weather-map-live.mjs` für späteren expliziten externen GetMap-PNG-Read-only-Nachweis mit hartem Budget; ein PNG allein belegt nicht nichttransparente Daten.
- `v0.9.85.372` Versionsspiegel, iOS-Buildcounter 373, Worker, PWA, Registry, Nutzer-/interner Changelog und Baseline synchron. Ohne erfolgreiche tatsächliche CI-, Worker-/Pages-, Installer- und Stable-Gates nicht als veröffentlicht zu melden. Keine heimlichen Modell-/Warn-/Raster-/Zeitachsenänderungen.

## MID v0.9.85.371 · 30.10.2026 · Open-Meteo BOM ACCESS-G deterministisch außer Betrieb

- Offizielle Provenienz: seit 26.06.2025 18 UTC keine aktuellen BOM ACCESS-G-Läufe. Trotz weiter gelisteter API-ID keine aktuelle deterministische Quelle.
- Den aktiven Kandidaten aus kanonischem Forecast-Katalog und generiertem weather.ts entfernt; Worker-Fusionsmodell und globalIds in kanonischer Quelle, worker.js und metar-proxy.js entfernt.
- Bestehende globale Ersatzmodelle, Best-Match-Anker, 20er-Modellbudget, Unabhängigkeitsgruppen, RUC-/Warn- und Missing-Data-Semantik unverändert.
- BOM Ensemble und BOM ACCESS-S2 saisonal explizit bewahrt; keine historischen Prognosen verändert.
- Zwei veraltete Modellfamilien-Assertions angepasst; neue tatsächliche Worker-Auswahl-Regression test-openmeteo-bom-retirement-0985371.mjs für DE/AU/US, Katalog-/Mirror-Parität und Saison/Ensemble; 1049 Tests in beiden Inventaren.
- Versions-/PWA-/iOS-/Worker-/Lockfile-/Baseline-/Registry-/Nutzer-Changelog synchron auf 0.9.85.371, iOS Build 372. Source-Gates und Release nicht als erfolgreich bezeichnen, bis GitHub die Schritte belegt.

## MID v0.9.85.366 · 29.10.2026 · Karteneinstellungen und Ensemble-Cachevertrag

- Legacy-Composite-Layer-Mirror kann den kanonischen v3-Record nicht mehr überstimmen. Fehlender 2. Write, falsche/fehlende Werte und vollständiger Snapshot müssen die bewusste Auswahl `false` erhalten.
- Radar und UnifiedMap verwenden den letzten dauerhaften Zustand beim Patchen und aktualisieren mehrere Instanzen/Tabs. DWD-Warngebietsdarstellung verwirft nicht die Benutzerpräferenz.
- Sieben konkrete Ensemble-UI-Schlüssel vom vergänglichen Forecast-Cache getrennt, direkte Durable-Speicherung, Backup-/Quota-Events.
- Neuer tatsächlicher Produktionshelper-Test `test-composite-settings-durability-0985366.mjs` in beiden vollständigen Regressioninventaren; Browser-/Build-/Native-/Release-Prüfungen bleiben Pflicht.
- Fachlich offene 250m-Auswahl bei Nichtverfügbarkeit, vollständige Geräteabnahme sowie Schnee-/RUC-Qualifikation nicht als geschlossen deklarieren.
- Buildversion `v0.9.85.366`, iOS Buildcounter 367, synchronisierte Worker-/PWA-/Registry-/Baseline-Spiegel. Nur SHA-Bot mit Installer/Pages/Stable darf veröffentlichen.

## MID v0.9.85.361 · 29.10.2026 · transaktionale Security-Diagnostik

- Exklusiv reservierte Erstfehler-Berichte mit sofort gültigem JSON-Zwischenstatus und atomarem Endbericht.
- Sicherer Fehler-Fallback bei Collector-Rejection, zyklischem/undefiniertem oder nicht-objektförmigem Payload ohne Übernahme vertraulicher Fehlermeldungen.
- Parallele 32-Writer-, In-Flight-, Symlink-, Datei-0600-/Screenshot-/Timing-Regressionsprüfungen; keine Pflichtprüfung deaktiviert.
- Der WebKit-320px-Kaltstart-CSS-Paritätsblocker wird mit echten stabilen Frame-Snapshots und präziser DOM-Diagnose statt gelockerter Parität überprüft; die gesamte Browser-/Pixelmatrix bleibt Pflicht.
- Versionsspiegel für App, Worker, Service Worker, iOS und Registry synchronisiert. Freigabe ausschließlich über den MID-Releasebot.

## MID v0.9.85.355 · 2026-10-28 · Bergwetter-Installer-Recovery

- SHA-verifizierter Stable-.353-Nachfolger mit übernommenem .354-Source-Tree, ohne rotes Release-ZIP.
- Echte CDP-Hit-Geometrie nach Layoutframes, Browserfehlersicherung, Persistenz und erneute Einheitenauswahl.
- ZIP-Git-Merge-Provenienzprüfung mit fünf Git-Laufzeitproben; rootfreie Release-Notizen.
- Push-Settings-Chromium hat bei echtem Startausfall maximal einen weiteren frischen Port-0-/Profilversuch (2 × 12 s) mit klarer Diagnose; vollständige 12-Fälle-UI-Prüfung bleibt zwingend.
- Alte meteorologische, Accessibility-, Responsive-, Browser- und Sicherheitsprüfungen bleiben Pflicht.
- Ausschließlich kompletter geschützter MID-Releaseweg.

## MID v0.9.85.335 · 2026-10-25 · Fusion resume

Begrenzte Auswahlmarkierung im Tagesdiagramm beseitigt den im bestehenden Heavy-Browsergate reproduzierten epoch-Absturz. Nachholen versäumter Fusionsabrufe, begrenzter Fehlerbackoff, Lifecycle-Cleanup und explizite fehlende Übernahmeverifikation. Wetterwerte und Workerkern unverändert.

## MID v0.9.85.316 · 2026-10-23 · Parameterlinien, Rasterextreme und runde Windskalen

- Verifizierte Basis main = mid-stable = 48692e0cd168302f1dd035f5d79200a4812a00a6 / 0.9.85.314. PR449 reserviert .315 für unabhängige DWD-Geometrieinventur; keine Duplikation oder Aktivierung dieses WIP.
- Stückweise lineare Konturen auf jedem gültigen Rasterquad, deterministische Dreiecksteilung, keine räumliche Ausdünnung oder Glättung; fehlende Ecke sperrt den Quad. Wettercodes sind keine skalare Größe. Originalwerte bleiben unverändert.
- Gemeinsame nativeScalarAnnotations für UnifiedWeatherMap, NativeModelMap und native PNG/SVG; bestehende adaptive MSLP-Isobaren und T/H-Konvention bleiben erhalten. Min/Max beziehen sich ausdrücklich auf das veröffentlichte Raster, nicht auf volle native DWD-Gebietsabdeckung.
- niceWindRange wählt 1/2/5-Teilstriche nach Anzeigeumrechnung; Koordinaten und Spitzen bleiben kanonisch in Knoten. Pflichtregression test-map-scalar-annotations-0985316.mjs.

## MID v0.9.85.314 · 2026-10-23 · Konsolidierte Konturen und strenger Domänenauditor

- Nutzerfreigabe: geprüfte Konturen-/Exportkorrekturen #445 und ausschließlich lesender Auditor #447 gemeinsam veröffentlichen; Vollgebiet #446 bleibt ausdrücklich separat offen.
- Basis main=mid-stable 7cabe4ca23d86dbf3aadccdb03aa3fc0dbf20885 (.311); keine alten Versionen, Draft-Workflows oder ungeprüften Dependency-Upgrades übernommen.
- Vollständiges vorhandenes Druckraster statt Sechser-Ausdünnung, gemeinsame verlustfreie Linienzüge in Karten und nativen/Wolken-Wetter-SVG-/PNG-Exporten.
- Auditor prüft volle Quellzeitachse, SHA, Einheiten, Intervalle und Missing-Masken; 17 Fälle im bestehenden Pflicht-Test registriert. Keine produktive Crop- oder Datenquellenänderung.
- Release ausschließlich nach erneuten kombinierten Source-/RUC-/Heavy-/Browser-/Installer-/Worker-/Pages-Gates und Stable-Promotion. #433/#432/#425 sowie nicht qualifizierte Dependency-PRs bleiben separat; keine ECMWF- oder Open-Meteo-RUC-Aktivierung.

## MID v0.9.85.311 · 2026-10-22 · Gepaarte Prognoseverifikation

- Basis main=mid-stable 8e829d2e1d474f4beb10937194773d65e12c69fe (.309). Parallel-PR #443 reserviert .310 und bleibt unberührt.
- Reproduzierter Fehler: asymmetrisch fehlende optionale Parameter erzeugen bei identischen gemeinsamen Fehlern einen scheinbaren MID-Vorteil. Report verglich außerdem Gesamtarchive mit unterschiedlicher Falldeckung.
- Gemeinsame Parametermaske pro archiviertem Stand, Tagesmittel vor Gesamtmittel, identische Fallmenge für Anzeige, adaptive Obergrenze und Aktivierungsentscheidung. Keine neue Kalibrierung und keine rückwirkende Änderung gespeicherter Prognosen.
- Neuer dynamischer Pflicht-Test test-paired-verification-0985311.mjs; Altcode rot, Korrektur grün. Release erst nach vollständigen Source-/Installer-/Pages-/Stable-Gates.

## MID v0.9.85.309 · 2026-10-21 · Extremwetter-Polygon-Ersatzmodus (Source-Kandidat)

- Reproduzierter P1-GeoJSON-Geometriefehler: fünf verschachtelte Originalringe ergaben vier statt drei MultiPolygon-Teile (Insel doppelt), sechs Ringe vier statt drei. Der neue ausschließlich direkte Hole→Island-Rekursionspfad erhält jeden Ring exakt einmal und normalisiert Außen- und Lochorientierung. Bestehende Pflichtregression test-extreme-outlook-geodata-096614 wurde um Ringtiefen 1–6, Multipolygonanzahl, Duplikatfreiheit, Ringanzahl und Winding erweitert. Kein Schluss auf WebGL-Pixel, Live-Ursache oder amtliche Warnungen.

- Basis: erfolgreich nach Pages/Worker promovierter Stable-SHA b57f07081a2b92ae763af9c909aa3f65b9e211ac, v0.9.85.307; paralleler blockierter RUC-PR #440 v0.9.85.308 und Draft #433 unberührt.
- Die maplibre-gl@6.7.0-GeoJSON-Flächen werden wie bisher zuerst verwendet. Ein zeitversetzter Source-/Layer-/Render-Check mit map.isSourceLoaded, queryRenderedFeatures und erfassten Workerfehlern aktiviert bei tatsächlichem Fehlen einen Canvas-Ersatz aus derselben Konturserie.
- Canvas zeichnet dieselben I1–I4-Konturen inklusive Schraffur, Inseln und Löchern; kann aber im Ersatzmodus über gezeichneten OSM-Ortsnamen liegen. Zustand wird optisch und per role=status deklariert. Nicht als amtliche Warnung ausgeben.
- Unterdrückte synchronen Fehler bei der nativen Installation dürfen nicht länger zu alleinstehenden Gefahrenlabels führen. Wiederherstellung über map.idle erneut prüfen, Eventlistener beim Wechsel freigeben.
- Neue Pflichtregression scripts/test-extreme-outlook-render-fallback-0985309.mjs, bestehende Label-/Canvas-/GeoJSON-Tests fachlich angepasst; Version, Worker, Service Worker, iOS und Verträge synchronisiert.
- **Freigabesperre:** Hier ist noch kein realer Browser-Pixel-/Viewport-/WKWebView-Nachweis vorhanden. Ein neuer Source-PR bleibt bis zum tatsächlichen Source-Gate, reproduzierbarer Polygon-Pixelprüfung, betroffener Heavy-Regression und dem regulären Installer/Pages/Worker/Stable-Pfad Draft. Kein öffentlicher Release durch diesen Commit allein.

## MID v0.9.85.307 · 2026-10-21 · P1-Datenintegrität

- Stable-Basis .306 a1f40fb42ea45bd3c695583a49a1310e0fc853fc verifiziert; parallele ECMWF-/RUC-Drafts unangetastet; vorhandene Workflownamen und Freigabepfade unverändert.
- Szenario-Ausreißerfilter und 6%-Sichtbarkeitsschwelle entfernt; RADOLAN nicht mehr bei 250 mm hart begrenzt, ungültige Daten uncovered.
- Lokale Güte- und Lernverifikation: nur measured/private-sensor, >=18h Deckung und Qualität >=0,55 aus ausschließlich Messquellen, jeweils >=12 Temperatur-/Niederschlagsproben; kein beobachtetes Regime rückwirkend als Ausgabe-Regime.
- Drei dynamische Pflichtregressionen zum gesamten Bestand hinzugefügt (1013); Source-, Installer-, Worker-, Pages-Gates noch nachzuweisen. Historische Archive bleiben erhalten; keine empirische 90-Tage- oder iOS-Gerätefreigabe behauptet.

## MID v0.9.85.296 · 2026-10-19 · Langfrist-Ausblick und Wiederherstellung

- PR419: Cache-/Workerpfad unabhängig von optionalem Direktmodul, Schema-Recovery und nutzergetriggerter Reload nach Modulfehler; keine meteorologische Änderung.
- Vier Source-Blocker ohne Gate-/Budgetausnahme repariert; dynamische Loaderprüfung und 24 tatsächliche Browserfälle, Types/Build und 1001/1001 lokal grün. Nachweis docs/implementation/MID_C36_EXTREME_RECOVERY_0.9.85.296.md.

## MID v0.9.85.295 · 2026-10-18 · Prägnante 7-Tage-Wettertexte

- Der 7-Tage-Trend priorisiert signifikanten Niederschlag, Schnee, Gewitter, markante Temperaturen und DWD-nahe Modellhinweise. Allgemeine Trocken- und Wolkenfloskeln wurden zurückgedrängt.
- Wetterphasen, markante Hinweise und Folgenächte werden über eine einheitliche chronologische Auswahl auf höchstens drei kurze Aussagen begrenzt. Doppeltes Gewitterworting bei gleichem Tag wird unterdrückt.
- Keine Veränderung an meteorologischen Prognosewerten, Warnquellen, Akkumulationszeiträumen oder Datenlücken; fehlende Daten bleiben unbekannt.
- Neue dynamische Pflichtregression test-seven-day-significant-timeline-0985295.mjs; Source- und Release-Gates noch ausstehend.
- Baseline v0.9.85.294 auf b0cf607c45746239ed6246ba1e473ee41877a96d.

## MID v0.9.85.294 · 2026-10-18 · Aktuell-Skybar mit exakten Sonnenübergängen

- MID-C36: optionale solare Aufteilung im zeitgebundenen Skybar-Adapter; segmentinterne Epochengrenzen vor dem Viewport-Clipping erhalten.
- Dynamische Regression für 12h-Geometrie, angeschnittene Sonnenübergänge, Missing, Wolkenschwellen, 15/60-min-Slots, DST und unveränderten Niederschlag erweitert.
- Basis main=mid-stable=5ad8be1fbafbcbfbc9d1aeda451b3e642a947617 (.293). #374 bleibt wegen klassischer Detailachse und weiterer Gesamtabnahme offen.

# MID v0.9.85.292 · Barcelona-Warnungsgebiete und CAP-Revision (Source-PR-Kandidat)

- Verifizierte Stable/main-Basis fbe9c758599928f4b5ba776de670505018750dbb, v0.9.85.291. Ursprung: gesicherter .290 Draft #412 @ 3ba91d51ae883df4b38c59b2fad09634994a01fe, unverändert erhalten. .291-API-NoData-Code und Regression beibehalten.
- #411: Eindeutige Warngebietsnamen/AEMET-Gemeinde Barcelona 08019 → Litoral 690804, CAP-Polygon/-Kreis zuerst, Schweregrad im semantischen Dubletten-Schlüssel, bei belegter CAP-ID/Referenz neue Ausgabezeit vor Beschreibungslänge. Eng begrenzter AEMET-Ortshinweis ohne behauptetes offizielles Gemeindegrenzenpolygon.
- Worker-End-to-End-Test scripts/test-barcelona-warning-area-dedupe-0985290.mjs mit **synthetischen** 26 Fällen, VIS-Fallback, CAP-Polygonen/Nachbargebieten/verschiedenen Zeitfenstern und Schweregraden sowie kürzerem amtlichem Update zu längerer Vorversion. Neuer Pflichttest neben unverändertem .291-API-NoData-Test.
- Grenzen: aktuelle echte 26-Warnungen-Liste nicht als Live-API-Objekte verfügbar; MeteoAlarm VIS-BBox ist keine exakte Geometrie, Cancel-/mehrsprachige CAP-Identität noch nicht abschließend abgenommen. Issue #411 bleibt offen. Keine physische iOS-/VoiceOver-Abnahme behauptet.
- Version- und Buildspiegel 0.9.85.292 synchronisiert; Source-, Build-, Security-, Worker-/Pages- und Stable-Gates noch ausstehend. Nur SHA-gebundener MID Source-PR → Release-Bot → serverseitiges ZIP → Installer → Worker/Pages → Stable, kein Direktmerge.

## MID v0.9.85.291 · 2026-10-18 · API-NoData-Verträge

- Reproduzierten Number(null/blank/boolean)-Fehler im API-Prüfer behoben; Min/Max-Unterschied erfordert gültiges Wertepaar.
- Echte CLI-Pflicht-/Optional-Providerfixtures und Serienregression in beiden Baseline-Inventaren. Open-Meteo #405 getrennt dokumentiert; keine unbestätigte Modellfreigabe oder historische Korrektur.

# MID v0.9.85.289 · C39 Kurzfristtext und mobile Kartenfläche (Source-PR-Kandidat)

- Verifizierte Basis: main=mid-stable=e54c237b2d21859638cf3b21b50a842d2f0f222d, v0.9.85.288; vollständiger Installer #39111144520 mit Worker/Pages und Stable-Promotion erfolgreich. Keine parallel offenen Produkt-PRs bei Start; bestehende Dependabot-PRs nicht verändert.
- #408: `ForecastCockpit.shortTermPointSummary` verwendet nun ausschließlich die `profileDisplayPoints`, die auch die 24-h-Kurve (`chartSourcePoints`) zeichnen. Der abweichende versteckte native 15-min-Anfang entfällt. Gemeinsamer Helper `src/shortTermSignificantBrief.ts` bewahrt absolute Epoch-Intervalle, unterscheidet laufenden/voraussichtlichen Niederschlag, bildet ein mögliches Ende nur mit zwei lückenlos gültigen Trockenintervallen und meldet Windböen nur >50 km/h als MID-Hinweis (nicht amtliche DWD-Warnung). Missing/NaN sind niemals 0 oder Trockenbeweis.
- #409: Auf schmalen Next-Karten werden Status- und Modell-Kachel einzeilig auf maximal 44 px begrenzt, abgeschnittene Namen mit CSS-Ellipse behandelt; geschlossene Legende ist ein kompakter 44-px-Schalter. Größere Layer-Beschreibung wird beim geschlossenen Untermenü ausgeblendet. Copyright-Attribution, volle Zeitsteuerung, vollständige Statusdetails und Karten-Interaktionen bleiben erhalten. Kein großflächiger Neubau des MapLibre-/Leaflet-Systems.
- Verbindliche neue Regression `scripts/test-short-term-brief-chart-0985289.mjs` in beiden Baseline-Regressionslisten: Build des echten TS-Helpers, unbekannte/gültige Niederschlagsintervalle, onset/off, 14/26/28/34 kt, 23-/25h-DST, fehlender Datenstatus, Quelltext- und CSS-Integrität. Echte komplette Source-/Browser-/Heavy-/Security-/iOS-/Worker-/Pages-Gates stehen zum Zeitpunkt dieses Kandidaten ausdrücklich aus.
- Versionsspiegel v0.9.85.289 in Package/Lock, Worker, Web/PWA, iOS, Baseline und Registry synchronisiert. Keine unabhängigen Open-Meteo-Modellfreigaben oder Replit-Handoffs. Replit bleibt wegen ungeklärter Admin-/Bypass-Rechte blockiert.
- Release ausschließlich Source-PR-Gate → SHA-gebundener Release Bot → ZIP aus Repository-Serverstand → install-mid.yml → erforderliche Worker/Pages-Gates → Stable. Browser-Screenshots sind keine physische WKWebView-/VoiceOver-Abnahme.

# MID v0.9.85.288 · Sichtweiten-NoData-Integrität (Source-PR-Kandidat)

- Verifizierte freigegebene Basis: main=mid-stable=ffcc37e37c6a143ff73a714494c3e9c52eea987c (v0.9.85.287), Installer #39108469858 und alle vorgeschriebenen Worker-/Pages-Gates erfolgreich; keine parallelen offenen MID-Produkt-PRs beim Entwicklungsstart.
- #405: `src/visibilityPhenomena.ts` konvertierte beim `finite(value)`-Helper `null`, Blanktext und weitere nicht-numerische Werte mittels `Number(value)` zu 0. Dadurch konnten bei unmittelbaren Caller-Eingaben eine 0-m-Sicht bzw. 0-%-Luftfeuchte erfunden und Nebel/Dunst abgeleitet werden. Zentrale `mapHours`-Maskierung war teilweise geschützt; kein unbewiesener App-Live-Screenshotfehler behauptet.
- Neue strikte finite-Grenze: ausschließlich endliche Nummern und nichtleere numerische Strings akzeptieren; echte Null, finite Sicht-gegen-Modell-Konflikte, WMO/DWD-Nebel-/Dunstschwellen und vertrauenswürdiges METAR unverändert erhalten.
- Pflichtregression `scripts/test-visibility-nodata-0985288.mjs` importiert den echten TypeScript-Classifier via esbuild und deckt NoData, echte Null, Modell-Wettercodes, Luftfeuchte/Taupunkt, Berichtskonflikte und Worker/JSON-null-Caching ab; beide Baseline-Inventare ergänzt.
- Quellstand, alle Versionsspiegel, externe/interne Changelogs und Implementierung dokumentiert: `docs/implementation/MID_C39_VISIBILITY_NODATA_0.9.85.288.md`. RUC-Kompression, neue native ICON-Modelle und amtliche Warnungen werden nicht geändert.
- Keine lokale/gerätebezogene Prüfung nach diesem Integrationscommit behaupten; verpflichtende vollständige Source-/Heavy-/Browser-/Worker-/Pages-/Native-Hüllen- und Installer-Gates stehen aus. Ein Changelog allein ist kein Release-Nachweis. Nur MID Source-PR-Bot → serverseitiges ZIP → install-mid.yml → Worker/Pages → Stable.

# MID v0.9.85.287 · Missing-Daily-Migration (Source-PR-Kandidat)

- Start nach erfolgreicher Promotion: main=mid-stable=394ff6f999accb5c4211490d44f52275faefa61c, v0.9.85.286 (18.10.2026). Übernahme des gesicherten Codex-Arbeitsstands ef34de34dd153d42ae6c9dfe267a99a5be440b36 in einen unabhängigen `chatgpt/*`-Branch; ursprünglicher Branch bleibt unverändert.
- Issue #397: explizite Verfügbarkeit von Tagesniederschlagsmenge und -wahrscheinlichkeit; Missing/null/NaN/Fehleinheiten dürfen nicht als trocken/0 interpretiert werden. Worker darf einen fehlenden mm-Wasseräquivalentwert insbesondere nicht aus Regen-mm plus Schnee-cm addieren. Tatsächliche Null bleibt gültig.
- Zeit-/Akkumulationsvertrag: 23/24/25-h-Lokaltage nur bei vollständiger Stundenabdeckung rekonstruieren; unabhängige Komponenten, Codes und Wahrscheinlichkeiten erhalten. Datenstatus wird bis Forecast-/Widget-/Cache-Konsumenten und additiver Swift-v1-Wire-Maske weitergegeben, mit rückwärtskompatiblen numerischen Pflichtfeldern.
- Regressionsinventare ergänzt: `scripts/test-missing-daily-source-0985287.mjs`. Der übernommene WIP dokumentiert 987/987 lokal bestandene Core-Tests und Type-/Probe-Build **vor** Migration auf .286; das ist ausdrücklich kein Testnachweis für diesen neuen Branch.
- Versionsspiegel: package/lock, Worker, Web/PWA, Native-Build und Contract-Registry auf .287 harmonisiert. Vollständige Source-PR-, Browser-/Heavy-, Security-, Worker-/Pages-, Installer- und Stable-Gates müssen **jetzt tatsächlich** erfolgreich laufen. Keine iOS-/VoiceOver-/Push-Realgeräteprüfung behauptet.
- Offene unabhängige Vorhaben bleiben Issue #352 (RUC-Transportkompression), #374 (Skybar bei geringer Bewölkung) und #405 (Open-Meteo Upstream). Kein Release, kein Production-Update aus dieser Dokumentation.

# MID v0.9.85.286 · Push-Präferenzen und Bestätigung (Source-PR-Kandidat)

- Basis .285 e8c3e4e61eff028797120fcecc6f3be58f993911 integriert. Keine neuen Dienste oder Berechtigungen.
- #400 reproduziert und durch geordnete Clientmutationen, konkrete Serverbestätigung und Schutz vor veralteten UI-/Scheduler-Antworten abgesichert.
- Neue echte Client-/Worker-Regression und React-Browsermatrix. Physische Geräteabnahme und globale KV-Atomarität nicht behauptet.
- Ausführliche Grenzen: docs/implementation/MID_C38_PUSH_CONFIRMATION_0.9.85.286.md. Freigabe nur über unveränderte Source-/Installer-/Deployment-Gates.

# MID v0.9.85.285 · Kalendertage und aktuelle Skybar (Source-PR-Kandidat)

- Freigegebene Basis: main=mid-stable=16b6c87906370b62315e0046dec64506304abcc4, v0.9.85.284.
- #401: Nur vollständige 23/24/25 reale Stunden, gültiges Folgestunden-Akkumulationsende und echte Rohwerte dürfen Tagesniederschlag/-anteile aus finalisierten Hour-Objekten neu berechnen. Vorhandene gültige Tageswerte haben bei lückenhafter Stundenfolge Vorrang; vergangener Niederschlag wird nicht durch „ab jetzt“ ersetzt.
- Meteodatenzeit: Epoch/TZ und echte lokale Mitternachtsgrenzen statt einer heuristischen Mindestzahl (18h); Sunshine-Daily-Fallback bei unvollständigen Stunden.
- Aktuell-Skybar: native, volle aktuelle Modellstunden für Basis, getrenntes zukünftiges 15-min-Nowcast für Niederschlag. Keine künstlichen Beobachtungen oder akkumulierten Mengen.
- Pflichtregression: `scripts/test-complete-calendar-day-current-skybar-0985285.mjs` für echtes 0, null/NaN, Tageslücken, 23/24/25h, 17:45 nach Morgenregen. Alle bisherigen Gates weiterhin verbindlich.
- #397 (Provider-Tagessumme vollständig missing), #352 (RUC Transport), #374 (Skybar bei niedriger Bewölkung) werden nicht still als erledigt ausgegeben. Keine echte iOS-/VoiceOver-Abnahme behauptet.
- Nur Source-PR → SHA-Bot → Release-ZIP → Installer → Worker/Pages → Stable; dieser Kandidatenkopf ist kein Veröffentlichungsbeleg.

- Native-Map-Popup: Nach dem Platzieren oberhalb eines teilweise aus dem Viewport ragenden Ankers wird die berechnete Position jetzt zwingend erneut geklemmt. Bisher war die Bounds-Prüfung ausschließlich im else-Zweig; dadurch konnten Kartenwert-Popups im Querformat unten hinausragen. Dieselbe Korrektur gilt für Punkt-Popups; die 844×390-Browserprüfung bleibt unverändert streng.

- Regression follow-up: immutables .169 CSS cascade restored without rewriting golden fingerprint; new maps-only CSS code-splits alongside lazily imported RadarPanel/WeatherMapsPanel (Vite cssCodeSplit=true) to preserve the 1.76 MB initial CSS budget. Source fixture includes the deferred stylesheet. Legacy push test now verifies the new compact Isobaren label while retaining default-on and persistence assertions; mountain baseline checks minimum .283 and version mirror rather than pinning a prior release.

# Map-Popup viewport bounds: Browserbefund 844×390 mit 7,5 px unterem Überlauf. Die Positionierung richtet sich jetzt nach der tatsächlich gerenderten Bounding-Rect-Höhe statt offsetHeight und begrenzt den sichtbaren Viewport konservativ; ResizeObserver reagiert auf Daten-/Labeländerungen. Echter Browser-Überlauftest bleibt verpflichtend.

# MID v0.9.85.284 · Mobile weather map canvas

- Baseline SHA 532f56a95a6d47a5cb2218146aaa038d7a74384c.
- RadarPanel: semantisch native details für Secondary-Layer/Modell und Linienstile, standardmäßig auf schmalen Viewports geschlossen. Beobachtungs-Master, Terminselector und Timeline bleiben jederzeit erhalten.
- WeatherMapsPanel: Basemap im Advanced-Menü, zwei primäre Dropdowns für Produkt/Modell; Statusleiste außerhalb des Wetterkarten-Canvas bei <=850px.
- Style rules: >70 svh map viewport, mobile line mini-trigger, 44px summaries, focus-visible, reduced-motion, landscape, Light/Dark via Tokens.
- No meteorological data transformations, contour-value conversions, API, warning, worker pipeline or RUC changes. Required script: scripts/test-map-canvas-mobile-0985284.mjs. CI/browser/installer gates must prove release.

# MID v0.9.85.283 · Technischer Entwicklungsnachweis (Source-PR-Kandidat)

- Ausgangsbasis `main=mid-stable=b02d1b018882807fbce114cf6816f520f52339d1`, v0.9.85.282, Installer #39038958909 grün. Issue #398; Branch `chatgpt/v0.9.85.283-forecast-mountain-resilience`.
- Exakter Core-Cache-Warmstart mit maximal 45 Minuten ohne Verwechslung von Orten/Höhen/Zeitzonen; gespeicherte Provenienz bleibt sichtbar. Netzaktualisierung, Sequenz- und Abort-Grenzen bleiben aktiv.
- Höhenkern unabhängig von optionalen Regionalmodellen. Nachträgliches Regional-Enrichment samt erhaltener stündlicher Zeitreferenz und erneuter UTCI-/Schneeaggregation. Abgebrochener Mehrpunkt-Request: gleichwertiger vollständiger Einzelpunkt-Retry mit Zeitlimit, 429-/Abort-Grenzen und fail-closed Schema-Prüfung.
- Regression `scripts/test-location-mountain-resilience-0985283.mjs`; alle bisherigen Pflichtprüfungen bleiben aktiv. Produktionsbuild und CI vor Merge und Installer zwingend; keine Behauptung realer iOS-/VoiceOver-Geräteabnahme.

# MID v0.9.85.282 · Technischer Entwicklungsnachweis (Source-Kandidat)

- Source of Truth: Nach erfolgreichem Installer #39029978638 stehen `main = mid-stable = 5153a43979a5b995008e554d1ee8bf111c8dbe5a`, veröffentlichte v0.9.85.281. Neuer Integrationsbranch `chatgpt/v0.9.85.282-calendar-day-skybar`, Source-Commit `3901dbb215ac275e11690a55e08b64320c54ad33`. Ausgabe folgt Issue #395 und Screenshot.
- Fachliche Zeitsemantik: Kalenderorientierte Tagesansichten werden als realer lokaler Zeitraum `[YYYY-MM-DD 00:00, Folgetag 00:00)` in verifizierter IANA-Ortszeitzone auf UTC-Epochen abgebildet. DST: 23/24/25 Stunden; wiederholte 02-Uhr-Stunde bleibt über Epoch-Zeitstempel unterscheidbar. Lokale Stundenwiederholungen werden nicht durch Uhrzeit-only-Sortierung kollabiert. Kein Datensatz darf vom ersten verfügbaren Forecast-Stundenwert an auf die komplette Tagesbreite gedehnt werden.
- `src/daySkybarTimeline.ts`: Kalenderfenster und punktgenaue reale Start-/Endpositionen, Ermittlung von unbekannten Stundenabschnitten; `src/detailSkyBar.ts` und `src/SkyBarSegments.tsx`: optionale echte Stundenenden für Bänder, Solar-Splits und Quadrate. Aufrufende 24-h-Nowcast-Verläufe ohne Kalenderfenster behalten ihren bisherigen rollierenden Vertrag.
- `src/ForecastCockpit.tsx`: sieben Tageskarten und Kurven/Widgets mit kalendergenauer Zeitachse, getrenntem Sonnen-/Nachtrendering und sichtbaren Missing-Slots. `src/SevenDayForecastSummary.tsx`: „Heute“-Tagescharakter aus allen verfügbaren Tagesstunden statt `epoch >= Date.now()`; nach vorne gerichtete Warnungs-/Nowcastfenster bleiben unabhängig. Tagesmengen werden weiterhin aus `Day.precipitation` und `Day.sunshineDuration` bezogen, nicht aus abgeschnittenen Stunden ab „Jetzt“ aggregiert.
- `scripts/test-full-calendar-skybar-0985282.mjs` testet 24h normal / 23h / 25h, Mitternacht, Sommer-/Winterzeit, doppelte lokale Stunde, fehlende erste 14 Tagesstunden, interne und komplette Datenlücken, korrekte Segmentenden, Widgets-/Tagesbeträge sowie unveränderten rollierenden Profileinstieg. Gesamtinventar: **986** Regressionen.
- Alle Produktions-/CI-Gates müssen auf dem genauen neuen Source-SHA vollständig durchlaufen; danach einzig kontrollierter MID-Bot-Merge → serverseitiges ZIP → `install-mid.yml` → Pages/Worker → Stable. Browserchecks ersetzen keine echte iOS/VoiceOver-Abnahme. **Kein Erfolgsnachweis vor den Gates.**

# MID v0.9.85.281 · Technischer Entwicklungsnachweis (Source-PR-Kandidat)

- **Source of Truth**: v0.9.85.280 auf `main=mid-stable=9bb12c712cce0d6a5f73460cbe76c4a498c9a01c` vollständig verifiziert, Installer `39023811560` inklusive ZIP, Core/Heavy, Pages, Worker und Promotion erfolgreich. Fortführung von Issue #392, vorbereiteter Quellstand auf `chatgpt/v0.9.85.281-pseudosat-land-water` (gesichert als `d13cd9aa0cbb4106c99ebd800199549dba6dc813`), ausschließlich nach Dateiüberlappungsprüfung auf aktuell stabile .280 übertragen.
- **Kartenbasis**: `src/pseudoSatelliteBasemap.ts` liefert gemeinsame Display-Palette; `UnifiedVectorBasemap` zeichnet Wasser aus OpenFreeMap-`source-layer:water` und Land im Hintergrund, beschränkt auf helles bestätigtes Pseudo-Modellbild. Native ICON-D2 verwendet dieselbe Basis mit negativen Karten-Layer-Prioritäten, damit Wetterraster mit `zIndex=0` sichtbar bleibt. Kein Eingriff in Modellwerte oder WMO-Palette.
- **Export**: `cloudWeatherSvg`/PNG verwendet die Wasserbasis und Country-Ringe plus alle 16 deutschen Bundesländer aus vorhandenem Natural Earth. Die vorhandene Country-Liste bildet Deutschland nicht als zusammenhängende Landfläche ab; Bundesländer schließen diese Lücke. SVG-/PNG-Raster liegt darüber. Kein erfundener Satellitendatensatz; bekannte land/water-Geometrieauflösungsunterschiede dokumentiert.
- **Regression**: neu `scripts/test-pseudo-satellite-basemap-0985281.mjs` (Farbkonstanz, Layerorder, Missing-/Clear-Transparenz, Export, 5 Land- und 3 Meer-Kontrollpunkte). In zwei bestehenden Pseudo-Sat-Tests wird lediglich die bewusst erweiterte Export-Aufrufsignatur mit `geography.countries` aktualisiert; fachliche Kontur-/WMO-Assertions bleiben erhalten. Vollständige Source-/Heavy- und Release-Gates müssen unabhängig erneut nachgewiesen werden.
- **Versionsspiegel**: v0.9.85.281 in package/lock, App/Worker, beiden Service-Workern, Build-/Release-Dokumentation, Baseline und Contract-Registry, iOS-Buildnummer 282 ohne behauptete physische iOS-/VoiceOver-Abnahme.
- **Freigabesperre**: Quell-PR zum geschützten `main`, SHA-gebundener MID-Release-Bot, serverseitiges ZIP, `install-mid.yml`, Worker-/Pages-Gates, Stable-Promotion. Keine PR-Completion-Standardmerges, manuelle Production-Releases oder Ausnahmen.

# MID v0.9.85.280 – Technischer Entwicklungsnachweis (Source, nicht automatisch veröffentlicht)

- Basis: v0.9.85.279 `afceb2d0b770a7f7c337cc1b9e69359dcfee19d6`, SHA-identische freigegebene Hauptbranches nach Installer #39019809930.
- Nutzerauftrag: #392; Regen-Vorlauf und Dauer neu formatiert; absolute Orts-/Gerätezeit als persistierte Push-Option; per-Modell-Synoptik-Isobaren sichtbar schaltbar, inklusive GFS/IFS.
- Worker-Quelle und die beiden generierten Worker-Aggregate sind bytegenau synchronisiert; Browser-/Worker-Vertrag bleibt abwärtskompatibel. Keine Änderung der meteorologischen Berechnung oder RUC-Kompression.
- Verifikation: neuer `test-mid280-push-time-isobars.mjs`; Source-PR-, Release-Core-, Heavy-, Worker-/Pages- und Stable-Prüfungen müssen nach Commit grün belegt werden.

## MID v0.9.85.279 · 17.10.2026 · Ortssuche-Recovery und pseudogeografische Kartenkonturen

- Source-of-Truth: freigegebener `main=mid-stable=ee2c00bfd0db42cf0f48715bccd0dbff1e221c42` (v0.9.85.278), erfolgreicher Installer #39012604444, keine konkurrierenden offenen Produkt-PRs.
- Nutzerfall #390: Sportplatz Rankenhohn, gelegentlich Timeout nach Open-Meteo-Direct (6,5 s) und Worker-Fallback; einmaliger automatischer erneuter Versuch bei `TimeoutError`, gebunden an den aktuellen Standort/Request-Generation. Manueller Wiederholungsbutton nach fortbestehendem Fehler, ohne unendliche Retry-Kette.
- Pseudo-Sat-Modus und Kartenauswahl waren schon persistiert; deren Speicherschlüssel bleiben unangetastet. Neuer unabhängiger gespeicherter 500-hPa-Isohypsen-Schalter, ergänzt zum MSLP-Isobaren-Schalter, nur für exakt identisches Modell/Run/Validität und bestätigte synoptische 500-hPa-Konturen. Kein GDPS-Mischprodukt.
- Bei aktivem schematischem Wolkenbild im hellen Design andere Kartenbasis nur in Prognoseframes; unbestätigte Wetter- und Satellitenframes behalten Originalgeografie. SVG/PNG passen Druck- und Höhenlinien mit eigenständigen Einheiten und Datenherkunft an.
- `scripts/test-mid279-pseudosat-isoheight-timeout.mjs`: Persistenz, Konturen mit falschem Modell/Run/Term ausgeschlossen, PNG/SVG-Quellgeometrie, fehlende Wetterwerte, Schutz früherer Light-/Dark-Maps, begrenzter Ortstimeout-Retry. Keine neuen Modell-/Warnschwellen, keine neuen kostenpflichtigen Datenquellen.
- Release ausschließlich Source-PR → kontrollierter SHA-gebundener Bot-Merge → ZIP → Installer → Worker/Pages → Stable. Kein reales iOS-/VoiceOver-Gerätezertifikat.

## MID v0.9.85.278 · 2026-10-16 · Exakte solare Skybar-Slotgrenzen (Issue #374)

- Ausgangsbasis: erfolgreich veröffentlichter `mid-stable` v0.9.85.277, SHA `6754d25358c809966a3e1d026c88f500a1699d69`. Keine konkurrierende Produkt-PR vor Arbeitsbeginn; RUC- und Revision-Runs separat in Arbeit und unverändert.
- `detailSkyBarSolarSegments` teilt ausschließlich **durchgehende Himmels-Grundbänder** auf echte Epochengrenzen aus `solarTimelineWindow.nightBands` auf. Punktbezogene Wolkenzustände werden an ihrem `hour.epoch` statt an möglichen anderen Niederschlagsakkumulationsankern aufgetragen. Unbekannte Zeitstempel behalten das bisherige Ergebnis.
- Niederschlagssegmente einschließlich WMO-/DWD-Phase, Intensitätsgrad, Farben, Menge, Lauf und Akkumulationszeit werden ohne geometrische Umdeutung exakt aus `detailSkyBarSegments` übernommen; kein erfundener meteorologischer Frame und keine Interpolation von Wetterwerten. Bestätigte Wolkenlücken werden nur in der astronomisch hellen Teilzeit als solche beschriftet, nicht als Sonnenscheinmessung ausgegeben. Bestehender .268-Schwellenfix bleibt aktiv.
- Eingebunden in 90 Minuten, 24 Stunden, Tageskacheln und 7-Tage-Kurvenübersicht, zusätzlich zum bisherigen SVG-/Widget-/Export-Fundament. Stundenquadrate bleiben diskret und unverändert. DST und Polarnacht/-tag ohne zusätzliche künstliche Zeiten.
- Neuer deterministischer Test `scripts/test-skybar-solar-epoch-split-0985278.mjs` deckt 15-/60-min-Intervallgeometrie, Sonnenauf-/-untergang, Niederschlagsunverändertheit, Missing, Vollnacht, Sommerzeitwechsel und ungültige Epochensemantik ab. Vorhandene reine Aufruftextassertionen ausschließlich an die neue Signatur angepasst; fachliche Prüfungen erhalten.
- Keine neuen kostenpflichtigen Datenquellen, Worker-/RUC-/Modell-/Warnschwellen-, WMO-Code- oder Sicherheitsänderungen. Ohne erfolgreiche Source-Core/Heavy, Browser-/iOS-Hülle, ZIP, Installer, Worker/Pages und Stable-Promotion ist dieser Branch keine veröffentlichte Version. Physisches VoiceOver/iOS nicht abgenommen.

## MID v0.9.85.277 · 2026-10-16 · Beobachtungsübergang und Isobaren

- Freigegebene Source-Basis ff30648863744759aca9b28c524662e3f65ba496, v0.9.85.276, Issue #386. Parallele Abhängigkeits-/RUC-PRs und Schutzregeln unverändert.
- Gemeinsame Radar-/Satellit-/Modellzeitachse: Wolkenmodelllayer nur bei bestätigtem forecast-Frame, Beobachtung/Nowcast ohne vorgezogene Modellwolken; Schematik klar ausgezeichnet, kein Satellitenradiometrie-Schein.
- Optionale DWD ICON-D2-/ICON-EU-/ICON-Global-MSLP-Isobaren hPa aus jeweils eigenem Modellfeld mit exakt gleichem Modell, Forecast-Run und Valid Time; native und gemeinsame Ansicht mit einer persistierten Auswahl; SVG und PNG verwenden überprüfte Konturpfade.
- Neue Required-Regression `scripts/test-pseudo-satellite-isobars-0985277.mjs`; bestehende v.276-WMO-/Null-/Exportregression bleibt bestehen. Release-Freigabe nur mit belegten Source-PR, ZIP, Installer, Worker-/Pages- und Stable-Gates.

## MID v0.9.85.276 · 2026-10-16 · Modell-Wolkenbild (Phase A)

- Stable-Basis 2879b8437123017bfc98bafcf54ec9e9b68a5b50, vorher v0.9.85.275; Issue #386. Parallel bestehende Dependabot-PRs und aktive RUC-Runs nicht verändert.
- DWD CLCT+WW unverändert; optionaler rein visueller RGBA-Kompositionsmodus ohne neue Modelle, Schein-Satellitenradiometrie, Änderung von WMO-Code, Schwellen oder Modelldaten. Fehlende Felder bleiben fehlend; bestätigte Wolkenfreiheit bleibt 0.
- Ein gemeinsamer Renderer für UnifiedWeatherMap/NativeModelMap und PNG/SVG-Export; Auswahl lokal persistent, Originalansicht rückwärtskompatibel. GDPS bleibt bei seiner ursprünglichen WMS-Kombination.
- Verbindliche Regression scripts/test-pseudo-satellite-cloud-render-0985276.mjs; vor Veröffentlichung Source-Core/Heavy, Installer, Worker, Pages und exakt SHA-gebundene Promotion erforderlich.

## MID v0.9.85.275 · 2026-10-16 · Parallele Extremwetter-Direktabrufe zuverlässig abbrechen

- Source of Truth: main=mid-stable=fabed02f7f42d4a430ba9478c33aadc0d0f98c25 v0.9.85.274 vor Entwicklung. Offene PRs zum Arbeitsbeginn nur Dependabot; keine v0.9.85.275-Parallelbranch.
- Problem #345 bestätigt: `let directRequestSignal` in `scripts/build-maintenance-aggregates.mjs` generierte eine modulglobale veränderliche Variable. Bei zwei gleichzeitig aktiven Direct-Fallback-Forecasts konnte der erste spätere `fetchWithDeadline` das Signal der zweiten Operation lesen.
- Die fachliche Worker-Quelle `worker-src/25-dach-extreme-outlook.js` bleibt unverändert. Der generatorseitig erzeugte Browser-Direktadapter bildet für jeden Vorgang einen eigenen lexikalischen Kontext mit dem jeweiligen Signal. Die beiden bisherigen Modul-Caches werden bewusst weitergeteilt, damit erfolgreiche Ergebnis-/Batch-Caches und Budgetschutz erhalten bleiben.
- Die generierte Datei `src/extremeWeatherOutlookDirect.generated.js` ist synchron. Zusätzlicher `signal.aborted`-Postcheck verhindert, dass ein mittlerweile abgebrochener Vorgang aufgrund des fachlich erlaubten Batch-Fallbacks als erfolgreicher frischer Direktwert zurückkehrt.
- Die bestehende Pflichtregression `scripts/test-extreme-outlook-worker-fallback-09664.mjs` schützt nun die ausschließlich cachebezogene Worker-Quelltexttransformation und enthält deterministische Konkurrenzfixtures: zwei gleichzeitig gestartete direkte Produkte, verzögerte zweite Teilabrufe, isolierter Abort und unabhängiger Abschluss. Keine neue externe Abhängigkeit, keine Workflow-/Gate-Schwächung, kein Server-Worker-Signalverhalten verändert.
- Alle Versionsspiegel für App/Worker/Pages/PWA/Capacitor/Verträge auf v0.9.85.275. Regulärer Source-Gate und MID Installer inklusive echter Worker-/Pages-Promotion sind Pflicht; physische WKWebView-/VoiceOver-Abnahme wird nicht behauptet.

## MID v0.9.85.274 · 2026-10-16 · Modellstand: Einzelne ältere Läufe nicht pauschal rot

- Basis 1b842f210c6f817693c8f117c91e4ee867248650, main = mid-stable, v0.9.85.273; keine überlappenden offenen Produkt-PRs oder 0.9.85.274-Branches vor Source-Arbeit.
- Die bisherige aggregierte Regel `any stale -> global red` war für heterogene Multi-Modellfusionen überstreng; gleichzeitig war `fusionLoaded=true` auch bei `usedInCanonical=false` relevant, während aktiver Ensemble-Fallback fehlte.
- Der neue Ampelvertrag verlangt für Rot >=2/3 der berücksichtigten Laufanzahl mit eigenem nachgewiesenen Stale-Status; ein einzelner tatsächlich verwendeter überfälliger Lauf bleibt Rot. Teilweise Stale=Gelb mit ungekürzter stale-Anzahl und Kennzeichnung `Einzelne Modellläufe überfällig`. Unbekannte Metadaten werden nie als grün interpretiert.
- Bewusst keine Änderung einzelner modell- und laufzeitabhängiger fachlicher Frischegrenzen, keine Glättung/Interpolation/WMO-Codeänderungen. Numerische Grenze 2/3 ist eine erklärte UI-Aggregationsentscheidung und kein meteorologischer Qualitätswert.
- Erweiterter existierender TS7-kompatibler Test für Mischstatus, Vollveraltung, ausdrücklich unbenutzte Fusion, echten Ensemble-Fallback und Missing. Keine CSS-Änderung, keine neuen Abhängigkeiten/Workflows, alle Release-Versionen synchron. Vollständige Source-, Heavy-, Installer-, Worker-, Pages- und Stable-Gates erforderlich.

## MID v0.9.85.273 · 2026-10-16 · Modellstand-Aktualität auf einen Blick

- Verifizierte MID-Stable-Basis 1a7eedbe49e35445619131d390d3991e218c164a; Branch chatgpt/v0.9.85.273-model-status-freshness bei 4dbb0ef9e36d75771fbfd075e523be73f14930b8 war exakt einen Commit voraus. Divergierter paralleler 273-Branch wurde nicht übernommen.
- Gemeinsamer CockpitModelRunDetails-Trigger für Kurzfrist, sieben und vierzehn Tage mit statusabhängiger Umrandung + Punkt, lesbarer Erklärung/ARIA, 60-s-Timer, explizitem Unknown und aktualisierungsfrequenzabhängigen Grenzwerten. Fachlich keine Modell-Skill- oder Warnstufeninterpretation.
- Quellnaher 979-Test-Registry-Eintrag einschließlich neuer Model-Freshness-Regression, bereinigter Version-/Worker-/Pages-/iOS-Spiegel und nur additivem CSS-Status. Source-Gate, reale Browser-/iOS-Prüfungen und Installer bleiben maßgeblich.
- Bestehende RUC-Vollkompression, Widget-Skybar, Ensemble-Meteorologie, Modellkarten und Cloudflare-Worker-Datenverträge sind unverändert.

## MID v0.9.85.260 · 2026-10-15 · RUC-Betriebsnachweis und Open-Meteo-Prüfstand

- Basis .259 / 9c0cd7cd0da3dcbd1d6cd72fc9ec1ad90311b021 nach erfolgreichem Installer 38689707057. Drei erfolgreiche nachfolgende RUC-Läufe; publiziertes Pilotobjekt und aktueller Worker-Basishealth belegt, Codec-Read im bisherigen Log nicht sichtbar.
- Source-Gate-Reparatur: gemischte Browserfixture hält ICON-06/18-UTC-Grenze von +120 h ein. Echter Produktionsleser prüft alle 24 UTC-Laufstunden; unzulässige +180 h bleiben abgewiesen. Keine Validator-/Kartenprüfungsabschwächung.
- check_ruc_health.py ergänzt getrennte laufgebundene Codec-Evidenz. Kein Ersatz von raw readiness durch Codecstatus; explizite Boolean-, Transport- und RawRetained-Prüfung. Regressionen decken echten Nachweis, falschen Lauf, fehlende Diagnostik, Abschaltung und Rohfallback ab. Keine Workflow-/Datenformatänderung.
- Frühere Open-Meteo-Prüfungen mit Original-PRs/SHAs konsolidiert: docs/implementation/MID_OPEN_METEO_RUC_AUDIT_0.9.85.260.md. Keine ungeprüften Aliaswechsel, wissenschaftlichen Doppelkorrekturen oder rückwirkenden Kalibrierungsänderungen. MID #345 bleibt separat offen.

## MID v0.9.85.259 · 2026-10-15 · Installer dependency repair

Installer 38686567282 correctly rejected .258: the byteplanes publisher imported NumPy through storage_audit. Load the optional delta diagnostic helpers only when selected; require the complete dual-read fixture to run under python3 -S. No dependency/workflow/gate change, no compression-wire or meteorology change. .258 never reached Stable.

## MID v0.9.85.258 · 2026-10-15 · Bounded dual-read pilot

One optional <=512-KiB deterministic tail chunk, raw retention, exact post-allocation budget, strict manifest/geometry/SHA, bounded shared decoder, legacy and rollback equivalence. No full storage migration or cache deletion.

## MID v0.9.85.257 · 2026-10-14 · RUC transport canary

Shared bounded SHA-verifying decoder in isolated browser and fixed-origin Worker diagnostic; synthetic all-int16 fixtures, raw legacy reads, CacheStorage round trips, rejection of auto-decoded opaque wire. Actual hosting is GitHub Pages behind Cloudflare, not Cloudflare Pages. No production grid.v2 migration or budget change.

# MID v0.9.85.256 · RUC-Kompression sicher für Browser und Worker vorbereiten

- Der neue Prüfschritt kann künftig verlustfrei komprimierte RUC-Wetterdaten in JavaScript wieder exakt in ihre ursprünglichen Werte umwandeln. Dabei werden auch fehlende Werte korrekt erhalten.
- Ein zusätzlicher automatisierter Test prüft alle 65.536 möglichen 16-Bit-Muster und echte Python-Kompressionsdateien. Beschädigte, verkürzte oder unerwartete Daten werden zurückgewiesen.
- Die Messung eines vollständigen RUC-Laufs zeigt für Byteplane-gzip rund 70,8 Prozent theoretisches Einsparpotenzial beim bisher veröffentlichten Datenbestand. Das ist eine Messung, noch keine aktivierte Speicherreduktion.
- Die bisherige RUC-Veröffentlichung, Wetterberechnungen, Karten und das bestehende Datenformat bleiben unverändert, bis Web-/Worker-Dual-Read, echte Leistungsprüfungen und die alten App-Caches sicher getestet sind.

# MID v0.9.85.255 · Kartenprüfung bei hoher Browserlast zuverlässiger

- Die regelmäßige Qualitätsprüfung der Wetterkarten verteilt gleichzeitig geöffnete Kartenfenster schonender. Dadurch wird die Software-Grafikdarstellung weniger stark überlastet.
- Alle 24 Bildschirmgrößen-, Design- und Hell-/Dunkel-Prüffälle bleiben erhalten. Die Anzeige der ICON-EU-Isobaren muss weiterhin tatsächlich funktionieren; eine fehlende Karte bleibt ein Fehler.
- Sollte die Prüfung scheitern, zeigt der Bericht jetzt deutlicher, welche Displayvariante, Modellkarte und Kartenlayer betroffen waren.
- An Wetterberechnungen, Modelllaufzeiten, Farben, Karteninhalten und der Bedienung ändert sich nichts. RUC-Datenformate und Speichergrenzen bleiben unverändert.

# MID v0.9.85.254 · Veröffentlichte Modellkarten wieder vollständig erreichbar

- Ein Fehler im Kartenkatalog wurde behoben: Gültige zusätzliche ICON-D2-Wolken-/Wettertermine bei +13, +14, +16 und +17 Stunden führten bisher dazu, dass die App den gesamten Synoptik-Katalog ablehnte. Die bereits veröffentlichten Karten von ICON-D2, ICON-EU, ICON, GFS und IFS sind dadurch wieder auswählbar.
- Die Prüfung bleibt streng: Zusatzstunden gelten ausschließlich für ICON-D2. Lauf, Gültigkeitszeit, Modellhorizont, Größe, Datenformat und Prüfsummen müssen weiterhin stimmen. Fehlende Karten werden nicht geschätzt oder künstlich ergänzt.
- Automatische Kartenprüfungen verwenden auch beim vollständigen Revisionslauf die bestehenden vollständigen Teilgruppen. Alle 24 Größen-/Theme-/Designfälle bleiben erhalten; die Zeitgrenze pro Teilgruppe wird nicht erhöht.
- Neue Regressionen prüfen den tatsächlich veröffentlichten Katalog und zusätzliche Kartenstunden. Wetterberechnungen, Darstellung, Speicherbudget und das RUC-Datenformat bleiben unverändert.

# MID v0.9.85.253 · Sicherheitsprüfungen mit eindeutigem Datenstatus

- Eine hohe Sicherheitslücke im Build-Werkzeugpfad wurde durch den kompatiblen Patch von `source-map-js` auf 1.2.2 behoben.
- Die Prüfung der Produktionsabhängigkeiten unterscheidet jetzt ein geprüftes Ergebnis von einem unbekannten Zustand bei ausgefallenen Prüfdiensten. Ein unbekannter Zustand wird nicht mehr als „keine hohen Sicherheitsbefunde“ bezeichnet.
- Prüfzeit, geprüfter Paketstand und verwendete Quelle werden nachvollziehbar dokumentiert. Bei Dienstausfällen wird eine notwendige Nachprüfung ausgewiesen.
- Unvollständige oder ungültige Antworten gelten nicht als erfolgreiche Prüfung. Bestätigte hohe und kritische Befunde blockieren weiterhin die Freigabe.
- Wetterdaten, Modellkarten und Darstellung bleiben unverändert. Die bestehende Regel für reine externe Dienstausfälle und die unabhängigen Release-Prüfungen bleiben erhalten.

# MID v0.9.85.252 · Modellkarten bei echten Datenlücken besser erreichbar

- Bei geöffneten Modellkarten wählt die gemeinsame Zeitleiste zum Einstieg einen tatsächlich vorhandenen Modelltermin statt eines reinen Radar-/Beobachtungszeitpunkts. Das reduziert leere Synoptik-Komposite bei ungleichmäßig verfügbaren Modellzeiten.
- Bei „Wolken und signifikantes Wetter“ kann ICON-D2 für einzelne fehlende Termine ein schon vorhandenes, zeitgleiches natives Wolken-/Wetterfeldpaar nutzen. Fehlende oder unpassende Felder werden weiterhin nicht ergänzt oder geschätzt.
- Zusätzliche Regressionen prüfen die Terminwahl und stellen sicher, dass nur gemeinsam verfügbare Modellfelder verwendet werden.
- Modellberechnungen, Warnschwellen, RUC-Datenformat, Speicherschutz und die Bedienung anderer Wetterkarten bleiben unverändert.

# MID v0.9.85.243 · Orte sortieren und verständliche Wetterwerte

- Prognose-Radar unter Vorhersage eindeutig benannt. Die erweiterte Ensembleanalyse im Prognose-Cockpit zeigt dieselbe Auswertung nicht doppelt; eigenständige Ensembleansichten und Änderungsbenachrichtigungen bleiben erhalten.
- Die Mehrort-Übersicht folgt standardmäßig deiner Favoritenreihenfolge in den Einstellungen. Sortiere alternativ nach Ortsname, Warnlage, Temperatur, Niederschlagsmenge, Böen oder Entfernung. Deine Wahl bleibt gespeichert.
- Übersicht und „Wetterfenster vergleichen“ haben klar unterschiedliche Aufgaben: kompakte Wetterkarten gegenüber einer Rangliste mit hervorgehobenen passenden Stunden und konkreten Trockenphasen.
- Ganzzahlige Temperaturen in der Ortsübersicht; gleiche gerundete Minima und Maxima werden nur einmal angezeigt.
- Einheitliche parameterabhängige Anzeigepräzision: keine Hundertstel bei Niederschlagswerten, ganzzahlige Windwerte auch in m/s, Sichtweiten in fachlich passenden Stufen. Kleine positive Niederschläge bleiben als „<0,1 mm“ sichtbar.
- Neuer verbindlicher Präzisionsvertrag unterscheidet SYNOP-Berichtsregeln von MID-Prognosedarstellung. Die unveränderten Originalwerte bleiben Grundlage für Berechnungen und Vergleiche.

## MID v0.9.85.236 · Ortsanzeige und verlustfreie RUC-Deduplizierung

- Die ausgewählte Ortsleiste bleibt beim Scrollen über dem Suchkopf scharf lesbar. Der überlagernde Kopf-Blur wird bei sichtbarer Ortsleiste abgeschaltet; Karten-/Einstellungsgrenzen und Dialoge bleiben erhalten.
- Bytegleiche RUC-Chunks werden nach Hash, Größe und vollständigem Bytevergleich einmal gespeichert. Der Worker unterstützt geprüfte Chunk-Aliase sowie unverändert ältere Snapshots. Missing, trockene Nullen, Zeitachsen und Datengenauigkeit bleiben bitidentisch.
- Gemessener Lauf2026-10-11T05:00:899950367 Objektbytes,20103168 Duplikatbytes. Der tatsächliche Gewinn jedes neuen Laufs fließt vor der Synoptik-Budgetierung ein und erhält damit mehr validierte Modelltermine, sofern verfügbar.1MB Reserve plus exakte Manifestprüfung schützen das unveränderte900MB-Budget.
- Gzip/Byteplane-Kompression bleibt Messkandidat bis vollständige Lauf-/Decoder-/Performance-Evidenz vorliegt. Keine zusätzlichen Felder oder Modelle werden zur Einsparung gestrichen, kein kostenpflichtiger Speicher aktiviert.

# MID v0.9.85.235

Kompakter gemeinsamer Profilkopf, kanonischer Sticky-Ortskontext und reversible Byteplane-Kompressionsmessung. Basis fd6890e; keine Decoder- oder Budgetänderung. Details: docs/implementation/MID_C27_COMPACT_PROFILE_0.9.85.235.md.

## MID v0.9.85.231 · 2026-10-10 · Missing-Vertrag RUC-Phasen

- Kartenparameter sigwx wird bei gleicher persistierter ID zur gemeinsamen Wolken-/Wetterkarte. Gemeinsamer Renderer/Legende/Ortswert/Export; native Legacy-Route nutzt dieselbe Kombination. GDPS nutzt zwei verifizierte GeoMet-Produkte desselben Laufs und Termins, begrenzte Niederschlagsart ausdrücklich gekennzeichnet.
- Optionale ICON-EU/ICON-Global-Anreicherung erhält Synoptikkerne bei Quellenfehlern. CLCT/WW-Raw-Identität, Einheiten, gültiger Termin und identisches Raster zwingend. Sechs reale DWD-Header belegen WW-Parameter0/19/25, keine hypothetischen WW-WMS-Layer. Kategoriale Raster auch im Kartenrenderer nearest statt linear.
- Neue Pflichtregression und zwei Pythonfälle prüfen Paarung, Missing, WMO-Intensitätsgrenzen, Katalogfilter und Atomizität. Bestehender echter Karten-Browsergate prüft die Kombination zusätzlich in allen Viewport-/Theme-/Designfällen.

- Fehlender Graupel bleibt NaN/int16-Missing statt trockener0. Wire-Struktur unverändert.
- Worker erhält Decoder-null und zählt nur endliche Phasenwerte. All-missing nicht verfügbar; echte trockene0 gültig.
- Overlay erzeugt aus null/Leerwerten keinen thermischen Schnee-/Gefrierbeleg. Zwei zusätzliche Pflicht-Pythonfälle und erweitertes reales Worker-/phaseFor-Gate.
- Basis .230 Stable116cc09e9fdd9605cfbc5154e6e84c4065793b78, Gates unverändert. Separate offene RAIN_GSP-Units/accum-Frage dokumentiert.

## MID v0.9.85.230 · 2026-10-10 · Skybar, alphabetische Karten und MU-Energieverträge

- Alphabetische Modelle und gruppenweise Parameter in UnifiedWeatherMap und WeatherMapsPanel; gemeinsamer deutscher Collator mit natürlichen Zahlen, kopierte Listen statt Mutation. Fallbackprioritäten/persistierte IDs unverändert.
- Vier echte CAPE_MU/CIN_MU-DWD-Header2026-10-10T15:00 +0/+1h mit Hash/Raw-Codes/Grid archiviert; reproduzierbarer begrenzter Probe. Separate MU193-Matrix und Energieeinheiten J/kg statt stiller Übernahme beliebiger Einheiten. Drei neue Python-Pflichttests, keine vollständige optionale Werte-/E2E-Abnahme.
- C21-CI-Browserfixture erhält den neuen expliziten minutes15-Prop;28 lokale Fälle grün. Karten-Browsergate prüft alphabetische sichtbare Reihenfolge in beiden Auswahlrichtungen; reine ThetaE-Reihenfolgeassertion folgt bewusst dem neuen Alphabetvertrag bei gleicher Anbieter-Menge.

- Verifizierte Basis main=mid-stable b88efe2f3ba580aad5a0e692037f2c9814f69547 (.229), Installer38059674163 erfolgreich; keine überlappende Source-PR.
- Current bekommt displayMinutes15 und shortTermAnchor wie Heute. buildShortTermForecast und die wiederverwendete shortTermProfileHourlyPoints-Aufbereitung erhalten geringe native Mengen und korrekte vorwärts gerichtete Zeitintervalle. Kein zweites Radar-Blending auf bereits finalisierten Daten.
- Gemeinsame detailSkyBarTimedSegments zeichnet ausdrücklich Anfang/Ende, clippt Geometrie ohne Mengen-/Intensitätsänderung und erhält Lücken. Current und Heute verwenden denselben Niederschlagsrenderer; Current-Stundenquadrate dieselbe Stundenaufbereitung und echte Epoch-Positionen.
- Regression reproduziert zuvor fehlende 0,06 mm, vergleicht Zeitpunkt/Phase/Intensität, Squares, trocken/Missing, Clipping, Lücken und Input-Unveränderlichkeit. Browser prüft echte Current-/Heute-Komponenten in sechs Viewports, beiden Themes/Designs und beiden Skybar-Modi.
- Bestehende wissenschaftliche, Sicherheits- und Freigabeverträge bleiben verbindlich; weitere Gesamtauditpunkte aus .229 bleiben offen.

## MID v0.9.85.229 · 2026-10-10 · UTCI, kompakte 14d-Entwicklung und reale Werte-Referenz

- Verifizierte Basis main=mid-stable ada0f6c54a7ed1faf56d4d202d8a897abf567157 (.228). Keine überlappende offene Source-PR; Releasegates unverändert.
- CurrentUtciHighlight erhält ausschließlich den bestehenden kanonischen UTCI; eigene Wertgruppe, Einheit und Kategorie. Nicht endliche Werte zeigen keine Behaglichkeitskategorie.
- Gemeinsamer HorizonSignalChart verbindet nur aufeinanderfolgende UTC-Kalendertage bei explizitem connectDaily; Missing und fehlende Tage unterbrechen die Linien. Periodenprodukte bleiben diskret. 14d nutzt kompakte Höhe und konsolidierte Phasen.
- derive_core_fields extrahiert unverändert die bisherige Produktionsrechnung; Werte-Referenz und Produktion teilen denselben Normalisierungs-/Ableitungs-/Packing-Pfad.
- DWD-Lauf 2026-10-10T09:00: 66 Dateien, zwölf Kernparameter/Koordinaten und EPS1..20 bei +0/+1h; vollständiges Gitter542040, QC und Niederschlagskonservation bestanden. 35 dekodierte Zellvektoren mit URL/Hashes und Bit-Goldens eingefroren. Keine rohe GRIB-Archivierung oder volle14h-/Rapid-/Lookup-/E2E-Abnahme behauptet.

## MID v0.9.85.228 · 2026-10-10 · Wissenschaftsaudit: kalibrierte Kern-GRIB-Verträge

- Basis main=mid-stable bc7c73a818714420474b688b48b7ef3fdf2893b1 (.227), Releasegates unverändert.
- CORE_CONTRACTS umfasst zwölf Kernfelder und CLAT/CLON; EPS TOT_PREC wird im Prozessdecoder ausdrücklich gebunden. Raw Fixed-Surface-Codes statt unknown-Anzeigenamen.
- Unstrukturierte Felder müssen UUID c6b12daa91ad64045b26c1b6452a2a20, Grid47/Reference1 und542040 Punkte treffen; Revisionen benötigen Neukalibrierung.
- UTC init+lead=valid, instant/accum/max-Bounds und explizite m/h/s-Schritte; additive sourceGribContract-Metadaten ändern keine Binärlayouts.
- Pflicht-Negativfixtures und read-only Header-Achsenprobe einschließlich20 EPS-Mitgliedern; keine vollständige Werte-/QC-/Packing-/E2E-Verifikation daraus behaupten.
- Vollständiger Produktions-Mitgliedersatz1..20 und Host-zeitzonenunabhängige UTC-Laufkennungen. Reale584 Header mit URL/Hash/Bounds/Grid archiviert;47 GRIB-/Integritäts- und3 Temperaturtests,955 App-Regressionen und14 Browserfälle lokal bestanden.

# MID v0.9.85.216 · Widget-Render-Gate

Geladene Fonts/Bilder, zwei Paints und sichtbare Geometrie sind gemeinsame Voraussetzung für URL-/PNG-/Clipboard-Export. Echte Bild-/Fontfehler erzeugen keine Ready-Freigabe. CDP bewahrt den ersten Fehler mit Screenshot und begrenztem Versions-/Stable-/Render-/Netzwerkbezug über Retry/Recovery. Fehlerartefakte bleiben im CI-Artefakt außerhalb des öffentlichen Widget-ZIP. Alte Source-Wiring-Prüfungen folgen dem extrahierten Helper; ihre Font-/Paint-/SVG-Restore-Verträge bleiben erhalten. Keine Wetterwerte, Skybar-Geometrie, Release-Gates oder Produktionsberechtigungen geändert.

# MID v0.9.85.215 · MID-C24: durchgehende Skybar und konkrete Intensivaudit-Abnahme

Gleiche angrenzende Skybar-Darstellungen werden im gemeinsamen SVG-Renderer einmal gezeichnet; Originalintervalle/Titel, Datenlücken und Niederschlags-Paint-Reihenfolge bleiben erhalten. Konkrete offene Auditschritte und Abnahmegrenzen: docs/implementation/MID_C24_SKYBAR_AUDIT_STATUS_0.9.85.215.md. Basis main=mid-stable a4e0031df84d46614b7fc5889f92577236d01680 (.214). Veröffentlichung ausschließlich durch Source-Gate, bestehenden Bot und Installer/Pages/Stable-Promotion.

# MID v0.9.85.214 · Intensivaudit Phase 3b: isolierte Karten-Speicherprobe

Verifizierte Basis main = mid-stable = 19b28d9e28bb05efa6e5e690f5e224566f62c551 (.213), Installer 37882113485 erfolgreich. Paralleländerungen .207–.213 vollständig erhalten. Branch codex/v0.9.85.214-audit-map-memory.

Die bestehende vollständige 24-Fälle-Kartenmatrix bleibt erhalten. Nach ihrem Abschluss läuft im Heavy-Shard 2/3 (oder lokal ohne Shard) ein zusätzlicher, isolierter 390px/Light/Next-Fall. Zwei Warmup-Rundwechsel ICON-EU→ICON-D2 füllen beide geprüften Modellcaches; danach 20 echte Rundwechsel über dieselben sichtbaren Controls. Jeder Wechsel wartet auf den aktuellen Modellstatus ohne Ladezustand sowie genau eine Synoptik-Flächenebene. Dieselbe ursprüngliche MapLibre-Instanz und genau eine Karte bleiben Pflicht. Die zusätzliche Probe ist klar als isolated-memory-cycles gekennzeichnet, damit ihre GC-/Stress-Frametimings nicht als unveränderte Phase-3a-Baseline verglichen werden.

Chrome DevTools Protocol sammelt nach Garbage Collection H0/H5/H10/H15/H20: V8-Isolate used/allocated heap, optional ArrayBuffer/external-string backing storage sowie DOM-Dokumente/Knoten/Listener. Das ist weder gesamter Browser-/GPU-/Worker-Speicher noch ein WKWebView-Profil. Ein synthetischer Trend allein beweist keinen Leak. Ausgabe enthält absolute Proben, Deltas, strictlyIncreasingHeap als rein beschreibenden Befund und p95 der 20 Roundtrip-Laufzeiten. Keine willkürlichen Heap-/FPS-Grenzen, keine Budgetlockerung, keine User-Telemetrie. Defekte/unvollständige Pflichtmessungen oder fehlerhafte Modellwechsel bleiben fatal; fehlende optionale backingStorage-Metrik wird null statt 0.

MID_MAP_TRACE=1 schreibt einen Chromium devtools.timeline/v8/blink.user_timing-Trace ausschließlich während der isolierten Zyklen nach /tmp/mid-map-cycles-390-light-next.json. Der Trace wird auch nach einem Zyklusfehler gestoppt; CDP-Session wird per finally freigegeben. CI-Normalweg erhebt Speicherproben ohne Tracing-Overhead. Schema mid.map.runtime.fixture.v2 nennt die echte package.json-Version statt der bisher fest codierten .210. Raw-JSON bleibt in bestehenden CI-Logs und /tmp; kompakte Speicherwerte ergänzen das Step-Summary. Keine Workflow-/Secret-/Ruleset-Änderungen.

Pflichtregression scripts/test-map-memory-profile-0985214.mjs prüft 2+20 Cycles, fünf GC-Proben in richtiger Reihenfolge, wachsende/fallende Werte, fehlende/kaputte Messungen, Durchreichen von CDP-/Modellfehlern und vollständiges Browser-Wiring. Beide Baseline-Inventare verlustfrei erweitert. Bestehende Core/Heavy/Responsive/iOS/Release-Gates bleiben unverändert.

Parallelstand: RUC-Bitmap-Reparatur .213 freigegeben. Issue #305 bleibt bis zur erfolgreichen neuen echten DWD-RUC/RUC-EPS-/Pages-Freshness-Abnahme offen. Die aktuelle Repo-Synchronität allein beweist keine frischen Wetterdaten. Weitere Auditpakete: Widget-readiness/Erstfehlerdiagnostik, produktfeste GRIB-Level-/shortName-Verträge mit echten Headern, Cross-Model-/Missing-Data-Prüfungen, A11y-Kartenalternative und iOS-Simulator-Lifecycle. SEC-001 aus dem PDF war durch aktive Rulesets bereits widerlegt (.207); Schutz nicht neu/parallel umbauen.

Primärquellen: https://chromedevtools.github.io/devtools-protocol/tot/Runtime/#method-getHeapUsage ; https://chromedevtools.github.io/devtools-protocol/tot/Memory/#method-getDOMCounters ; https://chromedevtools.github.io/devtools-protocol/tot/HeapProfiler/#method-collectGarbage . Freigabe ausschließlich über Source-PR-Gate → MID Agent Source Release → serverseitiges ZIP → Installer → Worker/Pages → SHA-gebundene Stable-Promotion.

# MID v0.9.85.213 – Intensivaudit: DWD-RUC/GRIB2-Bitmap-Reparatur

## Gesicherte GitHub- und Produktivbasis
Verifizierter Ausgangsstand `main = mid-stable = e71171c0d477c0fbef51e17e9c21c399525ec94d`, v0.9.85.212. Vollständig freigegeben über PR #306 und Release-Installer. Neuer Branch: `chatgpt/v0.9.85.213-ruc-bitmap-recovery`. Offener Produktionsblocker #305.

## Ursachennachweis (nicht aus bloßer Vermutung)
Reale GitHub-Action-Protokolle, u.a. Run 37876446456: Pro `T_2M`-Vorhersageschritt genau 542.040 dekodierte Werte, Kelvin, davon 16.968 konstante 9999-K-Einträge (ca. 3,13 %) entlang des ICON-D2-RUC-Gitterrandes. Der bisherige Parser übernimmt ecCodes-`values` vor Prüfung des GRIB2-Section-6-`bitmap` direkt; seine Kelvin-Umrechnung macht daraus 9725,85 °C. Die korrekte Validierung `validate_core_fields` stoppt deshalb fail-closed mit `temperature_2m: decoded values exceed physical/semantic bounds`. Mehrere Stundenläufe nach v0.9.85.212 reproduzieren dieselbe maschinenlesbare Ursache.

## Umsetzung und semantische Grenzen
`tools/ruc/grib_bitmap.py`: Die GRIB2-`bitmapPresent`- und tatsächliche ecCodes-`bitmap`-Maske wird verbindlich angewendet, bevor die Originalwerte interpretiert oder in Einheiten normiert werden. Bitmap-Bit 0 = nicht definiertes Gitterelement (IEEE NaN). Bitmap-Bit 1 = physikalischer Modellwert. **Alle Zellen und ihre Indizes bleiben erhalten; keinerlei Kürzung, Neugitterung oder Maskenraten**. Unbekannte Indicator-Werte, fehlende/anders lange oder mehrwertige Bitmaps führen zu `MeteoIntegrityError`. Bloßer Zahlenwert 9999 ohne authentische Bitmaske darf nicht stillschweigend eliminiert werden. Auf dieselbe Funktion gehen die Kernfelder, optionalen Rapid-/Phasendaten, RUC-EPS-Member und Koordinaten-Grib. Unmaskierte CLAT/CLON bleiben unverändert.

Im bestehenden Wire-Packer werden IEEE NaN als der bereits etablierte Int16-Wert -32768 (oder bei EPS der UInt16-Wert 65535) kodiert. Unmaskierte, real falsche physikalische Werte werden weiterhin abgewiesen. Der bisherige WMO-/DWD-Phasenvertrag, native DWD-Signatur-/Provenienzprüfer, meteorologische Grenzwerte, fehlende Provider-Backups und alle RUC-Wire-Schemas bleiben unverändert.

## Tests und Abnahme
`tools/ruc/test_grib_bitmap.py`: produktive echte Zellanzahl und fehlender Randbereich, Kelvin->°C nur für gültige Zellen, native Grid-Ausrichtung, Wire-NODATA, fehlende/kaputte/mehrwertige Bitmap, kein unerlaubtes Erraten fehlender Daten bei unmaskierten 9999, physikalischer Validator weiterhin fail-closed. Die Tests sind in den verbindlichen Python-Testpfad `tools/ruc/test_fetch_resilience.py` eingebunden. Nach grünem vollständigen Source-Gate/Installer **muss ein echter vollständiger DWD-RUC-/EPS-Job inklusive Pages-Free-Veröffentlichung und Worker-Datenaktualität grün nachgewiesen** werden; vorher Issue #305 nicht schließen und niemals behaupten, die gesamte Produktionspipeline sei wiederhergestellt.

## Audit-Fortsetzung
Offene Schritte: vollständiger RUC-Probelauf samt Maskenquoten/Panel-Freshness; dokumentierte DWD-Parameter-/Level-Matrix; Karten-Timeline-Traces, mehrfache Performance-Proben, mobile Barrierefreiheit, iOS-WKWebView-Simulator. Bestehende Risiken #270 (Audit-Dependencies), #246 (alte einzigartige Branches), #176 (Agent-Broker) und PR #252/#253/#260 unverändert getrennt.

## Referenzen
DWD ICON-Modellbeschreibung https://www.dwd.de/SharedDocs/downloads/DE/modelldokumentationen/nwv/icon_d2/icon_d2_dbbeschr_aktuell.pdf ; DWD ICON-D2-RUC Open Data https://opendata.dwd.de/weather/nwp/v1/m/icon-d2-ruc/ ; dokumentierter Bitmap-Befund mit 16968 Randzellen https://github.com/KnownStormChaser/master-weather-model-list/blob/main/models/nwp_models/regional/germany/icon-d2-ruc.md .


# MID v0.9.85.212 · Intensivaudit: Karten-Themekontrast und RUC-Provenienz

Source-of-truth-Basis: main = mid-stable 055a6ead7b76b68751079935f1994fc8984bf534 (v0.9.85.211); ausschließlich chatgpt/v0.9.85.212-dark-map-ruc-audit für den Source-PR.

## I. Dark Mode, Accessibility, mobile Darstellung

Screenshotbefund: Die direkte Karten-Terminsteuerung in RadarPanel.tsx besitzt in UnifiedWeatherMap.css die Regel background:var(--card,#fff). --card ist nicht kanonisch definiert und der weiße Fallback produziert unter dunklem Theme ein kontrastarmes, sehr helles Formular mit nahezu unsichtbarer Schrift. Appweite native MID-Farbvariablen --surface, --text und --border statt nicht definiertem --card oder hartem Weiß; korrekter nativer color-scheme und Option-Hintergrund, sichtbarer Tastaturfokus, 44px Ziele, mobil <=430px Aufteilung des zusätzlichen Aktuell-Buttons auf volle Zeile. Keine JS-Zeit-/Radar-/Datenänderung.

Tests: scripts/test-map-direct-time-theme-0985212.mjs schützt CSS/Fokus/Touch-/Theme-Vertrag als Core-Regression. Die bestehende echte Chromium-/MapLibre-Matrix scripts/verify-unified-map-browser-0985167.mjs prüft für alle dort verfügbaren Viewport-/Light-/Dark-/Designkombinationen Hintergrundhelligkeit und WCAG-AA-Textkontrast >=4,5 der aktivierten Bedienelemente sowie bereits vorhandene 44px und Overflow-Prüfungen. Browserwerte stammen aus synthetischer kontrollierter Kartenfixture, nicht aus Telemetrie realer Nutzender.

## II. RUC-Integrität: ISSUE #305, bewusst offen

Lauf https://github.com/MeteoMartini/MID/actions/runs/37853501210 scheitert in prepare weiterhin an unplausibel dekodiertem T_2M; Fail-Closed-Meteorologie-Gate bleibt unverändert. Bis zur nachgewiesenen Ursache darf kein ungeprüfter Fallback in die produktive RUC-Veröffentlichung einfließen. tools/ruc/build_ruc_bundle.py protokolliert nur bei Validierungsfehlern begrenzte per-Lead-Provenienz: GRIB-Dateiname, UTC-Valid-Time, Einheiten, Anzahl und Zahl nicht endlicher Zellen, Minimum/Maximum nativer und normierter Werte, Anzahl außerhalb des bestehenden °C-Sanity-Bereichs. Kein Rohfeld, kein Geheimnis, kein vollständiges GRID-Logging; Validator wird weder abgeschwächt noch abgefangen, sondern Fehler bleiben fatal. tools/ruc/test_temperature_decode_audit.py prüft Kelvin->C, C unverändert, NaN/Sentinel-Aggregat und fortdauernde Fehler bei physikalisch ungültigen Temperaturen. Der nächste echte DWD-Preprocessing-Run muss erst Ursache (Encoding, Bitmap/Missing, Unit) belegen. Anschließend separate validierte Korrektur, erneuter vollständiger RUC-Run und Pages-Snapshot. Issue NICHT abschließen ohne Produktivbeleg.

## III. GitHub offene Arbeit geprüft, nicht überstürzt gelöscht oder gemergt

- #305 offen: blockierter DWD-RUC-Produktivlauf; .212 liefert Diagnostik, keine Ursachenbehauptung, keine Gate-Umgehung.
- #270 offen: nächtliche Revision Audit failure; Beispiel https://github.com/MeteoMartini/MID/actions/runs/37764900622 bestätigt npm-audit-Befunde uuid@7.0.3 sowie source-map-js@1.2.1. Auch im verifizierten .212-Lockfile vorhanden; @capacitor/cli steht bereits bei 8.5.2. Abhängigkeitsgraph, Advisory-Fix und CI-/iOS-Kompatibilität müssen separat nachgewiesen werden. Keine npm-audit-Ausnahmeregel.
- #246 offen: zwei alte Branches mit einzigartigen Commits, niemals ohne SHA-verifizierte Sicherung löschen.
- #176 offen: Agent-Ref-Broker ist bewusst ein dauerhaftes Steuer-/Integrationsobjekt.
- PR #260 (13 Dependencies), #252 (pako v2→v3, API-/Export-Breaking-Change) und #253 (Wrangler Action) sind aktuell mergeable=false, z. T. veraltet. Keine automatische Versionserhöhung, Rebase, manuelle Merge-Umgehung oder Workflow-Änderung. Nach getrennten Kompatibilitäts-/Security-Tests und neuem Stable-Base-Check über normalen Source-PR einarbeiten.

## Auditfortsetzung und Freigabe

Map-/Timeline-Performance-Baseline aus .210 bleibt unverändert (Phase 3a); weiterführende Profile für Speicher und Interaktion (3b) erst aus reproduzierbaren Chromium-Traces, getrennt von diesem UI-/RUC-Blocker. Vollständiges Source-PR-Gate, deterministische Regressionen, Heavy-Map/Responsive, Python/RUC, Security/Build/iOS, Agent-Automerge, Release-ZIP, Installer und Worker/Pages- sowie SHA-geprüfte Stable-Promotion bleiben verbindlich.


# MID v0.9.85.211 – Sonderprüfung WMO-Niederschlagsphase und Kurzfrist-Zeitbezug

SHA-verifizierte Basis: main = mid-stable fb289175c0eb4e414900d6d645f9c5ed814c5d44 / v0.9.85.210. WMO-4677 Codes 66/67 stehen für gefrierenden Regen, 68/69 für Regen und Schnee gemischt. Positive Lufttemperatur allein schließt gefrierenden Regen bei kalter Oberfläche nicht aus. MID prüft die modellierte warme Oberfläche >=1,5 °C sowie T2m >=1,5 °C und Feuchtkugel >=1 °C als konservative Plausibilitätskorrektur nur von unbestätigten Forecast-Codes auf gewöhnlichen Regen. Fehlende oder kalte Bodenwerte bleiben vorsichtshalber kein Widerspruch. Ein bei positiver Luft-/Feuchtkugeltemperatur verbleibendes unbestätigtes Gefriersignal wird als möglich formuliert, ohne den WMO-Code oder vorhandenes Gefährdungssignal zu verfälschen. Diese MID-Fachgrenzen sind keine amtlichen DWD-Warnschwellen. Beobachtete Phänomene werden niemals umklassifiziert. FZRA und FZDZ verwenden ein eigenes Glätte-Oberflächenzeichen statt der mit Schneeregen verwechselbaren Schneekristallmarkierung; Schneeregen bleibt Regen plus Schneekristall.

Die Kurzfristüberschrift referenziert nun dieselben aggregierten vorwärts gerichteten Stundenintervalle wie das sichtbare Wetterprofil, bevorzugt innerhalb der ersten betroffenen Stunde den frühesten tatsächlich nassen nativen 15-min-Slot und verwendet dessen Intervallbeginn. Wahrscheinlichkeit bei 0 mm ist kein sicherer Regenbeginn. Die 90-min-Kacheln zeigen keine redundante Wolken-%-Zeile; der wissenschaftliche Skybarwert und seine Erklärung bleiben erhalten. Regressionen: scripts/test-precipitation-shortterm-coherence-0985211.mjs und aktualisierter C23-Sunset-Browsercheck; bestehende Mountain-Kälte-/Regen-Gates unverändert. Kein neuer Datenprovider, kein Release-Shortcut, keine Workerfunktion oder Kosten. Vollständige Source-/Installer-/Pages-/Stable-Gates erforderlich.

Primärquellen: https://confluence.ecmwf.int/spaces/ECC/pages/45023980/WMO%2B6%2Bcode-flag%2Btable ; DWD https://www.dwd.de/DE/leistungen/pbfb_verlag_vub/pdf_einzelbaende/vub_16_gesamt_pdf.pdf?__blob=publicationFile&v=5 .

# MID v0.9.85.210 · Intensivaudit – Schritt 3a: automatische Karten-/Timeline-Laufzeitbaseline

Verifizierte Basis main = mid-stable 722ca3b96f142e96cb6e99d1b7038f48d6386fec (v0.9.85.209). Das bestehende echte Headless-Chromium-QA-Szenario scripts/verify-unified-map-browser-0985167.mjs erhält optionale, nichtproduktive PerformanceObserver- und requestAnimationFrame-Proben. In allen vorhandenen isolierten Heavy-Karten-Shards werden 390px/Tablet/Desktop sowie weitere bisherige Viewports, Light/Dark und klassisches/modernes Design durchlaufen, sofern bereits vom Shard unterstützt. Gemessen werden Zeit bis zum initialen interaktiven Kartenstatus, p95 der aufgezeichneten Frame-Abstände, Anzahl/Maximum der Long Tasks und die im Browser verfügbare letzte LCP-Zeit. Vor vorhandenen Page-Reloads und am Testende werden einzelne Phasen snapshotsicher ausgewertet. Messwerte stehen als schema-versionierte JSON-Datei /tmp/mid-map-runtime-baseline-<shard>.json und als Tabelle im jeweiligen GitHub-Step-Summary. Neue nichtproduktive Statistik-/Browser-Probe-Module: scripts/lib/mapBaselineStatistics.mjs und scripts/lib/mapBrowserPerformanceProbe.mjs; der Pflichtregressionstest scripts/test-map-runtime-baseline-0985210.mjs prüft positive/negative Perzentilfälle und das reale QA-Wiring.

Abgrenzung: Dies ist eine **synthetische Vite-/MapLibre-Karten-Fixture mit simulierten Daten** unter CI-Last, nicht Real-User-Monitoring und nicht die Feldmetrik p75-LCP/INP/CLS. Daher werden keine unkalibrierten Laufzeitgrenzwerte oder feste FPS-Regressionsgates eingeführt; bestehende harte Bundlesicherheitsbudgets aus MID_PERFORMANCE_BASELINE.json und sämtliche Produkt-/Source-/Installer-Gates bleiben unverändert. Der nächste Audit-Schritt vermisst nach mehreren stabilen CI-Durchläufen die Varianz, erstellt gegebenenfalls Chrome-Trace/Heap-Baselines für 20 Karten-Zyklen und prüft Preview-Lighthouse und mobile/Native-WKWebView separat. Keine kostenpflichtigen Angebote, keine Datenquellen-/Workerlogik- oder UI-Änderungen.

Freigabe ausschließlich über Source-PR-Gate → Bot-Merge → serverseitiges Release-ZIP → Installer → Worker-/Pages-Prüfung → Stable-Promotion.

# MID v0.9.85.209 · Intensivaudit – GRIB2-Metadatenhärtung (Schritt 2b)

Verifizierte Basis main = mid-stable 419da8d3d780a142a9b25e50ae6e210be06acddb (v0.9.85.208). GRIB-Herkunft in tools/ruc/grib_metadata.py, fetch_and_build_ruc.py und build_ruc_bundle.py gehärtet: GRIB-Edition 2 und WMO-Ursprungszentrum 78 (DWD/Offenbach) aus der tatsächlichen Nachricht prüfen, Herkunft und Initialisierung der dynamischen deterministischen, Rapid-, optionalen und Ensemble-Felder sowie deren Gültigkeitszeiten kontrollieren. Innerhalb jedes logischen Produktparameters bleiben GRIB discipline/parameterCategory/parameterNumber/typeOfLevel/level/gridType/numberOfPoints invariant; doppelte Rapid-Zeiten oder EPS-Member-Zeitpaare werden abgewiesen. Koordinaten-GRIBs prüfen Edition und Zentrum, bleiben aber aufgrund ihrer Zeitunabhängigkeit von der strikten Run-Initialisierung ausgenommen.

Neue ecCodes-Positiv-/Negativtests in tools/ruc/test_grib_metadata.py sind im bereits verbindlichen Source-PR-Python-Testpfad aufgenommen. Die meteorologischen Plausibilitäts-, Taupunkt- und Niederschlagsakkumulationsprüfungen von v0.9.85.208 bleiben vollständig erhalten. Kein Parameter darf allein aufgrund des Dateinamens als fachlich richtig gelten. Weiter offen bleiben produktfeste shortName-/Level-Abbildungen nach vollständiger Verifikation echter DWD-v1-Produktheader: die jetzige Signaturprüfung erkennt innerhalb eines Produkts gemischte Felder, aber keine vollständig gleichförmig falsch etikettierte Produktfolge. Kein Sicherheits-/Workflow-/Secret-Umbau und keine neuen Kosten.

Quellen: WMO Manual on Codes 306 (gültig 01.06.2026) https://community.wmo.int/site/knowledge-hub/programmes-and-initiatives/wmo-information-system-wis/about-manual-codes-volume-i2/latest-version ; DWD GRIB2 https://www.dwd.de/DE/leistungen/opendata/help/modelle/grib2_erlaeuterungen.pdf?__blob=publicationFile&v=1 ; DWD ICON-D2-RUC v1 https://opendata.dwd.de/weather/nwp/v1/m/icon-d2-ruc/p/ . Freigabe ausschließlich über Source-PR-Gate, Agent-Merge, serverseitiges ZIP, Installer, Worker/Pages und Stable-Promotion.

# MID v0.9.85.208 · Intensivaudit – DWD/RUC-Integrität (Schritt 2)

Verifizierte Basis main = mid-stable: 2f3cd42a56fbf6625a901d68329d388889350754 / v0.9.85.207. Neuer fail-closed-Guard in tools/ruc/meteo_integrity.py; GRIB-Datenlauf-Initiierung und doppelte deterministische Gültigkeitszeiten werden im frühzeitigen Core-Coverage-Check geprüft. Vor der verlustbehafteten Serialisierung werden physikalische Grenzen der RUC-Kerndaten und der Taupunkt/Temperatur-Vertrag geprüft. Vor allen kumulativ→Intervall-Umrechnungen werden echte negative Sprünge unter -0,05 mm erkannt, statt wie bisher ohne Befund auf 0 mm gekappt zu werden (Deterministik, Rapid/Phase, EPS). Der numerische Toleranzwert ist ausdrücklich ein MID-Validierungs-Gate und keine amtliche DWD-Warnschwelle. Test: neue Offline-Positiv-/Negativfälle einschließlich extremer gültiger Temperaturen und fehlender Daten in tools/ruc/test_meteo_integrity.py, automatisch zusammen mit dem bereits Source-Gate-pflichtigen tools/ruc/test_fetch_resilience.py. Keine neue Quelle, kein Secret, keine UI-Änderung und keine abgeschwächten Release-Gates.

Offene weitere Schritte des Audits: strikter GRIB-Parameter-/Level-Metadatenvertrag auf Basis real nachgewiesener DWD-Felder, granulare Missing-Data-Quoten, Cross-Model-Prüfung, Performance-Baselines und iOS-Simulator-Smokes. Release ausschließlich nach vollem Source-Gate, Server-ZIP, Installer, Worker/Pages und Stable-Promotion.

# MID v0.9.85.207 · Intensivaudit – Build-Identität

Intensivaudit-Schritt 1: Der Auditbefund, main/mid-stable seien ungeschützt, war falsch. GitHub bestätigt aktive MID Production Branch Guard, MID Stable Protection mit Pflichtcheck und gesonderte Agent-/Replit-Regeln. Verifizierte Basis: main = mid-stable = 541ba0b77dc932288bf68ab78b0efd7925045a47 (v0.9.85.206). Nach dem Vite-Build erzeugt scripts/write-build-identity.mjs eine dist/mid-build-identity.json mit exakter Quellversion, möglicher Quell-SHA, Build-UTC, Anzahl Dateien und SHA-256 der gebauten Assets. Fehlerhafte Versionen oder fehlende JavaScript-Assets stoppen den Build. Neue Positiv-/Negativregression scripts/test-build-identity-0985207.mjs. Build-Quell-SHA, Release-Packaging-SHA und Stable-Promotion-SHA sind verschiedene vertragskonforme Identitäten und dürfen nicht blind gleichgesetzt werden. Wetter-, Daten-, Release- und Sicherheitsfunktionen bleiben unverändert.

# MID v0.9.85.206

Die 90-Minuten-Kacheln zeigen zusätzlich den Bewölkungswert ihres jeweiligen Zeitschritts. Die Skybar erklärt ihre Schwellen und die breite Nacht-Hinterlegung. Vorhandene Werte unter den Bandschwellen bleiben als solche erkennbar und werden nicht als fehlende Daten bezeichnet.

Fehlende Bewölkungswerte werden in gemeinsamen Wetterzeichen, Periodenmitteln, Wolkenschichten und Kurzfrist-Fallbacks nicht mehr als 0 % ausgewertet. In den 3-Stunden-Details folgen trockene Wetterbeschreibung und Wetterzeichen nun demselben Bewölkungsmittelwert. Das 24-h-Profil besitzt einen korrigierten Erklärungstext und kompakter angeordnete Hinweise auf breiten Bildschirmen. Echte Nullwerte, Bandfarben und meteorologische Schwellen bleiben erhalten.

Verifizierte Basis: main = mid-stable = 5abd95581f254b2612d94612dcab73b6c8ba75ce (.205). Details: docs/implementation/MID_C23_CLOUD_AUDIT_0.9.85.206.md. Synoptikhorizonte und sämtliche Veröffentlichungsgates bleiben erhalten.

# MID v0.9.85.200 · C21

Europäische native Synoptik, 60-kt-Windpfeile, Theta-E-Stufen/RH700-Konturen, budgetabhängige zusätzliche Termine und gepufferte Bildwechsel einschließlich OPERA und 250-m-Radar. Parallele Widget-Korrektur aus .199 erhalten. Details: docs/implementation/MID_C21_SYNOPTIC_BUFFERING_0.9.85.200.md. Bestehende Release-/Datenbudgets unverändert.

# MID v0.9.85.199 · kompakter Kurvenwidget-Kopf

Basis 36110a193328b0e4a5978e742e3768a8fcd9664f (.198). Widget-Präsentation blendet nur die zwei redundanten Unterüberschriften aus; App-Prognose bleibt erhalten. Bestehende Pflichtregression erweitert, keinerlei Wetterlogik-/API-/Sicherheitsänderung. Dokumentation: docs/implementation/MID_C21_CURVE_WIDGET_COMPACT_0.9.85.199.md.

# MID v0.9.85.198 · MID-C21 Karten und RUC-Veröffentlichung

Basis b27bd472e228c59a9cc36e7305307b775623288a (.197). Details: docs/implementation/MID_C21_MAP_RUC_0.9.85.198.md. Bestehende Source-/Installer-Gates bleiben verbindlich.

## MID v0.9.85.197 · 2026-10-08 · MID-C21 Wetterkarte, Synoptik und iPad-Rückkehr

- Basis main = mid-stable = 55bde6e4ed20127a32403c54546379fb6e86943c (.196). SHA-gebundener Replit-Handoff 6e4d3fc39ace83ae17c3b5a71e6ed9c06a902030, Tree ca4fbd13f4b6337262ee854b992ec6b1cad5f847, grün in Run 37694186641. Replit lieferte lokale Vorschläge ohne belastbaren ursprünglichen Git-Commit; ChatGPT rekonstruierte und verifizierte die neun UI-Dateien auf Stable. Zusätzliche UI-QA-Korrektur erhöht nur das innere Browserlimit 480 auf 900 Sekunden bei unveränderten 24 Fällen.
- Current verwendet einen scoped kanonischen CSS-Layer und echte DOM-Reihenfolge Skybar → gemeinsame Temperaturkurve → Zeitachse. UTCI, Werte, Messwertpriorität und Einheiten unverändert. Sichtweite weiterhin über Mehr. Alte .169-Cascade-Golden-Deklarationen bleiben separat geschützt.
- OSM country/admin2 und region/admin4 disjunkt; maritime Polygone ausgeschlossen. Entfernte Boundary-Fallback- und Natural-Earth-Canvas-Doppelgeografie; fünf persistente Touch-Optionen. Untere Vektorkarte zeichnet nur Land/Wasserflächen.
- Immutable RUC-Pages-Pfad wie DWD-Niederschlagssummen: ecCodes prüft alle sieben GRIB-Komponenten (IFS acht inklusive q/T700), Lauf/Termin/Level/Einheit/regular-grid. Downloads parallel, ecCodes durch Lock geschützt. ICON-D2 0,02°, ICON-EU 0,0625°, veröffentlichte GFS/IFS 0,25°-Raster. Neun vollständige Termine je Modell, keine Mischung von Läufen; fehlende Quellen explizit nicht verfügbar.
- Native Contourpy-Konturen aus vollständigen maskierten Rastern, moderate 0,65-Rasterzellen-Glättung, GH500 4 dam schwarz, MSL 4 hPa weiß, RH700 ab 60% blau gestrichelt; echte U/V300-Pfeile. Bitmap-Missing null/transparent. Bilineares Mercator-Theta-E-Rendering mit höherer Pixelauflösung behauptet keine höhere Modellauflösung.
- Bolton-1980-LCL korrigiert im gemeinsamen Theta-E-Erzeuger. Vier unabhängige MetPy-1.7.1-Referenzen: maximal 0,3 K Toleranz für unterschiedliche Bolton-/Ambaum-Sättigungsdampfdruckformeln. Alte inkonsistente Formel wich bei warm-feuchter Luft um mehrere K ab. Keine Änderung am operativen Punkt-Forecast.
- Frontend prüft Indexdigest, Bytes/SHA, sichere Dateinamen, vollständige aktuelle Termine, Einheiten, native Achsen, Masken, Konturlevel und Windvektoren. Höhenlinien allein ohne Theta-E-Probe. Gleiche bereits SHA-geprüfte immutable Zyklen können wiederverwendet werden; neue Zyklen werden zuerst gesucht. Budget unverändert 900 MB.
- iPad: transienter gemeinsamer Drawer-Hook startet geschlossen, schließt bei pagehide/pageshow/visibilitychange und überschreibt keine dauerhafte Inhaltswahl. Alte More-Speicherung behält gültige Inhaltssektion; ungültige fällt auf Current zurück. Deep Links priorisiert.
- Prüfung: 28 echte Current-Browserfälle, vier wiederholte iPad-Chromium-Touchansichten, vollständige 24-Fall-Kartenmatrix und neue wissenschaftliche ecCodes-/Kontur-/MetPy-/Manifest-Regressionen. Physisches iPad/Safari nicht geprüft. Alle bestehenden Source-/Installer-/Worker-/Pages-/Stable-Gates bleiben verbindlich.

## MID v0.9.85.196 · 2026-10-07 · MID-C21 Handoff-Zeitbudget

- Verifizierte Basis: main = mid-stable = cd3f88d3852591a6375fb46701f11708d118b6f1 (.195).
- Handoff Run 37683018228 für Head 3a30e125417d990a3764df73781ca1141426360a brach nach 15 Minuten ab. Bis 900/938 Prüfungen waren null Fehler gemeldet; Build, Dependencies und geschützte Pfade bestanden.
- Ausschließlich das Zeitbudget des vollständigen npm run verify im kanonischen und aktiven read-only Handoff-Gate steigt von 15 auf 25 Minuten; der Jobrahmen bleibt 30 Minuten.
- Keine Prüfungen ausgelassen, keine Schwellen angehoben, keine Tokens/Rechte/Actions-Pins/Releasegrenzen geändert. Die bestehende Collaboration-Regression schützt nun zusätzlich den vollständigen Verify-Aufruf und das Zeitbudget.
- Die UI-Integration bleibt bis zum grünen Handoff getrennt. Danach erneute Prüfung gegen die freigegebene Stable-Basis und normaler Source-/Installer-/Worker-/Pages-/Stable-Pfad.

## MID v0.9.85.188 · 2026-10-07 · Widget-Export auf vier automatische Läufe pro Tag begrenzt

- Basis: main = mid-stable = v0.9.85.187 @ `2a8370734e98f2c9c1d6da30ad30d9ee5a87aa34`.
- Bisher: stündlicher Cron plus automatischer Release-Abschluss-Trigger plus `mid-stable`-Push-Trigger; dadurch konnten zusätzliche bzw. doppelte Renderläufe entstehen.
- Neu: genau ein automatischer Cron `17 0,6,12,18 * * *`, also 00:17/06:17/12:17/18:17 UTC.
- Automatische `workflow_run`- und `mid-stable`-Push-Trigger entfernt.
- `workflow_dispatch` bleibt für bewusste manuelle Diagnose-/Notfallläufe erhalten.
- Aktiver und kanonischer Workflow bleiben bytegleich; Regressionen schützen die Viermal-pro-Tag-Taktung und das Verbot der entfernten Zusatztrigger.
- Widgetprofile, Renderlogik, Datenlogik, Integritätsprüfung und rollierendes Downloadpaket unverändert.
- Source-Gate-Befund: Unified-Map bestand in drei Versuchen jeweils 20/24 reale Browserfälle, bevor das feste 360-s-Unterprozesslimit griff. Testabdeckung/Assertions unverändert; Zeitbudget auf 480 s Unterprozess, 10 min Heavy-Schritt und 15 min Heavy-Job erweitert, damit alle 24 Fälle tatsächlich geprüft werden.

## MID v0.9.85.186 · 2026-10-06 · Karten-Layer

- Native Linien ohne Flächenraster; tatsächliche WMS-Stile, responsive Layer-Auswahl und unabhängige Beobachtungsschalter.
- Nativer Bild-Lifecycle: direkte dekodierte Bilder statt erneutem Data-URL-fetch; verspätete Bilder nach Layer-Abwahl werden verworfen.
- Paralleländerungen .181–.185 erhalten; DNS-Token-Regression wartungsversionstauglich bei unveränderten Gate-/Least-Privilege-Prüfungen.

## MID v0.9.85.185 · 2026-10-06 · DNS- und Worker-Berechtigungen strikt getrennt

- Basis: main v0.9.85.184 @ `d35659371f48099676409f93add33c4599bf07ec`; mid-stable weiterhin v0.9.85.182 @ `34d41442de1bb8e984dedca0e786dabb5b9f5ee1`.
- Installer Run `37489510896`, Versuch 2: Worker v0.9.85.184 bestand Versionsoverride-Smoke und produktiven Smoke; der DNS-Schritt erhielt erneut HTTP 403 und rollte den Worker danach korrekt zurück.
- Ursache im Workflow: Der DNS-Proxy-Schritt verwendete noch `secrets.CLOUDFLARE_API_TOKEN` statt des separat vorgesehenen DNS-Credentials.
- Korrektur: ausschließlich der DNS-Proxy-Schritt liest `secrets.CLOUDFLARE_DNS_API_TOKEN`; Worker-Upload, Worker-Promotion und Same-Origin-Route bleiben auf `secrets.CLOUDFLARE_API_TOKEN`.
- Die drei Installer-Spiegel bleiben bytegleich und eine Regression schützt die Credential-Trennung.
- Kein Credential-Fallback, keine Erweiterung des Worker-Tokens und keine meteorologische Fachänderung.

## MID v0.9.85.184 · 2026-10-06 · www.midwx.app für Same-Origin-Workerpfad sicher proxied

- Basis: main v0.9.85.183 @ `61fc2634651b865e571496da6eaf3dd0378c760b`; mid-stable weiterhin v0.9.85.182 @ `34d41442de1bb8e984dedca0e786dabb5b9f5ee1`.
- Befund aus Installer Run `37480541081`: Worker v0.9.85.183 bestand 0-%-Smoke, 100-%-Smoke und RUC ready/fresh; die Workers Route `www.midwx.app/api/mid-worker*` wurde bestätigt, der anschließende Same-Origin-Health-Check erhielt jedoch HTTP 404.
- Ursache: Die Route war vorhanden, aber der bestehende `www.midwx.app`-DNS-Record lief noch nicht durch den Cloudflare-Proxy; deshalb erreichte der Browserpfad weiterhin GitHub Pages statt der Workers Route.
- Neuer fail-closed Schritt `ensure_www_proxy.mjs`: exakt ein bestehender CNAME `www.midwx.app`, keine parallelen A/AAAA-Records, nur `proxied=true` per PATCH. Name, Typ und Zielwert werden vor/nachher verglichen.
- Kein neuer DNS-Record, kein Record-Ersatz, keine TLS-/Zone-Settings-Änderung, keine Änderung anderer DNS-Einträge.
- Reihenfolge: bestehender www-CNAME proxied -> exakte Worker-Route -> Same-Origin-Health/RUC -> Pages -> Stable.
- Benötigte zusätzliche Cloudflare-Berechtigung: Zone:DNS Edit ausschließlich für die Zone `midwx.app`.
- Meteorologische Fachlogik unverändert.

## MID v0.9.85.183 · 2026-10-06 · Corporate-safe Same-Origin Data Plane

- Basis: main = mid-stable = v0.9.85.182 @ `34d41442de1bb8e984dedca0e786dabb5b9f5ee1`.
- Produktives `www.midwx.app` verwendet für Worker-Daten ausschließlich `/api/mid-worker`; Browser-Fallbacks auf externe Worker-Adressen sind dort gesperrt.
- DWD-/EUMETSAT-WMS, RainViewer-Tiles sowie OpenFreeMap-Vektortiles/Glyphen werden über eng validierte MID-Worker-Endpunkte ausgeliefert; kein frei adressierbarer Proxy.
- Cloudflare-Route `www.midwx.app/api/mid-worker*` wird idempotent auf den bestehenden MID-Worker geprüft/angelegt; Konflikte blockieren fail-closed, DNS/TLS/andere Routes bleiben unberührt.
- Same-Origin-Health und bei aktivem RUC zusätzlich RUC-Health sind vor Pages/Stable verpflichtend.
- Neue In-App-Verbindungsdiagnose für Datendienst, Warnungen, RUC-Health, RUC-Lauf und Radar/Satellit.
- Keine Änderung an meteorologischen Schwellen, Warnstufen oder RUC-/Radar-/Satelliten-Fachlogik.

## MID v0.9.85.182 · 2026-10-06 · Widget-Rendering gegen transiente Daten-Timeouts gehärtet

- Basis: main = mid-stable = v0.9.85.181 @ `a855f418c3fa00af40da8ccedcd2b1a7c05b02b9`.
- Reproduzierter Fehler: Widget-Workflow Run `37464695591` erzeugte acht PNGs erfolgreich und scheiterte danach bei `kuerecik-kompakt-5d-light.png` an `Wetterabruf hat das Zeitlimit überschritten`.
- Pro Widgetvariante maximal drei Render-Versuche, Capture-Zeitfenster 180 s, kurzer Backoff und Entfernung partieller Zieldateien vor jedem Retry.
- Der Job-Zeitrahmen steigt kontrolliert von 30 auf 45 Minuten; nach dem dritten Variantenfehler bleibt die gesamte Veröffentlichung fail-closed.
- Regressionstest schützt Retryzahl, Zeitfenster, Cleanup und kanonisch/aktive Workflow-Synchronität.
- Keine Änderung an Meteorologie, Widgetprofilen, Orten, UI, Karten, RUC oder SharePoint-Uploadlogik.

## MID v0.9.85.181 · 2026-10-06 · Widget-Renderer auf GitHub-Linux lauffähig

- Basis: main = mid-stable = v0.9.85.180 @ `3fe968e5127a34d2e820e0d2e367d9cfb388ca35`; keine offenen PRs beim Start.
- Reproduzierter Betriebsfehler: Widget-Workflow Run `37456137572` startete korrekt auf der Stable-Promotion und verifizierte v0.9.85.180 öffentlich gegen mid-stable, scheiterte aber beim ersten PNG an `Edge-Debuggingport wurde nicht bereitgestellt`.
- Ursache: `capture-widget.mjs` erwartete effektiv Windows-Edge; der Ubuntu-GitHub-Runner verwendet Chrome/Chromium.
- Renderer unterstützt jetzt explizites `MID_WIDGET_BROWSER`/`--browser` sowie Edge/Chrome/Chromium auf Windows, macOS und Linux.
- Linux nutzt zusätzlich `--no-sandbox` und `--disable-dev-shm-usage`; Browserstart/-exit wird überwacht und Fehler werden sofort statt erst nach Timeout gemeldet.
- Widget-Workflow führt vor dem Rendern einen fail-closed Chrome/Chromium-Preflight durch und übergibt den gefundenen absoluten Browserpfad.
- Neue Required Regression `test-widget-export-browser-runtime-0985181.mjs` schützt den plattformübergreifenden CDP-Vertrag.
- Keine Änderung an meteorologischer Fachlogik, Widget-Inhalten, Ortsmatrix, Warnungen, RUC, Karten oder Worker-Funktion.

## MID v0.9.85.179 · 2026-10-06 · Widget-Trigger gehärtet

- Basis: main = mid-stable = v0.9.85.178 @ `16c007b264599c7162bd174d03179b2a4363d7e2`.
- Befund nach .178: App-Release vollständig grün, der neu eingeführte Widget-Workflow war jedoch weder nach dem Installer noch beim ersten Stundenfenster als Lauf sichtbar.
- Ergänzt: deterministischer `push`-Trigger auf `mid-stable`.
- Beibehalten: `workflow_run` nach erfolgreichem Installer, stündlicher Cron und manueller Start.
- Neuer Regressionstest `test-widget-export-stable-trigger-0985179.mjs` schützt den Triggervertrag.
- Keine Änderung an Meteorologie, UI, RUC, Workerlogik oder Widgetprofilen.

## MID v0.9.85.178 · 2026-10-06 · Serverautomatisierung der festen Widget-PNGs

- Basis: main = mid-stable = v0.9.85.177 @ `d771d9cfaec65f6c13538a143f2c52b620c997c0`; keine offenen PRs beim Start.
- Neuer kanonischer Workflow `widget-export.yml`: Trigger nach erfolgreichem Installer-Release, stündlich Minute 17 und manuell.
- Render-Job strikt read-only; Checkout ausschließlich `mid-stable`.
- Fail-closed vor Rendering: package.json, MID_BASELINE und public/version.json müssen übereinstimmen; zusätzlich muss `www.midwx.app/version.json` dieselbe Version melden.
- `render-widget-matrix.mjs` bezieht die Matrix ausschließlich aus `src/widgetUrlExports.ts`, erzwingt exakt zwölf Varianten und validiert PNG-Signatur, IHDR-Abmessungen und SHA-256.
- Ergebnis enthält zwölf PNGs, `manifest.json` und `SHA256SUMS.txt`; zusätzlich wird ein reproduzierbares `mid-widget-export-latest.zip` samt eigener SHA-256 erzeugt.
- Actions-Laufartefakte werden 14 Tage aufbewahrt.
- Rollierende Veröffentlichung erfolgt als Prerelease `widget-latest`; Schreibzugriff ausschließlich über den etablierten MID Release Bot mit kurzlebigem `contents: write`-Token.
- Fester Download: `https://github.com/MeteoMartini/MID/releases/download/widget-latest/mid-widget-export-latest.zip`.
- Neuer `Download-MID-Widgets.ps1`: reine Windows-/PowerShell-Bordmittel, Benutzerverzeichnis als Standardziel, ZIP- und Einzeldateiprüfsummen werden vor Überschreiben validiert.
- Keine Änderung an meteorologischer Prognose-, Warn-, RUC-, Karten-, Worker- oder Widgetdarstellungslogik.

## MID v0.9.85.177 · Atmosphärische Höhengrenzen

Geografisch feste Zellwahl in Höhenabrufen einschließlich Legacy-Pfad; freie Diagnostik ohne Oberflächen-Downscaling und mit Modellgeländehöhe. Unterste Wolkenbasis getrennt von lokaler Wolkenschicht-/Sichtprüfung und lokalem LCL. Fehlende DWD-Eingaben/Profilkoordinaten bleiben unbekannt.

## MID v0.9.85.176

- Bergwetter: getrennte Tagesmaxima für Wind und Böen; fehlende Werte bleiben unbekannt.
- Dezente Wind- und Neuschneefarben in Tages-, Stunden- und Periodenansichten.
- Gleichmäßige Tablet-Spalten für Sonnenstunden; vollständige Wettertexte.
- Gemeinsame Prüfung klar warmer Gefrierregen-Prognosen mit Feuchte; kalte Böden, Beobachtungen und Grenzlagen bleiben geschützt.
- Neuschnee-Methodik transparent: Modell-Schneewasser und feste Anbieterumrechnung, getrennt von der Schneedecke.

## MID v0.9.85.175 · 2026-10-06 · Widget-Exportprofile Malatya, Kürecik und Ämari

- Basis: main v0.9.85.174, Commit c5bcdc09ae97072ec3c6b7c9fca75d8debd248a5; keine offenen PRs und keine Widget-Differenz zu mid-stable v0.9.85.173.
- Feste Exportorte: Malatya, Kürecik und neu Ämari (59,26°N, 24,20°E); Wiesbaden entfällt aus dem kanonischen Batch.
- Kanonische Profile: 7d Kurve = Wind + Niederschlag + Sonne + ECMWF; 5d Kompakt = Wind + ECMWF. Hazards sind in diesen SharePoint-Exports deaktiviert.
- Beide Profile werden in Light und Dark erzeugt: 3 Orte × 2 Profile × 2 Themes = 12 PNGs.
- Sichtbarkeiten werden explizit über die Widget-URL übertragen und können nicht durch lokale Widget-Einstellungen verfälscht werden.
- Alte direkte 5-/7-Tage-Kompakt-/Kurven-URLs bleiben lesbar; außerhalb der neuen kanonischen Profile gilt ihr bisheriges vollständiges Sichtbarkeitsverhalten weiter.
- Der bestehende CDP-Exporter wartet weiterhin auf `midWidgetReady=ready` und erfasst ausschließlich die aktuelle `.weatherwidget`-Fläche von www.midwx.app.
- Keine meteorologische Prognose-, Warn-, RUC-, Karten- oder Worker-Fachlogik geändert.

## MID v0.9.85.174

Nebel-/Dunsttexte bleiben mit den Wetterpiktogrammen konsistent. Bergwetter verwendet vorhandene Modell-Schneefallgrenzen vor der vereinfachten Höhenableitung. Temperatur und Taupunkt erreichen die bestehende Kurzfrist-Phasenprüfung.

## v0.9.85.173 · RUC-Workflow-Koordination

Pages-/Worker-Konvergenz getrennt; Health-only Upstream-Probe; später Snapshot-Guard innerhalb bestehender Pages-Sperre; eindeutige Ergebnis-Summaries. Keine Änderungen an Sperrgruppen, Zeitplänen, fachlichen Daten oder Retry-Budgets.

## MID v0.9.85.172 · 2026-10-05 · Konsolidierung und RUC-Downloadrobustheit

- Stable .170 und vollständig geprüfte .171-Source-Gate-Aufteilung mit RUC-PR #262 zusammengeführt.
- Vier begrenzte Netzwerkversuche; atomare Streambereinigung; frühe GRIB-Gültigkeitsprüfung; Offline-Tests vor RUC-Ingestion.
- Keine meteorologische Fachänderung und kein fachlicher Worker-Deploy erforderlich.
- Release bleibt bis zur erfolgreichen Vorgänger-Promotion gesperrt.

## MID v0.9.85.171 · 2026-10-05 · Heavy-Regressionen im Source-Gate isoliert parallelisiert

- Vollständiges automatisch entdecktes Testinventar bleibt erhalten und wird exakt einmal auf Core + drei Heavy-Shards verteilt.
- Native-Map-, Unified-Map- und Berg-Visual-QA laufen in eigenen GitHub-Runnern auf demselben PR-Merge-SHA mit eigenem Produktionsbuild.
- Der bestehende Required-Check ist ein fail-closed Abschlussjob; nur Core + vollständige Heavy-Matrix gemeinsam können die Freigabe erteilen.
- Installer und Deployment-Gates bleiben in diesem Build unverändert.
- Keine meteorologische Fachlogik, UI-Funktion oder Sicherheitsregel verändert.

## MID v0.9.85.170 · 2026-10-05 · Widget/Bergwetter und CSS-Konsolidierung

- Basis main = mid-stable = 9b917ed7054903df6da983ed79fe20561af45ab9 (.169).
- 74 Bergwetter-, 7 Widget- und 36 gemeinsame Darstellungsdeklarationen aus App.tsx ausgelagert; 117 Definitionen byteidentisch zur .169-Basis.
- Lokale Suspense-Adapter und typisierte Props; Memo-, Standort-, Abbruch-, Persistenz- und Widget-URL-Verträge bleiben bestehen.
- 65 geordnete CSS-Quellen mit rekursiv aufgelöstem Import werden zu einer globalen Ausgabe. 1122 frühere identische Deklarationen konsolidiert; Selektoren, Werte, Importance, Bedingungen und Kaskadenreihenfolge erhalten.
- Statische Feature- und CSS-Ladereihenfolgetests lesen die kanonischen Modul-/Manifestquellen; fachliche Assertions bleiben erhalten. Neue Integritäts-, Lazy- und Browserprüfungen ergänzen die Suite.
- PostCSS 8.5.28 als bereits vorhandene Vite-Parser-Version direkt und exakt für den Aggregate-Builder deklariert; keine Laufzeit- oder Framework-Upgrades.
- App-/Wetterkern als unverändert eager geladenes index-Bundle; WidgetGenerator und MountainWeather bleiben separate Lazy-Chunks. Haupt-JS-Budget zählt nun sämtliche index-Chunks, Grenzen unverändert.

## MID v0.9.85.169 · 2026-10-05 · Schonende Wartung und bessere Touch-Bedienung

- Basis main = mid-stable = 9fc04b670047ebe00f61ef4e6e376e4a69972b55 (v0.9.85.168); Releasepfad-Beschleunigung, gemeinsame Karte und geschützte Altmodule erhalten.
- Nur unmittelbar aufeinanderfolgende identische Selektoren innerhalb desselben CSS-Kontexts zusammengeführt; Deklarationsreihenfolge bleibt identisch.
- AppleWidgetSettings und DashboardModuleSettingsPanel mit lokalen Suspense-Grenzen lazy geladen; Typimporte bleiben ohne Laufzeitkante.
- Capacitor Core/iOS/CLI 8.5.2, Share 8.0.2 und jsfive 0.4.2; keine Major-/Framework-Updates oder Security-Overrides.
- Statische Apple-Widget-Importprüfung an beauftragte Lazy-Architektur angepasst; Rendering-/Feed-/Native-Verträge unverändert.

## MID v0.9.85.168 · 2026-10-05 · Releasepfad ohne Gate-Abstriche beschleunigt

- Vollständige Regression-Suite bleibt erhalten; konservativ read-only erkannte Tests laufen mit begrenzter Parallelität, alle risikobehafteten Tests seriell.
- Gate/Auto-Release/Installer verwenden flache Snapshots; nur ein echter main-Race lädt im Installer die vollständige Historie nach.
- Pages-Artefakt wird parallel zum Worker-Gate vorbereitet; Veröffentlichung selbst bleibt strikt nach grünem Worker-Gate.
- Stable-Promotion verwendet SHA-genaue GitHub Compare/Refs-API, `force=false` und finale Ref-Verifikation statt eines vollständigen Git-Checkouts.
- Keine meteorologische Fachlogik, UI-Funktion oder Sicherheitsfreigabe wurde reduziert.

## MID v0.9.85.167 · 2026-10-05 · MID-C17 gemeinsame Wetterkarte

- Basis main = mid-stable = a40e2fbc12ea4c24b206e4904c3f03a3293fadc6 (.166); keine Replit-, Workflow- oder Governance-Änderung.
- Ein lazy/memoisiertes MapWorkspace mit unabhängigen Rasterlayern; shared MapLibre lässt optionale leere Stilfelder weg und bündelt Canvas-Repaints ohne Render-Starvation.
- Native Felder behalten SHA256-, Größen-, Lauf-, Raster- und Einheitenschutz. Summen werden auf Anfrage validiert; WMS nur aus freigegebenem Katalog mit bestätigtem Termin, Lauf und Druckfläche.
- Historische Trennungs-/Importassertionen werden durch Ein-Karten-Verträge ersetzt; numerische, Export- und Zeitwahrheitsprüfungen bleiben erhalten. Neue Pflichtregression mit zwölf echten Browser-Viewport-/Themefällen.

## MID v0.9.85.155 · 2026-10-03 · Reale ICON-EPS-Mitglieder für Tag 3–7

- Live nachgewiesen: HTTP 200 ist kein Nachweis auswertbarer Daten. Globales Mean-Modell liefert rain_spread, gust/spread und snowfall_spread vollständig null. Seamless-Mean liefert ebenfalls keinen rain_spread.
- Kanonischer Worker-/Browserpfad fordert 40 tatsächliche ICON-EPS-Seamless-Mitglieder an; Mittel und Populationsstreuung werden nur aus mindestens 32 endlichen Mitgliedern berechnet. Keine Übernahme von null als Nullwert.
- Tagesperioden bleiben erhalten, wenn mindestens eine Wettergefahr mindestens 65 % des Rasters vollständig abdeckt. Jede Gefahr erfordert separat denselben vollständigen 24-h-/Rastervertrag. Fehlende Böen werden ausdrücklich als Datenlücke dargestellt; Karte und Entwarnung sind dann ausgeblendet.
- Historische .151/.154-Regressionen an bewusst korrigierten Request-/Fixturevertrag angepasst; alle Schwellen-, Cache-, Abbruch-, Provenienz- und Fehlerassertionen erhalten. .154-Versionprüfung gilt ab ihrer Einführung auch für Wartungsreleases.
- Neue Regression mit realer API-Antwort als Fixture sowie Mitgliedsminimum und fehlenden Zeitfenstern. Keine CI-/Releasekonfiguration geändert.

## MID v0.9.85.154 · 2026-10-03 · Extremwetter-Langfristpfad gegen API-Tageslimit gehärtet

- Live-Reproduktion des Screenshots: produktiver `dach-extreme-outlook?range=extended`-Pfad lieferte HTTP 502 mit `Daily API request limit exceeded`; die verwendete ICON-EPS-Mean-Anfrage selbst wurde separat mit HTTP 200 verifiziert.
- Worker bleibt der bevorzugte Datenweg. Bei Worker-/Open-Meteo-Ausfall nutzt Tag 3–7 nun dieselbe kanonische `dachExtendedExtremeOutlookData`-Logik als Browser-Direktpfad.
- Separater persistenter Langfristcache: 3 h frisch, bis 24 h als Stale-Fallback. Ein erkanntes zentrales Tageslimit wird bis zum nächsten UTC-Tag gemerkt, um Wiederholungsfehler zu vermeiden.
- Worker-Fachcache und Cloudflare-Upstreamcache für die ICON-EPS-Langfristfelder auf 6 h angehoben; die DWD-ICON-EPS-Schwellen-, Zeitfenster- und Gefahrenlogik bleibt unverändert.
- Neue Regression `scripts/test-extreme-outlook-extended-resilience-0985154.mjs` prüft Quell-/Aggregatgleichheit, Cachevertrag, Fallback-Reihenfolge sowie die vollständige direkte Tag-3–7-Berechnung mit 169 Stunden Mean/Spread.

## MID v0.9.85.153 · 2026-10-03 · Warnungsseite und Extremwetter-Langfristpfad

- Verifizierte Basis: `main == mid-stable == 1cceaf812fa1491c687d8552a69762a1d263bdb3` (v0.9.85.152).
- Warnzentrum: redundanten, großflächigen Warnhorizont-Absatz entfernt; vorhandene Warn-/Hinweisstruktur unverändert.
- Extremwetter: Range-Router korrigiert (`u.searchParams` statt nicht definiertem `url`); produktive Worker-Aggregate aus den kanonischen Worker-Fragmenten neu erzeugt.
- Erweiterter Bereich maskiert interne Laufzeitfehler und liefert bei echtem Ausfall nur eine nutzergeeignete Meldung. Abbruchsemantik bleibt erhalten.
- Neue Regression: `scripts/test-warning-extreme-regression-0985153.mjs`; Schwellen, meteorologische Logik und Warnklassifikation unverändert.

## MID v0.9.85.152 · 2026-10-03 · MID-C13 Skybar-Intervallkonsistenz

- Basis main = mid-stable = d6d7e0e5d5f6fb20a0e3dbaaf2351ed93c1857bc. Kontinuierliche 24h-Skybar erhält dieselben Viertelstunden wie 90 min; stündliche Diagramme/Quadrate bleiben.
- Null-/Leerzustände sind keine Nullwerte. Ausführbare Regression prüft Farben/Dicken und echte Nullwerte; historische Stundentokenassertion an explizit geänderten Streifenvertrag angepasst.
- Replit-Bestandsabfrage Timeout; kein ungeprüfter Import. Keine Änderungen an Schwellen, Kalibrierung, CI oder Worker-Fachlogik.

## MID v0.9.85.151 · 2026-10-03 · Gestaffelte Warnhorizonte und regionaler Langfristausblick

- Basis main = mid-stable = 0d9205720c177243a2dec3f4f8169216cc620162 (.150); keine Überschneidung mit offener Agent-PR.
- Gemeinsame Vorlaufbezeichnung für Warnzentrum, Tagesansichten und Ensemble; bestehender Stundenauflösungs-Schutz bleibt erhalten.
- Separater Worker-Langfristcache und grobes Raster; Regen/Schnee ausschließlich vollständige 24-h-Summen. EPS-Prozentwerte unkalibrierte Näherungen. Keine langfristige Konvektions-/Eisregendiagnostik.
- Neue Laufzeitregression prüft 48–168 h, Schwellenfenster, Herkunft und Fehlerzustand bei fehlenden Feldern. Historische 24-h-Erwartungen bewusst auf neuen beauftragten Vertrag angepasst.

# v0.9.85.150 · iOS Bottom-Bar-Verankerung

Aus veröffentlichter .149, e6386ca6ed8fbab563261e7b78a96ea15e015c17. Narrow-iOS-Dokumentanker hält die bestehende Body-Portal-Navigation am sichtbaren unteren Rand; stale VisualViewport.offsetTop wird geometrisch begrenzt. Safe-Area und Desktop-/Tablet-Regeln unverändert. Browsermatrix ergänzt echten Bottom-Gap sowie Scroll-/Resize-/Keyboard-Rückkehr. Keine meteorologische Logik oder empirische Kalibrierung verändert. Details: docs/implementation/MID_BOTTOM_BAR_ANCHOR_0.9.85.150.md.

# v0.9.85.149 · Runde Kartenskalen und temporäre Ortswerte

Verifizierte .148-Basis c578a947e02a6d06638870d5d762c16ecb9be8bf. Runde Grenzen in der ausgewählten Einheit, gemeinsam für Raster/Legende/Export. Temporäre geografische Portal-Abfrage schließt nach sechs Sekunden oder bewusster Außen-/Karteninteraktion; keine dauerhaften Ortswert-Popups. Favoritenzustand und Exportfortschritt vereinheitlicht. Details: docs/implementation/MID_MODEL_MAP_PROBE_0.9.85.149.md.

## v0.9.85.148 · MID-C12 Modellkarten-Einheiten und Wertebereich

- Verifizierte Ausgangsbasis .147: main = mid-stable = e28fdd42a3e68decf4b2671d3cd71751a3e711af. Paralleländerungen .146/.147 erhalten; Abhängigkeiten, Budgets, CI- und Datenpublikationsregeln unverändert.
- Unveröffentlichte .148-Parallelarbeit e3d9f7ac2567b66bfbd0f769ffc5fa5d415eb5fb abgeglichen: begonnene Einheitenweitergabe vollständig zusammengeführt, Navigation-Portal erhalten und mit neutralem Namespace-Wrapper für bisherige mobile/Desktop-Stile sowie Forecast-Höhenmessung abgesichert. Ursprünglicher Branch bleibt unangetastet.
- Eine kanonische Windumrechnung für Karten, Favoriten, Popups, Legenden und PNG/SVG; Rohfelder bleiben unverändert km/h. Nicht unterstützte Roh-Einheiten werden abgewiesen.
- Ein gemeinsamer kontinuierlicher sRGB-Farbkern für Raster/Legenden/Exports. Relative Wertebereichsskala erfasst alle gültigen Feldextrema ohne Quantilabschneidung; feste Skala für Vergleiche und Animation. Konstante Felder ohne künstlichen Kontrast.
- Kategoriale Wettercodes unverändert diskret; trockene Niederschlagszellen transparent, fehlende RADOLAN-Zellen grau. Originale WMS-Bilder behalten ihre Anbieterpalette; standardisierte Windfiedern erhalten umgerechnete Erklärung.
- Bestehende Pflichtregression um vier Windeinheiten, Skalen-/Exportgleichheit, kontinuierliche Anker und responsive echte Kartenansichten erweitert. Der bestehende Summen-Testloader bündelt die neue Modulabhängigkeit statt einer isolierten data:-Transpilation; sämtliche fachlichen Assertions bleiben erhalten.
- Ungültige Replit-Dormant-Testausnahme nicht übernommen, kein unfreigegebener Handoff promoted. Legende eigenständig im Trusted-Branch fertiggestellt; originale Architekturprüfung bleibt unverändert. Neue Sichtbarkeitsprüfung erfasst auch übergeordnete Paint-/Overflow-Grenzen, nicht nur Elementgeometrie.

## v0.9.85.145 · MID-C12 Unterscheidbare Prognoseansichten

Basis .144, main = mid-stable = 3951e8ce58239634ed48b4f13e5a58ee23c73c91. Nutzerkorrektur: Spurenmengen ohne Abschneiden, keine Quantil-Kürzel vor sichtbaren Werten, 7d mit gemeinsamem Tmin/Tmax, 14d mit eigener Ensemble-Hierarchie. Meteorologische Werte und Median-/Quantilverträge bleiben erhalten. UI-Handoff ccb4800f3d015313dcf3224270dc934f4f640140 auf exakter Stable-Basis und read-only Gate 37030686168 verifiziert: Build/Types, 899 Regressionen, unveränderte Budgets und Web-/iOS-Hülle grün. Vollständige 96 Kartenfälle mit sichtbaren Tmin/Tmax-Feldern und unbeschnittenen Spurenwerten sind zusätzlich in der Source-Freigabe verpflichtend; Zusätzliche vollständige Source-Prüfung fand abgeschnittenes Temperaturfeld bei 1024 px und diagnostizierte eine nur 25 px breite Tageskarte durch geerbte klassische Rasterplatzierung; moderne Tablet-Zeilen setzen Spalte/Zeile explizit zurück, Temperaturspalte im Integrationsstand auf 114 px berichtigt und Beschriftungen im bestehenden Zahlen-Badge oberhalb der Werte angeordnet, mit natürlicher Badge-Größe und unverändert strengen Sichtbarkeits-/Budgetprüfungen. Details im Implementierungsbeleg.

## MID v0.9.85.144 · 2026-10-02 · Wochenunsicherheit, Trend und Karten

- Tatsächliche stündliche P25/P50/P75-Mitgliederquantile in bestehendem Ensemblebundle; eigenständige Familien-/Frischegewichtung, keine Pseudomitglieder oder Extrapolation, Cachegeneration v18.
- Wetterabschnittsauswahl erhält Niederschlagsbeginn trotz reserviertem Nacht-/Hazardsatz; ausführbare Mittwoch-/Donnerstag-Fixture.
- GRIB-RELHUM-Supersättigung getrennt von CLCT-Grenzen; echter GRIB-Regressionsnachweis und 48 Live-Kartenfelder erfolgreich.
- WMS-Terminwahl berücksichtigt das vollständige Akkumulationsfenster des gewählten Modelllaufs.
- Replit-UI-Handoff für kompakte numerische P25–P75-Grenzen; Integration SHA-verifiziert vor Release.
- 899 CI-Regressionen; zusätzliche responsive Wochenband-/Balkenprüfung, aktuelle DWD-Katalog-/PNG-Verifikation.

## MID v0.9.85.143 · 2026-10-02 · MID-C11 kompakte Unsicherheit

- Basis .142 4282232533fc70545d9b64676a9de1b4839f1b2e. Kein überlappender Produkt-PR.
- Kurze Tmax/Tmin/Regen/Böen-Bänder, echte gewichtete P50-Marker, keine Mittelwindzeile. Fehlende P50 nicht ersetzt.
- Echte stündliche P25–P75-Polygone nur im vorhandenen Warnungsensemble-Horizont. Kein künstlicher Halo und keine Tagesquantil-Interpolation. Historische Halo-Tokenprüfung absichtlich migriert.
- Umsetzung und Quellen: docs/implementation/MID_COMPACT_UNCERTAINTY_0.9.85.143.md.

## MID v0.9.85.142 · 2026-10-02 · MID-C11 Verlustfreies Kartenbudget

- Basis: vollständig veröffentlichte .141, main = mid-stable = ff2e310d107a745468d788fcec678693d507a68d.
- Live-Snapshot belegt bereits ca. 864,4 MB; unkomprimierte neue Raster würden das bestehende 900-MB-Budget überschreiten. Native Feldobjekte deshalb gzip-JSON in immutable .bin-Objekten, ca. 5,8 MB statt 39,5 MB; keine Auflösungs-/Wertreduktion.
- SHA256/Bytezahl vor Inflation, deklarierte entpackte Größe mit laufender Obergrenze; Legacy-JSON bleibt lesbar. Stream-Decoder bevorzugt, vorhandenes pako 2.2.0 explizit gepinnt als Lazy-Fallback für ältere Safari/WebViews.
- Pflichtregressionen um native/fallback gzip-, Größen-, Truncation- und Hash-Prüfungen erweitert. Browser prüft komprimierte Niederschlags- und Legacy-Temperaturfelder sowie PNG/SVG.
- Lokale Typ-, Decoder-/Python- und Browserprüfungen bestanden. Vollständige Suite bis mindestens 500/898 ohne Fehler protokolliert; lokale Ausführungsumgebung beim Abschluss ausgefallen. Verbindliches Source-PR-Gate muss den vollständigen Stand vor Veröffentlichung erneut prüfen.

## MID v0.9.85.141 · 2026-10-02 · MID-C11 Adaptive Prognosen und native Karten

- Basis main/mid-stable 87875585c773edf5fcb508cbe3466c7f98c08481, keine überlappende Produkt-PR.
- Parameterunabhängige Tages-Quantilbänder, kanonische Windumrechnung, echte Null kompakt ohne Spurenwerte zu nullen; Kurzfristgrenzen explizit.
- RADOLAN RW :50-Stunden ohne Rollingsummen-Doppelzählung; fehlende Zellen bleiben -1/grau, fehlende Stunden sperren Fenster.
- Acht native ICON-D2-Felder × sechs verifizierte Termine, nur gewähltes SHA256-geprüftes Raster im Browser. Gleiche Karten-/Favoriten-/Downloadergonomie; Bestandsschutz anderer WMS-Modelle.
- Neue Inhalte über bestehendes immutable Pages-Objektmanifest und unverändertes kostenloses Budget, keine neue API-/Schlüssel-/Bezahlabhängigkeit.
- 898 Pflichtregressionen, zusätzliche Python-Decoder-/Publikationstests und Browser-QA. Zwei historische Testauslese-/Formatverträge bewusst auf neue Typstruktur bzw. kompakte Zahlendarstellung migriert, meteorologische Assertions erhalten.
- Einzelheiten und Grenzen: docs/implementation/MID_ADAPTIVE_NATIVE_MAPS_0.9.85.141.md.

## MID v0.9.85.140 · 2026-10-01 · MID-C11 Radar kompakt

- Ursache der leeren Pille: globale `.top`-Headerregeln auf `.radar-nowcast-grid.top`; Gridlines explizit auf Höhe 0 und transparenten Hintergrund zurückgesetzt, Browsertest prüft diese Geometrie.
- Bright-Sky-Livekennung `RADARCOMP::RV` zusätzlich zur historischen `RADOLAN::RV` akzeptiert; Liveabruf Berlin liefert 24/24 verfügbare Prognoseschritte.
- Chart mit eigener ID gegen alte Layoutregeln isoliert; Summenpille entfernt, Phasentext verkürzt.
- Vollständige native RV-Reihen im schnellen und ausführlichen Pfad unmittelbar nutzen; keine WMS-Abhängigkeit für deren Mengen.
- Native Kontrollbeobachtung darf RV-Zeitschritte und Referenzzeit nicht ersetzen. Kein Auffüllen fehlender Werte mit Null.
- Browserfixture um tatsächliches CurrentNowcards-Umfeld erweitert. Historischer Wortlauttest auf ausdrücklich gewünschten kompakten Phasenvertrag aktualisiert.

# MID v0.9.85.139

## Radar-Nowcast und sichtbare Vorhersagespannen

- Radar-Balken und der unsichtbare Auswahlanker sind Grafikmarkierungen statt Buttons. Globale Touch-Mindesthöhen können Mengenunterschiede nicht mehr verdecken. Die gesamte Zeitachse bleibt per Berührung und Tastatur bedienbar.
- Ein kompakter nativer DWD-RV-Abruf über Bright Sky liefert Fünfminutenwerte ohne Ausdünnung. Einheiten, Referenzlauf, Aktualität und fehlende Werte werden geprüft; der direkte DWD-Pfad bleibt als Reserve erhalten. Fehlende Daten werden nicht interpoliert oder als trocken bilanziert.
- Summen, Hinweise, Achsen und Jetzt-Markierung erhalten ein abschließendes, eng begrenztes Layout. Auswahlanker werden auf einen unsichtbaren Pixel begrenzt.
- 7- und 14-Tage-Übersichten zeigen verfügbare P10–P90-Modellspannen für Tageshöchsttemperatur und Niederschlag. Das Temperaturband markiert zusätzlich P25–P75 und den angezeigten Wert auf einer gemeinsamen Skala. Fehlende Ensemblewerte erzeugen keine erfundenen Spannen.
- Eine aufklappbare Erklärung trennt Modellübereinstimmung von Trefferwahrscheinlichkeit und erläutert den zunehmenden Stellenwert von Tendenzen.

## Prüfung

- Basis: `main == mid-stable == 72c19e18f48cc9997d3ad65c69e3b00d8d723bf4` (v0.9.85.138).
- Neue Pflichtregression prüft native Einheiten, 24 Prognoseintervalle, Summen, Referenzläufe, fehlende/veraltete Werte und echte Mengenunterschiede.
- Im CI werden zusätzlich echte Browserprüfungen mit vollständiger CSS-Kaskade auf sechs Displaygrößen in Hell und Dunkel ausgeführt.
- UTCI-, Quellen-, Niederschlagsintervall- und gemeinsame Modellkartenänderungen aus .138 bleiben erhalten.

Native Quelle: https://github.com/jdemaeyer/brightsky/issues/144 und https://github.com/jdemaeyer/brightsky/blob/master/brightsky/query.py. Pixelwerte sind 0,01 mm/5 min; Prognosen werden nur aus dem neuesten frischen RV-Referenzlauf übernommen. Die verwendete öffentliche API benötigt keinen kostenpflichtigen Schlüssel. DWD-Daten und Bright-Sky-Bereitstellung werden in der Herkunft getrennt angegeben.

# MID v0.9.85.138

## Radarintensität, konsistente Niederschlagsstufen und UTCI appweit

- Die 5-Minuten-Balken des Radar-Nowcasts folgen jetzt der tatsächlichen DWD-RV-Intensität des jeweiligen Zeitschritts. Unterschiedlich starker Niederschlag wird deshalb wieder durch unterschiedlich hohe Balken sichtbar; Datenlücken bleiben ausdrücklich schraffiert und werden nicht als trocken interpretiert.
- Die Radar-y-Achse zeigt Maximum, halbe Skala und Null gleichmäßig am selben Raster wie die Balken. Die Einheit bleibt fachlich eindeutig mm/5 min.
- Niederschlagsangaben verwenden appweit dieselbe zentrale WMO-/DWD-basierte Intensitätsklassifikation. Angezeigte Rate und Textstufe stammen aus demselben Intervall; 1,9 mm/h Dauerregen wird beispielsweise als „mäßig“ eingeordnet.
- UTCI (Universal Thermal Climate Index) ist nun der kanonische Index für die gefühlte Außentemperatur in Aktuell, Kurzfrist, 24-h-Profil/Cockpit, Event- und Wassersportansichten sowie Bergwetter. Temperatur, Feuchte, Wind und Strahlungseinfluss werden gemeinsam berücksichtigt; die sichtbaren Belastungsstufen folgen den Standard-UTCI-Klassen.
- Wo keine direkte mittlere Strahlungstemperatur verfügbar ist, schätzt MID sie transparent aus Tageszeit, Bewölkung, UVI und Höhe. Unbrauchbare Eingangsdaten erzeugen keinen erfundenen UTCI-Wert.

## Technischer Nachweis

- Verifizierte Basis: `main == mid-stable == b013e6664966111fa2c466ba8cabb3520421b435` (v0.9.85.137).
- Radar-Grafik: visuelle Zeitschrittmenge = native Rate × 5/60; Summen-/Coverage-Vertrag bleibt davon getrennt.
- Aktuell-Niederschlag: zentraler Deskriptor hat für die sichtbare Rate Vorrang vor einem separaten Beobachtungslabel; Phasen- und WMO-/DWD-Code bleiben Eingaben der zentralen Klassifikation.
- UTCI: kanonische stündliche Neuberechnung erfolgt nach appweiten Forecast-Korrekturen. Provider-`apparent_temperature` ist nicht mehr die sichtbare fachliche Endgröße der betroffenen Module.
- Fokusregression: `scripts/test-radar-utci-consistency-0985138.mjs`; vollständige Suite und Build laufen im Source-PR-Gate.

# MID v0.9.85.137

## DWD-Radar im Fünfminutentakt und gemeinsame Modellkarten

- DWD GetFeatureInfo wertet RV_ANALYSIS, RV_FORECAST und RV_PREDICTION als native mm/5 min aus und normalisiert korrekt nach mm/h. Die bisher nicht erkannten numerischen Bandwerte verursachten Lücken zwischen den ausgedünnten Kartenbildern. Der bestehende kostenlose DWD-Pfad bleibt erhalten.
- Native Fünfminutenintervalle erhalten explizite Start-/Endzeiten. Die Forecast-Fusion zählt bei 15 Minuten genau drei native Intervalle. Lücken werden weder verbreitert noch als trocken interpretiert oder über RS-Mengenanker aufgefüllt.
- Die sichtbare Summe verwendet die tatsächlich verfügbaren zentralen, final kalibrierten Mengen eines ausdrücklich angegebenen 120-Minuten-Fensters. Nur 24 gültige Schritte ergeben eine vollständige Zweistundensumme und Ensemble-Spanne; ansonsten stehen Teilsumme, auswertbare Minuten und Datenlückenhinweis im Vordergrund. Frühere Summen bei Lücken sind nicht als vollständige Zweistundensummen belastbar.
- Unter Karte bleiben zwei Einstiege: Radar/Satellit/Blitz und Modellkarten. Niederschlagssummen sind ein ICON-D2-Kartenprodukt innerhalb der gemeinsamen, nach Wetterparameter gruppierten Auswahl. Alte Summen-Einstiege und gespeicherte Auswahl werden migriert; Favoriten, Zeitfenster und PNG-/SVG-Downloads bleiben erhalten.
- Kostenlose Natural-Earth-Grenzen (Public Domain) liegen über sämtlichen Modellfeldern. Ländergrenzen immer, Bundesländer ab Zoom 4,8 und kollisionsgeprüfte Ortsnamen ab Zoom 5,7. Bundeslandgrenzen sind auch im PNG-/SVG-Export sichtbar. Auf Smartphones sind die Auswahlfelder mindestens 44 px hoch.
- Neue funktionale Regression prüft Datenfeld/Einheit, 37 Fünfminutenabfragen, Intervallgrenzen, vollständige/partielle Mengen, RS-Lückenschutz, Intervallfusion, Navigationmigration und Zoomstufen. Betroffene historische Oberflächentests werden wegen der ausdrücklich gewünschten Zusammenführung und korrigierten Summenbasis angepasst; alle übrigen Assertions bleiben erhalten.

# MID v0.9.85.136

## ICON-D2-Abgrenzung und konsolidierte Regressionen

- Extremwetter-Ausblick: Außenbereich der gekrümmten ICON-D2-Modellabdeckung dunkel eingefärbt; Grenzpolygon entspricht exakt der bestehenden Analyse. Dunkler Bereich in der Kartenlegende erklärt, unabhängig von Hazard-Auswahl, Zeitraum und temporären Datenlücken.
- Alle 894 Regressionen bleiben unverändert wirksam. Automatische Dateierkennung und beide Baseline-Pflichtlisten werden jetzt als vollständige identische Inventare geprüft; fehlende, veraltete und doppelte Registrierungen brechen die Suite ab.
- Ein gemeinsamer Runner meldet Fortschritt, Gesamtdauer und langsamste Prüfungen; Fehler enthalten weiter die vollständige Ausgabe. MID_REGRESSION_VERBOSE=1 zeigt auch erfolgreiche Einzelausgaben. Ausführung bleibt isoliert und seriell, damit gemeinsam verwendete Artefakte keine Rennen verursachen.
- Neue Regression schützt die identische Modellgeometrie sowie positive und negative Fälle der Testregistrierung. Keine bestehenden Assertions entfernt, keine zusätzlichen Kosten oder Datenquellen.

## v0.9.85.133 · 2026-10-01 · Konsistenzfix Radar/Niederschlag/Pollen/Startnavigation

- Verifizierte Ausgangsbasis: `main == mid-stable == 3816a4332f90be6b73fd04b33bfa46e7918ac66b` (v0.9.85.132). Die Nutzer-Screenshots zeigen ausdrücklich noch diesen Stable-Stand.
- DWD-RV: Die vollständige 5-Minuten-Zeitachse wird gegen die tatsächlich verfügbaren RV-Zeitpunkte vervollständigt. Technisch nicht auswertbare GetFeatureInfo-Zeitschritte bleiben explizite Datenlücken (`dataAvailable=false` / `hitClass=missing`) und zählen weder im Renderer noch in der Forecast-Fusion als trockene Evidenz.
- Niederschlagsdauer: `Aktuell` verwendet dieselbe kanonische 24-h-Niederschlagszeitreihe wie die übrigen Prognosedarstellungen und wertet alle relevanten Phasen aus. Wahrscheinlichkeit allein verlängert keine sichtbare Niederschlagsphase.
- Niederschlagsart/-intensität: 15-Minuten-Mengen werden auf die tatsächliche Intervalllänge normiert. Zusätzlich wird eine frische, vertrauenswürdige lokale SYNOP-/METAR-Niederschlagsart kontrolliert in die kanonischen WMO-Prognosecodes übersetzt und mit expliziter Provenienz durch Stunden-, 15-Minuten- und Kurzfristpfad geführt. Nachgelagerte Modell-`rain/showers`-Heuristiken dürfen diese beobachtete Art im unmittelbaren Zeitfenster nicht zurücküberschreiben.
- Lokalitätsgrenze der beobachteten Niederschlagsart: maximal 40 min alt und maximal 20 km entfernt; die genaue Beobachtungszeit, Entfernung und Quelle werden auch durch die hyperlokale Stationsaggregation erhalten. Diese Grenze ist als MID-Assimilationsregel im Prognosekonsistenzvertrag dokumentiert.
- Pollenflug: Kalender-`Heute` wird vom lokalen Datum abgeleitet, DWD-`EFFECTIVE` als Produktstand ausgewiesen, Worker-Cache verkürzt. Die PWA lädt das Produkt zusätzlich alle 10 min und nach Rückkehr in den Vordergrund neu; ein temporärer Refreshfehler entfernt einen bereits geladenen verwertbaren Produktstand nicht.
- Regression `scripts/test-precipitation-radar-pollen-navigation-0985133.mjs` deckt DWD-RV-Datenlücken, 24-h-Phasen, 15-min-Intensität, beobachteten Schauercharakter, Pollen-Datum/-Refresh und Navigations-Race ab. Der bestehende Hyperlokal-Testharness wurde auf den neuen Beobachtungsvertrag angepasst.
- Worker betroffen: DWD-Radar-Nowcast und DWD-Pollenroute müssen im Release-Gate geprüft/promoviert werden.
- Gesundheitswetter-Platzierung bewusst nicht in diesem funktionalen Patch geändert. Read-only-Replit-IA-Review empfiehlt anschließend `Mehr → Gesundheitswetter` als erweiterbaren Unterbereich; in `Aktuell` höchstens kompakter Tagesstatus/Deep-Link. Umsetzung erst als separater SHA-verifizierter Replit-Handoff auf dem dann freigegebenen Stable-Stand.

## v0.9.85.132 · 2026-10-01 · Niederschlags-Endzeiten appweit vereinheitlicht

- Verifizierte Basis: `main == mid-stable == eb1f8e5bd4dce82a1af18c762a054d5184e51806` (v0.9.85.131), Release- und Stable-Quality jeweils grün.
- Fehlerursache: `precipitationBeyondTwoHours` wertete rohe stündliche Akkumulationswerte aus und addierte auf den letzten nassen Zeitstempel nochmals pauschal eine Stunde. Da die Providerwerte bereits das Ende des vorangegangenen Intervalls markieren, konnte die Aussage bei jedem Stundenwechsel um eine Stunde nach hinten wandern.
- Neue kanonische Funktion: `canonicalPrecipitationTimeline` in `src/precipitationIntervals.ts`.
- Bevorzugte Kurzfristbasis: finalisierte 15-Minuten-Reihe inklusive RUC-/Radar-/Modellfusion; bei unvollständiger Abdeckung vollständiger Fallback auf normalisierte Stundenwerte.
- Sichtbare Dauer wird nur aus messbarem Niederschlag gebildet; Wahrscheinlichkeit allein erzeugt keine künstliche Phase.
- Bestehende `precipitationPresentationHours`/`precipitationPresentationMinutes15` bleiben die gemeinsame Intervallnormalisierung für Aktuell, Prognose, 24-h-Profil und Widgets.
- Regression: `scripts/test-precipitation-timing-consistency-0985132.mjs` schützt insbesondere den früheren +1-h-Endzeitversatz.

## v0.9.85.131 · 2026-10-01 · C11-Kartensteuerung und schneller, korrekter Radar-Nowcast

- Verifizierte Basis: `main == mid-stable == 0daf09160c8f9de514d3fbb3d78c03df275604d1` (v0.9.85.130).
- Verifizierter C11-Replit-Handoff: `37e726c7be865402f4ee348c8b732233e98430fb`, 3 Commits vor Stable und 0 zurück.
- Radar-Preload startet auf normalen Verbindungen nach 20 ms statt 85 ms; Data-Saver/2G bleibt vorsichtiger gestaffelt.
- Der Fast-Path verwendet die bereits geladene DWD-Rasterprobe und vermeidet zusätzliche GetFeatureInfo-Runden pro grobem Schnellzeitschritt.
- Fast-Resultate werden 45 s kurz zwischengespeichert; bei kurzem Upstream-Hänger darf maximal 120 s auf den letzten Fast-Stand zurückgegriffen werden.
- Die vollständige 5-Minuten-Punktserie startet nach dem Fast-Signal nach 40 ms (statt 240 ms) und lädt exakte Punktwerte in 12er- statt 6er-Paketen.
- Fehlerkorrektur: Ausgelassene Fast-Zeitschritte werden nicht länger als künstliche 5-Minuten-Trockenphasen visualisiert. Die periodische Folge „drei Balken, eine Lücke“ war ein Samplingartefakt.
- Echte Trockenphasen des vollständigen DWD-Punktpfads bleiben unverändert erhalten.
- Echo-Gate unverändert: Radar-Nowcast bleibt unter „Aktuell“ verborgen, wenn kein relevantes Standort- oder Umfeldecho vorliegt.
- Regression: `scripts/test-radar-startup-fastpath-0985131.mjs`.

## v0.9.85.130 · 2026-09-30 · Gesundheitswetter sichtbar und Hauptnavigation wiederhergestellt

- Screenshot-Befund reproduziert: `.settings-split-navigation` blendete die gemeinsame Optionssektion vollständig aus; dadurch waren die bereits implementierten Bereiche „Gesundheitswetter“ und „Inhaltsmodule“ unsichtbar.
- CSS-Vertrag korrigiert: Im Navigation-Tab bleiben ausschließlich die navigationseigenen Optionslisten plus Modulreihenfolge sichtbar; Darstellungs-/Wetteroptionen bleiben ausgeblendet.
- Gesundheitswetter steht vor den übrigen optionalen Inhaltsmodulen; Pollenflug bleibt über `mid:pollenDisplaySettings` persistent schaltbar.
- Primärnavigation erhält einen eigenen gerätelokalen Schlüssel für Aktuell / Heute / Vorhersage / Karten / Mehr. Untermodul- und Forecast-Horizon-Zustand bleiben zusätzlich erhalten.
- „Mehr“ kann beim App-Neustart wieder geöffnet werden; bewusstes Schließen stellt den darunter aktiven Hauptbereich als letzten Bereich wieder her.
- Der alte Startpfad entfernt `#mid-section-…` nicht mehr; explizite Deep-Links behalten damit Vorrang.
- Keine Änderung an meteorologischer Logik, Datenquellen, Warnungen oder Worker-Fachlogik.
- CSS-/Budget-Nachgang: Gesundheitswetter und optionale Inhaltsmodule liegen nun als eigene Navigationselemente außerhalb des bewusst ausgeblendeten Darstellungscontainers. Die bestehenden CSS-Splitregeln bleiben unverändert; es entsteht kein zusätzliches CSS-Budget.
- Persistenz-Härtung: Primärbereich dient als Fallback bei fehlendem/ungültigem Modulwert, wird vor Suspend/Schließen erneut gesichert und bleibt gerätelokal.\n- Source-Gate-Nachgang: zwei veraltete Hash-Neutralisierungs-Assertions auf den neuen Deep-Link-Vorrang umgestellt; Pollen-v0.9.85.129-Regressionsvertrag vorwärtskompatibel gemacht.\n- Regression: `scripts/test-health-settings-primary-navigation-0985130.mjs`.

## v0.9.85.129 · 2026-09-30 · Gesundheitswetter/Pollen kompakt

- Reales iPhone-Screenshot-Follow-up: mehrspaltiger Pollen-Kopf entfernt; Region/Quelle/Aktualität als kompakte Metazeile; Defaultzustand auf heutige Relevanz reduziert.
- 3-Tage-Progressive-Disclosure: erste Detailstufe maximal vier relevante Pollenarten, nach höchster 3-Tage-Stufe priorisiert; vollständige 8-Arten-Matrix erst nach explizitem „Alle anzeigen“.
- DWD-Fachkorrektur: siebenstufige Belastungssemantik 0 / 0–1 / 1 / 1–2 / 2 / 2–3 / 3 wird robust aus den gelieferten Text-/Codewerten abgeleitet. „keine bis gering“ ist nicht mehr gleich 0.
- Responsive: keine 420-px-Mindestbreite der Pollentabelle; vier Spalten passen in mobile Karten, Detailblock erhält Bottom-Bar-Scrollabstand.
- DWD-WFS, Regionen, Vorhersagewerte und Worker-Datenlogik bleiben unverändert.
- Replit-Follow-up: zweiter Detailschalter auf ≥44 px angehoben; erste Detailstufe bleibt auch bei acht relevanten Arten auf maximal vier Zeilen begrenzt.
- Source-Gate-Nachgang: CSS-Budget ohne Grenzerhöhung korrigiert; nur nicht notwendige Scrollbar-/Overscroll- und Metazeilen-Deklarationen entfernt.\n- Regression: `scripts/test-pollen-compact-dwd-levels-0985129.mjs`.

## v0.9.85.128 · 2026-09-30 · Screenshot-/Security-Nachgang und Gesundheitswetter

- CodeQL #92–#98: unkontrollierte Textausgabe und dynamische Browser-Testausdrücke entfernt; CDP-Argumente werden strukturiert übergeben und der lokale Chromium-Port wird nicht mehr aus einer Datei in eine Netzwerkadresse übernommen.
- Dependency-Audit: `brace-expansion` lock-only 5.0.9 → 5.0.12; kein `npm audit fix --force` für den getrennten `uuid`-/Capacitor-Tooling-Pfad.
- GitHub Actions: `download-artifact` v4.3.0 → v8.0.1, SHA-gepinnt, kanonischer und aktiver RUC-Workflow identisch.
- Gesundheitswetter: eigener Einstellungsblock; Pollen bleibt gerätelokal optional. Aktive DWD-Pollen werden nach vorhandener Belastungsstufe priorisiert; keine Änderung der DWD-Datenlogik.
- Replit wurde auf Stable v0.9.85.127 synchronisiert und für die Designprüfung eingesetzt; Integration und Release bleiben bei ChatGPT/GitHub.
- Source-Gate-Nachgang: vorbestehenden RUC-Workflow-Drift zugunsten der neueren Release-Race-Sicherung kanonisiert; veraltete Versions-/Action-Assertions aktualisiert; CSS-Budget ohne Grenzerhöhung durch Entfernung ungenutzter Pollen-Legacyregeln korrigiert.
- Required Regression: `scripts/test-security-pollen-maintenance-0985128.mjs`.

## MID v0.9.85.127 · 2026-09-30 · Repository-Hygiene, Versionssynchronisierung und Governance

- Verifizierte Basis: `mid-stable/main 81d2bfb9d872ba97f4e2a3fec82e92a6f8aefab0`.
- PR #208 war funktional bereits integriert, obwohl alle Versionsspiegel auf v0.9.85.126 verblieben; v0.9.85.127 synchronisiert den tatsächlichen Stand.
- Historische, nicht mehr baselinegebundene Root-Dokumente werden nach `docs/` verschoben; eine Regression verhindert neues Root-Wachstum ab diesem Build.
- Branch-Cleanup, Vertragsregistry, KNMI-Workflow-Audit sowie Vitest-/Coverage-Bootstrap werden im selben Wartungsstand regressionsgeschützt.
- Keine Änderung an Wetterdaten, Warnschwellen oder meteorologischer Fachlogik.

## MID v0.9.85.107 · 2026-09-27 · Kompakte Vorhersage- und Bergwetteransichten

- Basis und Source of Truth: mid-stable 17e5fa60e9bee26ec2485a08b33b4ebdc2bfe77e (v0.9.85.106).
- Verifizierter Replit-Handoff: replit/mid-18-2-15-compact-forecast-mountain@59f74d0715e3012ef166030aed21a8718d35ddf8; Handoff-Gate #107 grün mit 873 Regressionen sowie Web-/iOS-Hülle.
- ChatGPT hat den Handoff selektiv in chatgpt/mid-18-2-15-v0985107 integriert und die Diff-Audit-Funde korrigiert: aktive cockpit-fourteen-sun-uvi-Klasse, semantische Schneemengenflächen, kompakte Warn-/Lawinen-/Methodikflächen und bedingungsabhängiger Matrix-Scroll.
- Die Schneemengen-Flächenstaffelung ist reine UI-Skalierung und ausdrücklich keine WMO-/DWD-Warn- oder Intensitätsschwelle.
- MID_CHATGPT_GITHUB_CONTRACT.md wurde auf Source-PR-Gate → kontrollierten Merge → serverseitiges Release-ZIP → Installer → Worker/Pages → Stable-Promotion umgestellt; ZIP-im-PR ist regressionsgeschützt ausgeschlossen.

## MID v0.9.85.105 · 2026-09-26 · Bergwetter kompakter und schneller

- Finaler Replit-Handoff 9d166f7a083aac991f11856608fa0b93178e6aec aus replit/mid-18-2-14-v0-9-85-105-handoff-20260926 selektiv auf den Stable-Quellstand übernommen.
- Kernprognose und 7-Tage-Werte rendern vor GeoSphere-, Schneefallgrenzen-Ensemble- und Diagnose-Enrichments; Fehler und Verzögerungen der Zusatzdaten bleiben isoliert.
- 872/872 Regressionen, Typecheck und Produktionsbuild grün; 6 Viewports × Light/Dark sowie verzögerte und fehlerhafte Enrichment-Szenarien geprüft.
- Replit-Metadaten, Anhänge und vorgebaute dist-Artefakte wurden nicht in den vertrauenswürdigen Source-Branch übernommen.

## MID v0.9.85.105 · 2026-09-26 · Bergwetter kompakter und progressiv geladen

- Finaler Replit-Handoff `9d166f7a083aac991f11856608fa0b93178e6aec` aus `replit/mid-18-2-14-v0-9-85-105-handoff-20260926` selektiv auf den aktuellen Stable-Quellstand übertragen; Replit-Metadaten, Anhänge und vorgebaute dist-Artefakte wurden nicht übernommen.
- Berg-/Wintersportwetter zeigt Kernprognose und 7-Tage-Werte vor GeoSphere-, Ensemble- und Diagnose-Enrichments; verzögerte oder fehlerhafte Zusatzdaten blockieren die Kernansicht nicht.
- Die Hauptansicht ist weiter verdichtet; redundante Analyse-/Methodikblöcke liegen in kompakten Disclosures. Sonnenstunden und Tages-Max-UVI bleiben in 7-/14-Tage-Zeilen kompakt sichtbar.
- Replit-Abnahme: 872/872 Regressionen, Typecheck und Produktionsbuild grün; reale 6-Viewport-×-Light/Dark-Matrix sowie verzögerte/fehlerhafte Enrichment-Szenarien geprüft.
- Veröffentlichung ausschließlich über Source-PR-Gate → Auto-Merge → Release-ZIP → Installer/Pages → Stable-Promotion.

## MID v0.9.85.104 · 2026-09-26 · Berg-/Wintersportwetter responsiv nachgeschärft

- Finaler Replit-Handoff fe80b066739f40b1ede633a1124b3f18d9d366b4 wurde als Remote-Snapshot 155cd7aa11915cdc60229bd1b380d35a9939cd33 verifiziert und selektiv auf den aktuellen Stable-Quellstand übertragen.
- Neue Format- und Schneeabdeckungsregressionen schützen 0 cm, Spurenmengen unter 1 cm und fehlende Daten.
- Die Bergwetter-Visualmatrix prüft iPhone schmal/breit, Android-Breite, iPad hoch/quer und Desktop in Light/Dark sowie Expand/Collapse.
- Meteorologische Datenlogik, Einheitenwahl und Worker-Fachlogik bleiben unverändert.

## MID v0.9.85.103 · 2026-09-25 · Berg-/Wintersportwetter neu strukturiert

- Höhenprognose auf 168 Stunden erweitert; Tagesaggregate stammen aus derselben Höhenzeitreihe wie die geöffneten Details.
- Punktwerte und Intervallsummen bleiben fachlich getrennt; Missing-Snow-Fenster liefern NaN statt künstlichem Nullwert.
- Neue Regression scripts/test-mountain-seven-day-domain-1813.mjs schützt 7-Tage-, Höhen-, Niederschlags- und Schnee-Verträge.
- Replit-Designabnahme 09c3358cfe39f348f866b8f547d91183daebfca7 wurde in den geschützten Sourceweg übertragen.

## MID v0.9.85.103 · 2026-09-25 · MID 18.2.13 · Berg-/Wintersportwetter

- Höhenbezogene Bergprognose auf 168 Stunden erweitert; Tal/Mitte/Berg bleiben getrennte Punktprognosen.
- Zentrale 7-Tage-Aggregation leitet Temperatur, Wind/Böen, Niederschlag, Schnee, Sonnenschein sowie Nullgrad-/Schneefallgrenze aus derselben gewählten Höhenzeitreihe ab.
- Fehlende Schneefallintervalle erzeugen keinen künstlichen Nullwert mehr.
- Neue mobile-first Oberfläche mit Höhenwahl, horizontaler Istwert-Leiste, sieben geschlossenen Tageszeilen und maximal einem geöffneten 3-Stunden-Detail.
- Bestehende MID-Wetterpiktogramme, Windpfeile und DWD-Warnschwellen werden wiederverwendet; Winter-/Sommerpriorisierung ist getrennt.
- Replit-Abnahme: fokussierte Bergwetter-Regressionen, Typecheck, Produktionsbuild und Light/Dark-Viewportmatrix grün; finaler lokaler Design-Handoff 09c3358cfe39f348f866b8f547d91183daebfca7. Übernahme erfolgt in den geschützten GitHub-Sourceweg, nicht per Replit-Publish.

## MID v0.9.85.102 · 2026-09-25 · Bottom-Bar-Tippverhalten und Forecast-Horizont stabilisiert

- Der explizite Forecast-Horizont wird deklarativ aus activeNavSection an ForecastCockpit übergeben und beim Mount vor localStorage priorisiert.
- ForecastCockpit synchronisiert navigationHorizon auch nach dem Mount ohne Timeout- oder Delay-Hacks.
- Neue Regression scripts/test-bottom-bar-forecast-horizon-race-0985102.mjs schützt Mount/Remount und Bottom-Bar-Responsive-Verträge.

## MID v0.9.85.102 · 2026-09-25 · Bottom-Bar-/Forecast-Horizon-Stabilisierung

- Bottom-Bar „Heute“ übergibt den gewünschten Kurzfrist-Horizont deklarativ an das Forecast-Cockpit.
- Explizite Navigation gewinnt beim Mount/Remount vor `mid:forecastCockpit:activeHorizon`; der gespeicherte Wert bleibt nur Wiedereinstiegs-Fallback.
- Bereits gemountete Forecast-Cockpits synchronisieren den Navigationshorizont ohne Timeout-/Delay-Hacks.
- Neue Regression `scripts/test-bottom-bar-forecast-horizon-race-0985102.mjs` schützt Vorhersage→Aktuell→Heute, Heute→Karten→Vorhersage sowie Safe-Area-/Touchzielverträge.
- Wetterdaten, Modellfusion, Warnlogik, Worker und fachliche Prognosewerte werden nicht verändert.

## MID v0.9.85.101 · 2026-09-25 · MID 18.2.13 · Sky-Kohärenz, Nacht-Skybars und Kartenfokus

- Numerische DWD-SYNOP-ww-Codes 0–3 werden nicht als Open-Meteo weather_code 0–3 übernommen; ww=3 kann nicht mehr allein Bedeckt setzen.
- Frische fieldFresh(cloudCover)-Beobachtung steuert aktuellen Code/Label und das Hauptpiktogramm gemeinsam; Modell-Wolkenschichten werden dann nicht in den beobachteten Sky-Visual gemischt.
- 7d day-card und 14d fourteen-row projizieren solarTimelineWindow mit MID-Nachtfarbe und weichen 14/86-Prozent-Fades hinter Band/Squares.
- PwaInstallButton erhält einen transienten, nicht persistenten Kartenfokus-Unterdrückungsvertrag; der manuelle App-Button bleibt aktiv.
- Neue Regression scripts/test-mid-18-2-13-sky-coherence-night-skybars-install.mjs.

## MID v0.9.85.101 · 2026-09-25 · MID 18.2.13 · Aktuelles Wetter, Nacht-Skybars und Kartenfokus

- Aktuelles Wetter nutzt für Zustandslabel und Hauptpiktogramm denselben kanonischen Bewölkungsstand: frische beobachtete Gesamtbewölkung gewinnt gemeinsam; ohne frische Beobachtung greifen Text und Symbol gemeinsam auf den Modellhintergrund zurück.
- Numerische DWD-SYNOP-Wettermeldungen ww=0–3 werden nicht mehr als Open-Meteo-Wettercodes 0–3 interpretiert; insbesondere kann ww=3 nicht fälschlich „Bedeckt“ erzwingen.
- Die Bewölkungs-Info weist verwendete Quelle, Beobachtungsstand/Alter und Modellfallback nachvollziehbar aus.
- 7-Tage-Tageskarten und 14-Tage-Zeilen erhalten astronomisch berechnete Nachtflächen aus der zentralen solarTimelineWindow-Geometrie; Band- und Quadratdarstellung teilen dieselbe Nachtgeometrie.
- Der transiente PWA-Installationshinweis wird im Karten-/Komposit-Fokus temporär unterdrückt, ohne den manuellen „App“-Knopf oder den Installationsstatus zu verändern.
- Neue Regression `scripts/test-mid-18-2-13-sky-coherence-night-skybars-install.mjs`; vollständiger Source-Gate prüft Build, Regressionen und Web-/iOS-Hülle vor Veröffentlichung.

## MID v0.9.85.100 · 2026-09-25 · MID 18.2.12 · Mobile Einstellungsnavigation

- Geprüfter Replit-Handoff `e05bca0aa305a938c886b77e5062ca1c635d4994` vom Branch `replit/settings-mobile-tabs-098599`; read-only Handoff-Gate vollständig grün.
- Die mobile Einstellungsnavigation bleibt einzeilig horizontal scrollbar und führt den aktiven Bereich automatisch vollständig ins sichtbare Scrollfeld.
- Dezente linke/rechte Fortsetzungshinweise zeigen nur dann weitere Tabs an, wenn tatsächlich zusätzlicher Inhalt vorhanden ist; permanente Scrollbars entfallen.
- 44-px-Touchziele und Safe-Area-Abstände bleiben auf 360×800 und 390×844 erhalten; Light/Dark visuell geprüft.
- Neue Regression `scripts/test-settings-mobile-horizontal-tabs.mjs`; bestehender MID-18.2.7-Responsive-Test sowie Handoff-Build/Web-/iOS-Hüllenprüfung grün.
- Keine Änderung an Wetterdaten, Modellfusion, Warnlogik, Schwellen, Parameterfarben, Worker- oder iOS-Fachlogik.

## MID v0.9.85.99 · 2026-09-25 · MID 18.2.11 · Responsive Forecast-Horizontnavigation

- Geprüfter Replit-Handoff dcdfc8c18b1fcc84c19547a8f4d85c163ce07960 über den read-only Handoff-Gate übernommen.
- navigateToDashboardSection verwendet bei modernen Forecast-Modulen die unmittelbar vor dem Modul liegende Horizontnavigation als Scrollziel.
- Mobile Forecast-Horizontnavigation erhält Safe-Area-Scroll-Margin und Abstand zum nachfolgenden Forecast-Modul.
- Neue Regression scripts/test-modern-forecast-horizon-viewport.mjs; Handoff-Build und Web-/iOS-Hüllenprüfung grün.

## MID v0.9.85.99 · 2026-09-25 · MID 18.2.11 · Forecast-Horizontnavigation responsive stabilisiert

- Replit-Handoff aus geprüftem SHA `dcdfc8c18b1fcc84c19547a8f4d85c163ce07960` übernommen; Handoff-Gate vollständig grün.
- Bottom-Tab-Forecastnavigation scrollt bei Prognosemodulen auf die unmittelbar zugehörige Horizontleiste statt den darunterliegenden Modulcontainer, sodass die Leiste nicht oberhalb des Viewports verschwindet.
- Mobiler/Querformat-Abstand und Scroll-Margin berücksichtigen Safe Areas; keine Sticky-/Fixed-Navigation eingeführt.
- Neue Regression `scripts/test-modern-forecast-horizon-viewport.mjs`; vorhandener MID-18.2.7-Responsive-Test und Produktionsbuild grün.
- Reale Sichtprüfung 360×800 Light bestätigt; weitere Zielgrößen sind zusätzlich regressionsgeschützt, die Replit-Browserautomation war dort nicht zuverlässig genug für eine behauptete Sichtabnahme.

## MID v0.9.85.98 · 2026-09-24 · MID 18.2.10 · 90‑Minuten-Skybar mit Nachtkennzeichnung

- ForecastCockpit.ShortTermRibbon leitet now90StartEpoch/now90EndEpoch aus den realen 15‑Minuten-Intervallen ab und nutzt solarTimelineWindow gemeinsam mit Aktuell/24 h.
- now90NightBands werden auf die 120×16-Skybar-Geometrie projiziert und vor SkyBarSegmentsSvg/SkyBarHourCellsSvg gerendert; MID-Nachtfarbe und 14/86-%-Fade entsprechen Aktuell.
- Neue Regression scripts/test-mid-18-2-10-now90-night-098598.mjs schützt Solarquelle, Layer-Reihenfolge, Fade, Farbe und Baseline-Vertrag.

## MID v0.9.85.98 · 2026-09-24 · MID 18.2.10 · 90‑Minuten-Skybar-Nachtkennzeichnung

- 90‑Minuten-Skybar „Heute / Ab jetzt“ nutzt dieselbe zentrale Solar-Geometrie wie „Aktuell“ und das 24‑h‑Profil.
- Nachtbereiche werden aus den realen 15‑Minuten-Intervallen auf die Skybar-Geometrie projiziert und hinter Wettersegmenten bzw. Stundenquadraten gerendert.
- MID-Nachtfarbe und weiche 14/86-%-Fade-Geometrie entsprechen „Aktuell“; Niederschlag, Bewölkung und Sonne behalten ihre bestehende Fachlogik.
- Regression: `scripts/test-mid-18-2-10-now90-night-098598.mjs`.

## MID v0.9.85.97 · 2026-09-24 · MID 18.2.10 · Replit-Audit: Cache, Fokus und lokale Zeitbasis

- Forecast-Core-Cachevertrag Frontend v4 und Worker-Edge v3 dimensionieren Koordinaten, gerundete Höhe und effektive IANA-Zeitzone; unsichere Legacy-Einträge werden nicht migriert.
- Forecast-Fusion-Localcache v10 trennt Höhenstände; Lead-Time-Reconciliation und Tagesfusion nutzen reale lokale Stunden-Epochen.
- forecastPeriods.addForecastDays verwendet reine gregorianische Kalenderarithmetik ohne UTC-Date-Mutation; SevenDayForecastSummary nutzt diesen Vertrag für die Folgenacht.
- AppPortalPopover stellt den gemeinsamen verschachtelbaren Fokusstack bereit; Mehr-Drawer, Event-Center, Impressum und Einstellungen sind angeschlossen.
- Neue Regression test-mid-18-2-10-replit-audit-098597 schützt Cache-Dimensionen, Fokusvertrag, DST-/Datumsgrenzen und Release-Version.

## MID v0.9.85.97 · 2026-09-24 · MID 18.2.10 · Replit-Audit-Fixes

- Forecast-Core-Cache Frontend v4 und Worker-Edge v3 trennen Koordinaten, Höhe und effektive Ortszeitzone; unsichere Legacy-Caches werden nicht mehr als frischer Stand migriert.
- Direktabruf und Worker-Pfad reichen Höhe und Zeitzone konsistent an Open-Meteo weiter; der explizite Worker-Request-Key enthält dieselben Dimensionen.
- Forecast-Fusion-Cache v10 trennt Höhenstände; Tages-Lead-Time basiert auf realen lokalen Stunden-Epochen statt auf festem 12:00Z.
- Gemeinsamer Fokusstack für Dialoge/Popover/Sheets mit Initialfokus, Tab-/Shift-Tab-Fang, Escape nur auf oberster Ebene und Fokus-Rückgabe; Mehr, Event-Center, Impressum und Einstellungen angeschlossen.
- Zivile Kalenderarithmetik für Folgenächte arbeitet ohne UTC-Date-Mutation und ist für CET/CEST, Datums-/Jahresgrenzen sowie weit entfernte IANA-Zeitzonen regressionsgeschützt.
- Neue Regression: `scripts/test-mid-18-2-10-replit-audit-098597.mjs`.

## MID v0.9.85.96 · 2026-09-23 · MID 18.2.9 · METAR-Beobachtung und kompakte 14-Tage-Ansicht

- METAR-Current-Auswertung endet vor Trend-/Remark-Gruppen wie TEMPO, BECMG, NOSIG, INTER, PROB30/40, FM-Zeitgruppen und RMK.
- Der reproduzierende EDDG-Fall `... Q1020 TEMPO SHRA BKN025TCU` kann Current Weather nicht mehr fälschlich auf Regenschauer/Trendbewölkung setzen.
- 14 Tage: Default je Tag nur Wetterkopf, Tmin/Tmax, eine Skybar, Niederschlag, Wind/Böen und Konfidenz; Sekundärwerte ausschließlich im ausgewählten Inline-Detail.
- Doppelte 24-h-Detail-Skybar sowie separate Defaultblöcke für Sonnenscheindauer, Temperaturabweichung und Regime wurden entfernt.
- Replit vor Designänderung auf mid-stable v0.9.85.95 synchronisiert; Veröffentlichung weiterhin ausschließlich über den kanonischen GitHub-Releaseweg.
- Regressionen: `test-metar-trend-observation-boundary-098596.mjs` plus aktualisierter `test-fourteen-day-replit-fluid-grid-098593.mjs`.

## MID v0.9.85.95 · 2026-09-23 · MID 18.2.9 · Gewitter-, RUC-, Skybar- und Performance-Härtung

- J.1: signalScore-only-Vertrag für Detail-/Rapid-Gewitterdiagnose; Legacy-percent-Pfade aus UI und Spezialmodulen entfernt.
- J.2: MU-CAPE/CIN in nativen stündlichen Specialist-Pfad verschoben, Valid-Time-Grenze 35 min eingeführt; VIS/CEILING feldspezifisch als native 15-min-Zustände gekennzeichnet.
- J.3: Skybar trennt direkte Sonnenscheindauer von Wolkenkomplement; alter Komplement-Vertrag und Wissenschaftstest aktualisiert.
- J.4: WeatherNext 2 mit nativeTemporalHours=6/interpolatedHourly markiert, aus stündlichen Warn-/Event-Ensembles ausgeschlossen und in Tagesgewichtung konservativ berücksichtigt.
- J.5: Feature-Chunk-Budgets, Aggregate-Source-of-Truth, Entfernung von weather.tsfrag und dokumentierter Dependency-Review ohne partielle Lockfile-Migration.

## MID v0.9.85.95 · 2026-09-23 · MID 18.2.8 · J.1–J.5 Härtung

- J.1: signalScore-only-Vertrag für Detail-/Rapid-Gewitterdiagnose; Legacy-percent-Pfade aus UI und Spezialmodulen entfernt.
- J.2: MU-CAPE/CIN in nativen stündlichen Specialist-Pfad verschoben, Valid-Time-Grenze 35 min eingeführt; VIS/CEILING feldspezifisch als native 15-min-Zustände gekennzeichnet.
- J.3: Skybar trennt direkte Sonnenscheindauer vom Wolkenkomplement; Wissenschaftsregression entsprechend aktualisiert.
- J.4: WeatherNext 2 mit nativeTemporalHours=6/interpolatedHourly markiert, aus stündlichen Warn-/Event-Ensembles ausgeschlossen und in Tagesgewichtung konservativ berücksichtigt.
- J.5: Feature-Chunk-Budgets, Aggregate-Source-of-Truth, Entfernung von weather.tsfrag und dokumentierter Dependency-Review ohne partielle Lockfile-Migration.

## MID v0.9.85.89 · 2026-09-22 · Arbeitspaket H · Responsive Gesamtabnahme und 7-Tage-Korrektur

- Replit-Abnahme: 7-Tage-Fix sowie H.1/H.2a/H.2b/H.2c umgesetzt; H.1 und H.2c jeweils mit vollständiger Light/Dark-Viewportmatrix grün, Typecheck/Produktionsbuild/Regressionen ohne Befund.
- Produktive Übernahme erfolgt bewusst als Mapping auf ForecastCockpit, MeteogramPanel und WaterSportsPanel statt durch Kopieren des Mockup-Sandbox-Codes.
- Neue finale UI-Schicht midC18WorkPackageH.css erzwingt die vertikale 7-Tage-Tagesliste unabhängig vom früheren Orientierungsvertrag, ordnet die aktive Detailfläche hinter allen sieben Zeilen an und schützt H.2c-Overflow-/Touchverträge.
- Regression test-mid-18-2-6-h-responsive-handoff-098589.mjs schützt die produktiven 7-Tage-, Meteogramm- und Tide-Verträge; meteorologische Daten-, Warn-, Schwellen-, Modellfusions- und Skybar-Fachlogik bleiben unverändert.

## MID v0.9.85.88 · 2026-09-22 · Arbeitspaket G · Ensemble, Klima und Widgets

- Replit-Abnahme vollständig grün: Typecheck, Produktionsbuild, fokussierte Regressionen sowie Light/Dark auf 360×800, 390×844, 430×932, 844×390, 768×1024, 1024×768 und 1440×900.
- Produktintegration verwendet die bestehenden EnsemblePanel-, ClimatePanel- und AppleWidgetSettings-/Export-Verträge; Datenquellen, Schwellen und Berechnungen wurden nicht geändert.
- Neue finale UI-Schicht midC18WorkPackageG.css schützt Umbruch, Tooltipbreite, Touchziele und Overflow; Regression test-mid-18-2-5-g-ensemble-climate-widgets-098588.mjs sichert die Verträge.

## MID v0.9.85.87 · 2026-09-22 · 14-Tage-Zeilen responsiv entzerrt

- Replit-Abnahme: Light/Dark auf 360×800, 390×844, 430×932, 844×390, 768×1024, 1024×768 und 1440×900 sowie längere mobile Detailansichten grün.
- Mobiler 14-Tage-Header nutzt flexiblen Textbereich plus getrennte Konfidenzspalte mit mindestens 132 px; verschachtelte Elemente erhalten min-width:0 und wesentliche Texte keinen Truncate-Vertrag.
- Neuer Regressionstest schützt ForecastRow-Struktur, Konfidenzpille, Umbruch und Overflow-Vertrag.
- Der v0.9.85.86-Heute-/24-h-Viewport-Regressionsvertrag ist vorwärtskompatibel auf 0.9.85.86 oder neuer fortgeschrieben; seine fachlichen Viewport-Assertions bleiben unverändert.

## MID v0.9.85.86 · 2026-09-22 · Heute-/24-h-Viewport-Fix

- Replit-Abnahme für Smartphone, Tablet und Desktop in Light/Dark vollständig grün.
- Künstliche 600/640-px-Mindestbreiten des 24-h-Profils entfernt; der Profiltrack bleibt durchgehend stündlich.
- Außencontainer der Heute-Arbeitsfläche gegen horizontalen Overflow abgesichert; der bewusste 90-Minuten-Innenscroll bleibt lokal begrenzt.
- Untere Profilachse erhält sicheren Rendering- und Padding-Raum; meteorologische Fachlogik und Daten bleiben unverändert.
- Neue Regression test-mid-18-2-5-today-viewport-098586 schützt den Responsive-Vertrag.

## MID v0.9.85.85 · 2026-09-22 · MID 18.2.5 · gesammelte Current-/24-h-/7-/14-Tage-Korrekturen

- Beide Replit-Einschübe gemeinsam abgenommen: Typecheck, Produktionsbuild und fokussierte Regressionen grün.
- Responsive Abnahme für Light/Dark auf Smartphone, Tablet und Desktop inklusive Hoch-/Querformat ohne offene Restpunkte.
- Produktive Übernahme schützt Current-Windrichtungspfeil, getrennten +12-h-Header, ausschließlich stündliches 24-h-Profil, aktive 7-/14-Tabs, kollisionsfreie 7-Tage-Zeilen, lesbare Konfidenz-Pillen und ganzzahlige Haupt-Sonnenstunden.
- Neue Regression scripts/test-mid-18-2-5-ui-fixes-098585.mjs und nach Arbeitspaket F geladener Designlayer src/midC18ResponsiveCorrections.css.

## MID v0.9.85.84 · 2026-09-22 · Arbeitspaket F · Map-first Kartenarbeitsraum

- Replit-F-Abnahme einschließlich Transparenz-Follow-up vollständig grün.
- Neuer Designlayer `src/midC18MapFirstWorkspace.css`, geladen nach Arbeitspaket E.
- Produktive Fachverträge verbleiben in `RadarPanel.tsx`, `WeatherMapsPanel.tsx` und `SynopticPanel.tsx`; keine Änderung der meteorologischen Datenlogik.
- Neue Regression `scripts/test-mid-18-2-5-f-map-first-098584.mjs` schützt Timeline, Playback, Jetzt, Layer-Deckkraft, Synoptik und Responsive-Komposition.
- Light/Dark-Abnahme: 360×800, 390×844, 430×932, 834×1112, 1112×834 und 1440×900.

## MID v0.9.85.83 · 2026-09-22 · Arbeitspaket E

- ForecastCockpit: gemeinsame MidForecastRow-Familie für 7-/14-Tage.
- 7 Tage: selectedDate ist alleiniger Inline-Detailzustand; unabhängiges expandedDate entfernt.
- 14 Tage: bisherige Fokuskarte direkt unter die aktive Tageszeile verschoben; kompakte Skybar und Tmin/Tmax-Faden aus bestehenden Daten ergänzt.
- Neuer zuletzt geladener Designlayer für Desktop, Tablet hoch/quer und Smartphone.
- Neuer Regressionstest schützt gemeinsame Row-Struktur, genau eine Inline-Erweiterung, vorhandene Datenquellen und Responsive-Vertrag.
- Replit-Vorprüfung: Typecheck/Produktionsbuild und Light/Dark-Viewportmatrix grün; kanonischer GitHub-Gate bleibt maßgeblich.

# MID v0.9.85.39

## MID-C9 · Mobile Layoutkorrektur nach Screenshots

- Aktuell: vier Kernparameter tatsächlich als 2×2-Raster; alte übergreifende Zellbelegungen zurückgesetzt. Wetterkopf, Quellenzeile und Niederschlagsinformation kompakter; doppelte Freifläche vor dem Footer reduziert.
- Kurzfrist: alle Zeitpunkte bleiben in genau einer horizontal scrollbareren Zeile. Die feste Sechs-Spalten-Begrenzung entfällt, auch der siebte Zeitpunkt bleibt oben.
- Favoriten: einzeilige Anordnung mit klarer Auswahl, separater Verwaltung und einmaliger Standard-Kennzeichnung; keine überlagerten Grid-Bereiche oder doppelte Abkürzung.
- Aktiver Kurzfrist-Schalter mit lesbarem Textkontrast. Wetterwerte, Quellen und Bedienfunktionen bleiben erhalten.

# MID v0.9.85.38

## MID-C9 · Einheitlicheres Design und ruhigere Bildsteuerung

- Die 90-Minuten-Vorschau bildet eine durchgehende Zeitleiste mit klar hervorgehobenem Zeitpunkt.
- Auf Tablets passen Seitenleiste und Inhaltsabstand zusammen; auf großen Bildschirmen sind die Navigationsziele wieder beschriftet. Lange Ortsnamen bleiben lesbar.
- „Mehr“ erhält übersichtliche Einstellungszeilen und einen beim Scrollen erreichbaren Kopf. Flächen und Abstände sind ruhiger und einheitlicher.
- Das DWD-Originalbild lässt sich in feineren Schritten von 50 bis 500 Prozent zoomen. Der betrachtete Ausschnitt bleibt beim Zoomen erhalten; „Standort“ und „100 %“ führen gezielt zurück.
- Verzögerte Zentrierungssprünge entfallen. Die eingebettete Originallegende wird nicht mehr durch allgemeine Bildgrößenregeln verkleinert.
- Wetterwerte, Warnschwellen, Parameterfarben und die bisherige geografische Bildkalibrierung bleiben unverändert.

# MID Build-Changelog · v0.9.85.37

## Redesign-Stufe C17 · DWD-Ortsausschnitt wieder exakt lokalisiert

- Der reale Mobil-Sichtvergleich zeigte, dass „Wolken + Niederschlagsart“ trotz unveränderter DWD-Georeferenzierung nicht in jedem Öffnungs-/Resize-Zyklus sichtbar auf dem gewählten Ort stehen blieb. Ursache war die Darstellungsfolge: der Bildcanvas konnte nach dem ersten Zentriervorgang noch seine Größe ändern beziehungsweise animieren.
- DwdPrecipitationTypeRadar zentriert jetzt mit der tatsächlich gerenderten Canvas- und Viewportgröße. Ein zusätzlicher ResizeObserver überwacht sowohl Viewport als auch Canvas und zieht den gewählten Standort nach jeder relevanten Größenänderung wieder exakt in die Mitte.
- Bildladen löst nach dem Layout zusätzlich eine Standortzentrierung aus. Die Wiederholungen liegen bei unmittelbarem Layout, zwei Animation Frames sowie 80/180/360 ms, damit iOS-/PWA-Layoutwechsel und aufklappende Bereiche nicht mehr in einem halbverschobenen Zustand enden.
- Der Standortmarker ist nun ein konsistentes MID/Lucide-MapPin mit zusätzlichem 6-px-Ankerpunkt exakt auf dem georeferenzierten Originalpixel. Der bisherige Emoji-Pin entfällt.
- src/midC17DwdLocationFix.css entfernt die Breitenanimation des Originalbild-Canvas, schützt Auto-Scroll-Zentrierung und reduziert die eingebettete Originallegende mobil leicht, ohne DWD-Inhalt oder Pixelanalyse zu verändern.
- scripts/test-c17-dwd-location-centering-098537.mjs schützt die etablierte Kalibrierung einschließlich des realen Elsig-Sichtvergleichs (50,67° N / 6,76° E → normierter Originalbildpunkt 0,33102793 / 0,46836195) und prüft exakte Zentrierbarkeit auf 320/390/430/768 px Viewports.
- Keine Änderung an DWD-Quelle, Originalbild, Niederschlagsartenklassifikation, Pixelanalyse, Radar-/Satellitenzeit, Nowcast-/RUC-Logik oder meteorologischen Schwellen.

# MID Build-Changelog · v0.9.85.36

## Redesign-Stufe C16 · Heute-Proportionen nach realem iPhone-Sichtvergleich

- Der Sichtvergleich mit v0.9.85.35 zeigte, dass das 24-h-Wetterprofil auf schmalen Viewports die volle Desktop-Y-Geometrie von 632 Einheiten beibehielt und dadurch gegenüber der verfügbaren Breite sichtbar überdehnt wirkte.
- `ForecastCockpit` skaliert die komplette Y-Geometrie des 24-h-Profils jetzt gemeinsam und konsistent: Smartphone bis 560 px auf 72 %, mittlere Viewports bis 860 px auf 86 %, Desktop unverändert auf 100 %. Zeitachse, Solarereignisse, Wetterpiktogramme, Wolken-, Temperatur-, Niederschlags-, Wind-, Druck- und Hazardspuren folgen derselben Skalierung.
- `src/midC16TodayProfileFix.css` schützt Textfluss und Containerbreiten. Die Kurzfrist-Zusammenfassung darf umbrechen, die 90-Minuten-Kopfzeile wird auf sehr schmalen Geräten von redundantem Zusatztext befreit.
- Der DWD-Disclosure verwendet nun einen expliziten Button statt des nativen `details`-Zustands. Dadurch kann eine vom Browser wiederhergestellte `open`-Eigenschaft das große DWD-Originalbild nach Rückkehr oder Reload nicht ungefragt erneut öffnen. Das Bild wird weiterhin erst nach Nutzeraktion gerendert. Zusätzlich wurde der nicht definierte helle `--card`-Fallback entfernt; die Disclosure-Fläche verwendet jetzt die aktiven MID-Themeflächen `--surface`/`--s2`.
- Wetterdaten, DWD-Originalprodukt, Pixelanalyse, Zoom, Nowcast-/RUC-Fusion, Warnschwellen, Parameterfarben und Zeitsemantik bleiben unverändert.
- `scripts/test-c16-today-profile-density-098536.mjs` schützt die responsive Profilgeometrie, den Textfluss und den explizit geschlossenen DWD-Startzustand.

# MID Build-Changelog · v0.9.85.35

## Redesign-Stufe C15 · Heute-Dichte und progressive DWD-Ansicht

- `DwdPrecipitationTypeDisclosure` hält das amtliche DWD-Originalprodukt vollständig verfügbar, rendert die große Bildfläche in „Heute“ und Kurzfrist aber erst nach bewusster Öffnung. Originalbild, Radar-/Satellitenzeit, Pixelanalyse und Zoom bleiben unverändert erhalten.
- `ForecastCockpit` und `ShortTermForecast` verwenden denselben Disclosure-Vertrag, damit das DWD-Bild nicht mehr mehrfach als dauerhaft dominante Fläche erscheint.
- `src/midC15TodayDensity.css` wird nach C14 geladen und verdichtet das mobile 24-h-Wetterprofil. Abgeleitete Signale werden auf schmalen Viewports als horizontale, touchfreundliche Leiste geführt; Auflösungswahl, Legende und Info bleiben erhalten.
- Die Profil- und Hilfeflächen sind weiterhin an ihren eigenen Viewport gebunden. Die meteorologischen Spuren, Warnschwellen, Parameterfarben, Quellprovenienz und Zeitsemantik werden nicht verändert.
- `scripts/test-c15-today-density-098535.mjs` schützt die progressive DWD-Ansicht, die C15-Kaskadenposition und die mobile Profil-Dichte. Der bestehende C11-Vertrag wurde ausschließlich auf den gemeinsamen Disclosure-Namen fortgeschrieben.

# MID Build-Changelog · v0.9.85.34

## Redesign-Stufe C14 · Karten als Arbeitsraum und reale Viewport-Korrekturen

- `src/midC14MapWorkspace.css` vereinheitlicht den Kartenbereich als Map-first-Arbeitsraum. Komposit und DWD-Wetterkarten verwenden denselben Dichtevertrag für Smartphone, Querformat, Tablet und Desktop.
- Der bestehende Komposit-Fokus bleibt fachlich unverändert: Radar, Satellit, Nowcast und Modell/Synoptik teilen weiterhin die bestätigte Produktzeitachse. Überschrift, Moduswahl und Zeitleiste werden visuell deutlich kleiner, die Karte erhält den größten Viewport-Anteil.
- `WeatherMapsPanel` entfernt die dauerhaft doppelte Zeitschritt-Auswahl. Direkt sichtbar bleiben nur Modell und Kartenprodukt; die Karte trägt Produkt, Gültigkeit und Lead Time kompakt als Overlay.
- Druckfläche/Höhe, Kartenbasis, Deckkraft und Reload liegen nun in `Darstellung & Ebenen`; Quelle, INIT und Gültigkeit liegen in `Quelle & Lauf`. Beide Bereiche sind standardmäßig eingeklappt und bleiben vollständig zugänglich.
- Die gemeinsame Kartenzeitleiste behält Zurück/Play/Vor/Range und ergänzt einen `Jetzt`-Sprung zum fachlich bevorzugten verfügbaren Termin.
- Der Screenshot-Abgleich zeigte eine zentrale Kaskadenursache: `v078` wurde nach den Redesign-Dateien geladen und konnte C7–C13 auf realen Smartphones teilweise wieder überschreiben. `src/main.tsx` lädt den Legacy-Layer nun vor sämtlichen Redesign-Stufen; C14 bleibt als letzte visuelle Schicht maßgeblich.
- `src/midC14ViewportFixes.css` verdichtet Kopf, Suche, Favoriten, Orts-/Warnkontext und aktuelle Kernwerte. Die primäre Smartphone-Ansicht zeigt vier Kernparameter; Sichtweite bleibt in den Zusatzdetails erreichbar.
- Das Impressum erhält einen strikt viewportgebundenen Dialog mit dauerhaft zugänglichem, sticky Schließen-Kopf und intern scrollendem Inhalt. Hoch- und Querformat verwenden Safe-Areas und `100dvh`.
- DWD-Originalbildzoom und breite Diagramme dürfen ihre äußeren Container nicht mehr verbreitern. Vergrößerung und horizontales Scrollen bleiben auf den jeweiligen Bild-/Diagrammviewport beschränkt; die App selbst wird horizontal geklemmt.
- `CompositeTimelineContract.phaseSources` bereitet die gemeinsame Kartenzeitachse auf einen späteren transparenten Übergang von Satellitenbeobachtungen zu modellbasierten Pseudo-Satellitenbildern vor. Jede Phase kann eine eigene Quelle tragen; weiterhin werden ausschließlich bestätigte Produktzeitpunkte verwendet und keine Zwischenbilder erfunden.
- Datenquellen, DWD-WMS/Raster, Radar-/Satelliten-/Nowcastlogik, Modellkonturen, Warnregeln, Farbcodierungen und Zeitsemantik wurden nicht geändert.
- `scripts/test-c14-map-workspace-098534.mjs` schützt Map-first-Hierarchie, eine gemeinsame Zeitleiste, einklappbare Sekundärsteuerung und Responsive-Verträge. `scripts/test-c14-viewport-fixes-098534.mjs` schützt Kaskadenreihenfolge, Portrait-Impressum, Zoom-Containment, Smartphone-Dichte und den künftigen Quellenwechsel Satellit → Pseudo-Satellit.

## Redesign-Stufe C13 · mobile Dichte und Aktuell

- `src/midC13MobileDensity.css` wird nach C12 geladen und korrigiert die im realen Smartphonebild noch zu große, kachelartige Aktuell-Darstellung.
- Der Orts-/Warnkontext erhält verbindlich die Reihenfolge vor `Aktuell`; die alte CSS-Sortierung darf den Ort nicht mehr ans Abschnittsende verschieben.
- Der bestehende `hidden`-Vertrag der Zusatzwerte wird auf Autorenebene geschützt. `mehr/weniger` blendet die Sektion damit tatsächlich ein bzw. aus.
- Geöffnete Zusatzwerte werden als eine zusammenhängende, ruhige Detailfläche mit Zeilentrennung dargestellt; UVI-/AQI-Skalen und Sonne/Mond bleiben erhalten, ohne wieder eine gleichrangige Kachelmatrix zu bilden.
- Auf Smartphonebreiten scrollt der große Kopf mit der Seite statt den knappen Viewport dauerhaft zu belegen. Logo, Aktionsflächen, Suche, Favoriten, Ortskopf, Atmosphärenkarte, Radar-Nowcast und Bottom-Bar erhalten reduzierte Höhen und Schriftgrößen mit Safe-Area-Schutz.
- Wetterdaten, Nowcast-/RUC-Logik, Warnschwellen, Piktogramme, Parameterfarben, Quellenbewertung und Zeitsemantik bleiben fachlich unverändert.
- `scripts/test-c13-mobile-density-098533.mjs` schützt Reihenfolge, echte Klappung, De-Kachelung, mobile Dichte und die wichtigsten Breakpoint-/Safe-Area-Verträge.

## Redesign-Stufe C12 · Vorhersage

- `src/midC12ForecastRedesign.css` wird nach C11 geladen und setzt die verbindliche visuelle Hierarchie der Vorhersage um.
- 7 Tage: Verlaufsgrafik bleibt Primärvisualisierung; Tageswerte bilden ein zusammenhängendes Band; die stündliche Detailansicht wird in denselben Arbeitsraum integriert.
- 14 Tage: Ensemble-/Konsistenzinformationen bleiben vollständig erhalten; Tagesdarstellung wird als fortlaufende Spalten organisiert; der gewählte Tag erhält eine integrierte Detailtiefe statt einer zweiten gleichgewichteten Karte.
- Responsive Verträge schützen Smartphone Hoch-/Querformat, Tablet, Desktop, Safe-Areas, horizontale Prognosebereiche und reduzierte Bewegung.
- Keine Änderung an Wetterdaten, Nowcast-/RUC-Logik, Warnschwellen, Piktogrammlogik, Parameterfarben oder Zeitsemantik.
- `scripts/test-c12-forecast-redesign-098532.mjs` schützt Struktur, Auswahlzustände, Responsive-Verträge und den ausgelieferten, nichttechnischen App-Changelog.

## Veröffentlichung

Verbindlicher Pfad: **Source-PR-Gate → Auto-Merge → Release-ZIP → Installer → Stable-Promotion**. Der Stand darf erst nach grünem Gate und erfolgreicher Stable-Promotion als veröffentlicht gelten.

- Renderprüfung von PR #442 um native Fill-Style-Sichtbarkeit (`layout.visibility`, numerisches `fill-opacity`) ergänzt. Der positive MapLibre-Query allein konnte bei unsichtbarem Fill eine falsche Gesundmeldung auslösen. Zusätzliche Vitest- und TSX-MapLibre-Mockfälle für `none`/`0`; unveränderte Feature-, GeoJSON-, Modell- und Source-PR-Gates. Sichtbare WebGL-Pixel und tatsächlicher Browser-/Recovery-Check weiterhin offene Release-Blocker.
