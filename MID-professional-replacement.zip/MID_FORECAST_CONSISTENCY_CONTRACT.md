# MID – verbindlicher Vertrag für eine konsistente Prognose aus einem Guss

Dieser Vertrag gilt ab MID v0.9.53.26 app-weit für alle bestehenden und neuen sichtbaren Prognose-, Analyse-, Warn-, Event-, Aktivitäts-, Widget- und Exportmodule.

## 1. Eine operative Prognose, mehrere Darstellungen

MID darf fachlich relevante Vorhersagewerte nicht pro Ansicht neu zusammensetzen. Nach Abschluss der zentralen Prognosekette existiert für einen Standort nur eine operative MID-Prognose. Karten, 90-Minuten-Ansicht, Kurzfristprognose, Stundenprofil, Tagesgrafiken, 7-Tage-Ansicht, Hazards, Widgets, Events und Aktivitäten sind Verbraucher dieser Prognose und keine eigenständigen Forecast-Engines.

## 2. Kanonische Zeitreihen

Für die sichtbare App gelten zwei kanonische Zeitreihen:

- `displayHours`: finale stündliche MID-Prognose.
- `displayMinutes15`: finale 15-Minuten-Niederschlags-/Wetterreihe für 90-Minuten- und Kurzfristdarstellungen sowie zeitlich feinere Niederschlagsauswertungen.

Rohes `hours` oder `minutes15` darf in sichtbaren Forecast-Verbrauchern nicht an der kanonischen Endstufe vorbei verwendet werden, wenn eine entsprechende finale Reihe verfügbar ist.

## 3. Gemeinsame Reihenfolge der Prognosekette

Die fachliche Reihenfolge lautet grundsätzlich:

1. Best Match / Modellbasis und kohärente Wetterbündel.
2. Zulässige Mehrquellen-/Fusion-Reparaturen.
3. Optional validierte lokale Wetterzwilling-Bias-Korrekturen.
4. Operatives Radar-/Nowcast- und Konvektivsignal.
5. Feldbezogene hyperlokale Beobachtungs-/Stationskorrektur mit zeitlichem Ausblenden.
6. Zentrale Niederschlags-, Wettercode- und Plausibilitätsabstimmung.
7. Ableitung der finalen 15-Minuten-Reihe aus derselben operativen Evidenz.
8. Aggregation der finalen Stunden in Tageswerte und nachgelagerte Verbraucher.

Ein Modul darf diese Reihenfolge nicht lokal neu erfinden oder einzelne Schritte ein zweites Mal anwenden.

## 4. Hyperlokale Anpassungen wirken app-weit

Eine fachlich freigegebene hyperlokale Anpassung ist keine reine Anzeige des Moduls „Aktuelles Wetter“. Soweit der Parameter und der Zeithorizont eine Extrapolation zulassen, fließt sie in die operative Prognose ein.

Das betrifft insbesondere:

- Temperatur und daraus abgeleitete gefühlte Temperatur,
- Feuchte und Taupunkt,
- Luftdruck,
- Wind, Böen und Windrichtung,
- Bewölkung, tiefe Bewölkung und Sicht,
- beobachteten Niederschlag,
- daraus gestützte Niederschlagswahrscheinlichkeit,
- plausiblen Wettercode bzw. Wettercharakter.

Die Korrektur muss parameterbezogen und zeitlich begrenzt auslaufen. Eine aktuelle Beobachtung darf nicht pauschal über viele Stunden oder Tage fortgeschrieben werden.

## 5. Niederschlagswahrscheinlichkeit und Nowcast

Erhöht oder senkt die zentrale Kurzfristlogik die Niederschlagswahrscheinlichkeit – etwa durch Radar, Konvektion oder belastbare lokale Niederschlagsbeobachtung –, muss dieses Signal in allen betroffenen Darstellungen erkennbar sein. Insbesondere dürfen 90-Minuten-Karte, Kurzfristprofil, Stundenprofil, Niederschlagszusammenfassung und Tagesauswertung nicht gleichzeitig verschiedene Wahrscheinlichkeitsstände für dasselbe Zeitfenster verwenden.

15-Minuten-Werte dürfen aufgrund ihrer feineren zeitlichen Auflösung vom Stundenwert abweichen; sie müssen jedoch aus derselben Evidenz und derselben zentralen Blend-/Plausibilitätslogik stammen. Feinere zeitliche Struktur ist zulässig, widersprüchliche Prognoseursachen sind es nicht.

## 6. Keine doppelte Assimilation

Radar, Konvektion, Stationsanker, Wetterzwilling oder andere lokale Korrekturen dürfen in einer UI-Komponente nicht erneut auf bereits finalisierte Werte angewendet werden. Darstellungskomponenten erhalten finale Werte und visualisieren sie lediglich.

## 7. Tageswerte folgen finalen Stunden

Wo ausreichend Stundenabdeckung vorliegt, werden Niederschlag, Wettercode und kurzfristig relevante Tageskennwerte aus den finalen Stunden abgeleitet. Ein Tageswert darf keine lokale oder Nowcast-Korrektur wieder verlieren, die in den zugrunde liegenden Stunden bereits fachlich wirksam ist.

## 8. Events und Aktivitäten

Events und Aktivitäten am aktuell geöffneten Ort verwenden dieselben bereits finalisierten `displayHours`. Andere Orte durchlaufen dieselbe zentrale Endstufe einschließlich der dort verfügbaren hyperlokalen Beobachtungsanker. Eine Event- oder Aktivitätsengine darf keine abweichende lokale Forecast-Logik etablieren.

## 9. Herkunft und Nachvollziehbarkeit

Lokale Korrekturen bleiben als solche erkennbar. Die zugrunde liegende Modell-/Best-Match-Herkunft wird nicht fälschlich ersetzt; ergänzend kann die operative Reihe eine lokale Anpassungskennzeichnung tragen. Eine Anpassung darf nur erfolgen, wenn die feldbezogene Beobachtung nach dem Hyperlokal-Analysevertrag verwendbar ist.

## 10. Neue Module

Jedes neue Modul mit Prognosewerten muss vor Merge beantworten:

- Verwendet es `displayHours` beziehungsweise `displayMinutes15` oder eine daraus abgeleitete kanonische Struktur?
- Wird lokale/Nowcast-Evidenz nur einmal zentral angewendet?
- Stimmen Niederschlagswahrscheinlichkeit, Wettercode, Hazard und Tagesaggregation mit den übrigen Verbrauchern überein?
- Bleiben Zeit, Einheit, Provenienz und Cache-Regeln erhalten?

Lokale Parallelberechnungen sind nur zulässig, wenn sie eine bewusst andere fachliche Größe darstellen und ausdrücklich dokumentiert sowie regressionsgeschützt sind.

## 11. Regressionsschutz

Der Required-Test `scripts/test-forecast-consistency-contract-095326.mjs` schützt die kanonischen Stunden-/15-Minuten-Pfade, die app-weite Verwendung und das Verbot eines erneuten UI-seitigen Hyperlokal-/Radar-Blends.

## 12. Current → 90 Minuten → 24 Stunden: einmalige Temperaturassimilation (ab v0.9.53.40)

Ein frischer Temperatur-Stationsanker darf je operativer Prognosekette genau **einmal** auf die Modellstunden angewendet werden. Insbesondere ist es verboten, denselben Stationswert zunächst über `reconcileCurrentTemperatureObservation` in die nächstgelegene Modellstunde zu schreiben und anschließend über `applyHyperlocalForecastHours` ein zweites Mal als Abweichung zur unveränderten Modellreferenz zu verrechnen. Wenn ein verwendbarer Stationsanker vorliegt, übernimmt ausschließlich die kanonische Hyperlokalstufe dessen zeitlich ausblendende Korrektur; die allgemeine Current/Stunden-Reconciliation bleibt in diesem Fall für die Temperatur deaktiviert.

Dieselbe Regel gilt für Ortsansicht, klassische Kurzfrist, Prognose-Cockpit, Events und Aktivitäten. Bereits lokal finalisierte Stunden dürfen in `ShortTermForecast` oder anderen Darstellungskomponenten nicht nochmals feldweise gegen denselben Current-Anker assimiliert werden.

Für die sichtbare Kontinuität gilt zusätzlich:

- der aktuelle Messwert ist der Ausgangspunkt der unmittelbar folgenden Kurzfristdarstellung,
- innerhalb der ersten 15 Minuten wird kein künstlicher Sprung allein durch Stundeninterpolation erzeugt,
- bis 90 Minuten erfolgt ein stetiger Übergang zur bereits kanonisch lokalisierten Forecast-Zeitreihe,
- das 24-h-Profil beginnt mit einem synthetischen Punkt `jetzt` am aktuellen Zeitpunkt und demselben Temperaturanker; danach gilt dieselbe Übergangslogik,
- die gefühlte Temperatur folgt der Temperaturverschiebung, solange kein eigener verwendbarer Apparent-Temperature-Messanker existiert.

Eine Darstellungskorrektur darf keine zusätzliche Datenquelle und keinen zusätzlichen Request erzeugen. Sie dient ausschließlich dem zeitlichen Übergang zwischen derselben aktuellen Beobachtung und derselben finalisierten MID-Prognose.

Kurzfrist-Zeitangaben müssen außerdem den Ortstag eindeutig erkennen lassen: Eine reine Uhrzeit ist nur am selben Tag zulässig. Für den Folgetag ist mindestens `morgen HH:MM`, für den zweiten Folgetag `übermorgen HH:MM` und danach ein eindeutiger Datums-/Wochentagsbezug auszugeben.

Required Regression: `scripts/test-current-shortterm-temperature-consistency-095340.mjs`.
