# Kanonische RUC-/RUC-EPS-Laufabdeckung ab v0.9.85.336 (Source-Kandidat)

Der Nutzerauftrag erweitert den gemeinsamen stündlichen Zustandskern und die voraggregierte RUC-EPS-Wahrscheinlichkeitsreihe auf native +0…+27 h **seit UTC-Modellinitialisierung**. Die vorhandene Kartenqualifikation .305 bleibt gültig; deren damaliger Ausschluss einer Fusion-/EPS-Erweiterung beschreibt den historischen Umfang und wird für diese beiden kanonischen Stundenprodukte hier ausdrücklich abgelöst. Keine Behauptung zusätzlich gemessener Vorhersagegüte.

Worker prüft Herkunft, streng aufsteigende volle UTC-Stunden, native Leads 0…27 und höchstens vier Stunden Laufalter (maximal fünf Minuten Zukunftstoleranz). Gewichtung verwendet den Quelllauf, niemals verbleibende Stunden ab Abrufzeit. Tatsächliches Datenende begrenzt jedes Produkt separat; ein Rohrollback mit 15 Terminen bleibt +14 h. Ungültige Herkunft/Achse liefert keine RUC-Korrektur; authentische fehlende Werte werden weder interpoliert noch zu null. Die gemeinsame `weatherHours`-Reihe versorgt weiterhin alle Ansichten, Widgets und Exporte.

Die begrenzte, nicht empirisch gütekalibrierte MID-Heuristik behält die bisherigen frühen Gewichtsknoten und physikalischen Delta-/Niederschlags-Ausreißerschutzregeln. Der deterministische Anteil nimmt ab +12 h mit einer stetigen kubischen Übergangsfunktion von 0,30 bis null bei +27 h ab; auch der konvektive Zusatz wird im selben Bereich gegen null geführt. Der EPS-Wahrscheinlichkeitsanteil nimmt jenseits +14 h von 0,34 bis null bei +27 h ab. Am letzten Termin wird kein Gewicht oder Anschlusswert erfunden. RUC/EPS bleibt dieselbe DWD-Unabhängigkeitsgruppe, keine zusätzliche unabhängige Modellstimme.

Native 5-/15-min-Produkte bleiben +0…+6 h; `rapid-extreme.v4` bleibt bewusst +0…+14 h mit Zeitfenstern 0–6, 6–12 und 12–14. Auch die gesonderte native Member-Eventauswahl bleibt bei ihrem bisherigen +14-h-Vertrag. Keine Erweiterung dieser Extremwetter-/Eventprodukte durch die Erweiterung der kanonischen Stundenfusion.

Der Vorprozessor verlangt einen gemeinsamen vollständigen +27-h-Lauf für Deterministik/EPS. Ein ausschließlich temporäres `pages-codec-staging-v1` darf den Rohcodec-Eingang aufnehmen; es wird von produktiven Lesern abgelehnt. Veröffentlichung erfordert weiterhin vollständigen unabhängigen Python-/JS-/Worker-Dekodiernachweis und weniger als 900.000.000 Bytes einschließlich Manifest. Der Rückfallpfad bleibt derselbe native Lauf in `pages-free-v1`, als byteidentisches +0…+14-h-Präfix ohne erneute meteorologische Berechnung; native Rapid-/Extremprodukte bleiben unverändert. Staging darf niemals als Rollback hochgeladen werden. Fehler blockieren atomare Veröffentlichung, der letzte gültige Stand bleibt erhalten.

# Separate RUC-Kartenachse ab v0.9.85.305

Die optionalen RUC-Modellkarten erhalten eine eigene stündliche Achse0…27h aus demselben vollständig validierten nativen DWD-Lauf. Der gesamte ursprüngliche0…14h-Kern muss nach Dekodierung der aktiven Codec-Parts bitgleich zum Präfix der Kartenquelle sein. +27h wird nur bei vollständig dekodierten12Feldern, identischem Gitter, GRIB-/UTC-/Intervall-/Einheiten-/Missing-Prüfungen und darstellbaren int16-Werten zugelassen; sonst bleibt der geprüfte Kernhorizont für Karten verwendbar. Kein zusätzlicher Konsensbeitrag, keine EPS-/Rapid-/Fusion-Erweiterung. Kartenprodukte Temperatur/Druck/Wind/Böen/Wolken/Niederschlag nutzen den bestehenden Lookup als nearest-native-cell-Sampling, ohne Wertglättung. NoData bleibt null/transparent; trockene0 bleibt0. Initialisierungs-Böe/-Niederschlag wird nicht als1h-Intervall angeboten.

Zulassung erst nach kompletter Codec-Aktivierung und Prüfung sämtlicher vorhandener SHA-/Größeninventare. Atomare Manifestersetzung nach unveränderlicher Ausgabe aller Kartenobjekte, erneutem Source-Check und realer Gesamtbudgetprüfung (<900000000Bytes einschließlich Manifest). Bestehende Objekte, Codec-Proof und separat archivierter Raw-Rollback bleiben unverändert. Kartenfehler lassen den bestehenden validierten Snapshot bestehen. Browser prüft Root-/Index-/Frame-Verträge, SHA/Bytes, vier Stunden Freshness und durchgängige identische Stundenachsen. Keine RUC-Daten als ICON-D2 oder WMS-Ersatz ausgeben.

# MID DWD RUC/RUC-EPS Pipeline Contract

Stand: v0.9.85.336 (kanonische Stundenfusion; historische Produktgrenzen ausdrücklich ausgenommen)

## Missing-Vertrag optionaler Niederschlagsphasen (v0.9.85.231)

Fehlt die optionale Graupelreihe, bleibt ihr Feld im festen Phase-Wire-Layout vollständig Missing: NaN vor Packing, int16-Sentinel -32768, null beim Dekodieren/JSON. Kein Ersatz durch trockene0. Vorhandene Regen-/Schneereihen und echte trockene Graupelwerte bleiben nutzbar. Partielle Missing-Zellen propagieren durch Akkumulationsdifferenzen; unvollständige Summen werden nicht als vollständige Phasenmengen ausgegeben. Der Worker darf Decoder-null nicht numerisch in0 umwandeln; nur endliche Phasenwerte zählen als verfügbare Zellen. Vollständig fehlende Phasenzellen bestehen keine Verfügbarkeitsprüfung. Das Radar-Phasenoverlay darf aus fehlender Thermik/Feuchte/Höhe keine0°C oder kalte Phase ableiten. Schwellen/Feldlayout bleiben unverändert; Phase-Einheiten-/Größenartkalibrierung ist ein gesonderter offener Vertrag.

## Terminabdeckung vor Quantisierung (v0.9.85.218)

Alle stündlichen Kernfelder müssen identische Zeit-/Gitterdimensionen besitzen. Jeder Termin jedes Feldes muss mindestens eine endliche native Zelle enthalten; ein vollständig fehlender Termin ist kein gültiges Nullfeld. Akkumulationen benötigen endliche Zellen je Termin über ihre Raum-/Memberachsen. Teilweise authentisch maskierte Randbereiche bleiben erhalten und werden nicht aufgefüllt. Dies ist ein MID-Integritätsgate, keine neue DWD-Warnschwelle oder prozentuale Vollständigkeitszusage. Differenzierte Quoten werden nach dem folgenden Diagnosevertrag gemessen; kalibrierte prozentuale Freigabegrenzen bleiben gesonderte Abnahmepunkte. Fehler blockieren vor Packing und Veröffentlichung; kein Catch oder Fallback darf sie in einen publizierten Teillauf umwandeln.

## EPS-Mitgliederabdeckung (v0.9.85.219)

Alle in den Zielterminen gelieferten Mitglieds-IDs müssen an jedem Zieltermin vorhanden sein; die Schnittmenge darf unvollständige Mitglieder nicht still entfernen. Jeder Mitgliedstermin braucht mindestens eine endliche native Zelle. Prüfung vor Akkumulationsprüfung, Aggregation und Packing; Fehler sind fatal. Die Mindestzahl 10 bleibt unverändert. Dies beweist keine erwartete feste Mitgliederzahl oder prozentuale Zellabdeckung. Authentische Masken und trockene Nullen bleiben erhalten; keine Interpolation oder Ersatzmitglieder.

## RUC-Snapshot-Transport (v0.9.85.220)

Abgebrochene HTTP-Body-Reads (IncompleteRead) werden im vorhandenen endlichen Fetch-Backoff erneut vollständig geladen. Keine Teilbytes übernehmen; Größen-/SHA-Verletzungen bleiben fatal und werden nicht als Netzwerkfehler behandelt. Atomare Ersetzung erst nach vollständiger Abnahme; bei Erschöpfung vorhandenen Snapshot erhalten und temporäre Dateien entfernen. Keine Scheduler-/Freshness-Schwellenänderung.

## Aktualitätsdiagnostik (v0.9.85.221)

Schema mid.ruc.freshness.v1 protokolliert beobachteten UTC-Zeitpunkt, angekündigten gemeinsamen DWD-Lauf, veröffentlichten Lauf und Metadatenvalidität. upstreamRunAgeMinutes und publishedRunAgeMinutes sind Minuten seit Initialisierung; availabilityLagMinutes ist die signierte Differenz der beiden Initialisierungen. Fehlende/ungültige Informationen sind null; negative Werte bleiben sichtbar. Ausgabe in bestehenden Job-Logs, Step-Summary und freshness_metrics-Output. Keine neue Freigabe-/Freshness-Schwelle; keine gemessene Discovery→Publish-Latenz oder dauerhafte SLO-Historie behauptet.

## Missing-Data-Diagnostik (v0.9.85.222)

Nach erfolgreicher semantischer Prüfung, vor Quantisierung bzw. EPS-Aggregation, schreibt der Builder `RUC_MISSING_METRICS` mit Schema `mid.ruc.missing.v1` in die vorhandenen Joblogs. Deterministische Kernfelder beziehen sich auf die normalisierten gemeinsamen Felder (Niederschlag: Intervalle); EPS bezieht sich auf die native normalisierte TOT_PREC-Akkumulation vor Differenzbildung. `validTimes` ordnet jeden Null-basierten `step` seinem UTC-Termin zu; Kernberichte nennen zusätzlich den initialisierten `run`. EPS-Berichte verwenden tatsächliche Mitglieds-IDs.

`missingFraction` ist die Anzahl nicht endlicher Werte geteilt durch alle nativen Gitterzellen je Termin/Parameter bzw. Termin/Mitglied (0 bis 1, kein Prozentwert). `persistentMissingCount` zählt über alle gelieferten Termine durchgehend nicht endliche Zellen. `additionalMissingCount` ist die Differenz zur terminweisen fehlenden Zellzahl. Persistenz ist eine Beobachtung, kein Beweis für eine authentische GRIB-Bitmap und keine Erklärung der Ursache. Inf und NaN sind nicht endlich; trockene Nullwerte zählen als vorhandene Daten. Alle Originalwerte und Indizes bleiben erhalten. Die vorhandene Endlichkeitsmaske wird wiederverwendet; keine zusätzlichen Zelllisten oder Rasterscans außerhalb der Validierung. Leere Zeit-/Member-/Punktdimensionen sind ungültig.

Dies sind Diagnosequoten, keine neue physikalische Grenze, DWD-Warnschwelle oder kalibrierte Publish-Schwelle. Keine historische SLO-Aggregation/Alarmierung, keine Missing-Quoten für optionale Rapid-/Spezialistfelder und keine feste erwartete EPS-Mitgliederzahl behaupten. Bestehende harte Gates (leerer Termin/Mitglied, Dimensionen, physikalische Grenzen, Akkumulation) bleiben verbindlich; keine Freigabe fehlerhafter Runs.

## Zweck und fachliche Rolle

DWD ICON-D2-RUC ist in MID ein stündlich neu initialisierter Kurzfrist-Kalibrator mit parameterabhängiger nativer Zeitauflösung der bereits kohärenten kanonischen Best-Match-Prognose. Der räumliche Vertrag ist auf `[-3.85, 43.18, 20.22, 58.05]` begrenzt, der zeitliche Vertrag auf native 0–27 Stunden seit UTC-Initialisierung innerhalb der tatsächlich validierten Laufabdeckung. Best Match bleibt die Prognosebasis; RUC erzeugt weder eine zweite DWD-Modellfamilienstimme noch einen parallelen UI-Forecast.

RUC-EPS gehört wie ICON-D2-EPS zur Unabhängigkeitsgruppe `dwd-ensemble` und zur gemeinsamen Variantengruppe `dwd-icon-d2-eps-rapid`. In der Kurzfrist/Event-Auswertung wird RUC-EPS bis maximal 14 Stunden vor ICON-D2-EPS versucht. Ist RUC-EPS nicht nutzbar, fällt MID innerhalb derselben Familie auf ICON-D2-EPS zurück. Normale 7-/14-Tage-Ensembleabrufe laden RUC-EPS nicht.

## Meteorologische Schutzregeln

- RUC darf ausschließlich innerhalb des nativen 0–27-h- und Gebietsvertrags kalibrieren.
- Die Gewichtung ist in 0–3 h am höchsten und nimmt danach begrenzt ab und läuft bis +27 h stetig gegen null aus. Physikalische Felder werden zusätzlich durch Delta-Grenzen geschützt.
- RUC-Niederschlag wird mit dem kanonischen Best-Match-Niederschlagsbündel reconciled; RUC ersetzt keine Niederschlagsphase blind.
- RUC-EPS kalibriert die kurzfristige Niederschlagswahrscheinlichkeit im normalen Forecast aus bereits im Vorprozessor aggregierten Memberwahrscheinlichkeiten.
- Native RUC-EPS-Member sind ausschließlich eine optionale exakt eventbezogene Zusatzquelle. Fehlen sie im kostenlosen Speicherprofil, fällt diese Memberauswertung auf ICON-D2-EPS innerhalb derselben DWD-Ensemblefamilie zurück.
- **Beobachtung und Prognose sind strikt getrennt:** Eine aktuelle Radar-/KONRAD3D-Zelle wird ohne detektierten Blitz weiterhin nicht als beobachtetes `Gewitter` bezeichnet. Diese Blitzregel gilt jedoch **nicht** als Sperre für numerische Gewitterprognosen. Die kanonische NWP-Prognose darf auch ohne Rapid-Daten Gewitter vorhersagen; ICON-D2-RUC darf bei verfügbarer Rapid-Diagnostik ein numerisches Gewittersignal erzeugen, wenn mehrere physikalisch unabhängige Zutaten (Instabilität/Inhibition + modellierter konvektiver Trigger + elektrische/organisatorische Unterstützung wie LPI/UH/EchoTop/Aufwind) gemeinsam tragen. Kein einzelnes Rapid-Feld ist alleinige Gewitterautorität.
- Radar, Blitz, Stationen und Wetterzwilling bleiben nachgelagerte hyperlokale Korrekturen der kanonischen Reihe.

## DWD-Open-Data-Aufbereitung und native Zeitachsen

Quelle sind die offiziellen DWD-Open-Data-Bäume `icon-d2-ruc` und `icon-d2-ruc-eps`. Der Vorprozessor sucht den jüngsten gemeinsamen vollständigen Lauf, inventarisiert die benötigten Parameterbäume rekursiv und dekodiert GRIB2 mit ecCodes ausschließlich in GitHub Actions. Das native `CLAT`/`CLON`-Dreiecksgitter bleibt unverändert; MID regriddet die RUC-Felder nicht.

**Verbindlicher parameterabhängiger Zeitvertrag ab v0.9.73.11:**

- gemeinsamer Zustandskern 0…+27 h **stündlich**: `T_2M`, `TD_2M`, `RELHUM_2M`, `PMSL`, `U_10M`, `V_10M`, `VMAX_10M`, `CLCT`, `CLCL` sowie stündliche Referenzen für Niederschlag/CAPE/CIN;
- `TOT_PREC` 0…+6 h **5-minütlich** als natives Rapid-Niederschlagsprodukt; daraus wird zusätzlich eine echte 15-min-Akkumulation gebildet;
- `TOT_PREC`, `CAPE_ML` und `CIN_ML` 0…+6 h **15-minütlich** für den kanonischen Kurzfrist-/Konvektionspfad;
- `DBZ_CMAX` wird optional **15-minütlich** verwendet und ausdrücklich nur als **modellierte Reflektivität**, niemals als beobachtetes Radar;
- `RAIN_GSP`/`SNOW_GSP`/`GRAU_GSP` werden optional nur dann als 15-min-Phasenstütze genutzt, wenn der konkrete Lauf eine vollständige gemeinsame 15-min-Serie liefert;
- weitere optionale 15-min-Severe-Diagnostik (`CAPE_MU`, `CIN_MU`, `LPI`, `LPI_MAX`, `UH_MAX*`, `ECHOTOPinM`, `HAIL_GSP`, `LAPSE_RATE`, `W_CTMAX`, `VORW_CTMAX`) wird nur bei vollständiger Zeitachse aufgenommen und nie als alleinige Warn-/Gewitterautorität verwendet;
- `ASOB_S`, `ASWDIR_S`, `ASWDIFD_S` werden optional 15-minütlich als Strahlungsdiagnostik geführt;
- `VIS`, `CEILING`, `HZEROCL`, `SNOWLMT`, `CLCM`, `CLCH`, `T_G`, `H_SNOW` werden optional stündlich als Specialist-Diagnostik geführt; `SRH` und `WSHEAR_U/V` bleiben bis zur expliziten `lvt1`-Layerauswahl deaktiviert;
- RUC-EPS bleibt für den normalen probabilistischen Kurzfristpfad **stündlich 0…+27 h**.

Fehlende Zwischenwerte von Temperatur, Wind, Druck oder Wolken werden nicht interpoliert. Die feineren Einzelprodukte werden als getrennte Wire-Produkte publiziert (`rapid-5m.bin`, `rapid-15m.bin`, optional Reflektivität/Phase) und erzwingen keine falsche gemeinsame 5-/15-min-Zustandsachse.

### Appweite Verwendung

Die RUC-Rapid-Felder laufen in `forecast-fusion` als `rapidMinutes15` in die kanonische `displayMinutes15`-Endstufe ein. RUC wird **vor** Radar/Nowcast angewendet; beobachtetes Radar und lokale Beobachtungen bleiben dadurch nachgelagert und höher priorisiert. 5-min-Niederschläge liefern neben der 15-min-Summe einen Peak-Intensitätswert. CAPE/MU-CAPE und CIN/MU-CIN bilden zusammen mit modellierter Reflektivität bzw. Niederschlagstriggern den konvektiven Kern; LPI, UH, EchoTop und maximaler Aufwind verstärken ihn als zusätzliche elektrische/organisatorische Evidenz. Ab v0.9.76.35 darf diese **Mehrparameterdiagnostik** ein numerisches Gewittersignal in der Prognose erzeugen. Die aktuelle KONRAD3D-Zellbezeichnung bleibt davon unabhängig und heißt ohne Blitz weiterhin Schauer-/starke Schauerzelle.

Für den Mitteleuropa-Extremwetter-Ausblick erzeugt der Vorprozessor ein kompaktes räumliches `rapid-extreme.json` (Schema v4) über die **bewusst separat begrenzte Zeitachse 0…+14 h**. +0–6 h enthält die nativen 5-/15-min-Produkte (u. a. 6-h-Niederschlag, max. 1 h, max. 15 min, 5-min-Peakrate, CAPE/CIN und optional `DBZ_CMAX`, MU-CAPE/CIN, UH, LPI, EchoTop, Hagel und Niederschlagsphase). +6–12 h und +12–14 h werden aus dem stündlichen RUC-Zustandskern abgeleitet (Niederschlag/max. 1 h, Böen/Wind, CAPE/CIN, Temperatur, Taupunkt, Feuchte sowie – wenn vorhanden – Nullgrad- und Schneefallgrenze). Schema v4 ergänzt pro Zeitraum ausschließlich **voraggregierte** RUC-EPS-Niederschlagsevidenz (Memberzahl, Wahrscheinlichkeit >0,2 mm bzw. >5 mm, Q75 sowie die I1–I4-Überschreitungswahrscheinlichkeiten für 1 h und – bei vollständiger Abdeckung – 6 h); das native Member-Cube wird weiterhin nicht an App oder Worker ausgeliefert. Im UI-Zeitraum +12–24 h darf RUC/RUC-EPS deshalb ausschließlich die reale Teilabdeckung +12–14 h stützen; +24–48 h bleibt vollständig beim ICON-D2-/EPS-Pfad. Deterministische RUC-Werte dürfen eine I-Stufe nur dann stützen, wenn die zugehörige Intensitätsschwelle tatsächlich erreicht wird; subthreshold RUC-Werte erzeugen keine höhere I-Stufe. RUC-EPS darf die bestehende ICON-D2-EPS-Regenwahrscheinlichkeit kurzfristig **begrenzt in beide Richtungen kalibrieren**, eine bereits ensemblegestützte I-Stufe aber nicht allein unter ihre Aktivierungsschwelle drücken. Schnee und Eis dürfen RUC-EPS nur als Niederschlagsstütze zusammen mit deterministischen Temperatur-/Phasen-/Nullgrad- bzw. Schneefallgrenzensignalen verwenden; daraus wird keine ungestützte hohe Intensitätsstufe erzeugt. Diese Unterstützung ergänzt ICON-D2-EPS/ICON-D2, ersetzt aber weder die Ensemble-Wahrscheinlichkeit noch KONRAD3D/Meso/Blitz als beobachtungsnahe Bestätigung.


### Gewittersemantik ab v0.9.76.35

MID unterscheidet zwei verschiedene Aussagen, die nicht mehr gegenseitig blockiert werden:

1. **Aktuelle beobachtete Zellklassifikation:** KONRAD3D/Radar ohne detektierten Blitz → Schauer bzw. starke Schauerzelle; mit Blitz → Gewitterzelle. VIL, Reflektivität, vertikale Ausdehnung, Starkregenpotential und Zellmasse fließen über die amtliche KONRAD3D-Schwereklassifikation weiterhin in die Intensitätsbewertung ein, ersetzen aber den Blitznachweis für die Benennung des aktuellen Zustands nicht.
2. **Numerische Gewitterprognose:** kann unabhängig vom aktuellen Blitzstatus entstehen. Ohne Rapid-Daten bleibt die kanonische Mehrparameter-/WMO-Prognose voll wirksam. Mit Rapid-Daten ergänzt ICON-D2-RUC +0–6 h die Diagnose aus CAPE/MU-CAPE, CIN/MU-CIN, 5-/15-min-Niederschlag, `DBZ_CMAX`, LPI/LPI_MAX, UH, EchoTop und Aufwind. Für die kanonische Stundenfusion von +6 bis +27 h stehen nur die wissenschaftlich belastbaren stündlichen Zustandsparameter zur Verfügung; sie dürfen ein vorhandenes Ensemble-Gewittersignal nur bei passender CAPE-/CIN- und Niederschlagslage stützen und ersetzen fehlende Scherungs-/Organisationsdiagnostik nicht. Die Entscheidung ist ingredient-basiert; ein einzelnes Feld allein erzeugt keinen synthetischen Gewittercode.

Damit bedeutet „kein aktueller Blitz“ nur „aktuell nicht blitzbestätigt“ und niemals „numerisch kein Gewitter möglich“.

### Strahlung und Sonnenscheindauer

Der aktuelle RUC-v1-Baum bietet u. a. `ASOB_S`, `ASWDIR_S` und `ASWDIFD_S`. Diese Felder werden in v0.9.73.11 bewusst **nicht** in Sonnenscheindauer umgerechnet. `ASWDIR_S` beschreibt direkte kurzwellige Strahlung an der Oberfläche; die meteorologische Sonnenscheindauer setzt direkte Sonnenstrahlung normal zur Strahlrichtung gegen die 120-W/m²-Schwelle. Eine belastbare Ableitung benötigt deshalb Sonnenstand/Projektionskorrektur und eine separat validierte Kalibrierung. Der bestehende appweite Sunshine-Duration-Contract bleibt Primärpfad. RUC-Strahlung ist für einen späteren validierten Strahlungs-/PV-/Thermik- und Sunshine-Plausibilitätsadapter vorgemerkt, wird aber nicht nur „weil verfügbar“ heruntergeladen.

Deterministisch werden mindestens Temperatur, Taupunkt, relative Feuchte, MSL-Druck, 10-m-Windkomponenten, Böen, Gesamtniederschlag, Gesamt-/tiefe Bewölkung, CAPE und CIN verarbeitet. RUC-EPS erzeugt für den normalen Forecast vorab je Punkt/Stunde Niederschlagswahrscheinlichkeit (>0,2 mm), signifikante Wahrscheinlichkeit (>5 mm), Mittel sowie Q25/Q50/Q75. Uneinheitliche Gitter, fehlende Pflicht-Rapid-Reihen oder unzureichende räumliche Lookup-Abdeckung brechen die Veröffentlichung fail-closed ab.

## Primärer kostenfreier Speicher-/Workervertrag: GitHub Pages

Der produktive Standardpfad ist `pages-free-v1` und benötigt weder R2 noch eine neue kostenpflichtige Ressource. Veröffentlicht werden laufbezogen:

- deterministische stündliche RUC-Kerndaten,
- native 5-min-/15-min-RUC-Rapid-Produkte,
- ein kompaktes 0–14-h-Extremwetter-RUC/RUC-EPS-Summary (native Rapid-Diagnostik 0–6 h, stündlicher Zustandskern 6–14 h und voraggregierte RUC-EPS-Niederschlagsevidenz),
- die voraggregierte RUC-EPS-Zusammenfassung,
- der Punkt-Lookup,
- ein kleines `latest.json`.

Die Binärprodukte werden in immutable Chunks geteilt. Der Worker liest pro Zielpunkt nur den erforderlichen Chunk; HTTP-Range-Unterstützung des Pages-CDN ist keine Voraussetzung. Das native EPS-Memberobjekt wird im Pages-Free-Profil bewusst ausgelassen. Der veröffentlichte Gesamtstand aus MID-App und RUC wird auf weniger als 950 MB begrenzt und hält damit Abstand zum aktuellen 1-GB-Pages-Limit. Daten älter als vier Stunden gelten nicht als frischer RUC-Lauf.

Normale App-Releases erhalten einen vorhandenen Pages-Free-RUC-Snapshot, indem sie dessen Manifest und immutable Chunks vor dem Pages-Deployment wieder in `dist/ruc` übernehmen und per Größe/SHA-256 prüfen. Ist `MID_RUC_PIPELINE_ENABLED=true`, gilt dieser Erhalt fail-closed.

Der Worker nutzt standardmäßig `https://midwx.app/ruc/`; `MID_DWD_RUC_STATIC_BASE_URL` kann diese Quelle ausdrücklich überschreiben. `ruc-health` meldet das aktive Backend und akzeptiert beim Pages-Profil die absichtliche Abwesenheit nativer EPS-Member.

### Scheduler-/Catch-up-Vertrag ab v0.9.74.5

GitHub-`schedule` ist als best-effort Trigger zu behandeln und darf nicht als lückenlose meteorologische Uhr angenommen werden. Der kostenlose RUC-Workflow erhält deshalb zwei versetzte Chancen je Stunde (`:11` und `:41` UTC) und darf einen bereits laufenden Build nicht durch einen verspäteten Folgetrigger abbrechen (`cancel-in-progress: false`). Vor ecCodes/pip vergleicht ein stdlib-only Guard den neuesten gemeinsam beworbenen DWD-RUC/RUC-EPS-Lauf mit dem veröffentlichten Pages-Free-`latest.json`. Nur ein strukturell gültiger, exakt gleicher und innerhalb des Vier-Stunden-Vertrags liegender Lauf darf den teuren Neubau als No-op überspringen. Bei neuerem DWD-Lauf, stale/ungültigem Pages-Metadatensatz oder jeder Discovery-/Netzwerkunsicherheit wird fail-open vollständig verarbeitet. Die eigentliche Vollständigkeitsentscheidung verbleibt bei `fetch_and_build_ruc.py`; ein bloß beworbener, aber unvollständiger neuer DWD-Lauf kann daher weiterhin nicht veröffentlicht werden.

### Scheduler-Resilienz ab v0.9.76.24

Die primären GitHub-Slots bleiben unverändert bei `:11` und `:41` UTC. Zusätzlich prüft der GitHub-interne Watchdog alle zehn Minuten (`:08/:18/:28/:38/:48/:58`). Vor einem Recovery-Dispatch muss er aktive/queued RUC-Läufe respektieren und einen 18-Minuten-`workflow_dispatch`-Cooldown einhalten. Jeder Recovery-Lauf verwendet `force=false`, damit der bestehende Freshness-Guard weiterhin über Neubau oder No-op entscheidet.

Da Primärworkflow und GitHub-Watchdog denselben Scheduler-Provider teilen, ist unter `tools/ruc/cloudflare_schedule_watchdog/` eine optionale provider-unabhängige zweite Cron-Ebene vorbereitet. Sie ist nicht automatisch aktiviert und benötigt kein R2. Ihre Aktivierung setzt ein separat als Cloudflare-Secret hinterlegtes, minimal berechtigtes GitHub-Token voraus. Ohne diese manuelle Credential-Freigabe bleibt die externe Ebene inaktiv; der produktive GitHub-Pfad funktioniert weiterhin mit den beiden Primärslots und dem verdichteten GitHub-Watchdog.

## Optionaler R2-Pfad

Der bereits gehärtete private Cloudflare-R2-Pfad bleibt vollständig erhalten, wird aber nicht für den kostenlosen Standardbetrieb benötigt. Falls er später ausdrücklich freigegeben wird, enthält er unveränderliche laufbezogene Binärdateien für Deterministik, EPS-Zusammenfassung, native EPS-Member und Lookup. `latest.json` wird erst nach vollständigem Upload und Remote-Größenprüfung atomar aktualisiert; vier vollständige Runs bleiben erhalten. R2 wird vom Worker bevorzugt, wenn das Binding vorhanden und der Lauf frisch/vollständig ist; ansonsten fällt MID auf GitHub Pages zurück.

Als Legacy-Fallback bleiben `MID_DWD_RUC_POINT_ENDPOINT` und `MID_DWD_RUC_EPS_POINT_ENDPOINT` samt optionalen Bearer-Tokens zulässig, sofern sie bereits dekodierte numerische Punktdaten liefern. Fehlt jede RUC-Quelle, bleibt MID über Best Match, ICON-D2 und ICON-D2-EPS voll funktionsfähig.

## Aktivierung und Kosten

Die GitHub-Actions-Pipeline läuft produktiv nur bei explizitem `MID_RUC_PIPELINE_ENABLED=true`. Für `pages-free-v1` ist dies ein technisches Aktivierungsgate, **kein Kosten-Gate**. Der öffentliche MID-Repository-Standardrunner und GitHub Pages sind der vorgesehene kostenlose Pfad. Es werden keine R2-Secrets und kein Cloudflare-Speicher benötigt.

R2-Bucket, R2-Credentials, Custom Domain oder andere potenziell kostenpflichtige Ressourcen bleiben weiterhin hinter dem separaten MID-Kostenvertrag und dürfen nur nach transparenter Kostenangabe und ausdrücklicher Nutzerfreigabe aktiviert werden.

## Regressionen

- `scripts/test-ruc-native-cadence-nowcast-097311.mjs`: parameterabhängige 5-/15-/60-min-Auflösung, Radarpriorität und native Rapid-0–6-h-Vertrag; der Extremwetter-Zustandskern reicht separat bis +14 h.
- `scripts/test-ruc-parameter-audit-097311.mjs`: appweiter 114-Parameter-Audit, Specialist-/Severe-/Solar-Vertrag, Layer-Schutz für SRH/WSHEAR und Sunshine-Duration-Sperre.
- `scripts/test-ruc-dwd-pipeline-09690.mjs`: Domain-, Actions-, Binär-, Free-Pages-, optionaler R2- und Schutzvertrag.
- `scripts/test-ruc-fusion-runtime-09691.mjs`: Worker-Runtimepfad mit RUC-Kalibrierung, EPS-Wahrscheinlichkeit, Cache-/Read-Schutz und Gewittersperre.
- `scripts/test-ruc-pages-free-storage-09700.mjs`: echter statischer Pages-Backendpfad ohne Range-Abhängigkeit.
- `tools/ruc/test_prepare_ruc_pages.py`: Chunking und Ausschluss nativer EPS-Member aus dem Free-Profil.
- `tools/ruc/test_publish_ruc_r2.py`: optionaler Fake-R2-Lauf für atomare Veröffentlichung/Retention.
- `tools/ruc/test_cloudflare_r2_bootstrap.py`: optionaler R2-Bootstrap bleibt private-by-default und kostengegated.
- `scripts/test-ruc-storage-health-09692.mjs` und `tools/ruc/check_ruc_health.py`: Backend-neutrale Health-/Post-Publish-Prüfung ohne Geheimnislecks.
- Bestehende Forecast-Fusion-, Ensemble-, Best-Match-, Worker- und iOS-Regressionen bleiben zusätzlich verbindlich.
## Native ICON-D2-RUC grid coordinates

- Forecast GRIB messages on the native triangular ICON grid are not required to expose synthetic ecCodes `latitudes`/`longitudes` arrays.
- The preprocessing pipeline stages DWD's authoritative `CLAT` and `CLON` fields once per selected run and uses their cell values as the native geographic grid.
- `CLAT`/`CLON` may be encoded in radians; the builder converts them to degrees when their value ranges identify radian units.
- Coordinate count, finiteness and geographic bounds are fail-closed. Deterministic parameters and RUC-EPS must match the native point count.
- No regular-grid regridding is introduced; the compact lookup preserves the native ICON-D2-RUC triangular grid.


## Open-Meteo-Abgrenzung (Stand 02.09.2026)

- Open-Meteo stellt **DWD ICON-D2-RUC derzeit nicht als Forecast-API-Modell bereit**. Die Modell-IDs `icon_d2_ruc` bzw. `dwd_icon_d2_ruc` dürfen deshalb nicht als Open-Meteo-Capability probiert oder als Fallback bezeichnet werden.
- MID bezieht den echten stündlich initialisierten ICON-D2-RUC/RUC-EPS weiterhin ausschließlich aus dem direkten DWD-Open-Data-Preprocessing über den kanonischen Pages-/optional freigegebenen R2-Pfad bzw. den expliziten Punktadapter.
- Open-Meteo `minutely_15` bleibt dennoch wertvoll und wird als **separater Regional-/Best-Match-Pfad** genutzt: in Mitteleuropa reguläres ICON-D2-15-min (Modelllauf alle 3 h), in Nordamerika HRRR-15-min und im AROME-Gebiet die stündlich aktualisierten AROME-France-(HD)-15-min-Produkte.
- Reguläres Open-Meteo ICON-D2-15-min ist **kein Ersatz für ICON-D2-RUC** und erhält deshalb keine stündliche Rapid-Refresh-Kennzeichnung. Beide Quellen dürfen innerhalb der DWD-ICON-Familie nicht als unabhängige Stimmen doppelt gewichtet werden.
- Der generische `/v1/forecast`-Best-Match-Pfad mit `minutely_15` bleibt als breit verfügbarer Kurzfrist-/Fallbackpfad aktiv; die echte DWD-RUC-Kalibrierung hat innerhalb ihres geprüften Gebiets und Horizonts weiterhin Vorrang gemäß diesem Vertrag.
## Niederschlagskonsens ab v0.9.78.6

Der deterministische ICON-D2-RUC bleibt für 0–14 h ein hoch priorisierter Kurzfristpfad, erhält für Niederschlagsmengen jedoch einen separaten, konsensabhängigen Anteil. Die frühere Regel „RUC ist nass → +5 Prozentpunkte RUC-Gewicht“ ist aufgehoben. Ist der RUC deutlich nasser als die Best-Match-Leitstunde, wird die Mengenwirkung kontinuierlich gegen Best Match, DWD MOSMIX (lokale 60-min-Punktmenge / RR1c-naher Konsens) und RUC-EPS geprüft. Zusätzlich dient das RUC-EPS-Q75 als **Upper-Tail-Plausibilisierung**: liegt ein deterministischer RUC-Niederschlag deutlich über lokaler Referenz und RUC-EPS-Q75, wird sein Mengenanteil kontinuierlich gedämpft; Q75 ist ausdrücklich **keine harte Mengenobergrenze**. Gestützte RUC-Signale bleiben erhalten; isolierte nasse Ausreißer werden gedämpft. MOSMIX bleibt korreliertes Postprocessing und keine zusätzliche unabhängige Modellstimme. Radar/Nowcast sowie lokale Messungen bleiben danach höher priorisiert. Für Extremwetter-Regen wird RUC-EPS nur kurzfristig und begrenzt zur Wahrscheinlichkeitseichung verwendet; Schnee/Eis koppeln die RUC-EPS-Niederschlagsstütze ausschließlich an passende deterministische Phasen-/Temperatursignale. Eine RUC-EPS-Windwahrscheinlichkeit wird nicht abgeleitet, solange die Vorverarbeitung nur Niederschlagsmember enthält.


## Zusätzliche Datenintegritäts-Gates ab v0.9.85.208

Der DWD-RUC-Vorprozessor prüft vor Veröffentlichung die GRIB-Initialisierung gegen den beabsichtigten Lauf, die Pflichtstunden auf doppelte Gültigkeitszeitstempel, auf bereitgestellten Roh-Akkumulationen größere Rücksprünge als 0,05 mm sowie nach Einheiten-Normalisierung die physikalische Semantik von Temperatur, Taupunkt, relativer Feuchte, Bewölkung, Wind und Niederschlag. Taupunkt oberhalb Temperatur ist nur bis +0,5 K als numerische Toleranz erlaubt; relative Feuchte/Bewölkung bis ±0,5 Prozentpunkte an den Rändern. Für Temperatur dient ein bewusst breiter Decode-Sanity-Bereich von 180–340 K. Diese Toleranzen sind MID-spezifische technische Plausibilitäts-Gates, ausdrücklich keine DWD-Warnschwellen; meteorologische Extremereignisse innerhalb physikalischer Grenzen dürfen nicht kaschiert werden. Kleine negative Niederschlags-Rundungssprünge bis 0,05 mm werden weiterhin nach bestandener Validierung auf null begrenzt. Vollständig fehlende Pflichtfelder werden abgewiesen, einzelne fehlende Gitterpunkte bleiben fehlend. Weitere GRIB-Parameter-/Level- und modelübergreifende Prüfungen benötigen einen eigenen validierten Vertrag; sie werden durch diese Stufe nicht als bereits umgesetzt bezeichnet.

## GRIB2-Herkunft und Parameter-Signaturen ab v0.9.85.209

Zusätzlich zur fachlichen Validierung müssen alle verarbeiteten GRIB-Nachrichten Edition 2 und das WMO-Erzeugungszentrum 78 (Offenbach, DWD) ausweisen. Dynamische deterministische, optionale, Rapid- und RUC-EPS-Felder dürfen ausschließlich zur angefragten Initialisierung gehören; deren Valid-Time darf nicht vor dem Modelllauf liegen. Innerhalb eines logischen Parameters muss die aus GRIB-Disziplin, Parameterkategorie/-nummer, Höhentyp/-wert, Gittertyp und nativer Punktzahl bestehende Signatur über alle Zeitschritte und Member gleich bleiben. Identische Stützzeiten bzw. EPS-Member/Zeitpaare werden nicht mehr still überschrieben. Die statischen Koordinatenprodukte sind vom strengen dynamischen Laufzeitabgleich ausgenommen, nicht von Edition und Zentrum. Produktfeste shortName-/Level-Tabellen erfordern nachfolgende echte DWD-RUC-v1-Headerkalibrierung; Dateinamen bleiben kein alleiniger Provenienznachweis. Diese Prüfungen sind technische MID-Publish-Gates und keine amtlichen Wetterwarnschwellen.

## Native GRIB-Bitmap ab v0.9.85.213

Die explizite Section-6-Bitmap jeder DWD-GRIB2-Nachricht ist verbindlicher Gültigkeitsbeleg für ihre Rasterzellen. Maskierte Zellen werden vor jeder Einheitennormierung als fehlender Wert geführt; alle 542040 nativen Zellpositionen bleiben für das CLAT-/CLON-Gitter einschließlich Randbereich erhalten. Eine nicht passende, mehrwertige oder fehlende deklarierte Bitmap darf nicht publiziert werden. Physikalisch falsche **gültige** Daten bleiben dem unveränderten Fail-Closed-Validator unterworfen; der Wert 9999 ohne Bitmap ist kein hinreichender Grund für eine automatisierte Reparatur. Bereits festgelegte Wire-NODATA-Werte bleiben identisch. Nach einem Source-Release ist zusätzlich ein real erfolgreicher vollständiger DWD-RUC-/EPS-Preprocessing-Lauf mit Pages-Free-Veröffentlichung zu belegen, bevor Problem #305 abgeschlossen wird.

## MID-C26 .224 · vollständiger Kernvertrag

Die zwölf aus PARAM_MAP abgeleiteten Kernfelder sind verpflichtend, einschließlich pressure_msl (hPa, positiv) und convective_inhibition (normalisierter Betrag, >= -0.01 J/kg Rundungstoleranz). Diese Vor-Packing-Prüfung ersetzt keinen GRIB-Einheitenvertrag und setzt keine neue Missing-Prozentgrenze. EPS-Mitgliedskennungen dürfen sich nicht wiederholen. Tests entfernen jeden einzelnen Pflichtparameter und prüfen negative/Null-Druckwerte, negatives normalisiertes CIN und doppelte EPS-IDs.

## .225 · explizite Einheiten und numerische Einheitennaht

Temperatur wird nur bei K/Kelvin in Celsius, Druck nur bei Pa in hPa und Prozentfelder nur bei expliziter Bruchteil-Einheit in Prozent umgerechnet. Wertemagnitude entscheidet niemals über Einheiten. Native Prozentwerte einschließlich0..1 bleiben unverändert. Unbekannte Einheiten der kontrollierten Felder werden vor Packing abgewiesen. Reale Header-Samples mit URL/Hash sind archiviert; feste gesamte GRIB-Parameter-/Levelmatrix bleibt separat offen.

## .226 · Missing bleibt Missing bei Extremwetter-Aggregation

Niederschlagsmengen über eine Periode dürfen nur bei vollständigen endlichen Intervallen summiert werden. Vollständig oder teilweise fehlende Intervalle sind keine trockenen Nullen. Rollierende Maxima berücksichtigen vollständige Fenster und erhalten gültige Fenster trotz späterer Datenlücken. EPS-Perioden-Wahrscheinlichkeiten und Quantile verwenden denselben vollständigen Mitgliedersatz pro Zelle; unvollständige Mitglieder werden ausgeschlossen. Fehlende optionale Phasen und ungültige Summen bleiben auch in Kompatibilitätsfeldern absent. Keine neue Prozent-Freigabegrenze, keine Wetter-/Warnschwellenänderung.

## .227 · verbleibende Kern- und Koordinateneinheiten

CLAT/CLON verwenden deklarierte, achsenspezifische Grad-Einheiten oder explizite Radiant-Einheiten. Größenheuristiken sind unzulässig; kleine Gradwerte dürfen nicht als Radiant interpretiert werden. Endliche Werte und geographische Bounds bleiben erforderlich. Windkomponenten/Böen müssen m/s, CAPE/CIN J/kg und Niederschlagsakkumulation kg/m² oder äquivalente mm Wassersäule deklarieren. Unbekannte oder fremde Größeneinheiten werden vor Packing abgewiesen. Native Missing-/Nullwerte bleiben erhalten. Archivierte Header-Stichproben sind keine vollständige Zeit-/Level-/Gitteridentitätsabnahme.

## .228 · kalibrierte Kernparameter, rohe Schichten und native Gitteridentität

CORE_CONTRACTS in tools/ruc/grib_metadata.py ist verbindlich für alle zwölf Kernparameter, CLAT/CLON und EPS TOT_PREC. Die kalibrierten raw Fixed-Surface-Codes und dekodierten skalierten Werte bleiben maßgeblich, auch wenn typeOfLevel unknown ist. Unstrukturierte Felder einschließlich optionaler Felder müssen das belegte native UUID-/Grid-/Reference-/Punktzahl-Tupel treffen; eine Gitterrevision ist bis zur Neukalibrierung fail-closed. Optionale Parameter-/Levelmatrizen sind hiervon nicht als kalibriert erklärt.

Der Produktionsbuilder erwartet ausdrücklich EPS-IDs1..20. Auch ein über die gesamte Zeitachse fehlendes Mitglied muss abgewiesen werden, statt aus einer beobachteten Vereinigungsmenge zu verschwinden. Synthetische Hilfsfixtures dürfen weiterhin eigene ausdrücklich angeforderte IDs verwenden; der Produktionsaufruf bleibt an den kalibrierten DWD-Satz gebunden.

UTC valid=initialization+endStep; instant start=end, Niederschlagsakkumulation ab0, Böen-Maximum start=max(0,end-1h) bei nativen Stunden und Nullfenster am Laufstart. Minute/Stunde/Sekunde werden explizit dekodiert, mit oder ohne passenden ecCodes-Suffix. sourceGribContract ist zusätzliche maschinenlesbare Quellsemantik in latest.json; vorhandene Binärlayouts und Intervallmengen bleiben identisch. Vollständige angeforderte Header-Achsen sind separat vom vollständigen Werte-/E2E-Referenzlauf nachzuweisen.

## .258 · optionaler begrenzter verlustfreier Dual-Read-Pilot

grid.v2 und pages-free-v1 bleiben unverändert lesbar. Optional darf deterministic.pages.losslessV1 genau einen letzten deterministischen Chunk mit maximal 524288 Originalbytes ergänzen (Schema mid.ruc.dual-read.v1). Alle Rohschlüssel, Rohbytes und SHA bleiben erhalten. Byteplane-gzip liegt ausschließlich unter dem gleichen Laufnamespace und vollständigem Wire-SHA-Schlüssel; niemals unter einem Rohschlüssel. Originalbestand, Zusatzkopie und vollständiges Manifest müssen gemeinsam strikt unter 900000000 Bytes bleiben. Kein Platz oder Kompressionsvorteil bedeutet unverändertes Rohprodukt, nicht weniger Felder, Karten oder Termine.

Aktivierte Leser prüfen vor dem Abruf Deskriptorschema, Größen, Chunk-Geometrie und Roh-/Lauf-/SHA-Bindung. Wire-SHA vor und Original-SHA nach begrenztem Inflate sind verbindlich. Ein gültiger, aber fehlgeschlagener Codec darf nur auf größen- und SHA-identische Rohbytes zurückfallen; ein ebenfalls ungültiger Rohfallback ergibt NoData, keine Null. Ungültige optionale Deskriptoren bleiben im Legacy-Rohpfad ohne Codecabruf. Abschaltung oder alte Leser müssen unveränderte Rohdaten verwenden können. Der Pilot gilt erst nach einem echten veröffentlichten RUC-Lauf und codecPilot.verified=true am deployten Worker als produktiv belegt. Vollständige Rohablösung ist nicht Teil dieses Piloten.

## .263 · begrenzte gleichzeitige Codec-Arbeit
Gleicher Ursprung/Rohschlüssel/Manifest darf im selben Isolate nur einen laufenden Wireabruf mit SHA-geprüfter Dekodierung erzeugen. Maximal zwei verschiedene Codec-Vorgänge sind gleichzeitig aktiv. Weitere Schlüssel verwenden einen gegen Originalgröße/SHA geprüften Rohfallback mit reason codec-busy; dies ist kein 30-s-Codecfehler. Erfolg und Fehler räumen laufende Einträge auf. Verified-Cache (zwei Chunks), Rejected-Cache (vier Einträge), 3-s-Bodydeadline, Pilotumfang und Rohbestand bleiben unverändert. Neue Offline-Browserprüfungen verwenden den byteidentischen Original-Service-Worker .257 (Blob 9025890e5d44d880149602f2956d4782fe18cc4f, Source e0f05c5059a6b5e88c377f433e9737423a174393) und den aktuellen Worker. Poisoned Shell-Caches dürfen keine RUC-Binärdaten oder Live-API-Daten als Offline-Ersatz liefern. Browser-Simulation ist keine physische iOS-/Cloudflare-CPU-/RAM-Abnahme und keine Vollmigrationsfreigabe.

## .264 · Vollständige Inventur und separater Offline-Migrationsnachweis
Vollständige Speicheranalysen prüfen alle deklarierten Dateien einschließlich JSON, nativer gzip-Karten und nicht komprimierter Objekte gegen Größe/SHA, eindeutige sichere Schlüssel, Inventursumme und das unveränderte Budget. Ein separater Offline-Prüfer darf deklarierte int16-Produkte an ganzen Datensätzen in maximal524288 Originalbytes große Teile zerlegen; Python- und tatsächliche JS-Decoder müssen jeden Originalbytewert und die vollständige Objekt-SHA rekonstruieren. Physisch deduplizierte Originale und Codecdateien werden jeweils einmal gezählt. Ersatzlayout und Layout mit sämtlichen Rohkopien einschließlich vollständiger Deskriptoren getrennt bilanzieren. Dies ist kein produktiver Manifest-/Formatwechsel, kein Gesamtspeichernachweis aus Teilbeständen und keine ProviderCPU/RAM-/Rolloutfreigabe. Originalbestand, aktiver Pilot und900000000B-Grenze bleiben erhalten.

## .265 · Vollständiges Ersatzpaket ausschließlich als separater Kandidat
Das Profil pages-lossless-candidate-v1 darf nur durch das explizite Offline-Werkzeug in einem neuen Verzeichnis außerhalb des unveränderten Original-/Rückfallbestands entstehen. Es ist keine produktive Profilfreigabe. Wissenschaftliche Metadaten und unveränderte andere Dateien bleiben identisch; int16-Produkte enthalten lückenlose compressedPages-Bereiche mit Recordgeometrie, Laufnamespace und vollständigen Wire-/Original-SHA. Originalparts<=524288B, Wire<=524800B, maximal8192 Teile und10Millionen Records pro Produkt, endgültiger Payload plus vollständiges Manifest strikt unter900000000B. Der vorbereitete Reader bleibt außerhalb der produktiven Worker-Aggregate und verlangt expliziten Opt-in. Höchstens zwei aktive Jobs und32 wartende unterschiedliche Jobs, zwei Decodecache- und vier Fehlercacheeinträge, maximal3000ms Deadline; volle Queue/Timeout/Codecfehler ergeben NoData, keinen erfundenen Rohfallback oder Nullwert. Original- und Kandidatenobjekte vollständig hashen, sämtliche Teile in Python/JS bytegleich prüfen und tatsächlichen meteorologischen Record-Decoder vergleichen. Produktive Integration einschließlich Publisher/Preserver/Health, Betriebsnachweise und gekoppelter Daten-/Reader-Rückfall sind gesonderte Freigabeschritte.


## MID-C47 · v0.9.85.344 · Unveränderliche Übergaben und Wiederzulassung

- Berechnung (`calculate`) und Aufbereitung (`prepare`) besitzen getrennte 45-Minuten-Jobgrenzen. Die Berechnung lädt/dekodiert weiterhin den qualifizierten +0..+27-h-Kern einschließlich nativer EPS; die Aufbereitung behält alle bestehenden Wire-/Native-/Pages-/Rohrollback-/vollständigen Python-/JS-/meteorologischen Codec- und optionalen Kartenprüfungen. Keine Pflichtprüfung wird übersprungen. Der Rohcheckpoint ist nicht veröffentlichbar. Die bereits validierten PMSL-/CLCT-GRIB-Dateien bleiben SHA-gebunden für denselben optionalen Kartenpfad erhalten; auch diese Dateien werden nicht veröffentlicht.
- Zwischen beiden Jobs wird der vollständige Kern samt Producer-Identität, Quellvertrag und sämtlichen Objekt-SHAs über eine exakte unveränderliche Artefakt-ID mit verpflichtender Digest-Prüfung transportiert. Ein fehlgeschlagener Aufbereitungsjob kann innerhalb der Retention wiederholt werden, ohne die erfolgreiche Berechnung erneut auszuführen. Rohcheckpoint: ein Tag, bestehende vollständig vorbereitete Daten und Rohrollback: zwei Tage.
- `reuse_run_id` ist eine ausdrücklich gewählte ursprüngliche Producer-Run-ID. Die Wiederverwendung überspringt fachliche Berechnung, GRIB-Download und Nebenprodukt-Neubau vollständig. `force=true` und Wiederverwendung sind widersprüchlich und werden abgewiesen. Ein Replay-Lauf ohne neu erzeugte Original-Artefakte wird nicht als neuer Producer akzeptiert.
- Zulässige Producer stammen aus demselben geschützten Repository, `main`, dem exakten etablierten RUC-Workflow und `schedule`/`workflow_dispatch`; der ursprüngliche `prepare`-Job muss erfolgreich sein. Daten und Rohrollback werden als eindeutiges, nicht abgelaufenes Artefaktpaar desselben Producer-Versuchs per ID/Digest gebunden. Die Receipt muss zur authentifiziert gelesenen Event-SHA, Run-ID und zum Producer-Versuch passen. Producer-Code und Event müssen als Vorfahren des aktuellen Consumers nachgewiesen werden; bei unzureichender verfügbarer Historie wird fail-closed abgewiesen.
- Der konservative Datenvertrag bindet RUC-Quellen, Python-/JS-Decoder, Worker-Quellen, RUC-Clients, Pipelinevertrag, Workflow und Lockfile. Nur die reine MID-Releaseversion in Worker/Lockfile wird normalisiert. Reine UI-/Versionsänderungen können damit zulässig bleiben; Änderungen an diesem Quellvertrag benötigen eine neue vollständige Producer-Qualifikation. Keine pauschale Annahme gleicher Schemanamen.
- Nach erneuter vollständiger Größen-/SHA-Inventarprüfung, Python- und unabhängiger JS-Dekodierung aller komprimierten Teile, Record-Decoder-Stichproben und Prüfung der ursprünglichen vollständigen meteorologischen Migration-Proof werden unveränderte Bytes zugelassen. Die bestehende Vier-Stunden-Frischegrenze mit höchstens fünf Minuten Uhrentoleranz bleibt erhalten. Unbekannte Dateien/Symlinks, unqualifizierte Stundenachsen, fehlende Original-Proofs und Budgetverletzungen sind fatal. Ein neuerer bereits veröffentlichter RUC-Lauf darf nicht durch einen älteren Snapshot ersetzt werden.
- Die Daten-Receipt ist kein selbständiger Vertrauensanker. Erst authentifizierter Producer/Artefaktursprung, geprüfte SHA-Linie, identischer Quellvertrag und erneute vollständige Byte-/Decoderprüfung zusammen begründen die Zulassung. Alte Artefakte ohne Receipt werden nicht nachträglich durch eine erfundene Producer-Freigabe legitimiert.
- Veröffentlichung bleibt ein eigener kurzer `mid-pages`-Lock mit ausschließlich aktueller Stable-App-Shell. Ein laufender App-Release bleibt ein sicherer No-op. Der zweite Guard bindet die exakte aktuell zugelassene Consumer-SHA; Producer-SHA und Consumer-SHA werden getrennt protokolliert. Keine Wiederherstellung einer alten App-Shell aus Datenartefakten. Feste 900-MB-Daten-/950-MB-Site-Grenzen, produktives Worker-Healthgate und ursprünglicher unveränderlicher Rohrollback bleiben verbindlich.
- Alle GitHub-Schritte erhalten ihren tatsächlichen Start, ihr Ende, ihre Laufzeit und ihre unveränderte Konklusion im Diagnosebericht. Unterprozesse protokollieren zusätzlich monotone Laufzeit, Exitcode, Signal, Deadline oder Elternsignal. Ein unaufgeklärtes GitHub-`cancelled` wird nicht als bewiesener Timeout oder benannter manueller Abbruch ausgegeben. Nach einem unauffangbaren Kill verbleibt gegebenenfalls nur der zuvor geflushte Start im Joblog; GitHub-Metadaten bleiben die maßgebliche äußere Evidenz.
- Der neue aktive Workflow darf den Vertrag nicht aus noch nicht promotetem App-Code ausführen: Fehlt der Handoff-Validator auf dem ausgecheckten Stable während des erstmaligen Releasefensters, bleibt der letzte geprüfte Datensatz erhalten. Der nächste reguläre/watchdog-getriggerte Lauf verwendet den promoteten Vertrag.

Fachliche Nichtänderung: keine Ausweitung über die bereits qualifizierten +27 h, keine Änderung nativer Rapid-/Extremwertachsen, EPS-Werte, Missing-Konventionen, Auflösung oder Decoder-Budgets. Keine unqualifizierte Integration der Drafts #480/#449/#433/#463.
