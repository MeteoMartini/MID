MID-GITHUB-WORKFLOWS v0.9.19.0

Diese ZIP nicht auf dem iPhone öffnen.
Die Datei MID-github-workflows.zip unverändert in das Hauptverzeichnis des GitHub-Branches main hochladen.
Der vorhandene MID-Workflow verarbeitet das Archiv serverseitig und legt die Dateien in .github an.

Ausgangsbasis: mid-stable v0.9.18.6, Commit c60e7878402609ed2246052cc92bd2a7da36d2bc
