module.exports={
 ci:{
  collect:{url:[process.env.MID_SITE_URL||'https://www.midwx.app/'],numberOfRuns:3,settings:{preset:'desktop',chromeFlags:'--headless --no-sandbox --disable-dev-shm-usage'}},
  assert:{assertions:{
   'categories:performance':['warn',{minScore:0.70}],
   'categories:accessibility':['error',{minScore:0.88}],
   'categories:best-practices':['error',{minScore:0.85}],
   'categories:seo':['error',{minScore:0.90}],
   'largest-contentful-paint':['warn',{maxNumericValue:4500}],
   'cumulative-layout-shift':['error',{maxNumericValue:0.20}],
   'total-blocking-time':['warn',{maxNumericValue:900}],
   'uses-responsive-images':'warn',
   'unused-javascript':'warn'
  }},
  upload:{target:'filesystem',outputDir:'artifacts/lighthouse'}
 }
};
