import {test,expect} from '@playwright/test';

const siteUrl=new URL(process.env.MID_SITE_URL||'https://www.midwx.app/');
const criticalConsole=/Uncaught|TypeError|ReferenceError|SyntaxError|ChunkLoadError/i;

test('MID startet ohne kritische Browserfehler und zeigt die Kernoberfläche',async({page})=>{
 const consoleErrors=[];
 const pageErrors=[];
 const failedFirstPartyRequests=[];
 page.on('console',message=>{if(message.type()==='error'&&criticalConsole.test(message.text()))consoleErrors.push(message.text())});
 page.on('pageerror',error=>pageErrors.push(error.message));
 page.on('requestfailed',request=>{const url=new URL(request.url());if(url.hostname===siteUrl.hostname)failedFirstPartyRequests.push(`${request.failure()?.errorText||'failed'} ${url}`)});
 const response=await page.goto('/',{waitUntil:'domcontentloaded'});
 expect(response?.status()).toBeLessThan(400);
 await expect(page).toHaveTitle(/MID Wetter/i);
 await expect(page.locator('#root')).toBeVisible();
 await expect(page.locator('#mid-boot-shell')).toHaveCount(0,{timeout:30000});
 await expect(page.locator('body')).toContainText(/MID|Wetter/i);
 await expect(page.locator('button').first()).toBeVisible({timeout:15000});
 const horizontalOverflow=await page.evaluate(()=>document.documentElement.scrollWidth-document.documentElement.clientWidth);
 expect(horizontalOverflow).toBeLessThanOrEqual(4);
 await page.waitForTimeout(2500);
 expect(pageErrors,`Unbehandelte Seitenfehler:\n${pageErrors.join('\n')}`).toEqual([]);
 expect(consoleErrors,`Kritische Konsolenfehler:\n${consoleErrors.join('\n')}`).toEqual([]);
 expect(failedFirstPartyRequests,`Fehlgeschlagene MID-Ressourcen:\n${failedFirstPartyRequests.join('\n')}`).toEqual([]);
});

test('Manifest, Version und Service Worker sind produktiv erreichbar',async({request})=>{
 for(const path of ['/manifest.webmanifest','/version.json','/service-worker.js','/sw.js']){
  const response=await request.get(path,{headers:{'cache-control':'no-cache'}});
  expect(response.status(),path).toBe(200);
  expect((await response.body()).length,path).toBeGreaterThan(20);
 }
});
