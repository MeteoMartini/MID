# MID – automatisierte Code-Revision v0.9.19.0

Die Revision ergänzt die laufende Qualitätssicherung der verbindlichen `mid-stable`-Codebasis:

- CI bei Push und Pull Request,
- tägliche vollständige Regression und Sicherheitsprüfung,
- sechsstündliche Produktiv- und API-Vertragsprüfung,
- wöchentliche Playwright-/Lighthouse-Revision,
- CodeQL für JavaScript und TypeScript,
- Dependabot-Vorlage für npm und GitHub Actions,
- deduplizierte GitHub-Issues bei reproduzierbaren Fehlern,
- Build- und Bundlegrößenbudget.

Die Workflowdatei wird aus Sicherheits- und GitHub-Berechtigungsgründen einmalig manuell sowohl in `main` als auch in `mid-stable` unter `.github/workflows/mid-code-revision.yml` abgelegt. Auf dem iPhone muss dafür kein versteckter lokaler Ordner geöffnet werden; nur die sichtbare Datei `mid-code-revision.yml` wird im bereits geöffneten GitHub-Ordner hochgeladen.
