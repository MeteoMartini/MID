# MID automatisierte Code-Revision v0.9.19.0 – Installer Revision 2

## Korrektur des Installationsverfahrens
- Der verifizierte Abhängigkeitsstand aus MID v0.9.18.6 wird ausschließlich mit `npm ci` geladen.
- `package-lock.json` wird vor den Regressionen nicht neu berechnet.
- Playwright und Lighthouse werden nur im wöchentlichen Performance-Job isoliert mit `--no-save --no-package-lock` installiert.
- Die sechs beim ersten Versuch gemeldeten Cockpit-Regressionen werden vor und nach dem Overlay separat geprüft.
- Der korrigierte Workflow wird bei erfolgreicher Installation automatisch von `main` nach `mid-stable` synchronisiert.

# MID – automatisierte Code-Revision v0.9.19.0

Die Revision ergänzt die laufende Qualitätssicherung der verbindlichen `mid-stable`-Codebasis:

- CI bei Push und Pull Request,
- tägliche vollständige Regression und Sicherheitsprüfung,
- sechsstündliche Produktiv- und API-Vertragsprüfung,
- wöchentliche Playwright-/Lighthouse-Revision,
- CodeQL für JavaScript und TypeScript,
- Dependabot-Vorlage für npm und GitHub Actions,
- deduplizierte GitHub-Issues bei reproduzierbaren Fehlern,
- Build- und Bundlegrößenbudget.

Die Workflowdatei wird aus Sicherheits- und GitHub-Berechtigungsgründen einmalig manuell sowohl in `main` als auch in `mid-stable` unter `.github/workflows/mid-code-revision.yml` abgelegt. Auf dem iPhone muss dafür kein versteckter lokaler Ordner geöffnet werden; nur die sichtbare Datei `mid-code-revision.yml` wird im bereits geöffneten GitHub-Ordner hochgeladen.
## Installer-Revision 4
Der Versionsvertrag der sechs jüngsten Cockpit-Regressionen wird zeilenbasiert und idempotent umgestellt. Dadurch ist die Reparatur unabhängig davon, wie Anführungszeichen im JavaScript-Quelltext escaped sind. Die fachlichen Cockpit-Prüfungen bleiben unverändert.

