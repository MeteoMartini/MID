import {readFile} from 'node:fs/promises';

const requiredFiles=[
 '.github/workflows/mid-code-revision.yml',
 'MID_DEPENDABOT_TEMPLATE.yml',
 'playwright.config.mjs',
 'tests/smoke/mid-production.spec.mjs',
 'lighthouserc.cjs',
 'MID_PERFORMANCE_BASELINE.json',
 'scripts/check-deployed-mid.mjs',
 'scripts/check-api-contracts.mjs',
 'scripts/check-build-budget.mjs',
 'scripts/create-revision-report.mjs'
];
const failures=[];
for(const file of requiredFiles){try{await readFile(new URL(`../${file}`,import.meta.url),'utf8')}catch{failures.push(`Pflichtdatei fehlt: ${file}`)}}

let workflow='';
try{workflow=await readFile(new URL('../.github/workflows/mid-code-revision.yml',import.meta.url),'utf8')}catch{}
for(const token of [
 'MID CI verify',
 'MID-code-revision-v0.9.19.0.zip',
 "cron: '17 3 * * *'",
 "cron: '23 */6 * * *'",
 "cron: '23 2 * * 0'",
 "cron: '41 1 * * 3'",
 'scripts/check-deployed-mid.mjs',
 'scripts/check-api-contracts.mjs',
 'scripts/check-build-budget.mjs',
 'playwright test',
 'lhci autorun',
 'github/codeql-action/init@',
 'gh issue create'
])if(!workflow.includes(token))failures.push(`Workflow-Vertrag fehlt: ${token}`);
for(const line of workflow.match(/^\s*uses:\s*[^\s#]+/gm)||[]){
 const revision=line.match(/@([^\s#]+)/)?.[1];
 if(!revision||!/[0-9a-f]{40}/i.test(revision))failures.push(`Action nicht auf vollständigen SHA fixiert: ${line.trim()}`);
}

const dependabot=await readFile(new URL('../MID_DEPENDABOT_TEMPLATE.yml',import.meta.url),'utf8');
if((dependabot.match(/target-branch:\s*mid-stable/g)||[]).length<2)failures.push('Dependabot zielt nicht für npm und GitHub Actions auf mid-stable');
if(workflow.includes('npm install --package-lock-only'))failures.push('Installer berechnet das verifizierte MID-Lockfile neu');
if(!workflow.includes('Verifizierte Abhängigkeiten unverändert aus Lockfile installieren'))failures.push('Lockfile-treue Installation fehlt');
if(!workflow.includes('npm install --no-save --no-package-lock'))failures.push('Isolierte Installation der Browserwerkzeuge fehlt');
if(!workflow.includes('Gemeldete Cockpit-Regressionen auf unveränderter Stable-Basis vorprüfen'))failures.push('Stable-Vorabprüfung der gemeldeten Cockpit-Regressionen fehlt');
if(!workflow.includes('cp "$GITHUB_WORKSPACE/.github/workflows/mid-code-revision.yml"'))failures.push('Korrigierter Revisionsworkflow wird nicht nach mid-stable synchronisiert');
const packageJson=JSON.parse(await readFile(new URL('../package.json',import.meta.url),'utf8'));
if(packageJson.devDependencies?.['@playwright/test']||packageJson.devDependencies?.['@lhci/cli'])failures.push('Browserwerkzeuge dürfen das produktive MID-Lockfile nicht verändern');
const baseline=JSON.parse(await readFile(new URL('../MID_PERFORMANCE_BASELINE.json',import.meta.url),'utf8'));
for(const key of ['assetCount','totalBytes','totalGzipBytes','jsGzipBytes','cssGzipBytes','largestJsGzipBytes'])if(!Number.isFinite(baseline.limits?.[key]))failures.push(`Performance-Limit fehlt: ${key}`);
if(failures.length){console.error(`Code-Revisionsautomation unvollständig:\n- ${failures.join('\n- ')}`);process.exit(1)}
console.log('Code-Revisionsautomation vollständig: CI, Nightly, Live-Checks, API-Verträge, Dependabot, CodeQL, Playwright, Lighthouse, Build-Budget und Issue-Meldung sind abgesichert.');
