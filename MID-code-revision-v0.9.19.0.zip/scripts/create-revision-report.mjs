import {mkdir,readdir,readFile,writeFile} from 'node:fs/promises';
import path from 'node:path';

const artifactDir=path.resolve('artifacts');
await mkdir(artifactDir,{recursive:true});
const sections=[];
for(const name of (await readdir(artifactDir)).filter(name=>name.endsWith('.json')).sort()){
 try{const data=JSON.parse(await readFile(path.join(artifactDir,name),'utf8'));sections.push({name,ok:data.ok!==false,failures:data.failures||[],warnings:data.warnings||[],summary:data.totals||data.checks?.length||null})}catch{}
}
const status=sections.every(section=>section.ok)?'bestanden':'fehlgeschlagen';
const markdown=[`# MID Revisionsbericht`,``,`Erzeugt: ${new Date().toISOString()}`,`Workflow: ${process.env.GITHUB_WORKFLOW||'lokal'}`,`Run: ${process.env.GITHUB_RUN_ID||'-'}`,`Commit: ${process.env.GITHUB_SHA||'-'}`,`Gesamtstatus: **${status}**`,``];
for(const section of sections){markdown.push(`## ${section.name}`,``,`Status: **${section.ok?'bestanden':'fehlgeschlagen'}**`,``,...(section.warnings.length?['Warnungen:',...section.warnings.map(item=>`- ${item}`),'']:[]),...(section.failures.length?['Fehler:',...section.failures.map(item=>`- ${item}`),'']:[]))}
await writeFile(path.join(artifactDir,'revision-report.md'),`${markdown.join('\n')}\n`);
if(process.env.GITHUB_STEP_SUMMARY)await writeFile(process.env.GITHUB_STEP_SUMMARY,`${markdown.join('\n')}\n`,{flag:'a'});
console.log(`Revisionsbericht erstellt: ${sections.length} Teilberichte, Status ${status}.`);
