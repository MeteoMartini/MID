import {mkdir,writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';

const timeoutMs=Math.max(7000,Number(process.env.MID_API_TIMEOUT_MS)||22000);
const failures=[];
const warnings=[];
const checks=[];

function sameLength(payload,group,required){
 const source=payload?.[group];
 if(!source||!Array.isArray(source.time)){failures.push(`${group}: time fehlt`);return}
 const length=source.time.length;
 for(const field of required){
  if(!Array.isArray(source[field]))failures.push(`${group}.${field} fehlt oder ist kein Array`);
  else if(source[field].length!==length)failures.push(`${group}.${field}: ${source[field].length} Werte statt ${length}`);
 }
 for(let index=1;index<source.time.length;index++)if(String(source.time[index])<=String(source.time[index-1])){failures.push(`${group}.time ist nicht streng aufsteigend`);break}
}
function range(values,min,max,label,{nullable=true}={}){
 if(!Array.isArray(values))return;
 for(const [index,value] of values.entries()){
  if(value===null&&nullable)continue;
  if(typeof value!=='number'||!Number.isFinite(value)||value<min||value>max){failures.push(`${label}[${index}] unplausibel: ${value}`);break}
 }
}
async function getJson(name,url,{soft=false}={}){
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),timeoutMs);
 const started=performance.now();
 try{
  const response=await fetch(url,{signal:controller.signal,headers:{accept:'application/json','cache-control':'no-cache','user-agent':'MID-contract-monitor/1.0'}});
  const elapsedMs=Math.round(performance.now()-started);
  const text=await response.text();
  let payload;
  try{payload=JSON.parse(text)}catch{throw new Error(`ungültiges JSON: ${text.slice(0,120)}`)}
  checks.push({name,url,status:response.status,elapsedMs,bytes:Buffer.byteLength(text)});
  if(!response.ok||payload?.error)throw new Error(`HTTP ${response.status}: ${payload?.reason||payload?.error||text.slice(0,160)}`);
  if(elapsedMs>12000)warnings.push(`${name} langsam: ${elapsedMs} ms`);
  return payload;
 }catch(error){
  const message=`${name}: ${error instanceof Error?error.message:String(error)}`;
  if(soft)warnings.push(message);else failures.push(message);
  return null;
 }finally{clearTimeout(timer)}
}

const forecastFields=['temperature_2m','precipitation_probability','weather_code','wind_speed_10m','wind_direction_10m'];
const dailyFields=['weather_code','temperature_2m_max','temperature_2m_min','sunrise','sunset','moonrise','moonset','moon_phase'];
const referenceLocations=[
 {name:'Niederkassel',lat:50.815,lon:7.037,model:'best_match'},
 {name:'Sölden',lat:46.969,lon:11.010,model:'best_match'},
 {name:'ICON-D2 Köln',lat:50.938,lon:6.960,model:'icon_d2'}
];
for(const place of referenceLocations){
 const query=new URLSearchParams({latitude:String(place.lat),longitude:String(place.lon),timezone:'auto',forecast_days:'3',models:place.model,wind_speed_unit:'kn',hourly:forecastFields.join(','),daily:dailyFields.join(',')});
 const payload=await getJson(`Open-Meteo Forecast ${place.name}`,`https://api.open-meteo.com/v1/forecast?${query}`);
 if(!payload)continue;
 sameLength(payload,'hourly',forecastFields);
 sameLength(payload,'daily',dailyFields);
 range(payload.hourly?.precipitation_probability,0,100,`${place.name}.precipitation_probability`);
 range(payload.hourly?.wind_direction_10m,0,360,`${place.name}.wind_direction_10m`);
 range(payload.hourly?.temperature_2m,-90,65,`${place.name}.temperature_2m`);
 range(payload.daily?.moon_phase,0,1,`${place.name}.moon_phase`);
}

const ensembleQuery=new URLSearchParams({latitude:'50.938',longitude:'6.960',timezone:'auto',forecast_days:'3',models:'icon_d2',wind_speed_unit:'kn',hourly:'temperature_2m,precipitation,wind_speed_10m,wind_gusts_10m'});
const ensemble=await getJson('Open-Meteo Ensemble ICON-D2',`https://ensemble-api.open-meteo.com/v1/ensemble?${ensembleQuery}`);
if(ensemble){
 if(!ensemble.hourly||!Array.isArray(ensemble.hourly.time))failures.push('Ensemble.hourly.time fehlt');
 const memberFields=Object.keys(ensemble.hourly||{}).filter(key=>key!=='time');
 if(memberFields.length<4)failures.push(`Ensemble liefert zu wenige Mitgliedsfelder: ${memberFields.length}`);
 for(const field of memberFields.slice(0,12))if(!Array.isArray(ensemble.hourly[field])||ensemble.hourly[field].length!==ensemble.hourly.time.length){failures.push(`Ensemblefeld ${field} ist nicht zeitachsen-konsistent`);break}
}

for(const model of ['icon_d2','icon_eu','ecmwf_ifs025']){
 const meta=await getJson(`Open-Meteo Metadaten ${model}`,`https://api.open-meteo.com/data/${model}/static/meta.json`,{soft:true});
 if(meta){
  const update=Number(meta.update_interval_seconds);
  const availability=Date.parse(meta.last_run_availability_time||meta.last_run_modification_time||'');
  if(Number.isFinite(update)&&Number.isFinite(availability)){
   const ageSeconds=(Date.now()-availability)/1000;
   if(ageSeconds>update+7200)warnings.push(`${model}: letzter verfügbarer Lauf ist ${Math.round(ageSeconds/60)} Minuten alt`);
  }
 }
}

if(process.env.MID_WORKER_HEALTH_URL)await getJson('MID Cloudflare Worker',process.env.MID_WORKER_HEALTH_URL,{soft:false});

const report={schema:1,generatedAt:new Date().toISOString(),ok:failures.length===0,failures,warnings,checks};
await mkdir('artifacts',{recursive:true});
await writeFile('artifacts/api-contracts.json',`${JSON.stringify(report,null,2)}\n`);
if(process.env.GITHUB_STEP_SUMMARY){
 const rows=checks.map(item=>`| ${item.name} | ${item.status} | ${item.elapsedMs} ms | ${item.bytes} |`).join('\n');
 await writeFile(process.env.GITHUB_STEP_SUMMARY,`## MID API-Vertragsprüfung\n\nStatus: **${report.ok?'bestanden':'fehlgeschlagen'}**\n\n| Prüfung | HTTP | Zeit | Bytes |\n|---|---:|---:|---:|\n${rows}\n\n${warnings.length?`### Warnungen\n${warnings.map(item=>`- ${item}`).join('\n')}\n`:''}${failures.length?`### Fehler\n${failures.map(item=>`- ${item}`).join('\n')}\n`:''}`,{flag:'a'});
}
if(warnings.length)console.warn(`API-Vertragswarnungen:\n- ${warnings.join('\n- ')}`);
if(failures.length){console.error(`API-Vertragsprüfung fehlgeschlagen:\n- ${failures.join('\n- ')}`);process.exit(1)}
console.log(`API-Vertragsprüfung bestanden: ${checks.length} externe Verträge geprüft.`);
