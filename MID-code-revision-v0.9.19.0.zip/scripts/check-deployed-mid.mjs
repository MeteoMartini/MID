import {mkdir,writeFile} from 'node:fs/promises';
import {performance} from 'node:perf_hooks';

const baseUrl=new URL(process.env.MID_SITE_URL||'https://www.midwx.app/');
const apexUrl=new URL(process.env.MID_APEX_URL||'https://midwx.app/');
const timeoutMs=Math.max(5000,Number(process.env.MID_HEALTH_TIMEOUT_MS)||20000);
const maxDocumentMs=Math.max(1000,Number(process.env.MID_DOCUMENT_WARN_MS)||6000);
const failures=[];
const warnings=[];
const checks=[];

async function fetchTimed(url,{expectedStatus=200,redirect='follow',requiredContentType}={}){
 const controller=new AbortController();
 const timer=setTimeout(()=>controller.abort(),timeoutMs);
 const started=performance.now();
 try{
  const response=await fetch(url,{redirect,signal:controller.signal,headers:{accept:'*/*','cache-control':'no-cache','user-agent':'MID-revision-monitor/1.0'}});
  const elapsedMs=Math.round(performance.now()-started);
  const body=await response.text();
  const result={url:String(url),finalUrl:response.url,status:response.status,elapsedMs,contentType:response.headers.get('content-type')||'',bytes:Buffer.byteLength(body)};
  checks.push(result);
  if(response.status!==expectedStatus)failures.push(`${url}: HTTP ${response.status} statt ${expectedStatus}`);
  if(requiredContentType&&!result.contentType.toLowerCase().includes(requiredContentType))failures.push(`${url}: unerwarteter Content-Type ${result.contentType||'(leer)'}`);
  return {response,body,result};
 }catch(error){
  const message=error instanceof Error?error.message:String(error);
  failures.push(`${url}: ${message}`);
  return {response:null,body:'',result:null};
 }finally{clearTimeout(timer)}
}

const home=await fetchTimed(baseUrl,{requiredContentType:'text/html'});
if(home.result&&home.result.elapsedMs>maxDocumentMs)warnings.push(`Startdokument langsam: ${home.result.elapsedMs} ms > ${maxDocumentMs} ms`);
if(home.body){
 for(const token of ['<title>MID Wetter','id="root"','name="mid-version"','rel="manifest"']){
  if(!home.body.includes(token))failures.push(`Startdokument enthält Pflichtmerkmal nicht: ${token}`);
 }
 const assetUrls=new Set();
 for(const match of home.body.matchAll(/(?:src|href)=["']([^"']+)["']/g)){
  const value=match[1];
  if(/^(?:\.\/|\/)?(?:assets\/|manifest\.webmanifest|service-worker\.js|sw\.js|version\.json|mid-logo\.png)/.test(value))assetUrls.add(new URL(value,baseUrl));
 }
 for(const url of [...assetUrls].slice(0,16))await fetchTimed(url);
}

const mandatoryFiles=['manifest.webmanifest','version.json','service-worker.js','sw.js'];
for(const relative of mandatoryFiles)await fetchTimed(new URL(relative,baseUrl));

const apex=await fetchTimed(apexUrl);
if(apex.response&&new URL(apex.response.url).hostname!==baseUrl.hostname){
 failures.push(`${apexUrl} endet nicht auf ${baseUrl.hostname}, sondern ${apex.response.url}`);
}

const report={schema:1,generatedAt:new Date().toISOString(),site:String(baseUrl),apex:String(apexUrl),ok:failures.length===0,failures,warnings,checks};
await mkdir('artifacts',{recursive:true});
await writeFile('artifacts/deployed-health.json',`${JSON.stringify(report,null,2)}\n`);
if(process.env.GITHUB_STEP_SUMMARY){
 const rows=checks.map(item=>`| ${item.status} | ${item.elapsedMs} ms | ${item.bytes} | ${item.url} |`).join('\n');
 await writeFile(process.env.GITHUB_STEP_SUMMARY,`## MID Live-Healthcheck\n\nStatus: **${report.ok?'bestanden':'fehlgeschlagen'}**\n\n| HTTP | Zeit | Bytes | URL |\n|---:|---:|---:|---|\n${rows}\n\n${warnings.length?`### Warnungen\n${warnings.map(item=>`- ${item}`).join('\n')}\n`:''}${failures.length?`### Fehler\n${failures.map(item=>`- ${item}`).join('\n')}\n`:''}`,{flag:'a'});
}
if(warnings.length)console.warn(`MID Live-Healthcheck Warnungen:\n- ${warnings.join('\n- ')}`);
if(failures.length){console.error(`MID Live-Healthcheck fehlgeschlagen:\n- ${failures.join('\n- ')}`);process.exit(1)}
console.log(`MID Live-Healthcheck bestanden: ${checks.length} Ressourcen geprüft.`);
