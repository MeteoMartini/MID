import {readFile,readdir,stat,mkdir,writeFile} from 'node:fs/promises';
import path from 'node:path';
import {gzipSync} from 'node:zlib';

const root=path.resolve(process.argv[2]||'dist');
const baseline=JSON.parse(await readFile(new URL('../MID_PERFORMANCE_BASELINE.json',import.meta.url),'utf8'));
const files=[];
async function walk(dir){for(const entry of await readdir(dir,{withFileTypes:true})){const full=path.join(dir,entry.name);if(entry.isDirectory())await walk(full);else files.push(full)}}
await walk(root);
const assets=[];
for(const file of files){const data=await readFile(file);assets.push({file:path.relative(root,file).replaceAll('\\','/'),bytes:data.length,gzipBytes:gzipSync(data,{level:9}).length,extension:path.extname(file).toLowerCase()})}
const js=assets.filter(item=>item.extension==='.js');
const css=assets.filter(item=>item.extension==='.css');
const totals={assetCount:assets.length,totalBytes:assets.reduce((sum,item)=>sum+item.bytes,0),totalGzipBytes:assets.reduce((sum,item)=>sum+item.gzipBytes,0),jsGzipBytes:js.reduce((sum,item)=>sum+item.gzipBytes,0),cssGzipBytes:css.reduce((sum,item)=>sum+item.gzipBytes,0),largestJsGzipBytes:Math.max(0,...js.map(item=>item.gzipBytes))};
const failures=[];
for(const [key,limit] of Object.entries(baseline.limits||{}))if(Number.isFinite(limit)&&totals[key]>limit)failures.push(`${key}: ${totals[key]} > ${limit}`);
const largest=[...assets].sort((a,b)=>b.gzipBytes-a.gzipBytes).slice(0,12);
const report={schema:1,generatedAt:new Date().toISOString(),root,ok:failures.length===0,limits:baseline.limits,totals,failures,largest};
await mkdir('artifacts',{recursive:true});
await writeFile('artifacts/build-budget.json',`${JSON.stringify(report,null,2)}\n`);
if(process.env.GITHUB_STEP_SUMMARY){const rows=largest.map(item=>`| ${item.file} | ${item.bytes} | ${item.gzipBytes} |`).join('\n');await writeFile(process.env.GITHUB_STEP_SUMMARY,`## MID Build-Budget\n\nStatus: **${report.ok?'bestanden':'fehlgeschlagen'}**\n\n\`\`\`json\n${JSON.stringify(totals,null,2)}\n\`\`\`\n\n| Größte Datei | Bytes | Gzip |\n|---|---:|---:|\n${rows}\n${failures.length?`\n### Überschreitungen\n${failures.map(item=>`- ${item}`).join('\n')}\n`:''}`,{flag:'a'})}
if(failures.length){console.error(`Build-Budget überschritten:\n- ${failures.join('\n- ')}`);process.exit(1)}
console.log(`Build-Budget bestanden: ${totals.assetCount} Dateien, ${totals.totalGzipBytes} Byte gzip.`);
