import {readFile,writeFile} from 'node:fs/promises';

const version=process.argv[2]||'0.9.19.0';
if(!/^\d+\.\d+\.\d+\.\d+$/.test(version))throw new Error(`Ungültige MID-Version: ${version}`);

function parts(value){return String(value).split('.').map(Number)}
function compare(a,b){
 const left=parts(a),right=parts(b);
 for(let index=0;index<Math.max(left.length,right.length);index++){
  const difference=(left[index]??0)-(right[index]??0);
  if(difference)return Math.sign(difference);
 }
 return 0;
}

const packageUrl=new URL('../package.json',import.meta.url);
const pkg=JSON.parse(await readFile(packageUrl,'utf8'));
const sourceVersion=String(pkg.version||'').trim();
if(compare(sourceVersion,'0.9.18.6')<0)throw new Error(`MID-Codebasis ist zu alt: v${sourceVersion}; mindestens v0.9.18.6 erforderlich.`);
if(compare(sourceVersion,version)>=0)throw new Error(`MID-Codebasis v${sourceVersion} ist bereits gleich neu oder neuer als das Revisionsziel v${version}.`);

const baselineUrl=new URL('../MID_BASELINE.json',import.meta.url);
const baseline=JSON.parse(await readFile(baselineUrl,'utf8'));
if(String(baseline.releaseVersion||'').trim()!==sourceVersion){
 throw new Error(`Baseline und package.json stimmen nicht überein: ${baseline.releaseVersion} / ${sourceVersion}`);
}
if(baseline.stableBranch!=='mid-stable')throw new Error(`Unerwarteter Stable-Branch in MID_BASELINE.json: ${baseline.stableBranch}`);

pkg.version=version;
pkg.scripts={
 ...pkg.scripts,
 'test:code-revision-automation':'node scripts/test-code-revision-automation-09190.mjs',
 'test:deployed-health':'node scripts/check-deployed-mid.mjs',
 'test:api-contracts':'node scripts/check-api-contracts.mjs',
 'test:build-budget':'node scripts/check-build-budget.mjs',
 'test:browser-smoke':'playwright test --config=playwright.config.mjs',
 'test:lighthouse':'lhci autorun --config=./lighthouserc.cjs'
};
// Browser-/Lighthouse-Werkzeuge werden im Performance-Job isoliert mit --no-save installiert.
// Das verifizierte MID-Lockfile und der bestehende Abhängigkeitsbaum bleiben bei der Revision unverändert.
await writeFile(packageUrl,`${JSON.stringify(pkg,null,2)}\n`);

baseline.releaseVersion=version;
baseline.requiredRegressionTests=[...new Set([...(baseline.requiredRegressionTests||[]),'scripts/test-code-revision-automation-09190.mjs'])];
baseline.regressionTests=[...new Set([...(baseline.regressionTests||[]),'scripts/test-code-revision-automation-09190.mjs'])];
await writeFile(baselineUrl,`${JSON.stringify(baseline,null,2)}\n`);

// Die jüngsten Cockpit-Regressionen enthielten noch einen exakten Release-String.
// Das ist bei einer reinen Versionsfortschreibung kein Funktionsfehler. Der Vertrag
// wird deshalb dauerhaft auf Synchronität zwischen package.json und MID_BASELINE.json
// umgestellt, statt eine konkrete Versionsnummer festzuschreiben.
const cockpitVersionTests=[
 'scripts/test-cockpit-meteogram-overlay-scale-09186.mjs',
 'scripts/test-cockpit-meteogram-pro-09180.mjs',
 'scripts/test-cockpit-shortterm-insight-09171.mjs',
 'scripts/test-cockpit-shortterm-interaction-09173.mjs',
 'scripts/test-cockpit-shortterm-premium-09172.mjs',
 'scripts/test-cockpit-windbarb-buildfix-09185.mjs'
];
const oldPackageAssertion=`need('Version',pkg,'\\"version\\": \\"${sourceVersion}\\"');`;
const oldBaselineAssertion=`need('Version',baseline,'\\"releaseVersion\\": \\"${sourceVersion}\\"');`;
const synchronizedVersionAssertion=[
 'const packageVersion=JSON.parse(pkg).version;',
 'const baselineVersion=JSON.parse(baseline).releaseVersion;',
 'if(packageVersion!==baselineVersion)failures.push(`Versionen nicht synchron: \${packageVersion} / \${baselineVersion}`);'
].join('\n');
for(const relativePath of cockpitVersionTests){
 const fileUrl=new URL(`../${relativePath}`,import.meta.url);
 let source=await readFile(fileUrl,'utf8');
 if(!source.includes(oldPackageAssertion)||!source.includes(oldBaselineAssertion)){
  throw new Error(`Veralteter Versionsvertrag in ${relativePath} wurde nicht eindeutig gefunden.`);
 }
 source=source.replace(oldPackageAssertion,synchronizedVersionAssertion).replace(oldBaselineAssertion,'');
 await writeFile(fileUrl,source);
}

const changelogUrl=new URL('../CHANGELOG.md',import.meta.url);
let changelog='';
try{changelog=await readFile(changelogUrl,'utf8')}catch{}
if(!changelog.includes(`## v${version}`)){
 const entry=`## v${version}\n- Automatisierte Code-Revision für Build, Regressionen, Sicherheitslücken, Open-Meteo-/API-Verträge und Produktiverreichbarkeit ergänzt.\n- Regelmäßige Playwright- und Lighthouse-Prüfungen mit vier Geräteprofilen sowie ein hartes Bundle-Größenbudget ergänzt.\n- CodeQL, Dependabot-Vorlage und deduplizierte GitHub-Issues für erkannte Fehler und Performance-Regressionsbefunde ergänzt.\n\n`;
 await writeFile(changelogUrl,entry+changelog);
}

console.log(`MID-Code-Revisionsmetadaten von v${sourceVersion} auf v${version} aktualisiert.`);
