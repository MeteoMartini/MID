import {defineConfig,devices} from '@playwright/test';

const baseURL=process.env.MID_SITE_URL||'https://www.midwx.app/';
export default defineConfig({
 testDir:'./tests/smoke',
 timeout:45000,
 expect:{timeout:12000},
 retries:2,
 workers:1,
 reporter:[['list'],['html',{outputFolder:'artifacts/playwright-report',open:'never'}]],
 use:{baseURL,trace:'on-first-retry',screenshot:'only-on-failure',video:'retain-on-failure',navigationTimeout:30000,actionTimeout:12000,serviceWorkers:'block'},
 projects:[
  {name:'mobile-portrait',use:{...devices['iPhone 13'],viewport:{width:390,height:844}}},
  {name:'mobile-landscape',use:{...devices['iPhone 13 landscape'],viewport:{width:844,height:390}}},
  {name:'tablet',use:{...devices['iPad (gen 7)'],viewport:{width:1024,height:768}}},
  {name:'desktop',use:{...devices['Desktop Chrome'],viewport:{width:1440,height:900}}}
 ]
});
